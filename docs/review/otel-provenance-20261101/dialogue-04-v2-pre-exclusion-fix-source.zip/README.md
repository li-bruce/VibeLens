# Team file sharing trial

This independent local trial implements the confirmed file review and owner sharing workflow with Python, Flask, SQLite, a declaration-driven state executor and the VibeLens developer graph. All accounts and files are synthetic.

## Start and stop

Run `./Start-Local.ps1` from this folder in PowerShell. It uses the local `.venv` when present, otherwise the explicitly authorized development environment at `../../SoftwareStatusObserverSkill/.venv`. Pass `-PythonPath` to choose another installed environment. The command starts the application, real delayed notification worker and VibeLens in one process. The terminal and `runtime/launcher.json` contain the current application and graph URLs. Both services bind only to localhost. Keep the process running; Ctrl+C stops it. `./Stop-Local.ps1` requests graceful shutdown after checking this project's process identity.

The synthetic accounts are `admin1`, `admin2`, `member1` and `member2`. Their password is `Trial2026!`. There is no registration.

## Workflow

Upload a file, then sign in as another administrator to approve or reject it. Administrators cannot review their own uploads. The decision remains pending until the background worker inserts the uploader's message and commits the resulting state in one SQLite transaction. The worker waits five seconds in the interactive application.

The uploader and administrators can read file information and download bytes in every state. After approval takes effect, the uploader can share with an existing colleague. The recipient's permission becomes active only when their share message and the grant commit together. Recipients cannot share onward. Rejected files and reasons remain available; there is no preview or resubmission. Each account sees only its own messages.

The uploader can revoke one colleague's pending or active share from its row. The
native revoke commit withdraws that grant immediately, cancels its waiting original
share job and queues a revocation notice for the same colleague. Old delivery work
cannot reactivate it. Notification failure does not undo committed revocation.
Other grants and independent uploader/administrator access remain available.

## Developer graph and evidence

The application links to the full VibeLens viewer. It exposes the source, state and policy declarations, selected native OTel execution context, SQLite operations and recordings. Use recording controls before a workflow, stop recording to flush queued observations, then select the saved recording for replay. Selected telemetry excludes file bytes, passwords, session secrets and SQL parameter values.

`bo_stategraph/project.json` contains the same state declaration consumed by the native executor. `app/` owns business decisions and transactions; `integrations/bo_integration.py` owns optional OTel/provenance formatting and capture. `--no-observer` runs the application and worker without the observer. Capture or transport failure does not grant permissions or activate business state.

Run `& '../../SoftwareStatusObserverSkill/.venv/Scripts/python.exe' -B -X utf8 tooling/verify.py` in PowerShell for the canonical scan, inspection, business/state/mapping checks, acceptance and final synchronization check. The active iteration is `.stategraph/revoke-sharing`; the earlier `initial-v1` and `http-entry-responses` records remain immutable. `review/revoke-implementation.md` explains the current change, and `review/http-entry-repair.md` retains the response repair evidence. The complete gate includes the earlier scenarios plus revocation, source routes, current native HTTP responses, invocation closure and migration checks. Browser acceptance is performed separately by the parent conversation.

`runtime/` contains the private SQLite database and generated session key. Tests use separate synthetic databases under `review/`. Initialization migrates the former observer-only `jobs.carrier` column to `jobs.bo_carrier` while preserving queued values and all business fields. The application is a localhost trial; production identity, deployment, storage quotas and operational recovery remain outside this confirmed scope.
