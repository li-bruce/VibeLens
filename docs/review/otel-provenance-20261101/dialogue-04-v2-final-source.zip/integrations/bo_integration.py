"""Optional OTel, probe transport, state snapshots and complete VibeLens service."""
import json
import copy
import re
import threading
from contextlib import contextmanager
from contextvars import ContextVar
from pathlib import Path
from opentelemetry.sdk.trace import TracerProvider,SpanProcessor
from opentelemetry import trace
from opentelemetry.instrumentation.flask import FlaskInstrumentor
from observer_runtime.bo_observer.service import GraphSession,make_server
from observer_runtime.bo_observer.adapters.python.bo_probe import BOProbe
from observer_runtime.bo_observer.adapters.python.bo_otel import BOOpenTelemetry,BOOpenTelemetryProcessor
from observer_runtime.bo_observer.policy.recording import record_evaluation
from observer_runtime.bo_observer.data.runtime import BODataRuntime
from app.ports import ObservationPort

_current=ContextVar("bo_trial_activation",default=None)

class BOHTTPRouteFields(SpanProcessor):
    """Select native route arguments before the graph processor reads HTTP entry."""
    def __init__(self):
        self.errors=0
    def on_start(self, span, parent_context=None):
        try:
            from flask import has_request_context,request
            if span.instrumentation_scope.name!=FlaskInstrumentor.__module__ or not has_request_context():
                return
            for name in ("operation","file_id"):
                if name in (request.view_args or {}):
                    span.set_attribute("team_files."+name,request.view_args[name])
        except Exception:
            self.errors+=1


def native_machine(snapshot):
    return {"configurations":[{"attempt":row["id"],"phase":row["state"],"state_revision":row["revision"],
        "revision":row["revision"],"run_build_id":row["build_id"],"context":{},"source_status":"current",
        "journal":[entry for entry in snapshot["journal"] if entry["entity_id"]==row["id"]]} for row in snapshot["instances"]]}

class BOIntegration(ObservationPort):
    def bo_authentication_provenance(self):
        from flask import has_request_context,session
        rows=self.store.read("SELECT id FROM users WHERE id=?",(session.get("user_id"),),observe=False) if has_request_context() else []
        return self.bo_provenance(rows[0] if rows else None)
    def bo_provenance(self, actor, file=None, extra=None):
        result={"actor":None if actor is None else {"id":actor["id"],"kind":"user"}}
        if file:
            result.update(workflow_id=file["workflow_id"],objects=[{"type":"File","id":file["id"],"role":"input"}])
        if extra:
            result.setdefault("objects",[]).extend(extra)
        return result
    def bo_worker_provenance(self, job):
        return {"actor":{"id":"notification-worker","kind":"service"},"workflow_id":job["workflow_id"],"objects":[{"type":"Job","id":job["id"],"role":"input"},{"type":"File","id":job["file_id"],"role":"input"},{"type":"User","id":job["recipient_id"],"role":"recipient"}]}
    def bo_completed_provenance(self, provenance, message_id):
        return {**provenance,"objects":provenance["objects"]+[{"type":"Message","id":message_id,"role":"output"}]}
    def bo_queue_metadata(self):
        return json.dumps(self.carrier())
    @contextmanager
    def bo_receive_metadata(self, metadata):
        with self.receive(json.loads(metadata)):
            yield
    def __init__(self, root, store, mode="on", capacity=4096):
        self.root,self.store=Path(root),store
        self.session=GraphSession(root)
        def failing_sink(kind,event):
            raise OSError("injected_observer_transport_failure")
        self.probe=BOProbe(self.session.project,self.session.manifest["build_id"],
            sink=failing_sink if mode=="fault" else self.session.bo_sink,enabled=mode!="off",capacity=capacity)
        self.provider=TracerProvider()
        self.http_fields=BOHTTPRouteFields()
        self.provider.add_span_processor(self.http_fields)
        self.tracing=self.probe.bo_bind_tracing(BOOpenTelemetry(self.provider.get_tracer("vibelens-team-files")))
        self.provider.add_span_processor(BOOpenTelemetryProcessor(self.tracing,json.loads((self.root/"bo_stategraph/telemetry.json").read_text(encoding="utf-8"))))
        self.session.bo_bind_capture(scope_setter=self.probe.bo_set_scope,flush_capture=self.probe.flush,health=self.health)
        self.data=BODataRuntime(self.probe,json.loads((self.root/"bo_stategraph/databases.json").read_text(encoding="utf-8")))
        store.bo=self
    @contextmanager
    def span(self, node, builder=lambda:{}, **options):
        def selected():
            value=builder()
            actor=(options.get("provenance") or {}).get("actor")
            if actor and actor.get("kind")=="user":
                value.setdefault("inputs",{})["actor_id"]=actor["id"]
            return value
        with self.probe.span(node,selected,**options) as activation:
            audit=getattr(self,"native_audit",None)
            if audit is not None and audit.active.get() is not None:
                context=trace.get_current_span().get_span_context()
                if context.is_valid:
                    audit.active.get()["trace_id"]=format(context.trace_id,"032x")
                    audit.active.get()["span_id"]=format(context.span_id,"016x")
                    audit.active.get()["_inside_span"]=True
                    audit.add(node,"enter",{key:audit.active.get()[key] for key in ("trace_id","span_id")},audit.active.get()["entry"])
            token=_current.set((node,activation))
            try:
                yield activation
            finally:
                if audit is not None and audit.active.get() is not None:
                    audit.active.get()["_inside_span"]=False
                _current.reset(token)
    def record(self, node, phase, builder=lambda:{}, **options):
        return self.probe.record(node,phase,builder,**options)
    def health(self):
        health=self.probe.bo_health()
        return {**health,"errors":health["errors"]+self.http_fields.errors,
                "http_route_errors":self.http_fields.errors,"data_errors":self.data.bo_errors}
    def carrier(self):
        return self.tracing.inject() if self.probe.bo_enabled else {}
    @contextmanager
    def receive(self, carrier):
        if not self.probe.bo_enabled:
            yield
            return
        with self.tracing.receive(carrier,trusted=True,link=True):
            yield
    def policy(self, evaluation):
        audit=getattr(self,"native_audit",None)
        if audit is not None and audit.active.get() is not None:
            audit.active.get().setdefault("policy_evaluations",[]).append(copy.deepcopy(evaluation))
            audit.record_policy(evaluation)
        context=self.probe.bo_current_context()
        return record_evaluation(self.session.model["policy"],evaluation,self.probe,
            entity=context.get("entity","application"),attempt=context.get("attempt","application"))
    def state(self, instance):
        current=_current.get()
        if current is None:
            return
        node,activation=current
        revision=instance["revision"]
        previous=activation.bo_options.get("revision")
        audit=getattr(self,"native_audit",None)
        if audit is not None:
            audit.record_state()
        activation.bo_options["revision"]=revision
        evidence=activation.record("change",lambda:{"outputs":{"state":instance["state"],"instance_id":instance["id"]}})
        if previous is None:
            activation.bo_options.pop("revision",None)
        else:
            activation.bo_options["revision"]=previous
        if evidence:
            journal=self.store.read("SELECT * FROM transitions WHERE entity_id=? ORDER BY id DESC LIMIT 1",(instance["id"],))
            self.probe.snapshot(instance["id"],instance["state"],{},revision,evidence,event=journal[0]["event"] if journal else None,guards={},payload={})
    def attach_flask(self, app):
        # The observer runs on its own HTTPServer listener; it has no Flask routes here.
        static_prefixes=[rule.rule.partition("<")[0] for rule in app.url_map.iter_rules()
                         if app.has_static_folder and rule.endpoint=="static"]
        self.bo_http_exclusions=tuple(static_prefixes)
        FlaskInstrumentor().instrument_app(app,tracer_provider=self.provider,
            excluded_urls=",".join(r"^https?://[^/]+"+re.escape(prefix) for prefix in static_prefixes))
    def execute(self, sql, parameters, callback):
        verb=sql.lstrip().split(None,1)[0].upper()
        if verb not in {"SELECT","INSERT","UPDATE","DELETE"}:
            return callback()
        node=("db_read" if self.probe.bo_current_context().get("provenance") else "db_context_read") if verb=="SELECT" else "db_write"
        return self.data.execute(node,callback,statement=sql,language="sql",parameters={"count":len(parameters)},summarize=lambda cursor:{"result":{"rowcount":cursor.rowcount},**({"rows":cursor.rowcount} if cursor.rowcount>=0 else {})})
    @contextmanager
    def transaction(self, manager):
        with self.data.transaction("db_transaction",manager) as resource:
            yield resource
    def transform(self, node, function, value, **options):
        return self.data.transform(node,function,value,**options)
    def serve(self, port, app_url):
        self.server=make_server(self.session,port=port,origins=(app_url,),assets=self.root/"static/graph")
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True,name="vibelens-http")
        self.thread.start()
        return "http://127.0.0.1:"+str(self.server.server_port)+"/graph"
    def close(self):
        self.data.close()
        self.probe.flush(5)
        self.probe.close()
        if hasattr(self,"server"):
            self.server.shutdown()
            self.server.server_close()
        self.session.close()
        self.provider.shutdown()
