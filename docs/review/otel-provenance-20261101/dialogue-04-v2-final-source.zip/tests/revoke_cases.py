"""Independent HTTP, SQLite and worker race expectations for share revocation."""
import threading
from concurrent.futures import ThreadPoolExecutor
from tests.http_cases import NativeHTTPAudit
from app.domain import TeamFiles
from bo_stategraph.workflow import Workflow
from tests.scenarios import ROOT

REVOKE_CASES=("revoke_active","revoke_pending","revoke_race","revoke_http_error")


def revoke_scenario(case,t):
    t.http_audit=NativeHTTPAudit(t.app)
    identity=t.upload()
    t.approve(identity)
    assert t.share(identity).status_code==201
    share=t.read("SELECT * FROM shares WHERE file_id=?",(identity,))[0]
    original=t.job(identity,"share")
    recipient=t.client("member2")
    download="/api/files/"+identity+"/download"
    endpoint="files/"+identity+"/revoke"
    notices=lambda: t.read("SELECT * FROM messages WHERE kind='revoke' AND file_id=?",(identity,))
    state=lambda: t.read("SELECT state FROM shares WHERE id=?",(share["id"],))[0]["state"]
    if case=="revoke_active":
        t.service.deliver_notification(original["id"])
        assert recipient.get(download).status_code==200
        owner=t.client("member1")
        response=owner.post("/command/revoke",data={"csrf":t.clients["member1"][1],"file_id":identity,"recipient_id":"member-2"})
        assert response.status_code==303
        assert state()=="revoked_share"
        assert not notices()
        immediate=recipient.get(download)
        assert immediate.status_code==403
        assert recipient.get("/file/"+identity).status_code==403
        assert owner.get(download).status_code==200
        assert t.client("admin2").get(download).status_code==200
        job=t.job(identity,"revoke")
        assert t.service.deliver_notification(job["id"])
        assert recipient.get(download).status_code==403
        assert notices()[0]["recipient_id"]=="member-2"
        # Revoking an administrator's share must retain their independent admin basis.
        assert t.share(identity,recipient_id="admin-1").status_code==201
        t.service.deliver_notification(t.job(identity,"share")["id"])
        assert t.post("member1",endpoint,json={"recipient_id":"admin-1"}).status_code==200
        admin_access=t.client("admin1").get(download)
        assert admin_access.status_code==200
        assert len(t.read("SELECT id FROM shares WHERE file_id=? AND state='revoked_share'",(identity,)))==2
        other=t.upload("admin1")
        assert t.review(other,username="admin2").status_code==200
        t.service.deliver_notification(t.job(other,"review")["id"])
        for target in ("member-1","member-2"):
            assert t.share(other,username="admin1",recipient_id=target).status_code==201
            t.service.deliver_notification(t.job(other,"share")["id"])
        assert t.post("admin1","files/"+other+"/revoke",json={"recipient_id":"member-1"}).status_code==200
        removed=t.client("member1").get("/api/files/"+other+"/download")
        retained=t.client("member2").get("/api/files/"+other+"/download")
        assert removed.status_code==403 and retained.status_code==200
        out={"immediate_download_status":immediate.status_code,"admin_access":admin_access.status_code,
             "notice_recipient":notices()[0]["recipient_id"],"file_state":t.state(identity),
             "targeted_isolation":removed.status_code==403 and retained.status_code==200}
    elif case=="revoke_pending":
        assert t.post("admin1",endpoint,json={"recipient_id":"member-2"}).status_code==403
        assert t.post("member2",endpoint,json={"recipient_id":"member-2"}).status_code==403
        assert state()=="share_notice_wait"
        saved_enqueue=t.service.enqueue
        def fail_outbox(connection,kind,file,share_id,recipient_id):
            if kind=="revoke":
                raise RuntimeError("synthetic_revoke_outbox_failure")
            return saved_enqueue(connection,kind,file,share_id,recipient_id)
        t.service.enqueue=fail_outbox
        t.app.config["TESTING"]=False
        try:
            assert t.post("member1",endpoint,json={"recipient_id":"member-2"}).status_code==500
        finally:
            t.service.enqueue=saved_enqueue
            t.app.config["TESTING"]=True
        assert state()=="share_notice_wait"
        assert t.read("SELECT state FROM jobs WHERE id=?",(original["id"],))[0]["state"]=="waiting"
        assert not t.read("SELECT id FROM jobs WHERE kind='revoke'")
        response=t.post("member1",endpoint,json={"recipient_id":"member-2"})
        assert response.status_code==200
        assert response.json["share"]["cancelled_jobs"]==1
        assert state()=="revoked_share"
        assert t.read("SELECT state FROM jobs WHERE id=?",(original["id"],))[0]["state"]=="cancelled"
        stale_result=t.service.deliver_notification(original["id"])
        assert not stale_result
        job=t.job(identity,"revoke")
        try:
            t.service.deliver_notification(job["id"],fail_after_message=True)
        except RuntimeError:
            pass
        else:
            raise AssertionError("The native revocation notification rollback did not execute")
        assert not notices()
        failed_notice_download=recipient.get(download)
        assert failed_notice_download.status_code==403
        restarted=TeamFiles(t.store,Workflow(ROOT),bo=t.service.bo,delay=0)
        audit=getattr(t.service.bo,"native_audit",None)
        if audit is not None:
            audit.attach_service(restarted)
        assert restarted.deliver_notification(job["id"])
        assert not restarted.deliver_notification(job["id"])
        again=t.post("member1",endpoint,json={"recipient_id":"member-2"})
        assert again.status_code==200 and not again.json["share"]["revoked"]
        assert again.json["share"]["job_id"]==job["id"]
        assert len(notices())==1 and notices()[0]["recipient_id"]=="member-2"
        assert recipient.get(download).status_code==403
        message_id=notices()[0]["id"]
        assert recipient.get("/api/messages/"+message_id).status_code==200
        foreign_notice=t.client("member1").get("/api/messages/"+message_id)
        assert foreign_notice.status_code==404
        assert not t.read("SELECT id FROM messages WHERE job_id=?",(original["id"],))
        out={"final_state":state(),"stale_job_result":stale_result,"revoke_messages":len(notices()),
             "download_after_failed_notice":failed_notice_download.status_code,"private_notice":foreign_notice.status_code==404}
    elif case=="revoke_race":
        selected=threading.Event()
        resume=threading.Event()
        original_read=t.store.read
        def delayed_read(sql,parameters=(),observe=True):
            rows=original_read(sql,parameters,observe=observe)
            if observe and sql=="SELECT * FROM jobs WHERE id=?" and parameters==(original["id"],):
                selected.set()
                assert resume.wait(15),"The prefetched worker was not released"
            return rows
        t.store.read=delayed_read
        try:
            with ThreadPoolExecutor(max_workers=1) as executor:
                future=executor.submit(t.service.deliver_notification,original["id"])
                try:
                    assert selected.wait(15),"The real worker did not prefetch its native job"
                    response=t.post("member1",endpoint,json={"recipient_id":"member-2"})
                    assert response.status_code==200
                    assert recipient.get(download).status_code==403
                finally:
                    resume.set()
                late_result=future.result(timeout=15)
                assert late_result is False
        finally:
            t.store.read=original_read
        assert state()=="revoked_share"
        assert not t.read("SELECT id FROM messages WHERE job_id=?",(original["id"],))
        t.service.deliver_notification(t.job(identity,"revoke")["id"])
        # Opposite serialization: delivery commits first, then revoke still wins.
        assert t.share(identity,recipient_id="admin-1").status_code==201
        t.service.deliver_notification(t.job(identity,"share")["id"])
        assert t.post("member1",endpoint,json={"recipient_id":"admin-1"}).status_code==200
        assert not t.read("SELECT id FROM shares WHERE file_id=? AND state='active_share'",(identity,))
        out={"final_state":state(),"late_worker_delivered":late_result,
             "late_share_messages":len(t.read("SELECT id FROM messages WHERE job_id=?",(original["id"],))),
             "both_serializations_revoked":not bool(t.read("SELECT id FROM shares WHERE file_id=? AND state='active_share'",(identity,)))}
    elif case=="revoke_http_error":
        t.app.config["TESTING"]=False
        owner=t.client("member1")
        assert owner.post("/command/revoke",data={"file_id":identity,"recipient_id":"member-2"}).status_code==403
        def fail(*args,**kwargs):
            raise RuntimeError("synthetic_revoke_framework_failure")
        saved=t.service.revoke_share
        t.service.revoke_share=fail
        try:
            form=owner.post("/command/revoke",data={"csrf":t.clients["member1"][1],"file_id":identity,"recipient_id":"member-2"})
            api=t.post("member1",endpoint,json={"recipient_id":"member-2"})
            assert form.status_code==500 and api.status_code==500
        finally:
            t.service.revoke_share=saved
        assert state()=="share_notice_wait" and not notices()
        out={"form_status":form.status_code,"api_status":api.status_code,"native_state_unchanged":state()=="share_notice_wait"}
    else:
        raise ValueError(case)
    out["frontend_business_passed"]=True
    return out
