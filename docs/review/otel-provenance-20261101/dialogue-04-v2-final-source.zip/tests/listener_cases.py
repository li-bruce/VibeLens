"""Native application responses for names also used on the separate observer listener."""
from tests.http_cases import NativeHTTPAudit

APPLICATION_PATHS=("/api/events","/api/view","/api/recordings","/api/design",
                   "/api/capture","/api/source","/api/stategraph/export",
                   "/api/bo/health","/api/unknown-native-operation")


def listener_scenario(trial):
    audit=NativeHTTPAudit(trial.app)
    trial.http_audit=audit
    before=trial.read("SELECT id,state,revision FROM files")
    anonymous=trial.app.test_client()
    responses=[]
    for path in APPLICATION_PATHS:
        response=anonymous.get(path)
        assert response.status_code==404 and response.json=={"error":"route_not_found"},(path,response.status_code,response.json)
        responses.append(response.status_code)
    # Valid native authentication/CSRF reaches the same unknown-operation boundary on POST.
    client=trial.client("member1")
    for path in APPLICATION_PATHS:
        response=client.post(path,json={},headers={"X-CSRF-Token":trial.clients["member1"][1]})
        assert response.status_code==404 and response.json=={"error":"route_not_found"},(path,response.status_code,response.json)
        responses.append(response.status_code)
    after=trial.read("SELECT id,state,revision FROM files")
    assert before==after and not trial.read("SELECT id FROM jobs") and not trial.read("SELECT id FROM messages")
    return {"unknown_get_requests":len(APPLICATION_PATHS),"unknown_post_requests":len(APPLICATION_PATHS),
            "native_statuses":responses,"native_storage_unchanged":before==after,"frontend_business_passed":all(status==404 for status in responses)}
