"""Real recording, framework-error and coordinated SDK upgrade checks."""
import io
import json
import shutil
import sqlite3
import subprocess
import unittest
from contextlib import closing
from pathlib import Path
from tests.scenarios import ROOT,Trial
from integrations.bo_integration import BOIntegration
from observer_runtime.bo_observer.observation.provenance import trace_metadata

class ObservationChecks(unittest.TestCase):
    def test_native_file_share_frame_identity_and_replay(self):
        trial=Trial()
        observer=BOIntegration(ROOT,trial.store)
        trial.service.bo=observer
        observer.attach_flask(trial.app)
        try:
            recording=observer.session.recordings.start("Native File and Share instances under one application caller")
            identity=trial.upload()
            initial_files={(identity,1):trial.state(identity)}
            trial.approve(identity)
            self.assertEqual(trial.share(identity).status_code,201)
            trial.service.deliver_notification(trial.job(identity,"share")["id"])
            self.assertEqual(trial.post("member1","files/"+identity+"/revoke",json={"recipient_id":"member-2"}).status_code,200)
            # Later real File snapshots must not inherit the revoked Share phase.
            later_file=trial.upload()
            initial_files[(later_file,1)]=trial.state(later_file)
            trial.approve(later_file)
            self.assertTrue(observer.probe.flush(10))
            native={row["id"]:row for row in trial.read("SELECT id,state,revision FROM files UNION ALL SELECT id,state,revision FROM shares")}
            journal={(row["entity_id"],row["revision"]):row for row in trial.read("SELECT * FROM transitions")}
            configurations=observer.session.view()["machine"]["configurations"]
            self.assertEqual({cfg["native_instance_id"]:cfg["phase"] for cfg in configurations},{key:row["state"] for key,row in native.items()})
            self.assertEqual({cfg["attempt"] for cfg in configurations},{"application"})
            self.assertEqual(len({cfg["snapshot_instance"] for cfg in configurations}),len(native))
            self.assertEqual(observer.session.recordings.stop()["status"],"stopped")
            saved=observer.session.recordings.get(recording["id"])
            self.assertFalse(saved["gaps"])
            self.assertEqual(saved["final"]["machine"]["configurations"],configurations)
            frames={frame["event_id"]:frame for frame in saved["runtime_frames"]["frames"]}
            previous={}
            expected=[]
            for event in saved["events"]:
                frame=frames.get(event["id"])
                if frame is None:
                    continue
                cfg=frame["machine"]["configurations"][0]
                key=cfg["native_instance_id"]
                self.assertEqual(cfg["snapshot_instance"],event["run_id"]+":"+key)
                self.assertEqual(event["outputs"]["instance_id"],key)
                self.assertEqual(event["outputs"]["state"],cfg["phase"])
                native_transition=journal.get((key,frame["revision"]))
                state=native_transition["after_state"] if native_transition else initial_files[(key,frame["revision"])]
                self.assertEqual(state,cfg["phase"])
                if key in previous and previous[key]!=cfg["phase"]:
                    expected.append([event["id"],previous[key],cfg["phase"]])
                previous[key]=cfg["phase"]
            self.assertGreaterEqual(len(expected),6)
            self.assertTrue(any(value["state"]=="revoked_share" for value in native.values()))
            recording_path=ROOT/"review/instance-frame-recording.json"
            recording_path.write_text(json.dumps(saved),encoding="utf-8")
            script='''import fs from "node:fs";
import { pathToFileURL } from "node:url";
const { boFacts } = await import(pathToFileURL(process.argv[2]));
const { timeline } = await import(new URL("recording.js",pathToFileURL(process.argv[2])));
const recording = JSON.parse(fs.readFileSync(process.argv[3], "utf8"));
const changes = boFacts(recording, timeline(recording)).changes.flat();
const flows = changes.filter(c => c.kind === "business" && c.field === "Flow");
process.stdout.write(JSON.stringify(flows.map(c => [c.event,c.before,c.after])));
'''
            completed=subprocess.run(["node","--experimental-default-type=module","--input-type=module","-",str(ROOT/"static/graph/replay-steps.js"),str(recording_path)],input=script,text=True,capture_output=True,encoding="utf-8",timeout=30)
            self.assertEqual(completed.returncode,0,completed.stderr)
            actual=json.loads(completed.stdout)
            self.assertEqual(actual,expected)
            self.assertFalse(any(before=="revoked_share" and after=="approved" for _,before,after in actual))
            self.assertEqual(observer.health()["errors"],0)
            (ROOT/"review/instance-frame-check.json").write_text(json.dumps({"native_instances":native,"frame_count":len(frames),"shared_attempt":"application","expected_same_instance_flows":expected,"actual_viewer_flows":actual,"false_cross_instance_transition":False,"probe_health":observer.health()},indent=2),encoding="utf-8")
        finally:
            observer.close()

    def test_native_api_nodes_keep_frontend_backend_api_layer(self):
        from observer_runtime.bo_observer.workflow.observation_requirements import layer_of
        ids=("api_get","api_post","api_command","api_file_info","api_workspace")
        project=json.loads((ROOT/"bo_stategraph/project.json").read_text(encoding="utf-8"))
        nodes={node["id"]:node for node in project["model"]["nodes"]}
        backend={identity:layer_of(nodes[identity]) for identity in ids}
        self.assertEqual(backend,{identity:"api" for identity in ids})
        script='''import fs from "node:fs";
import { pathToFileURL } from "node:url";
const { layerOf } = await import(pathToFileURL(process.argv[2]));
const project=JSON.parse(fs.readFileSync(process.argv[3],"utf8"));
const ids=JSON.parse(process.argv[4]);
process.stdout.write(JSON.stringify(Object.fromEntries(project.model.nodes.filter(n=>ids.includes(n.id)).map(n=>[n.id,layerOf(n)]))));
'''
        completed=subprocess.run(["node","--experimental-default-type=module","--input-type=module","-",str(ROOT/"static/graph/graph-layers.js"),str(ROOT/"bo_stategraph/project.json"),json.dumps(ids)],input=script,text=True,capture_output=True,encoding="utf-8",timeout=30)
        self.assertEqual(completed.returncode,0,completed.stderr)
        frontend=json.loads(completed.stdout)
        self.assertEqual(frontend,backend)
        (ROOT/"review/api-layer-check.json").write_text(json.dumps({"frontend":frontend,"backend":backend,"existing_node_declarations_unchanged":True},indent=2),encoding="utf-8")

    def test_independent_login_reader_emits_no_observation(self):
        from tests.native_audit import NativeAudit
        from flask import session
        trial=Trial()
        observer=BOIntegration(ROOT,trial.store)
        trial.service.bo=observer
        try:
            audit=NativeAudit(trial.service,observer.probe.bo_build,observer.session.model["revision"])
            before=observer.probe.bo_health()["enqueued"]
            with trial.app.test_request_context("/api/login"):
                session["user_id"]="member-1"
                for _ in range(3):
                    self.assertEqual(audit.native_context("sign_in",("member1","unused"))["actor"],{"id":"member-1","kind":"user"})
            self.assertEqual(observer.probe.bo_health()["enqueued"],before)
        finally:
            observer.close()

    def test_recording_control_and_focused_values(self):
        trial=Trial()
        observer=BOIntegration(ROOT,trial.store)
        trial.service.bo=observer
        observer.attach_flask(trial.app)
        try:
            trial.client("member1")
            self.assertTrue(observer.probe.flush(10))
            before=trial.store.snapshot(observer.probe.bo_build,observer.session.model["revision"])
            events_before=observer.probe.bo_health()["enqueued"]
            observer.session.view()
            observer.session.recordings.list()
            after=trial.store.snapshot(observer.probe.bo_build,observer.session.model["revision"])
            self.assertEqual(before,after)
            self.assertEqual(events_before,observer.probe.bo_health()["enqueued"])
            recording=observer.session.recordings.start("Actual HTTP upload with queued-stop")
            trial.upload()
            form=trial.client("member1").post("/command/upload",data={"csrf":trial.clients["member1"][1],"file":(io.BytesIO(b"Native recording form"),"recorded-form.txt")})
            self.assertEqual(form.status_code,303)
            pending=observer.probe.bo_health()["pending"]
            stopped=observer.session.recordings.stop()
            self.assertEqual(stopped["status"],"stopped",stopped)
            saved=observer.session.recordings.get(recording["id"])
            self.assertFalse(saved["gaps"],saved["gaps"])
            self.assertTrue(any(e["node"]=="upload_file" and e["phase"]=="commit" for e in saved["events"]))
            self.assertTrue(any(e["node"]=="api_command" and e["phase"]=="return" and e["outputs"]["status"]==form.status_code for e in saved["events"]))
            self.assertTrue(saved["producer_settlement"]["flushed"])
            focused=observer.session.recordings.start("Selected upload fields",scope={"mode":"focused","roots":["upload_file"]})
            trial.upload()
            narrow=observer.session.recordings.stop()
            self.assertEqual(narrow["status"],"stopped",narrow)
            selected=observer.session.recordings.get(focused["id"])
            self.assertTrue(any(e["node"]=="upload_file" and e.get("inputs",{}).get("filename")=="notes.txt" for e in selected["events"]))
            self.assertTrue(all(e["node"]=="upload_file" or e.get("context_only") for e in selected["events"]))
            self.assertIsNone(observer.probe.bo_capture_nodes)
            (ROOT/"review/recording-check.json").write_text(json.dumps({"queued_stop":stopped,"pending_at_stop":pending,"focused_stop":narrow},indent=2),encoding="utf-8")
        finally:
            observer.close()

    def test_actual_framework_error_response(self):
        trial=Trial()
        observer=BOIntegration(ROOT,trial.store)
        trial.service.bo=observer
        observer.attach_flask(trial.app)
        try:
            client=trial.client("member1")
            trial.app.config["TESTING"]=False
            def fail(actor):
                raise RuntimeError("synthetic_framework_failure")
            trial.service.list_files=fail
            response=client.get("/api/files")
            self.assertEqual(response.status_code,500)
            self.assertTrue(observer.probe.flush(10))
            events=[e for e in observer.session.current_events() if e["run_id"]==observer.probe.bo_run and e["node"]=="api_get" and e["phase"]=="return"]
            self.assertEqual(events[-1]["outputs"]["status"],response.status_code)
            self.assertEqual(events[-1]["exception"]["type"],"RuntimeError")
            self.assertEqual(observer.health()["errors"],0)
            (ROOT/"review/framework-error-check.json").write_text(json.dumps({"native_status":response.status_code,"recorded_status":events[-1]["outputs"]["status"],"exception":events[-1]["exception"],"probe_health":observer.health()},indent=2),encoding="utf-8")
        finally:
            observer.close()

    def test_actual_old_build_queue_context(self):
        trial=Trial()
        observer=BOIntegration(ROOT,trial.store)
        observer.close()
        current=json.loads((ROOT/"manifest.json").read_text(encoding="utf-8"))["build_id"]
        candidate=None
        for database in sorted((ROOT/"review").glob("case-*/trial.sqlite3")):
            if database==trial.store.path:
                continue
            with closing(sqlite3.connect("file:"+database.as_posix()+"?mode=ro",uri=True)) as connection:
                columns={row[1] for row in connection.execute("PRAGMA table_info(jobs)")}
                carrier_column="bo_carrier" if "bo_carrier" in columns else "carrier"
                for identity,carrier in connection.execute("SELECT id,"+carrier_column+" FROM jobs WHERE state='waiting'"):
                    value=json.loads(carrier)
                    envelope=value.get("vibelens-context")
                    if isinstance(envelope,str):
                        envelope=json.loads(envelope)
                    if envelope and envelope.get("build_id")!=current and value.get("traceparent"):
                        candidate=(database,identity,value,envelope["build_id"])
                        break
            if candidate:
                break
        self.assertIsNotNone(candidate,"A real earlier-build waiting job is required; synthetic tracing facts are not substituted.")
        database,job_id,carrier,old_build=candidate
        copied=trial.directory/"old-build-queue.sqlite3"
        with closing(sqlite3.connect("file:"+database.as_posix()+"?mode=ro",uri=True)) as source,closing(sqlite3.connect(copied)) as target:
            source.backup(target)
        from app.storage import Store
        from app.domain import TeamFiles
        from bo_stategraph.workflow import Workflow
        store=Store(copied)
        before=store.read("SELECT * FROM jobs",observe=False)
        job_kind=next(row["kind"] for row in before if row["id"]==job_id)
        store.initialize()
        after=store.read("SELECT * FROM jobs",observe=False)
        self.assertEqual([{("bo_carrier" if key=="carrier" else key):value for key,value in row.items()} for row in before],after)
        observer=BOIntegration(ROOT,store)
        try:
            entered=False
            with self.assertRaises(ValueError):
                with observer.tracing.receive(carrier,trusted=True,link=True,strict=True):
                    entered=True
            self.assertFalse(entered)
            strict_health=observer.health()
        finally:
            observer.close()
        observer=BOIntegration(ROOT,store)
        service=TeamFiles(store,Workflow(ROOT),bo=observer,delay=0)
        try:
            self.assertTrue(service.deliver_notification(job_id))
            self.assertTrue(observer.probe.flush(10))
            expected_node={"review":"deliver_review_notice","share":"deliver_share_notice","revoke":"deliver_revoke_notice"}[job_kind]
            events=[e for e in observer.session.current_events() if e["run_id"]==observer.probe.bo_run and e["node"]==expected_node]
            self.assertTrue(events)
            links=[link for event in events for link in event["trace"]["links"]]
            self.assertTrue(any(link.get("source_build_id")==old_build for link in links))
            self.assertTrue(all(event["build_id"]==current for event in events))
            self.assertTrue(all(event["provenance"]["actor"]=={"id":"notification-worker","kind":"service"} for event in events))
            self.assertEqual(observer.health()["errors"],0)
            (ROOT/"review/coordinated-upgrade-queue-check.json").write_text(json.dumps({"source_database":str(database),"source_job_kind":job_kind,"expected_node":expected_node,"source_build_id":old_build,"current_build_id":current,"strict_rejected":True,"strict_rejection_health":strict_health,"native_delivery_succeeded":True,"links":links,"normal_delivery_health":observer.health()},indent=2),encoding="utf-8")
        finally:
            observer.close()

if __name__=="__main__":
    unittest.main()
