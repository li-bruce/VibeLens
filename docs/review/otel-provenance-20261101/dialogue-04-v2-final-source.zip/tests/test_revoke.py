"""Revocation migration preservation, native terminal state and witness sensitivity."""
import copy
import json
import sqlite3
import unittest
from contextlib import closing
from tests.scenarios import ROOT,Trial
from app.storage import Store
from bo_stategraph.workflow import Workflow
from observer_runtime.bo_observer.workflow.whitebox_contract import assess

TABLES=("users","files","shares","jobs","messages","transitions")

class RevocationChecks(unittest.TestCase):
    def legacy_database(self,trial):
        identity=trial.upload()
        trial.approve(identity)
        self.assertEqual(trial.share(identity).status_code,201)
        path=trial.directory/"legacy-v2.sqlite3"
        with closing(sqlite3.connect(path)) as connection:
            connection.executescript((ROOT/"review/pre-revoke/legacy-schema.sql").read_text(encoding="utf-8"))
            for table in TABLES:
                for row in trial.read("SELECT * FROM "+table):
                    connection.execute("INSERT INTO "+table+" VALUES("+",".join("?" for _ in row)+")",list(row.values()))
            connection.commit()
        return path

    def rows(self,path):
        with closing(sqlite3.connect(path)) as connection:
            return {table:connection.execute("SELECT * FROM "+table+" ORDER BY id").fetchall() for table in TABLES}

    def test_schema_migration_preserves_native_rows(self):
        trial=Trial()
        path=self.legacy_database(trial)
        before=self.rows(path)
        store=Store(path)
        store.initialize()
        self.assertEqual(self.rows(path),before)
        store.initialize()
        self.assertEqual(self.rows(path),before)
        with closing(sqlite3.connect(path)) as connection:
            self.assertEqual(connection.execute("PRAGMA user_version").fetchone()[0],3)
            self.assertEqual(connection.execute("PRAGMA foreign_key_check").fetchall(),[])
        (ROOT/"review/revoke-migration-check.json").write_text(json.dumps({"rows_preserved":{table:len(rows) for table,rows in before.items()},"idempotent":True,"foreign_keys_valid":True,"version":3},indent=2),encoding="utf-8")

    def test_schema_migration_failure_rolls_back(self):
        trial=Trial()
        path=self.legacy_database(trial)
        before=self.rows(path)
        store=Store(path)
        with closing(store.connect(observe=False)) as connection:
            original=connection.execute
            def fail(sql,parameters=()):
                if sql=="ALTER TABLE jobs_upgrade RENAME TO jobs":
                    raise RuntimeError("synthetic_migration_failure")
                return original(sql,parameters)
            connection.execute=fail
            with self.assertRaisesRegex(RuntimeError,"synthetic_migration_failure"):
                store.migrate_revocation(connection)
            self.assertFalse(connection.in_transaction)
            self.assertEqual(connection.execute("PRAGMA foreign_keys").fetchone()[0],1)
        self.assertEqual(self.rows(path),before)
        with closing(sqlite3.connect(path)) as connection:
            self.assertEqual(connection.execute("PRAGMA user_version").fetchone()[0],2)
            self.assertFalse(connection.execute("SELECT name FROM sqlite_master WHERE name LIKE '%_upgrade'").fetchall())

    def test_native_revoked_state_cannot_deliver_a_grant(self):
        workflow=Workflow(ROOT)
        with self.assertRaises(ValueError):
            workflow.executor.step("revoked_share","deliver",{},{})

    def test_removed_and_wrong_revocation_witness_rejected(self):
        payload=json.loads((ROOT/"review/complete-runtime-observations.json").read_text(encoding="utf-8"))
        model=json.loads((ROOT/"bo_stategraph/project.json").read_text(encoding="utf-8"))["model"]
        contract=json.loads((ROOT/"whitebox.json").read_text(encoding="utf-8"))
        selected={"schema_version":1,"rules":[r for r in contract["rules"] if r["id"]=="revocation-native-state"],
                  "checks":[c for c in contract["checks"] if c["rule"]=="revocation-native-state"]}
        clean=assess(selected,model,payload,payload["build_id"])
        self.assertTrue(clean["valid"],clean)
        results=[]
        for mutation in ("missing_state_change","wrong_return_state"):
            isolated=copy.deepcopy(payload)
            run=next(r for r in isolated["runs"] if r["case"]=="revoke_pending" and r["mode"]=="on")
            if mutation=="missing_state_change":
                run["events"]=[e for e in run["events"] if not (e["node"]=="revoke_share" and e["phase"]=="change")]
            else:
                for event in run["events"]:
                    if event["node"]=="revoke_share" and event["phase"]=="return":
                        event["outputs"]["state"]="active_share"
            result=assess(selected,model,isolated,payload["build_id"])
            self.assertFalse(result["valid"],result)
            results.append({"mutation":mutation,"rejected":True,"diagnostics":result})
        (ROOT/"review/revoke-witness-negative-controls.json").write_text(json.dumps(results,indent=2),encoding="utf-8")
