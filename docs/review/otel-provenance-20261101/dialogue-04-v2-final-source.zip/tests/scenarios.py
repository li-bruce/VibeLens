"""Independent HTTP scenarios and native SQLite effect readers."""
import io
import json
import tempfile
import time
import threading
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from app.storage import Store
from app.domain import TeamFiles
from app.web import create_app
from bo_stategraph.workflow import Workflow

ROOT=Path(__file__).resolve().parents[1]
CASES=["login","approval","rejection","sharing","denials","delivery_failure","concurrent_delivery","message_privacy"]
from tests.http_cases import HTTP_CASES
CASES.extend(HTTP_CASES)
CASES.extend(("revoke_active","revoke_pending","revoke_race","revoke_http_error"))
CASES.append("listener_boundary")

class Trial:
    def __init__(self, directory=None):
        self.directory=Path(directory or tempfile.mkdtemp(prefix="case-",dir=ROOT/"review"))
        self.store=Store(self.directory/"trial.sqlite3")
        self.store.initialize()
        self.service=TeamFiles(self.store,Workflow(ROOT),delay=0)
        self.app=create_app(ROOT,self.service,"synthetic-test-secret")
        self.app.config["TESTING"]=True
        self.clients={}
    def client(self, username):
        if username not in self.clients:
            client=self.app.test_client()
            response=client.post("/api/login",json={"username":username,"password":"Trial2026!"})
            assert response.status_code==200,response.json
            self.clients[username]=(client,response.json["csrf"])
        return self.clients[username][0]
    def post(self, username, path, **kwargs):
        client=self.client(username)
        kwargs.setdefault("headers",{})["X-CSRF-Token"]=self.clients[username][1]
        return client.post("/api/"+path,**kwargs)
    def upload(self, username="member1"):
        response=self.post(username,"files",data={"file":(io.BytesIO(b"Synthetic team file\n"),"notes.txt")},content_type="multipart/form-data")
        assert response.status_code==201,response.json
        return response.json["file"]["id"]
    def review(self, identity, decision="approved", username="admin1", reason=""):
        return self.post(username,"files/"+identity+"/review",json={"decision":decision,"reason":reason})
    def share(self, identity, username="member1", recipient_id="member-2"):
        return self.post(username,"files/"+identity+"/share",json={"recipient_id":recipient_id})
    def job(self, identity, kind):
        return self.read("SELECT * FROM jobs WHERE file_id=? AND kind=? ORDER BY rowid DESC",(identity,kind))[0]
    def read(self, sql, parameters=()):
        return self.store.read(sql,parameters,observe=False)
    def state(self, identity):
        return self.read("SELECT state FROM files WHERE id=?",(identity,))[0]["state"]
    def approve(self, identity):
        assert self.review(identity).status_code==200
        self.service.deliver_notification(self.job(identity,"review")["id"])

def scenario(case, trial=None):
    t=trial or Trial()
    s=t.service
    if case=="login":
        client=t.app.test_client()
        assert client.get("/").status_code==200
        invalid=client.post("/api/login",json={"username":"member1","password":"incorrect"})
        valid=client.post("/api/login",json={"username":"member1","password":"Trial2026!"})
        roles=t.read("SELECT role,COUNT(*) AS total FROM users GROUP BY role")
        counts={row["role"]:row["total"] for row in roles}
        out={"valid_status":valid.status_code,"invalid_status":invalid.status_code,"seed_admins":counts["admin"],"seed_members":counts["member"]}
        reauthenticated=client.post("/api/login",json={"username":"member2","password":"Trial2026!"})
        failed_again=client.post("/api/login",json={"username":"admin1","password":"incorrect"})
        with client.session_transaction() as native_session:
            retained=native_session.get("user_id")
        out.update(reauthenticated_status=reauthenticated.status_code,existing_identity_failure_status=failed_again.status_code,identity_after_failure=retained)
    elif case=="approval":
        identity=t.upload("admin1")
        own=t.review(identity,username="admin1")
        member=t.review(identity,username="member1")
        response=t.review(identity,username="admin2")
        assert response.status_code==200,response.json
        waiting=t.state(identity)
        before=t.share(identity,username="admin1",recipient_id="member-1")
        s.deliver_notification(t.job(identity,"review")["id"])
        out={"self_review_status":own.status_code,"member_review_status":member.status_code,"waiting_state":waiting,
            "pre_delivery_share_status":before.status_code,"final_state":t.state(identity),
            "review_message_count":len(t.read("SELECT id FROM messages WHERE recipient_id='admin-1'"))}
    elif case=="rejection":
        identity=t.upload()
        response=t.review(identity,"rejected",reason="Trial rejection reason")
        assert response.status_code==200,response.json
        s.deliver_notification(t.job(identity,"review")["id"])
        file=t.read("SELECT * FROM files WHERE id=?",(identity,))[0]
        out={"final_state":file["state"],"reason":file["rejection_reason"],"bytes_retained":file["content"]==b"Synthetic team file\n",
            "owner_download_status":t.client("member1").get("/api/files/"+identity+"/download").status_code,
            "admin_download_status":t.client("admin2").get("/api/files/"+identity+"/download").status_code,
            "reshare_status":t.share(identity).status_code}
    elif case=="sharing":
        identity=t.upload(); t.approve(identity)
        response=t.share(identity)
        assert response.status_code==201,response.json
        waiting=response.json["share"]["state"]
        before=t.client("member2").get("/api/files/"+identity+"/download")
        s.deliver_notification(t.job(identity,"share")["id"])
        after=t.client("member2").get("/api/files/"+identity+"/download")
        reshare=t.share(identity,username="member2",recipient_id="admin-2")
        out={"waiting_state":waiting,"before_download_status":before.status_code,"after_download_status":after.status_code,
            "recipient_reshare_status":reshare.status_code,"message_count":len(t.read("SELECT id FROM messages WHERE recipient_id='member-2'"))}
    elif case=="denials":
        identity=t.upload()
        anonymous=t.app.test_client().get("/api/files")
        foreign=t.share(identity,username="member2",recipient_id="admin-2")
        download=t.client("member2").get("/api/files/"+identity+"/download")
        admin=t.client("admin2").get("/api/files/"+identity+"/download")
        t.client("admin2").get("/api/files/"+identity)
        t.client("admin2").get("/file/"+identity)
        out={"anonymous_status":anonymous.status_code,"nonowner_share_status":foreign.status_code,
            "unrelated_download_status":download.status_code,"other_admin_download_status":admin.status_code}
    elif case=="delivery_failure":
        identity=t.upload()
        assert t.review(identity).status_code==200
        job=t.job(identity,"review")
        try:
            s.deliver_notification(job["id"],fail_after_message=True)
        except RuntimeError:
            pass
        else:
            raise AssertionError("The injected native transaction failure did not occur")
        waiting=t.state(identity)
        messages=len(t.read("SELECT id FROM messages"))
        # A new application instance reads the persisted waiting job after restart.
        restarted=TeamFiles(t.store,Workflow(ROOT),bo=s.bo,delay=0)
        audit=getattr(s.bo,"native_audit",None)
        if audit is not None:
            audit.attach_service(restarted)
        restarted.deliver_notification(job["id"])
        # Independently verify rollback of a sharing transaction as well.
        assert t.share(identity).status_code==201
        share_job=t.job(identity,"share")
        try:
            restarted.deliver_notification(share_job["id"],fail_after_message=True)
        except RuntimeError:
            pass
        active=bool(t.read("SELECT 1 FROM shares WHERE file_id=? AND state='active_share'",(identity,)))
        out={"waiting_state":waiting,"messages_after_failure":messages,"state_after_retry":t.state(identity),
            "messages_after_retry":len(t.read("SELECT id FROM messages WHERE kind='review'")),"grant_after_failure":active}
    elif case=="concurrent_delivery":
        identity=t.upload(); assert t.review(identity).status_code==200
        job=t.job(identity,"review")
        barrier=threading.Barrier(2)
        original_read=t.store.read
        def concurrent_read(sql,parameters=(),observe=True):
            rows=original_read(sql,parameters,observe=observe)
            if observe and sql=="SELECT * FROM jobs WHERE id=?" and parameters==(job["id"],):
                barrier.wait(timeout=10)
            return rows
        t.store.read=concurrent_read
        try:
            with ThreadPoolExecutor(max_workers=2) as executor:
                results=list(executor.map(s.deliver_notification,[job["id"],job["id"]]))
        finally:
            t.store.read=original_read
        assert not s.deliver_notification(job["id"])
        out={"delivery_count":sum(results),"message_count":len(t.read("SELECT id FROM messages WHERE job_id=?",(job["id"],))),"final_state":t.state(identity)}
    elif case=="message_privacy":
        identity=t.upload(); t.approve(identity); assert t.share(identity).status_code==201
        s.deliver_notification(t.job(identity,"share")["id"])
        review=t.read("SELECT id FROM messages WHERE kind='review'")[0]["id"]
        foreign=t.client("member2").get("/api/messages/"+review)
        own=t.client("member1").get("/api/messages/"+review)
        owner=t.client("member1").get("/api/messages").json["items"]
        recipient=t.client("member2").get("/api/messages").json["items"]
        t.client("member1").get("/api/files")
        t.client("admin2").get("/api/reviews")
        t.client("member1").get("/api/users")
        t.client("member1").post("/command/logout",data={"csrf":t.clients["member1"][1]})
        out={"foreign_message_status":foreign.status_code,"own_message_status":own.status_code,
            "owner_review_messages":len([m for m in owner if m["kind"]=="review"]),
            "recipient_share_messages":len([m for m in recipient if m["kind"]=="share"])}
    elif case=="listener_boundary":
        from tests.listener_cases import listener_scenario
        out=listener_scenario(t)
    elif case.startswith("revoke_"):
        from tests.revoke_cases import revoke_scenario
        out=revoke_scenario(case,t)
    elif case in HTTP_CASES:
        from tests.http_cases import frontend_scenario
        out=frontend_scenario(case,t)
    else:
        raise ValueError(case)
    return t,out
