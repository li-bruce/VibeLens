"""Extend existing protected bindings with independently read native HTTP responses."""
import json
import argparse
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--observations",default="review/complete-runtime-observations.json")
    arguments=parser.parse_args()
    source=(ROOT/arguments.observations).resolve()
    source.relative_to(ROOT)
    payload=json.loads(source.read_text(encoding="utf-8"))
    plan=json.loads((ROOT/"mapping.json").read_text(encoding="utf-8"))
    bindings=json.loads((ROOT/"review/runtime-bindings.json").read_text(encoding="utf-8"))
    known={item["id"] for item in plan["context_fields"]}
    existing={(item["case"],item["node"],item["phase"]) for item in bindings["cases"]}
    for run in payload["runs"]:
        if run["mode"]!="on":
            continue
        if run["case"] not in plan["cases"]:
            plan["cases"].append(run["case"])
        for node,phases in run["native_calls"].items():
            for phase in phases:
                identity="native/"+run["case"]+"/"+node+"/"+phase
                if identity in known:
                    continue
                actual_key=[["trace_id"],["span_id"]]
                mapped_key=[["trace","trace_id"],["trace","span_id"]]
                if node.startswith("policy:"):
                    actual_key.append(["check_id"])
                    mapped_key.append(["inputs","bo_check"])
                plan["context_fields"].append({"id":identity,"case":run["case"],"node":node,"phase":phase,
                    "source":"tests/native_audit.py: independently read native invocation context and SDK identity.",
                    "each":{"collection":["native_calls",node,phase],"actual_key":actual_key,"mapped_key":mapped_key},
                    "actual":["provenance"],"mapped":["provenance"]})
                known.add(identity)
        for node in run.get("native_http",{}):
            for name,actual,mapped in [("identity",["trace_id"],["trace","trace_id"])]:
                identity="http/"+run["case"]+"/"+node+"/"+name
                if identity in known:
                    continue
                plan["context_fields"].append({"id":identity,"case":run["case"],"node":node,"phase":"return",
                    "source":"tests/http_cases.py: native WSGI start_response status and Flask route arguments; independent SDK SpanContext before teardown.",
                    "each":{"collection":["native_http",node],"actual_key":[["trace_id"],["span_id"]],
                            "mapped_key":[["trace","trace_id"],["trace","span_id"]]},
                    "actual":actual,"mapped":mapped})
                known.add(identity)
        for event in run["events"]:
            key=(run["case"],event["node"],event["phase"])
            if key not in existing:
                bindings["cases"].append(dict(zip(("case","node","phase"),key)))
                existing.add(key)
    for path,value in [("mapping.json",plan),("review/runtime-bindings.json",bindings)]:
        (ROOT/path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({"cases":len(plan["cases"]),"context_fields":len(plan["context_fields"])}))

if __name__=="__main__":
    main()
