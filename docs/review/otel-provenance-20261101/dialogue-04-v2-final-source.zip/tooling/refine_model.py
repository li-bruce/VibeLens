"""Reconcile native entrypoints, parameters and canonical source projections."""
import json
from observer_runtime.code_structure import enrich
from observer_runtime.bo_observer.policy.projection import project

def refine(root,model,index):
    nodes={n["id"]:n for n in model["nodes"]}
    changes={"upload_file","review_file","share_file","revoke_share","deliver_review_notice","deliver_share_notice"}
    for node in model["nodes"]:
        if node.get("layer")=="business":
            capture=node["capture"]
            capture["out"].pop("error",None)
            if node["id"] not in changes:
                keep={"view_file":{"state","file_id"},"download_file":{"file_id"},"deliver_revoke_notice":{"state","file_id"}}.get(node["id"],set())
                for key in ("state","file_id"):
                    if key not in keep:
                        capture["out"].pop(key,None)
            else:
                capture["out"]["instance_id"]="string"
            symbol=node.get("source",{}).get("symbol")
            if symbol not in {"TeamFiles.sign_in","TeamFiles.deliver_notification"}:
                capture["in"]["actor_id"]="string"
    nodes["sign_in"]["capture"]["in"]["credential_supplied"]="boolean"
    for identity in ("deliver_review_notice","deliver_share_notice","deliver_revoke_notice"):
        nodes[identity]["capture"]["in"]["fail_after_message"]="boolean"
    for identity,symbol,layer,inputs,outputs,label in [
        ("workspace","create_app.index","business",{"authenticated":"boolean"},{"file_count":"number","message_count":"number"},"文件工作区"),
        ("api_command","create_app.command","api",{"operation":"string","path":"string"},{"status":"number"},"提交表单"),
        ("api_file_info","create_app.details","api",{"file_id":"string","path":"string"},{"status":"number"},"打开文件信息"),
        ("api_workspace","create_app.index","api",{"path":"string"},{"status":"number"},"加载工作区页面")]:
        node={"id":identity,"kind":"action" if layer=="business" else "function","layer":layer,"label":identity,"summary":label,
            "source":{"path":"app/web.py","symbol":symbol},"capture":{"in":inputs,"out":outputs}}
        model["nodes"].append(node)
        model["presentation"]["names"]["nodes"][identity]={"en":identity.replace("_"," ").title(),"zh-CN":label}
    for identity in ("api_get","api_post"):
        nodes[identity]["capture"]={"in":{"path":"string"},"out":{"status":"number"}}
        nodes[identity]["source"]={"path":"app/web.py","symbol":"create_app.api_entry"}
    for node in model["nodes"]:
        if node["id"].startswith("source:"):
            node["parent"]="workspace"
    for start,end,label in [("api_workspace","workspace","Render workspace"),("api_file_info","view_file","Read authorized file information")]+[("api_command",node,"Dispatch form operation") for node in ("sign_in","sign_out","upload_file","review_file","share_file","revoke_share")]:
        model["edges"].append({"id":start+":"+end,"from":start,"to":end,"type":"flow","label":label,"evidence":"Explicit native handler dispatch."})
    cases={"upload":["approval"],"review":["approval"],"share":["sharing"],
        "view":["denials"],"download":["denials","sharing"],"revoke":["revoke_active","revoke_pending"]}
    for operation in model["policy"]["operations"]:
        operation["cases"]=cases[operation["id"]]
    model=project(model)
    nodes={n["id"]:n for n in model["nodes"]}
    plan=model["implementation"]
    plan["support"]={key:value for key,value in plan["support"].items() if index["symbols"][key]["kind"]=="function"}
    additions=[
        ("workspace","workspace",["workspace"],["app/web.py::create_app.index"]),
        ("workspace_page","workspace",["api_workspace"],["app/web.py::create_app.index"]),
        ("http_api","workspace",["api_get","api_post"],["app/web.py::create_app.api_entry"]),
        ("workspace_form","workspace",["api_command"],["app/web.py::create_app.command"]),
        ("file_information","view_file",["api_file_info"],["app/web.py::create_app.details"]),
        ("authorization","review_file",[n["id"] for n in model["nodes"] if n["id"].startswith("policy:") and any(n.get("capture",{}).values())],["app/policy.py::flag_enabled"]),
        ("storage","workspace",["db_read","db_context_read","db_write","db_transaction","db_metadata"],["app/storage.py::Connection.execute","app/storage.py::Store.transaction","app/domain.py::TeamFiles.metadata"])]
    for identity,business,owned,sources in additions:
        plan["features"].append({"id":identity,"label":identity.replace("_"," ").title(),"business_node":business,"nodes":owned,"sources":sources,"parameters":[],"cases":[]})
    for feature in plan["features"]:
        for source in feature["sources"]:
            plan["support"].pop(source,None)
            if feature["id"]=="storage":
                continue
            for parameter in index["symbols"][source]["parameters"]:
                name=parameter["name"]
                if name in {"self","cls"}:
                    continue
                node=nodes[feature["nodes"][0]]
                field,policy,reason=name,"value",""
                if name=="actor":
                    field,policy,reason="actor_id","derived","Authenticated principal ID; credentials and session tokens are excluded."
                elif name=="password":
                    field,policy,reason="credential_supplied","derived","Credential presence only."
                elif name=="content":
                    field,policy,reason="size","derived","File byte length only."
                elif feature["id"]=="http_api":
                    field,policy,reason="path","derived","Native HTTP target is /api/ plus the operation path."
                elif feature["id"]=="authorization":
                    node=nodes["policy:signed_in"]
                item={"source":source,"name":name,"node":node["id"],"direction":"in","field":field,"policy":policy}
                if reason:
                    item["reason"]=reason
                feature["parameters"].append(item)
    storage=next(feature for feature in plan["features"] if feature["id"]=="storage")
    storage["parameters"]=[
        {"source":"app/storage.py::Connection.execute","name":"sql","node":"db_read","direction":"in","field":"statement","policy":"derived","reason":"Literal-free parsed SQL shape; native credentials and values are withheld."},
        {"source":"app/storage.py::Connection.execute","name":"parameters","node":"db_read","direction":"in","field":"parameters","policy":"derived","reason":"Only the count of native SQL parameters is selected."},
        {"source":"app/domain.py::TeamFiles.metadata","name":"file","node":"db_metadata","direction":"out","field":"before","policy":"derived","reason":"Only native size and state are selected from the stored file."}]
    bindings=root/"review/runtime-bindings.json"
    if bindings.exists():
        saved=json.loads(bindings.read_text(encoding="utf-8"))
        for feature in plan["features"]:
            feature["cases"]=[item for item in saved["cases"] if item["node"] in feature["nodes"]]
    model["implementation"]=plan
    return enrich(model,index,1)
