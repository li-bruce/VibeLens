# Findings

## HTTP response continuation, 2026-11-01

- Continued only the source-only archive in this project. No original service or
  business database was accessed.
- Reproduced an actual 303 form response with empty `api_command` outputs.
- Reused upstream Flask instrumentation for native routes and final responses;
  removed the redundant manual form/detail request spans.
- Added independent WSGI response and SDK identity readers. A reader-only missing
  file failure was preserved and corrected without changing native behavior.
- Current backend verification details and boundaries are in
  `review/http-entry-repair.md`; independent browser testing belongs to the parent.

The invoked VibeLens skill is on feat/otel-provenance, with an already dirty maintained working tree. Use its current source and record exact input hashes.

The design graph was verified at http://127.0.0.1:53754/graph. Its host-only process is 93884. Restricted detached processes did not remain accessible; the inaccessible exec session 60950 was stopped. Port 8843 belongs to an unrelated project and must not be reused or stopped.

The canonical gates require independent source classification, protected mapping and business expectations, source-bound probes, public BOStateGraph export, real producer health, and per-case runtime witnesses. Application outcomes remain independent from observer availability.

Initial restricted venv ensurepip failed. Recreating the same project-local environment on the host succeeded with the skill's pinned OTel and jsonschema dependencies and Flask 3.1.3.


The native context binding problem is solved by the managed public `each` extension using native trace/span keys (plus native policy check ID for point events). It compares entire provenance objects from independent native boundary reads. Required invocation counts and both join sides remain strict. The initial baseline has eight protected scenarios and no scalar context fields; the exploratory split plan is preserved and its replacement is documented in review/complete-context-migration.json.

The authentication endpoint is not necessarily anonymous. A native pre-login session identity is read by the observation adapter without collection, independently checked by the test reader, and kept distinct from the successful authentication result. New-session failure, success, same-session success and existing-identity failure are exercised.
