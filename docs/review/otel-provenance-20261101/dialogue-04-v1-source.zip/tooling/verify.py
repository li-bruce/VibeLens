"""Canonical project verification entrypoint; preserve the initial baseline."""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT/"observer_runtime"))
from observer_runtime.bo_observer.workflow.sync_config import config,snapshot

def run(name,arguments):
    completed=subprocess.run([sys.executable,"-B","-X","utf8",*arguments],cwd=ROOT,capture_output=True,text=True,encoding="utf-8")
    (LOGS/(name+".stdout.log")).write_text(completed.stdout,encoding="utf-8")
    (LOGS/(name+".stderr.log")).write_text(completed.stderr,encoding="utf-8")
    if completed.returncode:
        print(name+" failed; see "+str(LOGS/(name+".stdout.log")),flush=True)
    return completed

def main():
    global LOGS
    attempt=1
    while (ROOT/"review"/f"http-entry-attempt-{attempt:02}").exists():
        attempt+=1
    LOGS=ROOT/"review"/f"http-entry-attempt-{attempt:02}"
    LOGS.mkdir()
    os.environ.setdefault("PYTHONUTF8","1")
    os.environ.setdefault("PYTHONDONTWRITEBYTECODE","1")
    os.environ.setdefault("TEAM_FILES_DB_URL","sqlite:///runtime/team-files.sqlite3")
    baseline=ROOT/".stategraph/initial-v1/baseline.json"
    before=hashlib.sha256(baseline.read_bytes()).hexdigest()
    if run("recall",["observer_runtime/change_sync.py","recall","--root",str(ROOT)]).returncode:
        return 1
    if run("build-model",["tooling/build_model.py"]).returncode:
        return 1
    if run("scan",["observer_runtime/bo_sync.py","scan","--root",str(ROOT)]).returncode:
        return 1
    cfg=config(ROOT,"sync.json")
    current=snapshot(ROOT,cfg)
    change=ROOT/json.loads((ROOT/".stategraph/active.json").read_text(encoding="utf-8"))["change"]
    review={"candidate_id":current["id"],"decisions":{
        "business":{"action":"unchanged","reason":"Preserve all confirmed native business rules and independent assertions."},
        "state_machine":{"action":"unchanged","reason":"Preserve the same native executor and declaration."},
        "abstraction":{"action":"updated","reason":"Connect each native frontend HTTP route to its source handler and user operation."},
        "probes":{"action":"updated","reason":"Upstream Flask spans own final responses; WSGI readers independently compare real status and SDK identity without duplicate request spans."}},
        "excluded_symbols":{},"requirement_changes":{"R_OBSERVE":"Complete frontend HTTP responses, parent calls and route coverage; retain every earlier protected field, case and mode."}}
    (change/"review.json").write_text(json.dumps(review,indent=2)+"\n",encoding="utf-8")
    result=run("inspect",["observer_runtime/change_sync.py","inspect","--root",str(ROOT)])
    if result.returncode:
        return 1
    result=run("verify",["observer_runtime/change_sync.py","verify","--root",str(ROOT)])
    try:
        report=json.loads(result.stdout)
        print(json.dumps({key:value.get("status") for key,value in report.get("reports",{}).items()}),flush=True)
    except (ValueError,AttributeError):
        pass
    if result.returncode:
        return 1
    for step in ("accept","check"):
        if run(step,["observer_runtime/change_sync.py",step,"--root",str(ROOT)]).returncode:
            return 1
    after=hashlib.sha256(baseline.read_bytes()).hexdigest()
    if before!=after:
        raise AssertionError("The initial baseline changed")
    (ROOT/"review/baseline-integrity.json").write_text(json.dumps({"unchanged":True,"sha256":after})+"\n",encoding="utf-8")
    print("Canonical verify, accept and check passed; original baseline is unchanged.",flush=True)
    return 0

if __name__=="__main__":
    raise SystemExit(main())
