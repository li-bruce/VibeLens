param([string]$PythonPath = '', [int]$AppPort = 0, [int]$GraphPort = 0)
$ErrorActionPreference = 'Stop'
if (-not $PythonPath) {
    $PythonPath = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
    if (-not (Test-Path -LiteralPath $PythonPath)) {
        $workspace = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
        $PythonPath = Join-Path $workspace 'SoftwareStatusObserverSkill\.venv\Scripts\python.exe'
    }
}
if (-not (Test-Path -LiteralPath $PythonPath)) { throw 'Pass an installed Python environment using -PythonPath.' }
& $PythonPath -B -X utf8 (Join-Path $PSScriptRoot 'dev.py') --app-port $AppPort --graph-port $GraphPort
exit $LASTEXITCODE
