"""Real recording, framework-error and coordinated SDK upgrade checks."""
import io
import json
import shutil
import sqlite3
import unittest
from contextlib import closing
from pathlib import Path
from tests.scenarios import ROOT,Trial
from integrations.bo_integration import BOIntegration
from observer_runtime.bo_observer.observation.provenance import trace_metadata

class ObservationChecks(unittest.TestCase):
    def test_independent_login_reader_emits_no_observation(self):
        from tests.native_audit import NativeAudit
        from flask import session
        trial=Trial()
        observer=BOIntegration(ROOT,trial.store)
        trial.service.bo=observer
        try:
            audit=NativeAudit(trial.service,observer.probe.bo_build,observer.session.model["revision"])
            before=observer.probe.bo_health()["enqueued"]
            with trial.app.test_request_context("/api/login"):
                session["user_id"]="member-1"
                for _ in range(3):
                    self.assertEqual(audit.native_context("sign_in",("member1","unused"))["actor"],{"id":"member-1","kind":"user"})
            self.assertEqual(observer.probe.bo_health()["enqueued"],before)
        finally:
            observer.close()

    def test_recording_control_and_focused_values(self):
        trial=Trial()
        observer=BOIntegration(ROOT,trial.store)
        trial.service.bo=observer
        observer.attach_flask(trial.app)
        try:
            trial.client("member1")
            self.assertTrue(observer.probe.flush(10))
            before=trial.store.snapshot(observer.probe.bo_build,observer.session.model["revision"])
            events_before=observer.probe.bo_health()["enqueued"]
            observer.session.view()
            observer.session.recordings.list()
            after=trial.store.snapshot(observer.probe.bo_build,observer.session.model["revision"])
            self.assertEqual(before,after)
            self.assertEqual(events_before,observer.probe.bo_health()["enqueued"])
            recording=observer.session.recordings.start("Actual HTTP upload with queued-stop")
            trial.upload()
            form=trial.client("member1").post("/command/upload",data={"csrf":trial.clients["member1"][1],"file":(io.BytesIO(b"Native recording form"),"recorded-form.txt")})
            self.assertEqual(form.status_code,303)
            pending=observer.probe.bo_health()["pending"]
            stopped=observer.session.recordings.stop()
            self.assertEqual(stopped["status"],"stopped",stopped)
            saved=observer.session.recordings.get(recording["id"])
            self.assertFalse(saved["gaps"],saved["gaps"])
            self.assertTrue(any(e["node"]=="upload_file" and e["phase"]=="commit" for e in saved["events"]))
            self.assertTrue(any(e["node"]=="api_command" and e["phase"]=="return" and e["outputs"]["status"]==form.status_code for e in saved["events"]))
            self.assertTrue(saved["producer_settlement"]["flushed"])
            focused=observer.session.recordings.start("Selected upload fields",scope={"mode":"focused","roots":["upload_file"]})
            trial.upload()
            narrow=observer.session.recordings.stop()
            self.assertEqual(narrow["status"],"stopped",narrow)
            selected=observer.session.recordings.get(focused["id"])
            self.assertTrue(any(e["node"]=="upload_file" and e.get("inputs",{}).get("filename")=="notes.txt" for e in selected["events"]))
            self.assertTrue(all(e["node"]=="upload_file" or e.get("context_only") for e in selected["events"]))
            self.assertIsNone(observer.probe.bo_capture_nodes)
            (ROOT/"review/recording-check.json").write_text(json.dumps({"queued_stop":stopped,"pending_at_stop":pending,"focused_stop":narrow},indent=2),encoding="utf-8")
        finally:
            observer.close()

    def test_actual_framework_error_response(self):
        trial=Trial()
        observer=BOIntegration(ROOT,trial.store)
        trial.service.bo=observer
        observer.attach_flask(trial.app)
        try:
            client=trial.client("member1")
            trial.app.config["TESTING"]=False
            def fail(actor):
                raise RuntimeError("synthetic_framework_failure")
            trial.service.list_files=fail
            response=client.get("/api/files")
            self.assertEqual(response.status_code,500)
            self.assertTrue(observer.probe.flush(10))
            events=[e for e in observer.session.current_events() if e["run_id"]==observer.probe.bo_run and e["node"]=="api_get" and e["phase"]=="return"]
            self.assertEqual(events[-1]["outputs"]["status"],response.status_code)
            self.assertEqual(events[-1]["exception"]["type"],"RuntimeError")
            self.assertEqual(observer.health()["errors"],0)
            (ROOT/"review/framework-error-check.json").write_text(json.dumps({"native_status":response.status_code,"recorded_status":events[-1]["outputs"]["status"],"exception":events[-1]["exception"],"probe_health":observer.health()},indent=2),encoding="utf-8")
        finally:
            observer.close()

    def test_actual_old_build_queue_context(self):
        trial=Trial()
        observer=BOIntegration(ROOT,trial.store)
        observer.close()
        current=json.loads((ROOT/"manifest.json").read_text(encoding="utf-8"))["build_id"]
        candidate=None
        for database in sorted((ROOT/"review").glob("case-*/trial.sqlite3")):
            if database==trial.store.path:
                continue
            with closing(sqlite3.connect("file:"+database.as_posix()+"?mode=ro",uri=True)) as connection:
                columns={row[1] for row in connection.execute("PRAGMA table_info(jobs)")}
                carrier_column="bo_carrier" if "bo_carrier" in columns else "carrier"
                for identity,carrier in connection.execute("SELECT id,"+carrier_column+" FROM jobs WHERE state='waiting'"):
                    value=json.loads(carrier)
                    envelope=value.get("vibelens-context")
                    if isinstance(envelope,str):
                        envelope=json.loads(envelope)
                    if envelope and envelope.get("build_id")!=current and value.get("traceparent"):
                        candidate=(database,identity,value,envelope["build_id"])
                        break
            if candidate:
                break
        self.assertIsNotNone(candidate,"A real earlier-build waiting job is required; synthetic tracing facts are not substituted.")
        database,job_id,carrier,old_build=candidate
        copied=trial.directory/"old-build-queue.sqlite3"
        with closing(sqlite3.connect("file:"+database.as_posix()+"?mode=ro",uri=True)) as source,closing(sqlite3.connect(copied)) as target:
            source.backup(target)
        from app.storage import Store
        from app.domain import TeamFiles
        from bo_stategraph.workflow import Workflow
        store=Store(copied)
        before=store.read("SELECT * FROM jobs",observe=False)
        store.initialize()
        after=store.read("SELECT * FROM jobs",observe=False)
        self.assertEqual([{("bo_carrier" if key=="carrier" else key):value for key,value in row.items()} for row in before],after)
        observer=BOIntegration(ROOT,store)
        try:
            entered=False
            with self.assertRaises(ValueError):
                with observer.tracing.receive(carrier,trusted=True,link=True,strict=True):
                    entered=True
            self.assertFalse(entered)
            strict_health=observer.health()
        finally:
            observer.close()
        observer=BOIntegration(ROOT,store)
        service=TeamFiles(store,Workflow(ROOT),bo=observer,delay=0)
        try:
            self.assertTrue(service.deliver_notification(job_id))
            self.assertTrue(observer.probe.flush(10))
            events=[e for e in observer.session.current_events() if e["run_id"]==observer.probe.bo_run and e["node"] in {"deliver_review_notice","deliver_share_notice"}]
            self.assertTrue(events)
            links=[link for event in events for link in event["trace"]["links"]]
            self.assertTrue(any(link.get("source_build_id")==old_build for link in links))
            self.assertTrue(all(event["build_id"]==current for event in events))
            self.assertTrue(all(event["provenance"]["actor"]=={"id":"notification-worker","kind":"service"} for event in events))
            self.assertEqual(observer.health()["errors"],0)
            (ROOT/"review/coordinated-upgrade-queue-check.json").write_text(json.dumps({"source_database":str(database),"source_build_id":old_build,"current_build_id":current,"strict_rejected":True,"strict_rejection_health":strict_health,"native_delivery_succeeded":True,"links":links,"normal_delivery_health":observer.health()},indent=2),encoding="utf-8")
        finally:
            observer.close()

if __name__=="__main__":
    unittest.main()
