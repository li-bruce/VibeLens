"""HTTP source/response coverage, parent closure and isolated negative controls."""
import copy
import json
import unittest
from urllib.request import urlopen
from tests.scenarios import ROOT, Trial
from tests.http_cases import HTTP_CASES, ROUTES, check_http_run
from integrations.bo_integration import BOIntegration
from observer_runtime.bo_observer.code_graph.endpoints import endpoints
from observer_runtime.bo_observer.workflow.observation_requirements import invocation_closure


class FrontendHTTPChecks(unittest.TestCase):
    def payload(self):
        value=json.loads((ROOT/"review/complete-runtime-observations.json").read_text(encoding="utf-8"))
        self.assertEqual(value["build_id"],json.loads((ROOT/"manifest.json").read_text(encoding="utf-8"))["build_id"])
        return value

    def test_native_routes_responses_and_trace_parents(self):
        payload=self.payload()
        model=json.loads((ROOT/"bo_stategraph/project.json").read_text(encoding="utf-8"))["model"]
        index=json.loads((ROOT/"review/source-scan.json").read_text(encoding="utf-8"))
        nodes={node["id"]:node for node in model["nodes"]}
        source_routes={(method,route["path"],symbol["symbol"])
                       for symbol in index["symbols"].values() if symbol["path"]=="app/web.py"
                       for route in endpoints(symbol) for method in route["methods"]}
        summary=[]
        for case in HTTP_CASES:
            run=next(item for item in payload["runs"] if item["case"]==case and item["mode"]=="on")
            native={(row["method"],row["path"],row["symbol"]) for row in run["native_http_routes"]}
            self.assertEqual(native,source_routes)
            for method,path,symbol in native:
                node=nodes[ROUTES[(method,path)]]
                self.assertEqual(node["source"],{"path":"app/web.py","symbol":symbol})
            checked=check_http_run(run)
            self.assertEqual(run["probe_health"]["errors"],0)
            self.assertEqual(run["probe_health"]["dropped"],0)
            self.assertEqual(run["probe_health"]["tracing"]["automatic_open"],0)
            summary.append({"case":case,"requests":checked,"statuses":sorted({row["status"] for rows in run["native_http"].values() for row in rows})})
        closure=invocation_closure(payload,required=True,model=model)
        self.assertTrue(closure["valid"],closure)
        for case in HTTP_CASES:
            states=[run["authority_snapshot"] for run in payload["runs"] if run["case"]==case]
            # Scenario assertions independently check the same native outcomes in all modes.
            self.assertEqual(len(states),3)
            self.assertTrue(all(run["observations"]["frontend_business_passed"] for run in payload["runs"] if run["case"]==case))
        (ROOT/"review/http-native-response-check.json").write_text(json.dumps({"cases":summary,"closure":closure},indent=2),encoding="utf-8")

    def test_isolated_missing_and_wrong_response_rejected(self):
        original=next(run for run in self.payload()["runs"] if run["case"]=="frontend_commands" and run["mode"]=="on")
        failures=[]
        for mutation in ("missing_status","wrong_status","missing_return"):
            isolated=copy.deepcopy(original)
            event=next(event for event in isolated["events"] if event["node"]=="api_command" and event["phase"]=="return")
            if mutation=="missing_status":
                event["outputs"].pop("status")
            elif mutation=="wrong_status":
                event["outputs"]["status"]=200
            else:
                isolated["events"].remove(event)
            with self.assertRaises((AssertionError,KeyError)):
                check_http_run(isolated)
            failures.append({"mutation":mutation,"rejected":True,"scope":"In-memory copy only; original events remain intact."})
        (ROOT/"review/http-response-negative-controls.json").write_text(json.dumps(failures,indent=2),encoding="utf-8")

    def test_observer_static_and_export_requests_are_excluded(self):
        trial=Trial()
        observer=BOIntegration(ROOT,trial.store)
        trial.service.bo=observer
        observer.attach_flask(trial.app)
        try:
            graph_url=observer.serve(0,"http://127.0.0.1:1")
            base=graph_url.removesuffix("/graph")
            before=trial.store.snapshot(observer.probe.bo_build,observer.session.model["revision"])
            count=observer.probe.bo_health()["enqueued"]
            for path in ("/static/app.js","/static/style.css"):
                self.assertEqual(trial.app.test_client().get(path).status_code,200)
            statuses={}
            for path in ("/graph","/api/view","/api/stategraph/export","/api/recordings","/api/bo/health"):
                with urlopen(base+path,timeout=10) as response:
                    statuses[path]=response.status
                    response.read()
            self.assertEqual(observer.probe.bo_health()["enqueued"],count)
            self.assertEqual(trial.store.snapshot(observer.probe.bo_build,observer.session.model["revision"]),before)
            (ROOT/"review/http-exclusion-check.json").write_text(json.dumps({"statuses":statuses,"new_events":0,"business_unchanged":True},indent=2),encoding="utf-8")
        finally:
            observer.close()
