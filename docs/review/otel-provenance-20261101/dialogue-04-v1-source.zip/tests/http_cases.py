"""Native UI route and WSGI response readers; no values are read from BO events."""
import io
from opentelemetry import trace
from flask import request

HTTP_CASES = ("frontend_commands", "frontend_denials", "frontend_errors")
ROUTES = {
    ("GET", "/"): "api_workspace",
    ("POST", "/command/<operation>"): "api_command",
    ("GET", "/file/<file_id>"): "api_file_info",
    ("GET", "/api/<path:operation>"): "api_get",
    ("POST", "/api/<path:operation>"): "api_post",
}


class NativeHTTPAudit:
    def __init__(self, app):
        self.rows = []
        self.native_http = {}
        self.routes = [{"path": rule.rule, "method": method, "endpoint": rule.endpoint,
                        "symbol": app.view_functions[rule.endpoint].__qualname__.replace(".<locals>.", ".")}
                       for rule in app.url_map.iter_rules() if rule.endpoint != "static"
                       for method in sorted(rule.methods - {"HEAD", "OPTIONS"})]

        @app.after_request
        def read_native_response(response):
            context = trace.get_current_span().get_span_context()
            row = {"route": request.url_rule.rule if request.url_rule else None,
                   "method": request.method, "path": request.path,
                   "inputs": {"path": request.path, **{
                       key: value for key, value in (request.view_args or {}).items()
                       if key in {"operation", "file_id"} and not request.path.startswith("/api/")}},
                   "trace_id": format(context.trace_id, "032x"),
                   "span_id": format(context.span_id, "016x")}
            request.environ["trial.native_http"] = row
            return response

        original = app.wsgi_app

        def read_wsgi(environ, start_response):
            def native_start(status, headers, exc_info=None):
                row = environ.get("trial.native_http", {"path": environ["PATH_INFO"]})
                row["status"] = int(status.split()[0])
                row["location"] = dict(headers).get("Location")
                self.rows.append(row)
                node = ROUTES.get((row.get("method"), row.get("route")))
                if node:
                    self.native_http.setdefault(node, []).append(row)
                return start_response(status, headers, exc_info)
            return original(environ, native_start)
        app.wsgi_app = read_wsgi


def frontend_scenario(case, trial):
    t = trial
    audit = NativeHTTPAudit(t.app)
    t.http_audit = audit
    statuses = []

    def expect(response, status):
        statuses.append(response.status_code)
        assert response.status_code == status, (case, response.status_code, status)
        if status == 303:
            assert response.headers["Location"] == "/"
        return response

    def form(username, operation, **data):
        client = t.client(username)
        return client.post("/command/"+operation,
                           data={"csrf": t.clients[username][1], **data})

    if case == "frontend_commands":
        anonymous = t.app.test_client()
        expect(anonymous.get("/"), 200)
        expect(anonymous.post("/command/login", data={"username": "member1", "password": "Trial2026!"}), 303)
        # Use the same native session established by the actual HTML login form.
        with anonymous.session_transaction() as native_session:
            csrf = native_session["csrf"]
        t.clients["member1"] = (anonymous, csrf)
        expect(form("member1", "upload", file=(io.BytesIO(b"Native form bytes\n"), "form.txt")), 303)
        identity = t.read("SELECT id FROM files")[0]["id"]
        expect(anonymous.get("/"), 200)
        expect(anonymous.get("/file/"+identity), 200)
        expect(t.client("admin1").get("/"), 200)
        expect(form("admin1", "review", file_id=identity, decision="approved"), 303)
        assert t.state(identity) == "review_notice_wait"
        expect(form("member1", "share", file_id=identity, recipient_id="member-2"), 303)
        assert not t.read("SELECT id FROM shares")
        t.service.deliver_notification(t.job(identity, "review")["id"])
        expect(form("member1", "share", file_id=identity, recipient_id="member-2"), 303)
        assert t.state(identity) == "approved"
        recipient = t.client("member2")
        expect(recipient.get("/file/"+identity), 403)
        expect(recipient.get("/api/files/"+identity+"/download"), 403)
        t.service.deliver_notification(t.job(identity, "share")["id"])
        expect(recipient.get("/"), 200)
        expect(recipient.get("/file/"+identity), 200)
        downloaded = expect(recipient.get("/api/files/"+identity+"/download"), 200)
        assert downloaded.data == b"Native form bytes\n"
        expect(form("member2", "share", file_id=identity, recipient_id="admin-2"), 303)
        assert len(t.read("SELECT id FROM shares")) == 1
        expect(form("member1", "logout"), 303)
        expect(anonymous.get("/file/"+identity), 401)
        assert len(t.read("SELECT id FROM messages")) == 2
    elif case == "frontend_denials":
        identity = t.upload("admin1")
        owner = t.client("admin1")
        expect(form("admin1", "review", file_id=identity, decision="approved"), 303)
        assert t.state(identity) == "pending_review"
        expect(form("admin2", "review", file_id=identity, decision="rejected", reason="Retain the original"), 303)
        t.service.deliver_notification(t.job(identity, "review")["id"])
        assert t.state(identity) == "rejected"
        expect(owner.get("/file/"+identity), 200)
        assert expect(owner.get("/api/files/"+identity+"/download"), 200).data == b"Synthetic team file\n"
        expect(form("admin1", "share", file_id=identity, recipient_id="member-1"), 303)
        assert not t.read("SELECT id FROM shares")
        expect(t.client("member2").get("/file/"+identity), 403)
        expect(owner.get("/file/missing"), 404)
        expect(owner.get("/api/files/missing/download"), 404)
        expect(owner.post("/command/review", data={"file_id": identity}), 403)
        expect(owner.post("/command/share", data={"csrf": t.clients["admin1"][1]}, headers={"Origin": "http://foreign.invalid"}), 403)
        expect(owner.post("/command/login", data={"username": "admin1", "password": "incorrect"}), 303)
        expect(owner.get("/file/"+identity), 401)
        expect(owner.get("/api/files/"+identity+"/download"), 401)
        expect(owner.post("/command/upload", data={"csrf": "invalid"}), 403)
    elif case == "frontend_errors":
        identity = t.upload()
        client = t.client("member1")
        t.app.config["TESTING"] = False

        def fail(*args, **kwargs):
            raise RuntimeError("synthetic_native_http_failure")

        for name, method, path, data in [
            ("list_files", "GET", "/", None),
            ("upload_file", "POST", "/command/upload", {"csrf": t.clients["member1"][1], "file": (io.BytesIO(b"error"), "error.txt")}),
            ("review_file", "POST", "/command/review", {"csrf": t.clients["member1"][1], "file_id": identity, "decision": "approved"}),
            ("share_file", "POST", "/command/share", {"csrf": t.clients["member1"][1], "file_id": identity, "recipient_id": "member-2"}),
            ("view_file", "GET", "/file/"+identity, None),
            ("download_file", "GET", "/api/files/"+identity+"/download", None)]:
            original = getattr(t.service, name)
            setattr(t.service, name, fail)
            try:
                expect(client.open(path, method=method, data=data), 500)
            finally:
                setattr(t.service, name, original)
    else:
        raise ValueError(case)
    return {"native_http_statuses": statuses, "native_http_checks": len(statuses), "frontend_business_passed": True}


def check_http_run(run):
    """Recompute response comparisons from raw native and observed facts."""
    events = run["events"]
    by_id = {event["id"]: event for event in events}
    api_nodes = set(ROUTES.values())
    checked = 0
    for node, rows in run["native_http"].items():
        for row in rows:
            span = (row["trace_id"], row["span_id"])
            matched = [event for event in events if event["node"] in api_nodes
                       and (event["trace"]["trace_id"], event["trace"]["span_id"]) == span]
            assert len(matched) == 2, ("HTTP boundary count", row, len(matched))
            assert {event["node"] for event in matched} == {node}
            assert {event["phase"] for event in matched} == {"enter", "return"}
            returned = next(event for event in matched if event["phase"] == "return")
            assert returned["outputs"]["status"] == row["status"], ("Native HTTP status mismatch", row)
            assert all(event["inputs"] == row["inputs"] for event in matched), ("Native HTTP input mismatch", row)
            if row["status"] == 500:
                assert returned["exception"]["type"] == "RuntimeError"
            for event in events:
                if event["node"] in api_nodes or event.get("phase") != "enter":
                    continue
                metadata = event.get("trace", {})
                if (metadata.get("trace_id"), metadata.get("parent_span_id")) == span:
                    parent = by_id[event["parent_event_id"]]
                    assert parent["node"] == node and parent["phase"] == "enter"
                    assert parent["trace"]["span_id"] == row["span_id"]
            checked += 1
    assert sum(event["phase"] == "return" and event["node"] in api_nodes for event in events) == checked
    return checked
