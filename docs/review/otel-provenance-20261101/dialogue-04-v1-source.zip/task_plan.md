# Team file sharing implementation

## Objective

Deliver the confirmed Python/SQLite trial with a simple file, review and message interface, declaration-driven states, OpenTelemetry, and the canonical VibeLens viewer.

## Protected boundaries

- Work only in this independent project directory; maintained VibeLens input is read-only.
- Do not read or copy other trial implementations, databases, runtime evidence or credentials.
- Preserve original user dialogue and immutable initial verification baseline.
- Never patch canonical validators, fabricate events, weaken expectations or claim unrun checks passed.
- English source, identifiers and comments; Chinese conversation and localized display.

## Phases

1. Confirmed intent and independent verification contracts: complete.
2. Business storage, declaration executor and HTTP interface: complete.
3. Isolated OTel, database and VibeLens integration: complete.
4. Business, mapping, state and project verification: complete for the HTTP continuation; all four managed categories passed.
5. Backend recording/replay and joint launcher: verified; isolated application and graph URLs are live and their accepted build identity matches. Independent browser acceptance belongs to the parent conversation.

## Confirmed decisions

- Drive mode, SQLite, two administrators and two ordinary members, no registration.
- No self-review; only uploader shares; recipients cannot reshare.
- Owner and administrators access files in every state; recipients require active grants.
- Message insert and effect activation commit together; failure leaves waiting.
- Own-message access only; rejected files and reasons retained; no resubmission or preview.
