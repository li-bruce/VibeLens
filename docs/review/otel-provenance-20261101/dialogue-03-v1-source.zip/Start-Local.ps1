$ErrorActionPreference = 'Stop'
$pythonPath = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
& $pythonPath -B -X utf8 (Join-Path $PSScriptRoot 'dev.py')
exit $LASTEXITCODE
