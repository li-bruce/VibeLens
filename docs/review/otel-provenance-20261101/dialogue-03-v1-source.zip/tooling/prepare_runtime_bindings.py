"""Bind retained runtime cases to independent native context readers."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
TARGETS={"login":"sign_in","approval":"review_file","rejection":"deliver_review_notice","sharing":"share_file",
    "denials":"download_file","delivery_failure":"deliver_review_notice","concurrent_delivery":"deliver_review_notice","message_privacy":"read_message"}

def save(name,value):
    (ROOT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")

def main():
    payload=json.loads((ROOT/"review/runtime-observations.json").read_text(encoding="utf-8"))
    plan=json.loads((ROOT/"mapping.json").read_text(encoding="utf-8"))
    cases=[]; context=[]; seen=set()
    for run in payload["runs"]:
        if run["mode"]!="on":
            continue
        if run["case"] not in plan["cases"]:
            plan["cases"].append(run["case"])
        focus=TARGETS.get(run["case"]) or run["case"].split("__",1)[1].rsplit("_",1)[0]
        for event in run["events"]:
            key=(run["case"],event["node"],event["phase"])
            if key not in seen:
                seen.add(key)
                cases.append({"case":key[0],"node":key[1],"phase":key[2]})
            phase="completion" if event["node"]==focus and event["phase"] in {"return","commit"} else "entry"
            for component in event.get("provenance",{}):
                identity=key+(component,)
                if any(row["id"]=="/".join(identity) for row in context):
                    continue
                context.append({"id":"/".join(identity),"case":key[0],"node":key[1],"phase":key[2],
                    "source":"tests/native_audit.py: independent authenticated call arguments, native result and SQLite reads at the same boundary",
                    "actual":["native_context",phase,component],"mapped":["provenance",component]})
            if event["node"]==focus:
                identity=key+("sdk-trace",)
                if not any(row["id"]=="/".join(identity) for row in context):
                    context.append({"id":"/".join(identity),"case":key[0],"node":key[1],"phase":key[2],
                        "source":"Direct native OpenTelemetry SDK current SpanContext at the invocation boundary",
                        "actual":["native_trace_id"],"mapped":["trace","trace_id"]})
    plan["context_fields"]=context
    save("mapping.json",plan)
    save("review/runtime-bindings.json",{"source":"Actual native scenario entrypoints; no expected business values are inferred from probe output.","cases":cases})
    print(json.dumps({"cases":len(plan["cases"]),"context_fields":len(context),"runtime_bindings":len(cases)}))

if __name__=="__main__":
    main()
