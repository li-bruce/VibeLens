"""Complete native scenarios with all original events and per-call native facts."""
import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from tests.scenarios import CASES,Trial,scenario
from tests.native_audit import NativeAudit
from integrations.bo_integration import BOIntegration,native_machine
from bo_stategraph import BOStateGraph

def collect_case(case,mode):
    trial=Trial()
    observer=BOIntegration(ROOT,trial.store,mode=mode)
    observer.native_audit=NativeAudit(trial.service,observer.probe.bo_build,observer.session.model["revision"])
    trial.service.bo=observer
    observer.attach_flask(trial.app)
    try:
        _,observations=scenario(case,trial)
        flushed=observer.probe.flush(10)
        events=[event for event in observer.session.current_events() if event["run_id"]==observer.probe.bo_run]
        if mode=="on" and any(event.get("context_only") for event in events):
            raise AssertionError("Complete scenarios require full original observations")
        snapshot=trial.store.snapshot(observer.probe.bo_build,observer.session.model["revision"])
        machine=native_machine(snapshot)
        graph=BOStateGraph(observer.session.model,build_id=observer.probe.bo_build,mode="drive")
        graph.bo_require_definition(trial.service.workflow.machine)
        instances=graph.bo_instances(machine)
        actual={row["id"]:row for row in snapshot["instances"]}
        checks=[{"id":case+"/"+mode+"/"+item["observed"]["instance_id"]+"/"+key,
            "source":"Independent native SQLite read after the complete scenario","projection":"Public BOStateGraph.bo_instances",
            "actual":actual[item["observed"]["instance_id"]][key],"mapped":item["observed"][key]}
            for item in instances for key in ("state","revision","build_id")]
        native_calls=observer.native_audit.native_calls
        result={"case":case,"mode":mode,"events":events,"observations":observations,"native_calls":native_calls,
            "authority_snapshot":snapshot,"projection":{"build_id":observer.probe.bo_build,"machine":machine,"instances":instances},
            "probe_health":observer.health(),"mapping_checks":checks,"flush_complete":flushed,
            "policy_evaluations":[evaluation for record in observer.native_audit.records for evaluation in record.get("policy_evaluations",[])],
            "collector_health":{"errors":observer.session.errors,"last_error":observer.session.last_error},
            "scope_note":"The complete original scenario and every emitted original event; no call splitting, event rewriting or minimal-boundary substitution."}
        return result,graph.bo_export(runtime={"machine":machine})
    finally:
        observer.close()

def main():
    runs=[]; exported=None
    for mode in ("on","off","fault"):
        for case in CASES:
            run,public_export=collect_case(case,mode)
            runs.append(run)
            if case=="approval" and mode=="on":
                exported=public_export
    model=json.loads((ROOT/"bo_stategraph/project.json").read_text(encoding="utf-8"))["model"]
    payload={"build_id":runs[0]["projection"]["build_id"],"machine":model["machine"],"runs":runs,
        "mapping_checks":[check for run in runs for check in run["mapping_checks"]],"stategraph_export":exported}
    (ROOT/"review/complete-runtime-observations.json").write_text(json.dumps(payload,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(payload,ensure_ascii=False))

if __name__=="__main__":
    main()
