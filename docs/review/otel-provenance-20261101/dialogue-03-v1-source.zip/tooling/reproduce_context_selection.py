"""Minimal public context-selector reproduction using real HTTP and native facts."""
import json
import uuid
import sys
from contextlib import contextmanager
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from opentelemetry import trace
from tests.scenarios import ROOT,Trial
from integrations.bo_integration import BOIntegration
from observer_runtime.bo_observer.workflow.mapping_contract import validate_plan,assess_context_fields

def main():
    destination=ROOT/"review/framework-gap-context-selector"/uuid.uuid4().hex[:8]
    destination.mkdir(parents=True)
    trial=Trial()
    observer=BOIntegration(ROOT,trial.store)
    trial.service.bo=observer
    observer.attach_flask(trial.app)
    facts=[]; active=[None]
    original_span=observer.span
    @contextmanager
    def witness(node,builder=lambda:{},**options):
        with original_span(node,builder,**options) as activation:
            if node=="review_file" and active[0] is not None:
                context=trace.get_current_span().get_span_context()
                active[0]["native_sdk"]={"trace_id":format(context.trace_id,"032x"),"span_id":format(context.span_id,"016x")}
            yield activation
    observer.span=witness
    try:
        identity=trial.upload("admin1")
        trial.client("admin2")
        for username in ("admin1","admin2"):
            client=trial.client(username)
            with client.session_transaction() as native_session:
                user_id=native_session["user_id"]
            principal=trial.read("SELECT id,username,role FROM users WHERE id=?",(user_id,))[0]
            file=trial.read("SELECT id,owner_id,state FROM files WHERE id=?",(identity,))[0]
            fact={"username":username,"principal_before":{"actor":{"id":principal["id"],"kind":"user"},"role":principal["role"]},"file_before":file}
            active[0]=fact
            response=trial.review(identity,username=username)
            active[0]=None
            fact["native_http_status"]=response.status_code
            facts.append(fact)
        assert [fact["native_http_status"] for fact in facts]==[403,200]
        assert observer.probe.flush(10)
        events=[event for event in observer.session.current_events() if event["run_id"]==observer.probe.bo_run]
        assert not any(event.get("context_only") for event in events)
        rows=[{"id":"reviewer-"+str(index+1),"case":"two_reviewers","node":"review_file","phase":"enter",
            "source":"Native Flask session before the HTTP review, independently read user row and SDK SpanContext at invocation entry.",
            "actual":["native_requests",index,"principal_before","actor"],"mapped":["provenance","actor"]} for index in range(2)]
        plan={"schema":"bo-mapping/v1","cases":["two_reviewers"],"modes":["on"],"source":"Native session and SQLite readers",
            "actual_collection":["authority_snapshot","instances"],"actual_id":["id"],
            "fields":[{"id":key,"node":"upload_file","actual":[key],"mapped":[key]} for key in ("state","revision","build_id")],
            "export":{"case":"two_reviewers","mode":"on"},"context_fields":rows}
        validate_plan(plan,observer.session.model)
        payload={"runs":[{"case":"two_reviewers","mode":"on","events":events,"native_requests":facts,
            "authority_snapshot":trial.store.snapshot(observer.probe.bo_build,observer.session.model["revision"])}]}
        result=assess_context_fields(payload,plan)
        exact=[]
        for fact in facts:
            matches=[event for event in events if event["node"]=="review_file" and event["phase"]=="enter"
                and all(event.get("trace",{}).get(key)==value for key,value in fact["native_sdk"].items())]
            assert len(matches)==1
            event=matches[0]
            assert event["provenance"]["actor"]==fact["principal_before"]["actor"]
            exact.append({"native_username":fact["username"],"native_actor":fact["principal_before"]["actor"],
                "native_status":fact["native_http_status"],"native_sdk":fact["native_sdk"],
                "actual_event_id":event["id"],"recorded_actor":event["provenance"]["actor"]})
        assert result["valid"] is False and result["checks"]==4 and len(result["errors"])==2,result
        report={"kind":"public-context-selector-gap","case":"two_reviewers","node":"review_file","phase":"enter",
            "full_raw_events":len(events),"context_only_events":0,"native_per_invocation_matches":exact,
            "canonical_result":result,"probe_health":observer.health(),
            "required_binding":"Select each event by its independently read native trace_id and span_id, or another native invocation key; bind that selected event to the corresponding native request fact within the same case.",
            "acceptance":"This is a minimal public-checker reproduction, not complete application acceptance. No validator, raw event or protected project plan was changed."}
        for name,value in [("native-facts.json",facts),("raw-events.json",events),("context-plan.json",plan),("canonical-result.json",result),("report.json",report)]:
            (destination/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
        note="# Context selection cannot distinguish two native review calls\n\nThe same complete case executes two actual HTTP reviews of one file. The uploader's own review is denied; the other administrator's review succeeds. Native Flask sessions and SQLite rows independently establish the two principals. Direct SDK SpanContexts identify their actual invocations. Every original event, including full API ancestors, is retained.\n\nBoth public context rows select case=two_reviewers, node=review_file, phase=enter. Each row is applied to both events, so two correct native observations produce two mismatches. Adding another row cannot express which native invocation belongs to which event.\n\nRequired binding: retain one complete case, select an event by a native invocation key such as trace_id plus span_id, and compare it to the matching independent native fact. The two exact joins in report.json are diagnostic evidence, not replacement validators or acceptance.\n\nThe original protected mapping.json, initial baseline and strict complete-run check are unchanged by this reproduction.\n"
        (destination/"README.md").write_text(note,encoding="utf-8")
        print(json.dumps({"directory":str(destination),"full_raw_events":len(events),"canonical_checks":result["checks"],"canonical_errors":len(result["errors"]),"facts":[{"user":f["username"],"actor":f["principal_before"]["actor"]["id"],"status":f["native_http_status"]} for f in facts]},ensure_ascii=False))
    finally:
        observer.close()

if __name__=="__main__":
    main()
