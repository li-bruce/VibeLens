"""Export native SQL declarations using an ephemeral in-memory SQLite catalog."""
import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT/"observer_runtime"))
import sqlalchemy as sa
from app.storage import SCHEMA
from bo_observer.data.catalog import export_sqlalchemy_metadata

def main():
    engine=sa.create_engine("sqlite:///:memory:")
    raw=engine.raw_connection()
    try:
        raw.driver_connection.executescript(SCHEMA)
    finally:
        raw.close()
    metadata=sa.MetaData()
    metadata.reflect(engine)
    value=export_sqlalchemy_metadata(metadata,"team_sqlite",dialect=engine.dialect)
    value["limitations"].append("Native SQL DDL is reified only in ephemeral in-memory SQLite; no application database is opened or modified.")
    engine.dispose()
    print(json.dumps(value,sort_keys=True))

if __name__=="__main__":
    main()
