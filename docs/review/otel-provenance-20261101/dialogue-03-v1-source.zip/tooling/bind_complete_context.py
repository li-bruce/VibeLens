"""Bind complete protected scenarios to independently collected native invocations."""
import hashlib
import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

def save(path,value):
    (ROOT/path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")

def main():
    payload=json.loads((ROOT/"review/complete-runtime-observations.json").read_text(encoding="utf-8"))
    baseline=json.loads((ROOT/".stategraph/initial-v1/baseline.json").read_text(encoding="utf-8"))
    original=baseline["mapping_contract"]
    previous=json.loads((ROOT/"mapping.json").read_text(encoding="utf-8"))
    archive=ROOT/"review/pre-each-experimental-mapping.json"
    if not archive.exists():
        archive.write_text(json.dumps(previous,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    plan={**original,"context_fields":[]}
    bindings=[]
    for run in payload["runs"]:
        if run["mode"]!="on":
            continue
        assert run["case"] in original["cases"]
        assert not any(event.get("context_only") for event in run["events"])
        for node,phases in run["native_calls"].items():
            for phase,rows in phases.items():
                native_key=[["trace_id"],["span_id"]]
                mapped_key=[["trace","trace_id"],["trace","span_id"]]
                if node.startswith("policy:"):
                    native_key.append(["check_id"])
                    mapped_key.append(["inputs","bo_check"])
                plan["context_fields"].append({"id":"native/"+run["case"]+"/"+node+"/"+phase,
                    "case":run["case"],"node":node,"phase":phase,
                    "source":"tests/native_audit.py: native call arguments, independent authenticated session and SQLite reads, actual native result; SDK identity read at the same native callback. No expected values read from observed events.",
                    "each":{"collection":["native_calls",node,phase],"actual_key":native_key,"mapped_key":mapped_key},
                    "actual":["provenance"],"mapped":["provenance"]})
        bindings.extend({"case":run["case"],"node":node,"phase":phase} for node,phase in sorted({(event["node"],event["phase"]) for event in run["events"]}))
    assert set(original["cases"])=={run["case"] for run in payload["runs"]}
    save("mapping.json",plan)
    save("review/runtime-bindings.json",{"source":"Complete original native scenarios. Event identities select exercised technical boundaries; expected context values come exclusively from independent native readers.","cases":bindings})
    old=json.loads(archive.read_text(encoding="utf-8"))
    migration=[]
    for field in old.get("context_fields",[]):
        base=field["case"].split("__")[0]
        migration.append({"old":field["id"],"replacement":"native/"+base+"/"+field["node"]+"/"+field["phase"],"coverage":"Whole native provenance comparison at every original matching invocation; all actor, workflow and object components retained."})
    save("review/complete-context-migration.json",{"baseline_id":baseline["id"],"baseline_sha256":hashlib.sha256((ROOT/".stategraph/initial-v1/baseline.json").read_bytes()).hexdigest(),
        "protected_cases":original["cases"],"original_fields_retained":original["fields"]==plan["fields"],"modes_unchanged":original["modes"]==plan["modes"],
        "experimental_plan_archive":str(archive.relative_to(ROOT)),"replacement":"Managed canonical each binding; complete eight scenarios and unmodified original events.",
        "context_fields":len(plan["context_fields"]),"previous_context_bindings":migration,
        "source_isolation":{"formatting":"Moved from TeamFiles.provenance to BOIntegration.bo_provenance and bo_worker_provenance.","queue":"Native initialize renames jobs.carrier to jobs.bo_carrier without changing values or business columns; no queue reset.","native_reader":"Login reader uses direct observe=False SQLite reads and never calls the observed principal helper."}})
    print(json.dumps({"cases":len(plan["cases"]),"context_fields":len(plan["context_fields"]),"runtime_bindings":len(bindings)}))

if __name__=="__main__":
    main()
