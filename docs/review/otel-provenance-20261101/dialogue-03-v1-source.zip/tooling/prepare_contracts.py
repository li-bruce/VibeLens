"""Prepare confirmed intent and independent expectations before implementation."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def save(name, value):
    path = ROOT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

reply = "对，就按这张图。消息写进收件人的列表算投递成功，和审核结果或共享权限生效放在同一个事务里；没投递成功就保持等待，不提前生效。上传者和管理员在所有文件状态下都能查看、下载，但管理员不能审核自己的文件。只有上传者能分享自己的已生效文件，接收者不能转分享。审核消息发给上传者，共享消息发给指定同事，消息只能各自查看。驳回保留文件和原因，这一版不做重新提交；文件信息和下载就够了，不做预览。先准备两个管理员、两个普通成员供试用，不做注册。开始实现吧，把应用和 VibeLens 一起跑起来。"
discovery = json.loads((ROOT / "discovery.json").read_text(encoding="utf-8"))
save("review/discovery-before-confirmation.json", discovery)
discovery["sources"].append({"id":"U_CONFIRM","kind":"user","text":reply,"locator":"Current chat: explicit graph confirmation and implementation authorization, 2026-11-01"})
decision = next(item for item in discovery["decisions"] if item["id"] == "D_GRAPH")
discovery["changes"] = [{"id":"confirm-business-graph","decision":"D_GRAPH","previous":json.loads(json.dumps(decision)),"source_refs":["U_CONFIRM"],"reason":"The user explicitly confirmed the displayed graph and transaction interpretation."}]
decision.update(status="resolved", resolution={"kind":"user_answer","text":reply,"source_refs":["U_CONFIRM"]})
policy = discovery["policy"]
policy["revision"] = "team-files-confirmed-1"
policy["inputs"]["actor_is_uploader"] = "boolean"
policy["nodes"].append({"id":"not_uploader","op":"not","inputs":["is_uploader"],"label":"不是文件上传者","source_refs":["U_CONFIRM"]})
next(node for node in policy["nodes"] if node["id"] == "review_allowed")["inputs"].append("not_uploader")
for item in [*policy["nodes"],*policy["operations"]]:
    if "U_CONFIRM" not in item["source_refs"]:
        item["source_refs"].append("U_CONFIRM")
save("discovery.json", discovery)
with (ROOT / "review/design-dialogue.md").open("a", encoding="utf-8") as stream:
    stream.write("\n## Explicit graph confirmation and implementation authorization\n\n" + reply + "\n")

requirements = [
("R_LOGIN","Only authenticated seeded members use file operations; no registration."),
("R_ACCESS","Uploader and administrators access file information and download in every file state; other members require an effective recipient grant."),
("R_REVIEW","Only administrators other than the uploader may review a pending file."),
("R_ATOMIC","The recipient message and corresponding review decision or recipient grant take effect in the same SQLite commit; failed delivery retains waiting and no premature effect."),
("R_SHARE","Only the uploader may share their effectively approved file with a designated colleague; recipients cannot reshare."),
("R_MESSAGES","Review messages go to the uploader, share messages to the designated recipient, and each account reads only its own messages."),
("R_REJECT","Retain rejected file bytes and rejection reason; no resubmission or preview."),
("R_SEED","Provide exactly two synthetic administrators and two synthetic ordinary members."),
("R_BACKGROUND","Run actual delayed background notification work; preserve pending jobs across restart and prevent duplicate effects."),
("R_OBSERVE","Maintain the business/state/rule/source graph and actual OTel login, review, share, waiting and delivery evidence independently of business execution.")
]
save("intent.json", {"intent_id":"team-files-otel-dialogue-20261101-03","project_id":discovery["project_id"],"revision":"1","goal":discovery["goal"],"requirements":[{"id":key,"text":text,"status":"confirmed","source":"discovery.json::U_CONFIRM"} for key,text in requirements],"exclusions":["Registration","File preview","Resubmission","External email","Production deployment"]})
cases = ["login","approval","rejection","sharing","denials","delivery_failure","concurrent_delivery","message_privacy"]
expectations = {
"login":{"valid_status":200,"invalid_status":401,"seed_admins":2,"seed_members":2},
"approval":{"self_review_status":403,"member_review_status":403,"waiting_state":"review_notice_wait","pre_delivery_share_status":403,"final_state":"approved","review_message_count":1},
"rejection":{"final_state":"rejected","reason":"Trial rejection reason","bytes_retained":True,"owner_download_status":200,"admin_download_status":200,"reshare_status":403},
"sharing":{"waiting_state":"share_notice_wait","before_download_status":403,"after_download_status":200,"recipient_reshare_status":403,"message_count":1},
"denials":{"anonymous_status":401,"nonowner_share_status":403,"unrelated_download_status":403,"other_admin_download_status":200},
"delivery_failure":{"waiting_state":"review_notice_wait","messages_after_failure":0,"state_after_retry":"approved","messages_after_retry":1,"grant_after_failure":False},
"concurrent_delivery":{"delivery_count":1,"message_count":1,"final_state":"approved"},
"message_privacy":{"foreign_message_status":404,"own_message_status":200,"owner_review_messages":1,"recipient_share_messages":1}
}
checks = []
for case, fields in expectations.items():
    req = {"login":"R_LOGIN","approval":"R_REVIEW","rejection":"R_REJECT","sharing":"R_SHARE","denials":"R_ACCESS","delivery_failure":"R_ATOMIC","concurrent_delivery":"R_BACKGROUND","message_privacy":"R_MESSAGES"}[case]
    for field, expected in fields.items():
        checks.append({"id":case+"-"+field,"requirement":req,"case":case,"path":[field],"equals":expected})
save("acceptance.json", {"description":"Independent business effects derived from the actual confirmed dialogue, fixed before behavior implementation.","checks":checks})
planned_files = ["app/domain.py","app/storage.py","app/web.py","app/policy.py","app/ports.py","bo_stategraph/workflow.py","integrations/bo_integration.py","static/index.html","static/app.js","static/style.css","dev.py","observe.py","tests/test_business.py","tooling/build_model.py","tooling/verify.py"]
for name in planned_files:
    path=ROOT/name
    path.parent.mkdir(parents=True,exist_ok=True)
    if not path.exists():
        path.write_text('"""Planned project module; behavior implementation has not started."""\n' if name.endswith(".py") else "", encoding="utf-8")
model = {"schema_version":3,"project_id":discovery["project_id"],"revision":"1","title":"Team file sharing","intent":"intent.json","source_files":planned_files,"nodes":[],"edges":[],"overview":[],"scope":{"observable":["Confirmed team file sharing"],"unknowns":["Implementation not yet written"]}}
save("behavior.json", model)
save("mapping.json", {"schema":"bo-mapping/v1","cases":cases,"modes":["on","off","fault"],"source":"app/storage.py::Store.snapshot","actual_collection":["authority_snapshot","instances"],"actual_id":["id"],"fields":[{"id":"state","node":"upload_file","actual":["state"],"mapped":["state"]},{"id":"revision","node":"upload_file","actual":["revision"],"mapped":["revision"]},{"id":"build","node":"upload_file","actual":["build_id"],"mapped":["build_id"]}],"export":{"case":"approval","mode":"on"}})
save("whitebox.json", {"schema_version":1,"rules":[{"id":"no-self-review","requirement":"R_REVIEW","category":"business","claim":"An administrator cannot review their own upload.","basis":"discovery.json::U_CONFIRM","node":"review_file","source":{"path":"app/domain.py","symbol":"TeamFiles.review_file"}},{"id":"atomic-delivery","requirement":"R_ATOMIC","category":"state","claim":"A successful notification commit activates its corresponding effect.","basis":"discovery.json::U_CONFIRM","node":"deliver_review_notice","source":{"path":"app/domain.py","symbol":"TeamFiles.deliver_notification"}}],"checks":[{"id":"approval-waiting","rule":"atomic-delivery","case":"approval","phase":"return","count":{"min":1},"fields":[{"path":["outputs","state"],"equals":"review_notice_wait"}],"select":{"node":"review_file"}},{"id":"approval-delivered","rule":"atomic-delivery","case":"approval","phase":"commit","count":{"min":1},"fields":[{"path":["outputs","state"],"equals":"approved"}]}]})
excluded = {".venv/**":"Isolated dependency environment.","observer_runtime/**":"Canonical runtime copy checked by input hashes and native gates.","static/graph/**":"Canonical viewer assets checked by copy parity.","bo_stategraph/__init__.py":"Canonical public query implementation checked by installed hashes and public export.","bo_stategraph/bo_contracts.py":"Canonical declaration validation.","bo_stategraph/execution_contract.py":"Canonical state constraint validation.","tooling/**":"Project model generation and verification tooling tracked separately.","tests/**":"Independent business tests executed separately.","observe.py":"Independent real scenario driver tracked and executed by the normal gate.","review/**":"Read-only trial evidence; not application implementation."}
code = ["app/domain.py","app/storage.py","app/web.py","app/policy.py","app/ports.py","bo_stategraph/workflow.py","integrations/bo_integration.py","static/app.js","dev.py"]
save("sync.json", {"model":"bo_stategraph/project.json","manifest":"manifest.json","discovery":"discovery.json","code_files":code,"watch_files":["tooling/build_model.py","tooling/verify.py","observe.py","tests/test_business.py","bo_stategraph/__init__.py","static/index.html","static/style.css","implementation.json"],"source_scope":{"roots":["."],"exclude":excluded,"require_symbol_classification":True},"stategraph":{"module":"bo_stategraph/__init__.py","development_mode":"drive","execution_mode":"drive","decision_source":"user","decision":"drive：按状态声明执行; confirmed in discovery.json::U_A1 and U_CONFIRM"},"require_mapping_witnesses":True,"require_probe_health":True,"require_observation_closure":True,"mapping_contract":"mapping.json","whitebox":"whitebox.json","acceptance":"acceptance.json","slice_depth":1,"probe_callees":["bo.span","bo.record"],"required_probes":[{"symbol":"app/domain.py::TeamFiles.upload_file","node":"upload_file","phase":"enter"},{"symbol":"app/domain.py::TeamFiles.review_file","node":"review_file","phase":"return"},{"symbol":"app/domain.py::TeamFiles.share_file","node":"share_file","phase":"return"}],"required_runtime_probes":[{"case":"approval","node":"review_file","phase":"return"},{"case":"sharing","node":"share_file","phase":"return"},{"case":"login","node":"sign_in","phase":"return"}],"probe_modes":["on","off","fault"],"observations_command":["{python}","-B","-X","utf8","observe.py"],"test_commands":[["{python}","-B","-X","utf8","-m","unittest","discover","-s","tests","-v"]],"timeout_seconds":180})
save("bo_stategraph/project.json",{"protocol":"bo-project/v1","project_id":discovery["project_id"],"selection":{"mode":"drive","source":"user","answer":"drive：按状态声明执行","locator":"discovery.json::U_A1"},"model":model})
save("implementation.json",{"schema":"bo-implementation/v1","features":[],"support":{},"excluded":{}})
print("Prepared confirmed intent, independent business expectations and planned source inventory.")
