"""Generate source mappings from the confirmed design and independent source scan."""
import copy
import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT/"observer_runtime"))
from observer_runtime.code_structure import scan
from observer_runtime.bo_observer.policy.projection import project as project_policy
from observer_runtime.behavior_model import capture

def save(name,value):
    path=ROOT/name
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")

def main():
    discovery=json.loads((ROOT/"discovery.json").read_text(encoding="utf-8"))
    cfg=json.loads((ROOT/"sync.json").read_text(encoding="utf-8"))
    source_files=sorted(set(cfg["code_files"]+cfg["watch_files"]+["bo_stategraph/telemetry.json","intent.json","discovery.json","mapping.json","whitebox.json","implementation.json","requirements.txt"]))
    states={"pending_review":"pending_review","review_notice_wait":"review_notice_wait","approved_file":"approved","rejected_file":"rejected","share_notice_wait":"share_notice_wait","active_share":"active_share"}
    machine={"engine":"bo.fsm","version":"1","state_type":"enum","states":list(states.values()),"values":list(states.values()),
        "initial":"pending_review","context":{},"guards":{},"events":{name:{"payload":{}} for name in ("review","approved","rejected","share","deliver")},
        "transitions":[{"source":"pending_review","trigger":"review","dest":"review_notice_wait"},{"source":"review_notice_wait","trigger":"approved","dest":"approved"},{"source":"review_notice_wait","trigger":"rejected","dest":"rejected"},{"source":"approved","trigger":"share","dest":"share_notice_wait"},{"source":"share_notice_wait","trigger":"deliver","dest":"active_share"}]}
    names={}; nodes=[]
    captures={
        "sign_in":({"username":"string"},{"user_id":"string","authenticated":"boolean"}),
        "upload_file":({"filename":"string","size":"number"},{"file_id":"string","state":"string"}),
        "review_file":({"file_id":"string","decision":"string","reason":"string"},{"file_id":"string","job_id":"string","state":"string","decision":"string"}),
        "share_file":({"file_id":"string","recipient_id":"string"},{"file_id":"string","share_id":"string","job_id":"string","state":"string"}),
        "view_file":({"file_id":"string"},{"file_id":"string","state":"string","size":"number"}),
        "download_file":({"file_id":"string"},{"file_id":"string","size":"number"}),
        "deliver_review_notice":({"job_id":"string","file_id":"string"},{"delivered":"boolean","state":"string","job_id":"string","message_id":"string"}),
        "deliver_share_notice":({"job_id":"string","file_id":"string"},{"delivered":"boolean","state":"string","job_id":"string","message_id":"string"}),
        "message_list":({},{"count":"number"})}
    for raw in discovery["networks"][0]["nodes"]:
        ident=raw["id"]
        node={"id":ident,"label":ident,"summary":raw["summary"],"kind":"state" if ident in states else "action","layer":"state" if ident in states else "business","capture":{"in":{},"out":{}},"requirements":["R_OBSERVE"]}
        names[ident]={"en":ident.replace("_"," ").title(),"zh-CN":raw["label"]}
        if ident in states:
            node["value"]=states[ident]
        else:
            symbol="deliver_notification" if ident.startswith("deliver_") else "list_messages" if ident=="message_list" else ident
            node["source"]={"path":"app/domain.py","symbol":"TeamFiles."+symbol}
            inputs,outputs=captures[ident]
            node["capture"]={"in":inputs,"out":{**outputs,"error":"string","state":"string","file_id":"string"}}
        nodes.append(node)
    for ident,symbol,label,inputs,outputs in [
        ("sign_out","sign_out","退出登录",{},{"signed_out":"boolean"}),
        ("list_files","list_files","列出可见文件",{},{"count":"number"}),
        ("list_reviews","list_reviews","列出待审核文件",{},{"count":"number"}),
        ("list_colleagues","users","选择接收同事",{},{"count":"number"}),
        ("read_message","read_message","读取本人消息",{"message_id":"string"},{"message_id":"string"})]:
        nodes.append({"id":ident,"kind":"action","layer":"business","label":ident,"summary":label,"source":{"path":"app/domain.py","symbol":"TeamFiles."+symbol},"capture":{"in":inputs,"out":{**outputs,"error":"string","state":"string","file_id":"string"}},"requirements":["R_OBSERVE"]})
        names[ident]={"en":ident.replace("_"," ").title(),"zh-CN":label}
    for ident,method in [("api_get","GET"),("api_post","POST")]:
        nodes.append({"id":ident,"kind":"function","layer":"api","label":method+" API","summary":"Complete native HTTP request and framework response boundary.","source":{"path":"app/web.py","symbol":"api_request"},"capture":{"in":{},"out":{"status":"number","error":"string"}}})
    edges=[{"id":e["id"],"from":e["from"],"to":e["to"],"type":e["relation"],"label":e["label"],"evidence":"Confirmed business relationship; runtime execution is captured separately."} for e in discovery["networks"][0]["edges"]]
    for api in ("api_get","api_post"):
        for node in nodes[:]:
            if node["layer"]=="business":
                edges.append({"id":api+":"+node["id"],"from":api,"to":node["id"],"type":"flow","label":"Dispatches selected operation","evidence":"Native HTTP dispatch; only actual calls establish execution."})
    policy=copy.deepcopy(discovery["policy"]); policy["stage"]="bound"
    policy["predicates"][0]["source"]={"path":"app/policy.py","symbol":"flag_enabled"}
    cases={"upload":["approval"],"review":["approval","rejection"],"share":["sharing"],"view":["denials"],"download":["sharing","denials"]}
    for operation in policy["operations"]:
        operation["cases"]=cases[operation["id"]]
    model={"schema_version":3,"project_id":discovery["project_id"],"revision":"1","title":"Team file sharing","intent":"intent.json","source_files":source_files,
        "nodes":nodes,"edges":edges,"machine":machine,"policy":policy,"overview":[{"node":n["id"],"x":(i%5)*280,"y":(i//5)*180} for i,n in enumerate(nodes)],
        "presentation":{"subject":"Team file sharing","names":{"nodes":names},"states":{"pending_review":"Waiting for review","review_notice_wait":"Review notification pending","approved":"Approved","rejected":"Rejected","share_notice_wait":"Share notification pending","active_share":"Shared"}},
        "scope":{"observable":["Authentication","File review","Owner sharing","Own messages","Transactional background notification delivery"],"unknowns":["Finite synthetic trial scenarios; no production deployment or whole-program semantic proof."]}}
    model=project_policy(model)
    index=scan(ROOT,cfg["code_files"])
    save("review/source-scan.json",index)
    existing={(n.get("source") or {}).get("path","")+"::"+(n.get("source") or {}).get("symbol",""):n["id"] for n in model["nodes"] if n.get("source")}
    support={}
    for identity,symbol in index.get("symbols",{}).items():
        path=identity.split("::",1)[0]
        lexical=identity.split("::",1)[1]
        if identity not in existing:
            ident="source:"+identity
            model["nodes"].append({"id":ident,"kind":"function","layer":"program","label":lexical,"summary":"Native source declaration; execution requires runtime evidence.","source":{"path":path,"symbol":lexical},"capture":{"in":{},"out":{}}})
            existing[identity]=ident
        support[identity]={"node":existing[identity],"reason":"Source-bound native implementation or supporting declaration."}
    features=[]
    # Selected feature parameters are declared explicitly; other source remains searchable support.
    for node in model["nodes"]:
        if node.get("layer")!="business":
            continue
        identity=node["source"]["path"]+"::"+node["source"]["symbol"]
        features.append({"id":node["id"],"label":node["label"],"business_node":node["id"],"nodes":[node["id"]],"sources":[identity],"parameters":[],"cases":[]})
    inventory={"schema":"bo-implementation/v1","features":features,"support":support,"excluded":{}}
    model["implementation"]=inventory
    from tooling.refine_model import refine
    model=refine(ROOT,model,index)
    save("implementation.json",model["implementation"])
    project={"protocol":"bo-project/v1","project_id":discovery["project_id"],"selection":{"mode":"drive","source":"user","answer":"drive：按状态声明执行","locator":"discovery.json::U_A1 and U_CONFIRM"},"model":model}
    save("bo_stategraph/project.json",project)
    import os
    os.environ.setdefault("TEAM_FILES_DB_URL","sqlite:///runtime/team-files.sqlite3")
    from bo_observer.data.sync import synchronize
    report=synchronize(ROOT,update=True)
    save("review/data-model-generation.json",report)
    if not report["valid"]:
        raise ValueError(json.dumps(report))
    project=json.loads((ROOT/"bo_stategraph/project.json").read_text(encoding="utf-8"))
    from observer_runtime.code_structure import enrich
    model=enrich(project["model"],index,1)
    project["model"]=model
    save("bo_stategraph/project.json",project)
    save("behavior.json",model)
    save("manifest.json",capture(ROOT,model))
    print(json.dumps({"nodes":len(model["nodes"]),"edges":len(model["edges"]),"source_errors":index.get("errors",[])},ensure_ascii=False))

if __name__=="__main__":
    main()
