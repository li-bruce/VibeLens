"""Native declaration-driven states and shared rule evaluation."""
import json
from pathlib import Path
from .bo_runtime import BOExecutor
from .policy.runtime import evaluate
from app.policy import flag_enabled

class Workflow:
    def __init__(self, root):
        self.root=Path(root)
        project=json.loads((self.root/"bo_stategraph/project.json").read_text(encoding="utf-8"))
        self.machine=project["model"]["machine"]
        self.policy=project["model"]["policy"]
        self.executor=BOExecutor(self.machine)
    def transition(self, connection, entity_id, current, event, revision, now):
        result=self.executor.step(current,event,{},{})
        connection.execute("INSERT INTO transitions(entity_id,event,before_state,after_state,revision,created_at) VALUES(?,?,?,?,?,?)",
            (entity_id,event,current,result["state"],revision,now))
        return result["state"]
    def permission(self, operation, inputs, bo=None):
        result=evaluate(self.policy,operation,inputs,{"flag_enabled":flag_enabled},source_root=self.root,fact_revision="request-local")
        if bo:
            bo.policy(result)
        return result["value"] is True
