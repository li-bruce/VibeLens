# Independent trial boundary

- Work only in this project folder. The maintained VibeLens repository is read-only input.
- Use the explicitly invoked VibeLens Skill from SoftwareStatusObserverSkill on
  feat/otel-provenance, not an older globally installed copy.
- Use synthetic accounts, files and business data. Do not reuse other trial databases,
  runtime records, credentials or already-accepted results.
- Keep source, identifiers and comments in English; converse in Chinese.
- Preserve public questions, confirmed answers and verification evidence under review/.
- When shared Skill/runtime defects prevent normal verification, save a minimal
  reproduction and report the framework gap. Do not patch copied canonical validators,
  reclassify missing captures as success, weaken tests or fabricate observed events.
- Application changes and native business bug fixes remain normal development.
- Do not push, release, merge or modify the maintained repository or other trials.

# Project graph integrity

- This project retains source bindings and selected runtime evidence in its developer graph.
- Before later edits, run `.venv/Scripts/python.exe observer_runtime/change_sync.py recall --root PROJECT` with this project's absolute path.
- Run the normal validation entrypoint, including `change_sync check`, before delivery. Preserve the initial baseline and independent expectations.
- VibeLens conversation guidance is active only when the user explicitly invokes `$vibelens` in that conversation. This file does not activate it for other chats.
- Manual viewer controls use `/vibelens` and the scoped control entrypoint. Normal business changes retain the confirmed drive choice and existing integrity gates.
