"""Pure predicate used by the shared permission declaration."""
def flag_enabled(value: bool) -> bool:
    return value is True
