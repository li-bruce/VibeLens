"""Local HTTP entrypoints and authenticated session boundaries."""
import io
import secrets
from pathlib import Path
from flask import Flask, jsonify, request, session, send_file, render_template_string, redirect, flash, get_flashed_messages
from app.domain import DomainError

def api_request(service, operation):
    actor=service.principal(session.get("user_id"))
    data=request.get_json(silent=True) or {}
    if request.method=="POST":
        if request.headers.get("Origin") and request.headers["Origin"]!=request.host_url.rstrip("/"):
            raise DomainError("origin_not_allowed")
        if operation!="login" and not secrets.compare_digest(request.headers.get("X-CSRF-Token",""),session.get("csrf","missing")):
            raise DomainError("csrf_required")
    if operation=="session" and request.method=="GET":
        session.setdefault("csrf",secrets.token_hex(24))
        return jsonify(user=actor,csrf=session["csrf"])
    if operation=="login" and request.method=="POST":
        session.clear()
        user=service.sign_in(str(data.get("username","")),str(data.get("password","")))
        session.update(user_id=user["id"],csrf=secrets.token_hex(24))
        return jsonify(user=user,csrf=session["csrf"])
    if operation=="logout" and request.method=="POST":
        result=service.sign_out(actor)
        session.clear()
        return jsonify(result)
    if operation=="users" and request.method=="GET":
        return jsonify(items=service.users(actor))
    if operation=="files" and request.method=="GET":
        return jsonify(items=service.list_files(actor))
    if operation=="files" and request.method=="POST":
        upload=request.files.get("file")
        if upload is None:
            raise DomainError("file_required",400)
        return jsonify(file=service.upload_file(actor,upload.filename or "",upload.read())),201
    if operation=="reviews" and request.method=="GET":
        return jsonify(items=service.list_reviews(actor))
    if operation=="messages" and request.method=="GET":
        return jsonify(items=service.list_messages(actor))
    parts=operation.split("/")
    if len(parts)==2 and parts[0]=="messages" and request.method=="GET":
        return jsonify(message=service.read_message(actor,parts[1]))
    if len(parts)>=2 and parts[0]=="files":
        identity=parts[1]
        if len(parts)==2 and request.method=="GET":
            return jsonify(file=service.view_file(actor,identity))
        if len(parts)==3 and parts[2]=="download" and request.method=="GET":
            filename,content=service.download_file(actor,identity)
            return send_file(io.BytesIO(content),as_attachment=True,download_name=filename,mimetype="application/octet-stream",max_age=0)
        if len(parts)==3 and parts[2]=="review" and request.method=="POST":
            return jsonify(file=service.review_file(actor,identity,str(data.get("decision","")),str(data.get("reason",""))))
        if len(parts)==3 and parts[2]=="share" and request.method=="POST":
            return jsonify(share=service.share_file(actor,identity,str(data.get("recipient_id","")))),201
    raise DomainError("route_not_found",404)

def create_app(root, service, secret_key, graph_url=""):
    root=Path(root)
    app=Flask(__name__,static_folder=str(root/"static"),static_url_path="/static")
    app.config.update(SECRET_KEY=secret_key,MAX_CONTENT_LENGTH=11*1024*1024,
        SESSION_COOKIE_HTTPONLY=True,SESSION_COOKIE_SAMESITE="Strict",JSON_AS_ASCII=False)
    @app.get("/")
    def index():
        actor=service.principal(session.get("user_id"))
        session.setdefault("csrf",secrets.token_hex(24))
        with service.bo.span("workspace",lambda:{"inputs":{"authenticated":actor is not None}}) as call:
            files=service.list_files(actor) if actor else []
            messages=service.list_messages(actor) if actor else []
            colleagues=service.users(actor) if actor else []
            reviews=service.list_reviews(actor) if actor and actor["role"]=="admin" else []
            names={item["id"]:item["display_name"] for item in colleagues}
            if actor:
                names[actor["id"]]=actor["display_name"]
            call.result(lambda:{"outputs":{"file_count":len(files),"message_count":len(messages)}})
            return render_template_string((root/"static/index.html").read_text(encoding="utf-8"),
                user=actor,files=files,messages=messages,colleagues=colleagues,reviews=reviews,names=names,
                csrf=session["csrf"],flashes=get_flashed_messages(),graph_url=app.config.get("GRAPH_URL",graph_url),
                labels={"pending_review":"等待审核","review_notice_wait":"审核结果待投递","approved":"审核通过",
                    "rejected":"已驳回","share_notice_wait":"共享消息待投递","active_share":"共享已生效"})
    @app.post("/command/<operation>")
    def command(operation):
        with service.bo.span("api_command",lambda:{"inputs":{"operation":operation}}):
            actor=service.principal(session.get("user_id"))
            if request.headers.get("Origin") and request.headers["Origin"]!=request.host_url.rstrip("/"):
                raise DomainError("origin_not_allowed")
            if operation!="login" and not secrets.compare_digest(request.form.get("csrf",""),session.get("csrf","missing")):
                raise DomainError("csrf_required")
            try:
                if operation=="login":
                    session.clear()
                    user=service.sign_in(request.form.get("username",""),request.form.get("password",""))
                    session.update(user_id=user["id"],csrf=secrets.token_hex(24))
                elif operation=="logout":
                    service.sign_out(actor)
                    session.clear()
                elif operation=="upload":
                    upload=request.files.get("file")
                    if upload is None:
                        raise DomainError("file_required",400)
                    service.upload_file(actor,upload.filename or "",upload.read())
                    flash("文件已上传，等待管理员审核。")
                elif operation=="review":
                    service.review_file(actor,request.form.get("file_id",""),request.form.get("decision",""),request.form.get("reason",""))
                    flash("审核结果等待消息投递，送达后生效。")
                elif operation=="share":
                    service.share_file(actor,request.form.get("file_id",""),request.form.get("recipient_id",""))
                    flash("共享消息等待投递，送达后同事才能访问。")
                else:
                    raise DomainError("route_not_found",404)
            except DomainError as error:
                flash({"invalid_credentials":"账号或密码不正确","review_not_allowed":"不能审核自己的文件；需要另一位管理员处理。",
                    "share_not_allowed":"只有上传者能共享审核已生效的文件。","invalid_review":"驳回时请填写原因。",
                    "share_already_exists":"已为这位同事创建共享。","authentication_required":"请先登录。"}.get(error.code,error.code))
            return redirect("/",code=303)
    @app.get("/file/<file_id>")
    def details(file_id):
        with service.bo.span("api_file_info",lambda:{"inputs":{"file_id":file_id}}):
            value=service.view_file(service.principal(session.get("user_id")),file_id)
            return render_template_string("<!doctype html><html lang='zh-CN'><meta charset='utf-8'><link rel='stylesheet' href='/static/style.css'><title>文件信息</title><main><a href='/'>← 返回文件列表</a><h1>文件信息</h1><section class='panel'><h2>{{ file.filename }}</h2><p>{{ file.size }} 字节</p><p>状态：{{ file.state }}</p><p>上传者：{{ file.owner_id }}</p>{% if file.rejection_reason %}<p>驳回原因：{{ file.rejection_reason }}</p>{% endif %}<a class='button-link' href='/api/files/{{ file.id }}/download'>下载</a></section></main></html>",file=value)
    @app.route("/api/<path:operation>",methods=["GET","POST"])
    def api_entry(operation):
        return api_request(service,operation)
    @app.errorhandler(DomainError)
    def domain_error(error):
        return jsonify(error=error.code),error.status
    @app.errorhandler(500)
    def internal_error(error):
        return jsonify(error="internal_error"),500
    @app.after_request
    def headers(response):
        response.headers["X-Content-Type-Options"]="nosniff"
        response.headers["Cache-Control"]="no-store"
        response.headers["Content-Security-Policy"]="default-src 'self'; style-src 'self'; script-src 'self'; frame-ancestors 'none'; base-uri 'self'"
        return response
    return app
