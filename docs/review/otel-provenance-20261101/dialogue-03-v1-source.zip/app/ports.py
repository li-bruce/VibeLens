"""Failure-isolated observation interface, independent from the observer service."""
from contextlib import contextmanager

class NativeActivation:
    def result(self, builder):
        pass
    def record(self, phase, builder):
        pass

class ObservationPort:
    def bo_authentication_provenance(self):
        return {}
    def bo_provenance(self, actor, file=None, extra=None):
        return {}
    def bo_worker_provenance(self, job):
        return {}
    def bo_completed_provenance(self, provenance, message_id):
        return {}
    def bo_queue_metadata(self):
        return "{}"
    @contextmanager
    def bo_receive_metadata(self, metadata):
        yield
    @contextmanager
    def span(self, node, builder=lambda: {}, **options):
        yield NativeActivation()
    def record(self, node, phase, builder=lambda: {}, **options):
        return None
    def carrier(self):
        return {}
    @contextmanager
    def receive(self, carrier):
        yield
    def state(self, instance):
        pass
    def policy(self, evaluation):
        pass
    def execute(self, sql, parameters, callback):
        return callback()
    @contextmanager
    def transaction(self, manager):
        with manager as resource:
            yield resource
    def transform(self, node, function, value, **options):
        return function(value)
