$ErrorActionPreference = 'Stop'
$infoPath = Join-Path $PSScriptRoot 'runtime\launcher.json'
if (-not (Test-Path -LiteralPath $infoPath)) { Write-Output 'This project has no launcher record.'; exit 0 }
$info = Get-Content -LiteralPath $infoPath -Raw | ConvertFrom-Json
if ($info.project_id -ne 'team-files-otel-dialogue-20261101-03') { throw 'Unexpected project identity.' }
$process = Get-CimInstance Win32_Process -Filter ('ProcessId = ' + [int]$info.pid)
if (-not $process) { Write-Output 'The project process has already stopped.'; exit 0 }
$expectedScript = Join-Path $PSScriptRoot 'dev.py'
if (-not $process.CommandLine.Contains($expectedScript)) { throw 'Process ownership could not be verified; no process was stopped.' }
@{ pid = [int]$info.pid } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'runtime\stop.json') -Encoding utf8
Write-Output ('Requested graceful shutdown of this project process ' + $info.pid)
