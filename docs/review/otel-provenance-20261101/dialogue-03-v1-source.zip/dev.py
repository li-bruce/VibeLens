"""Launch this project's application, worker and optional VibeLens service together."""
import argparse
import json
import os
import secrets
import signal
import threading
from pathlib import Path
from werkzeug.serving import make_server
from app.storage import Store
from app.domain import TeamFiles
from app.web import create_app
from bo_stategraph.workflow import Workflow

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--app-port",type=int,default=0)
    parser.add_argument("--graph-port",type=int,default=0)
    parser.add_argument("--no-observer",action="store_true")
    args=parser.parse_args()
    root=Path(__file__).resolve().parent
    runtime=root/"runtime"
    runtime.mkdir(exist_ok=True)
    key_path=runtime/"session.key"
    if not key_path.exists():
        key_path.write_text(secrets.token_hex(32),encoding="utf-8")
    store=Store(runtime/"team-files.sqlite3")
    store.initialize()
    os.environ.setdefault("TEAM_FILES_DB_URL","sqlite:///runtime/team-files.sqlite3")
    service=TeamFiles(store,Workflow(root))
    app=create_app(root,service,key_path.read_text(encoding="utf-8"))
    server=make_server("127.0.0.1",args.app_port,app,threaded=True)
    app_url="http://127.0.0.1:"+str(server.server_port)
    observer=None
    graph_url=""
    if not args.no_observer:
        try:
            from integrations.bo_integration import BOIntegration
            observer=BOIntegration(root,store)
            service.bo=observer
            observer.attach_flask(app)
            graph_url=observer.serve(args.graph_port,app_url)
        except Exception as error:
            print("Observer unavailable: "+type(error).__name__+": "+str(error),flush=True)
    app.config["GRAPH_URL"]=graph_url
    stopping=threading.Event()
    def worker():
        while not stopping.wait(0.5):
            stop_path=runtime/"stop.json"
            if stop_path.exists():
                try:
                    if json.loads(stop_path.read_text(encoding="utf-8-sig")).get("pid")==os.getpid():
                        stop(0,None)
                        return
                except (OSError,ValueError):
                    pass
            service.deliver_due()
    def stop(signum,frame):
        stopping.set()
        threading.Thread(target=server.shutdown,daemon=True).start()
    signal.signal(signal.SIGINT,stop)
    signal.signal(signal.SIGTERM,stop)
    thread=threading.Thread(target=worker,daemon=True,name="notification-worker")
    thread.start()
    info={"pid":os.getpid(),"app_url":app_url,"graph_url":graph_url,"project_id":"team-files-otel-dialogue-20261101-03","observer_enabled":observer is not None,"delay_seconds":5}
    (runtime/"launcher.json").write_text(json.dumps(info,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(info),flush=True)
    try:
        server.serve_forever()
    finally:
        stopping.set()
        thread.join(5)
        server.server_close()
        if observer:
            observer.close()

if __name__=="__main__":
    main()
