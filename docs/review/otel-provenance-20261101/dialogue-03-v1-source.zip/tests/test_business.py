"""Business expectations fixed independently before implementation."""
import json
import unittest
from pathlib import Path
from tests.scenarios import CASES,scenario

class BusinessRules(unittest.TestCase):
    def test_confirmed_rules_through_http(self):
        expected=json.loads((Path(__file__).resolve().parents[1]/"acceptance.json").read_text(encoding="utf-8"))["checks"]
        for case in CASES:
            with self.subTest(case=case):
                _,observed=scenario(case)
                for check in expected:
                    if check["case"]==case:
                        self.assertEqual(observed[check["path"][0]],check["equals"],check["id"])

if __name__=="__main__":
    unittest.main()
