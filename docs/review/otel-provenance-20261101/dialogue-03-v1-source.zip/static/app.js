/* Refresh read-only lists while preserving an in-progress form. */
window.setInterval(function refreshIdleWorkspace() {
  const field = document.activeElement;
  const upload = document.querySelector('input[type="file"]');
  const reason = document.querySelector('input[name="reason"]');
  if (field && field.matches('input, select, textarea')) return;
  if (upload && upload.files.length) return;
  if (reason && reason.value) return;
  window.location.reload();
}, 3000);
