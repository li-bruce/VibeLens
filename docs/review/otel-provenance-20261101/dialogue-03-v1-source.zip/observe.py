"""Run complete scenarios; partial invocation experiments remain in review/."""
from tooling.observe_complete import main

if __name__=="__main__":
    main()
