"""Build the graph from confirmed intent, explicit bindings and independent source facts."""
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "observer_runtime"))
from code_structure import scan, enrich
from bo_observer.policy.projection import project
from bo_observer.data.sync import synchronize


def read(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def write(name, value):
    path = ROOT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    discovery = read("discovery.json")
    sources = sorted([p.relative_to(ROOT).as_posix() for name in ("app", "integrations") for p in (ROOT / name).glob("*.py")] + ["server.py", "bo_stategraph/driver.py", "bo_stategraph/query.py", "run.py"])
    index = scan(ROOT, sources)
    if index["errors"]:
        raise ValueError(index["errors"])
    cases = read("mapping.json")["cases"]
    node_specs = {
        "sign_in": ("sign_in", {"username": "string"}, {"authenticated": "boolean", "user_id": "string"}, "R_LOGIN"),
        "sign_out": ("sign_out", {"user_id": "string"}, {"outcome": "string"}, "R_LOGIN"),
        "upload_file": ("upload_file", {"filename": "string", "bytes": "number"}, {"outcome": "string", "file_id": "string", "state": "string"}, "R_UPLOAD"),
        "review_file": ("review_file", {"file_id": "string", "verdict": "string", "reason": "string"}, {"outcome": "string", "state": "string", "job_id": "string", "before": "string", "event": "string", "guard": "boolean", "revision": "number"}, "R_REVIEW"),
        "share_file": ("share_file", {"file_id": "string", "recipient_ids": ["string"]}, {"outcome": "string", "share_ids": ["string"], "granted": "boolean"}, "R_SHARE"),
        "access_file": ("access_file", {"file_id": "string"}, {"outcome": "string", "bytes": "number", "state": "string"}, "R_ACCESS"),
        "review_notice": ("queue_notice", {"file_id": "string", "recipient_id": "string"}, {"job_id": "string", "outcome": "string"}, "R_MESSAGES"),
        "share_notice": ("queue_notice", {"file_id": "string", "recipient_id": "string"}, {"job_id": "string", "outcome": "string"}, "R_MESSAGES"),
        "deliver_notices": ("deliver_notices", {"job_id": "string", "recipient_id": "string"}, {"outcome": "string", "message_id": "string"}, "R_MESSAGES"),
        "list_messages": ("list_messages", {"recipient_id": "string"}, {"count": "number", "message_ids": ["string"]}, "R_MESSAGES"),
        "list_files": ("list_files", {"review": "boolean"}, {"count": "number", "file_ids": ["string"]}, "R_ACCESS"),
    }
    for ident in ("sign_out", "upload_file", "review_file", "share_file", "access_file", "list_files", "list_messages"):
        node_specs[ident][1]["actor_id"] = "string"
    node_specs["sign_out"][2]["principal_after_id"] = "string"
    for ident in ("review_file", "share_file", "access_file"):
        node_specs[ident][2]["error"] = "string"
    known = {node["id"]: node for network in discovery["networks"] for node in network["nodes"]}
    model = {"schema_version": 3, "revision": "1", "title": "Team file sharing", "intent": "intent.json", "source_files": sources + ["templates/index.html", "static/app/style.css", "requirements.txt", "bo_stategraph/telemetry.json", "bo_stategraph/databases.json", "app/models.py", "build_model.py"], "nodes": [], "edges": [], "overview": [], "scope": {"observable": ["Authenticated principals", "File review and downloads", "Immediate recipient grants", "Delayed private notifications", "Native SQLite effects and OTel job context"], "unknowns": ["Local synthetic trial; no registration, preview or resubmission", "Finite scenario and concurrency coverage"]}}
    model["source_files"] = sorted(set(model["source_files"] + ["tooling/bo_build_model.py"]))
    for ident, (method, inputs, outputs, requirement) in node_specs.items():
        label = known.get(ident, {}).get("label", ident.replace("_", " ").capitalize())
        model["nodes"].append({"id": ident, "kind": "action", "layer": "business", "label": label, "summary": label, "source": {"path": "app/service.py", "symbol": "TeamService." + method}, "capture": {"in": inputs, "out": outputs}, "requirements": [requirement]})
    for ident, value, method in [("pending_review", "pending", "upload_file"), ("approved_file", "approved", "review_file"), ("rejected_file", "rejected", "review_file")]:
        model["nodes"].append({"id": ident, "kind": "state", "layer": "state", "value": value, "label": known[ident]["label"], "summary": "Committed file review state: " + value, "source": {"path": "app/service.py", "symbol": "TeamService." + method}, "capture": {"in": {}, "out": {"state": "string", "file_id": "string"}}})
    for network in discovery["networks"]:
        for item in network["edges"]:
            model["edges"].append({"id": item["id"], "from": item["from"], "to": item["to"], "type": "flow" if item["relation"] == "event" else item["relation"], "label": item["label"], "evidence": "Human-confirmed discovery.json"})
    model["nodes"].append({"id": "api:entry", "kind": "function", "layer": "api", "code_role": "endpoint", "label": "HTTP request", "summary": "Upstream Flask instrumentation around the routed handler and actual WSGI response", "source": {"path": "server.py", "symbol": "api_entry"}, "capture": {"in": {"route": "string", "method": "string"}, "out": {"status": "number"}}})
    for ident in node_specs:
        model["edges"].append({"id": "api-" + ident, "from": "api:entry", "to": ident, "type": "flow", "label": "Calls business operation", "evidence": "server.py dispatch; individual runtime calls retain their actual parent"})
    model["nodes"].append({"id": "file-state-argument", "kind": "data", "label": "File state", "summary": "State supplied to the declaration-configured executor", "semantic_role": "state_parameter", "represents": {"path": "bo_stategraph/driver.py", "symbol": "FileDriver.step", "parameter": "state"}, "capture": {}})
    model["machine"] = {"engine": "transitions.Machine", "version": "0.9.3", "initial": "pending", "states": ["pending", "approved", "rejected"], "values": ["pending", "approved", "rejected"], "state_type": "str enum", "transitions": [{"trigger": event, "source": "pending", "dest": dest, "conditions": "review_allowed"} for event, dest in [("approve", "approved"), ("reject", "rejected")]], "events": {"approve": {"payload": {}}, "reject": {"payload": {}}}, "context": {"owner_id": {"type": "string"}}, "guards": {"review_allowed": "Administrator and not the uploader; evaluated from current transaction facts"}}
    model["overview"] = [{"node": ident, "x": number * 220, "y": 0} for number, ident in enumerate(node_specs)]
    policy = discovery["policy"]
    policy["stage"], policy["revision"] = "bound", "file-sharing-policy-1"
    for predicate in policy["predicates"]:
        predicate["source"] = {"path": "app/policy.py", "symbol": predicate["id"]}
    for operation in policy["operations"]:
        operation["cases"] = [{"upload": "upload", "review": "approval", "share": "sharing", "access": "file_access"}[operation["id"]]]
    model["policy"] = policy
    model = project(model)
    lifecycle = {"states": [{"id": "checking", "label": "Checking credentials", "kind": "active"}, {"id": "authenticated", "label": "Signed in", "kind": "ended"}, {"id": "denied", "label": "Login rejected", "kind": "ended"}], "bindings": [{"phase": "enter", "boundary": "start", "state": "checking"}, {"phase": "return", "boundary": "end", "state": "authenticated", "when": {"direction": "out", "field": "authenticated", "equals": True}}, {"phase": "return", "boundary": "end", "state": "denied", "when": {"direction": "out", "field": "authenticated", "equals": False}}]}
    next(node for node in model["nodes"] if node["id"] == "sign_in")["lifecycle"] = lifecycle
    write("bo_stategraph/telemetry.json", {"protocol": "bo-telemetry/v1", "backend": "opentelemetry", "registrations": [{"node": "api:entry", "source": {"path": "server.py", "symbol": "api_entry"}, "match": {"name": name}, "capture": {"in": {"route": "http.route", "method": "http.method"}, "out": {"status": "http.status_code"}}} for name in ("POST /api/<operation>", "GET /api/<operation>", "POST /<operation>", "GET /<operation>", "GET /")]})
    operations = []
    def operation(ident, action, source, targets, parent, parameters=None, after=None, before=None, failure=None):
        item = {"id": ident, "label": ident.replace("_", " "), "store": "team", "action": action, "source": {"path": "app/service.py", "symbol": source}, "targets": targets, "parameters": parameters or {}, "after": after or {}, "before": before or {}, "parent": parent, "required_cases": ["normal"] + (failure or []), "requirements": ["R_OBSERVE"]}
        if failure:
            item["failure_cases"] = failure
        operations.append(item)
    operation("db_upload", "write", "TeamService.upload_file", ["table:files"], "upload_file", {"owner_id": "string"}, {"count": "number"})
    operation("db_list_files", "read", "TeamService.list_files", ["table:files", "table:shares"], "list_files", {"actor_id": "string"}, {"count": "number"})
    operation("filename_transform", "transform", "normalize_filename", [], "upload_file", after={"filename": "string"}, before={"filename": "string"})
    for ident, method, tables, parent in [("db_upload_tx", "upload_file", ["files"], "upload_file"), ("db_review_tx", "review_file", ["files", "jobs", "journal"], "review_file"), ("db_share_tx", "share_file", ["files", "shares", "jobs"], "share_file"), ("db_delivery_tx", "deliver_notices", ["jobs", "messages"], "deliver_notices")]:
        operation(ident, "transaction", "TeamService." + method, ["table:" + table for table in tables], parent, failure=["unapproved_share"] if ident == "db_share_tx" else None)
    write("bo_stategraph/databases.json", {"protocol": "bo-databases/v1", "stores": [{"id": "team", "label": "Team SQLite", "engine": "sqlalchemy", "url_env": "TEAM_DATABASE_URL", "selection": {"source": "user", "answer": "用 Python、SQLite 和简单前端", "locator": "discovery.json::U_REQUEST"}, "model_layer": "SQLAlchemy Core MetaData", "source_files": ["app/models.py", "export_models.py"], "declaration": "bo_stategraph/model-catalog.json"}], "operations": operations, "exporters": [{"store": "team", "command": ["{python}", "-B", "export_models.py"], "output": "bo_stategraph/model-catalog.json"}]})
    data_cases = {"db_upload": "upload", "filename_transform": "upload", "db_upload_tx": "upload", "db_list_files": "file_list", "db_review_tx": "approval", "db_share_tx": "sharing", "db_delivery_tx": "review_delivery"}
    database_config = read("bo_stategraph/databases.json")
    for item in database_config["operations"]:
        item["required_cases"] = [data_cases[item["id"]]] + item.get("failure_cases", [])
    write("bo_stategraph/databases.json", database_config)
    selection = {"mode": "drive", "source": "user", "answer": read("sync.json")["stategraph"]["decision"], "locator": "discovery.json::U_ANSWER"}
    write("bo_stategraph/project.json", {"protocol": "bo-project/v1", "project_id": discovery["project_id"], "selection": selection, "model": model})
    cfg = read("sync.json")
    cfg.update(model="bo_stategraph/project.json", code_files=sources, probe_callees=["self.bo.span", "self.bo.record", "bo_probe.span", "bo_probe.record"])
    cfg["source_scope"] = {"roots": ["."], "require_symbol_classification": True, "exclude": {".venv/**": "Isolated dependency environment", "observer_runtime/**": "Canonical copied tools verified by runtime-version hashes", "bo_stategraph/__init__.py": "Canonical public state query/export core", "bo_stategraph/bo_contracts.py": "Canonical core validator", "bo_stategraph/execution_contract.py": "Canonical execution validator", "bo_stategraph/policy/**": "Canonical native policy evaluator", "static/graph/**": "Canonical viewer assets", "review/**": "Preserved dialogue, generators and verification evidence", "build_model.py": "Offline graph builder, watched separately", "observe.py": "Real runtime verification entrypoint, watched separately", "test_business.py": "Independent tests, executed separately", "export_models.py": "Offline metadata exporter, tracked in database model sources", "validate.py": "Verification orchestrator", "demo.py": "Synthetic live operation script", "test_extended.py": "Extended independent acceptance"}}
    cfg["watch_files"] = sorted(set(cfg["watch_files"] + ["requirements.txt", "export_models.py", "bo_stategraph/runtime-version.json", "tooling/bo_build_model.py", "tooling/bo_observe.py"]))
    cfg["watch_files"] = sorted(set(cfg["watch_files"] + ["test_extended.py", "validate.py"]))
    extended_command = ["{python}", "-B", "-X", "utf8", "test_extended.py"]
    if extended_command not in cfg["test_commands"]:
        cfg["test_commands"].append(extended_command)
    cfg["source_scope"]["exclude"]["tooling/**"] = "Offline model builders and independent runtime verification tools; business methods remain inventoried under app."
    cfg["source_scope"]["exclude"]["test_*.py"] = "Independent acceptance entrypoints, executed by the project validation command."
    write("sync.json", cfg)
    # Use a fresh local database for the real metadata collector, with no shared trial data.
    os.environ.setdefault("TEAM_DATABASE_URL", "sqlite:///" + (ROOT / "data/team.sqlite3").as_posix())
    result = synchronize(ROOT, model_path="bo_stategraph/project.json", update=True)
    if not result["valid"]:
        raise ValueError(result)
    document = read("bo_stategraph/project.json")
    model = document["model"]
    model = enrich(model, index, 1)
    mapped = {node["source"]["path"] + "::" + node["source"]["symbol"]: node["id"] for node in model["nodes"] if node.get("source") and node.get("origin") != "policy-definition"}
    features, support, excluded = [], {}, {}
    owned = {node["id"] for node in model["nodes"] if any(node.get("capture", {}).values())}
    # Preserve all real operations in one coverage feature; source disposition remains explicit per symbol.
    entries = ["app/service.py::TeamService." + method for method in ("sign_in", "sign_out", "upload_file", "review_file", "share_file", "access_file", "list_files", "list_messages", "deliver_notices")] + ["server.py::api_entry"]
    parameters = []
    parameter_fields = {"actor": ("sign_in", "out", "user_id", "derived", "Authenticated principal is captured in provenance; selected user ID verifies its native identity."), "password": ("sign_in", "out", "authenticated", "redacted", "Credentials are never collected; only authentication outcome is captured."), "name": ("upload_file", "in", "filename", "value", ""), "content": ("upload_file", "in", "bytes", "derived", "File bytes are withheld; byte length is selected."), "clock": ("deliver_notices", "in", "job_id", "derived", "Worker invocation identifies a natively selected due job; arbitrary clock values are not captured.")}
    parameter_fields["clear_session"] = ("sign_out", "out", "outcome", "derived", "Native session-clearing callback executes before the observed logout completion.")
    parameter_fields["password"] = ("sign_in", "out", "authenticated", "derived", "Only the native authentication boolean is captured; credentials are withheld.")
    entry_nodes = {"TeamService." + method: ident for ident, (method, _, _, _) in node_specs.items() if ident not in ("review_notice", "share_notice")}
    for source in entries:
        symbol = index["symbols"][source]
        ident = "api:entry" if source == "server.py::api_entry" else entry_nodes[symbol["symbol"]]
        for parameter in symbol["parameters"]:
            name = parameter["name"]
            if name == "self":
                continue
            if name in parameter_fields:
                target, direction, field, policy_name, reason = parameter_fields[name]
                if name == "actor":
                    target, direction, field = ident, "in", "actor_id"
            else:
                target, direction, field, policy_name, reason = ident, "in", name, "value", ""
                if name == "username":
                    field = "username"
                if source == "server.py::api_entry" and name == "operation":
                    field, policy_name, reason = "route", "derived", "The selected upstream HTTP route identifies dispatch; business inputs are captured by their own native entrypoints."
            parameters.append({"source": source, "name": name, "node": target, "direction": direction, "field": field, "policy": policy_name, **({"reason": reason} if reason else {})})
    function_symbols = {sid: symbol for sid, symbol in index["symbols"].items() if symbol["kind"] == "function"}
    for sid, symbol in function_symbols.items():
        if sid in entries:
            continue
        if symbol["path"].startswith("integrations/") or symbol["path"] == "app/ports.py" or symbol["path"] == "run.py" or symbol["symbol"].startswith("bo_"):
            excluded[sid] = {"category": "observer", "reason": "Optional capture wiring or local development lifecycle; no business authorization or storage authority."}
        elif symbol["symbol"].endswith(".__init__"):
            excluded[sid] = {"category": "construction", "reason": "Construction only; behavior methods are separately mapped."}
        else:
            support[sid] = {"node": mapped.get(sid, "review_file"), "reason": "Native helper, storage or UI path retained in the independent source graph."}
    case_for_node = {"sign_in": "normal", "sign_out": "sign_out", "upload_file": "upload", "review_file": "approval", "share_file": "sharing", "access_file": "file_access", "list_files": "file_list", "list_messages": "message_list", "review_notice": "approval", "share_notice": "sharing", "deliver_notices": "review_delivery"}
    feature_cases = [{"case": case_for_node[ident], "node": ident, "phase": "return"} for ident in node_specs]
    feature_cases += [{"case": case_for_node[ident], "node": ident, "phase": "enter"} for ident in node_specs]
    feature_cases += [{"case": case, "node": ident, "phase": "change"} for ident, case in [("pending_review", "upload"), ("approved_file", "approval"), ("rejected_file", "rejection")]]
    feature_cases += [{"case": "approval", "node": "review_file", "phase": "commit"}, {"case": "sharing", "node": "share_file", "phase": "commit"}]
    feature_cases += [{"case": case, "node": node, "phase": "error"} for case, node in [("http500", "review_file"), ("unapproved_share", "share_file"), ("unrelated_access", "access_file")]]
    feature_cases.append({"case": "http500", "node": "api:entry", "phase": "return", "values": [{"direction": "out", "field": "status", "path": ["http_status"]}]})
    for case in feature_cases:
        if case["case"] == "http500" and case["node"] == "review_file" and case["phase"] == "error":
            case["values"] = [{"direction": "out", "field": "error", "path": ["native_exception"]}]
    for policy_node in model["nodes"]:
        if policy_node.get("origin") == "policy-definition" and any(policy_node.get("capture", {}).values()):
            feature_cases.append({"case": "file_access" if policy_node["id"].split(":", 1)[-1] not in ("not_owner", "review_allowed", "share_allowed") else {"not_owner": "approval", "review_allowed": "approval", "share_allowed": "sharing"}[policy_node["id"].split(":", 1)[-1]], "node": policy_node["id"], "phase": "decision"})
    feature_cases += [{"case": "normal", "node": "api:entry", "phase": "return"}]
    features.append({"id": "team-file-sharing", "label": "Team file sharing", "business_node": "upload_file", "nodes": sorted(owned), "sources": entries, "parameters": parameters, "cases": feature_cases, "requirements": [item["id"] for item in read("intent.json")["requirements"]]})
    model["implementation"] = {"schema": "bo-implementation/v1", "features": features, "support": support, "excluded": excluded}
    model["presentation"] = {"subject": "Team file sharing", "layout_id": discovery["layout_id"], "states": {"pending": "Pending review", "approved": "Approved", "rejected": "Rejected"}, "names": {"nodes": {}, "edges": {}, "states": {"pending": {"en": "Pending", "zh-CN": "待审核"}, "approved": {"en": "Approved", "zh-CN": "已通过"}, "rejected": {"en": "Rejected", "zh-CN": "已驳回"}}}}
    translations = {"sign_in": "登录", "sign_out": "退出登录", "upload_file": "上传文件", "review_file": "审核文件", "share_file": "分享文件", "access_file": "下载文件", "list_files": "文件列表", "list_messages": "我的消息", "review_notice": "审核通知入队", "share_notice": "共享通知入队", "deliver_notices": "后台送达消息", "pending_review": "待审核", "approved_file": "已通过", "rejected_file": "已驳回"}
    for node in model["nodes"]:
        if node["id"] in translations:
            model["presentation"]["names"]["nodes"][node["id"]] = {"en": node["label"], "zh-CN": translations[node["id"]]}
    model["overview"] = [{"node": ident, "x": (number % 4) * 270, "y": (number // 4) * 190} for number, ident in enumerate(translations)]
    document["model"] = model
    document["model"] = enrich(model, index, 1)
    model = document["model"]
    write("bo_stategraph/project.json", document)
    # This raw v3 file is an explicitly generated mirror, never an independent authority.
    write("behavior.json", model)
    print(json.dumps({"nodes": len(model["nodes"]), "edges": len(model["edges"]), "source_files": len(sources)}))


if __name__ == "__main__":
    main()
