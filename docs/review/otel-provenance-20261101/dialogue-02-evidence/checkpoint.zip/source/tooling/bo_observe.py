"""Run real native/HTTP scenarios and independently compare stored identity and state."""
import argparse
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "observer_runtime"))
from test_business import exercise
from mapping_contract import instance_witnesses

EXTRA_CASES = ["upload", "approval", "sharing", "file_access", "file_list", "message_list", "review_delivery", "share_delivery", "valid_login", "sign_out", "http500"]


def native_context(case, node, phase, fixture, file_id):
    """Expected metadata comes from scenario inputs, native sessions and raw SQLite reads."""
    login = case in ("normal", "invalid_login", "valid_login")
    if login:
        return {"actor": None if phase == "enter" or case == "invalid_login" else {"id": "member1", "kind": "user"}, "objects": []}
    actor = "admin1" if case in ("approval", "self_review", "rejection", "http500") else "member2" if case in ("file_access", "recipient_reshare", "unrelated_access", "message_list") else "admin2" if case == "private_messages" else "member1"
    primary_has_file = case in ("approval", "self_review", "rejection", "sharing", "unapproved_share", "recipient_reshare", "file_access", "unrelated_access", "delayed_notice", "http500")
    base = {"actor": {"id": actor, "kind": "user"}, "objects": [{"type": "File", "id": file_id, "role": "input"}] if primary_has_file else []}
    if case == "sign_out" and node == "sign_out":
        return fixture.native_signout[phase]
    if case in ("review_delivery", "share_delivery"):
        kind = "review" if case == "review_delivery" else "share"
        job = fixture.sql("select * from jobs where kind=?", (kind,))[0]
        objects = [{"type": "File", "id": job["file_id"], "role": "input"}, {"type": "NotificationJob", "id": job["id"], "role": "input"}, {"type": "User", "id": job["recipient_id"], "role": "recipient"}]
        if node == "deliver_notices" and phase == "return":
            message = fixture.sql("select id from messages where job_id=?", (job["id"],))[0]
            objects.append({"type": "Message", "id": message["id"], "role": "output"})
        return {"actor": {"id": "notification-worker", "kind": "service"}, "workflow_id": job["id"], "objects": objects}
    if node in ("review_notice", "share_notice"):
        kind = "review" if node == "review_notice" else "share"
        if case == "http500":
            owner = fixture.sql("select owner_id from files where id=?", (file_id,))[0]["owner_id"]
            return {"actor": base["actor"], "objects": [{"type": "File", "id": file_id, "role": "input"}, {"type": "User", "id": owner, "role": "recipient"}]}
        job = fixture.sql("select * from jobs where kind=?", (kind,))[0]
        objects = [{"type": "File", "id": file_id, "role": "input"}, {"type": "User", "id": job["recipient_id"], "role": "recipient"}]
        if phase == "return":
            objects.append({"type": "NotificationJob", "id": job["id"], "role": "output"})
        return {"actor": base["actor"], "objects": objects}
    if node == "upload_file" and phase == "return":
        native = fixture.sql("select id,revision from files where id=?", (file_id,))[0]
        return {"actor": base["actor"], "objects": [{"type": "File", "id": native["id"], "version": str(native["revision"]), "role": "output"}]}
    if node in ("pending_review", "approved_file", "rejected_file"):
        return {"actor": base["actor"], "objects": [{"type": "File", "id": file_id, "role": "input"}]}
    if node == "share_file" and phase == "return":
        rows = fixture.sql("select id,recipient_id from shares where file_id=? order by rowid", (file_id,))
        return {"actor": base["actor"], "objects": base["objects"] + [{"type": "Share", "id": row["id"], "role": "output"} for row in rows] + [{"type": "User", "id": row["recipient_id"], "role": "recipient"} for row in rows]}
    return base


def prepare_plan():
    plan = json.loads((ROOT / "mapping.json").read_text(encoding="utf-8"))
    for case in EXTRA_CASES:
        if case not in plan["cases"]:
            plan["cases"].append(case)
    if not any(field["id"] == "file-owner" for field in plan["fields"]):
        plan["fields"].append({"id": "file-owner", "node": "review_file", "actual": ["owner_id"], "mapped": ["context", "owner_id"]})
    (ROOT / "mapping.json").write_text(json.dumps(plan, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return plan


def collect(plan, modes=None):
    runs, witnesses = [], []
    export = None
    for mode in modes or plan["modes"]:
        for case in plan["cases"]:
            fixture, session, hooks, observations, file_id = exercise(case, mode, collect=True)
            try:
                public = fixture.client.get("/api/stategraph/export").get_json()
                projection = {"build_id": session.manifest["build_id"], "machine": public["runtime"]["machine"], "instances": public["instances"]}
                native = fixture.sql("select id,state,revision,owner_id from files order by rowid")
                for row in native:
                    row["build_id"] = session.manifest["build_id"]
                events = session.view()["events"]
                contexts = {}
                for event in events:
                    if "provenance" in event and not event.get("context_only"):
                        contexts.setdefault(event["node"], {})[event["phase"]] = native_context(case, event["node"], event["phase"], fixture, file_id)
                health = hooks.bo_health()
                run = {"case": case, "mode": mode, "events": events, "observations": observations, "probe_health": health, "policy_evaluations": list(hooks.policy_reports), "projection": projection, "authority_snapshot": {"runs": native}, "native_context": contexts, "native_sdk_spans": list(hooks.bo_sdk_exporter.get_finished_spans())}
                run["mapping_checks"] = instance_witnesses(projection["instances"], {row["id"]: {key: row[key] for key in ("state", "revision", "build_id")} for row in native}, case=case + ":" + mode, source="Independent sqlite3 SELECT after native application execution")
                runs.append(run)
                witnesses.extend(run["mapping_checks"])
                if case == plan["export"]["case"] and mode == plan["export"]["mode"]:
                    export = public
                print(f"scenario {case}/{mode}: {len(events)} events; errors={health['errors']}; dropped={health['dropped']}", file=sys.stderr, flush=True)
            finally:
                hooks.close()
                fixture.close()
    build_id = runs[0]["projection"]["build_id"]
    return {"build_id": build_id, "runs": runs, "mapping_checks": witnesses, "stategraph_export": export, "machine": fixture.service.declaration}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", action="store_true")
    args = parser.parse_args()
    plan = prepare_plan() if args.plan else json.loads((ROOT / "mapping.json").read_text(encoding="utf-8"))
    payload = collect(plan, ["on"] if args.plan else None)
    if args.plan:
        fields = list(plan.get("context_fields", []))
        identities = {field["id"] for field in fields}
        for run in payload["runs"]:
            for node, phases in run["native_context"].items():
                for phase in phases:
                    ident = run["case"] + ":" + node + ":" + phase + ":native-context"
                    if ident not in identities:
                        fields.append({"id": ident, "case": run["case"], "node": node, "phase": phase, "actual": ["native_context", node, phase], "mapped": ["provenance"], "source": "Native scenario principal, session operation and independent sqlite3 file/share/job/message reads"})
                        identities.add(ident)
        plan["context_fields"] = fields
        (ROOT / "mapping.json").write_text(json.dumps(plan, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        (ROOT / "review/preflight-observations.json").write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
        print(json.dumps({"planned": len(fields), "cases": len(plan["cases"])}))
    else:
        print(json.dumps(payload, ensure_ascii=False))


if __name__ == "__main__":
    main()
