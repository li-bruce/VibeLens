"""Application-owned flat-state executor configured by the shared declaration."""
from copy import deepcopy
from transitions import Machine
from .bo_contracts import validate_runtime_definition


class FileDriver:
    def __init__(self, declaration):
        validate_runtime_definition(declaration, loaded_engine="transitions.Machine", guard_names={"review_allowed"})
        self.declaration = deepcopy(declaration)
        self.allowed = False

    def review_allowed(self):
        return self.allowed

    def step(self, state, event, allowed):
        self.allowed = allowed
        machine = Machine(model=self, states=self.declaration["states"], initial=state,
                          transitions=deepcopy(self.declaration["transitions"]), auto_transitions=False)
        try:
            before = self.state
            changed = self.trigger(event)
            if not changed:
                raise PermissionError("review_denied")
            return {"event": event, "before": before, "after": self.state, "guards": {"review_allowed": self.allowed}}
        finally:
            machine.remove_model(self)
