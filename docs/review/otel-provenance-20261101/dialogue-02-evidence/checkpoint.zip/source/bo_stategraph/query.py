"""Public projection of native committed SQLite instances and transition witnesses."""
import json
from sqlalchemy import select
from app.models import files, journal


def machine_snapshot(store, build_id):
    with store.engine.connect() as connection:
        rows = list(connection.execute(select(files.c.id, files.c.state, files.c.owner_id, files.c.revision)).mappings())
        transitions = [dict(row) for row in connection.execute(select(journal)).mappings()]
    configurations = [{"attempt": row["id"], "phase": row["state"], "state_revision": row["revision"], "run_build_id": build_id, "source_status": "current", "context": {"owner_id": row["owner_id"]}} for row in rows]
    witnesses = [{"id": row["id"], "instance_id": row["file_id"], "event": row["event"], "before": row["before_state"], "after": row["after_state"], "revision": row["revision"], "guards": json.loads(row["guards"])} for row in transitions]
    return {"configurations": configurations, "journal": witnesses, "current": None}
