"""Concurrency, native-rule mutation and source freshness counterexamples."""
import concurrent.futures
import json
import shutil
import subprocess
import sys
import tempfile
import threading
import unittest
import sqlite3
from contextlib import closing
from pathlib import Path
from test_business import Fixture, ROOT


class ExtendedTests(unittest.TestCase):
    def test_source_only_change_is_stale(self):
        from behavior_model import capture, check
        document = json.loads((ROOT / "bo_stategraph/project.json").read_text(encoding="utf-8"))
        model = document["model"]
        manifest = capture(ROOT, model)
        target_root = ROOT / "review/test-data"
        target_root.mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(prefix="source-drift-", dir=str(target_root)) as directory:
            copied = Path(directory).resolve()
            self.assertTrue(copied.is_relative_to(target_root.resolve()))
            for name in manifest["files"]:
                destination = copied / name
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(ROOT / name, destination)
            for name in ("intent.json",):
                shutil.copy2(ROOT / name, copied / name)
            before = check(copied, model, manifest)
            self.assertEqual(before["status"], "current")
            source = copied / "app/policy.py"
            with source.open("a", encoding="utf-8") as stream:
                stream.write("\n# Deliberate isolated source-only drift.\n")
            after = check(copied, model, manifest)
            self.assertEqual(after["status"], "stale")
            (ROOT / "review/source-drift-check.json").write_text(json.dumps({"before": before, "after": after, "canonical_modified": False}, indent=2), encoding="utf-8")

    def test_observation_column_migration_preserves_jobs(self):
        fixture = Fixture()
        try:
            file_id = fixture.upload()
            fixture.approve(file_id)
            before = fixture.sql("select id,recipient_id,kind,text,bo_carrier,state from jobs")
            with closing(sqlite3.connect(fixture.path)) as connection:
                connection.execute("ALTER TABLE jobs RENAME COLUMN bo_carrier TO carrier")
                connection.commit()
            fixture.store.initialize()
            after = fixture.sql("select id,recipient_id,kind,text,bo_carrier,state from jobs")
            self.assertEqual(before, after)
            (ROOT / "review/schema-migration-job-check.json").write_text(json.dumps({"before": before, "after": after, "equal": before == after}, indent=2), encoding="utf-8")
        finally:
            fixture.close()

    def test_concurrent_administrators_review_once(self):
        fixture = Fixture()
        try:
            file_id = fixture.upload()
            barrier = threading.Barrier(2)
            def submit(actor):
                client = fixture.app.test_client()
                with client.session_transaction() as session:
                    session.update(user_id=actor, csrf="concurrent-trial")
                barrier.wait(timeout=10)
                return client.post("/api/review", json={"csrf": "concurrent-trial", "file_id": file_id, "verdict": "approve"}).status_code
            with concurrent.futures.ThreadPoolExecutor(2) as pool:
                codes = sorted(pool.map(submit, ["admin1", "admin2"]))
            self.assertEqual(codes, [200, 409])
            self.assertEqual(len(fixture.sql("select id from journal")), 1)
            self.assertEqual(len(fixture.sql("select id from jobs")), 1)
        finally:
            fixture.close()

    def test_non_owner_administrator_cannot_share(self):
        fixture = Fixture()
        try:
            file_id = fixture.upload()
            fixture.approve(file_id)
            self.assertEqual(fixture.request("share", "admin2", file_id=file_id, recipient_ids=["member2"]).status_code, 403)
            self.assertEqual(fixture.sql("select id from shares"), [])
        finally:
            fixture.close()

    def test_self_review_mutation_is_detected(self):
        target_root = ROOT / "review/test-data"
        with tempfile.TemporaryDirectory(prefix="mutation-", dir=str(target_root)) as directory:
            copied = Path(directory).resolve()
            self.assertTrue(copied.is_relative_to(target_root.resolve()))
            for name in ("app", "bo_stategraph"):
                shutil.copytree(ROOT / name, copied / name, ignore=shutil.ignore_patterns("data", "config", "__pycache__"))
            for name in ("server.py", "test_business.py", "acceptance.json"):
                shutil.copy2(ROOT / name, copied / name)
            policy_path = copied / "app/policy.py"
            clean = policy_path.read_text(encoding="utf-8")
            self.assertIn("return left == right", clean)
            policy_path.write_text(clean.replace("return left == right", "return False"), encoding="utf-8")
            command = [sys.executable, "-B", "-X", "utf8", "-c", "from test_business import Fixture; f=Fixture(); i=f.upload('admin1'); r=f.request('review','admin1',file_id=i,verdict='approve'); code=r.status_code; f.close(); assert code == 403, 'self_review_permission_guard: expected 403, observed '+str(code)"]
            result = subprocess.run(command, cwd=copied, capture_output=True, text=True, encoding="utf-8")
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("self_review_permission_guard: expected 403, observed 200", result.stderr)
            (ROOT / "review/business-mutation.json").write_text(json.dumps({"detected": True, "mutation": "same_identity always false", "stderr": result.stderr, "canonical_modified": False}, indent=2), encoding="utf-8")


if __name__ == "__main__":
    unittest.main(verbosity=2)
