"""Team file-sharing application."""
