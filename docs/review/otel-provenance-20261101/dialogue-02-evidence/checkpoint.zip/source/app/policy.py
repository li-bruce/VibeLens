"""Native scalar predicates used by the declared rule evaluator."""


def same_identity(left: str, right: str) -> bool:
    return left == right


def flag_enabled(value: bool) -> bool:
    return value is True
