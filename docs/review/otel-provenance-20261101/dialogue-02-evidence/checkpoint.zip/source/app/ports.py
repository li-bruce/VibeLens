"""Failure-isolated observation port; business execution works without a collector."""
from contextlib import contextmanager, nullcontext


def bo_principal(actor):
    return {"id": actor["id"], "kind": "user"} if actor else None


def bo_identity(actor, file_id=None, recipient_id=None, workflow_id=None):
    value = {"actor": bo_principal(actor), "objects": []}
    if workflow_id:
        value["workflow_id"] = workflow_id
    if file_id:
        value["objects"].append({"type": "File", "id": file_id, "role": "input"})
    if recipient_id:
        value["objects"].append({"type": "User", "id": recipient_id, "role": "recipient"})
    return value


class BOResult:
    def result(self, builder):
        pass

    def record(self, phase, builder):
        return None


class BOQuiet:
    @contextmanager
    def span(self, node, builder=lambda: {}, **identity):
        yield BOResult()

    def record(self, node, phase, builder, **identity):
        return None

    def policy(self, declaration, evaluation):
        pass

    def job_context(self):
        return "{}"

    def receive(self, carrier):
        return nullcontext()

    def snapshot(self, rows):
        pass

    def state(self, *args, **kwargs):
        pass

    def data(self, node, callback, **options):
        return callback()

    def transaction(self, node, manager):
        return manager

    def transform(self, node, function, value):
        return function(value)
