"""Stable command entrypoint for independent runtime verification."""
import runpy
from pathlib import Path

if __name__ == "__main__":
    runpy.run_path(str(Path(__file__).resolve().parent / "tooling/bo_observe.py"), run_name="__main__")
