"""Offline metadata export; never opens a database or runs migrations."""
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent / "observer_runtime"))
from sqlalchemy.dialects.sqlite import dialect
from app.models import metadata
from bo_observer.data.catalog import export_sqlalchemy_metadata

if __name__ == "__main__":
    print(json.dumps(export_sqlalchemy_metadata(metadata, "team", dialect=dialect())))
