"""Independent business expectations exercised through real native and HTTP entrypoints."""
import io
import json
import sqlite3
import sys
import tempfile
import time
import unittest
from contextlib import closing
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "observer_runtime"))
from app.service import TeamService
from app.store import Store
from server import create_app
from flask import session as native_session, got_request_exception, has_request_context


class Fixture:
    def __init__(self):
        test_root = ROOT / "review/test-data"
        test_root.mkdir(exist_ok=True)
        self.temp = tempfile.TemporaryDirectory(prefix="team-files-", dir=str(test_root))
        self.path = Path(self.temp.name) / "team.sqlite3"
        self.store = Store(self.path)
        self.store.initialize()
        self.service = TeamService(self.store, ROOT)
        self.actors = {name: self.service.sign_in(name, "Trial-2026!") for name in ("admin1", "admin2", "member1", "member2")}
        self.app = create_app(self.service, "synthetic-test-session-key")
        self.app.config["TESTING"] = True
        self.client = self.app.test_client()

    def sql(self, query, parameters=()):
        with closing(sqlite3.connect(self.path)) as connection:
            connection.row_factory = sqlite3.Row
            return [dict(row) for row in connection.execute(query, parameters)]

    def request(self, operation, actor=None, **body):
        with self.client.session_transaction() as native_session:
            native_session["csrf"] = "synthetic-csrf"
            if actor:
                native_session["user_id"] = actor
            else:
                native_session.pop("user_id", None)
        if operation == "upload":
            return self.client.post("/api/upload", data={"csrf": "synthetic-csrf", "file": (io.BytesIO(body.get("content", b"team evidence")), body.get("name", "team-notes.txt"))}, content_type="multipart/form-data")
        if operation == "download":
            return self.client.get("/api/download", query_string=body)
        if operation in ("files", "messages"):
            return self.client.get("/api/" + operation, query_string=body)
        return self.client.post("/api/" + operation, json={"csrf": "synthetic-csrf", **body})

    def upload(self, owner="member1"):
        return self.service.upload_file(self.actors[owner], "team-notes.txt", b"team evidence")["id"]

    def approve(self, file_id, actor="admin1"):
        return self.service.review_file(self.actors[actor], file_id, "approve")

    def close(self):
        self.store.close()
        assert self.path.parent.resolve().is_relative_to((ROOT / "review/test-data").resolve())
        self.temp.cleanup()


def exercise(case, mode="off", collect=False):
    fixture = Fixture()
    service, actors = fixture.service, fixture.actors
    file_id = None
    # Each capture case has one native principal/object basis. Preparation is real,
    # unobserved business work; the live end-to-end recording is verified separately.
    if case not in ("normal", "invalid_login", "upload", "valid_login", "sign_out"):
        file_id = fixture.upload("admin1" if case == "self_review" else "member1")
    if case in ("sharing", "recipient_reshare", "file_access", "private_messages", "delayed_notice", "review_delivery", "share_delivery", "message_list"):
        fixture.approve(file_id)
    if case in ("recipient_reshare", "file_access", "private_messages", "share_delivery", "message_list"):
        service.share_file(actors["member1"], file_id, ["member2"])
    if case in ("private_messages", "message_list"):
        service.deliver_notices(time.time() + 10)
    if case == "http500":
        fixture.app.config["TESTING"] = False
        fixture.native_errors = []
        def native_exception(sender, exception, **options):
            fixture.native_errors.append(type(exception).__name__)
        got_request_exception.connect(native_exception, fixture.app, weak=False)
        with closing(sqlite3.connect(fixture.path)) as connection:
            connection.execute("ALTER TABLE jobs RENAME TO unavailable_jobs")
            connection.commit()
    hooks = observer = None
    if collect:
        from bo_observer.service import GraphSession
        from integrations.bo_hooks import BOHooks
        observer = GraphSession(ROOT)
        hooks = BOHooks(observer, mode=mode)
        service.bo = hooks
        hooks.bo_instrument_app(fixture.app)
        if case == "sign_out":
            fixture.native_signout = {}
            original_record = hooks.bo_probe.record
            def record_with_native_session(node, phase, builder, **options):
                if node == "sign_out" and has_request_context():
                    user_id = native_session.get("user_id")
                    fixture.native_signout[phase] = {"actor": {"id": user_id, "kind": "user"} if user_id else None, "objects": []}
                return original_record(node, phase, builder, **options)
            hooks.bo_probe.record = record_with_native_session
    observations = {}
    expected_actor = None
    if case == "normal":
        response = fixture.request("login", username="member1", password="Trial-2026!")
        observations["R_LOGIN"] = response.status_code == 200
        # Retain the original full-flow independent expectations, executing later
        # operations without observation in this credential-focused case.
        from app.ports import BOQuiet
        active = service.bo
        service.bo = BOQuiet()
        file_id = fixture.upload()
        observations["R_UPLOAD"] = fixture.sql("select state from files where id=?", (file_id,))[0]["state"]
        fixture.approve(file_id)
        observations["R_REVIEW"] = fixture.sql("select state from files where id=?", (file_id,))[0]["state"]
        service.share_file(actors["member1"], file_id, ["member2"])
        observations["R_SHARE"] = service.access_file(actors["member2"], file_id)["content"] == b"team evidence"
        observations["R_ACCESS"] = observations["R_SHARE"]
        service.deliver_notices(time.time() + 10)
        observations["R_MESSAGES"] = len(service.list_messages(actors["member1"])) == 1 and len(service.list_messages(actors["member2"])) == 1
        observations["R_DRIVE"] = fixture.sql("select before_state,after_state from journal")[0] == {"before_state": "pending", "after_state": "approved"}
        observations["R_OBSERVE"] = len(fixture.sql("select id from shares")) == 1 and len(fixture.sql("select id from journal")) == 1
        service.bo = active
    elif case in ("invalid_login", "valid_login"):
        response = fixture.request("login", username="member1", password="wrong" if case == "invalid_login" else "Trial-2026!")
        observations["R_LOGIN"] = response.status_code == 200
    elif case == "upload":
        response = fixture.request("upload", "member1", name="  team-notes.txt  ")
        file_id = response.get_json()["id"]
        observations["R_UPLOAD"] = fixture.sql("select state from files where id=?", (file_id,))[0]["state"]
    elif case in ("self_review", "approval", "rejection", "http500"):
        expected_actor = "admin1"
        response = fixture.request("review", "admin1", file_id=file_id, verdict="reject" if case == "rejection" else "approve", reason="Needs another source" if case == "rejection" else "")
        observations["R_REVIEW"] = fixture.sql("select state from files where id=?", (file_id,))[0]["state"]
        if case == "http500":
            observations.update(http_status=response.status_code, native_exception=fixture.native_errors[0], rolled_back=observations["R_REVIEW"] == "pending")
        if case == "rejection":
            observations["R_ACCESS"] = service.store.engine is not None and fixture.sql("select length(content) as bytes,reason from files where id=?", (file_id,))[0] == {"bytes": 13, "reason": "Needs another source"}
    elif case in ("sharing", "unapproved_share", "recipient_reshare", "delayed_notice"):
        expected_actor = "member2" if case == "recipient_reshare" else "member1"
        response = fixture.request("share", expected_actor, file_id=file_id, recipient_ids=["admin2"] if case == "recipient_reshare" else ["member2"])
        observations["R_SHARE"] = response.status_code == 200
        if case == "delayed_notice":
            observations["R_MESSAGES"] = not fixture.sql("select id from messages") and bool(fixture.sql("select id from shares where recipient_id='member2'"))
    elif case in ("unrelated_access", "file_access"):
        expected_actor = "member2" if case == "file_access" else "member2"
        response = fixture.request("download", expected_actor, file_id=file_id)
        observations["R_ACCESS"] = response.status_code == 200
    elif case == "file_list":
        expected_actor = "member1"
        response = fixture.request("files", expected_actor)
        observations["items"] = response.get_json()["items"]
    elif case in ("private_messages", "message_list"):
        expected_actor = "admin2" if case == "private_messages" else "member2"
        response = fixture.request("messages", expected_actor)
        rows = response.get_json()["items"]
        observations["R_MESSAGES"] = all(row["recipient_id"] == expected_actor for row in rows) and (len(rows) == 0 if case == "private_messages" else len(rows) == 1)
    elif case in ("review_delivery", "share_delivery"):
        kind = "review" if case == "review_delivery" else "share"
        target = fixture.sql("select * from jobs where kind=?", (kind,))[0]
        # Restrict this real queue invocation to one due job for a single native basis.
        if kind == "share":
            with closing(sqlite3.connect(fixture.path)) as connection:
                connection.execute("update jobs set due_at=? where kind='review'", (time.time() + 100,))
                connection.commit()
        service.deliver_notices(target["due_at"])
        observations["R_MESSAGES"] = bool(fixture.sql("select id from messages where job_id=?", (target["id"],)))
    elif case == "sign_out":
        expected_actor = "member1"
        response = fixture.request("logout", expected_actor)
        observations["R_LOGIN"] = response.status_code == 200
        if collect:
            observations["native_session_at_capture"] = fixture.native_signout
            observations["event_timing_valid"] = fixture.native_signout["enter"]["actor"]["id"] == "member1" and fixture.native_signout["return"]["actor"] is None
    else:
        raise ValueError("unknown_case")
    if hooks:
        hooks.bo_probe.flush(15)
    return fixture, observer, hooks, observations, file_id


class BusinessTests(unittest.TestCase):
    def test_original_expectations(self):
        expectations = json.loads((ROOT / ".stategraph/initial/baseline.json").read_text(encoding="utf-8"))["acceptance"]["checks"]
        for case in sorted({item["case"] for item in expectations}):
            fixture, _, _, observations, _ = exercise(case)
            try:
                for item in expectations:
                    if item["case"] == case:
                        with self.subTest(case=case, check=item["id"]):
                            self.assertEqual(observations[item["path"][0]], item["equals"])
            finally:
                fixture.close()

    def test_owner_and_admin_access_all_states(self):
        fixture = Fixture()
        try:
            file_id = fixture.upload()
            for state in ("pending", "rejected", "approved"):
                with closing(sqlite3.connect(fixture.path)) as connection:
                    connection.execute("update files set state=? where id=?", (state, file_id))
                    connection.commit()
                for actor in ("member1", "admin1", "admin2"):
                    self.assertEqual(fixture.request("download", actor, file_id=file_id).data, b"team evidence")
                self.assertEqual(fixture.request("download", "member2", file_id=file_id).status_code, 403)
        finally:
            fixture.close()

    def test_repeated_review_and_atomic_recipient_validation(self):
        fixture = Fixture()
        try:
            file_id = fixture.upload()
            fixture.approve(file_id)
            self.assertEqual(fixture.request("review", "admin2", file_id=file_id, verdict="reject", reason="late").status_code, 409)
            self.assertEqual(fixture.request("share", "member1", file_id=file_id, recipient_ids=["member2", "unknown"]).status_code, 400)
            self.assertEqual(fixture.sql("select id from shares"), [])
            fixture.service.deliver_notices(time.time() + 10)
            fixture.service.deliver_notices(time.time() + 10)
            self.assertEqual(len(fixture.sql("select id from messages")), 1)
        finally:
            fixture.close()

    def test_csrf_and_anonymous_upload(self):
        fixture = Fixture()
        try:
            self.assertEqual(fixture.client.post("/api/share", json={"file_id": "none"}).status_code, 403)
            self.assertEqual(fixture.request("upload").status_code, 401)
            self.assertEqual(fixture.sql("select id from files"), [])
        finally:
            fixture.close()


if __name__ == "__main__":
    unittest.main(verbosity=2)
