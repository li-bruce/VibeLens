"""Stable command entrypoint for the offline graph builder."""
import runpy
from pathlib import Path

if __name__ == "__main__":
    runpy.run_path(str(Path(__file__).resolve().parent / "tooling/bo_build_model.py"), run_name="__main__")
