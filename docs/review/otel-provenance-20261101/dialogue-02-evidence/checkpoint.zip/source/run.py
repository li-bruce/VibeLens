"""One local development command for the application, observer and native worker."""
import argparse
import json
import os
import secrets
import signal
import sys
import threading
from pathlib import Path
from werkzeug.serving import make_server as make_application_server

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "observer_runtime"))
from app.store import Store
from app.service import TeamService
from server import create_app


def bo_worker(service, stop):
    while not stop.wait(0.5):
        try:
            service.deliver_notices()
        except Exception as error:
            print("Notification worker retry: " + type(error).__name__, file=sys.stderr, flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=0)
    parser.add_argument("--graph-port", type=int, default=0)
    parser.add_argument("--no-observer", action="store_true")
    args = parser.parse_args()
    (ROOT / "data").mkdir(exist_ok=True)
    os.environ["TEAM_DATABASE_URL"] = "sqlite:///" + (ROOT / "data/team.sqlite3").as_posix()
    store = Store(ROOT / "data/team.sqlite3")
    store.initialize()
    graph_server = hooks = graph_session = None
    graph_url = ""
    if not args.no_observer:
        from bo_observer.service import GraphSession, make_server
        from integrations.bo_hooks import BOHooks
        graph_session = GraphSession(ROOT)
        hooks = BOHooks(graph_session)
        graph_server = make_server(graph_session, args.graph_port, assets=ROOT / "static/graph")
        graph_url = "http://127.0.0.1:" + str(graph_server.server_port) + "/graph"
        threading.Thread(target=graph_server.serve_forever, daemon=True, name="bo-viewer").start()
    service = TeamService(store, ROOT, hooks)
    secret_path = ROOT / "data/session-key"
    if not secret_path.exists():
        secret_path.write_text(secrets.token_urlsafe(48), encoding="ascii")
    app = create_app(service, secret_path.read_text(encoding="ascii"), graph_url)
    app_server = make_application_server("127.0.0.1", args.port, app, threaded=True)
    app_url = "http://127.0.0.1:" + str(app_server.server_port)
    if graph_session:
        graph_session.program_url = app_url
    stop = threading.Event()
    threading.Thread(target=bo_worker, args=(service, stop), daemon=True, name="notification-worker").start()
    endpoints = {"app": app_url, "graph": graph_url, "pid": os.getpid(), "build_id": graph_session.manifest["build_id"] if graph_session else None}
    (ROOT / "review/runtime-endpoints.json").write_text(json.dumps(endpoints, indent=2), encoding="utf-8")
    print("Application: " + app_url, flush=True)
    print("VibeLens: " + (graph_url or "disabled"), flush=True)
    try:
        app_server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        stop.set()
        app_server.server_close()
        if graph_server:
            graph_server.shutdown()
            graph_server.server_close()
        if hooks:
            hooks.close()
        store.close()


if __name__ == "__main__":
    main()
