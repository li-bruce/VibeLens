"""Real return boundaries, producer health, recording settlement and drive witnesses."""

from copy import deepcopy
import json
from pathlib import Path
import shutil
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/"observer_runtime")]

from app.storage import Store
from app.service import Service
from app.web import create_app
from integrations.bo_monitor import BOMonitor
from bo_observer.observation.session import GraphSession
from bo_observer.workflow.sync_verify import assess_probe_health
from bo_observer.graph.behavior_model import capture,check
from bo_stategraph import BOStateGraph
from tooling.http_probe_regression import exercise_http_errors
from tooling.observe import run_case


class ObservationTests(unittest.TestCase):
    def setUp(self):
        self.project=json.loads((ROOT/"bo_stategraph/project.json").read_text(encoding="utf-8"))
        self.build_id=capture(ROOT,self.project["model"])["build_id"]

    def test_real_http_errors_close_and_keep_actual_status_fields(self):
        with tempfile.TemporaryDirectory(prefix="http-check-",dir=ROOT/"review") as directory:
            result=exercise_http_errors(self.project,self.build_id,directory)
        self.assertTrue(result["correct_responses"])
        self.assertTrue(result["complete_return_boundaries"])
        self.assertEqual(result["probe_health"],{"errors":0,"dropped":0,"data_errors":0})
        self.assertEqual(result["download_exception_types"],["BusinessError"]*3)
        download=next(node for node in self.project["model"]["nodes"] if node["id"]=="download")
        self.assertFalse(any(state["id"].lower()=="denied" for state in download["lifecycle"]["states"]))

    def test_reported_probe_failure_is_a_mapping_failure(self):
        report=assess_probe_health({"runs":[{"case":"actual-http-errors","mode":"on","probe_health":{"errors":5,"dropped":0,"data_errors":0}}]},required=True)
        self.assertFalse(report["valid"])
        self.assertTrue(any(error.get("counter")=="errors" for error in report["errors"]))

    def test_actual_drive_frames_and_missing_transition_witness(self):
        with tempfile.TemporaryDirectory(prefix="drive-check-",dir=ROOT/"review") as directory:
            run=run_case("revoked","on",self.project,self.build_id,directory)
        snapshots=run["snapshots"]
        self.assertEqual([item["state"] for item in snapshots],["pending","approved","revoked"])
        journal=run["authority_snapshot"]["instances"][0]["journal"]
        self.assertEqual([(item["event"],item["before_state"],item["after_state"]) for item in journal],[("submit","pending","pending"),("approve","pending","approved"),("revoke","approved","revoked")])
        def replay(frames):
            graph=BOStateGraph(self.project["model"],build_id=self.build_id,mode="drive")
            results=[]
            for frame in frames:
                results.append(graph.bo_observe(frame["instance_id"],state=frame["state"],context=frame["context"],revision=frame["revision"],evidence_id=frame["evidence_id"],build_id=frame["build_id"],event=frame["event"],guards=frame["guards"],payload=frame["payload"]))
            return results
        clean=replay(snapshots)
        self.assertTrue(all(not item["errors"] and not item["missing"] for item in clean))
        corrupted=replay([snapshots[0],snapshots[-1]])
        self.assertTrue(corrupted[-1]["errors"] or corrupted[-1]["missing"])

    def test_unsynchronized_source_and_missing_return_are_detected(self):
        with tempfile.TemporaryDirectory(prefix="sensitivity-",dir=ROOT/"review") as directory:
            run=run_case("approved","on",self.project,self.build_id,directory)
        self.assertTrue(all(item["actual"]==item["mapped"] for item in run["mapping_checks"]))
        corrupted=deepcopy(run)
        target=next(event for event in corrupted["events"] if event["node"]=="download" and event["phase"]=="return")
        target["outputs"].pop("allowed")
        from bo_observer.workflow.whitebox_contract import assess
        contract=json.loads((ROOT/"whitebox.json").read_text(encoding="utf-8-sig"))
        report=assess(contract,self.project["model"],{"build_id":self.build_id,"runs":[corrupted]},self.build_id)
        self.assertTrue(report["errors"])
        with tempfile.TemporaryDirectory(prefix="source-check-",dir=ROOT/"review") as directory:
            copied=Path(directory)
            for name in self.project["model"]["source_files"]+["intent.json"]:
                destination=copied/name
                destination.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(ROOT/name,destination)
            manifest=capture(copied,self.project["model"])
            with (copied/"app/service.py").open("a",encoding="utf-8") as stream:
                stream.write("\n# Synthetic unsynchronized source change.\n")
            self.assertEqual(check(copied,self.project["model"],manifest)["status"],"stale")

    def test_recording_stop_drains_actual_producer_and_restores_capture(self):
        with tempfile.TemporaryDirectory(prefix="recording-check-",dir=ROOT/"review") as directory:
            copied=Path(directory)
            for name in self.project["model"]["source_files"]+["intent.json","bo_stategraph/project.json"]:
                destination=copied/name
                destination.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(ROOT/name,destination)
            session=GraphSession(copied)
            def sink(body,kind):
                session.event(body) if kind=="events" else session.snapshot(body)
            monitor=BOMonitor(self.project,self.build_id,sink=sink)
            session.bo_bind_capture(scope_setter=monitor.probe.bo_set_scope,flush_capture=lambda:monitor.probe.flush(30),health=monitor.bo_health)
            store=Store(copied/"application-data",monitor)
            store.initialize()
            service=Service(store,self.project,ROOT)
            file=service.upload("owner","recording.txt",b"Recording boundary test")
            share=service.request_share("owner",file["id"],"recipient","reviewer")
            client=create_app(service).test_client()
            with client.session_transaction() as cookie:
                cookie["user"]={"id":"reviewer","name":"Zhou"}
            session.recordings.start("approval and final HTTP 404")
            service.change_share("reviewer",share["id"],"approve")
            self.assertEqual(client.get("/download/missing-file").status_code,404)
            before=store.snapshot(self.build_id)
            stopped=session.recordings.stop()  # No test-side flush before stop.
            recording=session.recordings.get(stopped["id"])
            self.assertTrue(recording["producer_settlement"]["flushed"])
            self.assertEqual(recording["gaps"],[])
            self.assertEqual(monitor.bo_health()["pending"],0)
            self.assertTrue(any(event["node"]=="http_download" and event["phase"]=="return" and event["outputs"]["status"]==404 for event in recording["events"]))
            self.assertEqual(len(recording["events"]),recording["end_seq"]-recording["start_seq"])
            second=service.request_share("owner",file["id"],"other","reviewer")
            session.recordings.start("selected approval",{"mode":"focused","roots":["review"]})
            service.change_share("reviewer",second["id"],"approve")
            focused=session.recordings.get(session.recordings.stop()["id"])
            self.assertEqual({event["node"] for event in focused["events"]},{"review"})
            self.assertEqual(len(focused["events"]),4)
            self.assertIsNone(monitor.probe.bo_capture_nodes)
            before_read_only=store.snapshot(self.build_id)
            session.recordings.start("restored full download")
            self.assertEqual(service.download("recipient",file["id"])[1],b"Recording boundary test")
            full=session.recordings.get(session.recordings.stop()["id"])
            self.assertIn("download",{event["node"] for event in full["events"]})
            self.assertTrue(any(event["node"].startswith("policy:") for event in full["events"]))
            self.assertEqual(full["gaps"],[])
            self.assertEqual(monitor.bo_health()["errors"],0)
            self.assertEqual(monitor.bo_health()["data_errors"],0)
            self.assertEqual(store.snapshot(self.build_id),before_read_only)
            monitor.probe.close()
            session.close()
            store.engine.dispose()

    def test_queue_loss_does_not_change_committed_business_effects(self):
        import time
        with tempfile.TemporaryDirectory(prefix="queue-check-",dir=ROOT/"review") as directory:
            def slow_sink(body,kind):
                time.sleep(0.01)
            monitor=BOMonitor(self.project,self.build_id,sink=slow_sink,capacity=1)
            store=Store(directory,monitor)
            store.initialize()
            service=Service(store,self.project,ROOT)
            file=service.upload("owner","queue.txt",b"Queue-limited business result")
            share=service.request_share("owner",file["id"],"recipient","reviewer")
            service.change_share("reviewer",share["id"],"approve")
            self.assertEqual(service.download("recipient",file["id"])[1],b"Queue-limited business result")
            snapshot=store.snapshot(self.build_id)
            self.assertEqual(snapshot["instances"][0]["state"],"approved")
            self.assertEqual(len(snapshot["messages"]),6)
            self.assertGreater(monitor.bo_health()["dropped"],0)
            monitor.probe.close()
            store.engine.dispose()


if __name__=="__main__":
    unittest.main()
