# Independent application trial

Work only in this directory. The maintained VibeLens repository and other trials
are read-only references; do not change them or the global Skill installation.

This project retains a source-bound developer graph and selected runtime evidence.
Run `python -B -X utf8 tooling/check.py` before delivery. Preserve the original
`.stategraph/initial-app/baseline.json`, independent expectations and failed attempts.
Conversation guidance is activated only by an explicit `$vibelens` invocation;
these integrity checks do not activate dialogue or viewer controls in other chats.

The user explicitly invokes the project-local `.agents/skills/vibelens/SKILL.md`
for this conversation. Use this exact local copy. Keep application source and
comments in English; converse in Chinese. Preserve actual questions, answers,
design confirmations, failures and checks in `review/`.

Wait for answers to business questions and graph confirmation. The test
coordinator supplies simulated-user replies in this same conversation; they are
test inputs and must be identified as such in the review evidence. Do not answer
your own blocking questions or invent confirmation. Do not contact other chats.

Use free local ports and synthetic test data. Keep processes hidden and record
only the process identities started for this project. Do not stop other services.
