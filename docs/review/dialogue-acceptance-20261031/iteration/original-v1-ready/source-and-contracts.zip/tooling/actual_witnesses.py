"""Compare real native arguments/results with captured fields; never use graph values as an oracle."""

from collections import defaultdict
from contextlib import contextmanager
from copy import deepcopy

from sqlalchemy import select,func
from app.models import notifications


def install_native_readers(service,store,monitor):
    calls=[]

    def wrap(name,describe,project):
        original=getattr(service,name)
        def invoke(*args,**kwargs):
            node,inputs=describe(args)
            record={"node":node,"inputs":deepcopy(inputs),"source":"Actual arguments and native return from app/service.py::Service."+name}
            calls.append(record)
            before=None
            if name=="_messages":
                before=args[0].execute(select(func.count()).select_from(notifications)).scalar_one()
            try:
                result=original(*args,**kwargs)
            except BaseException as error:
                record.update(phase="error",outputs={"error":type(error).__name__},error_status=getattr(error,"status",None))
                raise
            else:
                record.update(phase="return",outputs=project(args,result,before))
                return result
        setattr(service,name,invoke)

    wrap("login",lambda args:("login",{"username":args[0],"password_supplied":bool(args[1])}),lambda args,result,before:{"allowed":True,"user_id":result["id"]})
    wrap("logout",lambda args:("logout",{"actor_id":args[0]}),lambda args,result,before:{"logged_out":result is None})
    wrap("upload",lambda args:("upload",{"actor_id":args[0],"filename":args[1],"size":len(args[2])}),lambda args,result,before:{"file_id":result["id"],"saved":(store.blobs/result["id"]).is_file(),"size":(store.blobs/result["id"]).stat().st_size})
    wrap("request_share",lambda args:("share",dict(zip(["actor_id","file_id","recipient_id","reviewer_id"],args))),lambda args,result,before:{"share_id":result["id"],"state":result["state"],"revision":result["revision"]})
    wrap("change_share",lambda args:("review" if args[2] in {"approve","reject"} else "cancel_share" if args[2]=="cancel" else "revoke",dict(zip(["actor_id","share_id","event"],args))),lambda args,result,before:{"state":result["state"],"revision":result["revision"],"changed":True})
    wrap("download",lambda args:("download",dict(zip(["actor_id","file_id"],args))),lambda args,result,before:{"allowed":True,"size":len(result[1]),"file_id":args[1]})
    wrap("dashboard",lambda args:("received_files",{"actor_id":args[0]}),lambda args,result,before:{"owned_count":len(result["owned"]),"received_count":len(result["received"]),"review_count":len(result["reviews"]),"message_count":len(result["messages"])})
    wrap("read_notification",lambda args:("read_notification",dict(zip(["actor_id","notification_id"],args))),lambda args,result,before:{"is_read":bool(next(item for item in store.snapshot("independent")["messages"] if item["id"]==args[1])["is_read"])})
    wrap("_messages",lambda args:("notification" if args[3]=="review_result" else "share_message",{"share_id":args[1]["id"],"kind":args[3],"recipients":sorted({args[1]["owner_id"],args[1]["recipient_id"],args[1]["reviewer_id"]})}),lambda args,result,before:{"count":args[0].execute(select(func.count()).select_from(notifications)).scalar_one()-before,"state":args[1]["state"]})

    for name,node in [("read","db_read"),("write","db_write")]:
        original=getattr(store,name)
        def invoke_native(db,statement,_original=original,_node=node):
            record={"node":_node,"inputs":{},"source":"Native SQLAlchemy result from app/storage.py::Store."+("read" if _node=="db_read" else "write")}
            calls.append(record)
            try:
                result=_original(db,statement)
            except BaseException as error:
                record.update(phase="error",outputs={"error_type":type(error).__name__})
                raise
            count=len(result) if _node=="db_read" else max(0,result)
            record.update(phase="return",outputs={"rows":count,"result":{"count":count}})
            return result
        setattr(store,name,invoke_native)

    original_unit=store.unit
    @contextmanager
    def observe_unit():
        record={"node":"db_transaction","inputs":{},"source":"Actual completion of app/storage.py::Store.unit transaction manager"}
        calls.append(record)
        try:
            with original_unit() as connection:
                yield connection
        except BaseException as error:
            record.update(phase="error",outputs={"status":"rolled_back","committed":False,"error_type":type(error).__name__})
            raise
        else:
            record.update(phase="commit",outputs={"status":"committed","committed":True})
    store.unit=observe_unit
    original_transform=monitor.transform
    def observe_transform(node,function,value,**options):
        record={"node":node,"inputs":{},"source":"Actual clean_filename argument and returned filename"}
        calls.append(record)
        try:
            result=original_transform(node,function,value,**options)
        except BaseException as error:
            record.update(phase="error",outputs={"error_type":type(error).__name__})
            raise
        record.update(phase="change",outputs={"before":{"filename":value},"result":{"filename":result}})
        return result
    monitor.transform=observe_transform
    return calls


def compare_native_calls(case,mode,calls,events):
    checks=[]
    groups=defaultdict(list)
    by_call={}
    for event in events:
        key=(event["node"],event["call_id"])
        if event["phase"]=="enter":
            group={"entry":event,"events":[]}
            by_call[key]=group
            groups[event["node"]].append(group)
        if key in by_call:
            by_call[key]["events"].append(event)
    offsets=defaultdict(int)
    def add(record,name,actual,mapped):
        checks.append({"id":f"{case}:{mode}:native:{len(checks)}:{name}","source":record["source"],"projection":record["node"]+"."+name,"actual":actual,"mapped":mapped})
    for record in calls:
        node=record["node"]
        number=offsets[node]
        offsets[node]+=1
        group=groups[node][number] if number<len(groups[node]) else {"entry":{},"events":[]}
        entry=group["entry"]
        finish=next((event for event in reversed(group["events"]) if event["phase"]==record["phase"]),{})
        add(record,"completion_phase",record["phase"],finish.get("phase"))
        for field,value in record["inputs"].items():
            add(record,"inputs."+field,value,entry.get("inputs",{}).get(field))
        for field,value in record["outputs"].items():
            if field=="error" and not finish.get("outputs",{}).get("error"):
                continue  # Generic exception boundary is checked above; no cause is invented.
            add(record,"outputs."+field,value,finish.get("outputs",{}).get(field))
    return checks


def compare_policy_reports(case,mode,evaluations,events):
    checks=[]
    for evaluation in evaluations:
        for step in evaluation["trace"]:
            event=next((event for event in events if event["node"]=="policy:"+step["node"] and event.get("inputs",{}).get("bo_check")==evaluation["check_id"]),{})
            checks.append({"id":f"{case}:{mode}:predicate:{evaluation['check_id']}:{step['node']}","source":"Actual native policy evaluation return from app/policy.py::authorize","projection":"policy:"+step["node"],"actual":{"arguments":step["arguments"],"value":step["value"]},"mapped":{"arguments":{key:event.get("inputs",{}).get(key) for key in step["arguments"]},"value":event.get("outputs",{}).get("value")}})
    return checks
