"""Compare real HTTP rejection responses with their deferred captured return boundaries."""

import json
from pathlib import Path
import sys
import tempfile

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/"observer_runtime")]

from app.storage import Store
from app.service import Service
from app.web import create_app
from integrations.bo_monitor import BOMonitor
from bo_observer.graph.behavior_model import capture


def exercise_http_errors(project,build_id,directory):
    events=[]
    monitor=BOMonitor(project,build_id,sink=lambda body,kind:events.append(body) if kind=="events" else None)
    store=Store(directory,monitor)
    store.initialize()
    service=Service(store,project,ROOT)
    file=service.upload("owner","http-errors.txt",b"Synthetic rejection case")
    app=create_app(service)
    client=app.test_client()
    client.get("/")
    with client.session_transaction() as session:
        session["user"]={"id":"recipient","name":"Xu"}
    outcomes=[]
    outcomes.append({"name":"forbidden_download","response":client.get("/download/"+file["id"]).status_code,"expected":403,"business_expected":403,"node":"http_download"})
    outcomes.append({"name":"missing_download","response":client.get("/download/missing-file").status_code,"expected":404,"business_expected":404,"node":"http_download"})
    anonymous=app.test_client()
    outcomes.append({"name":"anonymous_download","response":anonymous.get("/download/"+file["id"]).status_code,"expected":401,"business_expected":401,"node":"http_download"})
    outcomes.append({"name":"csrf_redirect","response":client.post("/",data={"action":"upload","csrf":"incorrect"}).status_code,"expected":303,"business_expected":400,"node":"http_action"})
    with client.session_transaction() as session:
        csrf=session["csrf"]
    outcomes.append({"name":"login_error_redirect","response":client.post("/",data={"action":"login","username":"owner","password":"wrong-test-password","csrf":csrf}).status_code,"expected":303,"business_expected":401,"node":"http_action"})
    monitor.flush()
    captured=[event for event in events if event["node"] in {"http_download","http_action"} and event["phase"]=="return"]
    health={"errors":monitor.probe.bo_errors,"dropped":monitor.probe.bo_dropped,"data_errors":monitor.data.bo_errors}
    matching=len(captured)==len(outcomes) and all(event["node"]==row["node"] and event["outputs"].get("status")==row["response"] and event["outputs"].get("business_status")==row["business_expected"] for row,event in zip(outcomes,captured))
    result={"actual_responses":outcomes,"captured_returns":captured,"probe_health":health,"correct_responses":all(row["response"]==row["expected"] for row in outcomes),"complete_return_boundaries":matching,"download_exception_types":[event["outputs"].get("error") for event in events if event["node"]=="download" and event["phase"]=="error"]}
    monitor.probe.close()
    store.engine.dispose()
    return result


if __name__=="__main__":
    project=json.loads((ROOT/"bo_stategraph/project.json").read_text(encoding="utf-8"))
    manifest=capture(ROOT,project["model"])
    with tempfile.TemporaryDirectory(prefix="http-regression-",dir=ROOT/"review") as directory:
        result=exercise_http_errors(project,manifest["build_id"],directory)
    output=ROOT/sys.argv[1]
    output.write_text(json.dumps(result,indent=2),encoding="utf-8")
    print(json.dumps({key:value for key,value in result.items() if key!="captured_returns"}))
    raise SystemExit(0 if result["correct_responses"] and result["complete_return_boundaries"] and not any(result["probe_health"].values()) else 1)
