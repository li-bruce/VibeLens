# Capture viewer backlog technical upgrade

The coordinator requested this separate upgrade after `capture-batch-sink`
had already passed accept. Its normal check also passed before this change
began. The new immutable baseline starts from accepted candidate
`c1b9f60477f5cbe69691f41accb7af95de17593c72d694a334c02da6e34c7049`,
build `01e3f022cb923c50df6664e730ddfa65d18ef3fbf4ab1364424e7d252f1c937a`.
No intermediate restart occurred.

The coordinator reports repeated cold browser resource failures and an upstream
real TCP regression: old listener timed out 10 of 16 cold parallel connections;
the fixed listener served all 16 exact resources with no business events. The
official maintained source adds `SessionServer.request_queue_size = 64` and its
explanation. It does not alter HTTP validation, viewer assets, business logic,
parameter definitions, recording semantics or the 30-second producer drain.

Preservation 001 copies all four earlier changes, five baselines, the existing
database, 17 blobs, seven recordings and personal configuration. The maintained
working-tree source manifest differs from the batch source only in
`scripts/bo_observer/service.py`. Exact canonical hashes for that file and all
three batch modules are recorded. The previous 265-file Skill is preserved;
official install/upgrade and ownership sealing changed only runtime service.py.

The added project regression uses actual deployed HTML, routing vendor and WASM
bytes. Sixteen real sockets connect to an isolated cold listener before its
accept thread is scheduled; HTTP responses must be 200 and byte-identical.
Collector sequence/history/errors/gaps remain zero. No original service or
business operation is used.

Negative-control attempt 001 changed an already active socket's listen setting;
it did not reproduce the old cold state and is retained as an invalid attempt.
Attempt 002 sets only the isolated server instance's old queue value before its
first original native activation; the same unchanged regression correctly fails
on cold connection overflow. Canonical files and validators were not patched.
Restoring the actual official listener passed 16/16 again. Raw results and logs
are preserved with unique names. Existing seven observation test methods remain
verbatim equal to the saved accepted-batch recording source.

Business source/contracts, native machine/policy, all 19 feature parameter
records, 53 cases, 335 authored assertions, modes and probe/test requirements are
unchanged. The new 26-file core package is byte-identical entry by entry to the
core already executed in the batch change; that actual observer-free execution
is reused explicitly rather than reported as a new run.

Only after both complete formal upgrades pass will identity-verified owned
services restart on the existing ports. Post-start checks are read-only. Real
browser/recording acceptance of the final original-project build belongs to the
coordinator. No maintained/global Skill edits, publishing or other-chat messages.

## Accepted result

Full verify, accept and normal project check passed for candidate
`e5fc6cf0599f91b1b6fda8020a1720d92a6c1cf2d2f0bf92f6ef258b308111c9`,
build `60d18fc45a8c84a202b02f91ab203981d97ef3cea13e2ddb92a221fd6e87ece8`.
All 28 tests, 159 actual scenario runs, 18,752 native witnesses, 1,272 public
projections and all 1,005 assertions passed. Final cold run served all 16 exact
resources with zero events. The valid local old-queue control had nine timeouts,
distinct from the coordinator's upstream count of ten.

One verified owned restart replaced server 38932/launcher 40524 with hidden
server 29804/launcher 78512 at the existing ports. Both pages return 200 and
report the accepted/current build; all readiness counters and runtime events are
zero. Final preservation confirms all original rows/schema, 17 blobs, seven
recordings, five baselines, previous change directories, configs, session secret,
source backups and external failure evidence remain unchanged. No post-start
business or recording action occurred. Complete evidence and the still-pending
independent browser acceptance boundary are in `handoff-capture-viewer-backlog.json`.
