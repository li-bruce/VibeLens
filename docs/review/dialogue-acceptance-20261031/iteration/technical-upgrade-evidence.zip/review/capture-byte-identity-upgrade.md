# Capture byte identity technical upgrade

The coordinator requested an official project-local upgrade from the maintained
working tree after two full recordings in the original trial reached the
unchanged 30-second stop-drain bound. Both recordings remain `interrupted`.
Business correctness and zero capture errors/drops in those attempts do not
establish complete recording. A reported 1,231-event success in a separate copy
is external evidence, not acceptance of this original project.

`change_sync begin` created `.stategraph/capture-byte-identity` from accepted
candidate `caab0431a8dbba6ddee4df172cf1b740d8609224676bc5dc559b43c6a5f8a10e`
before any installed Skill or runtime changes. The `initial-app` change and its
original baseline remain intact. Preservation hashes and complete copies of the
old change and recordings are under `review/attempts/` and `review/preserved/`.
Read-only inspection confirms that `7d00fc89e4454cf284c03db80018597c` retains
1,303 events and `c7ef73d4e0894f4fb690b34ab4eae988` retains 1,129 events; both
retain the producer-drain gap and `interrupted` status. The older 149-event
recording is also retained and is not evidence of complete capture.

The official installer was run twice. The second installation follows the
coordinator's notice that the maintained `session.py` and `source_files.py`
formatting was stable. Both previous local Skill copies are retained with hash
manifests. The official runtime upgrader changed exactly those two runtime files.
The installed Skill also includes the top-level `mapping_checks` clarification
in `continuous-development.md` and `mapping-contract.md`. No global Skill or
maintained-repository file was edited.

The runtime optimization rereads actual project bytes and skips repeated JSON
normalization only for a previously verified byte identity. Formatting-equivalent
definitions remain comparable. Same-size/same-time changes and physical path
containment retain their checks. Protocols, business behavior, the capture
controller, fields, cases, modes, and `flush(30)` are unchanged.

Only backup provenance entries in `sync.json` and the official managed runtime
fingerprints in `ownership.json` require local integration updates. The graph
generator and the initial-app review helper are unchanged; the latter has a
fixed initial-app output path, so the new technical review is written directly
to the new change directory. Scan and acceptance refresh the exact candidate
and build without regenerating business semantics.

Attempt files have unique names. Two exploratory reads initially used incorrect
paths, and an `rg` invocation used a Windows wildcard as a literal path; these
were read-only command failures and were corrected before upgrade validation.

Final original-project browser recording and timeline validation belongs to the
independent coordinator. After accepting and restarting this technical build,
the implementation agent performs readiness reads only and leaves the services
running without business or recording operations.

The unchanged verification gate passed for candidate
`ae9cedf4681ef270aeadba5e1800633d76e65ef0925c8dea25795ae2e7f32fe6`.
Mapping passed with 9,086 witnesses and 744 projection checks; state constraints,
business rules and project checks also passed. All 81 required business assertions
executed, covering 31 cases in on/off/fault modes (93 real isolated runs). The
31 on-mode reports have zero capture errors, drops and data-adapter errors.
All 18 project tests passed in 31.654 seconds. The separate architecture check
passed for all 219 managed files. Full receipts, actual observations and command
outputs are retained under `attempts/capture-byte-identity-*` and the new change's
`checks/` directory. These results do not close independent browser acceptance.

Both `accept` and the normal `tooling/check.py` entrypoint passed for the same
candidate. Accepted build:
`22f404fa1a87c3da3dd442beadd03669ed3e3feff692be26948efd431ca8b7e9`.
Only the recorded, command-line-verified old trial processes were stopped.
The hidden replacement has server PID 82236 and launcher PID 68584.
Application: http://127.0.0.1:50643/ ; graph: http://127.0.0.1:50642/graph .
Readiness confirmed matching build identities, current source binding and HTTP
200 for the graph. Producer enqueued/pending/errors/drops/data errors and
collector errors/gaps were all zero at that check. Only application/graph health,
graph view and graph document GETs were performed after restart. Both services
remain running for the coordinator. Complete handoff and final preservation
checks are in `handoff-capture-byte-identity.json`; the original handoff is retained.
