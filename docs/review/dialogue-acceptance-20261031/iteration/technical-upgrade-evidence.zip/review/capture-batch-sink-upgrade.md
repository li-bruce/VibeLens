# Capture batch sink technical upgrade

The coordinator requested this upgrade in the same development conversation,
starting from accepted candidate
`92749e223f3735b616435db2a1d742744a8444036b6e1eaab9e3c30854e1d9e1`,
build `3c209caabc58b47e7814be670cffeae9f9f9e0723c53cf1d3177d86ded0ee2b7`.
No business requirement, graph meaning or acceptance expectation changes.

The coordinator reports that original-project browser business operations passed,
but recording interrupted at the existing 30-second drain bound: 1,226 events
saved and 111 pending, with zero capture/data errors or drops. The read-only
external recording confirms interrupted status, 1,226 events and the drain gap.
Its complete evidence remains untouched in the maintained repository under
`docs/review/dialogue-acceptance-20261031/operations-original-v2-supplement-01/`.
A reported 1,228-event success in a separate source-identical copy is external
evidence; it is not original-project acceptance after this upgrade.

`change_sync begin` created `.stategraph/capture-batch-sink` before changes, with
no changed requirement IDs. Preservation 001 archives the three earlier changes,
current database, 17 file blobs, seven recordings and personal configuration.
Exact source hashes identify the maintained local working tree rather than a
claimed release/commit. Old Skill provenance and every earlier baseline remain.

The official installer and upgrader changed three managed runtime files only:
`session.py`, `bo_probe.py` and new `observation/event_batch.py`. The optional
local sink validates adjacent event groups using an independent preflight cursor
and both source boundaries before publication. Probe batches contain at most 16
events and stop at snapshot barriers. Each event keeps its original protocol,
identity, acceptance reducer and receipt. Batch rejection falls back to individual
processing. HTTP and ordinary callbacks retain the original interface. The
withdrawn Windows handle experiment is not installed.

`tooling/dev.py` passes the actual `session.bo_sink` to BOMonitor. Capture scope,
health and `flush(30)` are unchanged. The original single-callback recording
regression is retained verbatim. A new real-sink regression creates backlog,
releases it immediately before the normal stop, and saves actual isolated
recording evidence. Call-through spies observe real batch acceptance and snapshot
receipt order; they do not fabricate events, validation results or receipts.
Checks cover four return/resubmit changes, instance/attempt/revision identity,
snapshots as barriers, latest-pair privacy, unchanged business data and zero
post-drain pending/error/drop counters. No pre-flush or queue-empty wait precedes
stop. Maintained tests are reported external evidence; project regressions run
only inside this independent trial.

After complete verify/accept/normal check, restart only identity-verified owned
services and perform readiness reads. Original-project browser business or
recording operations after restart belong to the independent coordinator. No
maintained/global Skill edits, publication or other-chat messages are authorized.

## Accepted result and combined deployment

Full verify, accept and normal check passed for candidate
`c1b9f60477f5cbe69691f41accb7af95de17593c72d694a334c02da6e34c7049`,
build `01e3f022cb923c50df6664e730ddfa65d18ef3fbf4ab1364424e7d252f1c937a`.
All 27 tests and unchanged 159-run/1,005-assertion gate passed. The coordinator's
later listener fix arrived after accept, so its separate change completed before
one combined restart. See `handoff-capture-batch-sink.json` for this accepted
historical build and `handoff-capture-viewer-backlog.json` for the final runtime.
