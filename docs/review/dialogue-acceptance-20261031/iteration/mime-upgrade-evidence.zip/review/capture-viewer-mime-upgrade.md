# Capture viewer MIME technical upgrade

This distinct change began from accepted backlog candidate
`e5fc6cf0599f91b1b6fda8020a1720d92a6c1cf2d2f0bf92f6ef258b308111c9`,
build `60d18fc45a8c84a202b02f91ab203981d97ef3cea13e2ddb92a221fd6e87ece8`,
before source edits, with no changed business requirement IDs.

The coordinator reports original-project two-round business and full recording
success (1,363 real events; stop 3.525 seconds), 12 page groups passing, a later
timeline reload initialization failure, and a subsequent nine-group diagnostic
timeline pass. These are independent trial reports. A reproducible MIME defect
was found separately: Chrome rejects streaming WASM when the response carries
`application/wasm; charset=utf-8`. Fixing that defect is not evidence that every
intermittent reload cause has been resolved.

Preservation 001 archives all five previous change directories/six baselines,
current rows and schema, 20 blobs, eight recordings, session files and personal
configuration. It confirms the newly complete recording
`2e074dbcacea43efa53131f39743e089` remains stopped with 1,363 events. No older
17-file/seven-recording snapshot is used to restore this current data.

Source manifest 001 records the first maintained service-only MIME proposal.
Before installation, the coordinator extended the same change to a shared MIME
function and listener class in canonical web/bo_web.py. Source manifest 002 keeps
001 intact and records the complete revised installation source. There was no
first installed parity result to overwrite. Official installation/upgrade and
ownership sealing changed exactly service.py and web/bo_web.py. All five relevant
runtime hashes are pinned; the three batch modules are unchanged. Maintained
examples and global Skill are outside scope and were not edited.

The added native HTTP regression first failed against the old canonical runtime
on the actual WASM charset defect; raw bytes were correct. Its raw failure and
complete response evidence are retained. The same added method now exercises
both real runtime make_server and real design bo_serve. A call-through design
server constructor witness only obtains the real ephemeral listener for cleanup;
it does not replace handlers, validators, source rules or results. Sixteen actual
responses cover deployed HTML/vendor/WASM plus explicit text/JSON/SVG/binary
transfer fixtures and native JSON APIs. Resource bytes, lengths, nosniff, text
UTF-8, exact binary MIME and zero business events are checked independently.
The isolated design server is shut down after the test.

All eight prior observation methods remain verbatim, and all business source,
declarations, actor/permission/field/instance/parameter/case/mode/probe requirements
remain unchanged. The shared BOHTTPServer retains queue64; actual batch sink,
snapshot barriers and flush(30) remain. New package entries are byte-identical
to the 26-file observer-free core actually executed earlier; this is explicitly
validation reuse, not a new execution claim.

The agent completes scan/inspect/concrete review/full verify/accept/normal check
before restarting identity-verified owned services on the same ports. After
startup, only readiness reads and documentation are allowed. Browser
compileStreaming and original-project timeline/reload/recording acceptance of
the final build remain with the independent coordinator. No publication or
other-chat messaging is performed.

## Accepted result

Full verify, accept and normal project check passed for candidate
`5c87114c17ae58eb0d9bb4c2e2b621280a1fd73c35416969d46b1c840c694596`,
build `55adb37274e9423694099b9fc86bbccf78454c50d14bd45eb9e756704e3b170f`.
All 29 tests, 159 actual runs, 18,752 native witnesses, 1,272 public projections
and all 1,005 assertions passed. Runtime and design native HTTP checks both pass;
the original WASM MIME failure remains as evidence.

After identity verification, old server 29804 was stopped and launcher 78512
exited. Hidden replacement server 18992/launcher 21120 use the same ports. Both
pages report the accepted/current build with zero counters/events. Read-only
live WASM GET returns exact application/wasm and all 485,460 expected bytes;
JSON/HTML retain UTF-8. No business or recording operation occurred after startup.

Final preservation confirms all six baselines, five previous change directories,
20 blobs/eight recordings/current rows/schema/configs/session secret and source
backups unchanged. The complete 1,363-event recording is byte-identical. Both
source manifests and external evidence are preserved. All 220 managed files and
five canonical runtime hashes match. Final handoff and the explicitly pending
new-build browser acceptance boundary: `handoff-capture-viewer-mime.json`.
