"""Independent supplementation rules, privacy, migration and capture regressions."""

from contextlib import closing
from copy import deepcopy
import json
from pathlib import Path
import sqlite3
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/"observer_runtime")]
from app.models import metadata
from app.service import Service,BusinessError
from app.storage import Store
from app.web import create_app
from bo_observer.graph.behavior_model import capture
from integrations.bo_monitor import BOMonitor
from tooling.actual_witnesses import install_native_readers,compare_native_calls


class SupplementTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix="supplement-test-",dir=ROOT/"review")
        self.project=json.loads((ROOT/"bo_stategraph/project.json").read_text())
        self.store=Store(self.temp.name)
        self.store.initialize()
        self.service=Service(self.store,self.project,ROOT)
        self.file=self.service.upload("owner","private.txt",b"unchanged file")
        self.share=self.service.request_share("owner",self.file["id"],"recipient","reviewer")

    def tearDown(self):
        self.store.engine.dispose()
        self.temp.cleanup()

    def records(self):
        with closing(sqlite3.connect(self.store.database)) as connection:
            connection.row_factory=sqlite3.Row
            return {name:[dict(row) for row in connection.execute("SELECT * FROM "+name+" ORDER BY id")] for name in ["shares","notifications","journal"]}

    def test_rounds_latest_pair_notices_and_final_recipients(self):
        ident=self.share["id"]
        self.service.return_share("reviewer",ident,"first reason")
        self.service.resubmit_share("owner",ident,"first explanation")
        self.service.return_share("reviewer",ident,"second reason")
        self.assertEqual(self.service.supplement_details("owner",ident)["supplement_text"],"")
        self.service.resubmit_share("owner",ident,"second explanation")
        row=self.service.supplement_details("reviewer",ident)
        self.assertEqual((row["return_reason"],row["supplement_text"]),("second reason","second explanation"))
        self.assertEqual([row[k] for k in ["file_id","owner_id","recipient_id","reviewer_id"]],[self.file["id"],"owner","recipient","reviewer"])
        records=self.records()
        for old in ["first reason","first explanation"]:self.assertNotIn(old,json.dumps(records))
        self.assertEqual([n["user_id"] for n in records["notifications"] if n["kind"]=="returned"],["owner","owner"])
        self.assertEqual([n["user_id"] for n in records["notifications"] if n["kind"]=="resubmitted"],["reviewer","reviewer"])
        for text in ["second reason","second explanation"]:
            self.assertNotIn(text,json.dumps(records["notifications"]))
            self.assertNotIn(text,json.dumps(records["journal"]))
        self.assertEqual(len(records["journal"]),5)
        self.service.change_share("reviewer",ident,"approve")
        for kind in ["review_result","shared"]:
            self.assertEqual(sorted(n["user_id"] for n in self.records()["notifications"] if n["kind"]==kind),["owner","recipient","reviewer"])

    def test_bounds_authority_and_waiting_rules(self):
        ident=self.share["id"]
        for reason in [""," \t\n","文"*201]:
            with self.assertRaises(BusinessError) as error:self.service.return_share("reviewer",ident,reason)
            self.assertEqual(error.exception.status,400)
        with self.assertRaises(BusinessError):self.service.return_share("other",ident,"valid")
        self.service.return_share("reviewer",ident,"文"*200)
        for event in ["approve","reject"]:
            with self.assertRaises(BusinessError):self.service.change_share("reviewer",ident,event)
        with self.assertRaises(BusinessError):self.service.return_share("reviewer",ident,"again")
        with self.assertRaises(BusinessError):self.service.resubmit_share("other",ident,"valid")
        for text in [""," \t\n","字"*201]:
            with self.assertRaises(BusinessError) as error:self.service.resubmit_share("owner",ident,text)
            self.assertEqual(error.exception.status,400)
        self.service.resubmit_share("owner",ident,"字"*200)
        self.assertEqual(self.records()["shares"][0]["state"],"pending")

    def test_cancel_and_non_granted_downloads(self):
        ident=self.share["id"]
        self.service.return_share("reviewer",ident,"reason")
        self.assertEqual(self.service.dashboard("recipient")["received"],[])
        with self.assertRaises(BusinessError):self.service.download("recipient",self.file["id"])
        with self.assertRaises(BusinessError):self.service.change_share("other",ident,"cancel")
        self.service.change_share("owner",ident,"cancel")
        with self.assertRaises(BusinessError):self.service.resubmit_share("owner",ident,"late")
        with self.assertRaises(BusinessError):self.service.change_share("reviewer",ident,"approve")
        self.assertEqual(self.records()["shares"][0]["state"],"cancelled")

    def test_http_private_view_and_real_form_paths(self):
        app=create_app(self.service)
        def client(actor):
            value=app.test_client()
            with value.session_transaction() as session:session.update(user={"id":actor,"name":actor},csrf="test-csrf")
            return value
        owner,reviewer,recipient,other=[client(a) for a in ["owner","reviewer","recipient","other"]]
        url="/application/"+self.share["id"]
        self.assertEqual(reviewer.post("/",data={"action":"return_share","share_id":self.share["id"],"reason":"private reason","csrf":"test-csrf"}).status_code,303)
        for value in [recipient,other]:self.assertEqual(value.get(url).status_code,403)
        self.assertEqual(app.test_client().get(url).status_code,401)
        self.assertEqual(owner.get("/application/missing").status_code,404)
        self.assertIn(b"private reason",owner.get(url).data)
        self.assertNotIn(b"private reason",owner.get("/").data)
        self.assertNotIn(b"private reason",reviewer.get("/").data)
        response=owner.post("/",data={"action":"resubmit_share","share_id":self.share["id"],"explanation":"<script>private</script>","file_id":"tampered","recipient_id":"other","reviewer_id":"other","csrf":"test-csrf"})
        self.assertEqual(response.status_code,303)
        page=reviewer.get(url).data
        self.assertIn(b"&lt;script&gt;private&lt;/script&gt;",page)
        self.assertNotIn(b"<script>private</script>",page)
        row=self.records()["shares"][0]
        self.assertEqual((row["file_id"],row["recipient_id"],row["reviewer_id"]),(self.file["id"],"recipient","reviewer"))

    def test_failure_rolls_back_text_state_journal_and_notices(self):
        original=self.service._messages
        def fail(*args):
            original(*args)
            raise OSError("synthetic insert failure")
        before=self.records()
        with patch.object(self.service,"_messages",fail):
            with self.assertRaises(OSError):self.service.return_share("reviewer",self.share["id"],"reason")
        self.assertEqual(self.records(),before)
        self.service.return_share("reviewer",self.share["id"],"reason")
        before=self.records()
        with patch.object(self.service,"_messages",fail):
            with self.assertRaises(OSError):self.service.resubmit_share("owner",self.share["id"],"explanation")
        self.assertEqual(self.records(),before)

    def test_two_simultaneous_returns_commit_one_round(self):
        barrier=threading.Barrier(2)
        outcomes=[]
        def act():
            barrier.wait()
            try:self.service.return_share("reviewer",self.share["id"],"reason");outcomes.append("changed")
            except BusinessError:outcomes.append("denied")
        threads=[threading.Thread(target=act) for _ in range(2)]
        for thread in threads:thread.start()
        for thread in threads:thread.join(5)
        self.assertEqual(sorted(outcomes),["changed","denied"])
        self.assertEqual(len(self.records()["notifications"]),1)

    def test_captured_lengths_are_independent_and_wrong_value_is_detected(self):
        events=[]
        build=capture(ROOT,self.project["model"])["build_id"]
        monitor=BOMonitor(self.project,build,sink=lambda body,kind:events.append(body) if kind=="events" else None)
        self.store.monitor=self.service.monitor=monitor
        calls=install_native_readers(self.service,self.store,monitor)
        try:
            self.service.return_share("reviewer",self.share["id"],"private reason")
            self.service.resubmit_share("owner",self.share["id"],"private explanation")
            self.service.supplement_details("reviewer",self.share["id"])
            self.assertTrue(monitor.flush())
            self.assertEqual(monitor.bo_health()["errors"],0)
            checks=compare_native_calls("supplement","on",calls,events)
            self.assertTrue(all(c["actual"]==c["mapped"] for c in checks))
            self.assertNotIn("private reason",json.dumps(events))
            self.assertNotIn("private explanation",json.dumps(events))
            for node in ["return_share","resubmit_share"]:
                identities={(e["run_id"],e["attempt"],e["entity"]) for e in events if e["node"]==node}
                self.assertEqual(len(identities),1)
                self.assertEqual(next(iter(identities))[1:],(self.share["id"],self.share["id"]))
            bad=deepcopy(events)
            next(e for e in bad if e["node"]=="return_share" and e["phase"]=="enter")["inputs"]["text_length"]+=1
            self.assertTrue(any(c["actual"]!=c["mapped"] for c in compare_native_calls("supplement","on",calls,bad)))
        finally:monitor.probe.close()

    def test_legacy_sqlite_upgrade_preserves_rows_and_blobs(self):
        legacy=Store(Path(self.temp.name)/"legacy")
        metadata.create_all(legacy.engine)
        try:
            with closing(sqlite3.connect(legacy.database)) as connection:
                connection.execute("DROP TABLE shares")
                connection.execute("CREATE TABLE shares (id VARCHAR PRIMARY KEY, file_id VARCHAR NOT NULL REFERENCES files(id), owner_id VARCHAR NOT NULL REFERENCES users(id), recipient_id VARCHAR NOT NULL REFERENCES users(id), reviewer_id VARCHAR NOT NULL REFERENCES users(id), state VARCHAR NOT NULL CHECK (state IN ('pending','approved','rejected','cancelled','revoked')), revision INTEGER NOT NULL, created_at VARCHAR NOT NULL)")
                for actor in ["owner","recipient","reviewer"]:connection.execute("INSERT INTO users VALUES (?,?,?)",(actor,actor,"preserved-hash"))
                connection.execute("INSERT INTO files VALUES ('legacy-file','owner','legacy.txt',6,'legacy-time')")
                connection.execute("INSERT INTO shares VALUES ('legacy-share','legacy-file','owner','recipient','reviewer','approved',2,'legacy-time')")
                connection.execute("INSERT INTO notifications VALUES ('old-notice','owner','legacy-share','review_result','approved','legacy.txt',0,'legacy-time')")
                connection.execute("INSERT INTO journal VALUES ('old-event','legacy-share',2,'approve','pending','approved','{}','legacy-time')")
                connection.commit()
            (legacy.blobs/"legacy-file").write_bytes(b"legacy")
            legacy.initialize()
            with closing(sqlite3.connect(legacy.database)) as connection:
                self.assertEqual(connection.execute("SELECT state,revision,return_reason,supplement_text FROM shares").fetchone(),("approved",2,"",""))
                self.assertEqual(connection.execute("SELECT count(*) FROM notifications").fetchone()[0],1)
                self.assertEqual(connection.execute("SELECT count(*) FROM journal").fetchone()[0],1)
                self.assertEqual(connection.execute("PRAGMA foreign_key_check").fetchall(),[])
            legacy.initialize()
            self.assertEqual((legacy.blobs/"legacy-file").read_bytes(),b"legacy")
        finally:legacy.engine.dispose()
