"""Real return boundaries, producer health, recording settlement and drive witnesses."""

from copy import deepcopy
from contextlib import ExitStack
from concurrent.futures import ThreadPoolExecutor
from http.client import HTTPConnection, HTTPResponse
import hashlib
import json
from pathlib import Path
import queue
import shutil
import socket
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/"observer_runtime")]

from app.storage import Store
from app.service import Service
from app.web import create_app
from integrations.bo_monitor import BOMonitor
from bo_observer.observation.session import GraphSession
from bo_observer.service import make_server
from bo_observer.web import bo_web as design_web
from bo_observer.workflow.sync_verify import assess_probe_health
from bo_observer.graph.behavior_model import capture,check
from bo_stategraph import BOStateGraph
from tooling.http_probe_regression import exercise_http_errors
from tooling.observe import run_case


class ObservationTests(unittest.TestCase):
    def setUp(self):
        self.project=json.loads((ROOT/"bo_stategraph/project.json").read_text(encoding="utf-8"))
        self.build_id=capture(ROOT,self.project["model"])["build_id"]

    def test_real_http_errors_close_and_keep_actual_status_fields(self):
        with tempfile.TemporaryDirectory(prefix="http-check-",dir=ROOT/"review") as directory:
            result=exercise_http_errors(self.project,self.build_id,directory)
        self.assertTrue(result["correct_responses"])
        self.assertTrue(result["complete_return_boundaries"])
        self.assertEqual(result["probe_health"],{"errors":0,"dropped":0,"data_errors":0})
        self.assertEqual(result["download_exception_types"],["BusinessError"]*3)
        download=next(node for node in self.project["model"]["nodes"] if node["id"]=="download")
        self.assertFalse(any(state["id"].lower()=="denied" for state in download["lifecycle"]["states"]))

    def test_reported_probe_failure_is_a_mapping_failure(self):
        report=assess_probe_health({"runs":[{"case":"actual-http-errors","mode":"on","probe_health":{"errors":5,"dropped":0,"data_errors":0}}]},required=True)
        self.assertFalse(report["valid"])
        self.assertTrue(any(error.get("counter")=="errors" for error in report["errors"]))

    def test_actual_drive_frames_and_missing_transition_witness(self):
        with tempfile.TemporaryDirectory(prefix="drive-check-",dir=ROOT/"review") as directory:
            run=run_case("revoked","on",self.project,self.build_id,directory)
        snapshots=run["snapshots"]
        self.assertEqual([item["state"] for item in snapshots],["pending","approved","revoked"])
        journal=run["authority_snapshot"]["instances"][0]["journal"]
        self.assertEqual([(item["event"],item["before_state"],item["after_state"]) for item in journal],[("submit","pending","pending"),("approve","pending","approved"),("revoke","approved","revoked")])
        def replay(frames):
            graph=BOStateGraph(self.project["model"],build_id=self.build_id,mode="drive")
            results=[]
            for frame in frames:
                results.append(graph.bo_observe(frame["instance_id"],state=frame["state"],context=frame["context"],revision=frame["revision"],evidence_id=frame["evidence_id"],build_id=frame["build_id"],event=frame["event"],guards=frame["guards"],payload=frame["payload"]))
            return results
        clean=replay(snapshots)
        self.assertTrue(all(not item["errors"] and not item["missing"] for item in clean))
        corrupted=replay([snapshots[0],snapshots[-1]])
        self.assertTrue(corrupted[-1]["errors"] or corrupted[-1]["missing"])

    def test_unsynchronized_source_and_missing_return_are_detected(self):
        with tempfile.TemporaryDirectory(prefix="sensitivity-",dir=ROOT/"review") as directory:
            run=run_case("approved","on",self.project,self.build_id,directory)
        self.assertTrue(all(item["actual"]==item["mapped"] for item in run["mapping_checks"]))
        corrupted=deepcopy(run)
        target=next(event for event in corrupted["events"] if event["node"]=="download" and event["phase"]=="return")
        target["outputs"].pop("allowed")
        from bo_observer.workflow.whitebox_contract import assess
        contract=json.loads((ROOT/"whitebox.json").read_text(encoding="utf-8-sig"))
        report=assess(contract,self.project["model"],{"build_id":self.build_id,"runs":[corrupted]},self.build_id)
        self.assertTrue(report["errors"])
        with tempfile.TemporaryDirectory(prefix="source-check-",dir=ROOT/"review") as directory:
            copied=Path(directory)
            for name in self.project["model"]["source_files"]+["intent.json"]:
                destination=copied/name
                destination.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(ROOT/name,destination)
            manifest=capture(copied,self.project["model"])
            with (copied/"app/service.py").open("a",encoding="utf-8") as stream:
                stream.write("\n# Synthetic unsynchronized source change.\n")
            self.assertEqual(check(copied,self.project["model"],manifest)["status"],"stale")

    def test_recording_stop_drains_actual_producer_and_restores_capture(self):
        with tempfile.TemporaryDirectory(prefix="recording-check-",dir=ROOT/"review") as directory, ExitStack() as resources:
            copied=Path(directory)
            for name in self.project["model"]["source_files"]+["intent.json","bo_stategraph/project.json"]:
                destination=copied/name
                destination.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(ROOT/name,destination)
            session=GraphSession(copied)
            def sink(body,kind):
                session.event(body) if kind=="events" else session.snapshot(body)
            monitor=BOMonitor(self.project,self.build_id,sink=sink)
            session.bo_bind_capture(scope_setter=monitor.probe.bo_set_scope,flush_capture=lambda:monitor.probe.flush(30),health=monitor.bo_health)
            store=Store(copied/"application-data",monitor)
            resources.callback(store.engine.dispose)
            resources.callback(session.close)
            resources.callback(monitor.probe.close)
            store.initialize()
            service=Service(store,self.project,ROOT)
            file=service.upload("owner","recording.txt",b"Recording boundary test")
            share=service.request_share("owner",file["id"],"recipient","reviewer")
            client=create_app(service).test_client()
            with client.session_transaction() as cookie:
                cookie["user"]={"id":"reviewer","name":"Zhou"}
            session.recordings.start("approval and final HTTP 404")
            service.change_share("reviewer",share["id"],"approve")
            self.assertEqual(client.get("/download/missing-file").status_code,404)
            before=store.snapshot(self.build_id)
            stopped=session.recordings.stop()  # No test-side flush before stop.
            recording=session.recordings.get(stopped["id"])
            self.assertTrue(recording["producer_settlement"]["flushed"])
            self.assertEqual(recording["gaps"],[])
            self.assertEqual(monitor.bo_health()["pending"],0)
            self.assertTrue(any(event["node"]=="http_download" and event["phase"]=="return" and event["outputs"]["status"]==404 for event in recording["events"]))
            self.assertEqual(len(recording["events"]),recording["end_seq"]-recording["start_seq"])
            second=service.request_share("owner",file["id"],"other","reviewer")
            session.recordings.start("selected approval",{"mode":"focused","roots":["review"]})
            service.change_share("reviewer",second["id"],"approve")
            focused=session.recordings.get(session.recordings.stop()["id"])
            self.assertEqual({event["node"] for event in focused["events"]},{"review"})
            self.assertEqual(len(focused["events"]),4)
            self.assertIsNone(monitor.probe.bo_capture_nodes)
            before_read_only=store.snapshot(self.build_id)
            session.recordings.start("restored full download")
            self.assertEqual(service.download("recipient",file["id"])[1],b"Recording boundary test")
            full=session.recordings.get(session.recordings.stop()["id"])
            self.assertIn("download",{event["node"] for event in full["events"]})
            self.assertTrue(any(event["node"].startswith("policy:") for event in full["events"]))
            self.assertEqual(full["gaps"],[])
            self.assertEqual(monitor.bo_health()["errors"],0)
            self.assertEqual(monitor.bo_health()["data_errors"],0)
            self.assertEqual(store.snapshot(self.build_id),before_read_only)
            loop_file=service.upload("owner","supplement-recording.txt",b"Supplement recording loop")
            loop_share=service.request_share("owner",loop_file["id"],"recipient","reviewer")
            session.recordings.start("two actual supplementation rounds")
            private_texts=["First private return reason","First private owner explanation","Latest private return reason","Latest private owner explanation"]
            service.return_share("reviewer",loop_share["id"],private_texts[0])
            service.resubmit_share("owner",loop_share["id"],private_texts[1])
            service.return_share("reviewer",loop_share["id"],private_texts[2])
            service.resubmit_share("owner",loop_share["id"],private_texts[3])
            latest=service.supplement_details("owner",loop_share["id"])
            self.assertEqual((latest["return_reason"],latest["supplement_text"]),tuple(private_texts[2:]))
            before_loop_stop=store.snapshot(self.build_id)
            loop=session.recordings.get(session.recordings.stop()["id"])  # Stop drains the real producer.
            self.assertTrue(loop["producer_settlement"]["flushed"])
            self.assertEqual(loop["gaps"],[])
            frames=[frame for frame in loop["runtime_frames"]["frames"] if frame["authority"]["entity"]==loop_share["id"] and frame["revision"]>=2]
            frames.sort(key=lambda frame:frame["revision"])
            self.assertEqual([frame["machine"]["current"] for frame in frames],["awaiting_supplement","pending","awaiting_supplement","pending"])
            transitions=[frame["machine"]["journal"][0] for frame in frames]
            self.assertEqual([item["event"] for item in transitions],["return_for_supplement","resubmit","return_for_supplement","resubmit"])
            native_journal=next(item for item in before_loop_stop["instances"] if item["instance_id"]==loop_share["id"])["journal"][1:]
            self.assertEqual([(item["source"],item["target"]) for item in transitions],[(item["before_state"],item["after_state"]) for item in native_journal])
            recorded=json.dumps({"events":loop["events"],"runtime_frames":loop["runtime_frames"],"commands":loop.get("commands",[])})
            self.assertTrue(all(text not in recorded for text in private_texts))
            self.assertEqual(store.snapshot(self.build_id),before_loop_stop)
            self.assertEqual(monitor.bo_health()["pending"],0)
            self.assertEqual(monitor.bo_health()["errors"],0)
            self.assertEqual(monitor.bo_health()["data_errors"],0)

    def test_actual_batch_sink_preserves_recording_snapshot_barriers_and_privacy(self):
        with tempfile.TemporaryDirectory(prefix="batch-recording-",dir=ROOT/"review") as directory, ExitStack() as resources:
            copied=Path(directory)
            for name in self.project["model"]["source_files"]+["intent.json","bo_stategraph/project.json"]:
                destination=copied/name
                destination.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(ROOT/name,destination)
            session=GraphSession(copied)
            monitor=BOMonitor(self.project,self.build_id,sink=session.bo_sink)
            session.bo_bind_capture(scope_setter=monitor.probe.bo_set_scope,flush_capture=lambda:monitor.probe.flush(30),health=monitor.bo_health)
            store=Store(copied/"application-data",monitor)
            resources.callback(store.engine.dispose)
            resources.callback(session.close)
            resources.callback(monitor.probe.close)
            store.initialize()
            service=Service(store,self.project,ROOT)
            file=service.upload("owner","batch-recording.txt",b"Actual local sink recording")
            share=service.request_share("owner",file["id"],"recipient","reviewer")
            self.assertIs(monitor.probe.bo_sink,session.bo_sink)
            self.assertTrue(callable(session.bo_sink.bo_accept_many))
            session.recordings.start("actual sink two supplementation rounds")
            snapshot_receipts=[]
            actual_snapshot=session.snapshot
            def witnessed_snapshot(value):
                result=actual_snapshot(value)
                snapshot_receipts.append({"instance_id":value["instance_id"],"revision":value["revision"],"evidence_id":value["evidence_id"],"receipt_seq":session.sequence})
                return result
            private_texts=["Batch first private reason","Batch first private explanation","Batch latest private reason","Batch latest private explanation"]
            with patch.object(session,"snapshot",side_effect=witnessed_snapshot), patch.object(session.bo_sink,"bo_accept_many",wraps=session.bo_sink.bo_accept_many) as batches:
                # Create a real backlog; release it immediately before the normal stop.
                with session.lock:
                    service.return_share("reviewer",share["id"],private_texts[0])
                    service.resubmit_share("owner",share["id"],private_texts[1])
                    service.return_share("reviewer",share["id"],private_texts[2])
                    service.resubmit_share("owner",share["id"],private_texts[3])
                    latest=service.supplement_details("owner",share["id"])
                    before_stop=store.snapshot(self.build_id)
                    queued=monitor.bo_health()["pending"]
                recording=session.recordings.get(session.recordings.stop()["id"])  # No pre-flush or queue-empty wait.
                batch_sizes=[len(call.args[0]) for call in batches.call_args_list]
            frames=[frame for frame in recording["runtime_frames"]["frames"] if frame["authority"]["entity"]==share["id"] and frame["revision"]>=2]
            by_id={event["id"]:event for event in recording["events"]}
            attempts=ROOT/"review/attempts"
            prior=[int(path.stem.rsplit("-",1)[-1]) for path in attempts.glob("capture-batch-sink-project-recording-*.json")]
            target=attempts/("capture-batch-sink-project-recording-"+str(max([0]+prior)+1).zfill(3)+".json")
            target.write_text(json.dumps({"kind":"isolated actual-sink project regression","recording":recording,"snapshot_receipts":snapshot_receipts,"batch_sizes":batch_sizes,"pending_before_stop":queued,"health":monitor.bo_health(),"authority_snapshot":before_stop},ensure_ascii=False),encoding="utf-8")
            self.assertGreater(queued,0)
            self.assertTrue(any(size>1 for size in batch_sizes))
            self.assertTrue(all(1<size<=16 for size in batch_sizes))
            self.assertTrue(recording["producer_settlement"]["flushed"])
            self.assertEqual(recording["status"],"stopped")
            self.assertEqual(recording["gaps"],[])
            self.assertEqual(len(recording["events"]),recording["end_seq"]-recording["start_seq"])
            self.assertEqual([frame["revision"] for frame in frames],[2,3,4,5])
            self.assertEqual([frame["machine"]["current"] for frame in frames],["awaiting_supplement","pending","awaiting_supplement","pending"])
            self.assertEqual([frame["machine"]["journal"][0]["event"] for frame in frames],["return_for_supplement","resubmit","return_for_supplement","resubmit"])
            self.assertEqual([item["revision"] for item in snapshot_receipts],[2,3,4,5])
            self.assertEqual([item["evidence_id"] for item in snapshot_receipts],[frame["event_id"] for frame in frames])
            self.assertTrue(all(item["instance_id"]==share["id"] and item["receipt_seq"]==by_id[item["evidence_id"]]["seq"] for item in snapshot_receipts))
            for frame in frames:
                event=by_id[frame["event_id"]]
                self.assertEqual((event["entity"],event["attempt"],event["revision"]),(share["id"],share["id"],frame["revision"]))
            self.assertEqual((latest["return_reason"],latest["supplement_text"]),tuple(private_texts[2:]))
            recorded=json.dumps({"events":recording["events"],"frames":recording["runtime_frames"],"commands":recording.get("commands",[]),"authority":before_stop})
            self.assertTrue(all(text not in recorded for text in private_texts))
            self.assertEqual(store.snapshot(self.build_id),before_stop)
            self.assertTrue(all(monitor.bo_health()[key]==0 for key in ["pending","errors","dropped","data_errors"]))

    def test_cold_viewer_connections_preserve_assets_without_business_events(self):
        with tempfile.TemporaryDirectory(prefix="viewer-tcp-",dir=ROOT/"review") as directory:
            copied=Path(directory)
            for name in self.project["model"]["source_files"]+["intent.json","bo_stategraph/project.json"]:
                destination=copied/name
                destination.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(ROOT/name,destination)
            assets=ROOT/"static/graph"
            expected={name:(assets/name).read_bytes() for name in ["index.html","routing-tools.vendor.js","libavoid.wasm"]}
            session=GraphSession(copied)
            server=make_server(session,port=0,assets=assets)
            started,release=threading.Barrier(17),threading.Event()
            connections=queue.Queue()
            def request_asset(index):
                started.wait(timeout=5)
                try:
                    connection=socket.create_connection(server.server_address,timeout=1)
                except OSError as error:
                    connections.put(str(error))
                    return None
                connections.put(None)
                with connection:
                    if not release.wait(5):
                        raise TimeoutError("The test did not start its isolated server")
                    name=tuple(expected)[index%len(expected)]
                    connection.settimeout(5)
                    connection.sendall((f"GET /{name} HTTP/1.0\r\nHost: 127.0.0.1:{server.server_port}\r\n\r\n").encode("ascii"))
                    response=HTTPResponse(connection)
                    response.begin()
                    return name,response.status,response.read()
            thread=threading.Thread(target=server.serve_forever,daemon=True)
            try:
                with ThreadPoolExecutor(max_workers=16) as pool:
                    pending=[pool.submit(request_asset,index) for index in range(16)]
                    started.wait(timeout=5)
                    # Exercise the real cold listen queue before scheduling accepts.
                    connected=[connections.get(timeout=5) for _ in pending]
                    thread.start()
                    release.set()
                    responses=[future.result(timeout=10) for future in pending]
                errors=[error for error in connected if error]
                exact=sum(result is not None and result[1]==200 and result[2]==expected[result[0]] for result in responses)
                evidence={"kind":"isolated real cold TCP burst against actual viewer assets","connections":16,"connection_errors":errors,"exact_resource_responses":exact,"resources":{name:{"size":len(content),"sha256":hashlib.sha256(content).hexdigest()} for name,content in expected.items()},"runtime_events":session.sequence,"history_events":len(session.current_events()),"collector_errors":session.errors,"collector_gaps":session.gaps}
                attempts=ROOT/"review/attempts"
                prior=[int(path.stem.rsplit("-",1)[-1]) for path in attempts.glob("capture-viewer-backlog-cold-tcp-*.json")]
                target=attempts/("capture-viewer-backlog-cold-tcp-"+str(max([0]+prior)+1).zfill(3)+".json")
                target.write_text(json.dumps(evidence,indent=2)+"\n",encoding="utf-8")
                self.assertEqual(errors,[],"Cold viewer connections overflowed the real listen queue")
                self.assertEqual(exact,16)
                self.assertEqual(session.sequence,0)
                self.assertEqual(session.current_events(),[])
                self.assertEqual((session.errors,session.gaps),(0,0))
            finally:
                release.set()
                if thread.is_alive():
                    server.shutdown()
                    thread.join(timeout=5)
                server.server_close()
                session.close()

    def test_native_http_preserves_text_json_and_binary_mime(self):
        with tempfile.TemporaryDirectory(prefix="viewer-mime-",dir=ROOT/"review") as directory:
            copied=Path(directory)
            for name in self.project["model"]["source_files"]+["intent.json","bo_stategraph/project.json"]:
                destination=copied/name
                destination.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(ROOT/name,destination)
            assets=copied/"mime-assets"
            assets.mkdir()
            expected={
                "index.html":((ROOT/"static/graph/index.html").read_bytes(),{"text/html; charset=utf-8"}),
                "routing-tools.vendor.js":((ROOT/"static/graph/routing-tools.vendor.js").read_bytes(),{"text/javascript; charset=utf-8","application/javascript; charset=utf-8"}),
                "libavoid.wasm":((ROOT/"static/graph/libavoid.wasm").read_bytes(),{"application/wasm"}),
                "opaque.bin":(b"\x00\xff\x80\xfeMIME\x00",{"application/octet-stream"}),
                "message.txt":("MIME \u6d88\u606f".encode("utf-8"),{"text/plain; charset=utf-8"}),
                "sample.json":(b'{"message":"UTF-8 JSON"}',{"application/json; charset=utf-8"}),
                "icon.svg":(b'<svg xmlns="http://www.w3.org/2000/svg"><title>MIME</title></svg>',{"image/svg+xml; charset=utf-8"}),
            }
            for name,(body,_) in expected.items():
                (assets/name).write_bytes(body)
            session=GraphSession(copied)
            server=make_server(session,port=0,assets=assets)
            thread=threading.Thread(target=server.serve_forever,daemon=True)
            connection=HTTPConnection("127.0.0.1",server.server_port,timeout=5)
            results=[]
            try:
                thread.start()
                for name,(body,types) in expected.items():
                    connection.request("GET","/"+name)
                    response=connection.getresponse()
                    received=response.read()
                    results.append({"surface":"runtime","path":"/"+name,"status":response.status,"content_type":response.getheader("Content-Type"),"expected_types":sorted(types),"size":len(received),"sha256":hashlib.sha256(received).hexdigest(),"expected_sha256":hashlib.sha256(body).hexdigest(),"exact_bytes":received==body,"content_length":response.getheader("Content-Length"),"nosniff":response.getheader("X-Content-Type-Options")})
                connection.request("GET","/api/bo/health")
                response=connection.getresponse()
                body=response.read()
                health=json.loads(body.decode("utf-8"))
                results.append({"surface":"runtime","path":"/api/bo/health","status":response.status,"content_type":response.getheader("Content-Type"),"expected_types":["application/json; charset=utf-8"],"valid_utf8_json":True,"build_id_matches":health["build_id"]==self.build_id})
                created=queue.Queue()
                design_errors=[]
                actual_server=design_web.BOHTTPServer
                def witnessed_server(*args,**kwargs):
                    actual=actual_server(*args,**kwargs)
                    created.put(actual)
                    return actual
                def serve_design():
                    try:
                        design_web.bo_serve(copied,port=0,assets=assets)
                    except BaseException as error:
                        design_errors.append(type(error).__name__+": "+str(error))
                design_thread=threading.Thread(target=serve_design,daemon=True)
                design_server=None
                design_connection=None
                with patch.object(design_web,"BOHTTPServer",side_effect=witnessed_server):
                    try:
                        design_thread.start()
                        design_server=created.get(timeout=10)
                        design_connection=HTTPConnection("127.0.0.1",design_server.server_port,timeout=5)
                        for name,(body,types) in expected.items():
                            design_connection.request("GET","/"+name)
                            response=design_connection.getresponse()
                            received=response.read()
                            results.append({"surface":"design","path":"/"+name,"status":response.status,"content_type":response.getheader("Content-Type"),"expected_types":sorted(types),"size":len(received),"sha256":hashlib.sha256(received).hexdigest(),"expected_sha256":hashlib.sha256(body).hexdigest(),"exact_bytes":received==body,"content_length":response.getheader("Content-Length"),"nosniff":response.getheader("X-Content-Type-Options")})
                        design_connection.request("GET","/api/view")
                        response=design_connection.getresponse()
                        design_view=json.loads(response.read().decode("utf-8"))
                        results.append({"surface":"design","path":"/api/view","status":response.status,"content_type":response.getheader("Content-Type"),"expected_types":["application/json; charset=utf-8"],"valid_utf8_json":True,"design_runtime_events":len(design_view["events"])})
                    finally:
                        if design_connection is not None:
                            design_connection.close()
                        if design_server is not None and design_thread.is_alive():
                            design_server.shutdown()
                        design_thread.join(timeout=5)
                evidence={"kind":"isolated native runtime and design HTTP MIME regression; deployed bytes and explicit transfer fixtures; call-through design server constructor witness","responses":results,"design_errors":design_errors,"runtime_events":session.sequence,"history_events":len(session.current_events()),"collector_errors":session.errors,"collector_gaps":session.gaps}
                attempts=ROOT/"review/attempts"
                prior=[int(path.stem.rsplit("-",1)[-1]) for path in attempts.glob("capture-viewer-mime-http-*.json")]
                target=attempts/("capture-viewer-mime-http-"+str(max([0]+prior)+1).zfill(3)+".json")
                target.write_text(json.dumps(evidence,indent=2)+"\n",encoding="utf-8")
                for item in results:
                    self.assertEqual(item["status"],200)
                    self.assertIn(item["content_type"],item["expected_types"],item["path"])
                    if "exact_bytes" in item:
                        self.assertTrue(item["exact_bytes"],item["path"])
                        self.assertEqual(int(item["content_length"]),item["size"])
                        self.assertEqual(item["nosniff"],"nosniff")
                    elif item["surface"]=="runtime":
                        self.assertTrue(item["build_id_matches"])
                    else:
                        self.assertEqual(item["design_runtime_events"],0)
                self.assertEqual(design_errors,[])
                self.assertFalse(design_thread.is_alive())
                self.assertEqual((session.sequence,len(session.current_events()),session.errors,session.gaps),(0,0,0,0))
            finally:
                connection.close()
                if thread.is_alive():
                    server.shutdown()
                    thread.join(timeout=5)
                server.server_close()
                session.close()

    def test_queue_loss_does_not_change_committed_business_effects(self):
        import time
        with tempfile.TemporaryDirectory(prefix="queue-check-",dir=ROOT/"review") as directory:
            def slow_sink(body,kind):
                time.sleep(0.01)
            monitor=BOMonitor(self.project,self.build_id,sink=slow_sink,capacity=1)
            store=Store(directory,monitor)
            store.initialize()
            service=Service(store,self.project,ROOT)
            file=service.upload("owner","queue.txt",b"Queue-limited business result")
            share=service.request_share("owner",file["id"],"recipient","reviewer")
            service.change_share("reviewer",share["id"],"approve")
            self.assertEqual(service.download("recipient",file["id"])[1],b"Queue-limited business result")
            snapshot=store.snapshot(self.build_id)
            self.assertEqual(snapshot["instances"][0]["state"],"approved")
            self.assertEqual(len(snapshot["messages"]),6)
            self.assertGreater(monitor.bo_health()["dropped"],0)
            monitor.probe.close()
            store.engine.dispose()


if __name__=="__main__":
    unittest.main()
