"""Record the reviewed source dispositions for one exact current candidate."""

import argparse
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/"observer_runtime")]
from bo_observer.workflow.sync_config import config,snapshot


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--change")
    args=parser.parse_args()
    change=args.change or json.loads((ROOT/".stategraph/active.json").read_text())["change"]
    cfg=config(ROOT,"sync.json")
    current=snapshot(ROOT,cfg)
    plan=current["model"]["implementation"]
    review={"candidate_id":current["id"],"requirement_changes":{},"decisions":{
        "business":{"action":"updated","reason":"Implement the U007-U009 confirmed supplementation loop while preserving prior final-result rules, original file/actors and approved-only downloads."},
        "state_machine":{"action":"updated","reason":"The canonical drive declaration adds return/resubmit/awaiting cancellation; SQLite atomically owns state, latest text pair, state journal and directed notices."},
        "abstraction":{"action":"updated","reason":"Stable design identities map to native service methods, rule expressions, data operations and explicitly classified HTTP handlers."},
        "probes":{"action":"updated","reason":"Capture new native spans, real policy decisions, text lengths and state effects without raw private text; retain every prior probe/mode and independent case."}},"excluded_symbols":{sid:"Reviewed static implementation helper mapped to "+item["node"]+": "+item["reason"] for sid,item in plan["support"].items()}}
    (ROOT/change/"review.json").write_text(json.dumps(review,indent=2),encoding="utf-8")
    print(json.dumps({"candidate_id":current["id"],"support_dispositions":len(review["excluded_symbols"])}))
