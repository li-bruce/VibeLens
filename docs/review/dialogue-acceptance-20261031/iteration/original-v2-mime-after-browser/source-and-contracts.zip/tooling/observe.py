"""Execute real application cases and preserve independent values and public projections."""

from contextlib import closing
import sqlite3
import json
import os
from pathlib import Path
import sys
import tempfile

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/"observer_runtime")]

from bo_stategraph import BOStateGraph
from bo_observer.graph.behavior_model import capture
from app.storage import Store
from app.service import Service,BusinessError
from app.web import create_app
from integrations.bo_monitor import BOMonitor
from tooling.actual_witnesses import install_native_readers,compare_native_calls,compare_policy_reports


def machine_from(snapshot):
    return {"configurations":[{"attempt":row["instance_id"],"phase":row["state"],"state_revision":row["revision"],"revision":row["revision"],"run_build_id":row["build_id"],"source_status":"current","context":row["context"],"journal":row["journal"]} for row in snapshot["instances"]]}


def expect_denied(callback):
    try:
        callback()
    except BusinessError as error:
        assert error.status in {400,401,403,404,409}
        return error.status
    raise AssertionError("The unauthorized operation was accepted.")


def outcome_for(case):
    if case in {"rejected","selected_reviewer_rejects","rejected_download_denied","rejected_file_hidden"}:
        return "rejected"
    if case in {"cancelled","owner_cancels_pending","cancelled_request_review_denied","cancelled_file_hidden"}:
        return "cancelled"
    if case in {"revoked","owner_revokes_share","revoked_old_url_denied","revoked_stale_page_denied","revoked_file_hidden"}:
        return "revoked"
    if case in {"pending","unauthorized","unselected_reviewer_denied","ungranted_download_denied","pending_download_denied","pending_file_hidden","nonowner_cancel_denied"}:
        return "pending"
    return "approved"


SUPPLEMENT_CASES={"owner_cancels_awaiting_supplement","awaiting_approve_denied","awaiting_reject_denied","awaiting_download_denied","awaiting_file_hidden","reviewer_returns_for_supplement","unselected_return_denied","awaiting_return_denied","blank_reason_denied","overlong_reason_denied","owner_resubmits_supplement","nonowner_resubmit_denied","pending_resubmit_denied","blank_supplement_denied","overlong_supplement_denied","cancelled_resubmit_denied","owner_reads_latest_supplement","reviewer_reads_latest_supplement","recipient_supplement_hidden","other_supplement_denied","multiple_supplement_rounds","supplement_http_errors"}
REASON_ONE="First private reason"
NOTE_ONE="First private explanation"
REASON_TWO="Current private reason"
NOTE_TWO="Current private explanation"


def supplement_case(case,service,share):
    identifier=share["id"]
    if case in {"unselected_return_denied","blank_reason_denied","overlong_reason_denied","pending_resubmit_denied"}:
        if case=="pending_resubmit_denied":expect_denied(lambda:service.resubmit_share("owner",identifier,NOTE_ONE))
        else:expect_denied(lambda:service.return_share("other" if case=="unselected_return_denied" else "reviewer",identifier," " if case=="blank_reason_denied" else "x"*201 if case=="overlong_reason_denied" else REASON_ONE))
        return ("","")
    service.return_share("reviewer",identifier,REASON_ONE)
    if case in {"awaiting_approve_denied","awaiting_reject_denied"}:expect_denied(lambda:service.change_share("reviewer",identifier,"approve" if case=="awaiting_approve_denied" else "reject"))
    if case=="awaiting_return_denied":expect_denied(lambda:service.return_share("reviewer",identifier,REASON_TWO))
    if case in {"owner_cancels_awaiting_supplement","cancelled_resubmit_denied"}:
        service.change_share("owner",identifier,"cancel")
        if case=="cancelled_resubmit_denied":expect_denied(lambda:service.resubmit_share("owner",identifier,NOTE_ONE))
    if case in {"nonowner_resubmit_denied","blank_supplement_denied","overlong_supplement_denied"}:expect_denied(lambda:service.resubmit_share("other" if case=="nonowner_resubmit_denied" else "owner",identifier," " if case=="blank_supplement_denied" else "x"*201 if case=="overlong_supplement_denied" else NOTE_ONE))
    if case in {"owner_resubmits_supplement","owner_reads_latest_supplement","reviewer_reads_latest_supplement","recipient_supplement_hidden","other_supplement_denied","multiple_supplement_rounds"}:
        service.resubmit_share("owner",identifier,NOTE_ONE)
        if case=="multiple_supplement_rounds":
            service.return_share("reviewer",identifier,REASON_TWO)
            assert service.supplement_details("owner",identifier)["supplement_text"]==""
            service.resubmit_share("owner",identifier,NOTE_TWO)
            service.change_share("reviewer",identifier,"approve")
            return REASON_TWO,NOTE_TWO
        return REASON_ONE,NOTE_ONE
    return REASON_ONE,""


def run_case(case,mode,project,build_id,directory):
    events=[]
    snapshots=[]
    def sink(body,kind):
        if mode=="fault":
            raise OSError("deliberate observation failure")
        (events if kind=="events" else snapshots).append(body)
    monitor=BOMonitor(project,build_id,sink=sink,enabled=mode!="off",run_id=case+"-"+mode)
    store=Store(directory,monitor)
    store.initialize()
    service=Service(store,project,ROOT)
    actual_calls=install_native_readers(service,store,monitor)
    service.login("owner","TrialOnly!2026")
    if case=="invalid_login":
        expect_denied(lambda:service.login("owner","wrong-test-password"))
    file=service.upload("owner","trial-notes.txt",b"Synthetic trial file.\n")
    share=service.request_share("owner",file["id"],"recipient","reviewer")
    if case=="upload_anonymous_denied":
        expect_denied(lambda:service.upload("","denied.txt",b"denied"))
    if case=="nonowner_share_denied":
        expect_denied(lambda:service.request_share("other",file["id"],"recipient","reviewer"))
    if case in {"unauthorized","unselected_reviewer_denied"}:
        expect_denied(lambda:service.change_share("other",share["id"],"approve"))
    if case=="nonowner_cancel_denied":
        expect_denied(lambda:service.change_share("other",share["id"],"cancel"))
    expected_pair=supplement_case(case,service,share) if case in SUPPLEMENT_CASES else None
    state=store.snapshot(build_id)["instances"][0]["state"] if expected_pair is not None else outcome_for(case)
    if expected_pair is None and state in {"approved","revoked"}:
        service.change_share("reviewer",share["id"],"approve")
    elif expected_pair is None and state=="rejected":
        service.change_share("reviewer",share["id"],"reject")
    elif expected_pair is None and state=="cancelled":
        service.change_share("owner",share["id"],"cancel")
        if case=="cancelled_request_review_denied":
            expect_denied(lambda:service.change_share("reviewer",share["id"],"approve"))
    if case=="nonowner_revoke_denied":
        expect_denied(lambda:service.change_share("other",share["id"],"revoke"))
    if state=="revoked":
        assert service.download("recipient",file["id"])[1]==b"Synthetic trial file.\n"
        service.change_share("owner",share["id"],"revoke")
    if state=="approved":
        filename,body=service.download("recipient",file["id"])
        assert filename=="trial-notes.txt" and body==b"Synthetic trial file.\n"
        allowed=True
    else:
        assert expect_denied(lambda:service.download("recipient",file["id"]))==403
        allowed=False
    dashboard=service.dashboard("recipient")
    if state=="approved":
        message=dashboard["messages"][0]
        service.read_notification("recipient",message["id"])
    assert bool(dashboard["received"])==(state=="approved")
    application=create_app(service)
    client=application.test_client()
    def http_call(client,method,path,data=None):
        with client.session_transaction() as session:
            actor_id=session.get("user",{}).get("id","")
        node="http_application" if path.startswith("/application/") else "http_download" if path.startswith("/download/") else "http_action" if method=="POST" else "http_page" if actor_id else None
        inputs={"actor_id":actor_id,"share_id":path.rsplit("/",1)[-1]} if node=="http_application" else {"file_id":path.rsplit("/",1)[-1]} if node=="http_download" else {"action":data.get("action","")} if node=="http_action" else {"actor_id":actor_id}
        record={"node":node,"inputs":inputs,"source":"Actual HTTP request arguments and Flask response status"}
        if node:
            actual_calls.append(record)
        response=client.open(path,method=method,data=data)
        record.update(phase="return",outputs={"status":response.status_code})
        return response
    http_call(client,"GET","/")
    with client.session_transaction() as session:
        csrf=session["csrf"]
    http_call(client,"POST","/",{"action":"login","username":"recipient","password":"TrialOnly!2026","csrf":csrf})
    assert http_call(client,"GET","/").status_code==200
    response=http_call(client,"GET","/download/"+file["id"])
    assert response.status_code==(200 if state=="approved" else 403)
    if case=="http_error_paths":
        assert http_call(client,"GET","/download/missing-file").status_code==404
        anonymous=application.test_client()
        assert http_call(anonymous,"GET","/download/"+file["id"]).status_code==401
        assert http_call(client,"POST","/",{"action":"upload","csrf":"incorrect"}).status_code==303
        with client.session_transaction() as session:
            error_csrf=session["csrf"]
        assert http_call(client,"POST","/",{"action":"login","username":"recipient","password":"wrong-test-password","csrf":error_csrf}).status_code==303
    if expected_pair is not None:
        for actor in ["owner","reviewer","recipient","other"]:
            private_client=application.test_client()
            with private_client.session_transaction() as private_session:
                private_session.update(user={"id":actor,"name":actor},csrf="supplement-csrf")
            private_response=http_call(private_client,"GET","/application/"+share["id"])
            assert private_response.status_code==(200 if actor in {"owner","reviewer"} else 403)
        if case=="supplement_http_errors":
            for actor,action,field,text in [("owner","resubmit_share","explanation"," "),("reviewer","return_share","reason",REASON_TWO),("owner","resubmit_share","explanation",NOTE_ONE),("reviewer","return_share","reason",REASON_TWO)]:
                actor_client=application.test_client()
                with actor_client.session_transaction() as actor_session:actor_session.update(user={"id":actor,"name":actor},csrf="supplement-csrf")
                assert http_call(actor_client,"POST","/",{"action":action,"share_id":share["id"],field:text,"csrf":"supplement-csrf"}).status_code==303
            expected_pair=REASON_TWO,""
    with client.session_transaction() as session:
        csrf=session["csrf"]
    http_call(client,"POST","/",{"action":"logout","csrf":csrf})
    service.logout("owner")
    monitor.flush()
    authority=store.snapshot(build_id)
    row=authority["instances"][0]
    messages=authority["messages"]
    observations={"state":row["state"],"download_allowed":allowed,"recipient_visible":bool(dashboard["received"]),"review_results":sum(item["kind"]=="review_result" for item in messages),"share_messages":sum(item["kind"]=="shared" for item in messages),"file_size":len(b"Synthetic trial file.\n"),"recipient_id":"recipient"}
    if expected_pair is not None:
        with closing(sqlite3.connect(store.database)) as connection:
            connection.row_factory=sqlite3.Row
            actual=dict(connection.execute("SELECT * FROM shares WHERE id=?",(share["id"],)).fetchone())
            notice_rows=[dict(r) for r in connection.execute("SELECT * FROM notifications")]
            history_rows=[dict(r) for r in connection.execute("SELECT * FROM journal")]
        observations.update(latest_pair_correct=(actual["return_reason"],actual["supplement_text"])==expected_pair,reason_length=len(actual["return_reason"]),supplement_length=len(actual["supplement_text"]),identities_preserved=all(actual[k]==share[k] for k in ["file_id","owner_id","recipient_id","reviewer_id"]),intermediate_recipients_correct=all(n["user_id"]==("owner" if n["kind"]=="returned" else "reviewer") for n in notice_rows if n["kind"] in {"returned","resubmitted"}),return_notices=sum(n["kind"]=="returned" for n in notice_rows),resubmit_notices=sum(n["kind"]=="resubmitted" for n in notice_rows),journal_entries=len(history_rows),private_text_hidden=not any(text in json.dumps(dashboard) for text in [REASON_ONE,REASON_TWO,NOTE_ONE,NOTE_TWO]),notices_have_no_text=not any(text in json.dumps(notice_rows) for text in [REASON_ONE,REASON_TWO,NOTE_ONE,NOTE_TWO]),history_has_no_text=not any(text in json.dumps(history_rows) for text in [REASON_ONE,REASON_TWO,NOTE_ONE,NOTE_TWO]),capture_has_no_text=not any(text in json.dumps([events,snapshots]) for text in [REASON_ONE,REASON_TWO,NOTE_ONE,NOTE_TWO]))
    machine=machine_from(authority)
    graph=BOStateGraph(project["model"],build_id=build_id,mode="drive")
    projection={"build_id":build_id,"machine":machine,"instances":graph.bo_instances(machine)}
    witnesses=[{"id":"state-"+case+"-"+mode,"source":"Independent SQLite Store.snapshot","projection":["state"],"actual":row["state"],"mapped":projection["instances"][0]["observed"]["state"]}]
    if mode=="on":
        witnesses+=compare_native_calls(case,mode,actual_calls,events)
        witnesses+=compare_policy_reports(case,mode,list(monitor.evaluations),events)
    run={"case":case,"mode":mode,"events":events,"snapshots":snapshots,"observations":observations,"authority_snapshot":authority,"projection":projection,"policy_evaluations":list(monitor.evaluations),"mapping_checks":witnesses,"probe_health":monitor.bo_health(),"loaded_definition":service.machine,"native_call_count":len(actual_calls)}
    monitor.probe.close()
    store.engine.dispose()
    return run


def main():
    os.environ["TRIAL_DATABASE_URL"]="sqlite:///"+(ROOT/"data/application.sqlite3").as_posix()
    project=json.loads((ROOT/"bo_stategraph/project.json").read_text(encoding="utf-8"))
    manifest=capture(ROOT,project["model"])
    contract=json.loads((ROOT/"mapping.json").read_text(encoding="utf-8"))
    output={"build_id":manifest["build_id"],"machine":project["model"]["machine"],"runs":[]}
    for case in contract["cases"]:
        for mode in contract["modes"]:
            with tempfile.TemporaryDirectory(prefix="case-",dir=ROOT/"review") as directory:
                run=run_case(case,mode,project,manifest["build_id"],directory)
                output["runs"].append(run)
    selected=next(run for run in output["runs"] if run["case"]=="approved" and run["mode"]=="on")
    graph=BOStateGraph(project["model"],build_id=manifest["build_id"],mode="drive")
    output["stategraph_export"]=graph.bo_export(runtime={"machine":selected["projection"]["machine"]})
    output["mapping_checks"]=[check for run in output["runs"] for check in run["mapping_checks"]]
    attempts=ROOT/"review/attempts"
    prior=[int(path.stem.rsplit("-",1)[-1]) for path in attempts.glob("observations-*.json")]
    target=attempts/("observations-"+str(max([1]+prior)+1).zfill(3)+".json")
    target.write_text(json.dumps(output,ensure_ascii=False),encoding="utf-8")
    (ROOT/"review/latest-observation.json").write_text(json.dumps({"path":target.relative_to(ROOT).as_posix(),"build_id":manifest["build_id"]},indent=2),encoding="utf-8")
    print(json.dumps(output,ensure_ascii=False))


if __name__=="__main__":
    main()
