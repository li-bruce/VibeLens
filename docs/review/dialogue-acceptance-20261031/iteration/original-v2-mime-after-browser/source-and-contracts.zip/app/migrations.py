"""Preserve existing rows while extending SQLite's sharing-state constraint."""

import re

from sqlalchemy.schema import CreateTable
from app.models import shares


def migrate_supplementation(engine):
    """Rebuild only the old sharing table in one transaction; retain foreign keys."""
    connection = engine.raw_connection()
    try:
        connection.commit()
        columns = [row[1] for row in connection.execute("PRAGMA table_info(shares)")]
        original = connection.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='shares'").fetchone()[0]
        if {"return_reason", "supplement_text"} <= set(columns) and "awaiting_supplement" in original:
            return False
        if set(columns) - set(shares.c.keys()):
            raise ValueError("Unknown sharing columns require an explicit migration")
        definition = str(CreateTable(shares).compile(dialect=engine.dialect))
        upgraded = re.sub(r"CREATE TABLE shares\b", "CREATE TABLE shares_supplement_upgrade", definition, count=1)
        if upgraded == definition:
            raise ValueError("Unsupported sharing table DDL")
        connection.execute("PRAGMA foreign_keys=OFF")
        connection.execute("BEGIN IMMEDIATE")
        connection.execute(upgraded)
        names = ",".join('"' + column + '"' for column in columns)
        connection.execute("INSERT INTO shares_supplement_upgrade (" + names + ") SELECT " + names + " FROM shares")
        connection.execute("DROP TABLE shares")
        connection.execute("ALTER TABLE shares_supplement_upgrade RENAME TO shares")
        if connection.execute("PRAGMA foreign_key_check").fetchall():
            raise ValueError("Migration would violate existing foreign keys")
        connection.commit()
        return True
    except BaseException:
        connection.rollback()
        raise
    finally:
        connection.execute("PRAGMA foreign_keys=ON")
        connection.close()
