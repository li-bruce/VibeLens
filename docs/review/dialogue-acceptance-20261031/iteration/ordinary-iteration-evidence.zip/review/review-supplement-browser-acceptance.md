# Independent browser acceptance handoff

Status: pending independent execution. Scripted HTTP/service/recording checks do
not establish browser or human acceptance. Use the accepted build and verified
URLs in `handoff-review-supplement.json` once that file is written.

1. Confirm both health endpoints and the graph's binding report the accepted
   build. Reuse existing accounts and preserve personal graph layouts.
2. With a dedicated synthetic file, submit a sharing application to an existing
   recipient and selected reviewer. Start a real recording before the reviewer
   returns it with a required reason. Confirm the owner alone receives an
   intermediate application notice; the recipient has no access.
3. Open the application as owner: see the latest reason and submit a required
   explanation. Confirm only the original reviewer receives the resubmission
   notice. Both intermediate notices contain an application pointer, not text.
4. Repeat the return/resubmit loop. The new return replaces the old reason and
   clears the previous explanation; the new submission fills the current pair.
   Only the owner and original reviewer can open that text. Verify blank and
   over-200-character input, and direct recipient access denial through HTTP.
5. While awaiting supplementation, verify the reviewer cannot approve/reject or
   return again. Exercise owner cancellation on a separate application. After
   resubmission, approve or reject the original application. Final result notices
   still reach all involved parties; approval also sends sharing notices. Only
   approved sharing grants recipient listing/download, and revocation denies a
   subsequent request to an old download URL.
6. Stop recording through the actual control without pre-flushing the producer.
   Inspect settlement, gaps, producer/data counters and saved runtime frames.
   Compare the four loop transitions with the authoritative journal; inspect
   native evaluated guards via the mapped evidence. Private text must not occur
   in events, state frames, notices or the state-only history. Recording and
   replay controls themselves must not write business data.
7. Reload the graph and inspect the changed region in the full view and local
   focus. Preserve stable node/relation IDs, saved 2D/3D layouts and explicit
   boundaries. Obsolete-build recordings should not appear as current evidence;
   all six original recording files must remain byte-identical on disk.

Record actual operations, responses, recording IDs, frame comparisons and any
failure separately. A graph URL, a queued panel, a stopped raw recording, or a
successful isolated replay alone is not independent acceptance of this build.
