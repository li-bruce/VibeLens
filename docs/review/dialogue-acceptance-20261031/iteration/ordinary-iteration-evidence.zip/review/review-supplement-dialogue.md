# Review supplementation iteration dialogue

## Provenance and accepted starting point

This is a new simulated-user business iteration supplied by the test coordinator
in this same development conversation. It is trial input, not human production
acceptance. The originating coordinator conversation is
`01a1439a-dceb-7ba2-bada-546619caf220`; no other conversation was contacted.

The starting point is accepted change `.stategraph/capture-byte-identity`,
candidate `ae9cedf4681ef270aeadba5e1800633d76e65ef0925c8dea25795ae2e7f32fe6`,
build `22f404fa1a87c3da3dd442beadd03669ed3e3feff692be26948efd431ca8b7e9`.
The prior accepted baselines, failed recordings, independent expectations and
managed runtime are preserved. The existing drive mode, owner-selected reviewer,
three-party review-result notices and approved-only access remain adopted rules.
The previous full browser recording/timeline acceptance status is not changed
by this new feature request.

## U007 — actual simulated-user request

> 【模拟用户，本轮业务迭代】
> 审核的时候有时资料不够。我想让审核人把共享申请退回给文件主人补充说明，主人补好后，再交回原来的审核人继续处理。

Supplied meaning: the reviewer may return the current sharing application to
its owner for explanatory supplementation; the owner submits it back to the
same reviewer for continued handling. The existing application and reviewer
identity are retained. A distinct awaiting-supplementation state is a candidate
representation, pending reconciliation and graph confirmation.

## A007 — actual clarification batch

1. 这轮“补充说明”按文字处理：审核人退回时的原因、主人重新提交时的补充说明，是否都必须填写？
   Suggested choices: 两者都必填 / 只要求补充说明必填 / 两者都可留空.
2. 申请处于“待补充”时，主人是否仍可取消？审核人是否必须等主人重新提交后，才能再次通过或驳回？
   Suggested choices: 主人可取消；重新提交后才能审核 / 主人不可取消；重新提交后才能审核 / 主人可取消；待补充时也能审核.
3. 是否允许多轮退回补充？退回／重新提交的通知，以及保留的各轮原因和说明，是否都给文件主人、原审核人、接收成员三方查看？

The questions were sent with the conversation's asynchronous user-input tool.
At that point all answers were pending; suggested choices were not answers.
The later actual supplied answers are retained below as U008.

## U008 — actual simulated-user answers

> 【模拟用户答复】
> 两种文字都必填，各不超过200字。待补充时主人可以取消，审核人要等主人重新提交后才能继续审核。
> 可以多轮退回，但现在只保存最新一次的退回原因和补充说明，原来的状态变更记录照旧。
> 退回时只通知主人，重新提交时只通知原审核人；这些原因和补充说明也只给主人和该审核人看。接收成员仍只收到最终审核结果和通过后的共享消息，最终结果继续通知三方。
> 本轮只补文字，文件、接收成员和审核人都保持原样。

These simulated answers resolve text requiredness/limits, waiting permissions,
repeat rounds, latest-only text storage, visibility and notification recipients.
Only final approval/rejection results retain the earlier three-party result
notification rule. Return/resubmit notices and explanation text have their
explicitly narrower recipients. The existing six decisions and their previous
resolutions are unchanged; new decisions distinguish the additional scope.
The canonical source ID for A007 in this file is `A_SUPPLEMENT_QUESTIONS`, avoiding
any confusion with the separate initial design dialogue's historical A007.

New-scope graph confirmation remains open as `D_SUPPLEMENT_GRAPH_CONFIRM`.

## Preparation and implementation boundary

Read-only inspection found the current pending/approved/rejected/cancelled/revoked
state constraint, the native declaration, reviewer queue filtering, sharing
transition service, notification creation, and HTTP dispatch as affected areas.
Adding a persisted state will require a data-preserving schema migration; model
metadata alone cannot alter the existing SQLite check constraint. This is a
technical observation, not an adopted business rule or completed migration.

The `review-supplement` change begins from the accepted inputs before any
business, discovery, declaration, expectation or probe edits. Business questions
may remain open at this point. After actual answers, reconcile their source
records, preserve previous decisions, update the same stable-ID business graph,
present its canonical preview and verified URL, and obtain scope confirmation
before implementing behavior. No business or recording operations, service
restart, schema migration or behavior implementation were performed in this
clarification stage.

## U009 — actual simulated graph confirmation

> 【模拟用户确认】
> 这张流程图是对的，可以按此实现。只保留最新的一组文字；退回和重提通知只提示需要处理哪份申请，具体原因和说明在申请中查看。原有最终结果和共享消息的范围照旧。

Graph scope is now confirmed. The latest pair replaces prior-round text; intermediate notices contain only an application pointer. This is trial authorization, not production acceptance.

## U010 — delayed actual question-tool reply

The delayed reply to A_SUPPLEMENT_QUESTIONS was: `两者都必填`; `主人可取消；重新提交后才能审核`; `是`.
The last answer addressed a compound question about repeat rounds, historical text and three-party visibility/notices. It contradicted the more detailed U008/U009 rules, so it was not silently applied.

## A010 — actual reconciliation question

> 第三项“是”是否要修改此前已确认的细则？此前是：只存最新一组文字，仅主人和原审核人可见；退回只通知主人，重提只通知原审核人；最终结果仍通知三方。请确认本轮采用哪套规则。

## U011 — actual reconciliation answer

> 沿用上述已确认细则

This explicitly retains U008/U009. No business graph, notice recipient, retention or visibility rule changes. All prior sources and complete decision versions remain recorded. These in-conversation replies remain trial evidence, not independent human production acceptance.
