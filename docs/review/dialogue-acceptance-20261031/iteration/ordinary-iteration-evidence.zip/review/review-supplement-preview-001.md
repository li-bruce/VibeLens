# Business network draft

```mermaid
flowchart LR
  n0["待补充（暂停审核）"]
  n1["主人取消待审核申请"]
  n2["已取消：不授予权限"]
  n3["等待审核（接收方不可见）"]
  n4["只通知原审核人"]
  n5["主人补充并重新提交"]
  n6["只通知文件主人"]
  n7["原审核人退回补充"]
  n8["主人指定的审核人审核"]
  n9["最新原因和说明（仅双方可见）"]
  n5 -->|"替换最新补充说明"| n9
  n7 -->|"替换最新退回原因"| n9
  n9 -->|"仅主人查看"| n5
  n9 -->|"仅原审核人查看"| n8
  n0 -->|"仅主人补充，必填且最多200字"| n5
  n8 -->|"资料不足，原审核人填写原因"| n7
  n5 -->|"重新提交成功"| n4
  n7 -->|"退回成功"| n6
  n0 -->|"主人可取消"| n1
  n1 -->|"结束待审核申请"| n2
  n3 -->|"主人可取消"| n1
  n3 -->|"所选审核人处理"| n8
  n5 -->|"同一申请；文件、接收方及审核人不变"| n3
  n7 -->|"原因必填，最多200字"| n0
  b0["通过并授予下载权限 (outside scope)"]
  n8 -.->|"通过"| b0
  b1["已驳回（接收方不可见） (outside scope)"]
  n8 -.->|"驳回"| b1
  b2["主人选择接收方及审核人 (outside scope)"]
  b2 -.->|"提交申请"| n3
  b3["OR · 主人可取消待审核或待补充申请 (outside scope)"]
  b3 -.->|"Requires"| n1
  b4["AND · 主人填写有效说明后重新提交 (outside scope)"]
  b4 -.->|"Requires"| n5
  b5["AND · 原审核人填写有效原因后退回 (outside scope)"]
  b5 -.->|"Requires"| n7
  b6["AND · 所选审核人处理待审核申请 (outside scope)"]
  b6 -.->|"Requires"| n8
  b7["OR · 仅文件主人或原审核人查看说明 (outside scope)"]
  b7 -.->|"Requires"| n9
```

[Open the live graph](http://127.0.0.1:59739/graph)

This is a focused view. Dashed boundaries retain original relations; open Web for the complete graph.

Still to confirm:

- 请确认新增的退回补充业务图是否符合上述答复，可以按此实现？

Confirm this understanding in the conversation, or describe a correction. Viewing the graph is not confirmation.
