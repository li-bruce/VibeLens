# Review supplementation business-flow detail

Derived from `review-supplement-preview-002.json` with the same business IDs and original relations. This conversation view shows the business flow; latest-text data and rule-network dependencies remain in the canonical full graph. Dashed approval/rejection branches are original boundaries. No execution is claimed.

```mermaid
flowchart LR
  pending["等待审核（接收方不可见）"]
  review["主人指定的审核人审核"]
  return_share["原审核人退回补充"]
  awaiting_supplement["待补充（暂停审核）"]
  resubmit_share["主人补充并重新提交"]
  return_notice["只通知文件主人"]
  resubmit_notice["只通知原审核人"]
  cancel_share["主人取消申请"]
  cancelled["已取消：不授予权限"]
  awaiting_supplement -->|"仅主人补充，必填且最多200字"| resubmit_share
  review -->|"资料不足，原审核人填写原因"| return_share
  resubmit_share -->|"重新提交成功"| resubmit_notice
  return_share -->|"退回成功"| return_notice
  awaiting_supplement -->|"主人可取消"| cancel_share
  cancel_share -->|"结束申请"| cancelled
  pending -->|"主人可取消"| cancel_share
  pending -->|"所选审核人处理"| review
  resubmit_share -->|"同一申请；文件、接收方及审核人不变"| pending
  return_share -->|"原因必填，最多200字"| awaiting_supplement
  granted["通过并授予下载权限"]
  review -.->|"通过"| granted
  rejected["已驳回（接收方不可见）"]
  review -.->|"驳回"| rejected
```

[Full design graph](http://127.0.0.1:59739/graph)

Required reason and explanation are at most 200 characters each. Only owner and original reviewer can read the latest text. Intermediate notices are owner-only on return and original-reviewer-only on resubmit. Final approval/rejection and approval sharing messages retain the prior three-party recipients. Repeated rounds preserve the file, recipient, reviewer and application. State-change history remains.
