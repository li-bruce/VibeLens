import {fileURLToPath} from 'node:url';
import { AvoidLib } from './node_modules/libavoid-js/dist/index-node.mjs';
console.log('before load');
try { await AvoidLib.load(fileURLToPath(new URL('./node_modules/libavoid-js/dist/libavoid.wasm',import.meta.url))); console.log('loaded'); } catch(e) { console.log('load error',String(e)); }
