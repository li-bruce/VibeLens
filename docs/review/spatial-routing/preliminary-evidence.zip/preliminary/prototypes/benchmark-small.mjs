import {createServer} from 'node:http';
import {readFile,writeFile} from 'node:fs/promises';
import {createRequire} from 'node:module';
const {chromium}=createRequire(import.meta.url)('playwright');
const server=createServer(async(req,res)=>{try{const name=req.url.slice(1)||'smoke.html';const data=await readFile(new URL(name,import.meta.url));res.writeHead(200,{'content-type':name.endsWith('.wasm')?'application/wasm':name.endsWith('.js')?'text/javascript':'text/html'});res.end(data);}catch{res.writeHead(404);res.end();}});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
const browser=await chromium.launch({headless:true,executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe'});
try{const page=await browser.newPage();page.on('console',m=>console.log(m.text().slice(0,300)));page.on('pageerror',m=>console.log(String(m).slice(0,500)));await page.goto('http://127.0.0.1:'+server.address().port+'/');await page.waitForFunction(()=>window.done,{timeout:15000});console.log(JSON.stringify(await page.evaluate(()=>({result,error}))));
for (const count of [8,32,128]) {
 const result=await Promise.race([page.evaluate(async(count)=>{
  const {AvoidLib}=await import('./node_modules/libavoid-js/dist/index.js');const A=AvoidLib.getInstance(); const r=new A.Router(A.OrthogonalRouting);const p=(x,y)=>new A.Point(x,y); const cols=Math.ceil(Math.sqrt(count));const xy=i=>({x:(i%cols)*100,y:Math.floor(i/cols)*100});const start=performance.now();
  for(let i=0;i<count;i++){const q=xy(i);new A.ShapeRef(r,new A.Rectangle(p(q.x,q.y),35,35));}
  const cons=[];
  for(let i=0;i<1;i++)for(let k=1;k<=1;k++){const a=xy(i),b=xy((i+k*3)%count);cons.push(new A.ConnRef(r,new A.ConnEnd(p(a.x+23,a.y)),new A.ConnEnd(p(b.x-23,b.y))));}
  r.setRoutingParameter(A.segmentPenalty,20);r.setRoutingParameter(A.shapeBufferDistance,3);r.setRoutingOption(A.nudgeSharedPathsWithCommonEndPoint,false);r.setRoutingOption(A.nudgeOrthogonalSegmentsConnectedToShapes,false);r.setRoutingOption(A.performUnifyingNudgingPreprocessingStep,false);r.setRoutingOption(A.nudgeOrthogonalTouchingColinearSegments,false);const init=performance.now();r.processTransaction();const elapsed=performance.now()-init; const q=cons[0].displayRoute();const result={count,edges:cons.length,create: init-start,solve:elapsed,points:q.size()};A.destroy(r);return result;
 },count),new Promise((_,reject)=>setTimeout(()=>reject(Error('routing deadline')),25000))]);console.log(JSON.stringify(result));
}
}finally{await browser.close();server.close();}
