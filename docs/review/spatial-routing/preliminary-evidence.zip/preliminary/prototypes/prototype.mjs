import {fileURLToPath} from "node:url";
import { AvoidLib } from './node_modules/libavoid-js/dist/index-node.mjs';
await AvoidLib.load(fileURLToPath(new URL('./node_modules/libavoid-js/dist/libavoid.wasm',import.meta.url)));
const A=AvoidLib.getInstance();
console.log('API',Object.keys(A).filter(k=>/Polygon|Shape|Conn|nudge|Cluster/.test(k)).join(','));
const router=new A.Router(A.OrthogonalRouting);
const point=(x,y)=>new A.Point(x,y);
const rect=(x,y,w,h)=>new A.Rectangle(point(x,y),w,h);
const shapes=[new A.ShapeRef(router,rect(0,0,40,40)),new A.ShapeRef(router,rect(100,0,40,80)),new A.ShapeRef(router,rect(200,0,40,40))];
const conn=new A.ConnRef(router,new A.ConnEnd(point(28,0)),new A.ConnEnd(point(172,0)));
router.setRoutingParameter(A.shapeBufferDistance,4);
router.processTransaction();
let p=conn.displayRoute();console.log('route',Array.from({length:p.size()},(_,i)=>{const q=p.get_ps(i);return[q.x,q.y]}));
console.log('polygon',Object.getOwnPropertyNames(A.Polygon.prototype));
A.destroy(router);

