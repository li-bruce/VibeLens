import {createServer} from 'node:http';
import {readFile,writeFile} from 'node:fs/promises';
import {createRequire} from 'node:module';
const {chromium}=createRequire(import.meta.url)('playwright');
const server=createServer(async(req,res)=>{try{const name=req.url.slice(1)||'smoke.html';const data=await readFile(new URL(name,import.meta.url));res.writeHead(200,{'content-type':name.endsWith('.wasm')?'application/wasm':name.endsWith('.js')?'text/javascript':'text/html'});res.end(data);}catch{res.writeHead(404);res.end();}});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
const browser=await chromium.launch({headless:true,executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe'});
try{const page=await browser.newPage();page.on('console',m=>console.log(m.text().slice(0,300)));page.on('pageerror',m=>console.log(String(m).slice(0,500)));await page.goto('http://127.0.0.1:'+server.address().port+'/');await page.waitForFunction(()=>window.done,{timeout:15000});console.log(await page.evaluate(()=>({result,error})));}finally{await browser.close();server.close();}
