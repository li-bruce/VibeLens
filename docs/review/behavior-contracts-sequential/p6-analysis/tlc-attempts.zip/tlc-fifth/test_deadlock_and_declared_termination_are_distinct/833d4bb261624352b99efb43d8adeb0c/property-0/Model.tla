---- MODULE Model ----
EXTENDS Integers, Sequences, FiniteSets
VARIABLES V0, V1, VLStep, VLCheck
physical == <<V0, V1>>
vars == <<V0, V1, VLStep, VLCheck>>
Type0 == V0 \in {"s696e616374697665", "s616374697665"}
Type1 == V1 \in {"s696e616374697665", "s616374697665"}
Init ==
  /\ Type0
  /\ Type1
  /\ ((V1 = "s696e616374697665") /\ (V0 = "s696e616374697665"))
  /\ V1 = "s696e616374697665"
  /\ V0 = "s696e616374697665"
  /\ VLStep = -1
  /\ VLCheck = TRUE
A0 ==
  /\ FALSE
  /\ V0 \in {"s616374697665"}
  /\ V0' = "s696e616374697665"
  /\ V1' = V1
  /\ VLStep' = 0
  /\ VLCheck' = TRUE
A1 ==
  /\ FALSE
  /\ V0 \in {"s616374697665"}
  /\ V0' = "s696e616374697665"
  /\ V1' = V1
  /\ VLStep' = 1
  /\ VLCheck' = TRUE
A2 ==
  /\ FALSE
  /\ V0 \in {"s696e616374697665"}
  /\ V0' = "s616374697665"
  /\ V1' = V1
  /\ VLStep' = 2
  /\ VLCheck' = TRUE
A3 ==
  /\ FALSE
  /\ V0 \in {"s696e616374697665"}
  /\ V0' = "s616374697665"
  /\ V1' = V1
  /\ VLStep' = 3
  /\ VLCheck' = TRUE
A4 ==
  /\ FALSE
  /\ V1 \in {"s616374697665"}
  /\ V0' = V0
  /\ V1' = "s696e616374697665"
  /\ VLStep' = 4
  /\ VLCheck' = TRUE
A5 ==
  /\ FALSE
  /\ V1 \in {"s616374697665"}
  /\ V0' = V0
  /\ V1' = "s696e616374697665"
  /\ VLStep' = 5
  /\ VLCheck' = TRUE
A6 ==
  /\ FALSE
  /\ V1 \in {"s696e616374697665"}
  /\ V0' = V0
  /\ V1' = "s616374697665"
  /\ VLStep' = 6
  /\ VLCheck' = (V0 = V0)
A7 ==
  /\ FALSE
  /\ V1 \in {"s696e616374697665"}
  /\ V0' = V0
  /\ V1' = "s616374697665"
  /\ VLStep' = 7
  /\ VLCheck' = (V0 = V0)
Terminal == TRUE
Finish == Terminal /\ UNCHANGED vars
Next == A0 \/ A1 \/ A2 \/ A3 \/ A4 \/ A5 \/ A6 \/ A7 \/ Finish
Spec == Init /\ [][Next]_vars
CheckedProperty == VLCheck
====
