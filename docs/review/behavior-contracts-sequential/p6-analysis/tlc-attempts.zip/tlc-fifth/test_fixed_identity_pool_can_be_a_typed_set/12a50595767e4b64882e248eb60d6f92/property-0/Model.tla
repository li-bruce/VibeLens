---- MODULE Model ----
EXTENDS Integers, Sequences, FiniteSets
VARIABLES V0, V1, V2, VLStep, VLCheck
physical == <<V0, V1, V2>>
vars == <<V0, V1, V2, VLStep, VLCheck>>
Type0 == V0 \in {"s696e616374697665", "s616374697665"}
Type1 == V1 \in {"s696e616374697665", "s616374697665"}
Type2 == V2 \in {s \in SUBSET {"s776f726b65722d61", "s776f726b65722d62"} : Cardinality(s) <= 2}
Init ==
  /\ Type0
  /\ Type1
  /\ Type2
  /\ ((V1 = "s696e616374697665") /\ (V0 = "s696e616374697665") /\ (V2 = {}))
  /\ V1 = "s696e616374697665"
  /\ V0 = "s696e616374697665"
  /\ VLStep = -1
  /\ VLCheck = TRUE
A0 ==
  /\ TRUE
  /\ V0 \in {"s616374697665"}
  /\ V0' = "s696e616374697665"
  /\ V1' = V1
  /\ V2' = V2
  /\ VLStep' = 0
  /\ VLCheck' = TRUE
A1 ==
  /\ TRUE
  /\ V0 \in {"s616374697665"}
  /\ V0' = "s696e616374697665"
  /\ V1' = V1
  /\ V2' = V2
  /\ VLStep' = 1
  /\ VLCheck' = TRUE
A2 ==
  /\ TRUE
  /\ V0 \in {"s696e616374697665"}
  /\ V0' = "s616374697665"
  /\ V1' = V1
  /\ V2' = V2
  /\ VLStep' = 2
  /\ VLCheck' = TRUE
A3 ==
  /\ TRUE
  /\ V0 \in {"s696e616374697665"}
  /\ V0' = "s616374697665"
  /\ V1' = V1
  /\ V2' = V2
  /\ VLStep' = 3
  /\ VLCheck' = TRUE
A4 ==
  /\ (0 < Cardinality(V2))
  /\ V0' = V0
  /\ V1' = V1
  /\ V2' = (V2 \ {"s776f726b65722d61"})
  /\ VLStep' = 4
  /\ VLCheck' = TRUE
A5 ==
  /\ (0 < Cardinality(V2))
  /\ V0' = V0
  /\ V1' = V1
  /\ V2' = (V2 \ {"s776f726b65722d62"})
  /\ VLStep' = 5
  /\ VLCheck' = TRUE
A6 ==
  /\ (Cardinality(V2) < 2)
  /\ V0' = V0
  /\ V1' = V1
  /\ V2' = (V2 \cup {"s776f726b65722d61"})
  /\ VLStep' = 6
  /\ VLCheck' = TRUE
A7 ==
  /\ (Cardinality(V2) < 2)
  /\ V0' = V0
  /\ V1' = V1
  /\ V2' = (V2 \cup {"s776f726b65722d62"})
  /\ VLStep' = 7
  /\ VLCheck' = TRUE
A8 ==
  /\ TRUE
  /\ V1 \in {"s616374697665"}
  /\ V0' = V0
  /\ V1' = "s696e616374697665"
  /\ V2' = V2
  /\ VLStep' = 8
  /\ VLCheck' = TRUE
A9 ==
  /\ TRUE
  /\ V1 \in {"s616374697665"}
  /\ V0' = V0
  /\ V1' = "s696e616374697665"
  /\ V2' = V2
  /\ VLStep' = 9
  /\ VLCheck' = TRUE
A10 ==
  /\ TRUE
  /\ V1 \in {"s696e616374697665"}
  /\ V0' = V0
  /\ V1' = "s616374697665"
  /\ V2' = V2
  /\ VLStep' = 10
  /\ VLCheck' = TRUE
A11 ==
  /\ TRUE
  /\ V1 \in {"s696e616374697665"}
  /\ V0' = V0
  /\ V1' = "s616374697665"
  /\ V2' = V2
  /\ VLStep' = 11
  /\ VLCheck' = TRUE
Next == A0 \/ A1 \/ A2 \/ A3 \/ A4 \/ A5 \/ A6 \/ A7 \/ A8 \/ A9 \/ A10 \/ A11
Spec == Init /\ [][Next]_vars
CheckedProperty == (Cardinality(V2) <= 2)
====
