"""Measure unchanged canonical ingress against a detached native trial copy."""
import cProfile
import hashlib
import io
import json
from pathlib import Path
import pstats
import shutil
import sys
import time
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'skills/vibelens/scripts'))
from bo_observer.graph.behavior_model import capture
from bo_observer.project_artifacts import references
from bo_observer.observation.session import GraphSession

source = ROOT / '.validation/p7-trials/python-retest-app'
out = ROOT / 'docs/review/behavior-contracts-sequential/p7-trials/repair-12'
out.mkdir(exist_ok=True)
project = json.loads((source / 'bo_stategraph/project.json').read_text(encoding='utf-8'))
manifest = capture(source, project['model'])
names = set(manifest['files']) | {'bo_stategraph/project.json', 'sync.json', 'acceptance.json'}
names.update(ref['path'] for _, ref in references(project))
target = ROOT / '.validation/p7-admission-profile'
target.mkdir(exist_ok=False)
hashes = {}
for name in sorted(names):
    data = (source / name).read_bytes()
    path = target / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    hashes[name] = hashlib.sha256(data).hexdigest()
with zipfile.ZipFile(out / 'prior-python-source.zip', 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for name in sorted(names):
        archive.write(target / name, name)
(out / 'prior-python-source.json').write_text(json.dumps({'build_id':manifest['build_id'],'files':hashes}, indent=2)+'\n', encoding='utf-8')
review = source / 'review'
evidence = list((review / 'browser/repair11-recording-20261120T083129').glob('*'))
evidence += [review / n for n in ('repair11-observations-original.json','repair11-verify.json','repair11-stopped-services.json','repair11-recording-once.py','repair11-live-processes.json','repair11-retention-and-gates.json')]
with zipfile.ZipFile(out / 'prior-python-recording.zip','x',compression=zipfile.ZIP_DEFLATED) as archive:
    for path in evidence:
        if path.is_file(): archive.write(path,path.relative_to(review).as_posix())
payload = json.loads((review / 'repair11-observations-original.json').read_text(encoding='utf-8'))
events = next(run['events'] for run in payload['runs'] if run['mode']=='on')
session = GraphSession(target)
assert session.manifest['build_id']==manifest['build_id']
results = {'scope':'Detached original events, no native execution or acceptance claim','build_id':manifest['build_id'],'files':len(names),'nodes':len(project['model']['nodes']),'events':len(events)}
def measure(name, fn):
    profile=cProfile.Profile(); started=time.perf_counter(); profile.enable()
    value=fn()
    profile.disable(); elapsed=time.perf_counter()-started
    text=io.StringIO(); pstats.Stats(profile,stream=text).strip_dirs().sort_stats('cumulative').print_stats(32)
    (out/(name+'.txt')).write_text(text.getvalue(),encoding='utf-8')
    results[name]={'seconds':elapsed,'result':value}
    print(name, results[name],flush=True)
measure('binding-profile',lambda:[session.binding()['status'] for _ in range(12)])
def admit():
    count=0; batch=[]; size=0
    for event in events:
        length=len(json.dumps(event).encode('utf-8'))
        if batch and (size+length>23000 or len(batch)>=64):
            session.bo_sink.bo_accept_many(batch); count+=1; batch=[];size=0
        batch.append(event);size+=length
    if batch: session.bo_sink.bo_accept_many(batch);count+=1
    return {'batches':count,'stored':session.sequence}
measure('admission-profile',admit)
measure('display-profile',lambda:[len(session.view()['events']) for _ in range(5)])
session.close()
(out/'baseline-profile.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
