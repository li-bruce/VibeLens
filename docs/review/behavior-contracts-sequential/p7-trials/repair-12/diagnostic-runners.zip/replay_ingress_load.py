"""Replay preserved envelopes into an isolated collector; never run business code."""
import argparse
import json
from pathlib import Path
import sys
import threading
import time
import zipfile

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'skills/vibelens/scripts'))
from bo_observer.observation.session import GraphSession
from bo_observer.service import make_server
from bo_observer.adapters.python.bo_probe import BOProbe

p=argparse.ArgumentParser();p.add_argument('--name',required=True);p.add_argument('--display',action='store_true');args=p.parse_args()
out=ROOT/'docs/review/behavior-contracts-sequential/p7-trials/repair-12'
target=ROOT/'.validation'/('p7-replay-'+args.name);target.mkdir(exist_ok=False)
with zipfile.ZipFile(out/'prior-python-source.zip') as archive: archive.extractall(target)
payload=json.loads((ROOT/'.validation/p7-trials/python-retest-app/review/repair11-observations-original.json').read_text(encoding='utf-8'))
run=next(r for r in payload['runs'] if r['mode']=='on')
session=GraphSession(target)
server=make_server(session,port=0,token='isolated-diagnostic')
threading.Thread(target=server.serve_forever,daemon=True).start()
probe=BOProbe(session.project,session.manifest['build_id'],endpoint=f'http://127.0.0.1:{server.server_port}',token='isolated-diagnostic',capacity=8192)
session.bo_bind_capture(scope_setter=probe.bo_set_scope,flush_capture=lambda:probe.flush(4),health=probe.bo_health)
recording=session.recordings.start('Detached ingress diagnostic')
closed=threading.Event();views=[];failures=[]
def poll():
 while not closed.is_set():
  started=time.perf_counter()
  try:session.view()
  except Exception as exc:failures.append(repr(exc))
  views.append(time.perf_counter()-started)
  closed.wait(.5)
display=threading.Thread(target=poll,daemon=True)
if args.display:display.start()
snapshots={s['evidence_id']:s for s in run['snapshots'] if s.get('evidence_id')}
started=time.perf_counter()
for i,event in enumerate(run['events']):
 probe.bo_put('events',event)
 if event['id'] in snapshots:probe.bo_put('snapshots',snapshots[event['id']])
 # Fixed diagnostic load approximates the native burst, including state frames.
 time.sleep(.004)
submitted=time.perf_counter()-started
before=probe.bo_health()
stop_started=time.perf_counter();stopped=session.recordings.stop();stop_seconds=time.perf_counter()-stop_started
after=probe.bo_health()
closed.set()
if args.display:display.join(10)
value=session.recordings.get(recording['id'])
report={'scope':'Isolated raw-envelope throughput; not native acceptance','display':args.display,'events':len(run['events']),'snapshots':len(snapshots),'enqueue_seconds':submitted,'before_stop':before,'after_stop':after,'stop_seconds':stop_seconds,'recording':stopped,'collector_errors':session.errors,'collector_last_error':session.last_error,'stored':session.sequence,'frames':len(session.frames),'display_seconds':views,'failures':failures}
(out/(args.name+'.json')).write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report),flush=True)
probe.flush(30);probe.close();server.shutdown();server.server_close()
