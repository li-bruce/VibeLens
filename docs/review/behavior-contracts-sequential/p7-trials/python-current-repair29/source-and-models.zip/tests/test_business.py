"""Independent business outcomes, real SQLite reads, HTTP responses, and isolation checks."""

from concurrent.futures import ThreadPoolExecutor
from contextlib import closing
from datetime import datetime, timezone
from io import BytesIO
from pathlib import Path
import json
import re
import sqlite3
import tempfile
import threading
import unittest
import zipfile

from sqlalchemy.exc import IntegrityError

from app.service import PermissionDenied, Service, StateConflict
from app.web import create_app
from integrations.bo_runtime import BOObservation


ROOT = Path(__file__).resolve().parents[1]
PAYLOAD = b"A real shared file.\nQueue admission is independent from result collection.\n"


def native_rows(directory: Path, table: str) -> list:
    """Read actual storage independently through SQLite rather than the observer projection.

    Args:
        directory: Scenario-specific native runtime directory.
        table: One allowlisted application table.
    """
    if table not in ("files", "grants", "download_jobs", "announcements", "users", "transition_journal"):
        raise ValueError("unregistered_table")
    with closing(sqlite3.connect(directory / "team.sqlite3")) as connection:
        connection.row_factory = sqlite3.Row
        return [dict(row) for row in connection.execute("SELECT * FROM " + table)]


class BusinessTests(unittest.TestCase):
    """Exercise the confirmed policy at native and HTTP boundaries."""

    def setUp(self):
        """Create an isolated actual database and file store."""
        parent = ROOT / "review/runtime"
        parent.mkdir(parents=True, exist_ok=True)
        self.temporary = tempfile.TemporaryDirectory(dir=parent)
        self.directory = Path(self.temporary.name)
        self.service = Service(ROOT, self.directory)

    def tearDown(self):
        """Close application connections before Windows removes scenario files."""
        self.service.close()
        self.temporary.cleanup()

    def shared_file(self) -> str:
        """Upload a real file as Alice and share it with Bob."""
        file_id = self.service.upload_file("alice", "team-note.txt", BytesIO(PAYLOAD))
        self.service.manage_share("alice", file_id, "bob")
        return file_id

    def test_three_real_accounts_and_passwords(self):
        """Three accounts exist, one is an editor, and wrong credentials are rejected."""
        rows = native_rows(self.directory, "users")
        self.assertEqual(len(rows), 3)
        self.assertEqual(sum(row["editor"] for row in rows), 1)
        self.assertEqual(self.service.sign_in("bob", "demo-bob-123")["id"], "bob")
        with self.assertRaises(PermissionDenied):
            self.service.sign_in("bob", "wrong")

    def test_original_visibility_and_management(self):
        """The recipient can see the file; recipients and editors cannot manage it."""
        file_id = self.shared_file()
        self.assertEqual(len(self.service.list_files("bob")["files"]), 1)
        self.assertEqual(self.service.list_files("casey")["files"], [])
        for actor in ("bob", "casey"):
            with self.assertRaises(PermissionDenied):
                self.service.manage_share(actor, file_id, "casey")
            with self.assertRaises(PermissionDenied):
                self.service.manage_share(actor, file_id, "bob", revoke=True)

    def test_unstarted_revoked_job_is_terminal(self):
        """A revoked queued job terminates and remains rejected after sharing again."""
        file_id = self.shared_file()
        job_id = self.service.request_download("bob", file_id)
        self.service.manage_share("alice", file_id, "bob", revoke=True)
        result = self.service.start_preparation()
        self.assertEqual(result["state"], "rejected")
        self.assertFalse(result["admitted"])
        self.service.manage_share("alice", file_id, "bob")
        self.assertIsNone(self.service.start_preparation())
        self.assertEqual(native_rows(self.directory, "download_jobs")[0]["state"], "rejected")
        with self.assertRaises(PermissionDenied):
            self.service.collect_result("bob", job_id)
        new_job = self.service.request_download("bob", file_id)
        self.assertNotEqual(job_id, new_job)
        self.assertEqual(self.service.start_preparation()["id"], new_job)

    def test_regrant_before_turn_cannot_revive_old_request(self):
        """A new grant generation cannot authorize an old queued request."""
        file_id = self.shared_file()
        self.service.request_download("bob", file_id)
        self.service.manage_share("alice", file_id, "bob", revoke=True)
        self.service.manage_share("alice", file_id, "bob")
        self.assertEqual(self.service.start_preparation()["state"], "rejected")

    def test_versioned_context_keeps_changed_operation_input_separate(self):
        """A denied new input preserves queued/1 context and every real snapshot is admitted."""
        from tests.native_boundaries import NativeBoundaryService, snapshot_value_checks
        manifest = json.loads((ROOT / "manifest.json").read_text(encoding="utf-8"))
        project = json.loads((ROOT / "bo_stategraph/project.json").read_text(encoding="utf-8"))
        events, snapshots = [], []
        def collect(value, kind):
            """Retain the actual probe envelope for canonical admission and independent SQL checks."""
            (events if kind == "events" else snapshots).append(value)
        self.service.close()
        observation = BOObservation(ROOT, sink=collect, build_id=manifest["build_id"])
        from bo_observer.workflow.snapshot_evidence import assess_snapshot_admission
        self.service = NativeBoundaryService(ROOT, self.directory, observation)
        try:
            file_id = self.shared_file()
            job_id = self.service.request_download("bob", file_id)
            self.service.manage_share("alice", file_id, "bob", True)
            self.assertEqual(self.service.start_preparation()["state"], "rejected")
            observation.bo_probe.flush(5)
            reads = [event for event in events if event["node"] == "state_before" and event["outputs"]["instance_id"] == job_id]
            denied_read = next(event for event in reads if event["outputs"]["allowed"] is False)
            self.assertEqual(denied_read["outputs"]["revision"], 1)
            self.assertTrue(denied_read["outputs"]["context_allowed"])
            snapshot = next(item for item in snapshots if item["evidence_id"] == denied_read["id"])
            self.assertEqual(snapshot["context"], {"allowed": True})
            self.assertIsNone(snapshot["payload"])
            committed = next(item for item in snapshots if item["instance_id"] == job_id and item["event"] == "reject")
            self.assertEqual((committed["state"], committed["revision"], committed["context"], committed["payload"]), ("rejected", 2, {"allowed": False}, {"allowed": False}))
            checks = snapshot_value_checks(events, snapshots, self.service.boundaries, "queued_revoked", "on")
            self.assertTrue(checks and all(row["passed"] for row in checks))
            admission = assess_snapshot_admission(project, manifest["build_id"], {"runs": [{"case": "queued_revoked", "mode": "on", "events": events, "snapshots": snapshots}]}, required=True)
            self.assertTrue(admission["valid"], admission["errors"])
        finally:
            observation.close()

    def test_started_then_revoked_finishes_and_repeats(self):
        """Admission survives revocation and returns actual bytes on repeated collection."""
        file_id = self.shared_file()
        job_id = self.service.request_download("bob", file_id)
        self.assertEqual(self.service.start_preparation()["state"], "preparing")
        admitted = native_rows(self.directory, "download_jobs")[0]
        self.assertTrue(admitted["admitted"])
        self.service.manage_share("alice", file_id, "bob", revoke=True)
        self.assertEqual(self.service.list_files("bob")["files"], [])
        self.service.complete_preparation(job_id)
        for _ in range(2):
            path, name = self.service.collect_result("bob", job_id)
            with zipfile.ZipFile(path) as archive:
                self.assertEqual(archive.read("team-note.txt"), PAYLOAD)
        self.assertEqual(native_rows(self.directory, "download_jobs")[0]["state"], "ready")
        with self.assertRaises(PermissionDenied):
            self.service.collect_result("alice", job_id)

    def test_revocation_is_recipient_specific(self):
        """Revoking Bob does not affect Casey's separately issued grant."""
        file_id = self.shared_file()
        self.service.manage_share("alice", file_id, "casey")
        self.service.manage_share("alice", file_id, "bob", revoke=True)
        self.assertEqual(self.service.list_files("bob")["files"], [])
        self.assertEqual(len(self.service.list_files("casey")["files"]), 1)

    def test_board_editor_owns_publications_only(self):
        """Colleagues read; the editor can publish/edit/delete only their own announcement."""
        for actor in ("alice", "bob"):
            with self.assertRaises(PermissionDenied):
                self.service.save_announcement(actor, "Denied", "No editor role")
        item = self.service.save_announcement("casey", "Team notice", "Initial text")
        self.assertEqual(self.service.list_announcements("bob")[0]["title"], "Team notice")
        self.service.save_announcement("casey", "Updated", "New text", item)
        self.assertEqual(self.service.list_announcements("alice")[0]["body"], "New text")
        with closing(sqlite3.connect(self.directory / "team.sqlite3")) as connection:
            connection.execute("INSERT INTO announcements VALUES (?,?,?,?,?,?,?)", ("external-fixture", "bob", "Another author", "Synthetic ownership fixture", "published", 1, "2026-01-01"))
            connection.commit()
        with self.assertRaises(PermissionDenied):
            self.service.save_announcement("casey", "Overwrite", "Denied", "external-fixture")
        with self.assertRaises(PermissionDenied):
            self.service.save_announcement("casey", "", "", "external-fixture", True)
        self.service.save_announcement("casey", "", "", item, True)
        self.assertEqual([a["id"] for a in self.service.list_announcements("bob")], ["external-fixture"])

    def test_parallel_claim_has_one_winner(self):
        """Actual simultaneous claimers cannot admit the same queued job twice."""
        file_id = self.shared_file()
        self.service.request_download("bob", file_id)
        barrier = threading.Barrier(2)
        def claim():
            """Start one synchronized native claimant."""
            barrier.wait(timeout=5)
            return self.service.start_preparation()
        with ThreadPoolExecutor(max_workers=2) as pool:
            result = list(pool.map(lambda _: claim(), range(2)))
        self.assertEqual(sum(item is not None for item in result), 1)
        self.assertEqual(sum(row["event"] == "start" for row in native_rows(self.directory, "transition_journal")), 1)

    def test_all_models_have_native_journal_witnesses(self):
        """Persist separate model identities even when state words overlap."""
        file_id = self.shared_file()
        job_id = self.service.request_download("bob", file_id)
        self.service.start_preparation()
        self.service.complete_preparation(job_id)
        self.service.save_announcement("casey", "Notice", "Body")
        journals = native_rows(self.directory, "transition_journal")
        self.assertEqual({j["model_id"] for j in journals}, {"file", "grant", "download-job", "announcement"})
        self.assertTrue(all(j["transaction_id"] for j in journals))

    def test_observer_on_off_fault_preserves_effects(self):
        """Actual failing transport cannot alter admission, revocation, or collected bytes."""
        manifest = json.loads((ROOT / "manifest.json").read_text(encoding="utf-8"))
        outcomes = []
        for mode in ("on", "off", "fault"):
            with tempfile.TemporaryDirectory(dir=ROOT / "review/runtime") as folder:
                events = []
                observation = BOObservation(ROOT, mode, sink=lambda value, kind: events.append((kind, value)), build_id=manifest["build_id"])
                service = Service(ROOT, Path(folder), observation)
                file_id = service.upload_file("alice", "proof.txt", BytesIO(PAYLOAD))
                service.manage_share("alice", file_id, "bob")
                job = service.request_download("bob", file_id)
                service.start_preparation()
                service.manage_share("alice", file_id, "bob", True)
                service.complete_preparation(job)
                path, _ = service.collect_result("bob", job)
                with zipfile.ZipFile(path) as archive:
                    content = archive.read("proof.txt")
                observation.bo_probe.flush(5)
                outcomes.append((native_rows(Path(folder), "download_jobs")[0]["state"], content))
                health = observation.bo_health()
                if mode == "on":
                    self.assertGreater(len(events), 0)
                    self.assertEqual(health["errors"], 0)
                    self.assertEqual({v["state_model_id"] for k, v in events if k == "snapshots"}, {"file", "grant", "download-job"})
                elif mode == "off":
                    self.assertEqual(events, [])
                else:
                    self.assertGreater(health["errors"], 0)
                service.close()
                observation.close()
        self.assertEqual(outcomes, [("ready", PAYLOAD)] * 3)

    def test_restart_keeps_admitted_attempt(self):
        """Native admission remains usable after a service restart and revocation."""
        file_id = self.shared_file()
        job = self.service.request_download("bob", file_id)
        self.service.start_preparation()
        self.service.manage_share("alice", file_id, "bob", True)
        self.service.close()
        self.service = Service(ROOT, self.directory)
        self.service.complete_preparation(job)
        self.assertTrue(self.service.collect_result("bob", job)[0].is_file())

    def test_admission_rollback_has_no_successful_effect(self):
        """A real database abort rolls back admission and emits no successful completion."""
        file_id = self.shared_file()
        job_id = self.service.request_download("bob", file_id)
        self.service.close()
        events = []
        manifest = json.loads((ROOT / "manifest.json").read_text(encoding="utf-8"))
        observation = BOObservation(ROOT, sink=lambda value, kind: events.append(value) if kind == "events" else None, build_id=manifest["build_id"])
        self.service = Service(ROOT, self.directory, observation)
        try:
            with closing(sqlite3.connect(self.directory / "team.sqlite3")) as connection:
                connection.execute("CREATE TRIGGER reject_admission BEFORE UPDATE OF state ON download_jobs WHEN NEW.state='preparing' BEGIN SELECT RAISE(ABORT, 'isolated_admission_rejection'); END")
                connection.commit()
            with self.assertRaises(IntegrityError):
                self.service.start_preparation()
            observation.bo_probe.flush(5)
            rejected = [event for event in events if event["node"] == "admission_transaction"]
            self.assertEqual([event["phase"] for event in rejected], ["enter", "error"])
            self.assertFalse(any(event.get("outputs", {}).get("committed") is True for event in rejected))
            self.assertEqual(native_rows(self.directory, "download_jobs")[0]["state"], "queued")
            self.assertFalse(native_rows(self.directory, "download_jobs")[0]["admitted"])
            self.assertFalse(any(row["instance_id"] == job_id and row["event"] == "start" for row in native_rows(self.directory, "transition_journal")))
            with closing(sqlite3.connect(self.directory / "team.sqlite3")) as connection:
                connection.execute("DROP TRIGGER reject_admission")
                connection.commit()
            offset = len(events)
            self.assertEqual(self.service.start_preparation()["state"], "preparing")
            observation.bo_probe.flush(5)
            committed = [event for event in events[offset:] if event["node"] == "admission_transaction"]
            self.assertEqual([event["phase"] for event in committed], ["enter", "return"])
            self.assertEqual(committed[0]["call_id"], committed[1]["call_id"])
            self.assertEqual(committed[0]["outputs"]["transaction_id"], committed[1]["outputs"]["transaction_id"])
            self.assertTrue(committed[1]["outputs"]["committed"])
            self.assertTrue(native_rows(self.directory, "download_jobs")[0]["admitted"])
        finally:
            observation.bo_probe.flush(5)
            evidence = ROOT / "review/runtime/admission-boundary" / datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%f")
            evidence.mkdir(parents=True)
            (evidence / "original-evidence.json").write_text(json.dumps({"fixture": "A real SQLite trigger deliberately aborts the first admission UPDATE; it is removed before an actual retry.", "events": events, "native_trace": observation.bo_request_facts.bo_values, "native_jobs": native_rows(self.directory, "download_jobs"), "native_journals": native_rows(self.directory, "transition_journal"), "health": observation.bo_health()}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            observation.close()

    def test_http_login_csrf_and_stale_permission(self):
        """Real HTTP endpoints reject missing CSRF and recheck a stale recipient page."""
        app = create_app(ROOT, self.directory, start_worker=False)
        client = app.test_client()
        self.assertEqual(client.get("/").status_code, 302)
        login = client.get("/login").get_data(as_text=True)
        token = re.search(r'name="csrf" value="([^"]+)"', login)[1]
        self.assertEqual(client.post("/login", data={"username": "bob", "password": "demo-bob-123"}).status_code, 400)
        self.assertEqual(client.post("/login", data={"csrf": token, "username": "bob", "password": "demo-bob-123"}).status_code, 303)
        file_id = self.shared_file()
        old_page = client.get("/").get_data(as_text=True)
        token = re.search(r'name="csrf" value="([^"]+)"', old_page)[1]
        self.assertIn("team-note.txt", old_page)
        self.service.manage_share("alice", file_id, "bob", True)
        response = client.post("/files/" + file_id + "/downloads", data={"csrf": token})
        self.assertEqual(response.status_code, 403)
        self.assertNotIn("team-note.txt", client.get("/").get_data(as_text=True))
        app.extensions["service"].close()


    def test_cancel_queued_is_terminal_and_new_request_is_distinct(self):
        """A committed cancellation has no admission or result and never re-enters the queue."""
        file_id = self.shared_file()
        job_id = self.service.request_download("bob", file_id)
        self.service.cancel_download("bob", job_id)
        row = native_rows(self.directory, "download_jobs")[0]
        self.assertEqual((row["state"], row["revision"], row["admitted"], row["result_name"]), ("cancelled", 2, 0, ""))
        journal = [j for j in native_rows(self.directory, "transition_journal") if j["instance_id"] == job_id]
        self.assertEqual([j["event"] for j in journal], ["request", "cancel"])
        self.assertEqual((journal[-1]["before"], journal[-1]["after"], journal[-1]["revision"]), ("queued", "cancelled", 2))
        self.assertTrue(journal[-1]["transaction_id"])
        self.assertFalse((self.service.results / (job_id + ".zip")).exists())
        self.assertIsNone(self.service.start_preparation())
        with self.assertRaises(StateConflict):
            self.service.cancel_download("bob", job_id)
        with self.assertRaises(PermissionDenied):
            self.service.complete_preparation(job_id)
        with self.assertRaises(PermissionDenied):
            self.service.collect_result("bob", job_id)
        self.service.close()
        self.service = Service(ROOT, self.directory)
        self.assertIsNone(self.service.start_preparation())
        fresh = self.service.request_download("bob", file_id)
        self.assertNotEqual(fresh, job_id)
        self.assertEqual(self.service.start_preparation()["id"], fresh)
        self.service.complete_preparation(fresh)
        path, _ = self.service.collect_result("bob", fresh)
        with zipfile.ZipFile(path) as archive:
            self.assertEqual(archive.read("team-note.txt"), PAYLOAD)
        self.assertEqual(next(j for j in native_rows(self.directory, "download_jobs") if j["id"] == job_id), row)

    def test_cancellation_has_no_owner_or_editor_override(self):
        """Only the current authenticated requester may cancel, even after sharing is revoked."""
        file_id = self.shared_file()
        job_id = self.service.request_download("bob", file_id)
        before = native_rows(self.directory, "download_jobs")
        journal = native_rows(self.directory, "transition_journal")
        for actor in ("alice", "casey", "missing-user"):
            with self.subTest(actor=actor), self.assertRaises(PermissionDenied):
                self.service.cancel_download(actor, job_id)
        with self.assertRaises(PermissionDenied):
            self.service.cancel_download("bob", "missing-job")
        self.assertEqual(native_rows(self.directory, "download_jobs"), before)
        self.assertEqual(native_rows(self.directory, "transition_journal"), journal)
        self.service.manage_share("alice", file_id, "bob", True)
        self.service.cancel_download("bob", job_id)
        self.assertEqual(native_rows(self.directory, "download_jobs")[0]["state"], "cancelled")
        with self.assertRaises(PermissionDenied):
            self.service.request_download("bob", file_id)

    def test_preparing_ready_and_rejected_attempts_cannot_cancel(self):
        """Once the queued boundary has passed, cancellation cannot alter any native row."""
        file_id = self.shared_file()
        job_id = self.service.request_download("bob", file_id)
        self.service.start_preparation()
        for expected in ("preparing", "ready"):
            before = native_rows(self.directory, "download_jobs")
            journal = native_rows(self.directory, "transition_journal")
            self.assertEqual(before[0]["state"], expected)
            with self.assertRaises(StateConflict):
                self.service.cancel_download("bob", job_id)
            self.assertEqual(native_rows(self.directory, "download_jobs"), before)
            self.assertEqual(native_rows(self.directory, "transition_journal"), journal)
            if expected == "preparing":
                self.service.manage_share("alice", file_id, "bob", True)
                self.service.complete_preparation(job_id)
        self.assertTrue(self.service.collect_result("bob", job_id)[0].is_file())
        self.service.manage_share("alice", file_id, "bob")
        rejected = self.service.request_download("bob", file_id)
        self.service.manage_share("alice", file_id, "bob", True)
        self.assertEqual(self.service.start_preparation()["state"], "rejected")
        before = native_rows(self.directory, "download_jobs")
        journal = native_rows(self.directory, "transition_journal")
        with self.assertRaises(StateConflict):
            self.service.cancel_download("bob", rejected)
        self.assertEqual(native_rows(self.directory, "download_jobs"), before)
        self.assertEqual(native_rows(self.directory, "transition_journal"), journal)

    def test_cancel_and_start_have_one_committed_queued_exit(self):
        """Concurrent real transactions preserve the winner without overwriting its state."""
        file_id = self.shared_file()
        attempts = []
        for _ in range(8):
            job_id = self.service.request_download("bob", file_id)
            gate = threading.Barrier(2)

            def cancel():
                """Contend through the normal requester operation."""
                gate.wait(timeout=10)
                try:
                    self.service.cancel_download("bob", job_id)
                    return "cancelled"
                except StateConflict:
                    return "conflict"

            def start():
                """Contend through the normal worker operation."""
                gate.wait(timeout=10)
                return self.service.start_preparation()

            with ThreadPoolExecutor(max_workers=2) as executor:
                cancelling, starting = executor.submit(cancel), executor.submit(start)
                cancelled, started = cancelling.result(timeout=35), starting.result(timeout=35)
            row = next(j for j in native_rows(self.directory, "download_jobs") if j["id"] == job_id)
            journal = [j for j in native_rows(self.directory, "transition_journal") if j["instance_id"] == job_id]
            self.assertEqual(row["revision"], 2)
            self.assertEqual(len(journal), 2)
            self.assertEqual(len([j for j in journal if j["before"] == "queued"]), 1)
            if cancelled == "cancelled":
                self.assertIsNone(started)
                self.assertEqual((row["state"], row["admitted"], journal[-1]["event"]), ("cancelled", 0, "cancel"))
            else:
                self.assertEqual((cancelled, started["id"], row["state"], row["admitted"], journal[-1]["event"]), ("conflict", job_id, "preparing", 1, "start"))
                self.service.complete_preparation(job_id)
                self.assertTrue(self.service.collect_result("bob", job_id)[0].is_file())
            attempts.append({"cancel_result": cancelled, "worker_result": started, "native_row": row, "native_journal": journal})
        evidence = ROOT / "review/runtime/cancellation-races" / datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%f")
        evidence.mkdir(parents=True)
        (evidence / "native-results.json").write_text(json.dumps(attempts, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    def test_cancellation_transport_on_off_fault_preserves_native_result(self):
        """Observer absence or an actual failing transport cannot change cancellation effects."""
        manifest = json.loads((ROOT / "manifest.json").read_text(encoding="utf-8"))
        outcomes = []
        for mode in ("on", "off", "fault"):
            with tempfile.TemporaryDirectory(dir=ROOT / "review/runtime") as folder:
                events = []
                observation = BOObservation(ROOT, mode, sink=lambda value, kind: events.append((kind, value)), build_id=manifest["build_id"])
                service = Service(ROOT, Path(folder), observation)
                try:
                    file_id = service.upload_file("alice", "cancel.txt", BytesIO(PAYLOAD))
                    service.manage_share("alice", file_id, "bob")
                    job_id = service.request_download("bob", file_id)
                    service.cancel_download("bob", job_id)
                    self.assertIsNone(service.start_preparation())
                    observation.bo_probe.flush(5)
                    row = native_rows(Path(folder), "download_jobs")[0]
                    outcomes.append((row["state"], row["revision"], row["admitted"], row["result_name"]))
                    if mode == "on":
                        self.assertTrue(any(kind == "events" and value["node"] == "cancel_download" and value["phase"] == "return" for kind, value in events))
                        self.assertEqual(observation.bo_health()["errors"], 0)
                    elif mode == "off":
                        self.assertEqual(events, [])
                    else:
                        self.assertGreater(observation.bo_health()["errors"], 0)
                finally:
                    service.close()
                    observation.close()
        self.assertEqual(outcomes, [("cancelled", 2, 0, "")] * 3)

    def test_cancellation_rollback_keeps_queued_until_real_retry(self):
        """A real SQLite abort cannot produce a committed cancellation or a false revision."""
        file_id = self.shared_file()
        job_id = self.service.request_download("bob", file_id)
        before = native_rows(self.directory, "download_jobs")
        journal = native_rows(self.directory, "transition_journal")
        with closing(sqlite3.connect(self.directory / "team.sqlite3")) as connection:
            connection.execute("CREATE TRIGGER abort_cancellation BEFORE UPDATE OF state ON download_jobs WHEN NEW.state='cancelled' BEGIN SELECT RAISE(ABORT,'deliberate cancellation rollback'); END")
            connection.commit()
        with self.assertRaises(IntegrityError):
            self.service.cancel_download("bob", job_id)
        self.assertEqual(native_rows(self.directory, "download_jobs"), before)
        self.assertEqual(native_rows(self.directory, "transition_journal"), journal)
        with closing(sqlite3.connect(self.directory / "team.sqlite3")) as connection:
            connection.execute("DROP TRIGGER abort_cancellation")
            connection.commit()
        self.service.cancel_download("bob", job_id)
        self.assertEqual(native_rows(self.directory, "download_jobs")[0]["state"], "cancelled")

    def test_download_page_offers_cancellation_only_for_own_queued_attempt(self):
        """Actual rendered forms follow requester identity and disappear after cancellation."""
        file_id = self.shared_file()
        job_id = self.service.request_download("bob", file_id)
        app = create_app(ROOT, self.directory, start_worker=False)
        client = app.test_client()
        route = "/downloads/" + job_id + "/cancel"
        try:
            for actor in ("alice", "casey", "bob"):
                client.get("/login")
                with client.session_transaction() as native:
                    token = native["csrf"]
                self.assertEqual(client.post("/login", data={"csrf": token, "username": actor, "password": "demo-" + actor + "-123"}).status_code, 303)
                page = client.get("/?tab=downloads").get_data(as_text=True)
                self.assertEqual(route in page, actor == "bob")
            with client.session_transaction() as native:
                token = native["csrf"]
            self.assertEqual(client.post(route, data={"csrf": token}).status_code, 303)
            page = client.get("/?tab=downloads").get_data(as_text=True)
            self.assertNotIn(route, page)
            self.assertIn("本次任务已取消", page)
            self.assertIn("如需下载请重新申请", page)
            self.assertNotIn('http-equiv="refresh"', page)
            self.assertEqual(client.post(route, data={"csrf": token}).status_code, 409)
        finally:
            app.extensions["service"].close()


if __name__ == "__main__":
    unittest.main()
