"""Independent raw SQL witnesses around actual native service transitions."""
from app.service import Service


def read_boundary(session, model_id, instance_id, transaction_id, boundary, operation_allowed):
    """Read the actual row and journal through SQL, never through observer values.

    Args:
        session: Native transaction whose uncommitted rows must also be witnessed.
        model_id: Allowlisted native model selecting the actual SQL table.
        instance_id: Native primary or composite key used only to select the row.
        transaction_id: Existing caller transaction used to join evidence.
        boundary: Before the executor or after its actual application and journal flush.
        operation_allowed: Actual native function argument, separate from stored context.
    """
    tables = {"file": "files", "grant": "grants", "download-job": "download_jobs", "announcement": "announcements"}
    table = tables[model_id]
    if model_id == "grant":
        file_id, recipient_id = instance_id.split(":", 1)
        where, parameters = "file_id=? AND recipient_id=?", (file_id, recipient_id)
    else:
        where, parameters = "id=?", (instance_id,)
    connection = session.connection()
    state, revision = connection.exec_driver_sql("SELECT state,revision FROM " + table + " WHERE " + where, parameters).one()
    journal = connection.exec_driver_sql("SELECT permission_allowed,sequence,transaction_id FROM transition_journal WHERE model_id=? AND instance_id=? AND revision=? ORDER BY sequence DESC LIMIT 1", (model_id, instance_id, revision)).first()
    context = {"allowed": bool(journal[0])} if journal else ({"allowed": False} if revision == 0 else {})
    return {"model_id": model_id, "instance_id": instance_id, "transaction_id": transaction_id, "boundary": boundary, "state": state, "revision": revision, "context": context, "operation_allowed": operation_allowed, "journal_sequence": journal[1] if journal else None, "journal_transaction_id": journal[2] if journal else None}


class NativeBoundaryService(Service):
    """Use the unchanged native methods while independently reading their SQL boundaries."""

    def __init__(self, *args, **kwargs):
        """Construct the real service and a test-owned native fact list."""
        super().__init__(*args, **kwargs)
        self.boundaries = []

    def _change(self, session, model_id, instance, event, allowed, transaction_id):
        """Read actual pre/post SQL around the original project method.

        Args:
            session: Unchanged caller-owned native transaction.
            model_id: Native model identity selecting its SQL table.
            instance: Real ORM row passed to the original service method.
            event: Original declared transition event.
            allowed: Native current-operation input, independent of observer output.
            transaction_id: Existing native transaction identity.
        """
        identity = instance.file_id + ":" + instance.recipient_id if model_id == "grant" else instance.id
        session.flush()
        self.boundaries.append(read_boundary(session, model_id, identity, transaction_id, "before", allowed))
        result = super()._change(session, model_id, instance, event, allowed, transaction_id)
        session.flush()
        self.boundaries.append(read_boundary(session, model_id, identity, transaction_id, "after_apply", allowed))
        return result


def snapshot_value_checks(events, snapshots, boundaries, case, mode):
    """Compare every submitted intermediate snapshot with its independent SQL boundary.

    Args:
        events: Actual captured events supplying correlation, never expected values.
        snapshots: Original ordered snapshot envelopes from the actual probe.
        boundaries: Independent raw SQL facts and original native function arguments.
        case: Protected native scenario identity.
        mode: Actual capture mode for unique witness identities.
    """
    event_by_id = {event["id"]: event for event in events}
    facts = {(row["model_id"], row["instance_id"], row["transaction_id"], row["boundary"]): row for row in boundaries}
    checks = []
    for snapshot in snapshots:
        event = event_by_id[snapshot["evidence_id"]]
        values = event["outputs"]
        boundary = "before" if event["node"] == "state_before" else "after_apply"
        native = facts[(snapshot["state_model_id"], snapshot["instance_id"], values["transaction_id"], boundary)]
        pairs = {"state": (native["state"], snapshot["state"]), "revision": (native["revision"], snapshot["revision"]), "context": (native["context"], snapshot["context"]), "current_input": (native["operation_allowed"], values["allowed"])}
        if boundary == "after_apply":
            pairs["typed_payload"] = ({"allowed": native["operation_allowed"]}, snapshot["payload"])
        else:
            pairs["read_has_no_transition_payload"] = (None, snapshot["payload"])
        for field, (actual, observed) in pairs.items():
            checks.append({"id": case + ":" + mode + ":snapshot:" + event["id"] + ":" + field, "case": case, "mode": mode, "state_model_id": snapshot["state_model_id"], "instance_id": snapshot["instance_id"], "transaction_id": values["transaction_id"], "evidence_id": event["id"], "field": field, "source": "tests/native_boundaries.py::read_boundary (actual raw SQL and native call input)", "projection": "original snapshot/event at " + boundary, "actual": actual, "mapped": observed, "passed": actual == observed})
    return checks
