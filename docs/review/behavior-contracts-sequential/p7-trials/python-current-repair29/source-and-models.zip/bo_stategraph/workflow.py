"""Project-native transactional adapter for declaration-driven state changes."""

import json
from pathlib import Path
from contextlib import nullcontext

from .bo_executor import BOExecutors


def allowed_guard(context: dict, payload: dict) -> bool:
    """Read the native permission result acquired by the enclosing transaction.

    Args:
        context: Complete native version, including its last committed decision.
        payload: Typed current event input containing the new permission decision.
    """
    return payload["allowed"]


class Workflow:
    """Execute the registered definitions and their declared local effects."""

    def __init__(self, root: Path, observation=None):
        """Load all four machines and their project-owned transition effects.

        Args:
            root: Application source root containing the canonical declarations.
            observation: Optional neutral notification port for actual guard returns.
        """
        project = json.loads((Path(root) / "bo_stategraph/project.json").read_text(encoding="utf-8"))
        self.definition = {"machines": project["model"]["machines"], "transition_effects": project["model"]["native_transition_effects"]}
        charts = self.definition["machines"]
        self.bo_probe = observation
        self.build_id = json.loads((root / "manifest.json").read_text(encoding="utf-8"))["build_id"]
        self.executors = BOExecutors(charts, {mid: {g: self.bind_guard(mid, g) for g in m["guards"]} for mid, m in charts.items()})

    def bind_guard(self, model_id: str, name: str):
        """Bind a callback without changing its native context or result.

        Args:
            model_id: Independent machine receiving the decision.
            name: Declared guard name.
        """
        def callback(context: dict, payload: dict):
            """Notify only after the real guard function returned to this callback."""
            result = allowed_guard(context, payload)
            if self.bo_probe is not None:
                self.bo_probe.bo_guard("native-guard:" + model_id + ":" + name, result)
            return result
        return callback

    def step(self, model_id: str, instance, event: str, allowed: bool, transaction_id: str, context: dict) -> dict:
        """Apply one declaration transition and its registered effect inside the caller's transaction.

        Args:
            model_id: Independent state model identity.
            instance: Actual ORM object; its state and revision are changed in place.
            event: Declared native event name.
            allowed: Permission decision read within the same transaction.
            transaction_id: Actual native transaction containing this transition attempt.
            context: Last committed decision read for the unchanged native version.
        """
        before = instance.state
        identity = instance.file_id + ":" + instance.recipient_id if model_id == "grant" else instance.id
        values = {"model_id": model_id, "model_ref": "state-model:" + model_id, "instance_id": identity, "event": event, "allowed": allowed, "context_allowed": context["allowed"], "transaction_id": transaction_id, "build_id": self.build_id}
        scope = self.bo_probe.span("native_transition", values) if self.bo_probe else nullcontext({})
        with scope as output:
            result = self.executors.step(model_id, before, event, context, {"allowed": allowed})
            key = model_id + ":" + before + ":" + event
            for effect in self.definition["transition_effects"].get(key, []):
                if effect != "record_admission":
                    raise ValueError("Unsupported project transition effect: " + effect)
                instance.admitted = True
            instance.state = result["state"]
            instance.revision += 1
            output.update(**values, state=instance.state, revision=instance.revision)
            return {"before": before, "after": instance.state, "event": event, "guards": result["guards"], "payload": result["payload"], "revision": instance.revision}

