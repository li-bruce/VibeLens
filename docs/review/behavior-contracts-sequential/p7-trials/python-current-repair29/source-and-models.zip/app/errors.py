"""Stable native service exceptions shared by application operation modules."""


class PermissionDenied(Exception):
    """A native permission rejection with a stable presentation code."""


class StateConflict(Exception):
    """The authenticated requester's operation no longer applies to the native state."""
