"""Native download operations using the application's existing transaction and rule context."""

from __future__ import annotations

from typing import TYPE_CHECKING, Callable
import uuid
import zipfile

from sqlalchemy import select

from .errors import PermissionDenied, StateConflict
from .models import DownloadJob, File, Grant

if TYPE_CHECKING:
    from .service import Service


class DownloadOperations:
    """Own download request, cancellation, preparation and result operations."""

    def __init__(self, service: Service, created_at: Callable[[], str]):
        """Reuse the application's native context and existing creation timestamp.

        Args:
            service: Existing application service owning storage, policy and state changes.
            created_at: Existing timestamp function, called at the original request boundary.
        """
        self.service = service
        self.created_at = created_at

    def request_download(self, actor_id: str, file_id: str) -> str:
        """Queue a distinct attempt while retaining its original grant generation.

        Args:
            actor_id: Authenticated uploader or currently shared recipient.
            file_id: Original file requested for preparation.
        """
        service = self.service
        job_id, transaction_id = (uuid.uuid4().hex, uuid.uuid4().hex)
        with service.bo_probe.span(
            "request_download", {"actor_id": actor_id, "file_id": file_id}
        ) as output:
            with service.store.transaction() as session:
                service._user(session, actor_id)
                file = service._file(session, file_id)
                grant = session.get(Grant, (file.id, actor_id))
                allowed = service._policy(
                    session,
                    "request_download",
                    actor_id,
                    file=file,
                    grant=grant,
                    fact_revision=transaction_id,
                )
                if not allowed:
                    raise PermissionDenied("file_unavailable")
                job = DownloadJob(
                    id=job_id,
                    file_id=file_id,
                    requester_id=actor_id,
                    grant_revision=(
                        grant.revision if grant and actor_id != file.owner_id else None
                    ),
                    state="not_requested",
                    revision=0,
                    admitted=False,
                    result_name="",
                    error_code="",
                    created_at=self.created_at(),
                )
                session.add(job)
                change = service._change(
                    session, "download-job", job, "request", True, transaction_id
                )
            service.bo_probe.bo_transition(change)
            output.update(
                job_id=job_id,
                state="queued",
                committed=True,
                transaction_id=transaction_id,
            )
        return job_id

    def cancel_download(self, actor_id: str, job_id: str) -> None:
        """Cancel this requester's queued attempt in the same transaction boundary as admission.

        Args:
            actor_id: Authenticated requester; file ownership and editor status grant no override.
            job_id: One download attempt that must still be queued when the write lock is held.
        """
        service = self.service
        transaction_id = uuid.uuid4().hex
        with service.bo_probe.span(
            "cancel_download", {"actor_id": actor_id, "job_id": job_id}
        ) as output:
            with service.store.transaction() as session:
                service._user(session, actor_id)
                job = session.scalar(
                    select(DownloadJob).where(DownloadJob.id == job_id)
                )
                if job is None:
                    raise PermissionDenied("job_unavailable")
                allowed = service._policy(
                    session,
                    "cancel_download",
                    actor_id,
                    job=job,
                    fact_revision=transaction_id,
                )
                if not allowed:
                    raise PermissionDenied("job_unavailable")
                if job.state != "queued":
                    output.update(allowed=True, state=job.state)
                    raise StateConflict("job_not_queued")
                change = service._change(
                    session, "download-job", job, "cancel", allowed, transaction_id
                )
            service.bo_probe.bo_transition(change)
            output.update(
                allowed=True,
                state="cancelled",
                committed=True,
                transaction_id=transaction_id,
            )

    def start_preparation(self) -> dict | None:
        """Claim the oldest job and atomically persist admission or permanent rejection."""
        service = self.service
        transaction_id = uuid.uuid4().hex
        with service.bo_probe.span("start_preparation", {}) as output:
            with service.store.transaction() as session:
                job = session.scalar(
                    select(DownloadJob)
                    .where(DownloadJob.state == "queued")
                    .order_by(DownloadJob.sequence)
                    .limit(1)
                )
                if job is None:
                    output.update(found=False)
                    return None
                file = service._file(session, job.file_id)
                grant = session.get(Grant, (file.id, job.requester_id))
                allowed = service._policy(
                    session,
                    "start_preparation",
                    job.requester_id,
                    file=file,
                    grant=grant,
                    job=job,
                    fact_revision=transaction_id,
                )
                event = "start" if allowed else "reject"
                if allowed:
                    service.bo_probe.bo_admission_started(transaction_id, job.id)
                change = service._change(
                    session, "download-job", job, event, allowed, transaction_id
                )
                if not allowed:
                    job.error_code = "share_revoked"
                result = {
                    "id": job.id,
                    "file_id": file.id,
                    "name": file.name,
                    "state": job.state,
                    "admitted": job.admitted,
                    "requester_id": job.requester_id,
                }
            service.bo_probe.bo_transition(change)
            output.update(
                found=True,
                job_id=result["id"],
                allowed=allowed,
                admitted=result["admitted"],
                state=result["state"],
                committed=True,
                transaction_id=transaction_id,
            )
            return result

    def complete_preparation(self, job_id: str) -> None:
        """Build a real ZIP for an admitted attempt; later revocation is not rechecked.

        Args:
            job_id: Identity of an attempt already in the preparing state.
        """
        service = self.service
        transaction_id = uuid.uuid4().hex
        with service.bo_probe.span(
            "complete_preparation", {"job_id": job_id}
        ) as output:
            with service.store.read() as session:
                job = session.scalar(
                    select(DownloadJob).where(DownloadJob.id == job_id)
                )
                if job is None or job.state != "preparing" or (not job.admitted):
                    raise PermissionDenied("job_not_admitted")
                file = service._file(session, job.file_id)
                original_id, filename = (file.id, file.name)
            temporary = service.results / (job_id + ".part")
            final = service.results / (job_id + ".zip")
            try:
                with zipfile.ZipFile(
                    temporary, "w", compression=zipfile.ZIP_DEFLATED
                ) as archive:
                    archive.write(service.originals / original_id, arcname=filename)
                temporary.replace(final)
                with service.store.transaction() as session:
                    job = session.scalar(
                        select(DownloadJob).where(DownloadJob.id == job_id)
                    )
                    if job.state != "preparing" or not job.admitted:
                        raise PermissionDenied("job_not_admitted")
                    job.result_name = final.name
                    job.error_code = ""
                    change = service._change(
                        session, "download-job", job, "complete", True, transaction_id
                    )
                service.bo_probe.bo_transition(change)
            finally:
                temporary.unlink(missing_ok=True)
            output.update(state="ready", committed=True, transaction_id=transaction_id)

    def collect_result(self, actor_id: str, job_id: str) -> tuple:
        """Return a ready result to its requester; keep it available for repeated downloads.

        Args:
            actor_id: Authenticated requester; other colleagues cannot collect this result.
            job_id: Identity of this admitted and completed download attempt.
        """
        service = self.service
        with service.bo_probe.span(
            "collect_result", {"actor_id": actor_id, "job_id": job_id}
        ) as output:
            with service.store.read() as session:
                service._user(session, actor_id)
                job = session.scalar(
                    select(DownloadJob).where(DownloadJob.id == job_id)
                )
                if (
                    job is None
                    or job.state != "ready"
                    or (
                        not service._policy(
                            session, "collect_result", actor_id, job=job
                        )
                    )
                ):
                    raise PermissionDenied("result_unavailable")
                file = service._file(session, job.file_id)
                path, name = (service.results / job.result_name, file.name + ".zip")
            if not path.is_file():
                raise FileNotFoundError("prepared_result_missing")
            output.update(allowed=True, state="ready")
            return (path, name)

    def list_jobs(self, actor_id: str) -> list:
        """List this requester's attempts, including rejected jobs and preserved results.

        Args:
            actor_id: Authenticated requester whose jobs are visible.
        """
        service = self.service
        with service.bo_probe.span("list_jobs", {"actor_id": actor_id}) as output:
            with service.store.read() as session:
                service._user(session, actor_id)
                rows = session.execute(
                    select(DownloadJob, File)
                    .join(File)
                    .where(DownloadJob.requester_id == actor_id)
                    .order_by(DownloadJob.sequence.desc())
                )
                result = [
                    {
                        "id": j.id,
                        "name": f.name,
                        "state": j.state,
                        "admitted": j.admitted,
                        "error_code": j.error_code,
                    }
                    for j, f in rows
                ]
            output.update(count=len(result))
            return result
