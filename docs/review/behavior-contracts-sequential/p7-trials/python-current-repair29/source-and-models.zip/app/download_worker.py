"""Background scheduling for the existing native download operations."""

from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy import select

from .models import DownloadJob

if TYPE_CHECKING:
    from .service import Service


def run_worker(service: Service, interval: float = 1.0):
    """Process the application-owned FIFO queue, including admitted jobs after restart.

    Args:
        service: Existing application service and worker stop Event.
        interval: Queue polling interval in seconds; it does not grant permission.
    """
    while not service.stop_event.wait(interval):
        try:
            with service.store.read() as session:
                pending = session.scalar(
                    select(DownloadJob.id)
                    .where(DownloadJob.state == "preparing")
                    .order_by(DownloadJob.sequence)
                    .limit(1)
                )
                queued = session.scalar(
                    select(DownloadJob.id).where(DownloadJob.state == "queued").limit(1)
                )
            if pending:
                service.complete_preparation(pending)
                continue
            if queued is None:
                continue
            job = service.start_preparation()
            if job and job["state"] == "preparing":
                service.complete_preparation(job["id"])
        except Exception as error:
            service.worker_error = type(error).__name__
