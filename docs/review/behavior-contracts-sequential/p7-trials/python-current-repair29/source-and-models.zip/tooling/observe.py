"""Run actual native operations in on/off/fault modes and compare independent storage reads."""

from contextlib import closing
from io import BytesIO
from pathlib import Path
import json
import sqlite3
import sys
import tempfile
import zipfile
from unittest.mock import patch


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from app.service import PermissionDenied, Service
from bo_stategraph import BOStateGraph
from bo_stategraph.query import bo_native_machine
from integrations.bo_runtime import BOObservation
from tooling.http_scenarios import native_http, native_rejections
from tests.native_boundaries import NativeBoundaryService, snapshot_value_checks


def read_native(directory: Path) -> tuple:
    """Read domain rows and their latest commit witnesses independently of graph/probes.

    Args:
        directory: Native scenario database directory.
    """
    tables = {}
    actual = []
    with closing(sqlite3.connect(directory / "team.sqlite3")) as connection:
        connection.row_factory = sqlite3.Row
        connection.execute("BEGIN")
        for model_id, table in (("file", "files"), ("grant", "grants"), ("download-job", "download_jobs"), ("announcement", "announcements")):
            tables[table] = [dict(row) for row in connection.execute("SELECT * FROM " + table)]
            for row in tables[table]:
                identity = row["file_id"] + ":" + row["recipient_id"] if model_id == "grant" else row["id"]
                commit = connection.execute("SELECT * FROM transition_journal WHERE model_id=? AND instance_id=? ORDER BY sequence DESC LIMIT 1", (model_id, identity)).fetchone()
                actual.append({"model_id": model_id, "id": identity, "state": row["state"], "revision": row["revision"], "allowed": bool(commit["permission_allowed"]), "build_id": commit["build_id"]})
        tables["journals"] = [dict(row) for row in connection.execute("SELECT * FROM transition_journal ORDER BY sequence")]
        tables["account_summary"] = dict(zip(("count", "editors"), connection.execute("SELECT COUNT(*), SUM(editor) FROM users").fetchone()))
    return tables, actual


def read_native_transitions(directory: Path) -> dict:
    """Read committed native state applications independently from SQLite journals.

    Args:
        directory: Actual isolated runtime database directory.
    """
    result = {}
    with closing(sqlite3.connect(directory / "team.sqlite3")) as connection:
        connection.row_factory = sqlite3.Row
        for original in connection.execute("SELECT * FROM transition_journal ORDER BY sequence"):
            row = dict(original)
            value = {"model": "state-model:" + row["model_id"], "instance_id": row["instance_id"], "transaction_id": row["transaction_id"], "build_id": row["build_id"], "state": row["after"], "allowed": bool(row["permission_allowed"])}
            target = result.setdefault(row["model_id"], {"all": []})
            target["all"].append(value)
            target.setdefault(row["event"], []).append(value)
    return result


def scenario(case: str, mode: str, project: dict, build_id: str) -> dict:
    """Exercise one independent business scenario with real filesystem and SQLite effects.

    Args:
        case: Registered acceptance scenario identity.
        mode: Actual observation on/off/fault mode.
        project: Current canonical project envelope.
        build_id: Captured source build identity.
    """
    with tempfile.TemporaryDirectory(dir=ROOT / "review/runtime") as temporary:
        directory = Path(temporary)
        events, snapshots = [], []
        def sink(value, kind):
            """Retain the canonical probe's actual event envelope."""
            (events if kind == "events" else snapshots).append(value)
        observation = BOObservation(ROOT, mode, sink=sink, build_id=build_id)
        service = NativeBoundaryService(ROOT, directory, observation)
        try:
            observations = {}
            login_result = service.sign_in("alice", "demo-alice-123")
            file_id = service.upload_file("alice", "acceptance.txt", BytesIO(b"Native acceptance content\n"))
            service.manage_share("alice", file_id, "bob")
            observations["recipient_visible"] = len(service.list_files("bob")["files"]) == 1
            observations["outsider_visible"] = len(service.list_files("casey")["files"]) > 0
            job_id = service.request_download("bob", file_id)
            if case == "queued_revoked":
                service.manage_share("alice", file_id, "bob", True)
                service.start_preparation()
                service.manage_share("alice", file_id, "bob")
                observations["old_resumed"] = service.start_preparation() is not None
                try:
                    service.collect_result("bob", job_id)
                    observations["collect_allowed"] = True
                except PermissionDenied:
                    observations["collect_allowed"] = False
            else:
                service.start_preparation()
                if case == "started_revoked":
                    service.manage_share("alice", file_id, "bob", True)
                service.complete_preparation(job_id)
                observations["downloads"] = 0
                for _ in range(2):
                    path, _ = service.collect_result("bob", job_id)
                    with zipfile.ZipFile(path) as archive:
                        observations["bytes_match"] = archive.read("acceptance.txt") == b"Native acceptance content\n"
                    observations["downloads"] += 1
                observations["collect_allowed"] = True
            announcement_id = service.save_announcement("casey", "Announcement", "Independent board")
            service.save_announcement("casey", "Updated", "Updated body", announcement_id)
            observations["announcement_visible"] = service.list_announcements("bob")[0]["title"] == "Updated"
            service.save_announcement("casey", "", "", announcement_id, True)
            observations["deleted_hidden"] = service.list_announcements("alice") == []
            try:
                service.manage_share("casey", file_id, "bob")
                observations["editor_file_override"] = True
            except PermissionDenied:
                observations["editor_file_override"] = False
            service.list_jobs("bob")
            with patch("app.web.Service", NativeBoundaryService):
                native_http_records = native_http(ROOT, directory, observation, service)
            observations.update(native_rejections(service, directory, file_id, job_id))
            observations["cancellation"] = native_http_records["cancellation"]
            service.start_preparation()
            observation.bo_probe.flush(5)
            native, actual = read_native(directory)
            native_trace = observation.bo_request_facts.bo_values
            observations["job_state"] = native["download_jobs"][0]["state"]
            observations["admitted"] = bool(native["download_jobs"][0]["admitted"])
            primary = native["download_jobs"][0]
            admissions = [row for row in native["journals"] if row["model_id"] == "download-job" and row["instance_id"] == job_id and row["event"] == "start"]
            observations.update(visible=observations["outsider_visible"], started=bool(admissions), completed=primary["state"] == "ready", state=primary["state"], admission={"committed": bool(admissions and primary["admitted"] and admissions[0]["transaction_id"])}, fact_basis={**native_http_records["fact_basis"], **service.fact_basis})
            observations.update(test_accounts=native["account_summary"]["count"], editor_count=native["account_summary"]["editors"], password_valid=login_result["id"] == "alice", native_models=sorted({row["model_id"] for row in native["journals"]}))
            machine = bo_native_machine(directory / "team.sqlite3", build_id)
            graph = BOStateGraph(project["model"], build_id=build_id, mode="drive")
            instances = graph.bo_instances(machine)
            mapped = {(item["observed"]["state_model_id"], item["observed"]["instance_id"]): item["observed"] for item in instances}
            witnesses = []
            for row in actual:
                entry = mapped[(row["model_id"], row["id"])]
                for field in ("state", "revision", "build_id", "allowed"):
                    observed = entry["context"]["allowed"] if field == "allowed" else entry[field]
                    witnesses.append({"id": case + ":" + mode + ":" + row["model_id"] + ":" + row["id"] + ":" + field, "case": case, "mode": mode, "state_model_id": row["model_id"], "instance_id": row["id"], "field": field, "source": "tooling/observe.py::read_native", "projection": "bo_instances.context.allowed" if field == "allowed" else "bo_instances." + field, "actual": row[field], "mapped": observed, "passed": row[field] == observed})
            boundaries = service.boundaries + native_http_records["state_boundaries"]
            intermediate = snapshot_value_checks(events, snapshots, boundaries, case, mode)
            if mode == "on" and (not intermediate or not all(row["passed"] for row in intermediate)):
                raise AssertionError({"native_snapshot_value_mismatch": [row for row in intermediate if not row["passed"]]})
            witnesses.extend(intermediate)
            return {"case": case, "mode": mode, "events": events, "snapshots": snapshots, "observations": observations, "native_http": native_http_records["requests"], "native_trace": native_trace, "native_transitions": read_native_transitions(directory), "native_state_boundaries": boundaries, "snapshot_value_checks": intermediate, "native_definition": {"machines": service.workflow.definition["machines"]}, "policy_evaluations": list(service.rules.evaluations) + native_http_records["policy_evaluations"], "probe_health": observation.bo_health(), "authority_snapshot": {"instances": actual, **native}, "projection": {"build_id": build_id, "machine": machine, "instances": instances}, "mapping_checks": witnesses, "stategraph_export": graph.bo_export(runtime={"machine": machine})}
        finally:
            service.close()
            observation.close()


def main():
    """Write canonical observation JSON with real native witnesses at the top level."""
    project = json.loads((ROOT / "bo_stategraph/project.json").read_text(encoding="utf-8"))
    manifest = json.loads((ROOT / "manifest.json").read_text(encoding="utf-8"))
    (ROOT / "review/runtime").mkdir(parents=True, exist_ok=True)
    runs = [scenario(case, mode, project, manifest["build_id"]) for case in ("normal", "queued_revoked", "started_revoked") for mode in ("on", "off", "fault")]
    result = {"build_id": manifest["build_id"], "machine": runs[0]["native_definition"], "runs": runs, "mapping_checks": [w for run in runs for w in run["mapping_checks"]], "stategraph_export": runs[0]["stategraph_export"]}
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
