"""Real native Flask command paths used by the initial acceptance run."""

from contextlib import closing
from concurrent.futures import ThreadPoolExecutor
from io import BytesIO
import sqlite3
import threading
import zipfile

from app.service import PermissionDenied
from app.web import create_app


def native_http(root, directory, observation, service) -> dict:
    """Execute actual form commands and retain their independent native response statuses.

    Args:
        root: Application source root.
        directory: Isolated scenario data directory.
        observation: Canonical observation adapter for this scenario.
        service: Native domain service used to advance the actual queued job.
    """
    app = create_app(root, directory, start_worker=False, observation=observation)
    client, records = app.test_client(), []

    def send(method, path, data=None):
        """Record one actual test-client response and session boundary."""
        with client.session_transaction() as native:
            before = native.get("actor_id", "")
        response = client.open(path, method=method, data=data, content_type="multipart/form-data" if data and "file" in data else None, buffered=True)
        with client.session_transaction() as native:
            after = native.get("actor_id", "")
        records.append({"method": method, "path": path.split("?")[0], "status": response.status_code, "actor_before": before, "actor_after": after})
        return response

    def csrf():
        """Read the actual session token without exporting it."""
        with client.session_transaction() as native:
            return native["csrf"]

    def login(actor):
        """Authenticate a synthetic account through its real HTTP handler."""
        send("GET", "/login")
        result = send("POST", "/login", {"csrf": csrf(), "username": actor, "password": "demo-" + actor + "-123"})
        assert result.status_code == 303

    def read_job(identity):
        """Read a committed attempt and its ordered journal through independent SQL."""
        with closing(sqlite3.connect(directory / "team.sqlite3")) as connection:
            connection.row_factory = sqlite3.Row
            row = dict(connection.execute("SELECT * FROM download_jobs WHERE id=?", (identity,)).fetchone())
            journal = [dict(item) for item in connection.execute("SELECT * FROM transition_journal WHERE model_id='download-job' AND instance_id=? ORDER BY sequence", (identity,))]
        return row, journal

    def enqueue(file_identity):
        """Create a real HTTP request and read its newly committed identity from SQL."""
        assert send("POST", "/files/" + file_identity + "/downloads", {"csrf": csrf()}).status_code == 303
        with closing(sqlite3.connect(directory / "team.sqlite3")) as connection:
            return connection.execute("SELECT id FROM download_jobs WHERE file_id=? AND requester_id='bob' ORDER BY sequence DESC LIMIT 1", (file_identity,)).fetchone()[0]

    try:
        assert send("GET", "/health").status_code == 200
        assert send("GET", "/").status_code == 302
        send("GET", "/login")
        assert send("POST", "/login", {"username": "bob", "password": "demo-bob-123"}).status_code == 400
        login("alice")
        assert send("GET", "/").status_code == 200
        assert send("POST", "/files", {"csrf": csrf(), "file": (BytesIO(b"Real HTTP upload bytes"), "http-acceptance.txt")}).status_code == 303
        with closing(sqlite3.connect(directory / "team.sqlite3")) as connection:
            file_id = connection.execute("SELECT id FROM files WHERE name='http-acceptance.txt'").fetchone()[0]
        assert send("POST", "/files/" + file_id + "/share", {"csrf": csrf(), "recipient_id": "bob"}).status_code == 303
        login("bob")
        assert send("POST", "/files/" + file_id + "/downloads", {"csrf": csrf()}).status_code == 303
        jobs = send("GET", "/api/jobs").get_json()
        job_id = next(job["id"] for job in jobs if job["name"] == "http-acceptance.txt")
        assert service.start_preparation()["id"] == job_id
        service.complete_preparation(job_id)
        result = send("GET", "/downloads/" + job_id + "/result")
        assert result.status_code == 200
        with zipfile.ZipFile(BytesIO(result.data)) as archive:
            assert archive.read("http-acceptance.txt") == b"Real HTTP upload bytes"
        assert send("POST", "/files/" + file_id + "/share", {"csrf": csrf(), "recipient_id": "bob", "action": "revoke"}).status_code == 403
        assert send("POST", "/downloads/" + job_id + "/cancel", {"csrf": csrf()}).status_code == 409
        cancelled = enqueue(file_id)
        cancellation_path = "/downloads/" + cancelled + "/cancel"
        assert cancellation_path in send("GET", "/?tab=downloads").get_data(as_text=True)
        assert send("POST", cancellation_path).status_code == 400
        login("alice")
        owner_status = send("POST", cancellation_path, {"csrf": csrf()}).status_code
        assert owner_status == 403
        login("casey")
        editor_status = send("POST", cancellation_path, {"csrf": csrf()}).status_code
        assert editor_status == 403
        assert read_job(cancelled)[0]["state"] == "queued"
        login("bob")
        assert send("POST", cancellation_path, {"csrf": csrf()}).status_code == 303
        cancelled_row, cancelled_journal = read_job(cancelled)
        assert (cancelled_row["state"], cancelled_row["revision"], cancelled_row["admitted"]) == ("cancelled", 2, 0)
        assert [item["event"] for item in cancelled_journal] == ["request", "cancel"]
        assert send("POST", cancellation_path, {"csrf": csrf()}).status_code == 409
        assert send("GET", "/downloads/" + cancelled + "/result").status_code == 403
        cancelled_page = send("GET", "/?tab=downloads").get_data(as_text=True)
        assert "本次任务已取消" in cancelled_page and cancellation_path not in cancelled_page
        assert service.start_preparation() is None
        fresh = enqueue(file_id)
        assert fresh != cancelled
        assert service.start_preparation()["id"] == fresh
        started_status = send("POST", "/downloads/" + fresh + "/cancel", {"csrf": csrf()}).status_code
        assert started_status == 409
        service.complete_preparation(fresh)
        fresh_result = send("GET", "/downloads/" + fresh + "/result")
        assert fresh_result.status_code == 200
        with zipfile.ZipFile(BytesIO(fresh_result.data)) as archive:
            assert archive.read("http-acceptance.txt") == b"Real HTTP upload bytes"

        raced = enqueue(file_id)
        gate = threading.Barrier(2)
        race_token = csrf()

        def compete_cancel():
            """Submit the actual authenticated form when both contenders are ready."""
            gate.wait(timeout=10)
            return send("POST", "/downloads/" + raced + "/cancel", {"csrf": race_token}).status_code

        def compete_start():
            """Let the real worker contend for the same committed queued state."""
            gate.wait(timeout=10)
            return service.start_preparation()

        with ThreadPoolExecutor(max_workers=2) as executor:
            cancel_future = executor.submit(compete_cancel)
            start_future = executor.submit(compete_start)
            race_status, start_result = cancel_future.result(timeout=35), start_future.result(timeout=35)
        race_row, race_journal = read_job(raced)
        exits = [item for item in race_journal if item["before"] == "queued"]
        race_valid = len(exits) == 1 and race_row["revision"] == 2 and (
            (race_status == 303 and start_result is None and race_row["state"] == "cancelled" and exits[0]["event"] == "cancel" and not race_row["admitted"])
            or (race_status == 409 and start_result is not None and start_result["id"] == raced and race_row["state"] == "preparing" and exits[0]["event"] == "start" and bool(race_row["admitted"]))
        )
        assert race_valid
        if race_row["state"] == "preparing":
            service.complete_preparation(raced)
        queued_before_revoke = enqueue(file_id)
        login("alice")
        assert send("POST", "/files/" + file_id + "/share", {"csrf": csrf(), "recipient_id": "bob", "action": "revoke"}).status_code == 303
        login("bob")
        assert send("POST", "/downloads/" + queued_before_revoke + "/cancel", {"csrf": csrf()}).status_code == 303
        assert send("POST", "/files/" + file_id + "/downloads", {"csrf": csrf()}).status_code == 403
        final_cancelled, final_journal = read_job(cancelled)
        fresh_row, _ = read_job(fresh)
        cancellation = {"queued_cancelled": cancelled_row["state"] == "cancelled", "cancelled_admitted": bool(cancelled_row["admitted"]), "owner_override": owner_status != 403, "editor_override": editor_status != 403, "started_cancelled": started_status != 409, "started_still_collectible": fresh_result.status_code == 200 and fresh_row["state"] == "ready", "cancelled_terminal": final_cancelled == cancelled_row and final_journal == cancelled_journal, "fresh_attempt_distinct": fresh != cancelled, "fresh_attempt_ready": fresh_row["state"] == "ready", "first_transition_wins": race_valid}
        login("casey")
        assert send("POST", "/announcements", {"csrf": csrf(), "title": "HTTP publication", "body": "Actual native form"}).status_code == 303
        with closing(sqlite3.connect(directory / "team.sqlite3")) as connection:
            notice = connection.execute("SELECT id FROM announcements WHERE title='HTTP publication'").fetchone()[0]
        assert send("GET", "/?tab=board").status_code == 200
        assert send("POST", "/announcements", {"csrf": csrf(), "announcement_id": notice, "title": "HTTP edited", "body": "Updated native text"}).status_code == 303
        assert send("POST", "/announcements", {"csrf": csrf(), "announcement_id": notice, "action": "delete"}).status_code == 303
        assert send("POST", "/logout", {"csrf": csrf()}).status_code == 303
        return {"requests": records, "policy_evaluations": list(app.extensions["service"].rules.evaluations), "fact_basis": dict(app.extensions["service"].fact_basis), "state_boundaries": list(getattr(app.extensions["service"], "boundaries", [])), "cancellation": cancellation, "cancellation_race": {"job_id": raced, "cancel_status": race_status, "worker_result": start_result, "native_row": race_row, "native_journal": race_journal}}
    finally:
        app.extensions["service"].close()


def native_rejections(service, directory, file_id, job_id):
    """Exercise actual rejection exits without changing the independent success expectations.

    Args:
        service: Native scenario service.
        directory: Scenario's isolated database directory.
        file_id: Actual original file owned by Alice.
        job_id: Actual primary download attempt.
    """
    result = {}
    try:
        service.manage_share("bob", file_id, "casey")
        result["allowed"] = True
    except PermissionDenied:
        result["allowed"] = False
    with closing(sqlite3.connect(directory / "team.sqlite3")) as connection:
        connection.execute("INSERT INTO announcements(id,author_id,title,body,state,revision,created_at) VALUES(?,?,?,?,?,?,?)", ("other-author-fixture", "alice", "Independent owner fixture", "Synthetic fixture for the own-author boundary", "published", 0, "2026-01-01"))
        connection.commit()
    try:
        for delete, key in ((False, "edit_allowed"), (True, "delete_allowed")):
            try:
                service.save_announcement("casey", "Attempt", "Attempt", "other-author-fixture", delete)
                result[key] = True
            except PermissionDenied:
                result[key] = False
    finally:
        with closing(sqlite3.connect(directory / "team.sqlite3")) as connection:
            connection.execute("DELETE FROM announcements WHERE id=?", ("other-author-fixture",))
            connection.commit()
    calls = [
        lambda: service.sign_in("alice", "incorrect"),
        lambda: service.upload_file("missing-user", "denied.txt", BytesIO(b"Not committed")),
        lambda: service.list_files("missing-user"),
        lambda: service.manage_share("casey", file_id, "bob"),
        lambda: service.manage_share("casey", file_id, "bob", True),
        lambda: service.request_download("casey", file_id),
        lambda: service.complete_preparation("missing-job"),
        lambda: service.collect_result("casey", job_id),
        lambda: service.list_jobs("missing-user"),
        lambda: service.list_announcements("missing-user"),
        lambda: service.save_announcement("bob", "Denied", "Not an editor"),
        lambda: service.save_announcement("bob", "Denied", "Not an editor", "missing-notice"),
        lambda: service.save_announcement("bob", "", "", "missing-notice", True),
    ]
    for call in calls:
        try:
            call()
        except PermissionDenied:
            continue
        raise AssertionError("Expected an actual native permission rejection")
    # An explicitly corrupt isolated fixture exercises the worker's native error
    # boundary. It is never presented as a successful application-generated row.
    with closing(sqlite3.connect(directory / "team.sqlite3")) as connection:
        connection.execute("INSERT INTO download_jobs(id,file_id,requester_id,grant_revision,state,revision,admitted,result_name,error_code,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)", ("corrupt-worker-fixture", "missing-file", "bob", 0, "queued", 0, 0, "", "", "2026-01-01"))
        connection.commit()
    try:
        try:
            service.start_preparation()
        except PermissionDenied:
            pass
        else:
            raise AssertionError("Corrupt native fixture should be rejected")
    finally:
        with closing(sqlite3.connect(directory / "team.sqlite3")) as connection:
            connection.execute("DELETE FROM download_jobs WHERE id=?", ("corrupt-worker-fixture",))
            connection.commit()
    return result
