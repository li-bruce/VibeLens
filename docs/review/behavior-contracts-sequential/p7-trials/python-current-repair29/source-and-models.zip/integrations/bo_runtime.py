"""Canonical native probe integration; transport failure cannot authorize or reject work."""

from contextlib import contextmanager, ExitStack
from contextvars import ContextVar
from pathlib import Path
import json
import os
import sys

from bo_stategraph.bo_probe import BOProbe
from bo_stategraph.bo_capture import BOCaptureClient


class BOObservation:
    """Capture selected actual service values and model-qualified native snapshots."""

    def __init__(self, root: Path, mode: str = "on", sink=None, build_id: str | None = None, capacity: int = 2048):
        """Bind the canonical probe to a local test sink or the actual external collector.

        Args:
            root: Project source root with its canonical model and manifest.
            mode: Capture mode: on, off, or deliberately failing transport.
            sink: Optional actual event sink for independent verification.
            build_id: Current captured build identity, required when no collector settings exist.
            capacity: Bounded native transport queue capacity.
        """
        root = Path(root)
        self.bo_root = root
        project = json.loads((root / "bo_stategraph/project.json").read_text(encoding="utf-8"))
        settings_path = root / ".stategraph/collector.json"
        settings = json.loads(settings_path.read_text(encoding="utf-8")) if settings_path.exists() else {}
        if build_id is None:
            build_id = settings.get("build_id") or json.loads((root / "manifest.json").read_text(encoding="utf-8"))["build_id"]
        self.bo_errors = 0
        self.bo_capture = None
        self.bo_effects = ContextVar("bo_transaction_effects", default=None)
        if mode == "fault":
            sink = self.bo_fault_sink
        # Optional tooling runs under its canonical package namespace. The native
        # executor and all business operations remain project-local dependencies.
        installation = json.loads((root / "tooling/vibelens.json").read_text(encoding="utf-8"))
        skill = (root / installation["skill_root"]).resolve()
        sys.path.insert(0, str(skill / "scripts"))
        os.environ.setdefault("OTEL_SEMCONV_STABILITY_OPT_IN", "http")
        from bo_observer.adapters.python.bo_probe import BOProbe as BOCanonicalProbe
        from bo_observer.adapters.python.bo_otel import BOOpenTelemetry, BOOpenTelemetryProcessor
        from opentelemetry.sdk.trace import TracerProvider
        self.bo_probe = BOCanonicalProbe(project, build_id, enabled=mode != "off", sink=sink, endpoint=settings.get("endpoint", ""), token=settings.get("token", ""), capacity=capacity)
        self.bo_provider = TracerProvider()
        self.bo_tracing = self.bo_probe.bo_bind_tracing(BOOpenTelemetry(self.bo_provider.get_tracer("team-files")))
        from .bo_http import BONativeRequestFacts
        configuration = json.loads((root / "bo_stategraph/telemetry.json").read_text(encoding="utf-8"))
        self.bo_request_facts = BONativeRequestFacts(configuration["registrations"])
        from bo_observer.data.runtime import BODataRuntime
        self.bo_data = BODataRuntime(self.bo_probe, json.loads((root / "bo_stategraph/databases.json").read_text(encoding="utf-8")))
        self.bo_provider.add_span_processor(self.bo_request_facts)
        self.bo_provider.add_span_processor(BOOpenTelemetryProcessor(self.bo_tracing, configuration))
        if sink is None and settings and mode == "on":
            try:
                self.bo_capture = BOCaptureClient(self.bo_probe).start()
            except Exception:
                self.bo_errors += 1

    def bo_instrument_app(self, app):
        """Install the canonical Flask boundary ahead of existing CSRF/auth guards.

        Args:
            app: Actual Flask application, before its first request.
        """
        from bo_observer.adapters.python.bo_otel import bo_instrument_flask
        from .bo_http import bo_response_facts
        bo_instrument_flask(app, tracer_provider=self.bo_provider, excluded_urls="/static/.*, /api/stategraph", response_hook=bo_response_facts)

    def bo_attach_storage(self, engine):
        """Attach driver listeners to this actual application engine.

        Args:
            engine: Native SQLAlchemy engine created by the application.
        """
        self.bo_data.attach_sqlalchemy(engine)

    @contextmanager
    def bo_transaction(self, manager):
        """Observe the application's actual commit acknowledgement or rollback.

        Args:
            manager: Existing native transaction manager; it owns all effects.
        """
        with self.bo_data.transaction("db-transaction", self.bo_native_transaction(manager), entity="application", attempt="application", scope="application") as session:
            yield session

    @contextmanager
    def bo_native_transaction(self, manager):
        """Finish registered effect intervals only after the native manager acknowledges commit.

        Args:
            manager: Unmodified application transaction manager, entered exactly once.
        """
        with ExitStack() as scope:
            completed = []
            token = self.bo_effects.set((scope, completed))
            try:
                with manager as session:
                    yield session
                for output in completed:
                    output["committed"] = True
            finally:
                self.bo_effects.reset(token)

    def bo_admission_started(self, transaction_id: str, job_id: str):
        """Open a real admission interval before mutation, closed by native commit or rollback.

        Args:
            transaction_id: Already allocated native transaction identity, known at entry.
            job_id: Actual attempt whose allowed start is about to apply record_admission.
        """
        try:
            active = self.bo_effects.get()
            if active is None:
                raise RuntimeError("admission observation requires the native transaction")
            scope, completed = active
            output = {"transaction_id": transaction_id}
            call = scope.enter_context(self.bo_probe.span("admission_transaction", lambda: {"inputs": {"transaction_id": transaction_id, "job_id": job_id}, "outputs": {"transaction_id": transaction_id}}, scope="application"))
            call.result(lambda: {"outputs": output})
            completed.append(output)
        except Exception:
            self.bo_errors += 1

    @contextmanager
    def bo_query_scope(self, write: bool = False):
        """Select actual driver work without reading or consuming result cursors.

        Args:
            write: Native transaction bodies may issue reads and writes.
        """
        with self.bo_data.operation("db-write" if write else "db-read", entity="application", attempt="application", scope="application"):
            yield

    @staticmethod
    def bo_fault_sink(value: dict, kind: str):
        """Raise an actual sink error to verify application/observer isolation.

        Args:
            value: Real native observation queued by the canonical probe.
            kind: Canonical events or snapshots channel.
        """
        raise OSError("deliberate_observer_transport_failure")

    def bo_policy(self, value: dict):
        """Record actual completed expression facts without executing another decision.

        Args:
            value: Native evaluator's actual check and visited dependencies.
        """
        try:
            from bo_observer.policy.recording import record_evaluation
            policy = self.bo_probe.bo_model["policy"] if hasattr(self.bo_probe, "bo_model") else json.loads((self.bo_root / "bo_stategraph/project.json").read_text(encoding="utf-8"))["model"]["policy"]
            for step in value["trace"]:
                self.bo_request_facts.bo_point("policy:" + step["node"], "decision", value["check_id"])
            record_evaluation(policy, value, self.bo_probe, entity="application", attempt="application")
        except Exception:
            self.bo_errors += 1

    def bo_guard(self, node: str, value: bool):
        """Record the Boolean actually returned by the native executor's guard callback.

        Args:
            node: Guard bound to its concrete machine and rule operation.
            value: Actual callback result.
        """
        self.bo_request_facts.bo_point(node, "decision")
        self.bo_probe.record(node, "decision", lambda: {"outputs": {"value": value}})

    @contextmanager
    def span(self, node: str, values: dict):
        """Observe a real service invocation without swallowing its native exception.

        Args:
            node: Source-bound business operation identity.
            values: Selected native input values, with secrets excluded.
        """
        output = {}
        with self.bo_probe.span(node, lambda: {"inputs": values}, scope="application") as call:
            yield output
            if output.get("transaction_id"):
                from opentelemetry import trace
                trace.get_current_span().set_attribute("app.transaction_id", output["transaction_id"])
            call.result(lambda: {"outputs": output})

    def bo_before_transition(self, value: dict):
        """Capture native pre-state at the read boundary, before running the executor.

        Args:
            value: Actual native version context plus the separate current decision.
        """
        probe = self.bo_probe
        self.bo_request_facts.bo_point("state_before", "read")
        event_id = probe.record("state_before", "read", lambda: {"outputs": value}, revision=value["revision"])
        if event_id is not None:
            probe.snapshot(value["instance_id"], value["state"], value["context"], value["revision"], event_id, state_model_id=value["model_id"])

    def bo_transition(self, value: dict):
        """Capture a real committed transition and its same-revision native snapshot.

        Args:
            value: Actual committed journal values and admission effect.
        """
        probe = self.bo_probe
        self.bo_request_facts.bo_point("state_commit", "commit")
        event_id = probe.record("state_commit", "commit", lambda: {"outputs": {**value, "committed": True}}, revision=value["revision"])
        if event_id is not None:
            probe.snapshot(value["instance_id"], value["after"], {"allowed": value["allowed"]}, value["revision"], event_id, event=value["event"], guards=value["guards"], payload=value["payload"], state_model_id=value["model_id"])

    def bo_health(self) -> dict:
        """Return actual producer and registration counters."""
        return {**self.bo_probe.bo_health(), "bootstrap_errors": self.bo_errors, "request_fact_errors": self.bo_request_facts.bo_errors, "database_errors": self.bo_data.bo_errors}

    def close(self):
        """Drain actual queued observations before closing acknowledged capture controls."""
        self.bo_probe.flush(5)
        if self.bo_capture:
            self.bo_capture.close()
        self.bo_provider.shutdown()
        self.bo_probe.close()
