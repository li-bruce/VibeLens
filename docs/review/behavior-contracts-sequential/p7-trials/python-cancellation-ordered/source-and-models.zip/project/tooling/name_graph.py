"""Author bilingual captions from reviewed business wording and exact source roles."""

from pathlib import Path
import json
import re


ROOT = Path(__file__).resolve().parents[1]
WORDS = {"actor_id": "当前同事", "logged_in": "已登录", "is_editor": "公告编辑员", "owner_id": "文件上传者", "recipient_id": "共享接收同事", "grant_active": "当前共享有效", "grant_fresh": "申请所用共享仍有效", "job_requester": "本次下载申请人", "job_admitted": "本次已获准备资格", "announcement_author": "公告作者", "is_owner": "当前同事是上传者", "is_recipient": "当前同事是接收人", "is_job_requester": "当前同事是申请人", "is_announcement_author": "当前同事是公告作者", "current_recipient": "当前接收人的共享有效", "current_file_access": "上传者或有效接收人", "interactive_file_access": "登录且可访问文件", "file_management": "登录且为上传者", "collection_entitlement": "申请人已有本次准备资格", "editor_publication": "登录且为公告编辑员", "own_announcement_management": "编辑员管理自己的公告", "preparation_access": "本次申请可以开始准备", "allowed": "本次权限判定", "value": "实际值", "status": "实际结果", "state": "当前状态", "before": "切换前", "after": "切换后", "revision": "原生版本", "build_id": "程序构建", "instance_id": "对象实例", "transaction_id": "原生事务", "file_id": "文件标识", "job_id": "本次下载标识", "model_id": "状态模型", "model_ref": "模型定义引用", "event": "实际切换事件", "admitted": "本次准备资格", "committed": "事务已提交", "grant_revision": "申请时的共享版本", "active": "共享有效", "inactive": "无共享权限", "absent": "尚未保存", "available": "已保存", "not_requested": "尚未申请", "queued": "排队等待", "preparing": "正在准备", "ready": "可领取", "rejected": "无法准备", "unpublished": "尚未发布", "published": "已发布", "deleted": "已删除", "username": "登录账号", "password_provided": "已填写密码", "actor_before": "请求开始时的同事", "actor_after": "响应完成时的同事", "filename": "文件显示名称", "size": "实际字节数", "count": "实际数量", "error": "原生异常", "error_type": "原生异常类型", "title_length": "标题字数", "body_length": "正文字数", "announcement_id": "公告标识", "delete": "删除操作", "revoke": "撤销操作", "found": "找到排队任务", "bo_check": "本次规则检查", "bo_basis": "事实读取依据", "left": "待比较身份", "right": "目标身份", "rows": "驱动返回的行数", "rows_known": "驱动行数已知", "statement": "脱敏查询形状", "parameters": "已选择参数", "result": "实际查询摘要", "targets": "实际访问资源", "unknown_targets": "未解析的资源", "target_source": "访问资源的来源", "target_access": "资源读写方向", "duration_ms": "实际耗时", "operation": "实际数据操作", "input_count": "输入数量", "output_count": "输出数量", "editor": "公告编辑员身份", "author_id": "公告作者", "requester_id": "下载申请人", "name": "显示名称", "title": "公告标题", "body": "公告正文", "created_at": "创建时间", "error_code": "原生原因", "result_name": "准备结果位置", "sequence": "原生先后顺序", "guards": "实际切换判定", "permission_allowed": "事务中的权限结果", "password_hash": "密码校验摘要", "action": "资源访问方式", "target": "目标资源"}
FUNCTIONS = {"sign_in": "验证账号密码", "upload_file": "保存上传文件", "list_files": "列出可见文件", "manage_share": "管理同事共享", "request_download": "创建下载申请", "start_preparation": "开始或拒绝本次准备", "complete_preparation": "生成已准入的下载包", "collect_result": "读取本次下载结果", "list_jobs": "列出本人的下载任务", "list_announcements": "读取已发布公告", "save_announcement": "维护编辑员自己的公告", "_policy": "读取事实并执行规则", "_access": "读取当前文件权限", "_user": "核对当前账号", "_file": "读取指定文件", "_change": "执行并保存状态切换", "run_worker": "执行下载准备队列", "start_worker": "启动准备后台", "close": "关闭原生资源", "step": "按声明切换原生状态", "allowed_guard": "返回本次准入判定", "bind_guard": "绑定机器判定", "same_identity": "比较两端身份", "can_access": "检查文件访问条件", "can_manage": "检查上传者身份", "can_edit_announcement": "检查编辑员及公告作者", "evaluate": "执行共享规则", "visit": "按依赖短路求值", "transaction": "执行读写事务", "_transaction": "提交或回滚原生事务", "read": "读取当前数据", "configure_connection": "配置数据库连接", "create_app": "创建文件共享应用", "request_identity": "读取会话并核对请求", "response_headers": "设置实际响应头", "authenticated": "要求登录身份", "checked": "执行已登录请求", "home": "显示团队工作空间", "login": "显示或提交登录", "logout": "退出当前账号", "upload": "接收上传文件", "share": "提交共享或撤销", "enqueue": "提交新的下载申请", "collect": "发送本次下载包", "announcement": "提交自己的公告变更", "job_status": "读取本人的任务状态", "health": "读取服务就绪状态", "denied": "显示实际权限拒绝", "invalid": "显示输入错误", "now": "读取当前创建时间", "read_native": "独立读取原生数据库", "read_native_transitions": "独立读取切换事务记录", "scenario": "执行真实业务验收场景", "native_http": "执行真实页面请求", "native_rejections": "核对实际拒绝边界", "implementation": "登记源码与参数覆盖", "prepare_discovery": "保留确认并绑定原生表示", "bind": "连接概念与实际实现", "build": "生成当前实现图", "build_behavior": "绑定四类对象的生命周期", "configuration": "登记实际数据库与访问", "write": "保存当前生成结果", "bo_export_metadata": "只读导出原生数据模型", "bo_sdk_fact": "独立读取真实 SDK 身份", "bo_point": "读取本次 SDK 调用上下文", "bo_policy": "记录实际规则求值", "bo_guard": "记录原生判定结果", "bo_transaction": "观察实际提交或回滚", "bo_query_scope": "观察实际驱动操作", "bo_attach_storage": "连接原生驱动观察", "bo_native_machine": "只读查询原生实例", "bo_export_native": "只读导出原生状态", "bo_health": "读取实际采集健康", "bo_before_transition": "记录原生切换前状态", "bo_transition": "记录真实事务完成", "bo_instrument_app": "观察完整 HTTP 边界", "bo_response_facts": "读取响应时的原生会话", "bo_fault_sink": "验证真实传输故障", "span": "观察实际函数调用", "main": "执行该模块入口"}
WORDS["context_allowed"] = "该版本最后提交的判定"
WORDS.update(cancelled="已取消", cancellation_identity="登录且为本次申请人", cancel="取消本次排队任务")
FUNCTIONS.update(cancel_download="取消本次排队任务", cancel="提交本次任务取消", state_conflict="显示任务状态冲突")
FUNCTIONS.update(read_boundary="独立读取原生前后版本", snapshot_value_checks="逐项核对快照与原生 SQL")
PHRASES = {"Requires": "需要所列条件", "Implemented by": "由原生函数实现", "Rule expression": "共享规则表达式", "Implemented state": "对应原生状态", "Commit native state": "提交本次原生状态", "Transition guarded by": "切换所需的规则", "Decision reads fact": "规则使用的原生事实", "Transition has effect": "切换触发的准入保存", "AND": "全部满足", "OR": "任一满足", "and": "全部满足", "or": "任一满足", "all": "全部满足", "any": "任一满足", "left": "待比较身份", "right": "目标身份", "contains": "包含", "read": "读取", "write": "写入", "transaction": "事务完成", "primary key": "主键", "foreign key": "外键", "primary_key": "主键", "foreign_key": "外键", "index": "索引", "Source": "实际源码", "Guards": "切换条件", "State": "对象状态"}


def main():
    """Maintain exact current fingerprints after reviewing the affected source meanings."""
    inventory = json.loads((ROOT / "review/name-inventory-final.json").read_text(encoding="utf-8"))
    previous = json.loads((ROOT / "bo_stategraph/config/semantic-names.json").read_text(encoding="utf-8"))
    output = {"schema": "bo-semantic-names/v1", "locales": ["en", "zh-CN"], "names": {}, "basis": {}}
    api = {"api:GET:/": "显示团队页面", "api:GET:/login": "显示登录页", "api:POST:/login": "提交账号登录", "api:POST:/logout": "退出当前账号", "api:POST:/files": "上传文件入口", "api:POST:/files/<file_id>/share": "共享或撤销入口", "api:POST:/files/<file_id>/downloads": "申请下载入口", "api:GET:/downloads/<job_id>/result": "领取下载包入口", "api:POST:/announcements": "维护自己公告入口", "api:GET:/api/jobs": "读取本人任务入口", "api:GET:/health": "读取服务就绪"}
    folders = {"app": "业务实现", "templates": "页面模板", "static": "页面样式", "tests": "独立验收", "tooling": "项目检查与生成", "integrations": "独立观测接入", "bo_stategraph": "原生声明与执行", "Project": "文件共享工程", "python-retest-app": "文件共享应用"}
    api["api:POST:/downloads/<job_id>/cancel"] = "取消本次排队任务入口"
    for item in inventory["items"]:
        category, identity = item["category"], item["id"]
        label = str(item.get("label") or identity.rsplit(":", 1)[-1])
        old = previous.get("names", {}).get(category, {}).get(identity, {})
        english = old.get("en") or (identity.replace("business-network:", "").replace("state-model:", "").replace("_", " ").replace(":", " · ") if re.search(r"[\u4e00-\u9fff]", label) else label)
        chinese = old.get("zh-CN")
        if identity in api:
            chinese = api[identity]
        elif identity == "native_transition":
            chinese = "应用原生状态切换"
        elif identity == "admission_transaction":
            english, chinese = "Commit preparation admission", "提交本次准备资格"
        elif identity.startswith("native-guard:"):
            chinese = {"may_upload": "允许上传", "may_manage": "允许上传者管理共享", "may_request": "允许新的下载申请", "may_start": "允许本次开始准备", "may_cancel": "允许本人取消排队任务", "may_publish": "允许编辑员发布", "may_manage_own": "允许编辑员管理自己公告"}[identity.rsplit(":", 1)[-1]]
        elif identity.startswith("policy:") and identity.rsplit(":", 1)[-1] in WORDS:
            chinese = WORDS[identity.rsplit(":", 1)[-1]]
        elif category in ("states", "events") or identity.startswith("native-state:"):
            qualified = json.loads(identity) if identity.startswith("[") else []
            value = item.get("value") or (qualified[-1] if qualified else identity.rsplit(":", 1)[-1])
            if category in ("states", "events") and qualified:
                english = value.replace("_", " ").capitalize()
            chinese = WORDS.get(value) or {"upload": "上传成功", "share": "分享给同事", "revoke": "撤销该同事共享", "request": "申请本次下载", "start": "确认资格并开始", "reject": "共享已撤销而终止", "complete": "本次准备完成", "publish": "发布公告", "edit": "修改自己的公告", "delete": "删除自己的公告"}.get(value, label)
        elif not chinese and category == "edges":
            chinese = PHRASES.get(label) or (label if re.search(r"[\u4e00-\u9fff]", label) else "关联 · " + label)
        elif not chinese and item.get("layer") == "symbols":
            chinese = WORDS.get(label, "所选字段 · " + label)
        elif not chinese and item.get("code_role") in ("directory", "file"):
            chinese = folders.get(label, "源文件 · " + label if item["code_role"] == "file" else "源码目录 · " + label)
        elif not chinese and item.get("code_role") == "parameter":
            chinese = WORDS.get(label, "原生参数 · " + label)
        elif not chinese and item.get("source"):
            symbol = item["source"].get("symbol", "")
            chinese = FUNCTIONS.get(symbol.rsplit(".", 1)[-1], "原生函数 · " + label)
        elif not chinese and item.get("data_role"):
            chinese = WORDS.get(label, {"store": "团队数据库", "dataset": "数据表 · " + label, "field": "数据字段 · " + label}.get(item["data_role"], "数据操作 · " + label))
        if not chinese:
            chinese = WORDS.get(label) or PHRASES.get(label) or (label if re.search(r"[\u4e00-\u9fff]", label) else "源码元素 · " + label)
        if identity == "business-network:authentication":
            english, chinese = "Team account login", "团队账号登录"
        if identity in ("cancel_download", "cancelled_download"):
            english, chinese = {"cancel_download": ("Cancel queued download", "取消本次排队任务"), "cancelled_download": ("Cancelled attempt", "本次任务已取消")}[identity]
        if old.get("en") and old.get("zh-CN"):
            english, chinese = old["en"], old["zh-CN"]
        captions = {}
        for locale, caption in (("en", english), ("zh-CN", chinese)):
            caption = re.sub(r"[\x00-\x20\x7f]+", " ", caption).strip()
            captions[locale] = caption if len(caption) <= 60 else caption[:59].rstrip() + "…"
        output["names"].setdefault(category, {})[identity] = captions
        output["basis"].setdefault(category, {})[identity] = item["basis"]
    (ROOT / "review/semantic-names-final.json").write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"captions": len(inventory["items"]), "categories": {key: len(value) for key, value in output["names"].items()}}))


if __name__ == "__main__":
    main()
