"""Bind reviewed conceptual definitions to actual native sources and independent cases."""

from copy import deepcopy
import json
from pathlib import Path


def prepare_discovery(root: Path):
    """Represent native decision context without changing the user's business rules.

    Args:
        root: Isolated application project root.
    """
    path = root / "discovery.json"
    doc = json.loads(path.read_text(encoding="utf-8"))
    if not any(item["id"] == "I_NATIVE_BINDING" for item in doc["sources"]):
        doc["sources"].append({"id": "I_NATIVE_BINDING", "kind": "inference", "text": "Technical binding: each flat native guard consumes the already acquired Boolean allowed decision. At preparation start the grant generation pinned by this request must still match; this implements the explicit instruction that revocation does not let an old queued request revive after re-sharing. Grant generation is an implementation detail, not an additional user role or lifecycle.", "locator": "Current coding batch; app/service.py::Service._policy and app/rules.py::Rules.evaluate; subject to source and runtime checks."})
    if not any(item["id"] == "A_BINDING_RECAP" for item in doc["sources"]):
        doc["sources"].append({"id": "A_BINDING_RECAP", "kind": "assistant", "text": "补齐后的图仍按你已确认的规则连接：文件上传后可用，上传者和当前接收人可见，只有上传者能管理共享；每位同事共享独立无权限和有效切换；下载排队、准备中、可领取，轮到准备时已撤销则终止，重新共享需新申请，已开始的可完成并重复领取；公告未发布、已发布、已删除，登录可读，编辑员只管理自己公告。实际读取登录身份、上传者、当前共享、申请人、准入和作者；准入和准备中在同一事务保存。沿用之前确认，不再提出业务选择。", "locator": "Current chat commentary during initial mapping acceptance, after the 434ff9d4 skill migration instruction; actual earlier user answers remain U_RULES, U_SETUP, U_FINAL_STATES."})
    for machine in doc["state_models"]:
        machine["context"] = {"allowed": {"type": "boolean"}}
        for event in machine["events"].values():
            event["payload"] = {"allowed": {"type": "boolean"}}
    if not any(item["id"] == "U_REPAIR11_CONTEXT" for item in doc["sources"]):
        doc["sources"].append({"id": "U_REPAIR11_CONTEXT", "kind": "user", "text": "版本化 context 与当前事件的 typed payload/判定事实要分清，独立原生读必须与前后快照相符。不能为了观察增加虚假版本、过滤冲突读或删掉保护检查。当前 context.allowed 的独立检查也要保持等价覆盖。", "locator": "Current chat: explicit repair11 continuation from the coordinating user, 2026-11-20."})
        doc["sources"].append({"id": "I_VERSIONED_DECISION", "kind": "inference", "text": "Technical binding: context.allowed retains the stored permission_allowed from the journal at this native revision; initial version zero has no committed decision and uses false. Current operation allowed is a typed event payload and guard input. Existing final SQL mapping of context.allowed remains unchanged. No native revision, permission or transition meaning is added.", "locator": "app/service.py::Service._change; bo_stategraph/workflow.py::allowed_guard; independent raw SQL boundaries in tests/native_boundaries.py."})
    decision_links = {"D_FILE_PERMISSIONS": (["R1"], ["view_file", "share_file", "revoke_share"], ["normal-recipient_visible", "normal-outsider_visible"]), "D_DOWNLOAD_REVOCATION": (["R2"], ["start_preparation", "collect_result"], ["queued_revoked-job_state", "started_revoked-collect_allowed"]), "D_ANNOUNCEMENT_ROLE": (["R3"], ["publish_announcement", "edit_announcement", "delete_announcement"], ["normal-announcement_visible", "normal-editor_file_override"]), "D_AUTH": (["R4"], ["sign_in"], ["normal-recipient_visible"]), "D_STORAGE": (["R5"], ["state_commit"], ["normal-job_state"]), "D_GRAPH_REVIEW": (["R1", "R2", "R3"], ["view_file", "start_preparation", "publish_announcement"], ["normal-recipient_visible", "queued_revoked-job_state", "normal-announcement_visible"]), "D_STATE_OVERVIEW": (["R1", "R2", "R3"], ["upload_file", "share_file", "start_preparation", "publish_announcement"], ["normal-job_state", "queued_revoked-job_state"]), "D_COLLECT_STATE": (["R2"], ["collect_result"], ["normal-downloads"])}
    for decision in doc["decisions"]:
        if decision["id"] in decision_links:
            requirements, model_nodes, checks = decision_links[decision["id"]]
            if decision["id"] in ("D_AUTH", "D_STORAGE"):
                requirements, checks = ["R4"], ["normal-test_accounts"]
            decision["links"] = {"requirements": requirements, "model_nodes": model_nodes, "checks": checks}
            for name in ("requirements", "model_nodes", "checks"):
                decision.pop(name, None)
        elif decision["id"] == "D_COLLECTION_LIFECYCLE":
            decision["links"] = {"requirements": ["R2"], "model_nodes": ["collect_result"], "checks": ["normal-downloads"]}
    policy = doc["policy"]
    if "grant_fresh" not in policy["inputs"]:
        policy["inputs"]["grant_fresh"] = "boolean"
        policy["nodes"].extend([{"id": "grant_fresh", "op": "input", "name": "grant_fresh", "source_refs": ["U_FINAL_STATES", "I_NATIVE_BINDING"]}, {"id": "preparation_access", "op": "all", "inputs": ["current_file_access", "grant_fresh"], "source_refs": ["U_RULES", "U_FINAL_STATES", "I_NATIVE_BINDING"]}])
        next(item for item in policy["operations"] if item["id"] == "start_preparation")["root"] = "preparation_access"
    path.write_text(json.dumps(doc, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return doc


def bind(root: Path, doc: dict, graph: dict) -> dict:
    """Bind every registered model, operation, fact, event, guard, effect and typed link.

    Args:
        root: Project root containing independently maintained acceptance assertions.
        doc: Current source-backed discovery record.
        graph: Actual native model before AST enrichment.
    """
    from bo_observer.concepts import snapshot
    from bo_observer.policy.projection import project
    from bo_observer.concepts.anchors import native_anchors
    from bo_observer.concepts.model import build
    from bo_observer.concepts.semantics import resolve_index

    policy = deepcopy(doc["policy"])
    policy["stage"] = "bound"
    policy["predicates"][0]["source"] = {"path": "app/permissions.py", "symbol": "same_identity"}
    business = {node["id"]: [node["id"]] for net in doc["networks"] for node in net["nodes"] if node["kind"] == "action"}
    business.update({"reject_preparation": ["start_preparation"], "stored_file": ["upload_file"], "download_result": ["collect_result"], "published_announcement": ["read_announcements"], "active_access": ["native-state:grant:active"], "revoked_access": ["native-state:grant:inactive"], "queued_download": ["native-state:download-job:queued"], "preparing_download": ["native-state:download-job:preparing"], "ready_download": ["native-state:download-job:ready"], "rejected_download": ["native-state:download-job:rejected"], "deleted_announcement": ["native-state:announcement:deleted"]})
    business["cancelled_download"] = ["native-state:download-job:cancelled"]
    for operation in policy["operations"]:
        operation["business_nodes"] = sorted({target for item in doc["applicability"] if operation["id"] in item["rules"].get("operations", []) for target in business[item["operation"]]})
        operation["cases"] = ["normal", "queued_revoked", "started_revoked"]
    graph["policy"] = policy
    graph = project(graph)
    for identity, method in (("stored_file", "upload_file"), ("published_announcement", "list_announcements"), ("download_result", "collect_result")):
        target = "native-data:" + identity
        graph["nodes"].append({"id": target, "kind": "function", "layer": "program", "label": identity.replace("_", " ").capitalize(), "summary": "Native function that produces or returns this business data.", "source": {"path": "app/service.py", "symbol": "Service." + method}, "capture": {"in": {}, "out": {}}})
        business[identity] = [target]
    acceptance = json.loads((root / "acceptance.json").read_text(encoding="utf-8"))
    for identity, requirement, field, expected in (("test_accounts", "R4", "test_accounts", 3), ("editor_count", "R4", "editor_count", 1), ("password_valid", "R4", "password_valid", True), ("native_models", "R5", "native_models", ["announcement", "download-job", "file", "grant"])):
        if not any(item["id"] == "normal-" + identity for item in acceptance["checks"]):
            acceptance["checks"].append({"id": "normal-" + identity, "case": "normal", "requirement": requirement, "path": [field], "equals": expected})
    binding = {"schema": "bo-concept-bindings/v2", "semantic_revision": snapshot(doc)["semantic_revision"], "state_models": {item["id"]: item["id"] for item in doc["state_models"]}, "objects": {item["id"]: item["subject"] for item in doc["state_models"]}, "business": business, "facts": {}, "expectations": {}, "crosslinks": {}, "effects": {"effect:download-job:record_admission": ["admission_transaction"]}, "events": {}, "guards": {}, "transition_effects": {"transition:download-job:job-start": [{"effect": "effect:download-job:record_admission", "edges": ["start_preparation-admission-transaction"], "completion": {"node": "admission_transaction", "phase": "return", "field": "committed", "equals": True, "identity_field": "transaction_id", "boundary": "preparation-start transaction commit", "expectation": "admission-committed", "path": ["admission", "committed"]}}]}}
    for fact in doc["facts"]:
        node, field = "policy:" + fact["id"], "value"
        path = ["fact_basis", fact["id"]]
        binding["facts"][fact["id"]] = [{"node": node, "direction": "out", "field": field, "basis_checks": [{"case": "normal", "path": path}]}]
        check = {"id": "fact-basis:" + fact["id"], "case": "normal", "requirement": "R4", "path": path, "equals": {"node": node, "direction": "out", "field": field, "read_basis": fact["read_basis"]}}
        if not any(item["id"] == check["id"] for item in acceptance["checks"]):
            acceptance["checks"].append(check)
    expectation_cases = {"outsider-invisible": "normal", "recipient-cannot-reshare": "normal", "revoke-before-start": "queued_revoked", "revoke-after-start": "started_revoked", "admission-committed": "normal", "editor-has-no-file-override": "normal", "editor-manages-own-only": "normal", "rejected-never-restores": "queued_revoked", "repeat-collection": "normal"}
    cancellation_expectations = {"requester-cancels-queued", "cancel-requester-only", "started-attempt-cannot-cancel", "cancelled-attempt-never-restores", "cancel-start-first-transition-wins"}
    expectation_cases.update({identity: "normal" for identity in cancellation_expectations})
    for expectation in doc["expectations"]:
        case = expectation_cases[expectation["id"]]
        binding["expectations"][expectation["id"]] = [case]
        for index, assertion in enumerate(expectation["then"]):
            check = {"id": "concept:" + expectation["id"] + ":" + str(index), "case": case, "requirement": "R2" if case != "normal" else "R1", **assertion}
            if expectation["id"] in cancellation_expectations:
                check["requirement"] = "R6"
            if not any(item["id"] == check["id"] for item in acceptance["checks"]):
                acceptance["checks"].append(check)
    operations = {"file": {"upload": "upload_file"}, "grant": {"share": "share_file", "revoke": "revoke_share"}, "download-job": {"request": "request_download", "start": "start_preparation", "reject": "start_preparation", "complete": "complete_preparation"}, "announcement": {"publish": "publish_announcement", "edit": "edit_announcement", "delete": "delete_announcement"}}
    operations["download-job"]["cancel"] = "cancel_download"
    for machine in doc["state_models"]:
        for event in machine["events"]:
            binding["events"]["event:" + machine["id"] + ":" + event] = {"node": operations[machine["id"]][event], "event": event}
        for guard, definition in machine["guards"].items():
            identity = "native-guard:" + machine["id"] + ":" + guard
            operation = definition["decision"].removeprefix("policy-operation:")
            graph["nodes"].append({"id": identity, "kind": "decision", "layer": "predicate", "label": guard.replace("_", " ").capitalize(), "summary": "Return the permission result acquired for this exact native transition.", "source": {"path": "bo_stategraph/workflow.py", "symbol": "allowed_guard"}, "policy_operation": operation, "capture": {"in": {}, "out": {"value": "boolean"}}})
            binding["guards"]["guard:" + machine["id"] + ":" + guard] = {"node": identity, "decision": definition["decision"], "field": "value"}
    graph["concepts"] = binding
    data = build(doc)
    failures = []
    anchors = native_anchors(doc, graph, binding, data, lambda code, item: failures.append((code, item)))
    if failures:
        raise ValueError(failures)
    for link in doc["crosslinks"]:
        left = anchors[resolve_index(data["index"], link["from"])]
        right = anchors[resolve_index(data["index"], link["to"])]
        if link["relation"] == "action_requests_event" and left == right:
            binding["crosslinks"][link["id"]] = {"relation": link["relation"], "from": left, "to": right, "native_event": binding["events"][link["to"]]["event"], "edges": []}
            continue
        if link["relation"] in ("transition_guarded_by", "decision_reads_fact"):
            left, right = right, left
        refs = []
        for source in left:
            for target in right:
                identity = "binding:" + link["id"] + ":" + str(len(refs))
                graph["edges"].append({"id": identity, "from": source, "to": target, "type": "guard" if link["relation"] == "transition_guarded_by" else "data" if link["relation"] == "decision_reads_fact" else "flow", "label": link["relation"].replace("_", " ").capitalize(), "evidence": "Explicit confirmed concept-to-native association; execution needs actual event evidence.", "evidence_kind": "conceptual"})
                refs.append(identity)
        binding["crosslinks"][link["id"]] = refs
    (root / "acceptance.json").write_text(json.dumps(acceptance, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    plan = json.loads((root / "mapping.json").read_text(encoding="utf-8"))
    rows = plan.setdefault("context_fields", [])
    known = {row["id"] for row in rows}
    for case in ("normal", "queued_revoked", "started_revoked"):
        for node in graph["nodes"]:
            identity = node["id"]
            if identity.startswith("policy:") and node.get("capture", {}).get("out"):
                phases = ["decision"]
            elif identity.startswith("native-guard:"):
                phases = ["decision"]
            elif identity == "state_before":
                phases = ["read"]
            elif identity == "state_commit":
                phases = ["commit"]
            elif identity == "admission_transaction":
                phases = ["enter", "return"]
            elif node.get("layer") in ("business", "api") and any(node.get("capture", {}).values()):
                phases = ["enter", "return"] + ([] if node["layer"] == "api" else ["error"])
            else:
                continue
            for phase in phases:
                key = "sdk:" + case + ":" + identity + ":" + phase
                if key in known:
                    continue
                each = {"collection": ["native_trace", identity, phase], "actual_key": [["trace", "trace_id"], ["trace", "span_id"]], "mapped_key": [["trace", "trace_id"], ["trace", "span_id"]]}
                if identity.startswith("policy:"):
                    each["actual_key"].append(["check_id"])
                    each["mapped_key"].append(["inputs", "bo_check"])
                rows.append({"id": key, "case": case, "node": identity, "phase": phase, "source": "integrations/bo_http.py::BONativeRequestFacts.bo_sdk_fact (actual SDK context, independent of BOProbe events)", "each": each, "actual": ["trace"], "mapped": ["trace"]})
    (root / "mapping.json").write_text(json.dumps(plan, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return graph
