"""Author source and parameter dispositions from the independently scanned project tree."""

from pathlib import Path
import json


def implementation(root: Path, model: dict, index: dict) -> dict:
    """Map observed entries and static support without claiming unobserved helper execution.

    Args:
        root: Project source root.
        model: Authored native graph before AST enrichment.
        index: Canonical independent source scan.
    """
    functions = {key: value for key, value in index["symbols"].items() if value["kind"] == "function"}
    groups = {}
    for node in model["nodes"]:
        if (node.get("layer") in ("business", "api") or node["id"] == "list_jobs") and any(node.get("capture", {}).values()) and node["id"] not in ("state_before", "state_commit"):
            source = node["source"]["path"] + "::" + node["source"]["symbol"]
            groups.setdefault(source, []).append(node)
    business = {"login": "sign_in", "logout": "sign_out", "home": "view_file", "upload": "upload_file", "share": "share_file", "enqueue": "request_download", "cancel": "cancel_download", "collect": "collect_result", "announcement": "publish_announcement", "job_status": "list_jobs", "health": "service_status"}
    features = []
    for source, nodes in groups.items():
        is_api = nodes[0].get("layer") == "api"
        owned = [node["id"] for node in nodes]
        anchor = business[source.rsplit(".", 1)[-1]] if is_api else owned[0]
        if anchor in ("service_status", "sign_out", "list_jobs"):
            anchor = None
        if not is_api and any(node["id"] in {"upload_file", "share_file", "revoke_share", "request_download", "cancel_download", "start_preparation", "complete_preparation", "publish_announcement", "edit_announcement", "delete_announcement"} for node in nodes):
            owned += ["state_before", "state_commit"]
        cases = [{"case": "normal", "node": node["id"], "phase": phase} for node in nodes for phase in ("enter", "return")]
        if not is_api:
            cases += [{"case": "normal", "node": node["id"], "phase": "error"} for node in nodes]
        if "state_commit" in owned:
            cases += [{"case": "normal", "node": "state_before", "phase": "read"}, {"case": "normal", "node": "state_commit", "phase": "commit"}]
        if "start_preparation" in owned:
            owned.append("admission_transaction")
            cases.extend({"case": "normal", "node": "admission_transaction", "phase": phase} for phase in ("enter", "return"))
        parameters = []
        for parameter in functions[source]["parameters"]:
            name = parameter["name"]
            if name in ("self", "cls"):
                continue
            selected = nodes[0]
            direction, field, policy, reason = "in", name, "value", None
            if name == "password":
                field, policy, reason = "password_provided", "derived", "Only actual presence is selected; password bytes and hashes are never captured."
            elif name == "stream":
                direction, field, policy, reason = "out", "size", "derived", "The stored byte count represents the uploaded stream without collecting its contents."
            elif name == "filename":
                policy, reason = "derived", "The selected value is the actual basename used for display; path segments are removed natively."
            elif name in ("title", "body"):
                field, policy, reason = name + "_length", "derived", "Only the actual input character count is selected; publication text is not traced."
            if field not in selected["capture"].get(direction, {}):
                raise ValueError("Missing safe parameter representation: " + source + ":" + name)
            entry = {"source": source, "name": name, "node": selected["id"], "direction": direction, "field": field, "policy": policy}
            if reason:
                entry["reason"] = reason
            parameters.append(entry)
        features.append({"id": ("http:" if is_api else "business:") + source, "label": nodes[0]["label"], "business_node": anchor, "nodes": owned, "sources": [source], "parameters": parameters, "cases": cases})
    expressions = {item["id"]: item for item in model.get("policy", {}).get("nodes", [])}
    for feature in features:
        if not feature["id"].startswith("business:"):
            continue
        selected_operations = [item for item in model.get("policy", {}).get("operations", []) if set(item["business_nodes"]) & set(feature["nodes"])]
        pending = [item["root"] for item in selected_operations]
        selected = set()
        while pending:
            identity = pending.pop()
            if identity in selected:
                continue
            selected.add(identity)
            pending.extend(expressions[identity].get("arguments", {}).values())
            pending.extend(expressions[identity].get("inputs", []))
        owned = ["policy:" + identity for identity in sorted(selected)]
        owned += [node["id"] for node in model["nodes"] if node["id"].startswith("native-guard:") and node.get("policy_operation") in {item["id"] for item in selected_operations}]
        feature["nodes"].extend(identity for identity in owned if identity not in feature["nodes"])
        feature["cases"].extend({"case": "normal", "node": identity, "phase": "decision"} for identity in owned)
    support, excluded = {}, {}
    if any(node["id"] == "native_transition" for node in model["nodes"]):
        source = "bo_stategraph/workflow.py::Workflow.step"
        groups[source] = []
        features.append({"id": "native:state-transition", "label": "Native state transition", "business_node": None, "nodes": ["native_transition"], "sources": [source], "parameters": [{"source": source, "name": name, "node": "native_transition", "direction": "in", "field": "instance_id" if name == "instance" else name, "policy": "derived" if name == "instance" else "value", **({"reason": "Use the real row or composite grant identity, without collecting the ORM instance."} if name == "instance" else {})} for name in ("model_id", "instance", "event", "allowed", "transaction_id")], "cases": [{"case": "normal", "node": "native_transition", "phase": phase} for phase in ("enter", "return")]})
        features[-1]["parameters"].append({"source": source, "name": "context", "node": "native_transition", "direction": "in", "field": "context_allowed", "policy": "derived", "reason": "Select the native version's last committed Boolean from context; preserve the separate current allowed parameter and its original witnesses."})
    for identity, symbol, anchor, phases in (("db-read", "Store.read", "view_file", ("return",)), ("db-write", "Store.transaction", "state_commit", ("return",)), ("db-transaction", "Store._transaction", "state_commit", ("commit", "error"))):
        if any(node["id"] == identity for node in model["nodes"]):
            source = "app/storage.py::" + symbol
            groups[source] = []
            features.append({"id": "database:" + identity, "label": identity.replace("-", " ").capitalize(), "business_node": None, "nodes": [identity], "sources": [source], "parameters": [], "cases": [{"case": "normal", "node": identity, "phase": phase} for phase in phases]})
    technical = {
        "business:app/service.py::Service.list_jobs": ("list_jobs", "Read the authenticated requester's existing attempts for status display; this query introduces no domain operation or state transition."),
        "http:app/web.py::create_app.logout": ("api:POST:/logout", "Clear the current Flask session and redirect. This is the existing technical session endpoint, not an additional confirmed domain action."),
        "http:app/web.py::create_app.job_status": ("api:GET:/api/jobs", "Return the current requester's native job states for page refresh through the existing authenticated HTTP handler."),
        "http:app/web.py::create_app.health": ("api:GET:/health", "Report process and worker readiness without reading or changing a domain business object."),
        "native:state-transition": ("native_transition", "Execute a registered per-instance native state declaration inside the caller transaction; confirmed business operations remain separately bound."),
        "database:db-read": ("db-read", "Observe actual SQLAlchemy read scopes and selected driver results; this is persistence implementation support."),
        "database:db-write": ("db-write", "Observe real reads and writes inside the native serialized transaction, retaining each table's actual access role."),
        "database:db-transaction": ("db-transaction", "Observe the existing native transaction manager's actual commit acknowledgement or rollback; this adds no domain action."),
    }
    for feature in features:
        if feature["id"] in technical:
            target, reason = technical[feature["id"]]
            feature.pop("business_node", None)
            feature.update(category="technical", implementation_node=target, classification_reason=reason)
    for source, symbol in functions.items():
        if source in groups:
            continue
        path, name = symbol["path"], symbol["symbol"]
        if path.startswith("integrations/") or path == "app/ports.py" or name.startswith(("create_app.bo_", "bo_")):
            excluded[source] = {"category": "observer", "reason": "Isolated observation/query wiring; it must not authorize or execute business effects."}
            if symbol.get("entrypoints"):
                from observation_scope import endpoint_paths
                excluded[source]["routes"] = endpoint_paths(symbol)
        elif name.endswith(".__init__"):
            excluded[source] = {"category": "construction", "reason": "Construct native services or test/observation adapters; operational entrypoints are covered separately."}
        else:
            target = "state_commit" if path in ("app/storage.py", "bo_stategraph/workflow.py") or "_change" in name else "view_file" if path == "app/permissions.py" else "sign_in"
            summary = (symbol.get("documentation") or {}).get("summary") or name
            support[source] = {"node": target, "reason": "Static support: " + summary + " Execution is claimed only when its own runtime evidence exists."}
    result = {"schema": "bo-implementation/v1", "features": features, "support": support, "excluded": excluded}
    (root / "implementation.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return result
