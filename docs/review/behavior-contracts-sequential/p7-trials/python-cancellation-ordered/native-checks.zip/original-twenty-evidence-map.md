# Original twenty checks: corrected semantic coverage index

The controlled raw module docstring/scope and some inherited check names mention ordinary-entry or automatic worker. They are legacy wording. This index classifies that run as create_app(start_worker=False) with explicit existing Service methods, not default run.py. Original files are retained without relabelling or rerunning.

Twenty original rows mapped, controlled predicates 20 passed, normal actual checks 19 passed. This is not a claim that the normal record exercised all twenty original premises or that controlled manual calls exercised the automatic worker.

| ID | Original check | Controlled native predicate | Normal execution / original premise |
|---|---|---|---|
| original-01 | real preferences response succeeds | Passed in controlled fixture | Passed |
| original-02 | native early authentication and CSRF returns | Passed in controlled fixture | Passed |
| original-03 | recipient reshare actually denied | Passed in controlled fixture | Passed |
| original-04 | first attempt is genuinely queued before revocation | Passed in controlled fixture | Corresponding property passed under a different premise; original order assertion unexercised |
| original-05 | automatic worker rejects revoked queued attempt | Passed; explicit native call, not automatic thread | Corresponding property passed under a different premise; original order assertion unexercised |
| original-06 | fresh admitted result bytes 1 | Passed in controlled fixture | Passed |
| original-07 | fresh admitted result bytes 2 | Passed in controlled fixture | Passed |
| original-08 | re-sharing did not revive the old request | Passed in controlled fixture | Corresponding property passed under a different premise; original order assertion unexercised |
| original-09 | recording actually stopped without gaps | Passed in controlled fixture | Passed |
| original-10 | fixed producer prefix drained | Passed in controlled fixture | Passed |
| original-11 | each recorded producer prefix is continuous | Passed in controlled fixture | Passed |
| original-12 | every real transition in all four models has an exact frame | Passed in controlled fixture | Passed for actual branch: exact 13/13/26; original 12/12/24 in controlled |
| original-13 | every initial and same-version read retains exact native context | Passed in controlled fixture | Passed for actual branch: exact 13/13/26; original 12/12/24 in controlled |
| original-14 | changed denied input does not rewrite queued context | Passed in controlled fixture | Unexercised |
| original-15 | all recorded invocation lifecycles close | Passed in controlled fixture | Passed |
| original-16 | real HTTP rejections retain API return events | Passed in controlled fixture | Passed |
| original-17 | safe per-producer diagnostics and retry counts retained | Passed in controlled fixture | Passed |
| original-18 | capture has no errors drops or frame evictions | Passed in controlled fixture | Passed |
| original-19 | read-only inspection preserves native rows | Passed in controlled fixture | Passed |
| original-20 | original recording is not supplemented after stop | Passed in controlled fixture | Passed |

| Original ID | Actual normal check name | Exact evidence |
|---|---|---|
| 4 | first attempt committed queued at its own native request version | historical-request-version-and-frame.json |
| 5 | automatic worker respects independently committed admission/revocation order | native-after-rejection.json, independent-ordering-expectation.json, native-ordering-before-result-expectation.json |
| 8 | re-sharing did not revive the old request | native-after-operations.json |
| 14 | changed denied input does not rewrite queued context | independent-read-frame-checks.json, runtime-frames-original.json |

Current-build automatic-worker rejection was not exercised by these records. Controlled rejection uses explicit real `Service.start_preparation()` after the revoke committed; it supplies the native rejection semantics, not automatic driver execution. The original controlled browser also delays automatic startup until its final allowed preparation. Older recording `bef6eebce72447579ebd8f2ab562147d` has historical automatic rejection evidence, with failed finalization and an older build; it is not promoted to a current-build pass.

The normal nineteen-executed/nineteen-passed fact is retained. Original 04/05/08 premise-specific coverage is not conflated with the corresponding rewritten normal properties, and 14 remains unexercised there. The JSON retains every actual check name, entry, recording ID, exact native identity and hashed original evidence path. No original record, runtime frame, report, script or evidence was modified, supplemented or rerun for this correction.

Each raw recording and its frame/lifecycle checks remains independent; no controlled event was appended to the normal recording.
