# Ordered evidence: scripted checks and root UI handoff

Candidate `85c8db3ad234e68240ccfeec053b62ce1d7f1d69926d8305114c4bd902620bba`. Build `788ab708c11a78be7bde19baab9ce5a45c6d684dcdf3f899689908329ec2015a`.

All five full native gate reports passed before and after the records, each with 162/162 business assertions, 21 business tests and six HTTP tests. The original on/off/fault, rollback, eight native races, detached missing-completion negative, original 12-check browser case and cancellation 38-check case remain intact and passed. Fresh pre/post native receipts are archived separately. No accept occurred.

| Run | Entry | Record ID | Events / frames | Actual executed checks | Lifecycle |
|---|---|---|---|---|---|
| controlled | Controlled create_app(start_worker=False), explicit original native Service methods | `50f3abc53dc245eebe3bf06a286847f6` | 866 / 24 | 20/20 | 304 closed, no errors |
| normal | Normal run.py with unchanged default automatic worker | `91bd56f0d2e243c7b393f83f42062093` | 3167 / 26 | 19/19 | 594 closed, no errors |

The controlled raw module docstring/scope and some inherited check names mention ordinary-entry or automatic worker. They are legacy wording. This index classifies that run as create_app(start_worker=False) with explicit existing Service methods, not default run.py. Original files are retained without relabelling or rerunning.

The normal record actually admitted before revoke. Its expected ready outcome was selected from independent native SQL start/revoke commit order before checking the eventual result. Initial queued is established by the real request journal revision and its exact historical frame; a later current SQL read is not treated as a scheduling barrier. The original rejection/context branch is retained in the explicitly controlled entry with completed native transactions.

The corrected twenty-row ledger is `original-twenty-evidence-map.md` / `.json`. Normal 04/05/08 corresponding properties passed under a different premise; their original order-specific assertions are not labelled normal passes. Original 14 remains unexercised normally and is tied to exact controlled model/object/revision/transaction/build/run/event and original frame. Controlled native predicates pass twenty checks, but explicit Service calls are not called an automatic thread. Current-build automatic-worker rejection remains unexercised; older default-worker rejection evidence is historical only.

Fixed prefix target=completed=3261. submitted=3277/pending=16 at the original stop ACK are exactly 16 submissions beyond that fixed target. This is not a claim that the entire later queue was empty. No backfill or error gap is inferred.

Each record separately retains original events/frames, producer-prefix continuity, exact native SQL/frame identities, canonical invocation closure, actual HTTP results, stop wire receipt and stopped-record immutability. No controlled events were inserted into normal. Source, guards, policy, fields, default worker, 2048 queue capacity and original deadlines stay unchanged.

Normal app: http://127.0.0.1:8875. Viewer: http://127.0.0.1:8876/graph?lang=zh-CN. Native DB: `C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.validation\p7-trials\python-retest-app\var\team.sqlite3`. Both normal processes remain running. The root chat has taken over independent UI testing; this agent does not run more business operations, records or tests. Ordinary operations already produced nonempty real history. Root UI/acceptance remains pending in this handoff.

True raw recording, frame, report and native data paths for both records are in `HANDOFF.json`. `native-readonly-backup-at-handoff.sqlite3` is a separately labelled read-only live backup; the per-record original native JSON snapshots remain the temporal authority for those recordings. Earlier failures and original archives are retained and hash-checked, including the first repair23 1580-event/12-frame partial record with successful capture finalization and failed business test ordering.
