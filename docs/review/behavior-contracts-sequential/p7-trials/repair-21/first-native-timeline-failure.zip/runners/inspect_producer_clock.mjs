import fs from 'node:fs';
import { timeline } from '../skills/vibelens/assets/stategraph-viewer/recording.js';
import { traceTime } from '../skills/vibelens/assets/stategraph-viewer/trace-evidence.js';
const [source, destination] = process.argv.slice(2);
const recording = JSON.parse(fs.readFileSync(source));
const owners = new Map(), backwards = [];
for (const item of timeline(recording)) {
  if (['start', 'end'].includes(item.kind)) continue;
  const owner = JSON.stringify([item.project_id, item.build_id, item.run_id, item.producer_id, item.stream_id]);
  const at = traceTime(item.observed_at), previous = owners.get(owner);
  if (previous && at < previous.at) backwards.push({owner, before: previous.id, after: item.id, delta_ms: at - previous.at});
  owners.set(owner, {id: item.id, at, count: (previous?.count || 0) + 1});
}
const report = {recording: recording.id, producer_groups: owners.size, backwards,
  groups: [...owners.entries()].map(([owner, value]) => ({owner, count:value.count}))};
fs.writeFileSync(destination, JSON.stringify(report, null, 2)+'\n', {flag:'wx'});
console.log(JSON.stringify(report));
