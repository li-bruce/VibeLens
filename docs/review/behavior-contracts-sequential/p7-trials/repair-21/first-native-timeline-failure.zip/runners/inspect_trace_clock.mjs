/** Read original event timestamps without altering their order or payloads. */
import fs from 'node:fs';
import crypto from 'node:crypto';
import { timeline } from '../skills/vibelens/assets/stategraph-viewer/recording.js';
import { traceTime } from '../skills/vibelens/assets/stategraph-viewer/trace-evidence.js';

const [source, destination] = process.argv.slice(2);
const raw = fs.readFileSync(source);
const recording = JSON.parse(raw);
const items = timeline(recording).filter(item => !['start', 'end'].includes(item.kind));
const select = item => Object.fromEntries(
  ['id', 'node', 'phase', 'kind', 'seq', 'stream_id', 'producer_id', 'observed_at']
    .map(key => [key, item[key]]),
);
const backwards = [];
for (let index = 1; index < items.length; index++) {
  const previous = traceTime(items[index - 1].observed_at);
  const current = traceTime(items[index].observed_at);
  if (previous !== null && current !== null && current < previous) {
    backwards.push({index, delta_ms: current - previous,
      same_stream: items[index].stream_id === items[index - 1].stream_id,
      before: select(items[index - 1]), after: select(items[index]),
    });
  }
}
const summary = {
  recording: recording.id,
  original_sha256: crypto.createHash('sha256').update(raw).digest('hex'),
  items: items.length,
  invalid_timestamps: items.filter(item => traceTime(item.observed_at) === null).length,
  inversions: backwards.length,
  same_stream_inversions: backwards.filter(row => row.same_stream).length,
  sub_millisecond_inversions: backwards.filter(row => row.delta_ms > -1).length,
  maximum_backward_ms: Math.max(0, ...backwards.map(row => -row.delta_ms)),
};
if (!raw.equals(fs.readFileSync(source))) throw Error('Original recording changed');
fs.writeFileSync(destination, JSON.stringify({...summary, inversions_detail: backwards}, null, 2)+'\n', {flag: 'wx'});
console.log(JSON.stringify(summary));
console.log(JSON.stringify(backwards.slice(0, 4), null, 2));
