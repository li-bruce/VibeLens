/** Read canonical clock admission from the frozen originals without rewriting evidence. */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const run = path.dirname(fileURLToPath(import.meta.url));
const app = path.resolve(run, '../../..');
const pack = path.resolve(app, '../source-index-final-skills/vibelens');
const { traceClock } = await import(pathToFileURL(path.join(pack, 'assets/stategraph-viewer/trace-clock.js')).href);
const load = p => JSON.parse(fs.readFileSync(p, 'utf8').replace(/^\uFEFF/, ''));
const digest = p => crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const seal = load(path.join(run, 'normal-stop-original-seal.json'));
const records = [];
for (const row of seal.recordings) {
  const filename = path.join(seal.unified_run, `independent-recording-${row.id}.json`);
  const originalHash = digest(filename), record = load(filename);
  const axis = traceClock(record.events, record.observed_until);
  const clocks = new Set(record.events.map(item => JSON.stringify([item.project_id, item.build_id, item.run_id, item.producer_id])));
  assert.equal(digest(filename), originalHash);
  records.push({ recording_id: record.id, events: record.events.length, source_time_axis_admitted: axis.ordered, arrival_ordered: axis.arrivalOrdered, arrival_inversions: axis.arrivalInversions, source_reversed: axis.sourceReversed, boundary_adjusted: axis.boundaryAdjusted, invalid_source_time_values: axis.dates.filter(value => value === null).length, producer_clock_domains: clocks.size, original_sha256: originalHash });
}
const result = { valid: records.every(row => row.source_time_axis_admitted && !row.source_reversed), scope: 'Installed canonical traceClock applied read-only to all events in each original newly stopped recording. This is source-clock/data admission, not independent Timeline UI acceptance. Replay ordinals, events, observed_at values and old recordings remain unchanged.', records };
fs.writeFileSync(path.join(run, 'source-clock-audit.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result));
assert.equal(result.valid, true, 'New recording source-clock admission failed; preserve and report without changing timestamps');
