/** Inspect the real isolated observer bridge capacities without emitting facts or starting HTTP. */
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { Store } from '../../../src/store.mjs';
import { FileService } from '../../../src/service.mjs';
import { bo_create } from '../../../integrations/bo_observe.mjs';
const run=path.dirname(fileURLToPath(import.meta.url)),app=path.resolve(run,'../../..');
const read=async p=>JSON.parse((await fs.readFile(p,'utf8')).replace(/^\uFEFF/,''));
const hash=async p=>crypto.createHash('sha256').update(await fs.readFile(p)).digest('hex');
const project=await read(path.join(app,'bo_stategraph/project.json'));
const manifest=await read(path.join(run,'current-source-capture.json'));
const database=path.join(app,'var/db/application.sqlite'),before=await hash(database),checks=[];
for(const [label,capacity,expected] of [['default',undefined,8192],['explicit-small',2,2],['explicit-existing-normal',4096,4096]]){
  const isolated=await fs.mkdtemp(path.join(run,'capacity-check-'));
  const store=new Store(path.join(isolated,'db/application.sqlite')),service=new FileService(store,isolated);
  const options={project,buildId:manifest.build_id,...(capacity===undefined?{}:{capacity})};
  const observer=await bo_create(service,app,options);
  try{
    assert.equal(observer.probe.bo_capacity,expected);
    assert.equal(observer.clientConfig().capacity,4096);
    assert.equal(observer.health().enqueued,0);
    checks.push({label,native_capacity:observer.probe.bo_capacity,browser_capacity:observer.clientConfig().capacity,observations_emitted:observer.health().enqueued,isolated_data:isolated});
  }finally{await observer.close();await service.stop();store.close();}
}
assert.equal(await hash(database),before);
const result={valid:true,checks,actual_var_database_unchanged:true,server_started:false,scope:'Real Store/FileService/bo_create in isolated review directories; no business invocation, event fabrication, HTTP service or original-test modification'};
await fs.writeFile(path.join(run,'capacity-check.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result));
