"""Compare published gzip bytes with the independently sealed native files."""
import gzip
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
app = root / '.validation/p7-trials/node-retest-app'
data = root / 'docs/site/forest-data'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda raw: hashlib.sha256(raw).hexdigest()
manifest = read(data / 'manifest.json')
rows = []
for epoch, stage in (
    ('initial', 'repair22-capacity-20261121'),
    ('updated', 'context-closure-runtime-20261122'),
):
    entry = manifest['epochs'][epoch]
    seal_path = app / 'review/runtime' / stage / 'normal-stop-original-seal.json'
    seal = read(seal_path)
    relative = 'bo_stategraph/data/recordings/' + entry['recording_id'] + '.json'
    expected = seal['record_file_sha256'][relative]
    original = (app / relative).read_bytes()
    compressed = (data / (epoch + '.json.gz')).read_bytes()
    assert sha(original) == sha(gzip.decompress(compressed)) == expected == entry['raw_sha256']
    assert sha(compressed) == entry['compressed_sha256']
    record = json.loads(original)
    assert record['build_id'] == entry['build_id'] and record['id'] == entry['recording_id']
    rows.append({'epoch': epoch, 'recording_id': record['id'], 'build_id': record['build_id'],
                 'persisted_record_sha256': expected,
                 'native_seal': seal_path.relative_to(root).as_posix(),
                 'native_seal_sha256': sha(seal_path.read_bytes()),
                 'acceptance_reference': entry['acceptance']})
out = root / '.validation/forest-provenance-check.json'
out.write_text(json.dumps({'valid': True, 'records': rows,
    'note': 'Source-clock audit hashes refer to the separate sealed HTTP export. This check matches the persisted recording file selected for the product archive.'}, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'valid': True, 'records': len(rows)}))
