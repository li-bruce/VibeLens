"""Run the combined desktop product gate and retain every independent result.

This runner owns only static-site servers launched by its children. It does not
run either trial application or change its scheduling. Failures do not suppress
the remaining independent checks, and the complete batch still fails.
"""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
out = args.out.resolve()
out.mkdir(parents=True, exist_ok=False)
env = dict(os.environ, BO_BROWSER_EXECUTABLE='C:/Program Files/Google/Chrome/Application/chrome.exe',
           BO_FOREST_EVIDENCE=str(out / 'forest'), BO_LOADING_EVIDENCE=str(out / 'loading'),
           BO_DEMO_STARTUP_EVIDENCE=str(out / 'startup'), BO_PYTHON=sys.executable,
           PYTHONUTF8='1', PYTHONDONTWRITEBYTECODE='1')
env.pop('BO_SITE_URL', None)
commands = [
    ('forest', ['node', 'tools/test_forest_story_browser.mjs']),
    ('legacy', [sys.executable, '-B', '-X', 'utf8', 'tools/test_product_story_browser.py',
                '--out', str(out / 'legacy'), '--browser', env['BO_BROWSER_EXECUTABLE']]),
    ('loading', ['node', 'tools/test_demo_loading_browser.mjs']),
    ('startup', ['node', 'tools/test_demo_startup_browser.mjs']),
]
results = []
for name, command in commands:
    started = datetime.now(timezone.utc).isoformat()
    with (out / (name + '.stdout.log')).open('x', encoding='utf-8') as stdout, \
         (out / (name + '.stderr.log')).open('x', encoding='utf-8') as stderr:
        process = subprocess.run(command, cwd=root, env=env, stdout=stdout, stderr=stderr)
    results.append({'name': name, 'command': command, 'exit_code': process.returncode,
                    'started_at': started, 'ended_at': datetime.now(timezone.utc).isoformat()})
    (out / 'sequence.json').write_text(json.dumps({
        'valid': len(results) == len(commands) and all(item['exit_code'] == 0 for item in results),
        'checks': results, 'scope': 'Static product presentation and original teaching regressions',
    }, indent=2) + '\n', encoding='utf-8')
    print(name, process.returncode, flush=True)
raise SystemExit(any(item['exit_code'] for item in results))
