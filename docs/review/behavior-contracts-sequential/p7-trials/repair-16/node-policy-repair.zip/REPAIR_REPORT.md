# Policy witness and shared viewing-rule repair

2026-11-20T20:10:21.775015+08:00 (Asia/Singapore)

Both authorized observation repairs are complete. The same direct-native scenario ran against the immutable pre-fix source and current source on/off/fault. Native business results and every native permission decision agree across versions. The target observation defects are absent in the current captures. No service listener, HTTP client, browser, recording, full verify or final accept ran this round.

## Actual changes

1. `integrations/bo_observe.mjs:89` uses `check + ':' + step.id` for policy expression call_id. Here native `step.id` becomes evaluation `trace.step.node`, so this is exactly `check_id + ':' + step.node`. Actual used, already-emitted expression results are linked with dependency type `data`. The real business parent options are unchanged. The source bytes differ by exactly this one-line authorized substitution; CRLF endings are preserved. No predicate is executed by this observer.
2. `discovery.json` now includes the already implemented `list_files` action in the files business network, marks it as reading current grant state, and applies the existing `view_file` permission. `view_file` and `list_files` share root `may_access`; rule expressions, predicates and native permission logic are unchanged. `bo_stategraph/project.json` binds the existing native list_files node and the shared policy consumer. All existing570 physical node IDs and capture contracts remain identical.

The actual user clarification is preserved as source **U6_LIST_VIEW** with the coordination origin and the original full instruction. Public `bo_concepts snapshot -> present -> confirm` commands saved **P_LIST_VIEW / C_LIST_VIEW**. The canonical requirements check and concept diff retain this as a model-coverage correction within the existing R_FILES scope, rather than a new business requirement. Original decisions, modeling obligations, expectations and prior confirmations remain intact.

```mermaid
flowchart LR
  L["list_files: list currently visible files"] -->|same current rule| R["policy:may_access"]
  V["view_file: inspect file details"] -->|same current rule| R
```

No list-to-detail navigation step or additional permission was invented. Native FileService remains authoritative.

## Controlled native comparison

`before-fixture` contains all246 pre-fix archived files, verified byte-identical. Both versions used the same driver, installed provider and dependencies. The fixture and all databases/files are under the declared review/runtime artifact subtree. Each scenario calls real native services and reads actual SQLite/file bytes; there are no mocked successful business results. Fault mode deliberately throws in the local observation sink, with no HTTP endpoint.

| Measure | Before | After |
| --- | ---: | ---: |
| Named native checks per on/off/fault mode | 15 / 15 / 15 passed | 15 / 15 / 15 passed |
| Native permission decisions per mode | 44 | 44, identical |
| Observed expression steps in on mode | 275 | 275 |
| Input/output value mismatches | 0 / 0 | 0 / 0 |
| Call-ID mismatches | 275 | **0** |
| Data-dependency mismatches | 121 | **0** |
| Real native-parent mismatches | 0 | **0** |
| List-rule invocation ownership errors | 9 | **0** |
| Captured on-mode events | 725 | 725 |

Each current evaluation is independently correlated with the native decision callback and its actual visited steps: all44 decisions and275 step values match. Business outcomes match both across versions and across observation on/off/fault. The original independent native reader reports zero emitted observer-query events, and persisted SQLite reads equal its live native reads. Enabled capture errors/drops and final pending count are zero.

The 15 named checks cover owner/recipient/editor visibility and detail rejection before grant, after grant and after revoke; recipient non-resharing; durable admission authorization; denial of new requests after revoke; successful preparation and repeat collection by the original requester; independent board permissions; and native logout. These are direct-native checks; the 401/403 properties are native rejection results, not newly exercised HTTP responses.

## Scope of the canonical runtime checks

The focused case has its own ID, **native_policy_listing**. It was not relabeled as the protected full workflow. The unchanged canonical policy runtime checker reports no value, identity, type or dependency witness errors after the repair. It still reports **10 missing workflow policy-case entries**, because this focused case does not replace that original case. Those raw diagnostics remain in `controlled-before-after.json`; they are not a full-gate pass. Canonical `_policy_errors` checks the actual observed ownership directly and reports no current invocation-target error. Transaction completion checks were not substituted or repaired.

The original full test commands, independent native scenarios, HTTP driver, mapping-case denominator, required captures and watched-file list remain byte-identical. Full verify would start the original HTTP test services, which this round explicitly forbids, so it was not invoked. The previous failed full verification and global runtime evidence remain byte-identical to their original seal. No focused result was promoted into those global observations.

## Source and declaration validation

- Canonical requirements reconciliation, concept check and policy check: **passed**.
- Strict source documentation and API registration: **passed**; all16 original application routes remain registered.
- Managed integration integrity and naming: **passed**. Five new business/relation names and36 changed-source context names have reviewed English/Chinese meanings.
- Final scan: no unregistered source or implementation gap, database valid, no missing/stale semantic names. Its `needs_update` status retains the active unaccepted initial change.
- Final inspect: **valid**, no structural or review errors.
- Current candidate: `b0117a81d7c89a80665dc1e0f2cd073527c7008149756fbd133c9e90c7854c9c`.
- Actual direct-native build: `5dc7cccff1add8a3e1f4c89aea87f6e658ff47e8359ae284a76f61c3574a3fe5`. Canonical manifest check reports **current** after final model/source generation.

All four state machines,570 captures, transaction effect bindings, original source readers and business assertions are unchanged. In particular, revoke still blocks new requests, while an already admitted task retains submission authorization and repeat collection. `src/policy.mjs`, `src/service.mjs`, `src/http.mjs`, `acceptance.json`, `mapping.json`, `behavior.json`, `intent.json`, `implementation.json`, `sync.json`, all original test drivers, managed adapters and the immutable initial baseline retain their pre-fix bytes.

## Evidence and reproducibility

- `controlled-before-after.json`: complete component diagnostics and before/after counters, including retained full-case coverage gaps.
- `before-controlled/native-focused-runs.json`, `after-controlled/native-focused-runs.json`: original actual captures, native decisions, independent reads and outcomes.
- `native_regression.mjs`: the same driver used for both versions.
- `controlled-comparison-provenance.json`: source/driver/provider provenance.
- `before-fix.zip` and its seal: immutable246-file source/model/check snapshot, SHA-256 `46d22956879eb352a6149f5c555680caca030ead8dc955b70dd60a8ca2e69c32`.
- `project-after.json`, `discovery-after.json`, `native-manifest.json`: frozen current declarations and build.
- `final-protection-check.json`: exact source substitution and protected-file hashes.
- `listing-confirmation.json`, `requirements-check-reconciled.json`, `concept-diff-relative.json`, `inspect.json`: canonical scope and review receipts.

To repeat the current focused native scenario, choose a fresh output directory so no evidence is overwritten:

```powershell
$env:VIBELENS_SKILL = 'C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.validation\p7-trials\interactive-capture-skills\vibelens'
$env:BO_NATIVE_REGRESSION_ROOT = 'C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.validation\p7-trials\node-retest-app'
$env:BO_NATIVE_REGRESSION_SETTINGS = 'C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.validation\p7-trials\node-retest-app\review\runtime\policy-listing-repair-20261120\native-settings.json'
$env:BO_NATIVE_REGRESSION_OUTPUT = 'C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.validation\p7-trials\node-retest-app\review\runtime\policy-listing-repair-20261120\new-after-replay'
New-Item -ItemType Directory -Path $env:BO_NATIVE_REGRESSION_OUTPUT -ErrorAction Stop
node 'C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.validation\p7-trials\node-retest-app\review\runtime\policy-listing-repair-20261120\native_regression.mjs'
```

For the pre-fix comparison, use `before-fixture` as the root, `before-settings.json`, and another fresh output directory with the same driver.

Provisional CLI rejections remain retained: live preview required an HTTP graph URL, so the user’s no-service instruction was honored with offline `bo_design show` and the actual conversation diagram; no live URL was fabricated. An initial edit to the frozen modeling-obligation wording was rejected and reverted; the final obligation bytes are unchanged. An absolute concept-diff path was rejected and rerun successfully as a contained relative path.

## Handoff

The two authorized repairs and corresponding bounded native regression are complete. The installed VibeLens and all validators remain untouched. Transaction completion identity/rollback validation is owned by the maintenance repository. Await its new independent installation and subsequent full HTTP/browser recording instructions. No accept ran.
