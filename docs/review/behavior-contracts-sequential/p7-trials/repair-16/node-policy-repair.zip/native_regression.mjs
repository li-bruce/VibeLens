// Focused direct-native regression. No listener, HTTP client, browser or recording.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdtemp, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(process.env.BO_NATIVE_REGRESSION_ROOT || path.resolve(here, '../../..'));
const output = path.resolve(process.env.BO_NATIVE_REGRESSION_OUTPUT || here);
const settings = JSON.parse(await readFile(process.env.BO_NATIVE_REGRESSION_SETTINGS || path.join(here, 'native-settings.json'), 'utf8'));
const { Store, TEST_PASSWORD } = await import(pathToFileURL(path.join(root, 'src/store.mjs')).href);
const { FileService } = await import(pathToFileURL(path.join(root, 'src/service.mjs')).href);
const { bo_create } = await import(pathToFileURL(path.join(root, 'integrations/bo_observe.mjs')).href);
const { nativeAuditor, readInstances, readPersistedInstances } = await import(pathToFileURL(path.join(root, 'tests/native_reader.mjs')).href);
const project = JSON.parse(await readFile(path.join(root, 'bo_stategraph/project.json'), 'utf8'));
const hash = bytes => createHash('sha256').update(bytes).digest('hex');

async function run(mode) {
  const data = await mkdtemp(path.join(output, 'native-direct-' + mode + '-'));
  const database = path.join(data, 'db/application.sqlite');
  const store = new Store(database), service = new FileService(store, data);
  service.workerDelay = 60000;
  const events = [], snapshots = [], nativePolicies = [];
  const detach = service.subscribe(event => {
    if (event.phase === 'policy') nativePolicies.push({ invocation_id: event.invocationId, operation: event.decision.operation, decision: event.decision });
  });
  const observer = await bo_create(service, root, {
    project, buildId: settings.build_id, policyHash: settings.policy_hash,
    enabled: mode !== 'off', capacity: 4096,
    sink: async (body, kind) => {
      if (mode === 'fault') throw new Error('Deliberate direct-native observer outage');
      (kind === 'events' ? events : snapshots).push(body);
    }
  });
  const auditor = nativeAuditor(service, settings.build_id);
  const checks = [], selection = { grant: [], download_task: [], announcement: [], session: [] };
  const denied = (action, status = 403) => assert.rejects(action, error => error.status === status);
  const mark = (id, details = {}) => checks.push({ id, passed: true, ...details });
  try {
    await denied(() => service.login('alice', 'invalid'), 401);
    const accounts = {}, actors = {};
    for (const name of ['alice', 'bob', 'editor']) {
      accounts[name] = await service.login(name, TEST_PASSWORD);
      actors[name] = service.requireActor(accounts[name].token);
      selection.session.push(actors[name].trace_id);
    }
    const payload = Buffer.from('Native policy and listing repair regression.\n');
    const file = await service.upload(actors.alice, 'native-policy.txt', payload);
    const visible = async (name, allowed, stage) => {
      const listed = await service.listFiles(actors[name]);
      assert.deepEqual(listed.files.map(value => value.id), allowed ? [file.id] : []);
      if (allowed) assert.equal((await service.viewFile(actors[name], file.id)).id, file.id);
      else await denied(() => service.viewFile(actors[name], file.id));
      mark(stage + ':' + name, { list_count: listed.files.length, detail_allowed: allowed });
    };
    await visible('alice', true, 'initial');
    await visible('bob', false, 'initial');
    await visible('editor', false, 'initial');
    await denied(() => service.requestDownload(actors.editor, file.id));
    await service.setGrant(actors.alice, file.id, 'bob', true);
    selection.grant.push(file.id + '/bob');
    await visible('alice', true, 'granted');
    await visible('bob', true, 'granted');
    await visible('editor', false, 'granted');
    await denied(() => service.setGrant(actors.bob, file.id, 'editor', true));
    await denied(() => service.setGrant(actors.bob, file.id, 'bob', false));
    mark('recipient_cannot_reshare_or_revoke');
    const task = await service.requestDownload(actors.bob, file.id);
    selection.download_task.push(task.task_id);
    const admitted = readInstances(store, settings.build_id, selection).instances.find(row => row.state_model_id === 'download_task');
    assert.equal(admitted.state, 'queued');
    assert.equal(admitted.context.requester_id, 'bob');
    assert.equal(admitted.context.authorized_at_submission, true);
    mark('durable_submission_authorization');
    await denied(() => service.collect(actors.bob, task.task_id));
    await service.setGrant(actors.alice, file.id, 'bob', false);
    await visible('alice', true, 'revoked');
    await visible('bob', false, 'revoked');
    await visible('editor', false, 'revoked');
    await denied(() => service.requestDownload(actors.bob, file.id));
    mark('revocation_denies_new_requests');
    clearTimeout(service.workerTimer); service.workerBusy = false;
    await service.drainWorker();
    for (let iteration = 0; iteration < 2; iteration++) {
      const collected = await service.collect(actors.bob, task.task_id);
      assert.deepEqual(collected.bytes, payload);
      assert.equal(hash(collected.bytes), hash(payload));
    }
    await denied(() => service.collect(actors.editor, task.task_id));
    mark('admitted_task_survives_revoke_and_repeat_collection');
    await denied(() => service.publish(actors.alice, 'Rejected', 'Member lacks editor role.'));
    const announcement = await service.publish(actors.editor, 'Native board', 'Synthetic announcement.');
    selection.announcement.push(announcement.id);
    assert.equal((await service.announcements(actors.bob)).announcements.length, 1);
    await denied(() => service.mutateAnnouncement(actors.alice, announcement.id, 'delete'));
    await service.mutateAnnouncement(actors.editor, announcement.id, 'edit', 'Updated', 'Updated synthetic announcement.');
    await service.mutateAnnouncement(actors.editor, announcement.id, 'delete');
    assert.equal((await service.announcements(actors.alice)).announcements.length, 0);
    mark('independent_board_and_editor_ownership');
    for (const name of ['alice', 'bob', 'editor']) {
      await service.logout(accounts[name].token);
      assert.equal(service.session(accounts[name].token), null);
    }
    mark('native_logout');
    const enqueuedBefore = observer.health().enqueued;
    const authority = readInstances(store, settings.build_id, selection);
    const enqueuedAfter = observer.health().enqueued;
    assert.equal(enqueuedAfter, enqueuedBefore);
    const persisted = await readPersistedInstances(database, settings.build_id, selection);
    assert.deepEqual(persisted, authority);
    assert.deepEqual(auditor.errors, []);
    await observer.probe.flush(10000);
    const health = observer.health();
    assert.equal(health.pending, 0); assert.equal(health.dropped, 0);
    if (mode === 'on') assert.equal(health.errors, 0);
    if (mode === 'off') assert.equal(events.length, 0);
    if (mode === 'fault') assert.ok(health.errors > 0);
    const outcomes = {
      checks: checks.map(({ id, passed }) => ({ id, passed })),
      prepared_sha256: hash(payload),
      grant_state: authority.instances.find(row => row.state_model_id === 'grant').state,
      task_state: authority.instances.find(row => row.state_model_id === 'download_task').state,
      task_authorized_at_submission: authority.instances.find(row => row.state_model_id === 'download_task').context.authorized_at_submission,
      announcement_state: authority.instances.find(row => row.state_model_id === 'announcement').state,
      sessions_ended: authority.instances.filter(row => row.state_model_id === 'session' && row.state === 'ended').length
    };
    const output = {
      case: 'native_policy_listing', mode, build_id: settings.build_id,
      scope: 'Focused direct-native regression. Original HTTP and complete workflow scenarios are retained but not executed by this driver.',
      checks, outcomes, events, snapshots, policy_evaluations: observer.evaluations,
      native_policies: nativePolicies, authority_snapshot: authority,
      native_states: auditor.stateValues, native_completions: auditor.completions,
      observer_query_exclusion: { before: enqueuedBefore, after: enqueuedAfter, emitted: enqueuedAfter - enqueuedBefore },
      persisted_native_rows_equal: true, probe_health: health
    };
    await writeFile(path.join(data, 'native-result.json'), JSON.stringify(output, null, 2), { flag: 'wx' });
    return output;
  } finally {
    auditor.close(); detach(); await service.stop(); await observer.close(); store.close();
  }
}

const runs = [];
try {
  for (const mode of ['on', 'off', 'fault']) runs.push(await run(mode));
  assert.deepEqual(runs[0].outcomes, runs[1].outcomes);
  assert.deepEqual(runs[0].outcomes, runs[2].outcomes);
  await writeFile(path.join(output, 'native-focused-runs.json'), JSON.stringify({
    valid: true, scope: 'Focused direct-native regression, separate from the protected full-suite observations.',
    provider: process.env.VIBELENS_SKILL, application_root: root, build_id: settings.build_id, runs,
    http_or_server_started: false, browser_or_recording_started: false,
    native_outcomes_equal_on_off_fault: true, original_checks_unchanged: true
  }, null, 2), { flag: 'wx' });
  console.log(JSON.stringify({ valid: true, checks_per_mode: runs.map(run => run.checks.length), events: runs.map(run => run.events.length), native_outcomes_equal: true }));
} catch (error) {
  await writeFile(path.join(output, 'native-focused-failure.json'), JSON.stringify({ error: error.stack, completed_modes: runs.map(run => run.mode) }, null, 2), { flag: 'wx' });
  throw error;
}
