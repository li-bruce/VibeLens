"""Configure real SQLite metadata and selected native data-operation evidence."""
import json
import os
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
SKILL=Path(os.environ.get("VIBELENS_SKILL",ROOT.parent/"node-migration-final-skills/vibelens"))
sys.path.insert(0,str(SKILL/"scripts"))
from bo_observer.data.sync import synchronize

def read(name):return json.loads((ROOT/name).read_text(encoding="utf-8-sig"))
def write(name,value):(ROOT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
tables=["users","sessions","files","grants","tasks","announcements"]
doc=read("discovery.json")
answer=next(s["text"] for s in doc["sources"] if s["id"]=="U3")
config={"protocol":"bo-databases/v1","stores":[{"id":"application","label":"Native application SQLite","engine":"sqlalchemy","url_env":"TEAM_FILES_SQLITE_URL","selection":{"source":"user","answer":answer[:1024],"locator":"U3 in discovery.json: SQLite with project-local file bytes"},"model_layer":"Shared native SQLite DDL; sql.js application storage; offline SQLAlchemy reflection/export of that DDL in memory.","source_files":["src/schema.sql","src/store.mjs","integrations/bo_export_schema.py"],"declaration":"bo_stategraph/database-declaration.json"}],"operations":[],"exporters":[{"store":"application","command":["{python}","-B","integrations/bo_export_schema.py"],"output":"bo_stategraph/database-declaration.json"}]}
for action in ["read","write"]:
    operation={"id":"data_"+action,"label":"Native SQLite "+action,"parent":"request_download","source":{"path":"src/store.mjs","symbol":"Store.all" if action=="read" else "Store.run"},"store":"application","action":action,"targets":["table:"+t for t in tables],"parameters":{},"before":{},"after":{},"required_cases":["workflow","storage_failure"],"failure_cases":["storage_failure"],"requirements":["R_AUTH","R_FILES","R_DOWNLOAD","R_BOARD"]}
    if action=="write":operation["target_actions"]={"table:"+t:"write" for t in tables}
    config["operations"].append(operation)
config["operations"].append({"id":"data_admission_transaction","label":"Commit admitted task or roll back","parent":"request_download","source":{"path":"src/service.mjs","symbol":"FileService.requestDownload"},"store":"application","action":"transaction","targets":["table:tasks"],"parameters":{},"before":{},"after":{},"required_cases":["workflow","storage_failure"],"failure_cases":["storage_failure"],"requirements":["R_DOWNLOAD"]})
write("bo_stategraph/databases.json",config)
os.environ.setdefault("TEAM_FILES_SQLITE_URL","sqlite:///var/db/application.sqlite")
result=synchronize(ROOT,model_path="bo_stategraph/project.json",update=True,force=True)
write("review/database-sync.json",result)
if not result["valid"]:raise ValueError(result["errors"])
project=read("bo_stategraph/project.json");model=project["model"];plan=model["implementation"]
for action in ["read","write"]:
    ident="data_"+action;symbol="src/store.mjs::Store."+("all" if action=="read" else "run")
    plan["support"].pop(symbol,None)
    plan["features"].append({"id":ident,"label":"Native SQLite "+action,"business_node":"request_download","nodes":[ident],"sources":[symbol],
        "parameters":[{"source":symbol,"name":name,"node":ident,"direction":"in","field":field,"policy":"derived","reason":"Derive only the native operation category or an empty nonsecret parameter projection. Raw SQL and bound values are withheld; actual public identities are selected separately at the native business boundary."} for name,field in [("sql","statement"),("parameters","parameters")]],
        "cases":[{"case":"workflow","node":ident,"phase":"return"},{"case":"storage_failure","node":ident,"phase":"error"}],"requirements":["R_AUTH","R_FILES","R_DOWNLOAD","R_BOARD"]})
request=next(f for f in plan["features"] if f["id"]=="request_download")
request["nodes"].append("data_admission_transaction")
request["cases"].extend([{"case":"workflow","node":"data_admission_transaction","phase":"commit"},{"case":"storage_failure","node":"data_admission_transaction","phase":"error"}])
write("implementation.json",plan);model["implementation"]=plan;write("bo_stategraph/project.json",project)
print(json.dumps({"database":"SQLite","stores":len(config["stores"]),"operations":len(config["operations"]),"valid":result["valid"]}))
