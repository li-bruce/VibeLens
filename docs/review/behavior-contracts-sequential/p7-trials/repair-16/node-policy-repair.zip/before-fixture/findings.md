# Findings

- User U4 explicitly confirms the displayed business/state/rule graph and authorizes implementation.
- User additionally requires real username/password login/logout; three test accounts, one announcement editor; no registration/account management UI.
- Node v20.19.6, npm 10.8.2 are installed. Node 20 does not supply the newer built-in SQLite API, so use a project-declared native SQLite dependency.
- The selected external Skill is v0.15.0 in ../node-retest-skills/vibelens. Supplied Python is ../../../../.venv/Scripts/python.exe by absolute path in the environment.
- Managed JavaScript BO runtime/capture modules installed through bo_integrate.py apply; framework source is untouched.
- Existing design-only graph is http://127.0.0.1:8926/graph. Host-launched processes are reachable by Chrome; sandbox-launched servers timed out. Keep this distinction when launching the application/observer.
SQLite implementation decision: use sql.js (SQLite compiled to WebAssembly) with project-local SQLite-file persistence. This avoids installing C++ tooling after the native-addon download failure. Native SQLite transactions and a commit-time atomic file replacement remain application-owned.

- The early origin guard precedes the original route-local HTTP probe; a real
  forbidden login request therefore returned 403 with no API return event. This
  was independently reproduced, rather than inferred from middleware order.
- The new managed bo_http adapter observes a native listener before middleware,
  closes once on response finish/close, and uses completed=false with no status
  if headers were never sent. Its route resolver must reuse native registrations.
- The new provider's current bo_integrate plan rejects addition of bo_http.mjs to
  the two-file receipt. This is a managed migration gap, not business permission
  ambiguity. The old installation and pre-repair native files remain unchanged.
- In this Windows Python environment, Path('.').resolve() unexpectedly appends
  the workspace basename. Use an explicit absolute root (or Path(os.getcwd()))
  in diagnostics; the project helpers use their absolute __file__ parent.

- Batch candidate unified-1795147982 has a successful first recording and a
  separate failed second recording. Do not flatten these into one outcome.
- The second wait failed before stop while Team files was visible. Received
  native events were produced within five seconds, then drained for over forty
  seconds. Exact timeout health was not retained; later stop health is labeled
  separately. A session-absent snapshot (evidence sequence 2200, 572 bytes) timed
  out twice. Actual server admission and the exact slow function are unresolved.
- All returned native observer HTTP responses were 200; ten attempts timed out.
  The 234 batch attempts contain 4213 items including retries. Request sizes and
  response-header latencies are retained; receipt bodies and exact batch members
  were absent in that original audit. New audit instrumentation does not recreate
  those missing historical values.
- A static old-provider bo_internal import has a distinct AsyncLocalStorage
  instance from dynamically selected data wiring, even when module bytes match.
  Aligning the reader's provider fixes independent-query suppression and requires
  fresh native evidence. The live browser app never imports that reader.
- Off/fault child environments formerly overrode the selected provider. They
  now inherit it, and future single-parent runs assert provider and served-SDK
  equality. Previous equal business results remain mixed-provider observations.
