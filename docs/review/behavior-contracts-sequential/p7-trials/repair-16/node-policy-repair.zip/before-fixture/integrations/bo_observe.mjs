import { readFile } from 'node:fs/promises';
import { createHash, randomUUID } from 'node:crypto';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { context } from '@opentelemetry/api';
import { AsyncLocalStorageContextManager } from '@opentelemetry/context-async-hooks';
import { TracerProvider } from '@opentelemetry/sdk-trace';
import { BOProbe } from '../bo_stategraph/bo_runtime.mjs';
import { BOCaptureClient } from '../bo_stategraph/bo_capture.mjs';
import { bo_attach_data } from './bo_data_wiring.mjs';
import { bo_wrap_http } from './bo_http_wiring.mjs';

let bo_context_manager;
/** Read the selected canonical artifact without altering it. */
async function bo_json(filename) { return JSON.parse(await readFile(filename, 'utf8')); }
/** Hash source bytes for native predicate-binding provenance. */
function bo_hash(bytes) { return createHash('sha256').update(bytes).digest('hex'); }
/** Resolve the real context fields from a native model-qualified row. */
function bo_context(model, row) {
  if (model === 'download_task') return { file_id: row.file_id, requester_id: row.requester_id, authorized_at_submission: Boolean(row.authorized_at_submission) };
  if (model === 'announcement') return { author_id: row.author_id };
  if (model === 'session') return { user_id: row.user_id };
  return {};
}
/** Observe selected actual native decisions/state; this module never calls a business predicate. */
export async function bo_create(service, root, options) {
  const project = options.project || await bo_json(path.join(root, 'bo_stategraph/project.json'));
  const probe = new BOProbe({ project, buildId: options.buildId, endpoint: options.endpoint, token: options.token, sink: options.sink, enabled: options.enabled !== false, capacity: options.capacity || 4096 });
  const skill = process.env.VIBELENS_SKILL || path.resolve(root, '../node-migration-final-skills/vibelens');
  const { BOOpenTelemetry } = await import(pathToFileURL(path.join(skill, 'scripts/bo_observer/adapters/javascript/bo_otel.mjs')).href);
  const { bo_observeHttp } = await import(pathToFileURL(path.join(root,'bo_stategraph/bo_http.mjs')).href);
  if (!bo_context_manager) {
    bo_context_manager = new AsyncLocalStorageContextManager().enable();
    context.setGlobalContextManager(bo_context_manager);
  }
  const provider = new TracerProvider();
  const nativeTracer = provider.getTracer('team-files-vibelens');
  const routeBindings = (await bo_json(path.join(root, 'review/native-node-index.json'))).api;
  const bo_tracer = {
    startSpan(name, spanOptions, parentContext) {
      const registered = routeBindings[name];
      const attributes = registered ? { 'http.request.method': registered[0], 'http.route': registered[1] } : {};
      return nativeTracer.startSpan(name, { ...spanOptions, attributes: { ...spanOptions.attributes, ...attributes } }, parentContext);
    }
  };
  probe.bo_bind_tracing(new BOOpenTelemetry(bo_tracer));
  const spans = new Map(), evaluations = [], stateFrames = [], nativeDecisions = [];
  const transactions = new Map();
  const dataTransactions = new Map();
  const data=await bo_attach_data(probe,service,root);
  const nativeBindings = await bo_json(path.join(root, 'bo_stategraph/native-bindings.json'));
  const policy = project.model.policy, operationIndex = new Map(policy.operations.map(op => [op.id, op]));
  const expressionIndex = new Map(policy.nodes.map(node => [node.id, node]));
  const predicateHash = bo_hash(await readFile(path.join(root, 'src/policy.mjs')));
  const fingerprint = options.policyHash || (await bo_json(path.join(root, 'review/policy-fingerprint.json'))).hash;
  const callback = event => {
    if (!probe.bo_enabled) return;
    const node = event.name;
    const active = spans.get(event.invocationId);
    if (event.phase === 'enter' && probe.bo_nodes.has(node)) {
      const parent = spans.get(event.parentInvocationId);
      const span = probe.startSpan(node, () => ({ inputs: event.inputs }), { callId: event.invocationId, parentCallId: event.parentInvocationId || null, parentEventId: parent?.entryId || null, entity: 'application', attempt: 'application', scope: 'application' });
      spans.set(event.invocationId, span);
    } else if ((event.phase === 'return' || event.phase === 'error') && active) {
      const outputs = { ...event.outputs };
      if (event.name === 'read_announcements') outputs.count = event.outputs.announcements?.length || 0;
      if (event.name === 'list_tasks') outputs.count = event.outputs.tasks?.length || 0;
      const builder = () => ({ outputs, ...(event.exception ? { exception: { type: event.exception } } : {}) });
      if (event.phase === 'error') active.fail(builder); else active.finish(builder);
      spans.delete(event.invocationId);
    } else if (event.phase === 'policy') {
      const native = event.decision, operation = operationIndex.get(native.operation);
      if (!operation) return;
      nativeDecisions.push({ invocation_id: event.invocationId, operation: native.operation, facts: native.facts, allowed: native.allowed });
      const parentOptions = { parentCallId: event.invocationId, parentEventId: active?.entryId || null, callId: randomUUID(), entity: 'application', attempt: 'application', scope: 'application' };
      probe.record('policy_facts', 'read', () => ({ inputs: { operation: native.operation, invocation_id: event.invocationId }, outputs: native.facts }), parentOptions);
      probe.record('guard_' + native.operation, 'decision', () => ({ inputs: { operation: native.operation }, outputs: { value: native.allowed } }), { ...parentOptions, callId: randomUUID() });
      const check = randomUUID(), factRevision = event.invocationId + ':' + check;
      const trace = [], emitted = new Map();
      for (const step of native.steps) {
        const definition = expressionIndex.get(step.id);
        const references = definition.op === 'predicate' ? [...new Set(Object.values(definition.arguments))] : definition.inputs || [];
        const used = definition.op === 'predicate' ? references : step.visited || [];
        const skipped = definition.op === 'predicate' ? [] : step.skipped || [];
        const record = { node: step.id, value: step.value, status: 'completed', arguments: step.arguments || {}, used, skipped };
        trace.push(record);
        const eventId = probe.record('policy:' + step.id, 'decision', () => ({
          inputs: { bo_check: check, bo_basis: factRevision, ...(step.arguments || {}) }, outputs: { value: step.value, status: 'completed' }
        }), { ...parentOptions, callId: randomUUID(), depends: used.filter(id => emitted.get(id)).map(id => ({ event: emitted.get(id), type: 'control' })) });
        emitted.set(step.id, eventId);
      }
      evaluations.push({ schema: 'bo-policy-evaluation/v1', policy_revision: policy.revision, policy_hash: fingerprint, check_id: check, fact_revision: factRevision, operation: native.operation, inputs: native.facts, bindings: { same_identity: { path: 'src/policy.mjs', symbol: 'sameIdentity', file_sha256: predicateHash } }, root: operation.root, value: native.allowed, decision: native.allowed ? 'allow' : 'deny', trace, diagnostics: [] });
    } else if (event.phase === 'transaction_enter') {
      transactions.set(event.transaction_id, probe.startSpan('task_commit', () => ({ inputs: { task_id: event.task_id, transaction_id: event.transaction_id } }), { callId: event.transaction_id, parentCallId: event.invocationId, parentEventId: active?.entryId || null, scope: 'application' }));
      const invocation={callId:randomUUID(),parentCallId:event.invocationId,parentEventId:active?.entryId || null,entity:'application',attempt:'application',scope:'application'};
      const inputs={operation:'transaction',statement:'transaction',parameters:{}};
      const outputs={status:'started',duration_ms:0,targets:['table:tasks'],unknown_targets:[],target_source:'provided',target_access:[],transaction_id:event.transaction_id};
      const entry=probe.record('data_admission_transaction','enter',()=>({inputs,outputs}),{...invocation,contextBoundary:'start'});
      dataTransactions.set(event.transaction_id,{invocation,inputs,outputs,entry,started:performance.now()});
    } else if (event.phase === 'commit' || event.phase === 'rollback') {
      const effect = transactions.get(event.transaction_id);
      const completion = () => ({ outputs: { committed: event.committed, ...(typeof event.authorized_at_submission==='boolean'?{authorized_at_submission:event.authorized_at_submission}:{}), transaction_id: event.transaction_id } });
      if (event.phase === 'commit') effect?.finish(completion); else effect?.fail(completion);
      transactions.delete(event.transaction_id);
      const transaction=dataTransactions.get(event.transaction_id);
      if(transaction)probe.record('data_admission_transaction',event.phase==='commit'?'commit':'error',()=>({inputs:transaction.inputs,outputs:{...transaction.outputs,status:event.phase==='commit'?'committed':'rolled_back',duration_ms:performance.now()-transaction.started,committed:event.committed,...(event.phase==='rollback'?{error_type:event.error_type}: {})}}),{...transaction.invocation,contextBoundary:'end'});
      dataTransactions.delete(event.transaction_id);
    } else if (event.phase === 'state') {
      const id = 'native_state:' + event.model + ':' + event.state, values = bo_context(event.model, event.row);
      const eventId = probe.record(id, event.event ? 'change' : 'read', () => ({ inputs: { instance_id: event.id, invocation_id: event.invocationId }, outputs: { state: event.state, revision: event.revision, state_model_id: event.model, event_name: event.event, before: event.before, ...values } }), { callId: randomUUID(), parentCallId: event.invocationId, parentEventId: active?.entryId || null, revision: event.revision, scope: 'application', entity: 'application', attempt: 'application' });
      const guards = event.event ? Object.fromEntries((project.model.machines[event.model].transitions.find(t => t.trigger === event.event)?.conditions || []).map(name => [name, event.native_decisions?.[nativeBindings.guards[event.model][name]]])) : null;
      probe.snapshot(event.id, event.state, values, event.revision, eventId, { stateModelId: event.model, event: event.event, guards, payload: event.event ? {} : null });
      if (event.event) {
        // The native_state event owns the transaction's state-frame boundary.
        // This separate value witness retains the actual row revision in its
        // selected outputs without declaring another native state transition.
        probe.record('state_value:' + event.model, 'change', () => ({ inputs:{instance_id:event.id,invocation_id:event.invocationId}, outputs:{model_ref:'state-model:' + event.model,state:event.state,revision:event.revision,event_name:event.event,...values} }), { callId:randomUUID(),parentCallId:event.invocationId,parentEventId:active?.entryId || null,entity:'application',attempt:'application',scope:'application' });
      }
      stateFrames.push({ model: event.model, id: event.id, state: event.state, revision: event.revision, context: values, event: event.event });
    }
  };
  const unsubscribe = service.subscribe(callback);
  service.instrumentation = {
    around: (nativeContext, execute) => {
      const span = spans.get(nativeContext.invocationId);
      return span ? span.run(execute) : execute();
    }
  };
  let capture = null, captureStartupErrors = 0;
  if (options.endpoint && options.enabled !== false) {
    try { capture = await new BOCaptureClient(probe).start(); }
    catch { captureStartupErrors++; }
  }
  return {
    probe, evaluations, stateFrames, nativeDecisions,
    /** Wrap the actual native listener before any origin, authentication or parser middleware. */
    wrapHttp(app) { return bo_wrap_http(app,probe,service,routeBindings,bo_observeHttp); },
    clientConfig() { return { project, buildId: options.buildId, endpoint: options.endpoint, token: options.token, capacity: 4096 }; },
    /** Own the real matched HTTP interval before body parsers run. */
    httpStart(id, method, requestPath, invocationId) {
      const start = performance.now(), span = probe.startSpan(id, () => ({ inputs: { method, path: requestPath } }), { callId: invocationId, entity: 'application', attempt: 'application', scope: 'application' });
      const finish = (status,completed=true) => span.finish(() => ({ outputs: { ...(status===undefined?{}:{status}),completed,duration_ms: performance.now() - start } }));
      finish.run = callback => span.run(callback); return finish;
    },
    async close() { unsubscribe(); data.close(); delete service.instrumentation; await capture?.close(); await probe.flush(10000); await provider.shutdown(); },
    health() { return { ...probe.bo_health(), data_errors:data.runtime.bo_errors, capture_control_errors: (capture?.bo_errors || 0) + captureStartupErrors }; }
  };
}
/** Optional external observer bootstrap; application execution remains native. */
export async function bo_start(service, root) {
  const settings = await bo_json(path.join(root, '.stategraph/collector.json'));
  if(process.env.VIBELENS_ENDPOINT){
    const endpoint=new URL(process.env.VIBELENS_ENDPOINT);
    if(endpoint.protocol!=='http:' || !['127.0.0.1','localhost'].includes(endpoint.hostname))throw new Error('Observer override requires a local HTTP test endpoint');
    settings.endpoint=endpoint.origin;
  }
  return bo_create(service, root, { ...settings, buildId: settings.build_id });
}
