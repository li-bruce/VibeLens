# Implementation plan

Objective: deliver the confirmed Node.js team file-sharing application with real login/logout, three synthetic accounts, SQLite/local files, independent announcements and external VibeLens observe-mode evidence.

Protected boundaries: work only in node-retest-app; do not change other applications or maintained VibeLens code. Managed native adapters and installed tool dependencies are allowed only through canonical Skill interfaces. No ARIS.

1. Record the actual graph confirmation and login instruction; preserve the semantic baseline. complete
2. Implement native storage, sessions, file permissions, queued preparation and announcements. complete
3. Build the Chinese browser UI with separate files/tasks/board views. complete
4. Connect canonical external observation, state/rule/data/source mappings and independent cases. in_progress
5. Run business, mapping, native-state and project checks; inspect browser behavior; fix failures. in_progress
6. Deliver running URLs, three test accounts, commands and bounded results. pending

No prior code baseline exists. Establish change_sync begin only after a parseable native scaffold and mappings exist; later edits use the active immutable baseline.

Current baseline is established and immutable: initial-node-app/baseline.json,
e7b11f4d284aee13d86d26183ea94b7219114d7994bec8cf632726e0981ab0bb.

2026-11-20 steering: preserve pre-repair source/model/evidence; finish early HTTP
rejection capture, selected fields, lifecycle and existing acceptance. The first
upgrade rejection and supported migration are retained. The final user-selected
provider is node-migration-final-skills/vibelens (reported export commit 9ddd6661).
All three managed adapters pass its integrity check and remain unedited.

Real browser trials exposed and retained project wiring failures: canonical
build_id needed conversion to the native buildId option, absolute asset paths
under .validation returned 404, and duplicate state-value witnesses incorrectly
claimed native state-frame boundaries. These are repaired in project-owned code;
all selected state/revision outputs remain. One actual rapid stop retained an
interrupted recording with an explicit undrained-queue gap. No failed recording
was rewritten. Native nine-case evidence and baseline integrity are retained.

After the desktop control session expired, the user explicitly authorized an
independent Playwright browser. Fresh real-page trials, screenshots, downloads
and current-build recording acceptance are in progress. Do not advance business
semantics until mapping and final verify/accept/check finish.

The batch provider is currently diagnostic only. Its first recording passed;
its second finite burst exceeded the unchanged pending-zero wait and retained
an actual double-timeout snapshot error. The preserved diagnosis, raw seal and
harness provider/health/receipt corrections are in progress.md. Do not promote
this candidate or reuse the old browser build after the reader-source change.

Current diagnostic provider is admission-candidate-skills/vibelens (repair09),
selected process-locally; canonical JS adapters are unchanged. Its one timed
first-recording retest is interrupted from a double receipt timeout at seq34,
although all events ultimately arrived. The09 watcher memo was observed to avoid
repeated full project validation. Residual tick/binding subphases remain under
maintenance investigation. Preserve all prior raw recordings/seals and keep
full browser/replay and final verify/accept/check pending. Do not run another
diagnostic or begin business changes without the next maintenance instruction.


Current maintenance status (2026-11-20): the requested canonical upgrade and strict-only checks are complete, with inspect/verify failed and preserved. Integration/docs/API/database pass. Registration/review/naming metadata need a separate maintenance step; runtime evidence remains pending. Preserve the admission/revocation distinction, all570 captures and the immutable baseline. No new recording or accept until the coordinating instruction. Detailed handoff: review/runtime/INTERACTIVE_UPGRADE_20261120.md.
