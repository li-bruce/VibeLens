# Business, state and rule review

Status: assembled from actual user answers U1/U2/U3; awaiting confirmation of the displayed combined graph. No application behavior, source binding or runtime acceptance exists.

[Open verified graph](http://127.0.0.1:8926/graph)

## Business networks

This compact diagram retains every authored business operation and route in discovery.json. State/rule boundaries are expanded below and in Web. Independent capabilities retain separate roots.

```mermaid
flowchart LR
  subgraph files["文件共享"]
    upload_file["上传文件"]
    share_file["分享给同事"]
    revoke_share["撤销共享"]
    view_file["查看文件"]
    upload_file -->|"选择已上传文件"| share_file
    share_file -->|"按需撤销"| revoke_share
    upload_file -->|"查看已上传文件"| view_file
  end
  subgraph downloads["下载准备与领取"]
    request_download["申请下载"]
    prepare_download["后台准备"]
    mark_download_ready["准备完成"]
    collect_download["页面领取"]
    request_download -->|"排队后开始"| prepare_download
    prepare_download -->|"产物准备完成"| mark_download_ready
    mark_download_ready -->|"已获准任务可领取"| collect_download
    collect_download -->|"同一申请人可重复领取"| collect_download
  end
  subgraph announcements["独立公告板"]
    publish_announcement["发布公告"]
    read_announcements["阅读公告"]
    edit_announcement["修改自己的公告"]
    delete_announcement["删除自己的公告"]
    publish_announcement -->|"已发布内容"| read_announcements
    publish_announcement -->|"作者按需修改"| edit_announcement
    publish_announcement -->|"作者按需删除"| delete_announcement
  end
```

## Independent state models

```mermaid
flowchart LR
  subgraph sm_grant["逐人共享权限"]
    s_grant_inactive["共享无效"]
    s_grant_active["共享有效"]
    s_grant_inactive -->|"上传者分享"| s_grant_active
    s_grant_active -->|"上传者撤销"| s_grant_inactive
  end
  subgraph sm_download_task["下载准备任务"]
    s_download_task_created["任务已创建"]
    s_download_task_queued["排队中"]
    s_download_task_preparing["准备中"]
    s_download_task_ready["可重复领取"]
    s_download_task_created -->|"提交时获准"| s_download_task_queued
    s_download_task_queued -->|"后台开始"| s_download_task_preparing
    s_download_task_preparing -->|"准备完成"| s_download_task_ready
  end
  subgraph sm_announcement["公告"]
    s_announcement_absent["尚无公告"]
    s_announcement_published["已发布"]
    s_announcement_deleted["已删除"]
    s_announcement_absent -->|"编辑员发布"| s_announcement_published
    s_announcement_published -->|"作者修改"| s_announcement_published
    s_announcement_published -->|"作者删除"| s_announcement_deleted
  end
```

Each grant is identified by file_id and recipient_id. Each download task has task_id, file_id and requester_id. Each announcement has announcement_id and author_id. Task allocation and announcement identity allocation are internal boundaries, not user-facing drafts. Collection reads a ready task and leaves it ready. Announcement edits retain published state; deletion is independent of files and tasks.

## Rule timing

```mermaid
flowchart LR
  member["当前已登录同事"]
  file_access["上传者 或 当前有效接收人"]
  may_access["同时满足：可查看文件／新建任务"]
  member --> may_access
  file_access --> may_access
  task_is_mine["操作者是原申请人"]
  submission_authorized["这一单提交时已获准"]
  task_is_ready["这一单准备好了"]
  may_collect["同时满足：可重复领取这一单"]
  member --> may_collect
  task_is_mine --> may_collect
  submission_authorized --> may_collect
  task_is_ready --> may_collect
```

| Operation | Decision |
| --- | --- |
| Upload file | Authenticated colleague. |
| Share or revoke | Authenticated colleague AND actor equals file uploader. |
| View file / create download task | Authenticated colleague AND (actor equals file uploader OR (actor equals designated recipient AND current grant is active)). |
| Collect existing task | Authenticated colleague AND actor equals original requester AND persisted submission authorization AND task status equals ready. File grants and announcement roles are not inputs. |
| Read board | Authenticated colleague; only published content is returned. |
| Publish announcement | Authenticated colleague AND announcement editor. |
| Edit/delete announcement | Authenticated colleague AND announcement editor AND actor equals announcement author AND announcement status equals published. |

The current file owner, recipient and grant are read at each file operation and new task submission. Authorization, task identity and requester are committed together at submission. Collection reads the selected task's persisted submission authorization, requester and status. The session is checked for every request. Announcement role, author and publication state are read at each current operation. Announcement roles do not appear in file-policy roots.

## Implementation boundary

The Node.js application's own logic is authoritative. Its worker performs actual preparation. VibeLens observes actual decisions and state without repeating business permission checks. U3 selected SQLite and project-local file storage. All three lifecycles are flat and independently identified, matching the documented multi-model observation contract. Source bindings and runtime witnesses remain pending implementation.

## Independent expected outcomes

- Unrelated colleagues cannot discover, view, download or manage an unshared file.
- A recipient cannot re-share or revoke the uploader's grant.
- A permitted task can finish and be repeatedly collected by its original requester after revocation. A new request after revocation is denied.
- A different colleague cannot collect another requester's task.
- An editor cannot edit/delete another author's announcement, and the editor role adds no file right.
- Source mapping, per-model runtime evidence, observation-on/off/failure comparisons and project checks are required during implementation; none are claimed now.
