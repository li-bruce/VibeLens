# Prepared only: selected-method timing

No diagnostic process has been started. Wait for the coordinating chat to report the end of full root regression. Use the provider it selects; do not rerun the historical watchdog helper.

The opt-in viewer_timing.py wrapper times exactly GraphSession.binding, _view_model, view, snapshot; BOSessionSink.bo_accept_many; DataWatch.tick; and protocol.validate_project. It forwards each original call once, returns the same object, re-raises the same exception and does not replace application locks. A separate SimpleQueue writer records method start/end, thread name, elapsed time and nesting. Existing aliases of validate_project are handled without changing installed files.

The installed server's GET/POST/OPTIONS dispatch and reply add request timing metadata. The body is not read again. On the native client, built-in undici request:create/sendHeaders diagnostic channels associate the existing audit UUID with the socket tuple and connection request index. They do not add a header or change options, payloads, signals or SDK retries. The offline summarizer joins only a unique transport match and leaves missing/ambiguous pairs visible. Browser-only HTTP traffic is not automatically claimed as native-client-correlated traffic.

Prepared invocation, after the root regression-end notice and using its selected provider:

    python tooling/unified_browser_run.py --recording --audit-network --timing-viewer

Use the supplied project Python path and process-local BO_DIAGNOSTIC_SKILL/BO_LOAD_CONTEXT as in prior owned runs. The parent continues to own app, viewer, mode fixtures and browser, with existing readiness and cleanup rules. New data is viewer-method-timing.jsonl plus transport_send_headers rows in native-fetch.jsonl. Afterwards summarize an actual run with:

    python tooling/summarize_method_timing.py ABSOLUTE_RUN_DIRECTORY

Python/JavaScript syntax, original result/exception identity, one original call and context restoration checks passed without starting a writer or server. Strict canonical API check also passed. Node's bundled undici source was inspected for the two channel shapes. Actual TCP correlation and timing overhead remain unverified until the one authorized diagnostic run.

Dispatch-to-binding includes original parsing, validation, session borrowing and lock waits; it does not directly measure a mutex. Nested durations overlap. The wrapper uses no faulthandler, sys.settrace or whole-program profiler. Existing SDK deadlines and business/recording assertions remain unchanged. Failed recordings stay failed; final accept remains pending.
