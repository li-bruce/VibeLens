# Admission completion expectation

The confirmed download model already declares `persist_authorized_task` on the
`created -> queued` transition, completed at the native transaction commit.
The existing discovery expectations do not explicitly select that effect. The
binding checker therefore rejects its completion witness even though the native
HTTP/SQLite test already checks the committed row.

Proposed explicit expectation, with no additional application feature:

- Given: the current requester is allowed to submit a task.
- When: the native task-admission transaction completes.
- Then: the task, original requester and `authorized_at_submission=true` are
  persisted together; the API returns task acceptance only after commit.
- Expected path: `admission.committed == true`.
- Canonical scope: `transition:download_task:enqueue` and
  `effect:download_task:persist_authorized_task`.
- Independent evidence: real HTTP 202, an independent SQLite read, successful
  artifact preparation after revocation and matching native transaction identity.

This proposed item is not a new human confirmation. Its actual answer must be
recorded before the discovery definition and confirmation history are extended.
