# UI direction

Audience: three colleagues sharing files and collecting prepared downloads. The application's job is to make ownership, recipient access and task readiness immediately visible.

Palette: ink #193245, canvas #eef3f6, paper #ffffff, teal #087e80, amber #9b6418, red #b13c42. No decorative gradients.

Typography: Segoe UI / Microsoft YaHei for body and headings; Consolas for small file sizes, task identifiers and times. A compact left navigation, broad file-list rows and a narrow upload panel fit a team workspace.

Signature: each download task has an explicit stage rail (queued / preparing / ready) and a small submission-authorization note; file sharing controls and announcement editor controls are visually separated. This serves the confirmed entitlement distinction, rather than adding a generic hero or metric cards.

Accessibility: real labels, visible focus, responsive stacked columns, text statuses beside colors, reduced motion. Errors explain the rejected action; rendering uses textContent for user input.
