# Team File Sharing

A Chinese-language Node.js application with real password sessions, uploader-owned
file sharing, durable download preparation and an independent announcement board.
SQLite and all uploaded/prepared bytes remain inside the project. VibeLens observes
the native implementation; the native service owns authorization and state.

Run from this project directory with Node.js 20.19 or newer:

```powershell
npm ci
npm run build:observer
npm run dev
```

The development command starts the application at http://127.0.0.1:8925 and the
external graph at http://127.0.0.1:8926/graph. It prints both URLs and tracks only
its own child processes. Ctrl+C stops those children. Its default external provider
is `../node-migration-final-skills/vibelens`, and its default Python is the supplied
`../../../.venv/Scripts/python.exe`. Override `VIBELENS_SKILL` or `VIBELENS_PYTHON`
when relocating this trial. No installed Skill files need editing.

| Username | Display name | Role |
| --- | --- | --- |
| alice | 林澈 | Member |
| bob | 陈可 | Member |
| editor | 叶青 | Announcement editor |

All three synthetic test passwords are `DemoPass!2026`. There is no registration or
account-management page. Only an uploader can grant/revoke file access. The editor
can manage their own announcements and has no additional file privilege.

A download submission commits the task, its requester and the submission-time
authorization together before acknowledgment. Revocation blocks subsequent tasks
and file visibility. An already accepted task still prepares, and its original
authenticated requester may collect the ready artifact repeatedly.

For native operation without the observer, use `npm start` (observation is disabled
by default). `PORT` and `APP_DATA_ROOT` select a loopback port and local storage
directory. Data defaults to `var/db/application.sqlite`, `var/uploads` and
`var/prepared`. Do not remove `var` when retaining application records.

`npm test` exercises real HTTP, SQLite and disk behavior. The independent observation
runner is `tooling/observe.py`, executed with the supplied Python environment and
the selected external Skill. `tooling/project_checks.py` runs canonical adapter,
database, documentation and API checks, isolated omission/wrong-value/stale-source
cases, and the native business suite with observer modules absent.

Canonical meaning and original user evidence remain in `discovery.json`,
`intent.json`, `behavior.json` and `review/`. `initial-node-app/baseline.json` is the
immutable initial coding baseline. Managed native observer files are installed or
migrated only through `bo_integrate.py`; previous receipts are retained under
`bo_stategraph/migrations/`. The pre-HTTP-repair archive, actual failure/retest
records, independent native captures and desktop-browser evidence remain in
`review/runtime/`. Automated checks and browser trials are not human usability
testing or a proof of arbitrary business semantics.
