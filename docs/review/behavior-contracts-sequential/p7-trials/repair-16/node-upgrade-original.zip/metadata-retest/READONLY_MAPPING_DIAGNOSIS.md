# Metadata repair and retained-evidence mapping diagnosis

2026-11-20T11:22:46.420509+00:00

The authorized metadata maintenance is complete. Canonical inspect passes. Full verify ran the original observations and all three configured test commands, then failed its mapping gate. The latest instruction was followed: after that failure, only read-only attribution and report/replay artifacts were produced. No implementation, expectation, original event, installed VibeLens file, recording or final acceptance was changed during attribution.

## Current result and preservation

- Provider: `C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.validation\p7-trials\interactive-capture-skills\vibelens`; coordinator-supplied maintained commit `27893a4a`.
- Candidate: `a5d2b66c5100b1d1d1042a881f30b8edd6437875385a9d8985ba6dddcbec3e38`. Build: `de14176e890b778c54bfb4734e9379310b2705d13304f49c2030a64971b42673`.
- Canonical inspect: valid, no structural/review errors. Scan: no unregistered source or implementation gap; semantic names current; database valid. Its `needs_update` status retains the active, unaccepted initial change.
- Verification reports: concepts **passed**, state rules **passed**, business **passed**, project checks **passed**, mapping **failed**. Concept declaration agreement is separate from the failed runtime association checks.
- Original tests ran unchanged: native business suite **13/13**, HTTP boundary driver **8 cases**, project checks **8/8** including standalone execution without observer and deliberate wrong-value/missing-witness sensitivity checks.
- Native observation runs: workflow, state_lifecycles and storage_failure, each on/off/fault. Enabled runs contain 634/247/54 events and 18/20/3 snapshots; errors/drops zero. Fault runs retain their deliberate actual observer failures.
- All 19 application/test source files and eight business/model/baseline contract files remain byte-identical to the pre-upgrade seal. All 570 existing capture contracts remain unchanged.
- Preserve admission-time authorization: revoke blocks new requests; already admitted preparation and repeated collection keep their original authorization. All protective assertions and original test commands remain unchanged.

## Metadata corrections already made

`sync.json` retains roots `.` and `tests/native_reader.mjs`, all selected application files, all watched files, all test commands and every strict boolean. `tests/http-boundary.mjs` is classified as the independent acceptance driver it actually is; its original `node tests/http-boundary.mjs after` execution and watched-file hashing remain. `tests/native_reader.mjs` remains mapped application-evidence source.

The 17 generated files below were content-reviewed and searched for literal references in src/public/integrations/tests/tooling. No references were found. None was selected executable source or previously in watch_files. Each has an exact `source_scope.prune` declaration with category `artifact` and its own reason. All files and their archive hashes remain intact. Their file nodes are absent from the engineering graph; no application/model node was removed. The existing bilingual overlay was restored through canonical names apply/check after removing those file nodes. No fabricated business labels are needed for these products.

| Retained artifact | Actual responsibility |
| --- | --- |
| `review/technical-review-20261120.json` | Technical review evidence index |
| `review/TIMING_DIAGNOSTIC_PREPARATION.md` | Timing diagnostic preparation |
| `review/TECHNICAL_REVIEW_20261120.md` | Technical review report |
| `review/repair09-plan.json` | Repair 09 integration update plan |
| `review/timing-preparation-api-check.json` | Pre-diagnostic API registration check |
| `review/repair09-recall.json` | Repair 09 restored project obligations |
| `review/repair09-provider-javascript-comparison.json` | Repair 09 JavaScript adapter comparison |
| `review/timing-diagnostic-preparation.json` | Timing diagnostic plan and invariants |
| `review/timing-diagnostic-preparation-seal.json` | Timing diagnostic evidence seal |
| `review/repair09-api-check.json` | Repair 09 API registration check |
| `review/repair09-check.json` | Repair 09 dependency integrity result |
| `review/first-recording-scope-validation.json` | First recording scope check |
| `review/reader-provider-fix.json` | Native reader provider verification |
| `review/timing-preparation-validation.json` | Timing wrapper validation result |
| `review/repair09-database-check.json` | Repair 09 database mapping check |
| `review/repair09-apply.json` | Repair 09 integration update receipt |
| `review/timing-native-runtime-evidence.json` | Native timing hook source evidence |

Current review is bound to the actual candidate. Prior failed inspect/verify and the intermediate maintenance outputs remain sealed, not overwritten.

## Exact failure partition

The canonical receipt contains **353 mapping diagnostics**: 233 policy call-identity errors, 88 policy dependency errors, 10 consequent policy-case coverage errors, three concept association errors, and 19 missing current-build browser-evidence errors. These are not 353 distinct business failures.

### Policy witness identity and dependency

Actual canonical messages:

- `policy graph values differ: credentials_valid` and corresponding messages for the visited policy nodes (233).
- `policy graph dependencies differ: is_owner` and corresponding dependent nodes (88).
- `missing policy case: <operation>/workflow` (10, downstream of rejected witnesses).

All **48 original policy evaluation traces** pass `evaluation_errors` with the frozen original manifest. Across all **233 steps**, inputs and outputs have **zero mismatches** against their matching original graph events. The failing comparison bundles call identity into its values message.

One exact original example:

- Node `policy:credentials_valid`, check `58c47c89-54ff-4923-a866-d730f1dbf30f`.
- Trace and graph both report `value=false`, `status=completed`, with matching `bo_check` and `bo_basis`.
- Actual call_id `b4b59c2b-62fd-474a-a1e7-3cc6f3e974b5`.
- Canonical expected call_id `58c47c89-54ff-4923-a866-d730f1dbf30f:credentials_valid`.

For `policy:is_owner`, actual arguments are `left=alice`, `right=alice`, and trace/graph both return true. The two actual actor/owner event references exist, but are tagged `control`; the canonical policy gate collects `data` references.

**Attribution:** confirmed project observer-wiring contract mismatch. `integrations/bo_observe.mjs:87-89` explicitly generates a random policy call ID and control dependencies. Config/declarations: `bo_stategraph/project.json#/model/policy`, `discovery.json#/policy`, and the policy-node capture definitions in project.json. Canonical comparisons are in the selected installation's `scripts/bo_observer/policy/evidence.py:249` and `:255`. Those validator bytes are identical to repair09 (SHA-256 `2b6fb20c81fa49f070f0d9b2fbb859727d8dc7e95427e9d9d4bd27ddbcce7f70`). No wiring, event ID or dependency was edited.

### Rule invocation target

Actual message:

`concept rule invocation target differs: d3b4d585-3e13-441d-aeff-27c94ca5037b`

The original check is operation `view_file`, root `may_access`, with inputs `member=true, actor=editor, owner=alice, recipient=editor, active=false`. The native trace and graph root both deny access (`false`). The witnessed owning invocation is **list_files**, while `business_nodes` declares only **view_file**.

**Attribution:** project rule-usage mapping is incomplete. `src/service.mjs:143-149` really calls `decide('view_file', facts)` while listing files. The declared membership is in both `discovery.json#/policy/operations[id=view_file]/business_nodes` and `bo_stategraph/project.json#/model/policy/operations[id=view_file]/business_nodes`. No permission truth or native flow was changed.

### Transaction completion identity and scope

Actual messages:

- `concept completion identity differs: transition:download_task:enqueue/effect:download_task:persist_authorized_task/workflow`
- `concept effect completion missing: transition:download_task:enqueue/effect:download_task:persist_authorized_task/workflow`

The successful original pair is task `4432c037-d3d2-4218-9838-f63653b26196`, transaction `fd07757f-5d98-4c72-aa2b-81896a7573a7`. Entry `inputs.transaction_id`, entry call_id, return call_id and return `outputs.transaction_id` are identical. The actual return contains `committed=true` and `authorized_at_submission=true`. Entry outputs are empty. The independent native reader records exactly one enqueue completion with `value=queued` for this task.

The gate at `scripts/bo_observer/concepts/runtime.py:169-175` requires the **entry output** transaction_id. The declaration specifies the output field for completion, while the adapter observes start identity in the entry **input** and call_id. This is a confirmed boundary/field-placement mismatch; the appropriate adapter or framework contract repair remains for maintenance review.

An additional source-backed concern is retained without changing any data: `_effect_errors` builds its required completion set from all four related effect entries. Three actually terminate with rollback/error and `committed=false`; only one commits and produces a native enqueue transition. All four original transaction identities match at start/end. The current required set includes the rollback attempts. This scoping behavior needs a framework decision; it is not justification to change rollback expectations or fabricate successful completions.

Config and source paths:

- `bo_stategraph/project.json#/model/nodes[id=task_commit]/capture`: identity is declared in input and output capture.
- `bo_stategraph/project.json#/model/concepts/transition_effects/transition:download_task:enqueue`: completion identity_field `transaction_id`, field `committed`, equals true.
- `tooling/bind_concepts.py:81-89`: declaration generator.
- `integrations/bo_observe.mjs:93-106`: actual transaction entry/completion collection.
- `src/service.mjs:209-225`: real transaction start, authorization, rollback and committed enqueue.
- `acceptance.json`, `behavior.json`: unchanged independent outcomes.

The concept checker is byte-identical to repair09, SHA-256 `f1000aab41a3fc1ef5ee9112fb1aba5c8ef3f2438026211d1f8d1ea5f6681545`. This run does not establish a newly introduced framework regression.

### Required browser evidence remains unrun

Actual messages are `invalid or incomplete implementation mapping: mapping scenario coverage differs from protected plan`, six `feature_event_missing` and twelve `feature_field_not_observed` diagnostics for `ui_row_action`, `ui_callback` and `ui_navigation`. Config: `mapping.json`, `implementation.json`, `acceptance.json` and `sync.json`. The protected plan retains all 12 case/mode entries. Nine native entries ran; browser on/off/fault entries were not recorded. Old browser evidence is explicitly `stale_build` and was not relabeled. This remains the separately authorized future recording step.

## Reproduce without running the app

`repro_readonly.py` reads the immutable evidence ZIPs and invokes the installed canonical policy/concept validators without replacements. It replays the full retained input so no configured case is removed to simplify a pass. It does not execute Node, open a server/browser, create a recording or edit any input.

```powershell
$env:PYTHONDONTWRITEBYTECODE = '1'
$env:PYTHONIOENCODING = 'utf-8'
& 'C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.venv\Scripts\python.exe' -B 'C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.validation\p7-trials\node-retest-app\review\runtime\interactive-upgrade-20261120T105144Z\metadata-retest\repro_readonly.py' --skill 'C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.validation\p7-trials\interactive-capture-skills\vibelens'
```

Observed replay: exit 0, all **331 policy** and **three concept** diagnostics exactly match the original canonical receipt; input/output mismatches zero; 233 call-ID mismatches and 88 dependency-type mismatches. Exit 0 means the diagnostic script completed, not that verification passed. See `readonly-repro.json` and `minimal-records.json` for the unchanged original values/events.

Native failure archive SHA-256: `bc913a2677fd7db9be97b60bcb805dd25e86a266c12910e3d958109b701ac789`. Its seal lists every file hash. Initial metadata failure archive SHA-256: `a03e72142921294f541a5b7ee58d9578ce4ca0648f4b91cc2b1ff77e05d66ee6`.

## Handoff boundary

Keep the real strict failure and all assertions. No implementation, expectation, raw ID, installed validator or recording has been altered after the read-only instruction. No final accept ran. Await the next independently installed provider and the coordinating maintenance instruction.
