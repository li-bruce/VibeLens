"""Replay unchanged sealed observations through the installed canonical gates.

No application execution, network, recording, source edits or validator replacement.
Output goes to stdout; the caller can retain it as a diagnostic report.
"""
import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import sys
import zipfile


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--skill", type=Path, default=Path(os.environ.get(
    "VIBELENS_SKILL", ROOT.parent / "interactive-capture-skills/vibelens")))
args = parser.parse_args()
sys.path.insert(0, str(args.skill / "scripts"))
from bo_observer.policy.evidence import evaluation_errors, runtime_errors as policy_errors
from bo_observer.concepts.runtime import InvocationEvidence, runtime_errors as concept_errors


def sha(data):
    return hashlib.sha256(data).hexdigest()


archive = HERE / "verify-failure-native-evidence.zip"
assert sha(archive.read_bytes()) == "bc913a2677fd7db9be97b60bcb805dd25e86a266c12910e3d958109b701ac789"
before = HERE.parent / "pre-upgrade.zip"
assert sha(before.read_bytes()) == "4993437875806ab06b98a4a98377b907ccd85db68604210117a5c05afb34bc24"
with zipfile.ZipFile(archive) as frozen:
    read = lambda name: json.loads(frozen.read(name))
    payload = read("review/runtime/observations.json")
    model = read("bo_stategraph/project.json")["model"]
    manifest = read("manifest.json")
    receipt = read("initial-node-app/verification.json")
with zipfile.ZipFile(before) as original:
    discovery = json.loads(original.read("discovery.json"))

original_policy = receipt["reports"]["mapping"]["policy"]["errors"]
original_concepts = receipt["reports"]["mapping"]["concept_associations"]["errors"]
actual_policy = policy_errors(model["policy"], payload, manifest=manifest)
actual_concepts = concept_errors(discovery, model, payload)

counts = Counter()
examples = {}
trace_errors = []
for run in payload["runs"]:
    if run["mode"] != "on":
        continue
    for evaluation in run["policy_evaluations"]:
        trace_errors.extend(evaluation_errors(model["policy"], evaluation, manifest=manifest))
        ids = {}
        for step in evaluation["trace"]:
            matches = [event for event in run["events"]
                       if event["node"] == "policy:" + step["node"]
                       and event["phase"] == "decision"
                       and event["inputs"].get("bo_check") == evaluation["check_id"]]
            assert len(matches) == 1
            event = matches[0]
            expected_inputs = {"bo_check": evaluation["check_id"],
                               "bo_basis": evaluation["fact_revision"], **step["arguments"]}
            expected_outputs = {"value": step["value"], "status": step["status"]}
            expected_call = evaluation["check_id"] + ":" + step["node"]
            wanted = {ids[key] for key in step["used"] if key in ids}
            actual = {item["event"] for item in event["depends"] if item["type"] == "data"}
            counts["steps"] += 1
            counts["inputs_mismatched"] += event["inputs"] != expected_inputs
            counts["outputs_mismatched"] += event["outputs"] != expected_outputs
            counts["call_id_mismatched"] += event["call_id"] != expected_call
            counts["data_dependencies_mismatched"] += wanted != actual
            example = {"case": run["case"], "check_id": evaluation["check_id"],
                       "step": step, "event": event, "expected_call_id": expected_call,
                       "expected_data_dependency_event_ids": sorted(wanted)}
            examples.setdefault("call_id", example)
            if wanted != actual:
                examples.setdefault("dependencies", example)
            ids[step["node"]] = event["id"]

workflow = next(run for run in payload["runs"] if run["case"] == "workflow" and run["mode"] == "on")
index = InvocationEvidence(workflow["events"])
bad_check = next(error.split(": ", 1)[1] for error in actual_concepts
                 if error.startswith("concept rule invocation target differs: "))
evaluation = next(item for item in workflow["policy_evaluations"] if item["check_id"] == bad_check)
operation = next(item for item in model["policy"]["operations"] if item["id"] == evaluation["operation"])
root_event = next(event for event in workflow["events"]
                  if event["node"] == "policy:" + operation["root"]
                  and event["inputs"].get("bo_check") == bad_check)
ancestors = [index.by_id[key] for key in index.upstream(root_event)
             if index.by_id[key]["phase"] == "enter"]
transactions = []
for entry in workflow["events"]:
    if entry["node"] != "task_commit" or entry["phase"] != "enter":
        continue
    terminals = [event for event in workflow["events"]
                 if event["node"] == "task_commit" and event["phase"] in {"return", "error"}
                 and index.entry(event) is entry]
    assert len(terminals) == 1
    terminal = terminals[0]
    transactions.append({"entry": entry, "terminal": terminal,
                         "actual_identity_matches": entry["inputs"]["transaction_id"]
                         == entry["call_id"] == terminal["call_id"]
                         == terminal["outputs"]["transaction_id"],
                         "entry_output_identity": entry["outputs"].get("transaction_id")})

result = {
    "diagnostic_only": True,
    "new_runtime_or_recording_started": False,
    "implementation_or_expectations_changed": False,
    "accept_performed": False,
    "provider": str(args.skill),
    "candidate_id": receipt["candidate_id"],
    "build_id": payload["build_id"],
    "original_error_count": len(receipt["errors"]),
    "canonical_replay": {
        "policy_error_count": len(actual_policy),
        "concept_error_count": len(actual_concepts),
        "policy_matches_original_receipt": actual_policy == original_policy,
        "concepts_match_original_receipt": actual_concepts == original_concepts,
        "policy_error_counts": dict(Counter(actual_policy)),
        "concept_errors": actual_concepts,
        "trace_validation_errors": trace_errors,
    },
    "policy_comparison": dict(counts),
    "original_policy_examples": examples,
    "rule_invocation": {"evaluation": evaluation, "operation": operation,
                        "root_event": root_event, "entered_ancestors": ancestors},
    "transaction_completion": {
        "binding": model["concepts"]["transition_effects"]["transition:download_task:enqueue"],
        "capture": next(node for node in model["nodes"] if node["id"] == "task_commit")["capture"],
        "pairs": transactions,
        "native_enqueue_completions": workflow["native_completions"]["download_task:enqueue"],
        "note": "The gate reads entry.outputs.transaction_id; the recorded begin identity is in inputs and call_id. It also requires completion of all four related effect entries, including three observed rollbacks. No data is changed to isolate either condition.",
    },
    "retained_report_statuses": {key: value["status"] for key, value in receipt["reports"].items()},
    "browser_evidence": payload.get("browser_evidence"),
    "config_paths": {
        "policy": "bo_stategraph/project.json#/model/policy; discovery.json#/policy",
        "emitter": "integrations/bo_observe.mjs:87-89",
        "native_listing": "src/service.mjs:143-149",
        "effect_capture": "bo_stategraph/project.json#/model/nodes[id=task_commit]/capture",
        "completion": "bo_stategraph/project.json#/model/concepts/transition_effects/transition:download_task:enqueue",
        "generator": "tooling/bind_concepts.py:81-89",
        "coverage": "mapping.json; implementation.json; sync.json",
    },
}
print(json.dumps(result, ensure_ascii=False, indent=2))
