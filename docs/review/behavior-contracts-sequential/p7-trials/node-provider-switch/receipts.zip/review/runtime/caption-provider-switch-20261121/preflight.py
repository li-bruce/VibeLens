"""Verify the managed installation and preserve all current application evidence."""
from datetime import datetime, timezone
from switch_tools import APP, RUN, PACK, OLD_PACK, REPOSITORY, PREVIOUS_RUN, CHANGE, load, save, sha

manifest_path = REPOSITORY / "docs/review/behavior-contracts-sequential/p7-trials/repair-24/installation-final.json"
proof_path = REPOSITORY / ".validation/p7-trials/caption-provider-commit.json"
manifest, proof = load(manifest_path), load(proof_path)
assert proof["commit"] == "24af640d7929229848616a83940ab9eb923e93d8"
assert proof["manifest_sha256"] == sha(manifest_path)
assert manifest["owned_files"] == 464 and manifest["all_equal"] is True and proof["valid"] is True
rows = []
differences = []
for record in manifest["files"]:
    name = record["path"]
    path = PACK / name
    assert path.resolve().is_relative_to(PACK.resolve())
    actual = sha(path)
    assert actual == record["sha256"], name
    old = sha(OLD_PACK / name)
    rows.append({"path": name, "expected": record["sha256"], "actual": actual})
    if old != actual:
        differences.append({"path": name, "old_sha256": old, "new_sha256": actual})
assert len(rows) == 464 and len(differences) == 3
assert not any(row["path"].startswith("scripts/") for row in differences)
assert sum(row["path"].startswith("assets/") for row in differences) == 1
assert sum(row["path"].startswith("references/") for row in differences) == 2
provider_hashes = {p.relative_to(PACK).as_posix(): sha(p) for p in PACK.rglob("*")
                   if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc"}
save(RUN / "provider-files-before.json", provider_hashes)
save(RUN / "owned-verification.json", {"valid": True, "commit": proof["commit"],
     "manifest_path": str(manifest_path), "manifest_sha256": sha(manifest_path),
     "proof_path": str(proof_path), "proof_sha256": sha(proof_path), "owned_files": rows,
     "differences_from_ordered": differences, "scripts_identical": True})
save(RUN / "installation.json", manifest)
save(RUN / "commit-proof.json", proof)
paths = {}
excluded = {"node_modules", ".tool-cache", "__pycache__", ".git"}
for path in APP.rglob("*"):
    if not path.is_file() or path.is_relative_to(RUN) or excluded.intersection(path.relative_to(APP).parts):
        continue
    paths[path.relative_to(APP).as_posix()] = sha(path)
save(RUN / "app-files-before.json", paths)
save(RUN / "prior-current-identities.json", {"prior_candidate": load(PREVIOUS_RUN / "static-handoff.json")["candidate_id"],
     "prior_handoff_sha256": sha(PREVIOUS_RUN / "HANDOFF.md"),
     "prior_bundle_sha256": sha(PREVIOUS_RUN / "static-handoff-evidence.zip"),
     "active": load(APP / ".stategraph/active.json"), "new_change_baseline_sha256": sha(APP / CHANGE / "baseline.json"),
     "database_sha256": sha(APP / "var/db/application.sqlite"),
     "personal_revision": load(APP / "bo_stategraph/config/views/local.json")["revision"],
     "personal_sha256": sha(APP / "bo_stategraph/config/views/local.json"),
     "manifest_sha256": sha(APP / "manifest.json"), "created_at_utc": datetime.now(timezone.utc).isoformat()})
print({"owned_files_verified": len(rows), "provider_files_sealed": len(provider_hashes),
       "application_files_sealed": len(paths), "differences": [row["path"] for row in differences], "application_executed": False})
