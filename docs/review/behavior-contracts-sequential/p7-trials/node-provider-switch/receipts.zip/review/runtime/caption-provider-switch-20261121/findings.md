# Managed provider findings

- Independently matched all464 owned file hashes and the supplied commit-proof manifest hash. The full installed package noncache hash inventory contains2779 files.
- Exact owned delta: assets/stategraph-viewer/spatial-renderer.js, references/concept-models.md and references/continuous-development.md. Every scripts byte is identical to ordered provider.
- The renderer now routes both left-label drag and right-label menu through labelTarget; a glyph under the label has priority. Right click suppresses the planar fallback before opening the resolved target menu. This is source review, not local UI runtime validation.
- The fact-timing reference documents the already implemented qualified preparation facts and preserves unchanged consumers. The toolchain reference documents strict accepted-provider begin recovery. The current active change already has its immutable accepted-state baseline, so no begin/reset or business re-confirmation is needed.
- Canonical JavaScript managed plan/apply/check passed with changes=[]; the adapters are byte-identical. The provider choice remains process-local and is retained in switch_tools.py and command receipts.
