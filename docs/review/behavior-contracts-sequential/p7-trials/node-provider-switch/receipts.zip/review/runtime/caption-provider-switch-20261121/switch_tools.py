"""Use the immutable caption-repair provider for static-only managed integration."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

RUN = Path(__file__).resolve().parent
APP = RUN.parents[2]
REPOSITORY = APP.parents[2]
PACK = APP.parent / "caption-repair-skills/vibelens"
OLD_PACK = APP.parent / "ordered-evidence-skills/vibelens"
PREVIOUS_RUN = APP / "review/runtime/queue-start-permission-20261121"
PY = REPOSITORY / ".venv/Scripts/python.exe"
CHANGE = "download-start-permission-20261121"
ENV = dict(os.environ, VIBELENS_SKILL=str(PACK), BO_DIAGNOSTIC_SKILL=str(PACK),
           VIBELENS_PYTHON=str(PY), PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1",
           PYTHONIOENCODING="utf-8", TEAM_FILES_SQLITE_URL="sqlite:///var/db/application.sqlite",
           APP_DATA_ROOT=str(APP / "var"),
           BO_LOAD_CONTEXT="Static-only managed provider upgrade. Python owns heavy testing. Do not run native verify, migrate SQL, start services/browsers or accept. Preserve source, declarations, all raw records and personal settings.")
ENV.pop("VIBELENS_ENDPOINT", None)


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def cli(label, script, *args, allow_failure=False):
    """Preserve each exact canonical invocation without overwriting prior receipts."""
    target = RUN / (label + ".json")
    assert not target.exists(), str(target)
    command = [str(PY), "-B", "-X", "utf8", str(PACK / "scripts" / script), *map(str, args), "--root", str(APP)]
    started = datetime.now(timezone.utc).isoformat()
    with target.open("wb") as stdout, (RUN / (label + ".stderr.log")).open("wb") as stderr:
        result = subprocess.run(command, cwd=APP, env=ENV, stdout=stdout, stderr=stderr, check=False, timeout=300)
    save(RUN / (label + "-command.json"), {"command": command, "exit_code": result.returncode,
         "started_at": started, "finished_at": datetime.now(timezone.utc).isoformat(), "provider": str(PACK), "static_only": True})
    try:
        value = load(target)
    except (json.JSONDecodeError, UnicodeDecodeError) as error:
        raise RuntimeError(f"Preserved non-JSON canonical output: {label}, exit {result.returncode}") from error
    print(json.dumps({"label": label, "exit_code": result.returncode, "valid": value.get("valid"),
          "status": value.get("status"), "candidate_id": value.get("candidate_id"),
          "errors": value.get("errors"), "review_errors": value.get("review_errors"),
          "changes": value.get("changes") if script == "bo_integrate.py" else None}, ensure_ascii=False), flush=True)
    if result.returncode and not allow_failure:
        raise RuntimeError(f"Canonical static failure retained: {label}")
    return value
