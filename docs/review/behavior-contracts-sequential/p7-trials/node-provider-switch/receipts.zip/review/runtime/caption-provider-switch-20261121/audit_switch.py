"""Check the managed upgrade's exact impact without running application code."""
from switch_tools import APP, RUN, PACK, PREVIOUS_RUN, load, save, sha

before = load(RUN / "app-files-before.json")
changed = []
for name, expected in before.items():
    path = APP / name
    actual = sha(path) if path.is_file() else None
    if actual != expected:
        changed.append({"path": name, "before_sha256": expected, "after_sha256": actual})
derived_allowed = {".stategraph/maintenance.json", ".stategraph/iteration-recall.json",
                   ".stategraph/code-graph.json",
                   "download-start-permission-20261121/impact.json",
                   "download-start-permission-20261121/structure.json",
                   "download-start-permission-20261121/behavior-impact.json"}
unexpected = [row for row in changed if row["path"] not in derived_allowed]
provider_before = load(RUN / "provider-files-before.json")
provider_changed = [{"path": name, "before_sha256": expected,
                     "after_sha256": sha(PACK / name) if (PACK / name).is_file() else None}
                    for name, expected in provider_before.items()
                    if not (PACK / name).is_file() or sha(PACK / name) != expected]
provider_after = {path.relative_to(PACK).as_posix() for path in PACK.rglob("*")
                  if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc"}
added_provider = sorted(provider_after - provider_before.keys())
prior = load(RUN / "prior-current-identities.json")
source_cache = load(RUN / "source-cache-change-classification.json")
assert source_cache["equal"] is True
assert source_cache["before_cache_sha256"] == before[".stategraph/code-graph.json"]
result = {"valid": not unexpected and not provider_changed and not added_provider,
          "application_files_checked": len(before), "changed_application_files": changed,
          "unexpected_changes": unexpected, "provider_files_checked": len(provider_before),
          "canonical_source_cache_refresh": source_cache,
          "provider_changes": provider_changed, "provider_added_files": added_provider,
          "prior_handoff_unchanged": sha(PREVIOUS_RUN / "HANDOFF.md") == prior["prior_handoff_sha256"],
          "prior_bundle_unchanged": sha(PREVIOUS_RUN / "static-handoff-evidence.zip") == prior["prior_bundle_sha256"],
          "actual_database_unchanged": sha(APP / "var/db/application.sqlite") == prior["database_sha256"],
          "personal_settings_unchanged": sha(APP / "bo_stategraph/config/views/local.json") == prior["personal_sha256"],
          "personal_revision": load(APP / "bo_stategraph/config/views/local.json")["revision"],
          "runtime_manifest_unchanged": sha(APP / "manifest.json") == prior["manifest_sha256"],
          "new_files_outside_run": sorted(path.relative_to(APP).as_posix() for path in APP.rglob("*")
              if path.is_file() and not path.is_relative_to(RUN)
              and not {"node_modules", ".tool-cache", "__pycache__", ".git"}.intersection(path.relative_to(APP).parts)
              and path.relative_to(APP).as_posix() not in before),
          "full_native_tests_run": False, "actual_migration_run": False,
          "services_or_browser_started": False, "accepted": False}
result["valid"] = result["valid"] and not result["new_files_outside_run"] and all(result[key] for key in
    ("prior_handoff_unchanged", "prior_bundle_unchanged", "actual_database_unchanged", "personal_settings_unchanged", "runtime_manifest_unchanged"))
save(RUN / "preservation-audit.json", result)
print({key: value for key, value in result.items() if key not in {"provider_changes"}})
raise SystemExit(0 if result["valid"] else 1)
