# Caption provider managed switch

Authorized scope: coordination-only provider upgrade to commit24af640d7929229848616a83940ab9eb923e93d8. No new simulated product requirement, business/source/declaration change, legacy scaffold generation, native verify, database migration, service/browser start, recording or accept. Python retains the full runtime slot. Preserve the previous HANDOFF and all source/config/SQL/records/personal settings.

1. Independently verify the464 owned files, commit proof and exact old/new delta; seal current application and prior handoff. complete
2. Read affected references and perform the new provider's canonical plan/apply/check. complete; changes=[]
3. Run only affected static inspection/integration/presentation checks; derive current candidate/build without writing a runtime manifest. complete
4. Check protected bytes and leave a separate static HANDOFF with exact results and pending runtime work. complete

Existing active change and its immutable accepted-state baseline remain authoritative. Do not begin/reset a change, edit installed files or restore old settings. Use process-local provider variables in switch_tools.py; no persistent global environment changes.
