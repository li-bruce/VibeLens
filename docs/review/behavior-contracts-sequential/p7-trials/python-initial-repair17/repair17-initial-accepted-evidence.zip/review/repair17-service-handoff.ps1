$ErrorActionPreference='Stop'
$taskRoot='C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.validation\p7-trials\python-retest-app'
$taskLaunch=Get-Content -Raw -LiteralPath (Join-Path $taskRoot 'review/repair17-live-processes.json') | ConvertFrom-Json
$taskMarker=Get-Content -Raw -LiteralPath (Join-Path $taskRoot 'review/repair17-recording-attempt.json') | ConvertFrom-Json
$taskReport=Get-Content -Raw -LiteralPath (Join-Path $taskMarker.output 'report.json') | ConvertFrom-Json
$taskListeners=@(Get-NetTCPConnection -LocalPort 8875,8876 -State Listen | Select-Object LocalAddress,LocalPort,OwningProcess)
$taskProcesses=@(Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('python.exe','node.exe') -and $_.CommandLine -like ('*'+$taskRoot+'*') } | Select-Object ProcessId,ParentProcessId,Name,CommandLine)
$taskAppPid=($taskListeners | Where-Object LocalPort -eq 8875).OwningProcess
$taskViewerPid=($taskListeners | Where-Object LocalPort -eq 8876).OwningProcess
if ($taskProcesses.Count -ne 4) { throw 'Unexpected project helper remains; retain actual ownership before handoff.' }
if (($taskProcesses | Where-Object ProcessId -eq $taskAppPid).ParentProcessId -ne $taskLaunch.app_pid) { throw 'App process ancestry differs.' }
if (($taskProcesses | Where-Object ProcessId -eq $taskViewerPid).ParentProcessId -ne $taskLaunch.viewer_pid) { throw 'Viewer process ancestry differs.' }
foreach ($taskProcess in $taskProcesses) { if (-not $taskProcess.CommandLine.Contains($taskRoot)) { throw 'Process ownership differs.' } }
if (@(Get-NetTCPConnection -LocalPort 8877 -State Listen -ErrorAction SilentlyContinue).Count) { throw 'An unexpected diagnostic listener exists.' }
$taskNative=Invoke-WebRequest -Uri 'http://127.0.0.1:8875/health' -TimeoutSec 20
$taskGraph=Invoke-WebRequest -Uri 'http://127.0.0.1:8876/graph' -TimeoutSec 20
$taskObserver=Invoke-RestMethod -Uri 'http://127.0.0.1:8876/api/bo/health' -TimeoutSec 20
$taskRecordings=Invoke-RestMethod -Uri 'http://127.0.0.1:8876/api/recordings' -TimeoutSec 20
$taskPreferences=Invoke-WebRequest -Uri 'http://127.0.0.1:8876/api/preferences' -TimeoutSec 20
$taskCollector=Get-Content -Raw -LiteralPath (Join-Path $taskRoot '.stategraph/collector.json') | ConvertFrom-Json
$taskNativeBody=$taskNative.Content | ConvertFrom-Json
if (-not $taskNativeBody.worker -or $taskObserver.build_id -ne $taskMarker.build_id) { throw 'Actual worker/build readiness differs.' }
if ($taskCollector.endpoint -ne 'http://127.0.0.1:8876' -or $taskCollector.build_id -ne $taskMarker.build_id) { throw 'Normal startup did not refresh the collector address/build.' }
if (-not $taskReport.browser_close_completed -or $taskRecordings.active) { throw 'A browser or recording is still active.' }
$taskReceipt=[ordered]@{checked_utc=(Get-Date).ToUniversalTime().ToString('o');status='running_for_coordinating_independent_web_review';app_url='http://127.0.0.1:8875';graph_url='http://127.0.0.1:8876/graph';app_listener_pid=$taskAppPid;viewer_listener_pid=$taskViewerPid;app_launcher_pid=$taskLaunch.app_pid;viewer_launcher_pid=$taskLaunch.viewer_pid;listeners=$taskListeners;processes=$taskProcesses;app_http_status=[int]$taskNative.StatusCode;graph_http_status=[int]$taskGraph.StatusCode;native_health=$taskNativeBody;observer_health=$taskObserver;recording_list=$taskRecordings;preferences_http_status=[int]$taskPreferences.StatusCode;collector=[ordered]@{endpoint=$taskCollector.endpoint;build_id=$taskCollector.build_id;refreshed_by='normal bo.py serve startup';diagnostic_8877_listening=$false};browser_closed=$taskReport.browser_close_completed;new_recording_rounds=1;final_accept='not_run'}
$taskReceipt | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath (Join-Path $taskRoot 'review/repair17-service-handoff.json') -Encoding utf8
[ordered]@{app_url=$taskReceipt.app_url;app_pid=$taskAppPid;app_parent=$taskLaunch.app_pid;graph_url=$taskReceipt.graph_url;graph_pid=$taskViewerPid;graph_parent=$taskLaunch.viewer_pid;worker=$taskNativeBody.worker;build_id=$taskObserver.build_id;collector_endpoint=$taskCollector.endpoint;browser_closed=$taskReport.browser_close_completed} | ConvertTo-Json -Depth 4
