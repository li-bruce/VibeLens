"""One real ordinary-entry recording with independent native SQL and actual HTTP outcomes."""
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, re, sqlite3, sys, urllib.request, zipfile
from urllib.parse import urlsplit
from playwright.sync_api import sync_playwright, expect

ROOT=Path(__file__).resolve().parents[1]
STAMP=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S')
OUT=ROOT/'review/browser'/('repair17-recording-'+STAMP)
OUT.mkdir(parents=True)
APP='http://127.0.0.1:8875'
VIEW='http://127.0.0.1:8876'
OPENER=urllib.request.build_opener(urllib.request.ProxyHandler({}))

def get(path):
    with OPENER.open(VIEW+path,timeout=20) as response:return json.load(response)

def save(name,value):
    (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def native():
    with closing(sqlite3.connect('file:'+(ROOT/'var/team.sqlite3').as_posix()+'?mode=ro',uri=True)) as connection:
        connection.row_factory=sqlite3.Row
        connection.execute('BEGIN')
        return {table:[dict(row) for row in connection.execute('SELECT * FROM '+table+' ORDER BY rowid')] for table in ('files','grants','download_jobs','announcements','transition_journal')}

def fingerprint(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def check(name,passed,details=None):
    report['checks'].append({'name':name,'passed':bool(passed),'details':details})
    print(json.dumps({'check':name,'passed':bool(passed)},ensure_ascii=False),flush=True)

def safe_body(value):
    return re.sub(r'(name="csrf"\s+value=")[^"]*',r'\1[REDACTED]',value)[:8000]

report={'started_at':datetime.now(timezone.utc).isoformat(),'status':'running','checks':[],'static_resource_failures':[],'page_errors':[],'viewer_http_errors':[],'native_http':[],'provider':json.loads((ROOT/'tooling/vibelens.json').read_text(encoding='utf-8')),'launch_environment':'host, normal run.py and installed bo.py serve','method_timing_wrappers':False,'scope':'One real recording. Real queue/revoke/automatic rejection, new attempt/automatic ZIP, independent announcement lifecycle, every native state event/frame and original strict snapshot admission. No layer/Timeline acceptance loop.','final_accept':'not_run'}
record_id=None
stopped=False
viewer=None
browser=None
collector=json.loads((ROOT/'.stategraph/collector.json').read_text(encoding='utf-8'))
assert collector['endpoint']==VIEW
assert collector['build_id']==json.loads((ROOT/'manifest.json').read_text(encoding='utf-8'))['build_id']
save('collector-before-recording.json',{'endpoint':collector['endpoint'],'build_id':collector['build_id'],'refreshed_by':'normal installed bo.py serve startup','diagnostic_8877_used':False})
initial=get('/api/view')
assert initial['binding_status']['status']=='current'
assert initial['health'].get('producer',{}).get('producers')==1
assert get('/api/recordings').get('active') is None
report['build_id']=initial['manifest']['build_id']
save('observer-before.json',initial)
before=native()
save('native-before.json',before)
sequence=max((row['sequence'] for row in before['transition_journal']),default=0)
strict=json.loads((ROOT/'review/repair17-upgrade/verify.json').read_text(encoding='utf-8'))
assert strict['valid']
assert strict['candidate_id']==json.loads((ROOT/'review/repair17-upgrade/inspect.json').read_text(encoding='utf-8'))['candidate_id']
assert report['build_id']==json.loads((ROOT/'manifest.json').read_text(encoding='utf-8'))['build_id']
report['candidate_id']=strict['candidate_id']
report['strict_snapshot_admission']={key:value for key,value in strict['reports']['mapping']['snapshot_admission'].items() if key!='checks'}
save('strict-snapshot-admission.json',strict['reports']['mapping']['snapshot_admission'])
attempt=ROOT/'review/repair17-recording-attempt.json'
assert not attempt.exists(), 'Only one recording attempt is authorized.'

with sync_playwright() as playwright:
    browser=playwright.chromium.launch(channel='chrome',headless=True)
    try:
        view_context=browser.new_context(viewport={'width':1600,'height':1000},locale='zh-CN')
        view_context.on('page',lambda page:page.on('pageerror',lambda error:report['page_errors'].append(str(error))))
        view_context.on('response',lambda response:report['viewer_http_errors'].append({'path':urlsplit(response.url).path,'status':response.status}) if response.status>=400 and response.url.startswith(VIEW) else None)
        viewer=view_context.new_page()
        static_network=[]
        cdp=view_context.new_cdp_session(viewer)
        cdp.send('Network.enable')
        cdp.on('Network.responseReceived',lambda message:static_network.append({key:message['response'].get(key) for key in ('url','status','protocol','connectionId','connectionReused','fromDiskCache','fromServiceWorker')}) if urlsplit(message['response']['url']).path.endswith(('.js','.css')) else None)
        view_context.on('requestfailed',lambda request:report['static_resource_failures'].append({'path':urlsplit(request.url).path,'failure':request.failure}) if urlsplit(request.url).path.endswith(('.js','.css')) else None)
        with viewer.expect_response(lambda response:response.request.method=='GET' and urlsplit(response.url).path=='/api/preferences') as preferences:
            viewer.goto(VIEW+'/graph?lang=zh-CN')
        save('preferences-browser-receipt.json',{'status':preferences.value.status,'raw_body':preferences.value.text()})
        check('real preferences response succeeds',preferences.value.status==200)
        viewer.wait_for_function("()=>{const e=document.querySelector('#analysis-view');return e&&e.options.length&&e.value!==''}")
        assert viewer.locator('#capture-mode').input_value()=='all'
        attempt.write_text(json.dumps({'started_utc':datetime.now(timezone.utc).isoformat(),'build_id':report['build_id'],'output':str(OUT)},indent=2)+'\n',encoding='utf-8')
        with viewer.expect_response(lambda response:response.request.method=='POST' and urlsplit(response.url).path=='/api/recordings/start') as start:
            viewer.locator('#record-start').click()
        report['start_response']={'status':start.value.status,'body':start.value.json()}
        assert start.value.status==200
        record_id=start.value.json()['id']
        report['recording_id']=record_id

        contexts=[browser.new_context(viewport={'width':1440,'height':960},locale='zh-CN',accept_downloads=True) for _ in range(3)]
        for context in contexts:
            context.on('response',lambda response:report['native_http'].append({'method':response.request.method,'path':urlsplit(response.url).path,'status':response.status}) if response.url.startswith(APP) else None)
        unauth=contexts[1].request.get(APP+'/',max_redirects=0)
        invalid_csrf=contexts[1].request.post(APP+'/login',form={'username':'bob','password':'incorrect'},max_redirects=0)
        check('native early authentication and CSRF returns',unauth.status==302 and invalid_csrf.status==400,{'authentication':unauth.status,'csrf':invalid_csrf.status})
        save('early-http-receipts.json',{'authentication':{'status':unauth.status,'path':'/'},'csrf':{'status':invalid_csrf.status,'path':'/login','body':safe_body(invalid_csrf.text())}})

        def login(context,actor):
            page=context.new_page()
            page.goto(APP+'/login')
            page.get_by_label('用户名',exact=True).fill(actor)
            page.get_by_label('密码',exact=True).fill('demo-'+actor+'-123')
            page.get_by_role('button',name='登录',exact=True).click()
            expect(page.get_by_role('heading',name='文件空间',exact=True)).to_be_visible()
            return page
        alice,bob,casey=[login(context,actor) for context,actor in zip(contexts,('alice','bob','casey'))]
        filename='repair17-'+STAMP+'.txt'
        payload=b'Real ordinary-entry bytes for queue revocation and a fresh admitted attempt.\n'
        upload=OUT/filename
        upload.write_bytes(payload)
        alice.locator('input[type=file]').set_input_files(str(upload))
        alice.get_by_role('button',name='上传文件',exact=True).click()
        owner=alice.locator('.file-row').filter(has=alice.get_by_role('heading',name=filename,exact=True))
        owner.get_by_label('分享 '+filename+' 给同事').select_option('bob')
        share_path=owner.locator('form.share-form').get_attribute('action')
        owner.get_by_role('button',name='分享',exact=True).click()
        bob.reload()
        recipient=bob.locator('.file-row').filter(has=bob.get_by_role('heading',name=filename,exact=True))
        expect(recipient).to_be_visible()
        denied=bob.request.post(APP+share_path,form={'csrf':bob.locator('input[name=csrf]').first.input_value(),'recipient_id':'casey'},max_redirects=0)
        report['denial_receipt']={'status':denied.status,'path':share_path,'body':safe_body(denied.text())}
        check('recipient reshare actually denied',denied.status==403)

        recipient.get_by_role('button',name='准备下载',exact=True).click()
        queued=native()
        new_jobs=[row for row in queued['download_jobs'] if row['id'] not in {old['id'] for old in before['download_jobs']}]
        assert len(new_jobs)==1
        rejected_id=new_jobs[0]['id']
        report['queued_boundary']=new_jobs[0]
        save('native-after-queue.json',queued)
        check('first attempt is genuinely queued before revocation',new_jobs[0]['state']=='queued' and not new_jobs[0]['admitted'],new_jobs[0])
        owner=alice.locator('.file-row').filter(has=alice.get_by_role('heading',name=filename,exact=True))
        owner.get_by_role('button',name='撤销与 bob 的共享',exact=True).click()
        job=bob.locator('.job-row').filter(has=bob.get_by_role('heading',name=filename,exact=True))
        expect(job.get_by_text('共享已撤销，无法准备',exact=True)).to_be_visible(timeout=20000)
        rejected=native()
        rejected_row=next(row for row in rejected['download_jobs'] if row['id']==rejected_id)
        rejected_journal=[row for row in rejected['transition_journal'] if row['model_id']=='download-job' and row['instance_id']==rejected_id]
        check('automatic worker rejects revoked queued attempt',rejected_row['state']=='rejected' and rejected_row['revision']==2 and not rejected_row['admitted'] and [row['event'] for row in rejected_journal]==['request','reject'],{'row':rejected_row,'journal':rejected_journal})
        save('native-after-rejection.json',rejected)

        owner=alice.locator('.file-row').filter(has=alice.get_by_role('heading',name=filename,exact=True))
        owner.get_by_label('分享 '+filename+' 给同事').select_option('bob')
        owner.get_by_role('button',name='分享',exact=True).click()
        bob.goto(APP+'/')
        recipient=bob.locator('.file-row').filter(has=bob.get_by_role('heading',name=filename,exact=True))
        recipient.get_by_role('button',name='准备下载',exact=True).click()
        ready=bob.locator('.job-row').filter(has=bob.get_by_role('heading',name=filename,exact=True)).filter(has=bob.get_by_role('link',name='领取结果',exact=True))
        expect(ready).to_be_visible(timeout=20000)
        for number in (1,2):
            with bob.expect_download() as download:ready.get_by_role('link',name='领取结果',exact=True).click()
            output=OUT/('actual-result-'+str(number)+'.zip')
            download.value.save_as(str(output))
            with zipfile.ZipFile(output) as archive:check('fresh admitted result bytes '+str(number),archive.read(filename)==payload)
        after_new=native()
        check('re-sharing did not revive the old request',next(row for row in after_new['download_jobs'] if row['id']==rejected_id)['state']=='rejected')

        casey.goto(APP+'/?tab=board')
        title='原生录制复测 '+STAMP
        casey.get_by_label('标题',exact=True).fill(title)
        casey.get_by_label('正文',exact=True).fill('独立公告的真实原生操作。')
        casey.get_by_role('button',name='发布公告',exact=True).click()
        notice=casey.locator('.notice').filter(has=casey.get_by_role('heading',name=title,exact=True))
        notice.get_by_role('link',name='修改',exact=True).click()
        casey.get_by_label('标题',exact=True).fill(title+' · 已修改')
        casey.get_by_role('button',name='保存修改',exact=True).click()
        casey.locator('.notice').filter(has=casey.get_by_role('heading',name=title+' · 已修改',exact=True)).get_by_role('button',name='删除',exact=True).click()
        casey.wait_for_load_state('networkidle')
        with viewer.expect_response(lambda response:response.request.method=='POST' and urlsplit(response.url).path=='/api/recordings/stop') as stop:
            viewer.locator('#record-stop').click()
        report['stop_response']={'status':stop.value.status,'body':stop.value.json()}
        stopped=True
        recording=get('/api/recordings/'+record_id)
        save('recording-original.json',recording)
        assert recording['capture']['mode']=='all' and recording['capture'].get('nodes') is None
        original_hash=fingerprint(recording)
        events=recording['events']
        frames={frame['event_id']:frame for frame in recording.get('runtime_frames',{}).get('frames',[])}
        save('runtime-frames-original.json',recording.get('runtime_frames'))
        report.update(recording_status=recording['status'],gaps=recording.get('gaps',[]),producer_settlement=recording.get('producer_settlement'),events=len(events),frames=len(frames))
        check('recording actually stopped without gaps',stop.value.status==200 and recording['status']=='stopped' and not recording.get('gaps'),report['stop_response'])
        settlement=recording.get('producer_settlement') or {}
        check('fixed producer prefix drained',settlement.get('flushed') is True and settlement.get('completed',-1)>=settlement.get('target',0),settlement)
        producer_sequences={}
        for event in events:producer_sequences.setdefault((event['run_id'],event['producer_id']),[]).append(event.get('source_seq',event['seq']))
        continuity=[{'run_id':key[0],'producer_id':key[1],'count':len(values),'first':values[0],'last':values[-1],'contiguous':values==list(range(values[0],values[-1]+1))} for key,values in producer_sequences.items()]
        save('producer-prefix-continuity.json',continuity)
        check('each recorded producer prefix is continuous',bool(continuity) and all(row['contiguous'] for row in continuity))

        final=native()
        save('native-after-operations.json',final)
        journals=[row for row in final['transition_journal'] if row['sequence']>sequence]
        matches=[]
        for row in journals:
            found=[event for event in events if event['node']=='state_commit' and all(event.get('outputs',{}).get(field)==row[field] for field in ('model_id','instance_id','event','before','after','revision','transaction_id'))]
            frame=frames.get(found[0]['id']) if len(found)==1 else None
            valid=bool(frame and frame['revision']==row['revision'] and frame['machine']['current']==row['after'] and frame['build_id']==row['build_id'] and frame['machine']['configurations'][0]['context']=={'allowed':bool(row['permission_allowed'])})
            matches.append({'journal':row,'event_id':found[0]['id'] if found else None,'matching_frame':valid})
        save('native-transition-correspondence.json',matches)
        check('every real transition in all four models has an exact frame',len(matches)==12 and all(row['matching_frame'] for row in matches) and {row['journal']['model_id'] for row in matches}=={'file','grant','download-job','announcement'},{'transitions':len(matches),'instances':sorted({(row['journal']['model_id'],row['journal']['instance_id']) for row in matches})})

        reads=[]
        for event in events:
            if event['node']!='state_before':continue
            value=event['outputs']
            prior=[row for row in final['transition_journal'] if row['model_id']==value['model_id'] and row['instance_id']==value['instance_id'] and row['revision']==event['revision']]
            expected_context={'allowed':bool(prior[-1]['permission_allowed'])} if prior else {'allowed':False}
            frame=frames.get(event['id'])
            native_state=prior[-1]['after'] if prior else {'file':'absent','grant':'inactive','download-job':'not_requested','announcement':'unpublished'}[value['model_id']]
            valid=bool(frame and frame['revision']==event['revision'] and frame['machine']['current']==native_state==value['state'] and frame['machine']['configurations'][0]['context']==expected_context and value['context_allowed']==expected_context['allowed'])
            reads.append({'event_id':event['id'],'model_id':value['model_id'],'instance_id':value['instance_id'],'revision':event['revision'],'native_state':native_state,'native_context':expected_context,'current_operation_allowed':value['allowed'],'matching_own_frame':valid,'native_journal_sequence':prior[-1]['sequence'] if prior else None})
        save('independent-read-frame-checks.json',reads)
        check('every initial and same-version read retains exact native context',len(reads)==12 and all(row['matching_own_frame'] for row in reads))
        changed=[row for row in reads if row['instance_id']==rejected_id and row['revision']==1]
        check('changed denied input does not rewrite queued context',len(changed)==1 and changed[0]['native_context']=={'allowed':True} and changed[0]['current_operation_allowed'] is False,changed)

        provider=(ROOT/report['provider']['skill_root']).resolve()
        sys.path.insert(0,str(provider/'scripts'))
        from bo_observer.workflow.observation_requirements import invocation_closure
        model=json.loads((ROOT/'bo_stategraph/project.json').read_text(encoding='utf-8'))['model']
        lifecycle=invocation_closure({'runs':[{'case':'repair17-recording','mode':'on','events':events}]},required=True,model=model)
        save('lifecycle-closure.json',lifecycle)
        check('all recorded invocation lifecycles close',lifecycle['valid'],lifecycle)
        check('real HTTP rejections retain API return events',all(any(event['node']==node and event['phase']=='return' and event.get('outputs',{}).get('status')==status for event in events) for node,status in [('api:GET:/',302),('api:POST:/login',400),('api:POST:/files/<file_id>/share',403)]))
        health=get('/api/view')['health']
        report['collector_health']=health
        report['producer_details']=health.get('producer',{}).get('producer_details',[])
        report['transport_retries']=health.get('producer',{}).get('transport_retries')
        save('producer-stop-details.json',{'recorded_final_health':recording.get('final',{}).get('health',{}).get('producer',{}),'post_stop_last_ack':health.get('producer',{}),'basis':'CaptureBridge last control acknowledgements, including stop settlement; not continuous producer samples.'})
        check('safe per-producer diagnostics and retry counts retained',len(report['producer_details'])==1 and all(isinstance(row.get('transport_retries'),int) and 'last_error' in row for row in report['producer_details']) and isinstance(report['transport_retries'],int),{'producer_details':report['producer_details'],'transport_retries':report['transport_retries']})
        report['receipt_boundary']='Ordinary unmodified SDK requires accepted=true for HTTP observations; original frames and stop ACK health are retained. Individual SDK POST response bodies are not exposed by this ordinary launch.'
        check('capture has no errors drops or frame evictions',health.get('errors',0)==0 and health.get('dropped',0)==0 and health.get('producer',{}).get('errors',0)==0 and health.get('producer',{}).get('dropped',0)==0 and health.get('runtime_frame_evictions',0)==0,health)
        readonly_before=native()
        viewer.screenshot(path=str(OUT/'stopped-recording.png'),full_page=True)
        alice.screenshot(path=str(OUT/'native-owner.png'),full_page=True)
        bob.screenshot(path=str(OUT/'native-recipient-ready-and-rejected.png'),full_page=True)
        casey.screenshot(path=str(OUT/'native-editor-after-deletion.png'),full_page=True)
        check('read-only inspection preserves native rows',readonly_before==native())
        check('original recording is not supplemented after stop',fingerprint(get('/api/recordings/'+record_id))==original_hash)
    except Exception as error:
        report.update(status='failed',error_type=type(error).__name__,error=str(error))
        if viewer:
            try:viewer.screenshot(path=str(OUT/'failure.png'),full_page=True,timeout=5000)
            except Exception:pass
    finally:
        if record_id and not stopped:
            try:
                with viewer.expect_response(lambda response:response.request.method=='POST' and urlsplit(response.url).path=='/api/recordings/stop') as cleanup:
                    viewer.locator('#record-stop').click()
                report['cleanup_stop_response']={'status':cleanup.value.status,'body':cleanup.value.json()}
                save('recording-original.json',get('/api/recordings/'+record_id))
            except Exception as error:report['cleanup_error']=str(error)
        if record_id and 'producer_details' not in report:
            try:
                diagnostic_health=get('/api/view')['health']
                report['collector_health']=diagnostic_health
                report['producer_details']=diagnostic_health.get('producer',{}).get('producer_details',[])
                report['transport_retries']=diagnostic_health.get('producer',{}).get('transport_retries')
                save('producer-details-on-failure.json',diagnostic_health.get('producer',{}))
            except Exception as diagnostic_error:
                report['producer_diagnostics_error']=type(diagnostic_error).__name__
        if report['status']=='running':report['status']='passed' if all(row['passed'] for row in report['checks']) and not report['page_errors'] and not report['viewer_http_errors'] and not report['static_resource_failures'] else 'completed_with_findings'
        report['finished_at']=datetime.now(timezone.utc).isoformat()
        browser.close()
        report['browser_close_completed']=True
        save('static-resource-network.json',static_network)
        save('report.json',report)
        print(json.dumps({'status':report['status'],'recording_id':record_id,'events':report.get('events'),'frames':report.get('frames'),'settlement':report.get('producer_settlement'),'failed_checks':[row['name'] for row in report['checks'] if not row['passed']],'report':str(OUT/'report.json'),'final_accept':'not_run'},ensure_ascii=False),flush=True)
        if report['status']!='passed':sys.exit(1)
