"""Challenge the installed effect-evidence checker using a detached observation copy."""
from copy import deepcopy
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
CASE = ROOT / "review/repair17-upgrade"
PROVIDER = ROOT.parent / "asset-transport-skills/vibelens"
sys.path.insert(0, str(PROVIDER / "scripts"))
from bo_observer.concepts.runtime import runtime_errors
from bo_observer.model_io import read_model


def save(name, value):
    (CASE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


receipt = ROOT / "initial-v1/checks/observations.json"
original_hash = hashlib.sha256(receipt.read_bytes()).hexdigest()
native = json.loads(json.loads(receipt.read_text(encoding="utf-8"))["stdout"])
assert native["build_id"] == json.loads((ROOT / "manifest.json").read_text(encoding="utf-8"))["build_id"]
save("strict-observations-original.json", native)
model = read_model(ROOT / "bo_stategraph/project.json", project_root=ROOT)
discovery = json.loads((ROOT / "discovery.json").read_text(encoding="utf-8"))
clean_before = runtime_errors(discovery, model, native)
assert clean_before == [], clean_before
altered = deepcopy(native)
run = next(item for item in altered["runs"] if item["case"] == "normal" and item["mode"] == "on")
target = next(event for event in run["events"] if event["node"] == "admission_transaction" and event["phase"] == "return" and event.get("outputs", {}).get("committed") is True)
run["events"] = [event for event in run["events"] if event["id"] != target["id"]]
save("negative-missing-effect-completion.json", altered)
negative_errors = runtime_errors(discovery, model, altered)
assert any("concept effect completion missing:" in error for error in negative_errors), negative_errors
clean_retest = runtime_errors(discovery, model, native)
assert clean_retest == [], clean_retest
assert hashlib.sha256(receipt.read_bytes()).hexdigest() == original_hash
save("effect-evidence-negative-control.json", {
    "valid": True,
    "method": "Installed canonical concept runtime_errors, also used by the complete verification gate, against this build's original observations and a detached copy. No native execution, browser or recording was started.",
    "build_id": native["build_id"],
    "clean_before_errors": clean_before,
    "mutation": {"case": run["case"], "mode": run["mode"], "removed_event_id": target["id"], "node": target["node"], "phase": target["phase"], "call_id": target.get("call_id"), "transaction_id": target.get("outputs", {}).get("transaction_id")},
    "negative_errors": negative_errors,
    "clean_retest_errors": clean_retest,
    "original_verification_receipt_unchanged": True,
    "transport_or_browser_claim": "none",
})
print(json.dumps({"valid": True, "negative_errors": negative_errors, "clean_retest_errors": clean_retest}), flush=True)
