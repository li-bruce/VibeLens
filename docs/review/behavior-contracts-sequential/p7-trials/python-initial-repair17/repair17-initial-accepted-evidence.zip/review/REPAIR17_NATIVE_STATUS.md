# Repair 17: initial native technical acceptance

The normal external-provider upgrade, one ordinary real-Chrome recording and both pre/post original complete verification gates passed. This is evidence for the initial application. No task-cancellation iteration or final accept was performed.

- Provider: `../asset-transport-skills/vibelens`; user-supplied upstream revision `844b878d`
- Candidate: `73b321f72b608803e5fb8c3c16e9ef4050f82e48a354a29338c7d58a1d19fc5e`
- Build: `cc8a0633e31654a24fba0d074b017628a440aa68a04581f128cd2f1419585815`
- Recording: `a4015db45df34133bc8110331100c3f0`
- Result: **stopped**, **2710 events**, **24 frames**, gaps **[]**, ownership gaps **[]**

## Normal upgrade and original requirements

The four old project-owned Python processes were checked against exact commands, ports and ancestry, then stopped. The current full recording, baseline, native files, personal configuration and service logs were archived in `repair17-upgrade/pre-upgrade.zip`, with file hashes. Old-provider recall, new dependency check, normal lightweight integration plan/apply/check, new-provider integrity recall, source/model generation, scan and names inventory/check passed. All seven managed adapters were already canonical and needed no byte changes. The expected first stale-review inspect (exit 1, no structural errors) is retained; a candidate-specific technical review was updated and inspect passed. No installed Skill was edited.

The entire native/conceptual model and manifest binding map equal the pre-upgrade version. All business source, rules, four declarations, IDs, original assertions, capture requirements, repaired bilingual names and baseline are unchanged. The original 20 browser check names and explicit timeouts are retained. Current full capture is `all`; there are no timing wrappers, enlarged stop deadlines, capture reductions, artificial waits or late-event backfills.

## Actual operation and capture results

Three real logins, actual upload/share, recipient re-share denial, a genuinely queued/unadmitted request, owner revoke and normal worker rejection ran through the application. Re-sharing did not revive the rejected attempt. A new attempt was admitted, produced a real ZIP and supported two successful byte-exact collections. The independent editor published, edited and deleted their own announcement. Actual independent HTTP receipts and matching API returns include 302 (unauthenticated), 400 (missing CSRF), 403 (forbidden re-share), and normal 200/303 returns.

All **20 original browser assertions** pass. Every one of **12 native journal commits** and **12 pre-state reads** has its own matching original frame, including the unchanged queued context with a newly denied operation input. All **24 frame identities** and all **5 final model-instance states/revisions/contexts** match independent native SQL. The actual admission effect has one entry, one successful completion, stable transaction identity, an explicit owning start-preparation call and the matching committed SQL journal. This recorded interval has **one committed effect attempt and zero failed effect attempts**; absent failures are not invented. Native rollback/error tests retain their separate original test evidence.

All **533 calls** close and the producer's recorded source prefix is continuous. Original stop: `flushed=true`, target **2892**, completed **2892**, submitted **2896**, pending **4**. The four pending items are after the fixed target. Original producer errors/drops and transport retries are zero; there is no recorded event/context/frame eviction. Last-ACK counters gathered later remain separate. Start/stop ACK counters bound **2730 queue items** over **11.672092 seconds**, approximately **233.89 items/s**. This includes events/snapshots and is an approximate interval rate, not a benchmark or continuous queue sample.

The collector and native producer are separate normal OS processes; the default native worker and the actual viewer were active. The native acceptance browser closed after four screenshots. The original record reloaded unchanged, and the final read after complete verification found all native rows equal to the saved post-operation SQL snapshot.

## Static-resource connection evidence

Browser CDP observed **104 JS/CSS responses**, all **200** and **HTTP/1.1**, across **10 reported connection IDs**; **96 responses** reported reused connections. There were **zero static request failures and zero page JS errors**. Only browser network metadata was added, without producer or SDK instrumentation. The raw responses are in `static-resource-network.json`; this one ordinary session does not replace the coordinating chat's repeated language/layer/Timeline review.

## Complete original verification and failure sensitivity

Both pre-recording and post-recording complete configured verify passed for this exact candidate. Mapping, native state rules, concepts, business and project checks all pass. The unchanged original commands ran **14 business tests**, **5 HTTP observation tests**, strict documentation and strict API checks. Nine original runs (`normal`, `queued_revoked`, `started_revoked` × `on`, `off`, `fault`) retain **132/132 assertions**, **106 ordered canonical snapshot admissions**, **530 independent intermediate SQL/input comparisons**, **818 mapping witnesses** and **369 projection comparisons**. Native permission rules and observation-on/off/fault outcomes retain their independent native witnesses.

A detached current-build observation copy missing one actual effect terminal was rejected by the installed canonical checker with `concept effect completion missing`; the unchanged original passed before and after. This is an intentional negative control. There were no unexpected upgrade, recording or gate failures. The main repository's reported 1174-test/105-group regression and export approval are upstream evidence supplied by the user, not tests rerun in this application trial.

## Configuration retention and live handoff

Normal `bo.py serve` refreshed `.stategraph/collector.json` to **http://127.0.0.1:8876** with this exact new build. Diagnostic **8877 is stopped**. No old collector address was used for this native run, and no collector token is printed in the report.

All **23 original recording/frame files** retain their hashes. At recording startup the **12 personal preference entries**, revision **236**, exactly matched the pre-upgrade entries. The coordinating chat subsequently began authorized independent Web/Timeline review and may change views, languages, notes and selection settings. Those later personal changes are not overwritten or reset. The startup configuration and result remain separately frozen.

- App: **http://127.0.0.1:8875**, listener **49104**, launcher **31544**, normal worker true.
- Graph: **http://127.0.0.1:8876/graph**, listener **47412**, launcher **46232**, installed `asset-transport-skills/vibelens/scripts/bo.py serve`.
- Both URLs and preferences return 200, the collector build matches, and the recording list has no active recording. Exact command lines and ancestry are in `repair17-service-handoff.json`. Both services remain running.

Independent per-layer, Timeline, live-exclusion and interaction conclusions belong to the coordinating chat, whose review is underway. The native thread performs no further page actions. Final accept is **not run**; any business iteration needs its own authorization and separate evidence.

## Evidence locations

- Original interval, frames, SQL, effect attempts, calls, source prefix, HTTP receipts, static transport metadata, downloaded ZIPs and screenshots: `review/browser/repair17-recording-20261120T133626/`
- Upgrade and original configurations: `review/repair17-upgrade/`
- Full post-record gate: `review/repair17-verify-after-recording.json`
- Frozen gate receipts: `review/archive/repair17-post-recording-strict.zip`
- Summary, process handoff and hashes: `repair17-diagnostic-summary.json`, `repair17-service-handoff.json`, `repair17-evidence-manifest.json`

Service logs are copied at seal; the running services' logs may continue growing. The saved recording is not supplemented.
