"""Join actual effect attempts to their native committed transaction and owning call."""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
CASE = Path(json.loads((ROOT / "review/repair17-recording-attempt.json").read_text(encoding="utf-8"))["output"])
sys.path.insert(0, str(ROOT.parent / "asset-transport-skills/vibelens/scripts"))
from bo_observer.concepts.runtime import InvocationEvidence

record = json.loads((CASE / "recording-original.json").read_text(encoding="utf-8"))
native = json.loads((CASE / "native-after-operations.json").read_text(encoding="utf-8"))
index = InvocationEvidence(record["events"])
attempts = []
for entry in record["events"]:
    if entry["node"] != "admission_transaction" or entry["phase"] != "enter":
        continue
    endings = index.endings(entry, {"return", "error"})
    assert len(endings) == 1 and index.entry(endings[0]) is entry
    terminal = endings[0]
    transaction = entry["inputs"]["transaction_id"]
    assert terminal["outputs"]["transaction_id"] == transaction
    owners = [index.by_id[identity] for identity in index.upstream(entry) if index.by_id[identity]["node"] == "start_preparation" and index.by_id[identity]["phase"] == "enter"]
    assert len(owners) == 1
    owner_endings = index.endings(owners[0], {"return", "error"})
    assert len(owner_endings) == 1
    committed = terminal["phase"] == "return" and terminal["outputs"].get("committed") is True
    journal = [row for row in native["transition_journal"] if row["transaction_id"] == transaction and row["model_id"] == "download-job" and row["event"] == "start"]
    if committed:
        assert len(journal) == 1 and journal[0]["after"] == "preparing" and journal[0]["permission_allowed"]
        assert journal[0]["instance_id"] == entry["inputs"]["job_id"]
        assert owner_endings[0]["phase"] == "return"
    else:
        assert terminal["phase"] == "error" and not journal and owner_endings[0]["phase"] == "error"
    attempts.append({"entry_event_id": entry["id"], "terminal_event_id": terminal["id"], "phase": terminal["phase"], "transaction_id": transaction, "job_id": entry["inputs"]["job_id"], "committed": committed, "owner_entry_event_id": owners[0]["id"], "owner_terminal_event_id": owner_endings[0]["id"], "native_journal": journal})
assert len(attempts) == 1 and attempts[0]["committed"]
report = {"valid": True, "attempts": attempts, "committed_attempts": sum(row["committed"] for row in attempts), "failed_attempts_in_this_recording": sum(not row["committed"] for row in attempts), "scope": "This actual browser interval has one admitted effect and one earlier queued rejection with no admission effect. Failed/rollback attempts and on/off/fault isolation retain their independent original native test evidence; no absent attempt is invented."}
(CASE / "actual-effect-attempts.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"valid": True, "actual_effect_attempts": len(attempts), "committed": report["committed_attempts"], "failed_in_recording": report["failed_attempts_in_this_recording"]}), flush=True)
