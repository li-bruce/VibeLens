"""Run the original configured gate after the ordinary current-build recording."""
from pathlib import Path
import json
import os
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tooling.verify import command

provider = (ROOT / json.loads((ROOT / "tooling/vibelens.json").read_text(encoding="utf-8"))["skill_root"]).resolve()
os.environ["TEAM_FILES_DATABASE_URL"] = "sqlite:///" + (ROOT / "var/team.sqlite3").as_posix()
prefix = [sys.executable, "-B", "-X", "utf8"]
command([*prefix, str(provider / "scripts/change_sync.py"), "inspect", "--root", str(ROOT)], "repair17-inspect-after-recording")
result = command([*prefix, str(provider / "scripts/change_sync.py"), "verify", "--root", str(ROOT)], "repair17-verify-after-recording")
assert result["candidate_id"] == json.loads((ROOT / "review/repair17-upgrade/inspect.json").read_text(encoding="utf-8"))["candidate_id"]
print(json.dumps({"valid": result["valid"], "reports": {name: report["status"] for name, report in result["reports"].items()}, "final_accept": "not_run"}), flush=True)
