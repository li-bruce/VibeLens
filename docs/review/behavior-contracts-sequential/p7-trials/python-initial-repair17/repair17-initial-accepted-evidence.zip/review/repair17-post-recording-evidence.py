"""Check every saved frame identity and immutable recording against native SQL."""
from collections import Counter
from contextlib import closing
from datetime import datetime
from pathlib import Path
import hashlib
import json
import sqlite3
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
CASE = Path(json.loads((ROOT / "review/repair17-recording-attempt.json").read_text(encoding="utf-8"))["output"])


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def save(name, value):
    (CASE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


record = read(CASE / "recording-original.json")
events = {event["id"]: event for event in record["events"]}
frames = record["runtime_frames"]["frames"]
native = read(CASE / "native-after-operations.json")
identities = []
latest = {}
for frame in frames:
    event = events[frame["event_id"]]
    value = event["outputs"]
    configuration = frame["machine"]["configurations"][0]
    valid = (
        frame["run_id"] == event["run_id"]
        and frame["build_id"] == event["build_id"] == record["build_id"] == configuration["run_build_id"]
        and frame["revision"] == event["revision"] == configuration["state_revision"] == frame["machine"]["state_revision"]
        and frame["machine"]["state_model_id"] == configuration["state_model_id"] == value["model_id"]
        and configuration["native_instance_id"] == value["instance_id"]
        and configuration["snapshot_instance"] == frame["machine"]["current_instance"]
    )
    identities.append({"event_id": frame["event_id"], "model_id": value["model_id"], "native_instance_id": value["instance_id"], "revision": frame["revision"], "state": frame["machine"]["current"], "valid": valid})
    latest[(value["model_id"], value["instance_id"])] = frame
assert len(frames) == 24 and all(row["valid"] for row in identities)
tables = {"file": "files", "grant": "grants", "download-job": "download_jobs", "announcement": "announcements"}
finals = []
for (model_id, instance), frame in latest.items():
    row = next(row for row in native[tables[model_id]] if (row["file_id"] + ":" + row["recipient_id"] if model_id == "grant" else row["id"]) == instance)
    journal = next(row for row in reversed(native["transition_journal"]) if row["model_id"] == model_id and row["instance_id"] == instance and row["revision"] == frame["revision"])
    context = frame["machine"]["configurations"][0]["context"]
    valid = frame["machine"]["current"] == row["state"] == journal["after"] and frame["revision"] == row["revision"] and context == {"allowed": bool(journal["permission_allowed"])}
    finals.append({"model_id": model_id, "native_instance_id": instance, "state": row["state"], "revision": row["revision"], "stored_context": context, "matches_final_sql": valid})
assert len(finals) == 5 and all(row["matches_final_sql"] for row in finals)
save("frame-identity-and-final-instance-checks.json", {"valid": True, "frame_checks": identities, "final_instance_checks": finals, "basis": "Original saved frames joined to their exact accepted event and independently read native SQL/journal. No replay or new execution."})
with closing(sqlite3.connect("file:" + (ROOT / "var/team.sqlite3").as_posix() + "?mode=ro", uri=True)) as connection:
    connection.row_factory = sqlite3.Row
    connection.execute("BEGIN")
    current = {table: [dict(row) for row in connection.execute("SELECT * FROM " + table + " ORDER BY rowid")] for table in native}
assert current == native
save("native-data-unchanged-after-browser.json", {"valid": True, "tables": {name: len(rows) for name, rows in native.items()}, "comparison": "All native rows equal the saved post-operation snapshot; post-recording verification uses its original isolated scenario data."})
opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
with opener.open("http://127.0.0.1:8876/api/recordings/" + record["id"], timeout=20) as response:
    reloaded = json.load(response)
assert reloaded == record
save("original-recording-still-immutable.json", {"valid": True, "recording_id": record["id"], "recording_sha256": hashlib.sha256((CASE / "recording-original.json").read_bytes()).hexdigest(), "api_record_equal_after_stop": True, "events": len(record["events"]), "frames": len(frames), "backfill": False})
start = record["context"]["health"]["producer"]
stop = record["final"]["health"]["producer"]
target = record["producer_settlement"]["target"]
duration = (datetime.fromisoformat(record["ended_at"]) - datetime.fromisoformat(record["started_at"])).total_seconds()
launch = read(ROOT / "review/repair17-live-processes.json")
save("input-rate-and-process-boundary.json", {"basis": "Original start/stop control-ACK counters; queue items include events and snapshots, and retries do not create native executions. Approximate ACK-bounded average, not a continuous sample or benchmark.", "start_ack_queue_submitted": start["queue_submitted"], "start_ack_queue_completed": start["queue_completed"], "stop_ack": stop, "settlement": record["producer_settlement"], "new_fixed_prefix_items": target - start["queue_submitted"], "recording_wall_seconds": duration, "queue_items_per_second": (target - start["queue_submitted"]) / duration, "transport_retries_at_start": start["transport_retries"], "transport_retries_at_stop": stop["transport_retries"], "transport_retries_during_recording": stop["transport_retries"] - start["transport_retries"], "collector_health_at_start": record["context"]["health"], "collector_health_at_stop": record["final"]["health"], "producer_process_separate_from_collector": launch["app_pid"] != launch["viewer_pid"], "actual_viewer_open_during_operations": True, "normal_worker_active": launch["default_worker"], "method_timing_wrappers": False})
http = [{"event_id": event["id"], "node": event["node"], "status": event["outputs"]["status"], "call_id": event.get("call_id"), "parent_event_id": event.get("parent_event_id")} for event in record["events"] if event["node"].startswith("api:") and event["phase"] == "return" and isinstance(event.get("outputs", {}).get("status"), int)]
save("recorded-http-returns.json", {"returns": http, "status_counts": dict(Counter(str(row["status"]) for row in http)), "independent_early_receipts": read(CASE / "early-http-receipts.json"), "independent_reshare_denial": read(CASE / "report.json")["denial_receipt"]})
assert record["gaps"] == [] and record.get("ownership_gaps", []) == []
print(json.dumps({"valid": True, "frame_identities": len(identities), "final_native_instances": len(finals), "recording_immutable": True, "ownership_gaps": record.get("ownership_gaps", []), "recorded_http_statuses": sorted({row["status"] for row in http}), "transport_retries_during_recording": stop["transport_retries"] - start["transport_retries"]}), flush=True)
