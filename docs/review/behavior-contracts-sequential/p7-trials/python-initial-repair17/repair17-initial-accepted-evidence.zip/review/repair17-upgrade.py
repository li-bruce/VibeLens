"""Use the normal external-provider upgrade and retain the original P7 boundaries."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
CASE = ROOT / "review/repair17-upgrade"
OLD = ROOT.parent / "effect-evidence-skills/vibelens"
NEW = ROOT.parent / "asset-transport-skills/vibelens"
PREFIX = [sys.executable, "-B", "-X", "utf8"]
os.environ["TEAM_FILES_DATABASE_URL"] = "sqlite:///" + (ROOT / "var/team.sqlite3").as_posix()


def save(name, value):
    (CASE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def files(directory):
    return [p for p in directory.rglob("*") if p.is_file() and "__pycache__" not in p.parts]


def run(script, action, name, *args, provider=NEW, expected_failure=False):
    if (CASE / (name + ".json")).exists():
        raise RuntimeError("Preserve previous command receipt: " + name)
    argv = [*PREFIX, str(provider / "scripts" / script), action, "--root", str(ROOT), *map(str, args)]
    completed = subprocess.run(argv, cwd=ROOT, capture_output=True, encoding="utf-8", errors="replace", timeout=420)
    (CASE / (name + ".stdout.log")).write_text(completed.stdout, encoding="utf-8")
    (CASE / (name + ".stderr.log")).write_text(completed.stderr, encoding="utf-8")
    result = json.loads(completed.stdout) if completed.stdout.strip() else {}
    save(name + ".json", result)
    save(name + "-command.json", {"argv": argv, "exit_code": completed.returncode, "utc": datetime.now(timezone.utc).isoformat()})
    print(json.dumps({"stage": name, "exit_code": completed.returncode, "valid": result.get("valid"), "candidate_id": result.get("candidate_id")}), flush=True)
    if completed.returncode and not expected_failure:
        raise RuntimeError("Failed stage: " + name)
    return result


def local(script, name):
    argv = [*PREFIX, str(ROOT / script)]
    completed = subprocess.run(argv, cwd=ROOT, capture_output=True, encoding="utf-8", errors="replace", timeout=420)
    (CASE / (name + ".stdout.log")).write_text(completed.stdout, encoding="utf-8")
    (CASE / (name + ".stderr.log")).write_text(completed.stderr, encoding="utf-8")
    save(name + "-command.json", {"argv": argv, "exit_code": completed.returncode})
    print(json.dumps({"stage": name, "exit_code": completed.returncode}), flush=True)
    if completed.returncode:
        raise RuntimeError("Failed stage: " + name)


stage = sys.argv[1]
if stage == "archive-recall":
    assert read(CASE / "services-stopped.json")["remaining_processes"] == []
    assert not (CASE / "pre-upgrade.zip").exists()
    paths = [p for p in ROOT.iterdir() if p.is_file()]
    for folder in ("app", "integrations", "templates", "static", "tests", "tooling", "initial-v1", ".stategraph", "bo_stategraph", "var"):
        paths += files(ROOT / folder)
    paths += files(Path(read(ROOT / "review/effect16-live-processes.json")["runtime_directory"]))
    protected = [p for folder in ("app", "integrations", "templates", "static", "tests", "tooling") for p in files(ROOT / folder) if p != ROOT / "tooling/vibelens.json"]
    protected += [ROOT / name for name in ("discovery.json", "intent.json", "acceptance.json", "mapping.json", "sync.json", "implementation.json", "bo_stategraph/behavior.json", "bo_stategraph/workflow.py", "bo_stategraph/query.py", "bo_stategraph/machines.json", "bo_stategraph/config/semantic-names.json", "bo_stategraph/config/views/local.json", "initial-v1/baseline.json", ".stategraph/active.json")]
    originals = list((ROOT / "review/browser").rglob("recording-original.json")) + list((ROOT / "review/browser").rglob("runtime-frames-original.json")) + files(ROOT / "bo_stategraph/data/recordings")
    with zipfile.ZipFile(CASE / "pre-upgrade.zip", "x", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(set(paths)):
            archive.write(path, path.relative_to(ROOT).as_posix())
    save("retention-before.json", {"utc": datetime.now(timezone.utc).isoformat(), "archive_sha256": digest(CASE / "pre-upgrade.zip"), "protected": {p.relative_to(ROOT).as_posix(): digest(p) for p in sorted(set(protected))}, "original_recordings": {p.relative_to(ROOT).as_posix(): digest(p) for p in sorted(set(originals))}, "native_runtime_data": {p.relative_to(ROOT).as_posix(): digest(p) for p in files(ROOT / "var")}, "old_provider_files": {p.relative_to(OLD).as_posix(): digest(p) for p in files(OLD)}, "new_provider_files": {p.relative_to(NEW).as_posix(): digest(p) for p in files(NEW)}})
    (CASE / "coding-review-before.json").write_bytes((ROOT / "initial-v1/review.json").read_bytes())
    recalled = run("change_sync.py", "recall", "recall-before", provider=OLD)
    print(json.dumps({"framework_valid": recalled.get("framework", {}).get("valid"), "models": recalled.get("model_inventory"), "source_errors": recalled.get("source_errors")}), flush=True)
elif stage == "upgrade":
    argv = [*PREFIX, str(NEW / "scripts/bo_dependencies.py"), "check"]
    completed = subprocess.run(argv, cwd=ROOT, capture_output=True, encoding="utf-8", errors="replace", timeout=90)
    (CASE / "dependencies.stdout.log").write_text(completed.stdout, encoding="utf-8")
    (CASE / "dependencies.stderr.log").write_text(completed.stderr, encoding="utf-8")
    save("dependencies-command.json", {"argv": argv, "exit_code": completed.returncode})
    assert completed.returncode == 0, "Dependency check failed; retain original result."
    for action in ("plan", "apply", "check"):
        result = run("bo_integrate.py", action, "integration-" + action, "--language", "python")
        if action == "plan":
            print(json.dumps({"integration_plan": result}, ensure_ascii=False), flush=True)
    (ROOT / "tooling/vibelens.json").write_text(json.dumps({"skill_root": "../asset-transport-skills/vibelens"}, indent=2) + "\n", encoding="utf-8")
    recalled = run("change_sync.py", "recall", "recall-after-provider")
    assert recalled.get("framework", {}).get("valid"), recalled.get("framework")
    local("tooling/build_model.py", "generation")
    run("bo_sync.py", "scan", "scan")
    run("bo_names.py", "inventory", "names-inventory")
    run("bo_names.py", "check", "names-check")
    inspected = run("change_sync.py", "inspect", "inspect-before-review", expected_failure=True)
    assert not inspected.get("errors") and inspected.get("candidate_id"), inspected.get("errors")
    review = read(ROOT / "initial-v1/review.json")
    review["candidate_id"] = inspected["candidate_id"]
    review["decisions"]["probes"]["reason"] += " The authorized repair17 external provider (user-supplied revision 844b878d) is selected through normal lightweight plan/apply/check. Static-resource connection reuse is supplied by the installed framework; no installed source is edited. Preserve business meaning, four native models, all original captures/assertions, repaired bilingual names, current personal views/annotations and original recordings. The initial native acceptance is separate from any later business iteration. Run the original configured gate, then one ordinary real-browser sequence using separate producer/collector processes, the default worker, unchanged capture and stop deadlines, no timing wrappers or backfill, followed by complete verification. No final accept."
    review["requirement_changes"] = {}
    (ROOT / "initial-v1/review.json").write_text(json.dumps(review, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    run("change_sync.py", "inspect", "inspect")
elif stage == "verify":
    run("change_sync.py", "verify", "verify")
else:
    raise ValueError("Unknown stage")
