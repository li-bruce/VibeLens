Accepted initial application archive.

Source-model ZIP retains authored application source, definitions, protected original tests/assertions and approved personal views. Dependencies and credentials are excluded. Recreate managed adapters only through the configured external Skill's normal plan/apply/check; requirements remain included.

Evidence ZIP retains the exact native interval, synthetic input/downloads, original pre/post verification, native SQL/rollback and two-claimant test evidence, normal accept/check, and the coordinating independent UI artifacts. Original event/frame bytes are unchanged. The private pre-upgrade recovery ZIP is intentionally excluded.

Acceptance covers the initial candidate only. P7 overall and future iteration remain unfinished. Running services and current approved personal views are not changed by packaging.
