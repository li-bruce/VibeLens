# Project verification

Business requirements and the drive-mode decision are preserved in `discovery.json` and `intent.json`. Change meaning only from an explicit current user instruction. Keep English source, comments and canonical documentation, with Chinese product display.

The existing project verification gate is `python -B -X utf8 tooling/verify.py`, using the external tooling interpreter documented in `README.md`. It runs the installed interfaces configured by `tooling/vibelens.json`. Retain the active change baseline, protected acceptance cases, mappings, original recordings and failed receipts. Run the gate before claiming delivery; after accepted code changes establish a new change before editing. Keep the managed native adapters unchanged and use normal plan/apply/check for updates.

This project gate does not activate VibeLens or ARIS workflows in other chats. Skill activation remains explicit per chat. Do not start a business iteration while the initial delivery is still under review.
