# Team Files

A local Python/Flask team file-sharing application with Chinese pages, SQLite/SQLAlchemy storage, four independent declaration-driven lifecycles and an independent announcement board.

## Run the application

From this project directory:

```powershell
& .\.venv\Scripts\python.exe -B -X utf8 run.py --port 8875
```

Open <http://127.0.0.1:8875>. The native background worker prepares real ZIP files. `--observe off` disables capture. `--observe fault` deliberately fails observation transport while native business effects continue. The application also works through its neutral port when external observation is unavailable. `--no-worker` is reserved for deterministic boundary acceptance.

Three synthetic accounts are seeded only when missing:

| Username | Password | Announcement editor |
|---|---|---|
| alice | demo-alice-123 | No |
| bob | demo-bob-123 | No |
| casey | demo-casey-123 | Yes |

The uploader and current recipients see original files. Only the uploader manages each recipient's grant. A queued download is permanently rejected if the pinned grant was revoked. Preparation-start admission and its state transition are committed together. An admitted attempt survives later revocation, finishes, and retains its result for repeated requester-only collection. The editor role grants no additional file authority.

## Run the observer

`tooling/vibelens.json` selects the explicitly authorized independent installation. Current tooling Python:

```powershell
$toolPython = 'C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.venv\Scripts\python.exe'
$appRoot = (Get-Location).Path
$env:TEAM_FILES_DATABASE_URL = 'sqlite:///' + (Join-Path $appRoot 'var/team.sqlite3').Replace('\','/')
$provider = Get-Content -Raw tooling/vibelens.json | ConvertFrom-Json
$viewerCli = Join-Path (Join-Path $appRoot $provider.skill_root) 'scripts/bo.py'
& $toolPython -B -X utf8 $viewerCli serve --root $appRoot --port 8876 --origin http://127.0.0.1:8875
```

Start the observer before the observed application so the native producer reads its current collector settings. Open <http://127.0.0.1:8876/graph>. The observer reads metadata and native state; the application owns all permissions, transitions, files and database writes. Collector tokens and the private session key are runtime secrets and are excluded from exported review archives.

## Verify

```powershell
& $toolPython -B -X utf8 tooling/verify.py
& $toolPython -B -X utf8 tooling/browser_acceptance.py
```

The first command preserves the original `initial-v1` baseline, regenerates source/rule/database bindings, runs actual on/off/fault scenarios and project tests, then verifies, accepts and checks the current candidate. `sync.json` retains the required mappings, producer health and invocation-closure gates. Inspect the saved raw output if any stage fails.

The second command launches a separate headless Chrome profile and a temporary localhost server on port 8878, using isolated native data. It verifies actual forms, stale-page rejection, deterministic preparation-start boundaries, repeated downloaded bytes, announcement operations and the automatic worker. It preserves screenshots, native database/journal facts, original events and HTTP statuses under `review/browser/<timestamp>/`. It never reads a personal browser profile.

## Evidence and scope

`review/archive/` contains pre-upgrade source/graph/failure snapshots. The managed updates used normal plan/apply/check. `review/runtime/` contains native boundary records. `review/final-*.json` and the original change directory hold final verification receipts. Failed diagnostics remain available; a later success does not rewrite them.

The pinned behavior contract describes each object's lifecycle and native executor boundaries. Separate protected checks cover permissions, transaction completion, HTTP, SQLite structure, actual file bytes, concurrent claims and observer isolation. Optional finite/formal analysis was not run. A finite acceptance suite does not prove arbitrary executions or distributed worker scheduling.

Application desktop screenshots are verified separately from VibeLens viewer acceptance. Recording/replay, Timeline, and every individual 2D/3D layer view require their own explicit viewer checks and must not be inferred from passing application tests.
