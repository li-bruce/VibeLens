"""Diagnostic byte reader; no project code is imported or executed."""
import sys,json,base64
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'skills/vibelens/scripts'))
from bo_observer.graph.source_files import SourceFiles
reader=SourceFiles(sys.argv[1])
for line in sys.stdin:
    try:
        values=reader.read_all(json.loads(line))
        result={'files':{str(k):base64.b64encode(v).decode() if v is not None else None for k,v in values.items()}}
    except Exception as e: result={'error':str(e)}
    print(json.dumps(result),flush=True)
