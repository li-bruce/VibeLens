"""External diagnostic producer: original envelopes only, no business execution."""
import json
from pathlib import Path
import sys
import time

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root/'skills/vibelens/scripts'))
from bo_observer.adapters.python.bo_probe import BOProbe
from bo_observer.adapters.python.bo_capture import BOCaptureClient
import bo_observer.adapters.python.bo_probe as sdk

data=json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
if data['legacy_budget']:
    sdk.BO_EVENT_BATCH_BYTES=24576
probe=BOProbe(data['project'], data['build_id'], endpoint=data['url'],
              token=data['token'], capacity=8192)
control=BOCaptureClient(probe).start()
print(json.dumps({'ready':True}),flush=True)
try:
    for line in sys.stdin:
        command=json.loads(line)
        if command['action']=='enqueue':
            snapshots={v['evidence_id']:v for v in data['run']['snapshots']}
            started=time.perf_counter()
            for event in data['run']['events']:
                probe.bo_put('events',event)
                if event['id'] in snapshots:
                    probe.bo_put('snapshots',snapshots[event['id']])
                time.sleep(.004)
            value={'seconds':time.perf_counter()-started,'health':probe.bo_health()}
        elif command['action']=='health': value=probe.bo_health()
        elif command['action']=='flush': value=probe.flush(command['timeout'])
        elif command['action']=='close':
            print(json.dumps({'closed':True}),flush=True)
            break
        else: raise ValueError('Unknown diagnostic command')
        print(json.dumps(value),flush=True)
finally:
    control.close()
    probe.close()
