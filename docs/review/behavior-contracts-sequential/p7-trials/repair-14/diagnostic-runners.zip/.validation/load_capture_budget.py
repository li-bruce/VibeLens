"""Isolated ingress load with real HTTP, capture controls, watcher and optional Web.

Original strict envelopes are replayed unchanged. This is diagnosis, never native
business acceptance. Method timings are enabled only in this detached process.
"""
import argparse
from collections import defaultdict
from functools import wraps
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import threading
import time
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "skills/vibelens/scripts"))
from bo_observer.graph.behavior_model import capture
from bo_observer.project_artifacts import references
from bo_observer.observation.session import GraphSession
from bo_observer.service import make_server
from bo_observer.adapters.python.bo_probe import BOProbe
from bo_observer.adapters.python.bo_capture import BOCaptureClient
from bo_observer.data.watcher import DataWatch
from bo_observer.data.sync import synchronize
from bo_observer.code_graph.service import CodeGraph

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("name")
parser.add_argument("--watch", action="store_true")
parser.add_argument("--browser", action="store_true")
parser.add_argument("--serial-reads", action="store_true")
parser.add_argument("--legacy-budget", action="store_true")
args = parser.parse_args()
if args.legacy_budget:
    import bo_observer.service as transport
    import bo_observer.adapters.python.bo_probe as sdk
    transport.EVENT_BATCH_BYTES = sdk.BO_EVENT_BATCH_BYTES = 24576
if args.serial_reads:
    from bo_observer.graph.source_files import SourceFiles
    SourceFiles.read_all = lambda self, names: {name:self.read(name) for name in names}
evidence = ROOT / "docs/review/behavior-contracts-sequential/p7-trials/repair-14"
evidence.mkdir(exist_ok=True)
source = ROOT / ".validation/p7-trials/python-retest-app"
target = ROOT / ".validation/p7-trials" / ("ingress-" + args.name)
target.mkdir(exist_ok=False)
project = json.loads((source / "bo_stategraph/project.json").read_text(encoding="utf-8"))
manifest = capture(source, project["model"])
names = set(manifest["files"]) | {"bo_stategraph/project.json", "sync.json", "acceptance.json"}
names.update(ref["path"] for _, ref in references(project))
names.update(["bo_stategraph/database.json", "bo_stategraph/database-catalog.json", "var/team.sqlite3"])
names.update(path.relative_to(source).as_posix() for path in (source / "bo_stategraph").glob("*.py"))
names.add("bo_stategraph/integration.json")
for name in sorted(names):
    path = source / name
    if path.is_file():
        destination = target / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, destination)
os.environ["TEAM_FILES_DATABASE_URL"] = "sqlite:///" + (target / "var/team.sqlite3").as_posix()

timings = defaultdict(list)
timing_lock = threading.Lock()
def instrument(cls, name):
    original = getattr(cls, name)
    @wraps(original)
    def timed(*values, **kwargs):
        started = time.perf_counter()
        try:
            return original(*values, **kwargs)
        finally:
            with timing_lock:
                timings[cls.__name__ + "." + name].append(time.perf_counter() - started)
    setattr(cls, name, timed)

for cls, names in [(GraphSession, ("binding", "view", "snapshot", "event")),
                   (CodeGraph, ("refresh", "project_view", "api_snapshot")),
                   (DataWatch, ("tick",))]:
    for name in names:
        instrument(cls, name)
runs = [item for item in json.loads((source / "review/sequential-observations-original.json")
    .read_text(encoding="utf-8"))["runs"] if item["mode"] == "on"]
run = {name:[value for item in runs for value in item[name]] for name in ('events','snapshots')}
if args.watch:
    initial_sync = synchronize(target)
    assert initial_sync["valid"], initial_sync
session = GraphSession(target)
print("session loaded", flush=True)
relocated_build = session.manifest["build_id"]
# Database endpoint identity changes when moving the SQLite copy. Rebase that
# declared build field only; keep all producer, causal, value and event identities.
# This derived load is recorded as diagnosis, never original runtime evidence.
for collection in (run["events"], run["snapshots"]):
    for envelope in collection:
        assert envelope["build_id"] == manifest["build_id"]
        envelope["build_id"] = relocated_build
server = make_server(session, port=0, token="detached-ingress-diagnostic")
url = f"http://127.0.0.1:{server.server_port}"
threading.Thread(target=server.serve_forever, daemon=True).start()
probe = BOProbe(session.project, relocated_build, endpoint=url,
                token="detached-ingress-diagnostic", capacity=8192)
control = BOCaptureClient(probe).start()
watcher = DataWatch(server) if args.watch else None
if watcher:
    initial_watch = watcher.tick()
    assert initial_watch["valid"], initial_watch
    print("watcher warmed", flush=True)
    watcher.start()
driver = browser = None
page_errors = []
if args.browser:
    from playwright.sync_api import sync_playwright
    driver = sync_playwright().start()
    browser = driver.chromium.launch(executable_path="C:/Program Files/Google/Chrome/Application/chrome.exe",
        headless=True, args=["--enable-unsafe-swiftshader"])
    page = browser.new_page(viewport={"width":1600, "height":1000})
    page.on("pageerror", lambda error: page_errors.append(str(error)))
    page.goto(url + "/graph?lang=zh-CN", wait_until="domcontentloaded")
    page.wait_for_function("window.graphDebug?.graph && !graphDebug.layoutBusy", timeout=60000)
    print("actual viewer loaded", flush=True)
recording = session.recordings.start("Detached original-envelope diagnostic")
print("recording started", flush=True)
snapshots = {item["evidence_id"]: item for item in run["snapshots"]}
started = time.perf_counter()
for event in run["events"]:
    probe.bo_put("events", event)
    if event["id"] in snapshots:
        probe.bo_put("snapshots", snapshots[event["id"]])
    time.sleep(.004)
enqueue = time.perf_counter() - started
before = probe.bo_health()
print("enqueue complete", before["pending"], flush=True)
stopped = session.recordings.stop()
report = {"scope":"Detached diagnostic; not native acceptance", "watch":args.watch,
          "relocated_build":{"original":manifest["build_id"], "copy":relocated_build},
          "browser":args.browser, "events":len(run["events"]), "snapshots":len(snapshots),
          "serial_reads":args.serial_reads, "legacy_batch_budget":args.legacy_budget, "original_run_count":len(runs),
          "enqueue_seconds":enqueue, "before_stop":before, "after_stop":probe.bo_health(),
          "recording":stopped, "collector_errors":session.errors, "collector_error":session.last_error,
          "stored":session.sequence, "frames":len(session.frames), "page_errors":page_errors}
if browser:
    page.screenshot(path=str(evidence / (args.name + ".png")))
    browser.close()
    driver.stop()
if watcher:
    watcher.close()
probe.flush(30)
control.close()
probe.close()
server.shutdown()
server.server_close()
report["timings"] = {key:{"calls":len(values), "total_seconds":sum(values),
    "max_seconds":max(values), "p95_seconds":sorted(values)[int((len(values)-1)*.95)]}
    for key,values in timings.items()}
(evidence / (args.name + ".json")).write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
print(json.dumps({key:value for key,value in report.items() if key != "recording"}),flush=True)
