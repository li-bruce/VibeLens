from pathlib import Path
import cProfile,pstats,sys,time,json
root=Path.cwd(); sys.path.insert(0,str(root/'skills/vibelens/scripts'))
from bo_observer.observation.session import GraphSession
from bo_observer.observation.event_batch import BOSessionSink
from bo_observer.protocol import validate_event
out=root/'docs/review/behavior-contracts-sequential/p7-trials/repair-14'
project=root/'.validation/p7-trials/ingress-external-after'
s=GraphSession(project)
r=json.loads((root/'.validation/p7-trials/python-retest-app/review/sequential-observations-original.json').read_text(encoding='utf-8'))['runs'][0]
for e in r['events']: e['build_id']=s.manifest['build_id']
for label,callback in [('binding',lambda:[s.binding() for i in range(40)]),('event_validation',lambda:[validate_event(e,s.project,s.manifest['build_id']) for e in r['events']]),('view',lambda:[s.view() for i in range(10)])]:
 profile=cProfile.Profile(); started=time.perf_counter(); profile.runcall(callback)
 print(label,time.perf_counter()-started,flush=True)
 with (out/('serial-profile-'+label+'.txt')).open('w',encoding='utf-8') as f:pstats.Stats(profile,stream=f).sort_stats('cumulative').print_stats(40)
s.close()
