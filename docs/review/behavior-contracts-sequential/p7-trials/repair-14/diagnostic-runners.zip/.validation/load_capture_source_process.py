"""Detached hypothesis: current source bytes read in a separate observer worker."""
import sys, json, runpy, subprocess,threading,atexit,base64
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'skills/vibelens/scripts'))
from bo_observer.graph.source_files import SourceFiles
readers={}; lock=threading.Lock()
def read_all(self,names):
    with lock:
        key=str(self.root)
        if key not in readers:
            readers[key]=subprocess.Popen([sys.executable,'-u',str(root/'.validation/source_reads_worker.py'),key],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True,encoding='utf-8')
        p=readers[key]; p.stdin.write(json.dumps([str(n) for n in names])+'\n');p.stdin.flush()
        v=json.loads(p.stdout.readline())
        if 'error' in v: raise ValueError(v['error'])
        return {n:base64.b64decode(b) if b is not None else None for n,b in v['files'].items()}
SourceFiles.read_all=read_all
def close():
    for p in readers.values(): p.stdin.close();p.wait(timeout=10);p.stdout.close()
atexit.register(close)
runpy.run_path(str(root/'.validation/load_capture_external.py'),run_name='__main__')
