"""Record request CPU/wall time in the detached load; no profiler tracing hooks."""
import sys,json,time,runpy,atexit,threading
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'skills/vibelens/scripts'))
from bo_observer import service
from bo_observer.observation.event_batch import BOSessionSink
from bo_observer.observation.session import GraphSession
from bo_observer.graph.source_files import SourceFiles
rows=[];lock=threading.Lock()
def wrap(cls,name,route=False):
    original=getattr(cls,name)
    def timed(self,*args,**kwargs):
        start=time.perf_counter();cpu=time.thread_time()
        try: return original(self,*args,**kwargs)
        finally:
            with lock: rows.append({'operation':self.path if route else cls.__name__+'.'+name,'wall':time.perf_counter()-start,'cpu':time.thread_time()-cpu,'count':len(args[0]) if name=='bo_accept_many' else None})
    setattr(cls,name,timed)
factory=service.make_server
def make(*a,**k):
    server=factory(*a,**k)
    for name in ('do_GET','do_POST'): wrap(server.RequestHandlerClass,name,True)
    return server
service.make_server=make
for cls,name in ((BOSessionSink,'bo_accept_many'),(GraphSession,'binding'),(SourceFiles,'read_all')):wrap(cls,name)
atexit.register(lambda:(root/'docs/review/behavior-contracts-sequential/p7-trials/repair-14'/('http-profile-'+sys.argv[1]+'.json')).write_text(json.dumps(rows,indent=2),encoding='utf-8'))
runpy.run_path(str(root/'.validation/load_capture_external.py'),run_name='__main__')
