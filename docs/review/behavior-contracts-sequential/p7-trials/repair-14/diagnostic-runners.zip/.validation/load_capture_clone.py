"""Detached hypothesis only: use JSON-value copies in JSON view paths."""
import sys, json, runpy
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'skills/vibelens/scripts'))
def clone(value):
    return json.loads(json.dumps(value,ensure_ascii=False,allow_nan=False,separators=(',',':')))
from bo_observer.observation import session,recording_session,concept_context,behavior_context
from bo_observer.code_graph import service
from bo_observer.web import semantic_names
for module in (session,recording_session,concept_context,behavior_context,service,semantic_names):
    module.deepcopy=clone
runpy.run_path(str(root/'.validation/load_capture_external.py'),run_name='__main__')
