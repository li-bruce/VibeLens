# Sequential-source candidate: strict gates pass, ordinary recording interrupted

The one authorized real-viewer recording failed to drain its stop prefix. It is not accepted as a complete recording. Native business outcomes and strict local gates pass, but independent Web/layer/Timeline and total P7 acceptance remain open. Both services and this browser are stopped; no repeat or framework repair follows.

Provider: `../sequential-source-skills/vibelens` (coordinating user supplied upstream revision cc10ceea).
Build: `4d9374abcbb6b9a10cf3804c7b4587147454bafc8a149cab841b6bcd8eaf4a03`.
Candidate: `c616dcca5da5d87bdc73eaf57c803a228aa738d732d5338e962f8526455856c2`.
Recording: `b5a562d365424e3ba1264898d4370ff5`.
Evidence directory: `browser/sequential-recording-20261120T095141/`.

## Upgrade and protected scope

Normal recall, plan/apply/check, generation, scan, inspect/review and strict verify were performed against the new installation. All seven managed files already match the new candidate, so plan reported no byte updates. The project selects the new external provider through tooling/vibelens.json and launches that provider's bo.py normally. No installed framework file was edited.

The original business code, repair11 context/payload correction, all independent SQL/HTTP/intermediate-state checks, mapping.json, acceptance.json, original baseline and protected test commands are byte-identical to the pre-upgrade snapshot. Strict checks pass: 106 ordered snapshot admissions, 530 independent intermediate value comparisons, 132 native business assertions across nine on/off/fault runs, 818 mapping witnesses, 369 projection checks, 14 business tests, five HTTP tests and both strict docs/API commands. `sequential-retention.json` confirms integrity; `archive/sequential-fixed-strict.zip` preserves raw fixed results.

The provider and previous installation retain their before/after byte snapshots. `archive/pre-sequential-upgrade.zip` preserves the previous source/status/check snapshot. The original transport recording and its failure data are unchanged; no artifact under transport-recording was overwritten.

## Ordinary operating conditions and native facts

The normal run.py entrypoint, automatic native worker and installed bo.py serve were used. The actual viewer page remained open and rendered during the user operations. SDK HTTP/stop deadlines, queue capacity, all-events capture range, bounded retry policy and normal worker behavior were not overridden. No method timing, detached replay or replacement sink was used for this browser run.

The exact previous Web flow was performed once: early unauthenticated/CSRF responses, three account logins, actual upload/share, recipient reshare rejection, download queue then grant revocation, automatic worker rejection, re-share/fresh attempt, two real ZIP downloads, and independent announcement publish/edit/delete. Native SQL proves the first job was queued and unadmitted before revocation, then rejected/2 with share_revoked and no admitted start. Re-sharing did not revive it. The new attempt completed and both ZIPs match the original bytes. Announcement operations are separate.

All 12 real transitions across five instances and four models completed. Real HTTP returns, SQL state/journals and actual downloaded files are retained; they do not depend on observed graph values. Existing native data was kept rather than resetting the app to a smaller fixture. The exact pre-run row counts and pending-job counts are saved in `sequential-diagnostic-summary.json` and native-before.json; this is workload provenance, not a demonstrated cause.

## Failed recording boundary

| Evidence | Actual result |
|---|---|
| Start / stop responses | HTTP 200; stop body status=interrupted |
| Original events / frames | 1033 / 12 |
| Stop settlement | flushed=false, target2188, completed1088, submitted2204, pending1116 |
| Fixed target remainder | 1100 unfinished queue items plus 16 after-target submissions; not an established missing-event count |
| Native transition correspondence | 6/12 have recorded commit frames; later fresh-job and announcement transitions are absent |
| Received revision events | 12/12 have their own frames |
| Received pre-state reads | 6/6 agree with independent native state/context; full 12-read coverage remains incomplete |
| Critical changed-input read | queued/1 current allowed=false with versioned context.allowed=true has its own matching frame |
| Gaps | Producer queue did not drain; received facts alone retained |
| Invocation closure | false; original unclosed IDs/calls retained in lifecycle-closure.json |
| Received source prefix | continuous within the original interval; not proof of full stop-prefix completion |

The browser checks correctly fail full transition/read coverage and lifecycle closure on the incomplete record. The matching received reads do not establish the arrival of later missing reads, and those missing facts were not inferred from final SQL.

Safe producer diagnostics and retry counters are saved at both the original stop ACK and the later scope-reset ACK. The later saved health reports transport_retries=6, errors=0, dropped=0 and last_error=null. There is no exposed concrete exception type. These counters cannot be relabeled as TimeoutError or proof that every retry completed. Individual SDK POST response bodies and attempt durations were not captured by the requested ordinary launch. Later ACK pending=1120 is a different sample from original stop pending=1116; the original settlement is authoritative for its boundary.

No event/context/frame evictions were reported. Zero error counters still do not override flushed=false or missing native transitions. Retried native IDs do not represent extra business executions.

## Preserved artifacts and stop

Original report, recording, raw collector frame projections, actual HTTP receipts, native before/after SQL snapshots, each read/transition comparison, lifecycle, continuity, stop settlement, producer details/retries, downloads, screenshot and ordinary logs are under the new evidence directory. `sequential-diagnostic-summary.json` provides the compact facts/unknowns. Same-build raw producer snapshot envelopes and every local admission result are in strict evidence. No wire snapshot was invented from a final state.

Late collector events were frozen separately after service stop and were not inserted into the recording. The original recording hash and old transport recording hash are retained. `sequential-evidence-manifest.json` seals current artifact hashes without exporting the private database or collector credentials.

Browser closure completed. Owned launcher PIDs54212/37328 stopped at 2026-11-20 17:53:01 +08:00. Ports8875/8876 are released, and no Python/Node/browser trial process remains. The former app and graph URLs are currently offline. See sequential-live-processes.json and sequential-stopped-services.json.

Stop at this first failed ordinary run. Await the coordinating session's next instruction. No new business iteration, source refactor, framework patch, timer wrapper, increased timeout, narrowed capture, second recording, historical backfill or final P7 accept follows.
