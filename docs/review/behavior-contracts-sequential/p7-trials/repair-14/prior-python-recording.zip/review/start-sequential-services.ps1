$ErrorActionPreference='Stop'
$taskRoot='C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.validation\p7-trials\python-retest-app'
if (@(Get-NetTCPConnection -LocalPort 8875,8876 -State Listen -ErrorAction SilentlyContinue).Count) { throw 'An existing listener must not be replaced.' }
if (@(Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('python.exe','node.exe') -and $_.CommandLine -like '*p7-trials*' }).Count) { throw 'A trial service or test is still running; no concurrent launch.' }
$taskStamp=(Get-Date).ToUniversalTime().ToString('yyyyMMddTHHmmss')
$taskRuntime=Join-Path $taskRoot ('review/runtime/sequential-live-'+$taskStamp)
New-Item -ItemType Directory -Path $taskRuntime -ErrorAction Stop | Out-Null
$taskToolPython='C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.venv\Scripts\python.exe'
$taskAppPython=Join-Path $taskRoot '.venv/Scripts/python.exe'
$taskProvider=[IO.Path]::GetFullPath((Join-Path $taskRoot ((Get-Content -Raw -LiteralPath (Join-Path $taskRoot 'tooling/vibelens.json') | ConvertFrom-Json).skill_root)))
$taskBuild=(Get-Content -Raw -LiteralPath (Join-Path $taskRoot 'manifest.json') | ConvertFrom-Json).build_id
$env:TEAM_FILES_DATABASE_URL='sqlite:///'+(Join-Path $taskRoot 'var/team.sqlite3').Replace('\','/')
$taskStarted=(Get-Date).ToUniversalTime().ToString('o')
$taskObserverArgs=@('-B','-X','utf8',(Join-Path $taskProvider 'scripts/bo.py'),'serve','--root',$taskRoot,'--port','8876','--origin','http://127.0.0.1:8875')
$taskObserver=Start-Process -FilePath $taskToolPython -ArgumentList $taskObserverArgs -WindowStyle Hidden -WorkingDirectory $taskRoot -RedirectStandardOutput (Join-Path $taskRuntime 'observer.stdout.log') -RedirectStandardError (Join-Path $taskRuntime 'observer.stderr.log') -PassThru
$taskReady=$false
for ($taskAttempt=0;$taskAttempt -lt 40;$taskAttempt++) {
    try { $taskHealth=Invoke-RestMethod -Uri 'http://127.0.0.1:8876/api/bo/health' -TimeoutSec 2; if ($taskHealth.build_id -eq $taskBuild) {$taskReady=$true;break} } catch { if ($taskObserver.HasExited) {throw 'Observer exited; retain logs.'} }
    Start-Sleep -Milliseconds 250
}
if (-not $taskReady) {throw 'Observer did not become ready.'}
$taskDefault=Invoke-WebRequest -Uri 'http://127.0.0.1:8876/api/preferences' -TimeoutSec 20
[ordered]@{method='GET';path='/api/preferences';status=[int]$taskDefault.StatusCode;raw_body=$taskDefault.Content;body=($taskDefault.Content | ConvertFrom-Json)} | ConvertTo-Json -Depth 7 | Set-Content -LiteralPath (Join-Path $taskRuntime 'preferences-get.json') -Encoding utf8
$taskAppArgs=@('-B','-X','utf8',(Join-Path $taskRoot 'run.py'),'--port','8875')
$taskApp=Start-Process -FilePath $taskAppPython -ArgumentList $taskAppArgs -WindowStyle Hidden -WorkingDirectory $taskRoot -RedirectStandardOutput (Join-Path $taskRuntime 'app.stdout.log') -RedirectStandardError (Join-Path $taskRuntime 'app.stderr.log') -PassThru
$taskReady=$false
for ($taskAttempt=0;$taskAttempt -lt 40;$taskAttempt++) {
    try { $taskNative=Invoke-RestMethod -Uri 'http://127.0.0.1:8875/health' -TimeoutSec 2; if ($taskNative.status -eq 'ok' -and $taskNative.worker) {$taskReady=$true;break} } catch { if ($taskApp.HasExited) {throw 'Native app exited; retain logs.'} }
    Start-Sleep -Milliseconds 250
}
if (-not $taskReady) {throw 'Native app did not become ready.'}
$taskReceipt=[ordered]@{launch_environment='host (exec require_escalated)';started_utc=$taskStarted;ready_utc=(Get-Date).ToUniversalTime().ToString('o');provider=$taskProvider;build_id=$taskBuild;runtime_directory=$taskRuntime;app_pid=$taskApp.Id;viewer_pid=$taskObserver.Id;app_arguments=$taskAppArgs;viewer_arguments=$taskObserverArgs;app_url='http://127.0.0.1:8875';viewer_url='http://127.0.0.1:8876/graph';method_timing_wrappers=$false;default_worker=$true;recordings_started_by_launcher=0;final_accept='not_run'}
$taskReceipt | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $taskRuntime 'launch-receipt.json') -Encoding utf8
$taskReceipt | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $taskRoot 'review/sequential-live-processes.json') -Encoding utf8
$taskReceipt | ConvertTo-Json -Depth 5
