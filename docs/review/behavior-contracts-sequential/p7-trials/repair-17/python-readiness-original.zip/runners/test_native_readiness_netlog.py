"""Repeat real locale/reload transitions and retain readiness flags on failure."""
import argparse
import json
from pathlib import Path
import time
from playwright.sync_api import sync_playwright

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--url', required=True)
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
args.out.mkdir(parents=True, exist_ok=False)
report = {'valid': False, 'transitions': [], 'errors': [], 'console': [], 'network': []}
requests = {}
started = time.monotonic()
def requested(request):
    row = {'url': request.url, 'method': request.method, 'type': request.resource_type,
           'started': round(time.monotonic() - started, 3)}
    requests[request] = row
    report['network'].append(row)
def responded(response):
    if response.request in requests:
        requests[response.request].update(status=response.status,
            received=round(time.monotonic() - started, 3))
def finished(request):
    if request in requests:
        requests[request]['finished'] = round(time.monotonic() - started, 3)
def failed(request):
    if request in requests:
        requests[request]['failure'] = request.failure
ready = """() => window.graphDebug?.graph && !graphDebug.sourceBusy &&
    !graphDebug.layoutBusy && !graphDebug.geometryBusy &&
    [...document.querySelector('#analysis-view').options].some(o => o.value === 'states')"""
with sync_playwright() as driver:
    browser = driver.chromium.launch(
        executable_path='C:/Program Files/Google/Chrome/Application/chrome.exe',
        headless=True, args=['--enable-unsafe-swiftshader',
            f'--log-net-log={args.out.resolve() / "netlog.json"}'])
    page = browser.new_page(viewport={'width': 1600, 'height': 1100})
    page.on('pageerror', lambda e: report['errors'].append(str(e)))
    page.on('request', requested)
    page.on('response', responded)
    page.on('requestfinished', finished)
    page.on('requestfailed', failed)
    page.on('console', lambda message: report['console'].append({'type':message.type,'text':message.text}))
    try:
        page.goto(args.url, wait_until='domcontentloaded')
        page.wait_for_function(ready, timeout=60000)
        for round_id in range(3):
            for locale in ('en', 'zh-CN'):
                started = time.monotonic()
                if page.locator('#language').input_value() != locale:
                    # Wait for the new document, not a matching URL still paired
                    # with the previous page's graphDebug and view options.
                    with page.expect_navigation(wait_until='domcontentloaded'):
                        page.select_option('#language', locale)
                else:
                    page.reload(wait_until='domcontentloaded')
                page.wait_for_function(ready, timeout=60000)
                assert page.locator('#language').input_value() == locale
                page.select_option('#analysis-view', 'states')
                page.wait_for_function(ready, timeout=60000)
                page.click('#collapse')
                page.click('#fit')
                page.wait_for_function(ready, timeout=60000)
                graph = page.evaluate("""() => ({
                    nodes:graphDebug.displayGraph.boxes.map(n=>n.id).sort(),
                    mode:document.querySelector('#layered-toggle').textContent,
                    flags:[graphDebug.sourceBusy,graphDebug.layoutBusy,graphDebug.geometryBusy]})""")
                assert len(graph['nodes']) > 0
                report['transitions'].append({'round':round_id,'locale':locale,
                    'elapsed_seconds':round(time.monotonic()-started,3),**graph})
                page.screenshot(path=str(args.out/f'{round_id}-{locale}.png'))
                page.click('#layered-toggle')
                page.wait_for_function(ready, timeout=60000)
        assert not report['errors'], report['errors']
        report['valid'] = True
    except Exception as exc:
        report['failure'] = str(exc)
        report['pending'] = [row for row in report['network']
                             if 'finished' not in row and 'failure' not in row]
        report['failure_ui'] = page.evaluate("""() => ({url:location.href,
            readyState:document.readyState,
            scripts:[...document.scripts].map(s=>({src:s.src,type:s.type})),
            sourceBusy:window.graphDebug?.sourceBusy,layoutBusy:window.graphDebug?.layoutBusy,
            geometryBusy:window.graphDebug?.geometryBusy,
            connection:document.querySelector('#connection')?.textContent})""")
        page.screenshot(path=str(args.out/'failure.png'))
    finally:
        browser.close()
(args.out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'valid':report['valid'],'transitions':len(report['transitions']),'failure':report.get('failure')}))
raise SystemExit(not report['valid'])
