"""Retain actual module/network startup evidence without replacing responses."""
import argparse
import json
from pathlib import Path
import time
from playwright.sync_api import sync_playwright

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--url', required=True)
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
args.out.mkdir(parents=True, exist_ok=False)
report = {'requests': [], 'console': [], 'errors': [], 'samples': []}
requests = {}
started = time.monotonic()
def requested(request):
    row = {'url': request.url, 'method': request.method, 'type': request.resource_type,
           'start': round(time.monotonic()-started,3)}
    requests[request] = row
    report['requests'].append(row)
def responded(response):
    row = requests.get(response.request)
    if row is not None:
        row.update(status=response.status, received=round(time.monotonic()-started,3))
def finished(request):
    if request in requests:
        requests[request]['finished'] = round(time.monotonic()-started,3)
def failed(request):
    if request in requests:
        requests[request]['failure'] = request.failure
with sync_playwright() as driver:
    browser = driver.chromium.launch(executable_path='C:/Program Files/Google/Chrome/Application/chrome.exe',
        headless=True,args=['--enable-unsafe-swiftshader'])
    page = browser.new_page(viewport={'width':1600,'height':1100})
    page.on('request', requested)
    page.on('response', responded)
    page.on('requestfinished', finished)
    page.on('requestfailed', failed)
    page.on('console', lambda msg: report['console'].append({'type':msg.type,'text':msg.text}))
    page.on('pageerror', lambda error: report['errors'].append(str(error)))
    try:
        page.goto(args.url,wait_until='domcontentloaded')
        for _ in range(12):
            page.wait_for_timeout(5000)
            report['samples'].append(page.evaluate("""() => ({
                clock:performance.now(), document:document.readyState,
                graph:!!window.graphDebug?.graph,
                sourceBusy:window.graphDebug?.sourceBusy,
                layoutBusy:window.graphDebug?.layoutBusy,
                geometryBusy:window.graphDebug?.geometryBusy,
                connection:document.querySelector('#connection')?.textContent,
                scripts:[...document.scripts].map(s=>({src:s.src,type:s.type})),
                resources:performance.getEntriesByType('resource').map(r=>({name:r.name,duration:r.duration}))
            })"""))
            if report['samples'][-1]['graph']:
                break
        page.screenshot(path=str(args.out/'startup.png'))
    except Exception as error:
        report['failure'] = str(error)
    report['pending'] = [r for r in report['requests'] if 'finished' not in r and 'failure' not in r]
    browser.close()
(args.out/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'graph':report['samples'][-1].get('graph') if report['samples'] else False,
                  'console':report['console'],'errors':report['errors'],'pending':report['pending']}))
