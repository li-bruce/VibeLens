"""Compare the exact version inputs used by the live recording selector."""
import json
from pathlib import Path
from urllib.request import urlopen

base='http://127.0.0.1:8926'
def read(path):
    with urlopen(base+path,timeout=30) as response:
        return json.load(response)
live=read('/api/view')
saved=read('/api/recordings/a76db4361e4a4005934ae6f5e282e122')
def identity(view):
    return {'build':view['manifest']['build_id'],'model_hash':view['manifest'].get('model_hash'),
        'api_revision':view.get('api_structure',{}).get('revision'),
        'concept_revision':view.get('concept_structure',{}).get('revision')}
report={'live':identity(live),'recorded':identity(saved['context']),
    'recorded_keys':list(saved['context'])}
for key in ('api_structure','concept_structure'):
    a,b=live.get(key),saved['context'].get(key)
    report[key]={'live_keys':list(a or {}),'recorded_keys':list(b or {}),'equal':a==b}
def differences(a,b,path=''):
    if type(a) is not type(b):
        return [{'path':path,'live_type':type(a).__name__,'recorded_type':type(b).__name__}]
    if isinstance(a,dict):
        return [d for key in sorted(set(a)|set(b)) for d in differences(a.get(key),b.get(key),path+'/'+key)]
    if isinstance(a,list):
        result=[] if len(a)==len(b) else [{'path':path,'lengths':[len(a),len(b)]}]
        return result+[d for i,(left,right) in enumerate(zip(a,b)) for d in differences(left,right,path+'/'+str(i))]
    if a!=b:
        return [{'path':path,'live':str(a)[:180],'recorded':str(b)[:180]}]
    return []
report['api_differences']=differences(live['api_structure'],saved['context']['api_structure'])
out=Path('.validation/p7-native-ui/node-repair19-recording-diagnostic/version-comparison.json')
out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report))
