"""Diagnose the real recording selector, retaining UI errors and identities."""
import json
from pathlib import Path
from playwright.sync_api import sync_playwright

root = Path.cwd()
out = root / '.validation/p7-native-ui/node-repair19-recording-diagnostic'
out.mkdir(exist_ok=False)
report = {'responses':[], 'console':[], 'page_errors':[]}
with sync_playwright() as driver:
    browser = driver.chromium.launch(executable_path='C:/Program Files/Google/Chrome/Application/chrome.exe',
        headless=True,args=['--enable-unsafe-swiftshader'])
    page = browser.new_page(viewport={'width':1600,'height':1050})
    page.on('pageerror',lambda error: report['page_errors'].append(str(error)))
    page.on('console',lambda message: report['console'].append({'type':message.type,'text':message.text[:500]}) if message.type=='error' else None)
    page.on('response',lambda response:report['responses'].append({'url':response.url.split('?')[0], 'status':response.status}) if '/recording' in response.url or response.status>=400 else None)
    page.goto('http://127.0.0.1:8926/graph?lang=zh-CN',wait_until='domcontentloaded')
    recording='a76db4361e4a4005934ae6f5e282e122'
    page.wait_for_function('id => [...document.querySelector("#record-list").options].some(o=>o.value===id)',arg=recording,timeout=60000)
    initial=page.locator('#record-status').inner_text()
    page.select_option('#record-list',recording)
    try:
        page.wait_for_function('([id, initial]) => graphDebug.view?.replay?.id===id || document.querySelector("#record-status").textContent!==initial',arg=[recording,initial],timeout=60000)
    except Exception as error:
        report['wait_error']=str(error)
    report['ui']=page.evaluate('''() => ({status:document.querySelector('#record-status').textContent,
        selected:document.querySelector('#record-list').value,
        replay:graphDebug.view?.replay,
        build:graphDebug.view?.manifest?.build_id,
        stateNodes:graphDebug.view?.model?.nodes?.filter(n=>n.kind==='state' && n.value==='inactive').map(n=>({id:n.id,label:n.label,concept_id:n.concept_id,explained_name:n.explained_name}))})''')
    page.screenshot(path=str(out/'recording-selection.png'))
    browser.close()
(out/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
