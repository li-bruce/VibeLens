# Ordinary recording failed: diagnostic handoff

The new application build did not complete its ordinary recording gate. Stop at preserved evidence and shared-framework diagnosis as explicitly directed by the coordinator. No retry, accept, installed-provider change, source-only refactor, queue/deadline increase, or field/assertion reduction followed this failure. No normal services or fresh live history were started. Post-browser full verification and independent 2D/3D/Timeline acceptance remain unperformed for this build.

Candidate: `f54ad18b76b30f5557e781397827ce9e1c8ff56ab337785b32785d5829d32a3f`. Build: `82c63ac015aa3550e7940c9d29c91ba240510323beb4d127ea9c0a207a02695c`. Immutable provider commit: `b8bdff26f5750a6e102356a755c35e22ebb1ea09`. Root: `C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.validation\p7-trials\node-retest-app`.

The prior build `fe0c2cb26352d5e62e10c5b307bcd86d48ec17b07a5b721aee449648dcd46695` retains its stopped 1850/7338-event recordings and its failed postverify(two naming-derived errors). They do not apply to the new build. The exact generated-log artifact classification and two obsolete product-copy fixes produced the new build. All real source/readers/tests remain; only `var/native-order.jsonl` left source inventory. No business logic or observation logic changed in this repair.

| Gate/evidence | Actual result |
|---|---|
| Isolated and actual native SQLite migration | Complete; every original row preserved in six tables |
| Current native verification | All 5 unchanged commands exited 0;15 native scenarios; only19 missing browser/UI gates before this browser run |
| Browser on/off/fault and share/revoke-repeat/editor/board checks | All actual business flags true; independent SQL/prepared/repeated-download bytes match |
| Recording `2319c8271138467a8a61228d5a4473ae` | stopped; 1962 events; gaps empty;target/completed 2003; pending 0 |
| Recording `60272dedcbca4a97a96d17d147379584` | interrupted; 1314 events; two explicit gaps;aggregate target 9789/completed 3320/pending 6469 |
| Entire ordinary workflow | Failed at original 35-second pre-Stop pending-zero gate |

The failure occurred after user `editor`(叶青) deleted the synthetic announcement and returned to Team files. `browser-failure.jpg` shows the announcement-deleted notice and 0 accessible files. The observer remained on its saved business-flow 3D view with Chinese semantic names, live observation and recording active; selected node `upload_file`. These are UI positions, not a claim that the last retained event was the currently executing business operation.

Queue evidence is in `queue-boundary-evidence.json`. The 35-second idle window begins at native submitted 9703/completed 2017/pending 7686/errors 0/retries 5. The first observed terminal transport error increments completed 2017→2018 and errors 0→1. At the gate's last sample: completed 2306/pending 7397/errors 1/retries 19. Submitted stays 9703 throughout; progress continues but does not settle. Pre-cleanup native health later shows completed 3234/pending 6469/retries 21, last error `TimeoutError`, dropped 0, no open spans/data/order/control errors.

The sender's queue ordinal 2018 is the first observed terminal failure position, not a `source_seq`, exact request body or successful ACK. The SDK increments `completed` even after a failed single-envelope transport in `bo_runtime.mjs`'s `bo_deliver` finally block. No per-fetch audit was enabled, so the exact first timed-out envelope ID/type and last successful event-ingress HTTP receipt cannot be recovered. The last retained native event in the failed record has source_seq 3223, viewer seq 3309, node `policy:is_owner`, phase `decision`, id `1c5cc1ab-c39d-4d01-b224-86ef45030b88:8f2b0acd-c000-4481-bf69-74d5aa54cd54:3223`. Its native prefix 1984..3223 is contiguous, which does not prove delivery of the pending tail. Snapshot/queue/aggregate counters are not converted into event-loss ratios.

The last retained recording-control response is an actual HTTP 200 from exception-cleanup Stop after 6011.51 ms, with body status `interrupted`; this is not an event-ingress ACK or recording success. Its exact body and hash remain in the run directory. Aggregate record-final producer health includes both native (errors 1, retries 19, pending 6469) and browser (errors 1, retries 14, pending 0); these samples precede pre-cleanup native retries 21 and must not be merged as one timestamp.

Evidence directory: `C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.validation\p7-trials\node-retest-app\review\runtime\unified-1795230023`.

| Requested evidence | Exact relative file under that directory |
|---|---|
| Failed recording export | `failed-recording-60272dedcbca4a97a96d17d147379584.json` |
| Actual managed recording | `C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.validation\p7-trials\node-retest-app\bo_stategraph\data\recordings\60272dedcbca4a97a96d17d147379584.json` |
| First stopped recording | `independent-recording-2319c8271138467a8a61228d5a4473ae.json` |
| Native health samples | `native-idle.jsonl`, `native-idle-summary.json` |
| Browser business/ordinary-order/failure state | `artifacts/browser-acceptance.json`, `browser-failure-1795230223.json` |
| Browser and SDK mode evidence | `artifacts/browser-ui-on.json`, `artifacts/browser-run-on.json`, `artifacts/browser-run-off.json`, `artifacts/browser-run-fault.json` |
| Native SDK stdout/stderr | `app.stdout.log`(34 bytes), `app.stderr.log`(0 bytes); no per-envelope network log |
| Viewer stdout/stderr | `viewer.stdout.log`, `viewer.stderr.log`(one WinError 10054 connection reset; cause not established) |
| Trial processes | `trials.stdout.log`, `trials.stderr.log` |
| Parent lifecycle and process ownership | `lifecycle.json`; parent wrapper logs under `C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.validation\p7-trials\node-retest-app\review\runtime\settlement-runtime-20261121\ordinary-browser-copy.stdout.log` and adjacent stderr/command receipt |
| Stop HTTP receipts/bodies | `artifacts/browser-stop-receipts.json`, `stop-receipt-60272dedcbca4a97a96d17d147379584-exception-cleanup.body` |
| System load | `system-load.jsonl`(71 samples: 6.25..34.45%, median 14.84%); no injected load/profile/stack/timing instrumentation |
| Page screenshots | `browser-failure.jpg`, `graph-failure.jpg`, `artifacts/gui-after-revoke-repeat.jpg`, `artifacts/gui-announcement-edited.jpg` |

The parent 38956, viewer 44804, app 30896 and trials 25860 have exited, verified by Get-Process. Child exit 1 values are expected owned-parent taskkill cleanup; each child was alive before cleanup. Ports 8925/8926/8935/8936 are closed. The browser's finally close completed, but its PID was not retained by the original harness.

`ordinary-runtime-failure-seal.json` hashes the new raw run/records and affected sources/definitions. `failure-browser-database.sqlite` is the necessary current SQL copy. `failure-source/` contains only affected source/definitions. The old 1.2 GB `before-runtime-evidence.zip` is unchanged, hash `9cf5f861ead80425a8017ca7c069ac0c26757a28893bc5ac2f34d46f35d41232`, referenced rather than recursively included. No new ZIP or dependency/old-archive copy was created.

Preservation: 2779 installed provider files remain exact; 27 pre-existing protected raw records remain exact; all 568 original fields,230 literal assertion lines, old node IDs, baseline and initial accepted receipt remain. All original six-table rows and the original native-order log byte prefix remain. Preferences were not restored: approved revision 168→181 differences remain, followed by revision 181→188 with only 4 tiny camera-coordinate differences; all node positions, pins, annotations, names and view identities are identical. Exact values are in `final-personal-view-preservation.json`.

This evidence establishes an ordinary producer transport/settlement failure. It does not identify the exact receiver hotspot or prove a root cause. Shared-framework investigation remains with the main repository. Prepared success-only sealing/audit/live-launch helpers were not executed. No acceptance receipt was written.
