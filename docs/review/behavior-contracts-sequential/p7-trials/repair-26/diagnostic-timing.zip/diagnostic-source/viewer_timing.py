"""Time seven selected methods and HTTP dispatch in an opt-in diagnostic process."""
import atexit
from contextvars import ContextVar
from functools import wraps
from itertools import count
import json
import os
from pathlib import Path
from queue import SimpleQueue
import runpy
import sys
import threading
import time
from urllib.parse import urlsplit


class TimingRecorder:
    """Move serialization and file writes off the original request threads."""

    def __init__(self, destination):
        self.destination = Path(destination)
        self.events = SimpleQueue()
        self.sequence = count(1)
        self.http = ContextVar('project_viewer_timing_http', default=None)
        self.calls = ContextVar('project_viewer_timing_calls', default=())
        self.thread = None
        self.lost = 0

    def emit(self, event):
        """Keep diagnostic queue errors outside the original call's outcome."""
        try:
            self.events.put({'wall_ms': time.time_ns()/1e6, 'pid': os.getpid(),
                'thread_id': threading.get_ident(), 'thread_name': threading.current_thread().name, **event})
        except Exception:
            self.lost += 1

    def write(self):
        """Write queued primitive metadata; never inspect application arguments."""
        with self.destination.open('w', encoding='utf-8', buffering=1) as stream:
            while True:
                event = self.events.get()
                if event is None:
                    break
                stream.write(json.dumps(event, ensure_ascii=False, allow_nan=False)+'\n')

    def start(self):
        """Start one independent writer for this diagnostic process only."""
        self.thread = threading.Thread(target=self.write, name='bo-method-timing-writer', daemon=True)
        self.thread.start()

    def close(self):
        """Drain normal shutdown; forced parent cleanup can leave partial pairs."""
        self.events.put(None)
        if self.thread:
            self.thread.join(timeout=2)

    def wrap(self, original, method):
        """Call the original once, preserving its return object and exception."""
        @wraps(original)
        def timed(*args, **kwargs):
            identity = next(self.sequence)
            parents = self.calls.get()
            request = self.http.get()
            common = {'method': method, 'call_id': identity,
                'parent_call_id': parents[-1] if parents else None,
                'http': dict(request) if request else None}
            self.emit({'event': 'method_start', **common})
            token = self.calls.set(parents+(identity,))
            started = time.perf_counter_ns()
            exception = None
            try:
                return original(*args, **kwargs)
            except BaseException as error:
                exception = type(error).__name__
                raise
            finally:
                elapsed = (time.perf_counter_ns()-started)/1e6
                self.calls.reset(token)
                self.emit({'event': 'method_end', **common, 'elapsed_ms': elapsed, 'exception_type': exception})
        return timed


def trace_http_handler(handler_class, recorder):
    """Trace only the installed server's dispatch, without reading its body again."""
    original_reply = handler_class.reply

    @wraps(original_reply)
    def reply(handler, code, *args, **kwargs):
        request = recorder.http.get()
        if request is not None:
            request['status'] = code if type(code) is int else None
        return original_reply(handler, code, *args, **kwargs)

    handler_class.reply = reply
    for name in ['do_GET', 'do_POST', 'do_OPTIONS']:
        original = getattr(handler_class, name)

        def dispatch(original):
            @wraps(original)
            def request(handler, *args, **kwargs):
                try:
                    ordinal = getattr(handler, '_project_timing_ordinal', 0)+1
                    handler._project_timing_ordinal = ordinal
                    state = {'request_id': next(recorder.sequence), 'method': handler.command,
                        'path': urlsplit(handler.path).path, 'peer_address': handler.client_address[0],
                        'peer_port': handler.client_address[1], 'server_port': handler.server.server_port,
                        'connection_request_index': ordinal, 'status': None}
                except Exception as error:
                    recorder.emit({'event': 'http_metadata_error', 'exception_type': type(error).__name__})
                    return original(handler, *args, **kwargs)
                token = recorder.http.set(state)
                recorder.emit({'event': 'http_start', 'http': dict(state)})
                started = time.perf_counter_ns()
                exception = None
                try:
                    return original(handler, *args, **kwargs)
                except BaseException as error:
                    exception = type(error).__name__
                    raise
                finally:
                    elapsed = (time.perf_counter_ns()-started)/1e6
                    recorder.emit({'event': 'http_end', 'http': dict(state), 'elapsed_ms': elapsed, 'exception_type': exception})
                    recorder.http.reset(token)
            return request

        setattr(handler_class, name, dispatch(original))


def install_timing(recorder):
    """Patch only selected call sites in memory; installed source files stay untouched."""
    from bo_observer import protocol

    original_validate = protocol.validate_project
    timed_validate = recorder.wrap(original_validate, 'protocol.validate_project')
    protocol.validate_project = timed_validate

    from bo_observer.observation.session import GraphSession
    from bo_observer.observation.event_batch import BOSessionSink
    from bo_observer.data.watcher import DataWatch
    from bo_observer import service

    # Imports can retain a preexisting alias. Replace only aliases of the same
    # authorized function, not other validators or arbitrary module functions.
    aliases = []
    for name, module in list(sys.modules.items()):
        if name.startswith('bo_observer.') and module is not None:
            for key, value in list(vars(module).items()):
                if value is original_validate:
                    setattr(module, key, timed_validate)
                    aliases.append(name+'.'+key)
    targets = [(GraphSession, name) for name in ['binding', '_view_model', 'view', 'snapshot']]
    targets += [(BOSessionSink, 'bo_accept_many'), (DataWatch, 'tick')]
    from bo_observer.observation.recording_session import Recordings
    targets += [(Recordings, name) for name in ['_capture', '_save', '_write', 'get', 'list']]
    methods = ['protocol.validate_project']
    for owner, name in targets:
        method = owner.__name__+'.'+name
        setattr(owner, name, recorder.wrap(getattr(owner, name), method))
        methods.append(method)

    original_factory = service.make_server

    @wraps(original_factory)
    def make_server(*args, **kwargs):
        server = original_factory(*args, **kwargs)
        trace_http_handler(server.RequestHandlerClass, recorder)
        return server

    service.make_server = make_server
    recorder.emit({'event': 'timing_installed', 'methods': methods, 'validate_project_aliases': aliases,
        'http_hooks': ['do_GET', 'do_POST', 'do_OPTIONS', 'reply'],
        'transport_join': 'client local port == server peer port, server port and connection request index; require a unique match',
        'line_profiler': False, 'locks_replaced': False, 'headers_or_bodies_changed': False})


def main():
    """Run the same installed CLI after the requested diagnostic hooks are ready."""
    root = Path(__file__).resolve().parents[1]
    skill = Path(os.environ['VIBELENS_SKILL'])
    entry = skill/'scripts/bo.py'
    sys.path.insert(0, str(entry.parent))
    recorder = TimingRecorder(os.environ['BO_VIEWER_TIMING'])
    recorder.start()
    atexit.register(recorder.close)
    install_timing(recorder)
    recorder.emit({'event': 'entrypoint', 'path': str(entry), 'diagnostic_only': True})
    sys.argv = [str(entry), 'serve', '--root', str(root), '--port', '8926', '--origin', 'http://127.0.0.1:8925']
    runpy.run_path(str(entry), run_name='__main__')


if __name__ == '__main__':
    main()
