"""Collect independent desktop findings on an unchanged trial candidate.

This is a discovery pass, not native acceptance. The observer alone is started;
no business producer or recording is started. Existing failed recordings remain
failed. Suites continue independently, retaining all of their original checks.
"""

import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT / '.validation/p7-trials/node-retest-app'
PROVIDER = ROOT / '.validation/p7-trials/recording-copy-skills/vibelens'
OUT = ROOT / '.validation/p7-trials/desktop-discovery-20261121-host'
OUT.mkdir(exist_ok=False)
URL = 'http://127.0.0.1:8926'
RECORD = '380df57764ce4038b1e20cd1c7ca7ad2'
BUILD = '150b7a8c49d72b8debd3022d464f516601b471bebd02bd7cc93590cd715c258b'


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def hashes():
    project = json.loads((PROJECT / 'bo_stategraph/project.json').read_text(encoding='utf-8'))
    paths = {PROJECT / name for name in project['model']['source_files']}
    paths.add(PROJECT / 'bo_stategraph/project.json')
    paths.update((PROJECT / 'bo_stategraph/data/recordings').glob('*.json'))
    paths.update((PROJECT / 'var/db').glob('*'))
    return {path.relative_to(PROJECT).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(paths) if path.is_file()}


def fetch(path):
    with urllib.request.urlopen(URL + path, timeout=30) as response:
        return json.load(response)


def run(name, script, options):
    command = [sys.executable, '-B', '-X', 'utf8', str(ROOT / script), *options]
    started = time.monotonic()
    with (OUT / (name + '.stdout.log')).open('x', encoding='utf-8') as stdout, \
         (OUT / (name + '.stderr.log')).open('x', encoding='utf-8') as stderr:
        try:
            completed = subprocess.run(command, cwd=ROOT, stdout=stdout, stderr=stderr, timeout=600)
            result = {'exit_code': completed.returncode}
        except subprocess.TimeoutExpired:
            result = {'exit_code': None, 'timeout_seconds': 600}
    result.update(name=name, command=command, seconds=round(time.monotonic()-started, 3))
    print(json.dumps(result), flush=True)
    return result


with socket.socket() as probe:
    assert probe.connect_ex(('127.0.0.1', 8926)) != 0, 'Observer port already in use'

before = hashes()
save('protected-before.json', before)
preferences = PROJECT / 'bo_stategraph/config/views/local.json'
save('preferences-before.json', json.loads(preferences.read_text(encoding='utf-8')) if preferences.exists() else None)
report = {'purpose': 'Issue discovery only; no native/capture acceptance',
          'recording': RECORD, 'recording_has_known_context_gaps': True, 'checks': []}
command = [sys.executable, '-B', str(PROVIDER / 'scripts/bo.py'), 'serve',
           '--root', str(PROJECT), '--port', '8926', '--origin', 'http://127.0.0.1:8925']
with (OUT / 'viewer.stdout.log').open('x', encoding='utf-8') as stdout, \
     (OUT / 'viewer.stderr.log').open('x', encoding='utf-8') as stderr:
    server = subprocess.Popen(command, cwd=PROJECT, stdout=stdout, stderr=stderr,
                              env={**os.environ, 'TEAM_FILES_SQLITE_URL': 'sqlite:///var/db/application.sqlite',
                                   'VIBELENS_SKILL': str(PROVIDER), 'PYTHONDONTWRITEBYTECODE': '1',
                                   'PYTHONIOENCODING': 'utf-8'},
                              creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    report['server'] = {'pid': server.pid, 'command': command}
    save('report.json', report)
    try:
        deadline = time.monotonic() + 60
        while True:
            assert server.poll() is None, 'Owned observer process exited during startup'
            try:
                view = fetch('/api/view')
                break
            except OSError:
                if time.monotonic() > deadline:
                    raise
                time.sleep(.2)
        assert view['manifest']['build_id'] == BUILD, view['manifest']['build_id']
        catalog = fetch('/api/recordings')
        assert not catalog.get('active'), 'A recording is active'
        save('catalog-before.json', catalog)
        report['binding_status'] = view['binding_status']
        tasks = [
            ('readiness', '.validation/test_native_readiness.py', []),
            ('layers', 'tools/test_trial_views_browser.py',
             ['--browser', 'C:/Program Files/Google/Chrome/Application/chrome.exe']),
            ('timeline', '.validation/test_native_timeline.py', ['--recording', RECORD]),
            ('arrows', '.validation/test_native_arrows.py', ['--recording', RECORD]),
            ('controls', '.validation/test_native_controls.py',
             ['--database', str(PROJECT / 'var/db/application.sqlite')]),
            ('captions', '.validation/review_trial_captions.py',
             ['--project', str(PROJECT), '--spec', str(ROOT / '.validation/node-iteration-caption-spec.json')]),
        ]
        for name, script, options in tasks:
            report['checks'].append(run(name, script,
                ['--url', URL+'/graph?lang=zh-CN', '--out', str(OUT / name), *options]))
            save('report.json', report)
        save('catalog-after.json', fetch('/api/recordings'))
    except Exception as error:
        report['failure'] = str(error)
        raise
    finally:
        if server.poll() is None:
            server.terminate()
            server.wait(timeout=30)
        report['server']['exit_code_after_owned_cleanup'] = server.returncode
        after = hashes()
        save('protected-after.json', after)
        report['protected_changes'] = [key for key in sorted(before.keys() | after.keys())
                                       if before.get(key) != after.get(key)]
        save('preferences-after.json', json.loads(preferences.read_text(encoding='utf-8')) if preferences.exists() else None)
        save('report.json', report)
        assert not report['protected_changes'], report['protected_changes']
