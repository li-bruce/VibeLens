"""Export the unchanged discovery evidence; do not create acceptance receipts."""

from collections import Counter
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]
TRIAL = ROOT / '.validation/p7-trials/node-retest-app'
NATIVE = TRIAL / 'review/runtime/unified-1795263116'
HANDOFF = TRIAL / 'review/runtime/recording-copy-runtime-20261121'
DESKTOP = ROOT / '.validation/p7-trials/desktop-discovery-20261121-host'
OUT = ROOT / 'docs/review/behavior-contracts-sequential/p7-trials/discovery-round-27'
OUT.mkdir(exist_ok=False)


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def digest(data):
    return hashlib.sha256(data).hexdigest()


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


selected = {}
for path in NATIVE.iterdir():
    if path.is_file():
        selected['native/' + path.name] = path
handoff_names = [
    'HANDOFF_FAILURE.md', 'issues.json', 'retention-failure-seal.json',
    'retention-gap-proof.json', 'read-only-own-interval-closure.json',
    'provider-owned-verification.json', 'parser-dependency-installation.json',
    'integration-plan.json', 'integration-apply.json', 'integration-check.json',
    'static-upgrade-preservation.json', 'managed-upgrade-hashes.json',
    'final-old-sql-row-preservation.json', 'final-native-order-prefix-preservation.json',
    'final-personal-view-preservation.json', 'actual-bob-sql-and-bytes.json',
    'pending-browser-evidence-proof.json', 'ordinary-browser-recording-command.json',
    'ordinary-browser-recording.stdout.log', 'ordinary-browser-recording.stderr.log',
    'ordinary-browser-start.json', 'code-scan-provider26.json',
    'code-scan-provider26-with-dependencies.json',
]
for name in handoff_names:
    selected['handoff/' + name] = HANDOFF / name
for path in DESKTOP.rglob('*'):
    if path.is_file():
        selected['desktop/' + path.relative_to(DESKTOP).as_posix()] = path
for attempt in ('desktop-discovery-20261121', 'desktop-discovery-20261121-configured'):
    directory = ROOT / '.validation/p7-trials' / attempt
    for name in ('report.json', 'viewer.stdout.log', 'viewer.stderr.log'):
        selected['setup/' + attempt + '/' + name] = directory / name
for name in ('discover_p7_desktop.py', 'test_native_readiness.py', 'test_native_timeline.py',
             'test_native_arrows.py', 'test_native_controls.py', 'review_trial_captions.py',
             'node-iteration-caption-spec.json', 'export_discovery27.py'):
    selected['review-scripts/' + name] = ROOT / '.validation' / name
selected['review-scripts/test_trial_views_browser.py'] = ROOT / 'tools/test_trial_views_browser.py'

recordings = []
project = read(TRIAL / 'bo_stategraph/project.json')
model = project['model']
discovery = read(TRIAL / 'discovery.json')
declared = {row['id']: row for row in discovery['state_models']}
for identity in ('5e4c8036b5a4428aaba2266820113d94', '380df57764ce4038b1e20cd1c7ca7ad2'):
    original = TRIAL / 'bo_stategraph/data/recordings' / (identity + '.json')
    selected['persisted/' + original.name] = original
    record = read(original)
    frames = record['runtime_frames']['frames']
    seen = Counter(frame.get('machine', {}).get('state_model_id') for frame in frames)
    event_nodes = Counter(event['node'] for event in record['events'])
    recordings.append({
        'id': identity, 'sha256': digest(original.read_bytes()),
        'status': record['status'], 'build_id': record['build_id'],
        'interval_events': len(record['events']), 'context_events': len(record['context']['events']),
        'start_seq': record['start_seq'], 'end_seq': record['end_seq'],
        'gaps': record['gaps'], 'ownership_gaps': len(record.get('ownership_gaps', [])),
        'observed_nodes': len(event_nodes), 'frames_by_state_model': dict(seen),
        'models_without_frames_in_this_record': sorted(set(model['machines']) - set(seen)),
        'meaning': 'Recorded frame presence is not complete transition or business coverage.',
    })

scope = {
    'project_id': project['project_id'], 'mode': project['selection']['mode'],
    'model_revision': model['revision'],
    'declared_networks': [{'id': row['id'], 'nodes': len(row['nodes'])} for row in discovery['networks']],
    'state_registry_ids_match': set(declared) == set(model['machines']) == set(model['concepts']['state_models']),
    'state_models': {identity: {
        'declared_states': declared[identity]['states'], 'bound_states': chart['states'],
        'states_match': declared[identity]['states'] == chart['states'],
        'initial_match': declared[identity]['initial'] == chart['initial'],
        'declared_transitions': len(declared[identity]['transitions']),
        'bound_transitions': len(chart['transitions']),
    } for identity, chart in model['machines'].items()},
    'records': recordings,
    'scope': 'Read-only identity inventory on Node candidate; not a full semantic or coverage validator.',
}
save('model-recording-inventory.json', scope)

manifest = []
archive = OUT / 'discovery-evidence.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for name, path in sorted(selected.items()):
        data = path.read_bytes()
        bundle.writestr(name, data)
        manifest.append({'member': name, 'bytes': len(data), 'sha256': digest(data)})
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    for row in manifest:
        assert digest(bundle.read(row['member'])) == row['sha256']
save('archive-index.json', {'archive': archive.name, 'bytes': archive.stat().st_size,
                          'sha256': digest(archive.read_bytes()), 'members': manifest})

raw = read(DESKTOP / 'report.json')
captions = read(DESKTOP / 'captions/result.json')
timeline = read(DESKTOP / 'timeline/result.json')
controls = read(DESKTOP / 'controls/result.json')
results = {
    'phase': 'P7', 'phase_status': 'in_progress', 'batch_stage': 'discovery',
    'provider_commit': 'df6bba9d2a71048d234c1fa4f2858a6a8b468bd1',
    'framework_source_changed': False, 'new_dialogues_created': 0,
    'new_business_or_recording_runs_in_root_discovery': 0,
    'complete_acceptance': False,
    'desktop': [{'name': row['name'], 'exit_code': row['exit_code'], 'seconds': row['seconds']}
                for row in raw['checks']],
    'timeline': {'passed_checks': timeline['checks'],
                 'positive_business_lifetimes': len(timeline['business_lifetimes']),
                 'visible_causal_routes': len(timeline['visible_routes'])},
    'captions': {'passed_cases': len(captions['checks']), 'source_navigation': 'pending',
                 'failure': captions['failure'], 'classification': 'reviewer search disambiguation assumption'},
    'controls': {'status': 'pending_native_history_precondition', 'failure': controls['failure']},
    'source_database_and_recordings_changed': raw['protected_changes'],
    'personal_view_edits': 'Ordinary UI actions; retained, not restored.',
    'recording_context_defect': 'open',
    'remaining': ['Batch recording-context repair and its focused regressions',
                  'Complete native controls and source navigation after reviewer preparation',
                  'Python provider-maintenance complete native acceptance',
                  'Node source-only announcement refactor and final full acceptance',
                  'Accepted product scenes, A24-A34 final review'],
}
save('results.json', results)
shots = OUT / 'screenshots'
shots.mkdir()
for name in ('layers/business-2D.png', 'layers/rules-2D-expanded.png',
             'layers/states-3D-expanded.png', 'timeline/timeline-causal-links.png',
             'arrows/arrows-2D.png', 'arrows/arrows-3D.png'):
    shutil.copy2(DESKTOP / name, shots / name.replace('/', '-'))
print(json.dumps({'archive_bytes': archive.stat().st_size, 'members': len(manifest),
                  'state_registry_ids_match': scope['state_registry_ids_match'],
                  'records': [(r['id'], r['frames_by_state_model']) for r in recordings]}))
