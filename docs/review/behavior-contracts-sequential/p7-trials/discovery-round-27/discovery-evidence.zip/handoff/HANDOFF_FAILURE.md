# Repair26 frozen recording-gap diagnostic handoff

This attempt is **not a complete acceptance pass**. The six registered commands exited 0 and fifteen native observation scenarios completed before the browser gate. The only pre-browser mapping gaps were the three not-yet-produced real browser modes and their UI fields; protected 18 case×mode plan versus actual 15 was retained unchanged in pending-browser-evidence-proof.json.

The original ordinary real-server run completed all on/off/fault business comparisons, upload/share, Bob's owner-control absence assertion at browser_acceptance.py:227, ready-before-revoke/repeat collection, editor isolation and independent announcement operations. It then failed the unchanged gaps assertion on its second stopped recording. No retry, gap/assertion change, retention/queue/deadline increase, history clearing, accept or announcement refactor followed.

Candidate `93dbc580b867cf4c57568e0ce858d4bfc9a27b8e6eb230c2def14a1705c4cdda`; build `150b7a8c49d72b8debd3022d464f516601b471bebd02bd7cc93590cd715c258b`; independent provider commit `df6bba9d2a71048d234c1fa4f2858a6a8b468bd1`. The provider selection changed the candidate/tool fingerprints; managed JavaScript adapters were already identical and the frontend source build stayed the same. Canonical plan/apply/check and all four before/after managed hashes are saved. The initial missing-typescript scan failure is retained; documented locked npm ci installed only generated node_modules and all 466 maintained file hashes remained exact.

| Recording | Control status | Events | Gaps | Aggregate producer prefix |
|---|---|---:|---|---|
| 5e4c8036b5a4428aaba2266820113d94 | stopped | 2066 | none | submitted/completed 2107, pending 0,flushed |
| 380df57764ce4038b1e20cd1c7ca7ad2 | stopped | 8178 | pre-context 2000 limit and missing parent entry | submitted/completed 10317, pending 0,flushed |

Both actual Stop requests returned HTTP 200; raw bodies and receipt timestamps/hashes are retained. A stopped status and HTTP 200do not clear the second record's gaps. Native pre-cleanup health was submitted/completed 10231, pending 0, errors 0, dropped 0, retries 0, open_spans 0, data/order/control_errors 0. Both final producer details also have no errors,drops,retries,pending or open spans. No Windows 10048 was observed in this attempt; prior diagnostic copies are not counted as this attempt's pass.

The context proof is specific: before the second recording, live health reported 2099 retained events, evicted 0, configured memory_events 10000. Its serialized pre-context contains only 2000 events (global seq 100..2099), omitting 99. The first original recording and its initial context together still retain all 2099 pre-events. All 446 ownership-gap references are inside that truncated pre-context and point to one real parent:

- id `218db5a8-0fd4-4468-8f9e-25ac16d42f9d:fbaf0f15-c0e2-4f31-8c21-a3faff97a1ad:57`
- node/phase `list_files/enter`,global seq 67, source_seq 57
- call_id `bc47a809-d72b-45fa-85b2-b692a1945ace`

The second recording's own 8178 events are globally contiguous and have zero missing parent references. Read-only invocation closure for each own interval is shown below. This narrows the diagnostic to pre-context capture; it does not rewrite context, remove gaps or establish complete graph/Timeline acceptance. No parent event was copied into the failed original.

| Recording own interval | Closure valid | Closed calls |
|---|---|---:|
| 5e4c8036b5a4428aaba2266820113d94 | true | 467 |
| 380df57764ce4038b1e20cd1c7ca7ad2 | true | 1470 |

All services were closed at freeze. Parent 55064, viewer 51964, app 33980, trials 52232 had no matching Get-Process result. The three children were alive before expected owned_parent_cleanup and then exited 1 via taskkill; this is not a service-crash claim. The original browser finally close completed. Ports 8925/8926/8935/8936 have no listener. Historical endpoints are app `http://127.0.0.1:8925/`, observer `http://127.0.0.1:8926/graph`, off/fault trials 8935/8936. Nothing was restarted. The coordinator may separately start only the observer for read-only desktop/Timeline diagnosis using these **gapped diagnostic records**, never as capture acceptance.

Preservation completed before that desktop diagnosis: 31 older raw recordings remain byte exact; 2781 installed files(including 466 maintained files and locked generated dependencies) remain exact against the post-install baseline; application/native sources, model, required 568 fields, 230 original assertion lines,six registered commands and original 180-second case timeout are unchanged during this attempt. All 211 pre-attempt SQL rows remain identical. New rows are only this real browser run's authorized sessions/files/grant/tasks/announcement. Before and after SQLite images are preserved separately; independent Bob task/grant and prepared/source/two-repeat-download byte checks pass.

| Table | Original rows | Current rows | Missing old | Changed old |
|---|---:|---:|---:|---:|
| users | 3 | 3 | 0 | 0 |
| sessions | 120 | 129 | 0 | 0 |
| files | 33 | 35 | 0 | 0 |
| grants | 11 | 12 | 0 | 0 |
| tasks | 34 | 36 | 0 | 0 |
| announcements | 10 | 11 | 0 | 0 |

Personal views were not restored. Revision 188→198 reflects ordinary autosave; every decoded entry value, old node position, pin, annotation, custom name and view identity is identical. The pre/post raw files and comparison are retained. Later normal personal-view changes by the coordinator are authorized and must not be rolled back to manufacture equality; this audit describes the frozen point only.

Raw run directory: `C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.validation\p7-trials\node-retest-app\review\runtime\unified-1795263116`.

| Evidence | File/location |
|---|---|
| First original export | independent-recording-5e4c8036b5a4428aaba2266820113d94.json |
| Second original export | independent-recording-380df57764ce4038b1e20cd1c7ca7ad2.json |
| Actual managed originals | `C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.validation\p7-trials\node-retest-app\bo_stategraph\data\recordings` with the same IDs |
| Start context and source/model snapshot | context/sources inside each unmodified export; ordinary-browser-start.json in this handoff directory |
| Actual Stop receipts | artifacts/browser-stop-receipts.json and stop-receipt-ID-normal.body |
| Native health samples | native-idle.jsonl,native-idle-summary.json |
| Real business/order/failure result | artifacts/browser-acceptance.json,browser-failure JSON,screenshots |
| Server/SDK/trial logs | app.stdout.log,app.stderr.log,viewer.stdout.log,viewer.stderr.log,trials.stdout.log,trials.stderr.log |
| Parent/process ownership | lifecycle.json; ordinary-browser-recording-command.json/stdout.log/stderr.log in this handoff directory |
| System load | system-load.jsonl |
| Exact context-parent diagnostic | retention-gap-proof.json in this handoff directory |
| SQL and prepared-byte audit | actual-bob-sql-and-bytes.json,final-old-sql-row-preservation.json |
| Own-interval-only closure | read-only-own-interval-closure.json |
| Preference comparison | personal-views-before-ordinary.json,personal-views-after-final-browser.json,final-personal-view-preservation.json |
| Original native-order prefix | final-native-order-prefix-preservation.json |
| Complete raw/hash/stop/service seal | retention-failure-seal.json |

The necessary current SQL image is database-after-browser.sqlite; database-before.sqlite remains original. failure-source/ contains only affected source/definitions. The existing 1.2 GB archive was verified unchanged and referenced by its original path/hash; no new recursive archive or dependency copy was made. Old failures, including the prior queue-timeout recording and this context-gap recording, remain separately identifiable.

The user's current policy is to collect issues and documents first, fix the batch, then perform full/fresh-chat retests after that batch is ready. No additional business/provider edits, recording runs, full post-verify, accept or announcement split were performed here. The prepared success/live-service helpers were never executed. Current application review/verification artifacts must not be mistaken for a completed ordinary-recording pass. The handoff and issue list are diagnostic materials for the coordinated batch.
