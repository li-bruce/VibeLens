"""Isolated native replay with method timings; never final acceptance evidence."""
from functools import wraps
import hashlib
import json
import os
from pathlib import Path
import runpy
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / '.validation/p7-trials/python-retest-app'
COPY = ROOT / '.validation/p7-trials/python-capture-diagnostic-v7'
PROVIDER = ROOT / 'skills/vibelens'


def timed(owner, name, log):
    """Measure the original call without altering its arguments or result."""
    original = getattr(owner, name)

    @wraps(original)
    def call(*args, **kwargs):
        started = time.perf_counter()
        cpu_started = time.thread_time()
        error = None
        detail = {}
        if owner.__name__ == 'Handler':
            detail['path'] = args[0].path.split('?')[0]
        if name == 'bo_http_request':
            detail['kind'] = args[1]
            detail['bytes'] = len(args[2])
        if name == 'bo_accept_many':
            detail['count'] = len(args[1])
        try:
            return original(*args, **kwargs)
        except BaseException as caught:
            error = type(caught).__name__
            raise
        finally:
            row = {'method': owner.__name__ + '.' + name, 'start': started,
                   'ms': (time.perf_counter() - started) * 1000,
                   'cpu_ms': (time.thread_time() - cpu_started) * 1000,
                   'thread': threading.get_ident(), 'error': error, **detail}
            # This diagnostic adds small file-I/O overhead; it is not a benchmark.
            with log['lock']:
                log['file'].write(json.dumps(row) + '\n')
                log['file'].flush()
    setattr(owner, name, call)


def child(mode):
    """Launch the unchanged entry point after attaching observational timers."""
    sys.path.insert(0, str(PROVIDER / 'scripts'))
    sys.path.insert(0, str(COPY))
    log = {'file': (COPY / (mode + '-timings.jsonl')).open('x'), 'lock': threading.Lock()}
    if mode == 'observer':
        from bo_observer.observation.session import GraphSession
        from bo_observer.observation.event_batch import BOSessionSink
        from bo_observer.observation.recording_session import Recordings
        from bo_observer.observation.capture_bridge import CaptureBridge
        from bo_stategraph import BOStateGraph
        for owner, names in [
            (GraphSession, ['binding', 'event', 'snapshot', 'view', 'recording_view']),
            (BOSessionSink, ['bo_accept_many']),
            (Recordings, ['_capture', '_save', '_write', 'start', 'stop']),
            (CaptureBridge, ['request', 'flush']),
            (BOStateGraph, ['bo_observe', 'bo_instances']),
        ]:
            for name in names:
                timed(owner, name, log)
        import bo_observer.service as service
        original = service.make_server
        def create(*args, **kwargs):
            server = original(*args, **kwargs)
            for name in ('do_GET', 'do_POST', 'reply'):
                timed(server.RequestHandlerClass, name, log)
            return server
        service.make_server = create
        # Pin the original verified catalog for transport diagnosis. The normal
        # CLI discovers this copy's different physical database path and rightly
        # gives it a new build. No schema discovery or upgrade is claimed here.
        session = GraphSession(COPY)
        server = create(session, 8898, origins=('http://127.0.0.1:8897',))
        settings_path = COPY / '.stategraph/collector.json'
        settings = json.loads(settings_path.read_text(encoding='utf-8'))
        settings.update(endpoint='http://127.0.0.1:8898', token=server.bo_token,
                        build_id=session.manifest['build_id'])
        settings_path.write_text(json.dumps(settings, indent=2) + '\n', encoding='utf-8')
        server.serve_forever()
    else:
        from bo_observer.adapters.python.bo_probe import BOProbe
        for name in ('bo_http_request', 'flush'):
            timed(BOProbe, name, log)
        sys.argv = ['run.py', '--port', '8897']
        runpy.run_path(str(COPY / 'run.py'), run_name='__main__')


def prepare():
    """Copy source and existing native data, excluding observer history and old runs."""
    COPY.mkdir(exist_ok=False)
    for path in SOURCE.iterdir():
        if path.is_file():
            shutil.copy2(path, COPY / path.name)
    for name in ('app', 'integrations', 'tooling', 'var', '.stategraph'):
        shutil.copytree(SOURCE / name, COPY / name,
                        ignore=shutil.ignore_patterns('__pycache__', '*.lock'))
    shutil.copytree(SOURCE / 'bo_stategraph', COPY / 'bo_stategraph',
                    ignore=shutil.ignore_patterns('data', '__pycache__'))
    # The trial keeps some browser sources beside app/, not within it. Copy every
    # pinned source, then compare bytes so this diagnosis cannot omit a binding.
    manifest = json.loads((SOURCE / 'manifest.json').read_text(encoding='utf-8'))
    for name in manifest['files']:
        source = (SOURCE / name).resolve()
        target = (COPY / name).resolve()
        assert source.is_relative_to(SOURCE.resolve())
        assert target.is_relative_to(COPY.resolve())
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        assert source.read_bytes() == target.read_bytes()
    for name in ('refactor24-normal-recording-once.py',
                 'download-refactor-v1/repair24-acceptance/pre-verify.json',
                 'download-refactor-v1/repair24-acceptance/inspect.json'):
        target = COPY / 'review' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(SOURCE / 'review' / name, target)
        if name.endswith('-recording-once.py'):
            # Change only diagnostic listener addresses; keep the original case
            # assertions, queue capacities, scope and deadlines byte-for-byte.
            text = target.read_text(encoding='utf-8')
            target.write_text(text.replace("APP='http://127.0.0.1:8875'", "APP='http://127.0.0.1:8897'")
                                  .replace("VIEW='http://127.0.0.1:8876'", "VIEW='http://127.0.0.1:8898'"), encoding='utf-8')
    digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
    assert digest(SOURCE / 'var/team.sqlite3') == digest(COPY / 'var/team.sqlite3')
    (COPY / 'diagnostic-origin.json').write_text(json.dumps({
        'scope': 'Isolated diagnosis only; timers add overhead',
        'source': str(SOURCE), 'provider': str(PROVIDER),
        'database_sha256': digest(SOURCE / 'var/team.sqlite3'),
        'cases_capacity_deadlines_unchanged': True,
        'observer_entry': 'Pinned GraphSession and standard HTTP server; no CLI database rediscovery',
    }, indent=2) + '\n')


def main():
    """Run one preserved full browser workload, always terminate diagnostic children."""
    if len(sys.argv) > 1:
        child(sys.argv[1])
        return
    for port in (8897, 8898):
        with socket.socket() as check:
            assert check.connect_ex(('127.0.0.1', port)) != 0, f'Port {port} is in use'
    prepare()
    env = {**os.environ, 'PYTHONUTF8': '1',
           'TEAM_FILES_DATABASE_URL': 'sqlite:///' + str(COPY / 'var/team.sqlite3').replace('\\', '/')}
    processes, handles = [], []
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    try:
        for mode, interpreter, url in [
            ('observer', ROOT / '.venv/Scripts/python.exe', 'http://127.0.0.1:8898/api/bo/health'),
            ('app', SOURCE / '.venv/Scripts/python.exe', 'http://127.0.0.1:8897/login'),
        ]:
            stdout = (COPY / (mode + '.stdout.log')).open('x')
            stderr = (COPY / (mode + '.stderr.log')).open('x')
            handles.extend([stdout, stderr])
            command = [str(interpreter), '-B', '-X', 'utf8', str(Path(__file__)), mode]
            process = subprocess.Popen(command, cwd=COPY, env=env, stdout=stdout,
                                       stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
            processes.append(process)
            deadline = time.monotonic() + 30
            while True:
                assert process.poll() is None, f'{mode} exited: inspect logs'
                try:
                    with opener.open(url, timeout=2) as response:
                        if response.status == 200:
                            break
                except OSError:
                    pass
                assert time.monotonic() < deadline, f'{mode} startup deadline exceeded'
                time.sleep(.25)
        with (COPY / 'browser.stdout.log').open('x') as stdout, (COPY / 'browser.stderr.log').open('x') as stderr:
            result = subprocess.run([sys.executable, '-B', '-X', 'utf8',
                str(COPY / 'review/refactor24-normal-recording-once.py')],
                cwd=COPY, env=env, stdout=stdout, stderr=stderr)
        (COPY / 'command.json').write_text(json.dumps({'exit_code': result.returncode,
            'scope': 'Diagnostic replay; unchanged original case assertions'}, indent=2) + '\n')
        print(json.dumps({'diagnostic_exit': result.returncode, 'path': str(COPY)}))
    finally:
        for process in reversed(processes):
            if process.poll() is None:
                process.terminate()
            process.wait(10)
        for handle in handles:
            handle.close()


if __name__ == '__main__':
    main()


