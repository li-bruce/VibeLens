# Repair-24 ordinary capture failure: root handoff

Paused after the one real ordinary recording. No rerecording, restart, capacity/deadline/assertion change or new full test followed. Normal services remain available for root read-only diagnosis. No accept.

- Recording: `9f19775c7d514dbda809a7cda8373b48` (interrupted, 3592 events, 24 frames, 17/20 actual checks passed).
- Candidate: `da761a692b95d73fc1b68f1b433a7810060ff19e8ddaa4855193969db69df765`
- Build: `5e9e960a6792a69a5876c23b721c1e7500e45e14c988dd695e566dcc62f70454`
- App: http://127.0.0.1:8875 (listening PID 27652; launcher 53600).
- Observer: http://127.0.0.1:8876/graph?lang=zh-CN (listening PID 48232; launcher 49932).
- SQLite: `C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.validation\p7-trials\python-retest-app\var\team.sqlite3`.
- Failed-record directory: `C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.validation\p7-trials\python-retest-app\review\browser\refactor24-normal-recording-20261120T232758`.
- Frozen failure directory: `C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.validation\p7-trials\python-retest-app\review\download-refactor-v1\repair24-acceptance\failure-01`.

Stop request starts 2026-11-21T07:28:14.714475+08:00; HTTP 200 response ends 2026-11-21T07:28:19.484400+08:00. Original browser timing: responseStart=4769.145 ms, responseEnd=4769.925 ms. HTTP 200 carries interrupted status and a producer-drain gap; it is not successful capture finalization.

| Boundary | Submitted | Target | Completed | Pending | Transport retries |
|---|---|---|---|---|---|
| Actual Stop ACK | 3830 | 3814 | 3624 | 206 | 1 |
| Later control ACK retained by report | 3834 | 3814 | 3624 | 210 | 2 |

The collector snapshot after Stop has attempted=written=3664 events, errors=dropped=0, frame/context/event evictions=0. Those event counts have different units from the SDK envelope counts, which include snapshots.

The closed record contains source events 73..3664 (3592), with a continuous earlier producer event prefix and 24 snapshots. Reconstructed received prefix is 3664+24=3688 envelopes. This is **64 already received beyond the last reported completed=3624**. Do not call the whole 190-unsettled fixed prefix unsent. The other 126 fixed-prefix envelopes are absent from this closed record; 16 further submissions are beyond its fixed target.

The SDK has one serial drain worker and advances completed only after its entire bounded batch finishes. A received 64-event group awaiting ACK/retry/fallback completion is consistent with the frozen state. Exact per-request send/ACK timings and in-flight contents were not exposed by this ordinary launch. Thus queued successors is a source-based inference; the remaining 126 are not claimed as directly observed never-sent packets.

The missing view_file return at source_seq 3780 and API return at 3790 were generated at 23:28:14.101870Z and 23:28:14.127867Z, before Stop began. Both appear in the later frozen live log, never appended to the failed original record. This establishes late transport/settlement rather than omitted native exits. It does not identify the exact socket/response-loss or fallback cause.

Default-worker native ordering was request 151 -> revoke 152 -> reject 153. Native behavior, all 12 transition frames and the denied-current-input/stored-queued-context check passed. The failed checks are clean Stop, fixed-prefix drain and invocation closure.

Already passed: pre-verify 162/162; original 21 business/6 HTTP tests; on/off/fault, rollback and eight races; both negatives; original 12 browser and cancellation 38 checks; controlled record `cbe97e25d89d42ceb08ea0137c874384` (866 events, 24 frames, 20 strict native predicates and independent artifact validation). These do not cure the failed ordinary recording.

Post-verify was not started after the failure, following root instruction. Independent repaired-renderer UI and accept remain pending.

Owned provider files checked unchanged: 464; frozen source checked unchanged: 67; old raw recordings unchanged: 16; baseline unchanged: True. Personal configuration offline continuity: True; no old document was restored.

Original freeze ZIP SHA256: `d46b41393e0bfb211a969c68ca16e75cc881c3747e918aea88dd681a196e8065`. The raw Stop request/response, diagnostics, original record, frames, native SQL snapshot, logs, current source/config and installation proof are all retained there. The diagnosis adds file-only references without modifying that ZIP.
