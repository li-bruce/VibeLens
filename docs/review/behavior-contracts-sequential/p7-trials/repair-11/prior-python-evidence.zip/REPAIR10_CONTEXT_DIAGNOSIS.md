# Repair10 context conflict and verification boundary

Status: normal external upgrade and the existing strict project gates passed. A separate native snapshot-context conflict was confirmed. At the user's stop instruction, the ordinary services were closed before any browser recording started. No project binding or installed framework source was repaired. Final accept and P7 total acceptance remain open.

Provider: `../receipt-candidate-skills/vibelens`.
Build: `396cd73be1258e1c0c48de33ea46d972acd88e4525a8d68c74c6b7d391e7bcd5`.
Candidate: `04e29dc8695b281792e0276e2a2a08b3817f99b9a44e7436219770b47bc9d72c`.

## Actual queued_revoked sequence

These are original envelopes from the unchanged existing `queued_revoked/on` native scenario in strict verification. Native download-job instance: `fb1eaee3d17f41ef87aaf6849df0ee30`. Full event-ID prefix: `03c9af2fac5741d8950448b19821fbeb:33418478d2ae4092872d6dbc0ea632de:`.

| Evidence suffix | Native state | Revision | context.allowed | Transition claim | Focused installed-validator return |
|---|---|---:|---|---|---|
| 110 | not_requested | 0 | true | None | accepted=true |
| 119 | queued | 1 | true | request | accepted=true |
| 168 | queued | 1 | false | None | {"accepted": false, "duplicate": false, "errors": ["old or conflicting revision"]} |
| 177 | rejected | 2 | false | reject | Not submitted in the focused local check |

Full envelopes, complete event IDs and unmodified return dictionaries are in `repair10-queued-context-difference.json`. The final row is the actual subsequent native snapshot; it is not an inferred or inserted transition.

The focused local validation loads the current project model and selected installed `BOStateGraph`. It supplies the original snapshots for this instance, in their original order, through `BOStateGraph.bo_observe`. Before each submission it also calls the selected installed `bo_observer.observation.snapshot_reads.matches_current_read` with the matching original event and prior entry. The initial version 0 and queued commit version 1 are accepted with status observed. The next queued/1 read changes context.allowed to false, fails the identical-read predicate and returns `{"accepted":false,"duplicate":false,"errors":["old or conflicting revision"]}`. The focused check ends at that failure.

This is an actual **local canonical validation return**, not an original HTTP response. The unchanged scenario's collection-only sink has no HTTP receipt, and no HTTP body is claimed. No service, business operation, old recording or state version was changed by this local validation.

## Source and diagnosis

- `app/service.py:273` computes the current start-preparation permission; `_change` at line 130 passes that input to the pre-transition observer before the native state/revision changes.
- `integrations/bo_runtime.py:198-200` records that read and writes the same current `allowed` input into snapshot.context under the unchanged revision.
- `bo_stategraph/query.py:26-32` instead obtains the versioned context from the last committed journal permission. The two boundaries describe different facts when current authorization changes.
- The installed `snapshot_reads.matches_current_read` requires identical state/context/configuration/revision/build. The old state engine continues rejecting changed complete content at the same revision. This is distinct from repair10's support for a new read ID of identical complete state.

The observed mismatch points to project context modeling/wiring: a temporary operation decision is being supplied as versioned complete-state context. This finding does not authorize a new revision, relaxed conflict checks or silently omitted reads. Follow the user's stated boundary: temporary decisions belong in event inputs/rule facts; versioned context represents persistent native state or facts with an explicit native version. Binding changes await the common guidance and regression update.

## Confirmed validation blind spot

`tooling/observe.py:75-77` only appends envelopes to `events` or `snapshots`; the callback returns None and does not run collector admission. At lines 133-143, the scenario reads final native state with `bo_native_machine`, creates a graph, calls `bo_instances(machine)` and compares those final values with independent final SQL reads. It does not pass the collected intermediate snapshot sequence through GraphSession snapshot admission. Therefore collection health and final mapping can pass while an intermediate snapshot would be rejected. The original strict pass remains evidence for its actual scope, not proof of remote snapshot acceptance.

`repair10-verify.json` passed all five reports, 132/132 assertions, 13 business tests, five HTTP tests and both strict documentation/API checks. The old provider, original business sources, protected commands and baseline remain unchanged (`repair10-scope-retention.json`). These results do not close the blind spot or P7 acceptance.

## Preserved configuration and stop boundary

Old mismatched preferences were moved byte-for-byte to `archive/preferences-before-repair10.json`; the archive receipt records their hash. No old project_id was edited. The normal GET `/api/preferences` returned HTTP 200 with the current project's revision-zero empty default, and the normal POST returned HTTP 200 with revision 1. Original response bodies are retained in `runtime/repair10-live-20261120T071711/preferences-default-get.json` and `preferences-default-save.json`.

The ordinary app and observer briefly started without method timing wrappers. The user stopped the retest before the browser script ran. `repair10-stopped-services.json` records stopped launcher PIDs 46932/45908, released ports 8875/8876, no remaining Python/Node/browser trial process and no recording-attempt marker. There is no new repair10 recording ID. No further testing, binding change or restart follows automatically.
