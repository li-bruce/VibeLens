"""Project database declarations and read-only canonical metadata refresh."""

from pathlib import Path
import json
import os


def configuration(root: Path):
    """Declare actual SQLite resources and native query/transaction sources.

    Args:
        root: Isolated application source root with its existing native database.
    """
    os.environ.setdefault("TEAM_FILES_DATABASE_URL", "sqlite:///" + (root / "var/team.sqlite3").as_posix())
    targets = ["table:" + name for name in ("users", "files", "grants", "download_jobs", "announcements", "transition_journal")]
    operations = []
    for identity, action, symbol, parent, resources in (("db-read", "read", "Store.read", "view_file", targets), ("db-write", "write", "Store.transaction", "state_commit", targets), ("db-transaction", "transaction", "Store._transaction", "state_commit", [])):
        operations.append({"id": identity, "label": identity.replace("-", " ").capitalize(), "parent": parent, "source": {"path": "app/storage.py", "symbol": symbol}, "store": "team", "action": action, "targets": resources, **({"target_actions": {name: "read_write" if action == "write" else "read" for name in resources}} if resources else {}), "parameters": {}, "before": {}, "after": {}, "required_cases": ["normal", "queued_revoked", "started_revoked"], "requirements": ["R4", "R5"]})
    result = {"protocol": "bo-databases/v1", "stores": [{"id": "team", "label": "Team application storage", "engine": "sqlalchemy", "url_env": "TEAM_FILES_DATABASE_URL", "selection": {"source": "user", "answer": "存储按你建议的 SQLite + SQLAlchemy。", "locator": "discovery.json:U_SETUP"}, "model_layer": "SQLAlchemy ORM", "source_files": ["app/models.py", "integrations/bo_data.py"], "declaration": "bo_stategraph/database-declaration.json"}], "operations": operations, "exporters": [{"store": "team", "command": ["{python}", "-B", "-X", "utf8", "integrations/bo_data.py"], "output": "bo_stategraph/database-declaration.json"}]}
    (root / "bo_stategraph/databases.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return result
