"""Run the installed verification interfaces against the original immutable baseline."""

from datetime import datetime, timezone
from pathlib import Path
import json
import os
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]


def command(argv: list, name: str) -> dict:
    """Retain the exact exit status and raw output of an installed project check.

    Args:
        argv: Explicit executable arguments; never a shell command string.
        name: Stable review artifact label.
    """
    completed = subprocess.run(argv, cwd=ROOT, capture_output=True, encoding="utf-8", errors="replace", timeout=420, shell=False)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%f")
    for suffix in (".stdout.log", ".stderr.log", ".json"):
        previous = ROOT / "review" / (name + suffix)
        if previous.exists():
            archive = ROOT / "review/archive/check-attempts" / stamp
            archive.mkdir(parents=True, exist_ok=True)
            (archive / previous.name).write_bytes(previous.read_bytes())
    (ROOT / "review" / (name + ".stdout.log")).write_text(completed.stdout, encoding="utf-8")
    (ROOT / "review" / (name + ".stderr.log")).write_text(completed.stderr, encoding="utf-8")
    try:
        result = json.loads(completed.stdout)
    except ValueError:
        result = {"exit_code": completed.returncode}
    (ROOT / "review" / (name + ".json")).write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"stage": name, "exit_code": completed.returncode, "valid": result.get("valid"), "candidate_id": result.get("candidate_id")}), flush=True)
    if completed.returncode:
        raise RuntimeError("Project check failed: " + name)
    return result


def main():
    """Review, verify, accept and recheck the same current source candidate."""
    installation = json.loads((ROOT / "tooling/vibelens.json").read_text(encoding="utf-8"))
    scripts = (ROOT / installation["skill_root"] / "scripts").resolve()
    os.environ.setdefault("TEAM_FILES_DATABASE_URL", "sqlite:///" + (ROOT / "var/team.sqlite3").as_posix())
    prefix = [sys.executable, "-B", "-X", "utf8"]
    command([*prefix, str(scripts / "bo_integrate.py"), "check", "--root", str(ROOT), "--language", "python"], "final-integration")
    command([*prefix, "tooling/build_model.py"], "final-generation")
    command([*prefix, str(scripts / "bo_sync.py"), "scan", "--root", str(ROOT)], "final-scan")
    command([*prefix, str(scripts / "bo_names.py"), "check", "--root", str(ROOT)], "final-names")
    # Inspect returns nonzero before the candidate-specific human-readable coding
    # review exists. Preserve that receipt, then reject every structural error.
    try:
        inspected = command([*prefix, str(scripts / "change_sync.py"), "inspect", "--root", str(ROOT)], "final-inspect-before-review")
    except RuntimeError:
        inspected = json.loads((ROOT / "review/final-inspect-before-review.json").read_text(encoding="utf-8"))
        if inspected.get("errors") or not inspected.get("candidate_id"):
            raise
    active = json.loads((ROOT / ".stategraph/active.json").read_text(encoding="utf-8"))
    change = ROOT / active["change"]
    assert change.is_dir() and change.resolve().is_relative_to(ROOT)
    review = {"candidate_id": inspected["candidate_id"], "decisions": {"business": {"action": "updated", "reason": "Initial implementation binds the actual reviewed file/grant, per-attempt download and own-author announcement operations. Existing confirmed rules and all protected expectations remain; added cases cover actual native HTTP outcomes, test accounts and independent fact-read boundaries."}, "state_machine": {"action": "updated", "reason": "Four independent bo.fsm declarations drive real ORM state changes. The project transaction adapter applies admission with preparation-start state and journals its commit. The pinned per-instance lifecycle contract binds actual executor entry/return, allowed input and independently read SQL journal values; business commit remains a separate witness."}, "abstraction": {"action": "updated", "reason": "The complete source inventory, exact API registrations, shared rule DAG and real SQLite metadata/driver scopes are projected with installed interfaces. Native rows, HTTP responses and SDK context provide independent comparisons. Per-instance lifecycle scope is explicit; no finite/formal analysis or arbitrary multiplicity proof is claimed."}, "probes": {"action": "updated", "reason": "Canonical Flask/OTel boundaries run before rejecting guards. Real CSRF 400, unauthenticated 302, login 303/401 and unexpected 500 are tested without inventing skipped business calls. Native SDK identities, guard decisions, rule paths, SQL work and commits retain actual context. On/off/fault and unavailable neutral ports preserve native effects."}}, "requirement_changes": {}}
    review_path = change / "review.json"
    if review_path.exists():
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
        (ROOT / "review/archive" / ("coding-review-" + stamp + ".json")).write_bytes(review_path.read_bytes())
    review_path.write_text(json.dumps(review, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    command([*prefix, str(scripts / "change_sync.py"), "inspect", "--root", str(ROOT)], "final-inspect")
    command([*prefix, str(scripts / "change_sync.py"), "verify", "--root", str(ROOT)], "final-verify")
    command([*prefix, str(scripts / "change_sync.py"), "accept", "--root", str(ROOT)], "final-accept")
    command([*prefix, str(scripts / "change_sync.py"), "check", "--root", str(ROOT)], "final-check")


if __name__ == "__main__":
    main()
