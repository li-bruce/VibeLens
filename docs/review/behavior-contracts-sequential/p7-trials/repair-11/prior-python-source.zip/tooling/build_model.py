"""Generate the native declarations and source-backed graph from the reviewed discovery."""

from pathlib import Path
import ast
import hashlib
import json
import sys


ROOT = Path(__file__).resolve().parents[1]


def write(name: str, value: dict):
    """Write a generated project artifact with stable formatting.

    Args:
        name: Project-relative destination.
        value: JSON-compatible model or verification contract.
    """
    path = ROOT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def build():
    """Preserve four model identities and emit their actual native executor declarations."""
    sys.path.insert(0, str(ROOT))
    from tooling.bind_model import prepare_discovery
    from tooling.data_model import configuration
    configuration(ROOT)
    discovery = prepare_discovery(ROOT)
    machines, effects = {}, {}
    for model in discovery["state_models"]:
        machines[model["id"]] = {
            "engine": "bo.fsm", "version": "1", "state_type": "enum",
            "states": model["states"], "values": model["states"], "initial": model["initial"],
            "context": {"allowed": {"type": "boolean"}}, "events": model["events"],
            "guards": {guard: {"source": {"path": "bo_stategraph/workflow.py", "symbol": "allowed_guard"}} for guard in model["guards"]},
            "transitions": [{k: v for k, v in t.items() if k in ("source", "dest", "trigger", "conditions", "unless")} for t in model["transitions"]],
        }
        for transition in model["transitions"]:
            if transition.get("effects"):
                effects[model["id"] + ":" + transition["source"] + ":" + transition["trigger"]] = transition["effects"]
    write("bo_stategraph/machines.json", {"machines": machines, "transition_effects": effects})
    operations = {
        "sign_in": ("sign_in", {"username": "string"}, {"allowed": "boolean", "actor_id": "string"}),
        "upload_file": ("upload_file", {"actor_id": "string", "filename": "string"}, {"file_id": "string", "size": "number", "state": "string", "committed": "boolean", "transaction_id": "string"}),
        "view_file": ("list_files", {"actor_id": "string"}, {"count": "number"}),
        "share_file": ("manage_share", {"actor_id": "string", "file_id": "string", "recipient_id": "string"}, {"state": "string", "committed": "boolean", "transaction_id": "string"}),
        "revoke_share": ("manage_share", {"actor_id": "string", "file_id": "string", "recipient_id": "string"}, {"state": "string", "committed": "boolean", "transaction_id": "string"}),
        "request_download": ("request_download", {"actor_id": "string", "file_id": "string"}, {"job_id": "string", "state": "string", "committed": "boolean", "transaction_id": "string"}),
        "start_preparation": ("start_preparation", {}, {"found": "boolean", "job_id": "string", "allowed": "boolean", "admitted": "boolean", "state": "string", "committed": "boolean", "transaction_id": "string"}),
        "complete_preparation": ("complete_preparation", {"job_id": "string"}, {"state": "string", "committed": "boolean", "transaction_id": "string"}),
        "collect_result": ("collect_result", {"actor_id": "string", "job_id": "string"}, {"allowed": "boolean", "state": "string"}),
        "list_jobs": ("list_jobs", {"actor_id": "string"}, {"count": "number"}),
        "read_announcements": ("list_announcements", {"actor_id": "string"}, {"count": "number"}),
        "publish_announcement": ("save_announcement", {"actor_id": "string", "announcement_id": "string"}, {"announcement_id": "string", "state": "string", "committed": "boolean", "transaction_id": "string"}),
        "edit_announcement": ("save_announcement", {"actor_id": "string", "announcement_id": "string"}, {"announcement_id": "string", "state": "string", "committed": "boolean", "transaction_id": "string"}),
        "delete_announcement": ("save_announcement", {"actor_id": "string", "announcement_id": "string"}, {"announcement_id": "string", "state": "string", "committed": "boolean", "transaction_id": "string"}),
    }
    business_labels = {n["id"]: n["label"] for network in discovery["networks"] for n in network["nodes"]}
    operations["sign_in"][1]["password_provided"] = "boolean"
    for node in ("share_file", "revoke_share"):
        operations[node][1]["revoke"] = "boolean"
    for node in ("publish_announcement", "edit_announcement", "delete_announcement"):
        operations[node][1].update(title_length="number", body_length="number", delete="boolean")
    nodes = [{"id": node, "kind": "action" if node in business_labels else "function", "layer": "business" if node in business_labels else "program", "label": method.replace("_", " ").capitalize(), "source": {"path": "app/service.py", "symbol": "Service." + method}, "capture": {"in": inputs, "out": {**outputs, "error": "string"}}, "requirements": ["R1"]} for node, (method, inputs, outputs) in operations.items()]
    nodes.append({"id": "state_commit", "kind": "effect", "label": "Committed native transition", "source": {"path": "app/service.py", "symbol": "Service._change"}, "capture": {"in": {}, "out": {"model_id": "string", "instance_id": "string", "event": "string", "before": "string", "after": "string", "revision": "number", "transaction_id": "string", "committed": "boolean", "admitted": "boolean", "allowed": "boolean"}}})
    nodes.append({"id": "state_before", "kind": "function", "label": "Read native pre-state", "source": {"path": "app/service.py", "symbol": "Service._change"}, "capture": {"in": {}, "out": {"model_id": "string", "instance_id": "string", "state": "string", "revision": "number", "allowed": "boolean"}}})
    nodes.append({"id": "admission_transaction", "kind": "function", "layer": "program", "label": "Commit native preparation admission", "summary": "Observe the actual allowed admission mutation through its native transaction acknowledgement, with transaction identity already known at entry.", "source": {"path": "app/service.py", "symbol": "Service.start_preparation"}, "capture": {"in": {"transaction_id": "string", "job_id": "string"}, "out": {"transaction_id": "string", "committed": "boolean"}}})
    for identity, handler, label in (("sign_out", "logout", "Sign out"), ("service_status", "health", "Check service status")):
        nodes.append({"id": identity, "kind": "function", "layer": "program", "label": label, "source": {"path": "app/web.py", "symbol": "create_app." + handler}, "capture": {"in": {}, "out": {}}})
    for node in nodes:
        if node["id"] in ("state_before", "state_commit"):
            node["layer"] = "program"
    registrations = []
    routes = [("GET", "/login", "login"), ("POST", "/login", "login"), ("POST", "/logout", "logout"), ("GET", "/", "home"), ("POST", "/files", "upload"), ("POST", "/files/<file_id>/share", "share"), ("POST", "/files/<file_id>/downloads", "enqueue"), ("GET", "/downloads/<job_id>/result", "collect"), ("POST", "/announcements", "announcement"), ("GET", "/api/jobs", "job_status"), ("GET", "/health", "health")]
    for method, route, handler in routes:
        identity = "api:" + method + ":" + route
        inputs = {"actor_before": "string"}
        attributes = {"actor_before": "app.actor_before"}
        for field in ("file_id", "job_id"):
            if "<" + field + ">" in route:
                inputs[field] = "string"
                attributes[field] = "app." + field
        source = {"path": "app/web.py", "symbol": "create_app." + handler}
        nodes.append({"id": identity, "kind": "function", "layer": "api", "label": method + " " + route, "source": source, "capture": {"in": inputs, "out": {"status": "number", "actor_after": "string"}}})
        registrations.append({"node": identity, "source": source, "match": {"name": method + " " + route}, "capture": {"in": attributes, "out": {"status": "http.response.status_code", "actor_after": "app.actor_after"}}})
    write("bo_stategraph/telemetry.json", {"protocol": "bo-telemetry/v1", "backend": "opentelemetry", "registrations": registrations})
    for mid, machine in machines.items():
        for state in machine["states"]:
            nodes.append({"id": "native-state:" + mid + ":" + state, "kind": "state", "label": state, "layer": "state", "state_model_id": mid, "value": state, "source": {"path": "bo_stategraph/workflow.py", "symbol": "Workflow.step"}, "capture": {"in": {}, "out": {}}})
    for node in nodes:
        declaration = ast.parse((ROOT / node["source"]["path"]).read_text(encoding="utf-8"))
        for part in node["source"]["symbol"].split("."):
            declaration = next(item for item in declaration.body if isinstance(item, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)) and item.name == part)
        node["summary"] = (ast.get_docstring(declaration) or node["label"]).split("\n")[0]
    node_ids = {n["id"] for n in nodes}
    edges = [{"id": e["id"], "from": e["from"], "to": e["to"], "type": e["relation"], "label": e["label"], "evidence": "Reviewed business declaration; no runtime transfer inferred."} for network in discovery["networks"] for e in network["edges"] if e["from"] in node_ids and e["to"] in node_ids]
    for node in operations:
        if node not in ("sign_in", "view_file", "list_jobs", "collect_result", "read_announcements"):
            edges.append({"id": node + "-commits-native-state", "from": node, "to": "state_commit", "type": "flow", "label": "Commit native state", "evidence": "Actual parent invocation and transaction identity required at runtime."})
    edges.append({"id": "start_preparation-admission-transaction", "from": "start_preparation", "to": "admission_transaction", "type": "flow", "label": "Commit preparation admission", "evidence": "The native allowed-start branch registers this interval before mutation; the unchanged transaction manager closes it after actual commit acknowledgement."})
    source_files = [p.relative_to(ROOT).as_posix() for folder in ("app", "templates", "static", "integrations", "tooling") for p in (ROOT / folder).rglob("*") if p.is_file() and "__pycache__" not in p.parts]
    source_files += ["run.py", "requirements.txt", "requirements-observation.txt", "bo_stategraph/workflow.py", "bo_stategraph/query.py", "bo_stategraph/telemetry.json", "bo_stategraph/machines.json", "discovery.json", "intent.json"]
    graph = {"schema_version": 3, "revision": "1", "title": "Team file sharing", "intent": "intent.json", "source_files": sorted(set(source_files)), "nodes": nodes, "edges": edges, "machines": machines, "overview": [{"node": node, "x": index % 4 * 250, "y": index // 4 * 180} for index, node in enumerate(operations)], "scope": {"observable": ["Native operations", "Committed transition identities", "Four independent object state models"], "unknowns": ["Concept-to-source and per-predicate bindings require the canonical acceptance gates; a running app is not mapping acceptance."]}, "presentation": {"layout_id": discovery["layout_id"], "names": {"nodes": {node: {"en": method.replace("_", " ").capitalize(), "zh-CN": business_labels.get(node, "查看下载任务")} for node, (method, _, _) in operations.items()}}}}
    discovery_hash = hashlib.sha256((ROOT / "discovery.json").read_bytes()).hexdigest()
    graph["native_transition_effects"] = effects
    installation = json.loads((ROOT / "tooling/vibelens.json").read_text(encoding="utf-8"))
    sys.path.insert(0, str((ROOT / installation["skill_root"] / "scripts").resolve()))
    from bo_sync import source_inventory
    from code_structure import scan, enrich
    sys.path.insert(0, str(ROOT))
    from tooling.coverage import implementation
    from tooling.bind_model import bind
    graph = bind(ROOT, discovery, graph)
    from tooling.behavior_contract import build_behavior
    graph, behavior_pin = build_behavior(ROOT, discovery, graph)
    config_path = ROOT / "sync.json"
    config = json.loads(config_path.read_text(encoding="utf-8"))
    for path, reason in (("review", "Original verification records, screenshots, dependency cache and archives; no application source lives here."), ("initial-v1", "Immutable baseline and verification receipts for the initial change; no application source lives here.")):
        if not any(item["path"] == path for item in config["source_scope"]["prune"]):
            config["source_scope"]["prune"].append({"path": path, "category": "artifact", "reason": reason})
    # The source inventory reads registered definition paths from the envelope.
    # Refresh this authored contract pin before that independent read; the frozen
    # change baseline and historical snapshots remain untouched.
    current_path = ROOT / "bo_stategraph/project.json"
    if current_path.exists():
        current_project = json.loads(current_path.read_text(encoding="utf-8"))
        current_project["model"] = graph
        current_project["contracts"]["discovery"]["sha256"] = hashlib.sha256((ROOT / "discovery.json").read_bytes()).hexdigest()
        if current_project["contracts"].get("behavior"):
            current_project["contracts"]["behavior"] = behavior_pin
        write("bo_stategraph/project.json", current_project)
    files = source_inventory(ROOT, config)["files"]
    config["code_files"] = sorted(files)
    config["stategraph"]["decision"] = "我选择状态图驱动执行（drive）。"
    config["watch_files"] = sorted(set(config["watch_files"]) | {"bo_stategraph/__init__.py", "tests/test_http_observation.py", "requirements-observation.txt", "tooling/vibelens.json"})
    config["test_commands"] = [["{python}", "-B", "-X", "utf8", "-m", "unittest", "tests.test_business", "-v"], ["{python}", "-B", "-X", "utf8", "-m", "unittest", "tests.test_http_observation", "-v"], ["{python}", "-B", "-X", "utf8", "tooling/strict_checks.py", "docs"], ["{python}", "-B", "-X", "utf8", "tooling/strict_checks.py", "api-check"]]
    config["watch_files"] = sorted(set(config["watch_files"]) | {"tooling/strict_checks.py"})
    write("sync.json", config)
    index = scan(ROOT, config["code_files"])
    graph["implementation"] = implementation(ROOT, graph, index)
    graph["source_files"] = sorted(set(graph["source_files"]) | set(config["code_files"]) | {"implementation.json"})
    graph = enrich(graph, index, depth=1)
    project = {"protocol": "bo-project/v2", "project_id": discovery["project_id"], "selection": {"mode": "drive", "source": "user", "answer": "我选择状态图驱动执行（drive）。", "locator": "discovery.json:U_REQUEST"}, "model": graph, "contracts": {"discovery": {"path": "discovery.json", "sha256": discovery_hash, "schema": "business-discovery/v3"}, "behavior": behavior_pin, "analysis_profiles": []}}
    write("bo_stategraph/project.json", project)
    from bo_observer.data.sync import synchronize
    data_result = synchronize(ROOT, force=True)
    write("review/database-generation.json", data_result)
    if not data_result["valid"]:
        raise ValueError(data_result["errors"])
    project = json.loads((ROOT / "bo_stategraph/project.json").read_text(encoding="utf-8"))
    graph = project["model"]
    graph["implementation"] = implementation(ROOT, graph, index)
    graph = enrich(graph, index, depth=1)
    project["model"] = graph
    write("bo_stategraph/project.json", project)
    write("behavior.json", graph)
    from behavior_model import capture
    write("manifest.json", capture(ROOT, graph))
    return graph


if __name__ == "__main__":
    build()
