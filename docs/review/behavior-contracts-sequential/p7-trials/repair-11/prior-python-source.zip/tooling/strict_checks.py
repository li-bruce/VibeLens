"""Project-local verification entry for the installed strict source and API checks."""

from pathlib import Path
import json
import subprocess
import sys


def main():
    """Run one exact installed check through a watched, source-bound project entry."""
    root = Path(__file__).resolve().parents[1]
    action = sys.argv[1] if len(sys.argv) == 2 else ""
    if action not in ("docs", "api-check"):
        raise ValueError("Expected docs or api-check")
    installation = json.loads((root / "tooling/vibelens.json").read_text(encoding="utf-8"))
    cli = (root / installation["skill_root"] / "scripts/bo_code.py").resolve()
    return subprocess.run([sys.executable, "-B", "-X", "utf8", str(cli), action, "--root", str(root), "--strict"], cwd=root, shell=False).returncode


if __name__ == "__main__":
    raise SystemExit(main())
