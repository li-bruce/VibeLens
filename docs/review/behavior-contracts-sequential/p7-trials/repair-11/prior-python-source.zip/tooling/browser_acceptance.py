"""Exercise real desktop pages with isolated data and a separately launched Chrome."""

from pathlib import Path
from threading import Thread
from datetime import datetime, timezone
import hashlib
import json
import sys
import zipfile

from playwright.sync_api import sync_playwright, expect
from werkzeug.serving import make_server


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from app.web import create_app
from integrations.bo_runtime import BOObservation
from tooling.observe import read_native


def main():
    """Verify actual UI commands, controlled admission boundaries and the automatic worker."""
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
    evidence = ROOT / "review/browser" / stamp
    evidence.mkdir(parents=True)
    directory = ROOT / "review/runtime" / ("browser-" + stamp)
    directory.mkdir(parents=True)
    payload = "Synthetic browser acceptance file.\n真实页面验收文件。\n".encode("utf-8")
    upload = evidence / "team-acceptance.txt"
    upload.write_bytes(payload)
    events, snapshots, responses, console_errors, checks = [], [], [], [], []

    def sink(value, kind):
        """Retain the actual canonical envelope; never synthesize an event."""
        (events if kind == "events" else snapshots).append(value)

    observation = BOObservation(ROOT, sink=sink, build_id=json.loads((ROOT / "manifest.json").read_text(encoding="utf-8"))["build_id"])
    app = create_app(ROOT, directory, start_worker=False, observation=observation)
    service = app.extensions["service"]
    server = make_server("127.0.0.1", 8878, app, threaded=True)
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base = "http://127.0.0.1:8878"

    def save(page, name):
        """Save the rendered native page after its actual navigation settles.

        Args:
            page: Actual browser page.
            name: Descriptive screenshot artifact name.
        """
        page.wait_for_load_state("networkidle")
        page.screenshot(path=str(evidence / (name + ".png")), full_page=True)
        assert page.evaluate("document.documentElement.scrollWidth <= window.innerWidth"), name

    def login(page, actor):
        """Log a synthetic account in through the real browser form.

        Args:
            page: Isolated browser session page.
            actor: Existing test account identity.
        """
        page.goto(base + "/login")
        page.wait_for_load_state("networkidle")
        page.get_by_label("用户名", exact=True).fill(actor)
        page.get_by_label("密码", exact=True).fill("demo-" + actor + "-123")
        page.get_by_role("button", name="登录", exact=True).click()
        expect(page.get_by_role("heading", name="文件空间", exact=True)).to_be_visible()

    report = {"started_at": datetime.now(timezone.utc).isoformat(), "build_id": service.build_id, "url": base, "data_directory": str(directory), "controlled_worker": "Native Service.start_preparation and complete_preparation establish the exact before/after-revocation boundaries. The last request uses the real automatic worker.", "status": "running"}
    try:
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(channel="chrome", headless=True)
            contexts = [browser.new_context(viewport={"width": 1440, "height": 960}, accept_downloads=True, locale="zh-CN") for _ in range(3)]
            for context in contexts:
                context.on("response", lambda response: responses.append({"method": response.request.method, "path": response.url.split("127.0.0.1:8878")[-1].split("?")[0], "status": response.status}))
                context.on("page", lambda page: page.on("pageerror", lambda error: console_errors.append(str(error))))
            alice, bob, casey = [context.new_page() for context in contexts]
            alice.goto(base + "/login")
            save(alice, "01-login")
            login(alice, "alice")
            alice.locator('input[type="file"]').set_input_files(str(upload))
            alice.get_by_role("button", name="上传文件", exact=True).click()
            expect(alice.get_by_role("heading", name="team-acceptance.txt", exact=True)).to_be_visible()
            alice.get_by_label("分享 team-acceptance.txt 给同事").select_option("bob")
            alice.get_by_role("button", name="分享", exact=True).click()
            expect(alice.get_by_text("已分享给 bob", exact=True)).to_be_visible()
            save(alice, "02-uploader-shared")
            login(bob, "bob")
            expect(bob.get_by_role("heading", name="team-acceptance.txt", exact=True)).to_be_visible()
            assert bob.locator("select[name=recipient_id]").count() == 0
            save(bob, "03-recipient-file")
            stale = contexts[1].new_page()
            stale.goto(base + "/")
            stale.wait_for_load_state("networkidle")
            bob.get_by_role("button", name="准备下载", exact=True).click()
            expect(bob.locator(".job-action").get_by_text("排队等待", exact=True)).to_be_visible()
            first_job = bob.locator("#job-list").get_attribute("data-states").split(":")[0]
            save(bob, "04-queued")
            alice.get_by_role("button", name="撤销与 bob 的共享", exact=True).click()
            expect(alice.get_by_text("仅自己可见", exact=True)).to_be_visible()
            with stale.expect_response(lambda response: response.request.method == "POST" and response.url.endswith("/downloads")) as denied:
                stale.get_by_role("button", name="准备下载", exact=True).click()
            assert denied.value.status == 403
            save(stale, "05-stale-request-denied")
            rejected = service.start_preparation()
            assert rejected["id"] == first_job and rejected["state"] == "rejected"
            bob.goto(base + "/?tab=downloads")
            expect(bob.get_by_text("共享已撤销，无法准备", exact=True)).to_be_visible()
            save(bob, "06-revoked-terminal")
            alice.get_by_label("分享 team-acceptance.txt 给同事").select_option("bob")
            alice.get_by_role("button", name="分享", exact=True).click()
            alice.wait_for_load_state("networkidle")
            assert service.start_preparation() is None
            bob.goto(base + "/")
            bob.get_by_role("button", name="准备下载", exact=True).click()
            admitted = service.start_preparation()
            assert admitted["id"] != first_job and admitted["state"] == "preparing"
            alice.get_by_role("button", name="撤销与 bob 的共享", exact=True).click()
            alice.wait_for_load_state("networkidle")
            service.complete_preparation(admitted["id"])
            bob.goto(base + "/?tab=downloads")
            expect(bob.get_by_role("link", name="领取结果", exact=True)).to_be_visible()
            for number in (1, 2):
                with bob.expect_download() as download:
                    bob.get_by_role("link", name="领取结果", exact=True).click()
                path = evidence / ("collected-" + str(number) + ".zip")
                download.value.save_as(str(path))
                with zipfile.ZipFile(path) as archive:
                    assert archive.read("team-acceptance.txt") == payload
            save(bob, "07-ready-after-revocation")
            bob.goto(base + "/")
            expect(bob.get_by_role("heading", name="team-acceptance.txt", exact=True)).to_have_count(0)
            checks.extend(["owner-only sharing controls", "stale native request denied with HTTP 403", "queued revoked attempt terminates", "re-sharing does not revive the old job", "admitted attempt finishes after revocation", "two downloads contain the original bytes", "revoked original hidden"])
            login(casey, "casey")
            expect(casey.get_by_role("heading", name="team-acceptance.txt", exact=True)).to_have_count(0)
            casey.get_by_role("link", name="公告板", exact=True).click()
            casey.get_by_label("标题", exact=True).fill("周五协作安排")
            casey.get_by_label("正文", exact=True).fill("共享文件请确认接收同事。下载任务以开始准备时的资格为准。")
            casey.get_by_role("button", name="发布公告", exact=True).click()
            expect(casey.get_by_role("heading", name="周五协作安排", exact=True)).to_be_visible()
            casey.get_by_role("link", name="修改", exact=True).click()
            casey.get_by_label("标题", exact=True).fill("周五协作安排 · 已更新")
            casey.get_by_role("button", name="保存修改", exact=True).click()
            expect(casey.get_by_role("heading", name="周五协作安排 · 已更新", exact=True)).to_be_visible()
            save(casey, "08-announcement-editor")
            bob.goto(base + "/?tab=board")
            expect(bob.get_by_role("heading", name="周五协作安排 · 已更新", exact=True)).to_be_visible()
            assert bob.get_by_role("link", name="修改", exact=True).count() == 0
            assert bob.get_by_role("button", name="删除", exact=True).count() == 0
            save(bob, "09-announcement-reader")
            casey.get_by_role("button", name="删除", exact=True).click()
            casey.wait_for_load_state("networkidle")
            bob.reload()
            expect(bob.get_by_role("heading", name="周五协作安排 · 已更新", exact=True)).to_have_count(0)
            checks.extend(["announcement editor has no file override", "editor publishes and edits own announcement", "ordinary colleague reads without edit/delete controls", "deleted announcement disappears"])
            alice.get_by_label("分享 team-acceptance.txt 给同事").select_option("bob")
            alice.get_by_role("button", name="分享", exact=True).click()
            alice.wait_for_load_state("networkidle")
            service.start_worker()
            bob.goto(base + "/")
            bob.get_by_role("button", name="准备下载", exact=True).click()
            expect(bob.get_by_role("link", name="领取结果", exact=True)).to_have_count(2, timeout=20000)
            save(bob, "10-automatic-worker")
            checks.append("actual background worker prepares a new UI request")
            assert console_errors == []
            for context in contexts:
                context.close()
            browser.close()
        report["status"] = "passed"
    except Exception as error:
        report.update(status="failed", error_type=type(error).__name__, error=str(error))
        raise
    finally:
        server.shutdown()
        thread.join(timeout=5)
        service.close()
        observation.bo_probe.flush(5)
        native, instances = read_native(directory)
        report.update(checks=checks, http_responses=responses, console_errors=console_errors, health=observation.bo_health(), screenshots=[path.name for path in evidence.glob("*.png")], upload_sha256=hashlib.sha256(payload).hexdigest(), finished_at=datetime.now(timezone.utc).isoformat())
        (evidence / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        (evidence / "raw-observations.json").write_text(json.dumps({"events": events, "snapshots": snapshots}, ensure_ascii=False) + "\n", encoding="utf-8")
        (evidence / "native-storage.json").write_text(json.dumps({**native, "instances": instances}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        observation.close()
        print(json.dumps({"status": report["status"], "report": str(evidence / "report.json"), "screenshots": report["screenshots"], "checks": checks}, ensure_ascii=False))


if __name__ == "__main__":
    main()
