"""Verify real Flask early returns and actual response statuses under canonical observation."""

from pathlib import Path
import json
import tempfile
import unittest
from io import BytesIO
from datetime import datetime, timezone

from app.web import create_app
from integrations.bo_runtime import BOObservation


ROOT = Path(__file__).resolve().parents[1]


class HTTPObservationTests(unittest.TestCase):
    """Compare native responses and sessions with actual SDK/probe records."""

    def setUp(self):
        """Create a real Flask application, database, and canonical local observation sink."""
        (ROOT / "review/runtime").mkdir(parents=True, exist_ok=True)
        self.temporary = tempfile.TemporaryDirectory(dir=ROOT / "review/runtime")
        self.events = []
        build_id = json.loads((ROOT / "manifest.json").read_text(encoding="utf-8"))["build_id"]
        self.observation = BOObservation(ROOT, sink=self.sink, build_id=build_id)
        self.app = create_app(ROOT, Path(self.temporary.name), start_worker=False, observation=self.observation)
        self.client = self.app.test_client()
        self.service = self.app.extensions["service"]

    def sink(self, value: dict, kind: str):
        """Retain original native envelopes without making application calls.

        Args:
            value: Actual envelope supplied by the canonical native probe.
            kind: Canonical events or snapshots channel.
        """
        if kind == "events":
            self.events.append(value)

    def tearDown(self):
        """Drain the producer and close native connections before deleting isolated test data."""
        self.service.close()
        self.observation.close()
        artifact = ROOT / "review/runtime/http-boundaries" / datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%f")
        artifact.mkdir(parents=True, exist_ok=True)
        (artifact / (self._testMethodName + ".json")).write_text(json.dumps({"test": self._testMethodName, "events": self.events, "health": self.observation.bo_health()}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        self.temporary.cleanup()

    def recorded_since(self, offset: int) -> list:
        """Read the settled event interval for one native HTTP request.

        Args:
            offset: Actual event count immediately before this request.
        """
        self.observation.bo_probe.flush(5)
        return self.events[offset:]

    def login(self, actor_id: str):
        """Authenticate through the actual form endpoint with its current CSRF token.

        Args:
            actor_id: One of the three synthetic test accounts.
        """
        self.client.get("/login")
        with self.client.session_transaction() as native:
            csrf = native["csrf"]
        return self.client.post("/login", data={"csrf": csrf, "username": actor_id, "password": "demo-" + actor_id + "-123"})

    def assert_http_status(self, events: list, node: str, native_status: int):
        """Compare a real API return with the independent native response status.

        Args:
            events: Original records for the native request interval.
            node: Exact method/route-qualified API identity.
            native_status: Actual response status returned by Flask.
        """
        entries = [e for e in events if e["node"] == node and e["phase"] == "enter"]
        returns = [e for e in events if e["node"] == node and e["phase"] == "return"]
        self.assertEqual(len(entries), 1)
        self.assertEqual(len(returns), 1)
        self.assertEqual(returns[0]["outputs"]["status"], native_status)
        self.assertEqual(entries[0]["call_id"], returns[0]["call_id"])
        self.assertEqual(entries[0]["trace"]["trace_id"], returns[0]["trace"]["trace_id"])
        self.assertEqual(self.observation.bo_health()["errors"], 0)

    def test_csrf_rejection_records_only_real_http(self):
        """A request rejected before the handler has HTTP 400 and no invented login call."""
        self.client.get("/login")
        self.observation.bo_probe.flush(5)
        offset = len(self.events)
        response = self.client.post("/login", data={"username": "bob", "password": "demo-bob-123"})
        events = self.recorded_since(offset)
        self.assertEqual(response.status_code, 400)
        self.assert_http_status(events, "api:POST:/login", response.status_code)
        self.assertEqual({e["node"] for e in events}, {"api:POST:/login"})

    def test_authentication_redirect_has_no_file_business_call(self):
        """An unauthenticated route redirect is recorded before file business logic runs."""
        response = self.client.get("/")
        events = self.recorded_since(0)
        self.assertEqual(response.status_code, 302)
        self.assert_http_status(events, "api:GET:/", response.status_code)
        self.assertNotIn("view_file", {e["node"] for e in events})

    def test_login_reauthentication_and_rejection_native_principals(self):
        """Entry and completion retain actual session principals on fresh and existing sessions."""
        self.assertEqual(self.login("bob").status_code, 303)
        for claimed, password, expected_status, expected_after in (("alice", "demo-alice-123", 303, "alice"), ("alice", "incorrect", 401, "alice")):
            with self.client.session_transaction() as native:
                before, csrf = native["actor_id"], native["csrf"]
            self.observation.bo_probe.flush(5)
            offset = len(self.events)
            response = self.client.post("/login", data={"csrf": csrf, "username": claimed, "password": password})
            with self.client.session_transaction() as native:
                after = native["actor_id"]
            events = self.recorded_since(offset)
            self.assertEqual((response.status_code, after), (expected_status, expected_after))
            self.assert_http_status(events, "api:POST:/login", response.status_code)
            entry = next(e for e in events if e["node"] == "api:POST:/login" and e["phase"] == "enter")
            end = next(e for e in events if e["node"] == "api:POST:/login" and e["phase"] == "return")
            self.assertEqual(entry["inputs"]["actor_before"], before)
            self.assertEqual(end["outputs"]["actor_after"], after)
            self.assertNotIn(password, json.dumps(events))

    def test_native_framework_500_has_actual_return(self):
        """A real missing prepared file produces a native exception and the framework's 500."""
        file_id = self.service.upload_file("alice", "source.txt", BytesIO(b"Actual data"))
        self.service.manage_share("alice", file_id, "bob")
        job_id = self.service.request_download("bob", file_id)
        self.service.start_preparation()
        self.service.complete_preparation(job_id)
        path, _ = self.service.collect_result("bob", job_id)
        path.unlink()
        self.login("bob")
        self.observation.bo_probe.flush(5)
        offset = len(self.events)
        response = self.client.get("/downloads/" + job_id + "/result")
        events = self.recorded_since(offset)
        self.assertEqual(response.status_code, 500)
        self.assert_http_status(events, "api:GET:/downloads/<job_id>/result", response.status_code)
        failures = [e for e in events if e["node"] == "collect_result" and e["phase"] == "error"]
        self.assertEqual(failures[0]["exception"]["type"], "FileNotFoundError")

    def test_observer_exports_make_no_business_events(self):
        """Reading the public native graph does not manufacture business or API observations."""
        self.login("alice")
        self.observation.bo_probe.flush(5)
        offset = len(self.events)
        response = self.client.get("/api/stategraph")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(self.recorded_since(offset), [])


if __name__ == "__main__":
    unittest.main()
