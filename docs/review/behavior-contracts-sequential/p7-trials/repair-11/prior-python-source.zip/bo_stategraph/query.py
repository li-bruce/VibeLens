"""Read complete native object configurations without executing business operations."""

from contextlib import closing
from pathlib import Path
import sqlite3


def bo_native_machine(database: Path, build_id: str) -> dict:
    """Project every stored object from an actual read-only SQLite snapshot.

    Args:
        database: Native application database file, never an observer-owned cache.
        build_id: Loaded application build identity.
    """
    if not Path(database).is_file():
        return {"configurations": []}
    result = []
    with closing(sqlite3.connect(Path(database).as_uri() + "?mode=ro", uri=True)) as connection:
        connection.row_factory = sqlite3.Row
        connection.execute("BEGIN")
        for model_id, table in (("file", "files"), ("grant", "grants"), ("download-job", "download_jobs"), ("announcement", "announcements")):
            for row in connection.execute("SELECT * FROM " + table):
                identity = row["file_id"] + ":" + row["recipient_id"] if model_id == "grant" else row["id"]
                journal = connection.execute("SELECT permission_allowed,build_id FROM transition_journal WHERE model_id=? AND instance_id=? ORDER BY sequence DESC LIMIT 1", (model_id, identity)).fetchone()
                if journal is None:
                    # Unwitnessed fixtures remain partial rather than acquiring invented context.
                    context = {}
                else:
                    context = {"allowed": bool(journal[0])}
                result.append({"state_model_id": model_id, "snapshot_instance": identity, "attempt": identity, "phase": row["state"], "state_revision": row["revision"], "run_build_id": journal["build_id"] if journal else None, "context": context})
    return {"configurations": result}


def bo_export_native(root: Path, directory: Path) -> dict:
    """Use the public native graph exporter against actual application storage.

    Args:
        root: Project source root and current manifest location.
        directory: Private application runtime data directory.
    """
    import json
    from bo_stategraph import BOStateGraph
    project = json.loads((Path(root) / "bo_stategraph/project.json").read_text(encoding="utf-8"))
    manifest = json.loads((Path(root) / "manifest.json").read_text(encoding="utf-8"))
    graph = BOStateGraph(project["model"], build_id=manifest["build_id"], mode="drive")
    machine = bo_native_machine(Path(directory) / "team.sqlite3", manifest["build_id"])
    return graph.bo_export(runtime={"machine": machine})
