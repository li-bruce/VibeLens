"""Selected native Flask facts; no credential, body, or query-string collection."""

from flask import has_request_context, request, session
from opentelemetry.sdk.trace import SpanProcessor
import threading


class BONativeRequestFacts(SpanProcessor):
    """Enrich the SDK boundary from the actual request before graph capture starts."""

    def __init__(self, registrations):
        """Initialize bounded native SDK readers from the real selected route declarations.

        Args:
            registrations: Existing exact method/route SDK selections.
        """
        self.bo_errors = 0
        self.bo_selected = {item["match"]["name"]: item["node"] for item in registrations}
        self.bo_values = {}
        self.bo_finished = []
        self.bo_lock = threading.Lock()

    def bo_sdk_fact(self, span, phase: str, node_override=None, check_id=None):
        """Read actual SDK identities independently from BOProbe events or graph projections.

        Args:
            span: Actual SDK span or completed ReadableSpan.
            phase: Physical SDK entry or completion boundary.
            node_override: Source-bound native point notification within this real SDK span.
            check_id: Actual native rule check identity for repeated reads in one call.
        """
        attributes = dict(span.attributes or {})
        node = node_override or attributes.get("vibelens.node_id") or self.bo_selected.get(span.name)
        if not node:
            return
        context = span.get_span_context() if hasattr(span, "get_span_context") else span.context
        parent = span.parent
        metadata = {"trace_id": format(context.trace_id, "032x"), "span_id": format(context.span_id, "016x"), "trace_flags": int(context.trace_flags), "parent_span_id": format(parent.span_id, "016x") if parent and parent.is_valid else None, "tracestate": context.trace_state.to_header(), "links": [{"trace_id": format(link.context.trace_id, "032x"), "span_id": format(link.context.span_id, "016x"), "relation": (link.attributes or {}).get("vibelens.relation", "trigger"), **({"source_build_id": link.attributes["vibelens.source_build_id"]} if (link.attributes or {}).get("vibelens.source_build_id") else {})} for link in span.links]}
        boundary = phase if phase != "complete" else "error" if not node.startswith("api:") and attributes.get("error.type") else "return"
        item = {"trace": metadata, "transaction_id": attributes.get("app.transaction_id"), "check_id": check_id}
        with self.bo_lock:
            if sum(len(values) for phases in self.bo_values.values() for values in phases.values()) >= 10000:
                self.bo_errors += 1
                return
            self.bo_values.setdefault(node, {}).setdefault(boundary, []).append(item)
            if phase == "complete":
                self.bo_finished.append(item)

    def bo_point(self, node: str, phase: str, check_id=None):
        """Read the current SDK context at an actual native point notification.

        Args:
            node: Native source-bound point identity.
            phase: Actual read, decision or commit boundary.
            check_id: Actual rule check identifier, when repeated within one call.
        """
        try:
            from opentelemetry import trace
            span = trace.get_current_span()
            if span.is_recording():
                self.bo_sdk_fact(span, phase, node, check_id)
        except Exception:
            self.bo_errors += 1

    def on_start(self, span, parent_context=None):
        """Read session identity and registered route arguments at API entry.

        Args:
            span: Actual SDK span currently starting.
            parent_context: SDK-provided causal parent context.
        """
        try:
            if has_request_context() and not span.attributes.get("vibelens.node_id"):
                span.set_attribute("app.actor_before", session.get("actor_id", ""))
                for field in ("file_id", "job_id"):
                    span.set_attribute("app." + field, str((request.view_args or {}).get(field, "")))
            self.bo_sdk_fact(span, "enter")
        except Exception:
            self.bo_errors += 1

    def on_end(self, span):
        """Read completed SDK facts without editing earlier observations.

        Args:
            span: Completed SDK span; source values are never repaired afterward.
        """
        try:
            self.bo_sdk_fact(span, "complete")
        except Exception:
            self.bo_errors += 1


def bo_response_facts(span, status: str, headers):
    """Select the native session principal while the actual Flask response exists.

    Args:
        span: SDK server span for this concrete HTTP request.
        status: Actual framework status line, independently captured by the instrumentor.
        headers: Actual framework response headers; none are exported here.
    """
    if has_request_context() and span is not None and span.is_recording():
        span.set_attribute("app.actor_after", session.get("actor_id", ""))
