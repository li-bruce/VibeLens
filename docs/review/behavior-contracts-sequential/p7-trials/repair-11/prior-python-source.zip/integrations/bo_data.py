"""Offline SQLAlchemy model export and optional native database observation."""

from pathlib import Path
import json
import sys


def bo_export_metadata():
    """Export existing ORM metadata without opening or changing a database."""
    root = Path(__file__).resolve().parents[1]
    installation = json.loads((root / "tooling/vibelens.json").read_text(encoding="utf-8"))
    sys.path.insert(0, str(root))
    sys.path.insert(0, str((root / installation["skill_root"] / "scripts").resolve()))
    from bo_observer.data.catalog import export_sqlalchemy_metadata
    from sqlalchemy.dialects.sqlite import dialect
    from app.models import Base
    return export_sqlalchemy_metadata(Base.metadata, "team", dialect=dialect())


if __name__ == "__main__":
    print(json.dumps(bo_export_metadata(), ensure_ascii=False))
