"""Optional application observation wiring."""
