"""Relational models for independent file, grant, download, and announcement lifecycles."""

from sqlalchemy import Boolean, ForeignKey, Integer, String, Text
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    """Own the application's SQLAlchemy metadata."""


class User(Base):
    """A password-authenticated colleague; editor authority applies only to announcements."""

    __tablename__ = "users"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    name: Mapped[str] = mapped_column(String)
    password_hash: Mapped[str] = mapped_column(String)
    editor: Mapped[bool] = mapped_column(Boolean, default=False)


class File(Base):
    """An original file owned by its uploader."""

    __tablename__ = "files"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    owner_id: Mapped[str] = mapped_column(ForeignKey("users.id"))
    name: Mapped[str] = mapped_column(String)
    size: Mapped[int] = mapped_column(Integer)
    state: Mapped[str] = mapped_column(String, default="absent")
    revision: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[str] = mapped_column(String)


class Grant(Base):
    """A current grant for one file and one recipient; revision prevents old-job revival."""

    __tablename__ = "grants"
    file_id: Mapped[str] = mapped_column(ForeignKey("files.id"), primary_key=True)
    recipient_id: Mapped[str] = mapped_column(ForeignKey("users.id"), primary_key=True)
    state: Mapped[str] = mapped_column(String, default="inactive")
    revision: Mapped[int] = mapped_column(Integer, default=0)


class DownloadJob(Base):
    """One preparation attempt; its admission survives later grant revocation."""

    __tablename__ = "download_jobs"
    sequence: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    id: Mapped[str] = mapped_column(String, unique=True)
    file_id: Mapped[str] = mapped_column(ForeignKey("files.id"))
    requester_id: Mapped[str] = mapped_column(ForeignKey("users.id"))
    grant_revision: Mapped[int | None] = mapped_column(Integer, nullable=True)
    state: Mapped[str] = mapped_column(String, default="not_requested")
    revision: Mapped[int] = mapped_column(Integer, default=0)
    admitted: Mapped[bool] = mapped_column(Boolean, default=False)
    result_name: Mapped[str] = mapped_column(String, default="")
    error_code: Mapped[str] = mapped_column(String, default="")
    created_at: Mapped[str] = mapped_column(String)


class Announcement(Base):
    """A publication managed only by its own editor author."""

    __tablename__ = "announcements"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    author_id: Mapped[str] = mapped_column(ForeignKey("users.id"))
    title: Mapped[str] = mapped_column(String)
    body: Mapped[str] = mapped_column(Text)
    state: Mapped[str] = mapped_column(String, default="unpublished")
    revision: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[str] = mapped_column(String)


class Journal(Base):
    """A committed native transition witness, independent from observer availability."""

    __tablename__ = "transition_journal"
    sequence: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    model_id: Mapped[str] = mapped_column(String)
    instance_id: Mapped[str] = mapped_column(String)
    event: Mapped[str] = mapped_column(String)
    before: Mapped[str] = mapped_column(String)
    after: Mapped[str] = mapped_column(String)
    revision: Mapped[int] = mapped_column(Integer)
    guards: Mapped[str] = mapped_column(Text)
    permission_allowed: Mapped[bool] = mapped_column(Boolean)
    transaction_id: Mapped[str] = mapped_column(String)
    build_id: Mapped[str] = mapped_column(String)

