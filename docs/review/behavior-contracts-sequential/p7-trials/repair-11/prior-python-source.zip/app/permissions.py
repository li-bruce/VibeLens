"""Native permission predicates. Announcement roles never grant file authority."""


def same_identity(left: str, right: str) -> bool:
    """Compare two native identity strings.

    Args:
        left: Principal or object identity.
        right: Identity required by the selected operation.
    """
    return left == right


def can_access(actor_id: str, owner_id: str, recipient_id: str, active: bool) -> bool:
    """Allow the uploader or the selected recipient with a current active grant.

    Args:
        actor_id: Colleague whose file access is being checked.
        owner_id: Original uploader read from the file row.
        recipient_id: Recipient read from the selected grant, or an empty string.
        active: Current grant status from the same transaction.
    """
    return same_identity(actor_id, owner_id) or (same_identity(actor_id, recipient_id) and active)


def can_manage(actor_id: str, owner_id: str) -> bool:
    """Allow only the original uploader to share or revoke this file.

    Args:
        actor_id: Authenticated colleague performing the operation.
        owner_id: Original uploader read from the file row.
    """
    return same_identity(actor_id, owner_id)


def can_edit_announcement(actor_id: str, author_id: str, editor: bool) -> bool:
    """Allow an announcement editor to manage only their own publication.

    Args:
        actor_id: Authenticated colleague.
        author_id: Author stored on the announcement.
        editor: This colleague's announcement editor role.
    """
    return editor and same_identity(actor_id, author_id)

