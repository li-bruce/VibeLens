"""Failure-isolated observation port; domain behavior has no external observer imports."""

from contextlib import contextmanager


class NullObservation:
    """Keep native operations available when monitoring is disabled or absent."""

    def bo_attach_storage(self, engine):
        """Leave native storage unchanged when database observation is unavailable.

        Args:
            engine: Application-owned SQLAlchemy engine.
        """

    @contextmanager
    def bo_transaction(self, manager):
        """Enter the application's own commit/rollback manager exactly once.

        Args:
            manager: Actual native transaction context manager.
        """
        with manager as session:
            yield session

    @contextmanager
    def bo_query_scope(self, write: bool = False):
        """Leave actual SQL execution unchanged.

        Args:
            write: Whether this native scope permits writes as well as reads.
        """
        yield

    def bo_policy(self, value: dict):
        """Receive an already completed native rule evaluation.

        Args:
            value: Actual decision and visited native expression results.
        """

    def bo_guard(self, node: str, value: bool):
        """Receive the actual executor callback result.

        Args:
            node: Source-bound guard identity.
            value: Boolean actually returned to the native executor.
        """

    def bo_instrument_app(self, app):
        """Leave framework dispatch unchanged when HTTP observation is unavailable.

        Args:
            app: Native Flask application under construction.
        """

    @contextmanager
    def span(self, node: str, values: dict):
        """Yield an isolated completion dictionary for selected observations.

        Args:
            node: Stable mapped operation identity.
            values: Explicitly selected non-secret input values.
        """
        yield {}

    def bo_transition(self, value: dict):
        """Accept an actual committed transition without changing application state.

        Args:
            value: Native journal values supplied after commit.
        """

    def bo_admission_started(self, transaction_id: str, job_id: str):
        """Leave native admission and its transaction unchanged without observation.

        Args:
            transaction_id: Actual transaction about to apply admission.
            job_id: Actual queued attempt admitted by the current permission check.
        """

    def bo_before_transition(self, value: dict):
        """Receive the actual pre-transition state at its native read boundary.

        Args:
            value: Native model, instance, state, revision, and decision context.
        """

