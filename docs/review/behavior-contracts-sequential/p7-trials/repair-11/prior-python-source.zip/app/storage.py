"""Application-owned SQLite transactions and three synthetic test accounts."""

from contextlib import contextmanager
from pathlib import Path

from sqlalchemy import create_engine, event
from sqlalchemy.orm import Session
from werkzeug.security import generate_password_hash

from .models import Base, User
from .ports import NullObservation


class Store:
    """Own persistence; serialize state and permission writes with BEGIN IMMEDIATE."""

    def __init__(self, directory: Path):
        """Open a project-local SQLite file and initialize application-owned schema.

        Args:
            directory: Private runtime data directory, separate from source.
        """
        self.directory = Path(directory)
        self.bo_probe = NullObservation()
        self.directory.mkdir(parents=True, exist_ok=True)
        self.path = self.directory / "team.sqlite3"
        self.engine = create_engine("sqlite:///" + self.path.as_posix(), connect_args={"timeout": 30})
        event.listen(self.engine, "connect", self.configure_connection)
        Base.metadata.create_all(self.engine)
        with self.transaction() as session:
            for user_id, name, editor in (("alice", "Alice", False), ("bob", "Bob", False), ("casey", "Casey", True)):
                if session.get(User, user_id) is None:
                    session.add(User(id=user_id, name=name, editor=editor, password_hash=generate_password_hash("demo-" + user_id + "-123")))

    @staticmethod
    def configure_connection(connection, record):
        """Enable foreign keys and bound lock waiting on each native connection.

        Args:
            connection: Actual SQLite DBAPI connection.
            record: SQLAlchemy connection-pool record.
        """
        connection.execute("PRAGMA foreign_keys=ON")
        connection.execute("PRAGMA busy_timeout=30000")

    @contextmanager
    def transaction(self):
        """Expose native work and commit acknowledgement to the optional neutral port."""
        with self.bo_probe.bo_transaction(self._transaction()) as session:
            with self.bo_probe.bo_query_scope(write=True):
                yield session
                session.flush()

    @contextmanager
    def _transaction(self):
        """Commit domain changes and transition journals atomically, or roll back both."""
        with Session(self.engine, expire_on_commit=False) as session:
            session.connection().exec_driver_sql("BEGIN IMMEDIATE")
            try:
                yield session
                session.commit()
            except BaseException:
                session.rollback()
                raise

    @contextmanager
    def read(self):
        """Read current application rows without acquiring a write transaction."""
        with self.bo_probe.bo_query_scope():
            with Session(self.engine, expire_on_commit=False) as session:
                yield session

