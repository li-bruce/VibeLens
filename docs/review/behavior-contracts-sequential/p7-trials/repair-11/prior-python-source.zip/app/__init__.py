"""Team file sharing application."""
