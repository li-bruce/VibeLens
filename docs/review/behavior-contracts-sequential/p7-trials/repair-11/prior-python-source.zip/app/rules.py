"""Project-owned rule execution over explicitly acquired native facts."""

from collections import deque
from copy import deepcopy
from pathlib import Path
import hashlib
import json
import uuid

from .permissions import same_identity


class Rules:
    """Execute the shared Boolean declaration used by the actual business service."""

    def __init__(self, root: Path):
        """Load the application rule declaration without importing observer tooling.

        Args:
            root: Native application source root.
        """
        self.root = root
        self.definition = json.loads((root / "bo_stategraph/project.json").read_text(encoding="utf-8"))["model"]["policy"]
        self.nodes = {item["id"]: item for item in self.definition["nodes"]}
        self.operations = {item["id"]: item for item in self.definition["operations"]}
        self.evaluations = deque(maxlen=512)
        self.callbacks = {"same_identity": same_identity}
        self.bindings = {}
        for predicate in self.definition["predicates"]:
            source = predicate["source"]
            self.bindings[predicate["id"]] = {**source, "file_sha256": hashlib.sha256((root / source["path"]).read_bytes()).hexdigest()}
        self.fingerprint = hashlib.sha256(json.dumps(self.definition, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode()).hexdigest()

    def evaluate(self, operation: str, inputs: dict, fact_revision: str) -> dict:
        """Return the real decision and visited expression facts from one native read basis.

        Args:
            operation: Registered business permission being evaluated.
            inputs: Explicit scalar facts acquired by the native service.
            fact_revision: Actual transaction or read-scope identity for this evaluation.
        """
        if operation not in self.operations or not fact_revision:
            raise ValueError("unknown_rule_or_read_basis")
        for name, value in inputs.items():
            expected = self.definition["inputs"].get(name)
            if not ((expected == "string" and type(value) is str) or (expected == "boolean" and type(value) is bool)):
                raise ValueError("invalid_rule_fact:" + name)
        trace, cache, diagnostics = [], {}, []

        def visit(identity):
            """Evaluate a declared dependency once within this check, retaining short circuits."""
            if identity in cache:
                return cache[identity]
            node = self.nodes[identity]
            operator, used, skipped, arguments = node["op"], [], [], {}
            status = "completed"
            if operator == "input":
                value = inputs.get(node["name"])
            elif operator == "constant":
                value = node["value"]
            elif operator == "predicate":
                for parameter, reference in node["arguments"].items():
                    arguments[parameter] = visit(reference)
                    if reference not in used:
                        used.append(reference)
                try:
                    value = None if any(item is None for item in arguments.values()) else self.callbacks[node["predicate"]](**arguments)
                except Exception as error:
                    value, status = None, "error"
                    diagnostics.append({"node": identity, "error": type(error).__name__})
            elif operator in ("all", "any", "not"):
                values = []
                for offset, reference in enumerate(node["inputs"]):
                    values.append(visit(reference))
                    used.append(reference)
                    if (operator == "all" and values[-1] is False) or (operator == "any" and values[-1] is True):
                        skipped = node["inputs"][offset + 1:]
                        break
                if operator == "not":
                    value = None if values[0] is None else not values[0]
                elif operator == "all":
                    value = False if False in values else None if None in values else True
                else:
                    value = True if True in values else None if None in values else False
            else:
                raise ValueError("unsupported_rule_operator:" + operator)
            if value is None and status != "error":
                status = "unknown"
            cache[identity] = value
            trace.append({"node": identity, "value": value, "status": status, "arguments": arguments, "used": used, "skipped": skipped})
            return value

        root = self.operations[operation]["root"]
        value = visit(root)
        result = {"schema": "bo-policy-evaluation/v1", "policy_revision": self.definition["revision"], "policy_hash": self.fingerprint, "check_id": uuid.uuid4().hex, "fact_revision": fact_revision, "operation": operation, "inputs": deepcopy(inputs), "bindings": self.bindings, "root": root, "value": value, "decision": "allow" if value is True else "deny" if value is False else "unknown", "trace": trace, "diagnostics": diagnostics}
        self.evaluations.append(result)
        return result
