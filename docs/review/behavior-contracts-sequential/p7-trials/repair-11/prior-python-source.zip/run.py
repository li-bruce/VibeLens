"""Launch the local team file-sharing service."""

import argparse
from pathlib import Path

from app.web import create_app


def main():
    """Start the native service with optional, failure-isolated observation wiring."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8875)
    parser.add_argument("--data-dir", type=Path)
    parser.add_argument("--no-worker", action="store_true")
    parser.add_argument("--observe", choices=("on", "off", "fault"), default="on")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    observation = None
    if args.observe != "off":
        try:
            from integrations.bo_runtime import BOObservation
            observation = BOObservation(root, args.observe)
        except (ImportError, OSError, ValueError, KeyError) as error:
            print("Observation unavailable:", type(error).__name__)
    app = create_app(root, args.data_dir, not args.no_worker, observation)
    app.run(host="127.0.0.1", port=args.port, threaded=True, use_reloader=False)


if __name__ == "__main__":
    main()
