"""Independently compare frozen real recordings with persisted SQL/file bytes."""
from contextlib import closing
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import zipfile

RUN = Path(__file__).resolve().parent
APP = RUN.parents[2]
PACK = APP.parent / "atomic-catalog-skills/vibelens"
UNIFIED = APP / "review/runtime/unified-1795184762"
load = lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
sha = lambda b: hashlib.sha256(b).hexdigest()
sys.path.insert(0, str(PACK / "scripts"))
from bo_observer.model_io import read_model
from bo_observer.workflow.observation_requirements import invocation_closure

model = read_model(APP / "bo_stategraph/project.json", project_root=APP)
seal = load(RUN / "normal-stop-original-seal.json")
build = seal["build_id"]
trials = load(UNIFIED / "artifacts/browser-trials.json")
acceptance = load(UNIFIED / "artifacts/browser-acceptance.json")
archive = zipfile.ZipFile(RUN / "normal-stop-original-evidence.zip")


def database(image):
    connection = sqlite3.connect(":memory:")
    connection.deserialize(image)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA query_only=ON")
    return connection


sql_modes = []
for mode, trial in trials["modes"].items():
    root = Path(trial["data_root"])
    filename = root / "db/application.sqlite"
    image = archive.read("var/db/application.sqlite") if mode == "on" else filename.read_bytes()
    with closing(database(image)) as connection:
        file = dict(connection.execute("SELECT * FROM files WHERE id=?", (trial["fixture_file_id"],)).fetchone())
        task = dict(connection.execute("SELECT * FROM tasks WHERE file_id=? AND requester_id='alice' ORDER BY created_at DESC LIMIT 1", (file["id"],)).fetchone())
    assert task["status"] == "ready" and task["authorized_at_submission"] == 1
    source, prepared = Path(file["storage_path"]), Path(task["prepared_path"])
    assert source.is_relative_to(root) and prepared.is_relative_to(root)
    assert sha(source.read_bytes()) == sha(prepared.read_bytes()) == file["sha256"] == task["sha256"] == trials["sha256"]
    sql_modes.append({"mode": mode, "database_sha256": sha(image), "file_id": file["id"], "task_id": task["id"], "requester_id": task["requester_id"], "authorization": task["authorized_at_submission"], "status": task["status"], "file_sha256": file["sha256"]})
assert len({r["file_sha256"] for r in sql_modes}) == 1

with closing(database(archive.read("var/db/application.sqlite"))) as connection:
    tasks = {r["id"]: dict(r) for r in connection.execute("SELECT * FROM tasks")}
    files = {r["id"]: dict(r) for r in connection.execute("SELECT * FROM files")}
    sessions = {r["trace_id"]: dict(r) for r in connection.execute("SELECT trace_id,user_id,status,revision FROM sessions")}
    grants = {r["file_id"] + "/" + r["recipient_id"]: dict(r) for r in connection.execute("SELECT * FROM grants")}
    announcements = {r["id"]: dict(r) for r in connection.execute("SELECT * FROM announcements")}

records, latest = [], {}
for item in seal["recordings"]:
    record = load(UNIFIED / ("independent-recording-" + item["id"] + ".json"))
    events = record["events"]
    assert record["build_id"] == record["context"]["manifest"]["build_id"] == build
    assert all(e["build_id"] == build and e["project_id"] == model["project_id"] for e in events)
    closure = invocation_closure({"runs": [{"case": record["id"], "mode": "on", "events": events}]}, required=True, model=model)
    assert closure["valid"], closure
    by_id = {e["id"]: e for e in events}
    request_links = []
    for request in [e for e in events if e["node"] == "request_download" and e["phase"] == "enter"]:
        returned = next(e for e in events if e["node"] == "request_download" and e["phase"] == "return" and e["call_id"] == request["call_id"])
        task = tasks[returned["outputs"]["task_id"]]
        assert task["file_id"] == request["inputs"]["file_id"] and task["requester_id"] == request["inputs"]["actor_id"]
        assert task["authorized_at_submission"] == 1
        commit = next(e for e in events if e["node"] == "task_commit" and e["phase"] == "enter" and e["parent_event_id"] == request["id"])
        terminal = next(e for e in events if e["node"] == "task_commit" and e["phase"] == "return" and e["call_id"] == commit["call_id"])
        assert commit["inputs"]["task_id"] == task["id"]
        assert terminal["outputs"]["committed"] is True and terminal["outputs"]["transaction_id"] == commit["inputs"]["transaction_id"] == returned["outputs"]["transaction_id"]
        http = next(e for e in events if e["node"] == "api_request" and e["phase"] == "enter" and e["trace"]["trace_id"] == request["trace"]["trace_id"] and e["trace"]["span_id"] == request["trace"]["parent_span_id"])
        response = next(e for e in events if e["node"] == "api_request" and e["phase"] == "return" and e["call_id"] == http["call_id"])
        assert response["outputs"]["status"] == 202 and response["outputs"]["completed"] is True
        request_links.append({"http_call": http["call_id"], "native_call": request["call_id"], "transaction": commit["call_id"], "task": task["id"], "requester": task["requester_id"]})
    frames = record["runtime_frames"]["frames"]
    for frame in frames:
        event = by_id[frame["event_id"]]
        assert frame["build_id"] == build and frame["run_id"] == event["run_id"]
        for cfg in frame["machine"]["configurations"]:
            ident, native = cfg["state_model_id"], cfg["native_instance_id"]
            assert ident in model["machines"] and cfg["run_build_id"] == build
            assert native == event["inputs"]["instance_id"]
            assert cfg["attempt"] == event["attempt"]
            assert cfg["snapshot_instance"] == "model-instance:" + ident + ":" + frame["run_id"] + ":" + native
            latest[(ident, native)] = cfg
    records.append({"id": record["id"], "events": len(events), "closed_calls": closure["closed_calls"], "closure_errors": closure["errors"], "frames": len(frames), "attempts": sorted({e["attempt"] for e in events}), "entities": sorted({e["entity"] for e in events}), "producers": sorted({e["producer_id"] for e in events}), "request_sql_http_links": request_links})

objects = []
for (ident, native), cfg in latest.items():
    row = {"download_task": tasks, "session": sessions, "grant": grants, "announcement": announcements}[ident][native]
    state = ("active" if row["active"] else "inactive") if ident == "grant" else row["status"]
    assert cfg["phase"] == state and cfg["state_revision"] == row["revision"]
    for name, value in cfg["context"].items():
        assert value == (bool(row[name]) if name == "authorized_at_submission" else row[name])
    objects.append({"model": ident, "instance": native, "state": state, "revision": row["revision"]})

bob_tasks = [r for r in tasks.values() if r["requester_id"] == "bob" and files[r["file_id"]]["name"].startswith("GUI_acceptance_483355a5_")]
assert len(bob_tasks) == 1
bob = bob_tasks[0]
assert bob["status"] == "ready" and bob["authorized_at_submission"] == 1 and grants[bob["file_id"] + "/bob"]["active"] == 0
prepared = Path(bob["prepared_path"]).read_bytes()
assert all(Path(p).read_bytes() == prepared for p in acceptance["repeat_downloads"])
assert sha(prepared) == bob["sha256"] == files[bob["file_id"]]["sha256"]
assert all(hashlib.sha256((APP / n).read_bytes()).hexdigest() == h for n, h in seal["record_file_sha256"].items())
result = {"targeted_audit_valid": True, "scope": "Unmodified raw recording lifecycle and typed identity/frame links; independent persisted SQLite image/file bytes. Does not override failed full verification or adapt its input.", "build_id": build, "records": records, "persisted_modes": sql_modes, "latest_model_objects_at_second_stop": objects, "bob_admitted_ready_after_revoke_and_repeat_bytes_match": True, "bob_prepared_sha256": sha(prepared), "original_record_files_unchanged": True, "sql_method": "Independent Python SQLite query-only in-memory deserialize of frozen actual persisted image; no native file connection retained.", "full_verify_valid": False, "remaining_active_or_ready_states": "Registered state residence is retained; physical invocation lifecycles close. No consumed state or fabricated per-object attempt is introduced."}
(RUN / "independent-recording-audit.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"targeted_audit_valid": True, "records": [{"id": r["id"], "closed_calls": r["closed_calls"], "frames": r["frames"]} for r in records], "sql_model_objects": len(objects), "file_hashes_and_repeat_bytes_match": True, "original_records_unchanged": True}, ensure_ascii=False))
