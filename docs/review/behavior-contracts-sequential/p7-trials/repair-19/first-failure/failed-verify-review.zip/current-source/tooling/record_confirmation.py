"""Record the actual prior review through canonical VibeLens commands."""
import json
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
skill = Path(sys.argv[1])
def run(action, *args):
    command = [sys.executable, "-B", str(skill / "scripts/bo_concepts.py"), action, "--root", str(root), *args]
    completed = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", env={**__import__("os").environ, "PYTHONIOENCODING": "utf-8"})
    value = json.loads(completed.stdout)
    if completed.returncode:
        raise RuntimeError(json.dumps(value))
    return value

snapshot = run("snapshot", "--scope", "*")
visible = [n["id"] for network in json.loads((root / "discovery.json").read_text(encoding="utf-8"))["networks"] for n in network["nodes"]]
explained = [ref for ref in snapshot["scope"] if ref not in visible]
run("present", "--scope", "*", "--visible", *visible, "--explained", *explained, "--sources", "A_REVIEW_1", "--id", "P_REVIEW_1", "--out", "review/presentation-1.json")
result = run("confirm", "--stage", "before_implementation", "--scope", "*", "--presentation", "P_REVIEW_1", "--sources", "U4", "--id", "C_REVIEW_1", "--out", "review/confirmation-1.json")
print(json.dumps({"valid": result["valid"], "confirmed": "C_REVIEW_1", "scope_count": len(snapshot["scope"])}))
