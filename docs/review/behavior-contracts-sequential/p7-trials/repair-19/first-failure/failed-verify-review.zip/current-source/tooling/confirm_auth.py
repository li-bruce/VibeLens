"""Preserve the directly authorized authentication scope using canonical commands."""
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
command = [sys.executable, "-B", str(Path(sys.argv[1]) / "scripts/bo_concepts.py")]
def call(action, *args):
    result = subprocess.run([*command, action, "--root", str(root), *args], capture_output=True, text=True, encoding="utf-8", env={**os.environ,"PYTHONIOENCODING":"utf-8"})
    value = json.loads(result.stdout)
    if result.returncode:
        raise RuntimeError(value)
    return value
snapshot = call("snapshot", "--scope", "business-network:authentication")
call("present", "--scope", "business-network:authentication", "--explained", *snapshot["scope"], "--sources", "A_AUTH_1", "--id", "P_AUTH_DIRECT", "--out", "review/auth-direct-presentation.json")
value = call("confirm", "--stage", "before_implementation", "--scope", "business-network:authentication", "--presentation", "P_AUTH_DIRECT", "--sources", "U4_AUTH", "--id", "C_AUTH_DIRECT", "--out", "review/auth-confirmation.json")
print(json.dumps({"valid":value["valid"],"confirmation":"C_AUTH_DIRECT","authority":"explicit user instruction U4"}))
