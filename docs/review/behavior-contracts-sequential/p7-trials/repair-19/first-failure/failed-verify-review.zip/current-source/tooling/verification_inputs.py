"""Maintain independent native/observed correspondence and confirmed business assertions."""
import json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
def write(name,value): (root/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
d=json.loads((root/"discovery.json").read_text(encoding="utf-8"))
checks=[]
for expectation in d["expectations"]:
    for i,assertion in enumerate(expectation["then"]):
        checks.append({"id":expectation["id"]+"-"+str(i),"requirement":"R_AUTH" if "logout" in expectation["id"] else "R_BOARD" if "announcement" in expectation["id"] or "editor" in expectation["id"] else "R_DOWNLOAD","case":"workflow","path":assertion["path"],"equals":assertion["equals"]})
extra={
 "early_origin_status":403,"early_origin_native_login":0,
 "unrelated_file_count":0,"recipient_reshare_status":403,"editor_file_status":403,
 "collect_after_revoke_status":200,"new_task_after_revoke_status":403,"other_requester_collect_status":403,
 "repeat_collect_status":200,"malformed_json_status":400,"logout_old_cookie_status":401,
 "native_task_committed":True
}
for key,value in extra.items():checks.append({"id":"native-"+key,"requirement":"R_AUTH" if "logout" in key or "json" in key or key.startswith("early_origin") else "R_DOWNLOAD","case":"workflow","path":[key],"equals":value})
prior=json.loads((root/"acceptance.json").read_text(encoding="utf-8")) if (root/"acceptance.json").exists() else {}
merged={c["id"]:c for c in prior.get("checks",[])}
merged.update({c["id"]:c for c in checks})
for key,value in {"persist_http_status":500,"task_count":0,"sql_read_failed":True,"sql_write_failed":True}.items():
    merged["storage-"+key]={"id":"storage-"+key,"requirement":"R_DOWNLOAD","case":"storage_failure","path":[key],"equals":value}
write("acceptance.json",{"description":"Independent expected outcomes from actual confirmed statements and native/HTTP boundaries; no expected value is taken from a graph frame.","checks":list(merged.values()),"model_checks":prior.get("model_checks",[])})
fields=[]
for key in ["state","revision","build_id","state_model_id"]:
    fields.append({"id":key,"node":"request_download","actual":[key],"mapped":[key]})
for model in d["state_models"]:
    for key in model["context"]:
        fields.append({"id":model["id"]+"-"+key,"node":"native_state:"+model["id"]+":"+model["initial"],"state_model_id":model["id"],"actual":["context",key],"mapped":["context",key]})
prior_mapping=json.loads((root/"mapping.json").read_text(encoding="utf-8")) if (root/"mapping.json").exists() else {}
contexts={item["id"]:item for item in prior_mapping.get("context_fields",[])}
index=json.loads((root/"review/native-node-index.json").read_text(encoding="utf-8"))
for node in [*index["actions"],*index["api"]]:
    for phase in ["enter","return"]:
        for field in ["trace_id","span_id","trace_flags"]:
            ident="sdk-"+node+"-"+phase+"-"+field
            contexts[ident]={"id":ident,"node":node,"phase":phase,"case":"workflow","source":"tests/native_reader.mjs::readSdkContext","actual":[field],"mapped":["trace",field],"each":{"collection":["native_sdk",node,phase],"actual_key":[["invocation_id"]],"mapped_key":[["call_id"]]}}
write("mapping.json",{"schema":"bo-mapping/v2","state_models":[m["id"] for m in d["state_models"]],"cases":["workflow","state_lifecycles","storage_failure","browser"],"modes":["on","off","fault"],"source":{"path":"tests/native_reader.mjs","symbol":"readInstances"},"actual_collection":["authority_snapshot","instances"],"actual_id":["id"],"actual_model_id":["state_model_id"],"fields":fields,"export":{"case":"workflow","mode":"on"},"context_fields":list(contexts.values())})
sync=json.loads((root/"sync.json").read_text(encoding="utf-8"))
sync.update({"probe_callees":["probe.record","probe.startSpan"],"required_probes":[{"symbol":"integrations/bo_observe.mjs::bo_create.callback","node":"policy_facts","phase":"read"}],"required_runtime_probes":[{"case":"workflow","node":"policy_facts","phase":"read"},{"case":"workflow","node":"task_commit","phase":"return"},{"case":"workflow","node":"collect_download","phase":"return"},{"case":"workflow","node":"api_login","phase":"return"}]})
write("sync.json",sync)
print(json.dumps({"independent_assertions":len(checks),"mapping_fields":len(fields)}))
