"""Add precise source parameter explanations to authored mapped declarations."""
import json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
index=json.loads((root/"review/source-index.json").read_text(encoding="utf-8"))
descriptions={
"req":("object","Native Express request with the matched route, current cookie and operation inputs."),
"res":("object","Native Express response used to return the actual status and resource."),
"next":("Function","Express continuation invoked after successful upload authentication."),
"actor":("object","Current authenticated native member; its id determines file/task ownership."),
"username":("string","Username submitted for real password authentication."),
"password":("string","Submitted password; observation selects only whether it was supplied."),
"token":("string","Opaque current session cookie; observation selects only its presence."),
"fileId":("string","Stored file identity whose current uploader and recipient grant are read."),
"taskId":("string","Identity of an already submitted download preparation task."),
"recipientId":("string","Named colleague receiving or losing access to the selected file."),
"active":("boolean","Requested grant state: true grants sharing; false revokes it."),
"name":("string","Original upload filename, bounded to 180 characters and kept separate from its storage name."),
"bytes":("Buffer","Uploaded bytes, bounded to 50 MB by HTTP; only byte count is observed."),
"title":("string","Announcement title, bounded to 120 characters."),
"body":("string","Announcement content, bounded to 8000 characters; observation selects its length."),
"action":("string","Selected announcement mutation: edit or delete."),
"operation":("string","Native permission operation whose actual decision is being checked."),
"facts":("object","Actual scalar authorization facts acquired for this operation; no credentials or cookie values."),
"context":("object","Enclosing native operation context carrying its invocation identity."),
"model":("string","Native state-model identity: grant, download_task, announcement or session."),
"row":("object","Actual native allocation or stored row at the observed state boundary."),
"event":("?string","Actual transition event, or null for an initial allocation read."),
"before":("?string","State read before the native change, or null for initial allocation."),
"left":("string","First actual identity or enum value supplied by the native policy."),
"right":("string","Second actual identity or enum value supplied by the native policy.")
}
updates={}
for record in index["symbols"].values():
    path=record["path"];doc=record.get("documentation") or {}
    if path not in {"src/http.mjs","src/service.mjs","src/policy.mjs"} or doc.get("status")!="documented":continue
    tags=[]
    for p in record.get("parameters",[]):
        name=p["name"]
        if name in doc.get("parameters",{}):continue
        if name=="id":
            kind,description=("string","Model-qualified native instance identity.") if record["symbol"]=="FileService.state" else ("string","Identity of the author's selected announcement.")
        elif name in descriptions:kind,description=descriptions[name]
        else:continue
        tags.append(" * @param {"+kind+"} "+name+" "+description)
    if not tags:continue
    location=doc["source"]
    updates.setdefault(path,[]).append((location["line"]-1,location["end_line"],tags))
for path,changes in updates.items():
    target=root/path;lines=target.read_text(encoding="utf-8").splitlines()
    for start,end,tags in sorted(changes,reverse=True):
        indent=lines[start][:len(lines[start])-len(lines[start].lstrip())]
        original="\n".join(lines[start:end]).rstrip()
        if not original.endswith("*/"):raise ValueError("Unexpected source comment boundary")
        original=original[:-2].rstrip()
        lines[start:end]=[original,*[indent+tag for tag in tags],indent+" */"]
    target.write_text("\n".join(lines)+"\n",encoding="utf-8")
print(json.dumps({"documented_files":list(updates),"updated_declarations":sum(map(len,updates.values()))}))
