"""Run native scenarios and canonical state-graph queries without executing business logic in Python."""
import copy
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
SKILL=Path(os.environ.get("VIBELENS_SKILL",ROOT.parent/"node-migration-final-skills/vibelens"))
sys.path.insert(0,str(SKILL/"scripts"))
from bo_observer.model_io import read_model
from behavior_model import capture
from bo_stategraph import BOStateGraph
from bo_observer.policy.definition import fingerprint

def read(name):return json.loads((ROOT/name).read_text(encoding="utf-8-sig"))
def write(name,value):
    p=ROOT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
def bo_machine(native):
    return {"configurations":[{"snapshot_instance":row["id"],"attempt":row["id"],"state_model_id":row["state_model_id"],"phase":row["state"],"state_revision":row["revision"],"context":copy.deepcopy(row["context"]),"run_build_id":row["build_id"],"source_status":"current"} for row in native["instances"]],"current":None,"journal":[]}
model=read_model(ROOT/"bo_stategraph/project.json",project_root=ROOT)
manifest=capture(ROOT,model)
write("manifest.json",manifest)
write("review/native-test-settings.json",{"build_id":manifest["build_id"],"policy_hash":fingerprint(model["policy"])})
result=subprocess.run(["node","tests/observe.mjs"],cwd=ROOT,capture_output=True,text=True,encoding="utf-8",timeout=180)
(ROOT/"review/runtime/native-command.log").write_text(result.stdout+result.stderr,encoding="utf-8")
if result.returncode:
    print(json.dumps({"valid":False,"native_command_failed":result.returncode,"detail":(result.stderr or result.stdout)[-5000:]}))
    raise SystemExit(result.returncode)
payload=read("review/runtime/native-runs.json")
# Browser cases are admitted only from retained, real GUI runs on this exact
# application build. A missing/stale trial remains a canonical mapping gap.
browser_path=ROOT/"review/runtime/browser-capture.json"
if browser_path.exists():
    browser=read("review/runtime/browser-capture.json")
    if browser.get("build_id")==manifest["build_id"]:
        payload["runs"].extend(browser["runs"])
    else:payload["browser_evidence"]="stale_build"
else:payload["browser_evidence"]="not_run"
graph=BOStateGraph(model,build_id=manifest["build_id"],mode="observe")
payload["mapping_checks"]=[]
for run in payload["runs"]:
    machine=bo_machine(run["authority_snapshot"])
    instances=graph.bo_instances(machine)
    run["projection"]={"build_id":manifest["build_id"],"machine":machine,"instances":instances}
    # The independent side comes from the native SQLite reader, never an observation frame.
    for row in run["authority_snapshot"]["instances"]:
        observed=next(item["observed"] for item in instances if item["observed"]["instance_id"]==row["id"] and item["observed"]["state_model_id"]==row["state_model_id"])
        for field in ["state","revision","build_id","state_model_id","context"]:
            payload["mapping_checks"].append({"id":"/".join([run["case"],run["mode"],row["state_model_id"],row["id"],field]),"case":run["case"],"mode":run["mode"],"node":"request_download","actual":copy.deepcopy(row[field]),"mapped":copy.deepcopy(observed[field]),"source":"tests/native_reader.mjs::readInstances","projection":"BOStateGraph.bo_instances"})
selected=payload["runs"][0]
payload["stategraph_export"]=graph.bo_export(runtime={"machine":selected["projection"]["machine"]})
write("review/runtime/observations.json",payload)
print(json.dumps(payload,ensure_ascii=False))
