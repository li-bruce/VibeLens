"""Add technical requirement/source/test links to resolved original business decisions."""
import json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
target=root/"discovery.json"
doc=json.loads(target.read_text(encoding="utf-8"))
links={
 "D_ACCESS":(["R_FILES","R_DOWNLOAD"],["share_file","revoke_share","view_file"],["native-recipient_reshare_status","native-unrelated_file_count"]),
 "D_REVOKE":(["R_DOWNLOAD"],["request_download","collect_download","task_commit"],["approved-task-survives-revoke-0","approved-task-survives-revoke-1"]),
 "D_BOARD":(["R_BOARD"],["publish_announcement","edit_announcement","delete_announcement"],["editor-own-announcement-only-0"]),
 "D_IDENTITY":(["R_FILES","R_DOWNLOAD"],["share_file","request_download","collect_download"],["native-other_requester_collect_status"]),
 "D_STORAGE":(["R_DOWNLOAD"],["request_download","task_commit"],["native-native_task_committed"]),
 "D_COLLECTION":(["R_DOWNLOAD"],["collect_download","native_state:download_task:ready"],["repeat-collection-keeps-ready-0","repeat-collection-keeps-ready-1","repeat-collection-keeps-ready-2"])
}
for decision in doc["decisions"]:
    requirements,nodes,checks=links[decision["id"]]
    decision["links"]={"requirements":requirements,"model_nodes":nodes,"checks":checks}
target.write_text(json.dumps(doc,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"linked_decisions":len(links)}))
