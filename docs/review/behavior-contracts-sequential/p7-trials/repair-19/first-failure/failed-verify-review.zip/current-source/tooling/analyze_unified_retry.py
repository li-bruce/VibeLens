"""Summarize the one authorized provider-unified recording retry without rerunning it."""
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import statistics
from urllib.parse import urlsplit
from zipfile import ZipFile, ZIP_DEFLATED

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'review/runtime'
RUN=OUT/'unified-1795149938'
read=lambda path:json.loads(path.read_text(encoding='utf-8'))
save=lambda path,value:path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
life=read(RUN/'lifecycle.json')
result=read(RUN/'browser-acceptance.json')
identity=result['recordings'][0]['id']
record=read(RUN/('independent-recording-'+identity+'.json'))
network=[json.loads(line) for line in (RUN/'native-fetch.jsonl').read_text(encoding='utf-8').splitlines() if line]
health=[json.loads(line) for line in (RUN/'native-idle.jsonl').read_text(encoding='utf-8').splitlines() if line]
waiting=[row for row in health if row['stage']=='before-stop-'+identity]
wait=next(row for row in result['idle_waits'] if row['stage']=='before-stop-'+identity)
requests={row['request_id']:row for row in network if row['event']=='request'}
failures=[row for row in network if row['event']=='failure']
endpoint=lambda row:urlsplit(row['endpoint']).path
stats={}
for path in sorted({endpoint(row) for row in network}):
    submitted=[row for row in requests.values() if endpoint(row)==path]
    returned=[row for row in network if row['event']=='response' and endpoint(row)==path]
    sizes=[row['body_bytes'] for row in submitted]
    latency=sorted(row['elapsed_ms'] for row in returned)
    receipts=[row for row in network if row['event']=='receipt' and endpoint(row)==path]
    stats[path]={'requests':len(submitted),'responses':len(returned),'status_counts':dict(Counter(str(row['status']) for row in returned)),
        'failed_attempts':sum(endpoint(row)==path for row in failures),'bytes':{'min':min(sizes),'median':statistics.median(sizes),'max':max(sizes)},
        'response_header_ms':{'median':statistics.median(latency),'p95':latency[int(.95*(len(latency)-1))],'max':max(latency)},
        'complete_receipt_bodies':sum(row['receipt_body_complete'] for row in receipts),'receipt_bodies_omitted_for_unexpected_shape':sum(not row['receipt_body_complete'] for row in receipts)}
    if path.endswith('/batch'):stats[path]['summed_items_including_retries']=sum(row['batch_items'] for row in submitted)

grouped=defaultdict(list)
for row in failures:
    if row.get('id'):grouped[row['id']].append(row)
lookup={row['id']:row for row in record['events']}
item_errors=[]
for item,attempts in grouped.items():
    if len(attempts)!=2:continue
    accepted=[row for row in network if row['event']=='response' and row.get('id')==item]
    if accepted:continue
    event=lookup.get(item)
    item_errors.append({'id':item,'node':attempts[0]['node'],'source_seq':attempts[0]['seq'],'phase':attempts[0]['phase'],
        'attempts':attempts,'retained_in_recording':event is not None,'native_observed_at':event['observed_at'] if event else None})

native_producer=life['pre_cleanup_native_health']['producer_id']
native=[row for row in record['events'] if row['producer_id']==native_producer]
sequences=sorted(row['source_seq'] for row in native)
coverage=sequences==list(range(min(sequences),max(sequences)+1))
analysis={'diagnostic_only':True,'run_id':life['run_id'],'build_id':life['build_id'],'recording_id':identity,'profiled_viewer':life['profiled_viewer'],
    'failure_stage':'First recording stop: pending-zero gate passed, then strict stopped-status assertion failed because producer transport errors persisted.',
    'second_recording_started':False,'three_mode_gui_comparison_completed':False,'whole_candidate_round_passed':False,
    'provider_consistent':len(set(life['browser_mode_providers'].values()))==1,'served_sdk':life['served_sdk'],
    'record':{'status':record['status'],'events':len(record['events']),'gaps':record['gaps'],'settlement':record['producer_settlement'],'final_health':record['final']['health']},
    'native_delivery':{'events_retained':len(native),'first_source_seq':min(sequences),'last_source_seq':max(sequences),'contiguous_source_sequences':coverage,
        'production_start':min(row['observed_at'] for row in native),'production_end':max(row['observed_at'] for row in native)},
    'before_stop_wait':{'elapsed_ms':wait['elapsed_ms'],'samples':len(waiting),'first':waiting[0],'last':waiting[-1],
        'enqueued_values':sorted({row['health']['enqueued'] for row in waiting}),'submitted_values':sorted({row['health']['queue_submitted'] for row in waiting}),
        'error_values':sorted({row['health']['errors'] for row in waiting}),'page':wait['page']},
    'exhausted_single_item_attempts':item_errors,'http':stats,'stop_receipts':result['stop_receipts'],
    'exact_stack':result['exception_traceback'],'load_context':life['load_context'],'load_context_source':life['load_context_source'],
    'liveness':[{'label':row['label'],'pre_cleanup_exit_code':row['pre_cleanup_exit_code'],'termination':row['termination']} for row in life['children']],
    'limits':['No request-to-server-function profile was collected; exact lock owner/CPU cause is unresolved.',
        'All 53 batch response bodies and 26 single-event response bodies were retained. Eight snapshot bodies had unexpected receipt keys and were omitted by the safe-shape audit; their status, size and SHA256 remain. The actual stop response body is complete.',
        'This run starts with an additional persisted browser fixture versus the earlier run; it is an acceptance retry, not a controlled throughput comparison.',
        'The earlier 816-event successful recording remains sealed under its original build; it is not replaced or relabeled.']}
save(RUN/'analysis.json',analysis)
failed_nodes=', '.join(str(item['source_seq'])+' '+item['node']+'/'+item['phase'] for item in item_errors)
report=f"""# Provider-unified retry: finite queue drained, transport gate failed

Build `{life['build_id']}`; recording `{identity}`. One authorized real-browser retry, no Python profiler, original deadlines/retries/gates. The coordinating chat reported full root regression and clean export finished before launch; other host load was not isolated.

All three mode children inherited the same candidate provider. Actual served runtime/capture SDK hashes match candidate bytes. The first on-mode login/task/real-download byte comparison completed, but its stop returned **interrupted**, so formal browser_on evidence and the remaining off/fault GUI and second recording were not reached.

The pending-zero wait passed after {wait['elapsed_ms']/1000:.2f} seconds, with {len(waiting)} retained health samples. Enqueued stayed exactly {analysis['before_stop_wait']['enqueued_values']} and submitted stayed {analysis['before_stop_wait']['submitted_values']} throughout. Pending fell from {waiting[0]['health']['pending']} to zero; completed reached965/965. The active page was Team files. These are direct measurements of a finite existing queue draining, not continuing business production or an expired35-second gate.

The persistent native transport error count reached3. Exactly three single envelopes exhausted both original attempts: **{failed_nodes}**. Their full IDs, sizes, request hashes and both attempts are in analysis.json/native-fetch.jsonl. All three IDs nevertheless occur in the actual recording: the server accepted them, while the producer did not receive a timely success receipt. The recording retains {len(native)} native events with contiguous source sequences {min(sequences)}–{max(sequences)}, plus12 browser events. This does not erase the producer errors or satisfy the strict recording gate.

The network audit contains15 failed attempts (7 single-event and8 batch attempts). All617 returned responses were200. Several failed batches retried or fell back using the exact same member IDs and hashes. All53 batch and26 single-event response bodies were retained and carry accepted receipts; complete member lists, bytes and timing are available. Eight snapshot receipt bodies were omitted because the diagnostic safe-shape whitelist did not include their keys; status/size/hash remain. These were successful snapshot responses, not the three exhausted event items.

The **original stop POST** returned HTTP200 with status interrupted,936 events, one transport-error gap and a complete636-byte raw body. Its SHA256 is `{result['stop_receipts'][0]['body_sha256']}`. Final settlement is flushed true,977/977/pending0; native health remains errors3/dropped0. The assertion failed at stop_record's stopped-status check, after this successful drain. The exact stack is preserved in browser-acceptance.json and analysis.json. All owned services were alive before normal parent cleanup.

No second recording or follow-up performance retry was started. No health reset, timeout increase, event removal or failure-to-success conversion occurred. The next framework investigation must explain why even the880-byte login entry at the queue head exhausted its receipt deadline; large batch payload size or ongoing task polling alone cannot explain this observed failure. The exact slow server function/lock remains unmeasured in this normal run.
"""
(RUN/'DIAGNOSIS.md').write_text(report,encoding='utf-8')
archive=OUT/'provider-unified-failure-1795149938.zip'
seal=OUT/'provider-unified-failure-1795149938-seal.json'
if not archive.exists():
    paths=sorted(path for path in RUN.rglob('*') if path.is_file())
    paths += [ROOT/'review/runtime/provider-unified-recording-1795149938-command.log',ROOT/'var/db/application.sqlite',Path(__file__)]
    with ZipFile(archive,'x',compression=ZIP_DEFLATED) as target:
        for path in paths:target.write(path,path.relative_to(ROOT).as_posix())
    save(seal,{'diagnostic_only':True,'whole_candidate_round_passed':False,'archive':str(archive),'sha256':sha(archive),'files':{path.relative_to(ROOT).as_posix():{'sha256':sha(path),'bytes':path.stat().st_size} for path in paths}})
print(json.dumps({'diagnosis':str(RUN/'DIAGNOSIS.md'),'queue_drained':True,'transport_errors':len(item_errors),'failed_sequences':[item['source_seq'] for item in item_errors],'native_sequence_coverage':coverage,'archive_sha256':sha(archive)},ensure_ascii=False))
