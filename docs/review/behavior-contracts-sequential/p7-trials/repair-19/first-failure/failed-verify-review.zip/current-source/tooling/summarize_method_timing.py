"""Join actual diagnostic HTTP attempts by transport tuple, without inventing matches."""
from collections import defaultdict
import json
from pathlib import Path
import sys
from urllib.parse import urlsplit


def rows(path):
    """Retain malformed/partial-line locations instead of silently discarding them."""
    parsed, errors = [], []
    for number, line in enumerate(path.read_text(encoding='utf-8').splitlines(), 1):
        try:
            parsed.append(json.loads(line))
        except ValueError:
            errors.append({'file': path.name, 'line': number})
    return parsed, errors


def ip(value):
    """Normalize the IPv4-mapped representation of this loopback transport."""
    return (value or '').removeprefix('::ffff:')


def main():
    """Summarize an existing run only; this command never starts a service."""
    root = Path(sys.argv[1])
    client, client_errors = rows(root/'native-fetch.jsonl')
    server, server_errors = rows(root/'viewer-method-timing.jsonl')
    requests = {row['request_id']: row for row in client if row['event'] == 'request'}
    send = defaultdict(list)
    for row in client:
        if row['event'] == 'transport_send_headers':
            send[row['request_id']].append(row)
    by_transport = defaultdict(list)
    ends = {}
    for row in server:
        if row['event'] == 'http_start':
            value = row['http']
            key = (ip(value['peer_address']), value['peer_port'], value['server_port'],
                value['connection_request_index'], value['method'], value['path'])
            by_transport[key].append(row)
        elif row['event'] == 'http_end':
            ends[row['http']['request_id']] = row
    starts = {row['call_id']: row for row in server if row['event'] == 'method_start'}
    calls, background, partial = defaultdict(list), [], []
    completed = set()
    for row in server:
        if row['event'] != 'method_end':
            continue
        start = starts.get(row['call_id'])
        if start is None:
            partial.append({'end_without_start': row['call_id']})
            continue
        completed.add(row['call_id'])
        value = {'call_id': row['call_id'], 'parent_call_id': row['parent_call_id'],
            'method': row['method'], 'thread_name': row['thread_name'],
            'start_ms': start['wall_ms'], 'end_ms': row['wall_ms'],
            'elapsed_ms': row['elapsed_ms'], 'exception_type': row['exception_type']}
        if row['http']:
            calls[row['http']['request_id']].append(value)
        else:
            background.append(value)
    partial += [{'start_without_end': key} for key in starts.keys()-completed]

    joined, unmatched = [], []
    for identity, request in requests.items():
        attempts = send.get(identity, [])
        if len(attempts) != 1:
            unmatched.append({'client_request_id': identity, 'reason': 'transport_send_count', 'count': len(attempts)})
            continue
        wire = attempts[0]
        key = (ip(wire.get('local_address')), wire.get('local_port'), wire.get('remote_port'),
            wire['connection_request_index'], request['method'], urlsplit(request['endpoint']).path)
        candidates = by_transport.get(key, [])
        if len(candidates) != 1:
            unmatched.append({'client_request_id': identity, 'reason': 'server_transport_match_count', 'count': len(candidates)})
            continue
        start = candidates[0]
        server_id = start['http']['request_id']
        end = ends.get(server_id)
        spans = sorted(calls.get(server_id, []), key=lambda value: value['start_ms'])
        binding = next((row for row in spans if row['method'] == 'GraphSession.binding'), None)
        outcome = [row for row in client if row.get('request_id') == identity and row['event'] in ('response', 'failure')]
        joined.append({'client_request_id': identity, 'server_request_id': server_id,
            'identity': {key: request[key] for key in ['endpoint', 'method', 'id', 'seq', 'evidence_id', 'batch_members', 'body_bytes'] if key in request},
            'client_start_ms': request['wall_ms'], 'undici_send_headers_ms': wire['wall_ms'],
            'server_dispatch_start_ms': start['wall_ms'], 'server_dispatch_end_ms': end['wall_ms'] if end else None,
            'before_send_ms': wire['wall_ms']-request['wall_ms'],
            'send_to_dispatch_ms': start['wall_ms']-wire['wall_ms'],
            'dispatch_to_binding_ms': binding['start_ms']-start['wall_ms'] if binding else None,
            'server_status': end['http']['status'] if end else None,
            'client_outcome': outcome, 'method_spans': spans})
    result = {'diagnostic_only': True, 'final_acceptance_performed': False, 'joined': joined,
        'unmatched': unmatched, 'background_spans': background, 'partial_method_pairs': partial,
        'malformed_lines': client_errors+server_errors,
        'limits': ['Transport joins require exactly one candidate; ambiguous port reuse or retries are not guessed.',
            'Dispatch-to-binding includes original body parsing, validation, session borrowing and lock waiting; it is not a direct mutex-wait measurement.',
            'Nested method durations overlap and must not be summed as independent end-to-end costs.',
            'sendHeaders is Undici\'s pre-write dispatch hook, not a measurement of bytes arriving on the wire.',
            'Instrumentation overhead is unmeasured. This diagnostic never changes a failed recording to accepted.']}
    (root/'method-timing-analysis.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'joined': len(joined), 'unmatched': len(unmatched), 'partial_pairs': len(partial), 'final_acceptance_performed': False}))


if __name__ == '__main__':
    main()
