"""Summarize completed diagnostics without changing recordings or acceptance gates."""
from collections import Counter
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'review/runtime'
cohorts=[('Old frozen provider','1795146229'),('View-lock candidate','1795146438')]
loaded=[]
correction={'recorded_at':datetime.now(timezone.utc).isoformat(),'source':'Subsequent coordination clarification from the user','correction':'repair05 regression had finished, but repair06 full regression was running during these cases (reported at about 73+ suites). The original lifecycle load_context saying Root regression finished is inaccurate. Keep the original lifecycle and load samples untouched. No isolated or low-load performance claim is supported.'}
for label,identity in cohorts:
    run=OUT/('unified-'+identity)
    (run/'load-context-correction.json').write_text(json.dumps(correction,indent=2),encoding='utf-8')
    analysis=json.loads((run/'transport-analysis.json').read_text(encoding='utf-8'))
    result=json.loads((run/'transport-result.json').read_text(encoding='utf-8'))
    life=json.loads((run/'lifecycle.json').read_text(encoding='utf-8'))
    loaded.append((label,identity,run,analysis,result,life))

text=['# Node observe transport diagnosis — 20 November 2026','',
'**Both compared recordings remain interrupted. This is fault comparison, not final acceptance.**',
'The application build stays `58c9af03b415b0cf60b7ccf696c633741498e844be4409a74069513a82aa730c`. Business, UI and project observation source bytes match the sealed old-provider files. Canonical plan/apply/check for the candidate returned valid with zero managed dependency changes; all eight JavaScript adapter files also match byte for byte. No installed package, validator, projector, timeout, required capture or failed recording was edited.',
'', '## Preserved failures and process ownership','',
'The original transport-failed recording is `9893c26c801f4c4387668768827f6e04`; its native health retained `TimeoutError` and its status remains interrupted. It did not retain a per-request audit, so its exact original failed request cannot be reconstructed retrospectively.',
'The later `ERR_CONNECTION_REFUSED` in `browser-acceptance-command.log` was a separate startup/readiness failure. It must not be used to explain the original in-recording timeout.',
'Every compared case was subsequently owned by `tooling/unified_browser_run.py`: the same parent starts viewer, app and browser/trial processes, waits for actual HTTP readiness, runs the case and cleans up only its child process trees. Completed cases show all services still alive immediately before intentional cleanup. A cleanup exit code from taskkill is labeled separately from a service exiting before cleanup.',
'', '## Workload, defaults and load limits','',
'The compared real UI sequence is login, create one preparation task, display its ready link, return to files, refresh once, wait up to 30 seconds for the native queue to settle, then click the real viewer Stop control. The graph stays open. App/viewer/browser share one owning process tree. There are no fabricated business events.',
'`BOProbe` keeps its default 1000 ms HTTP attempt deadline and two attempts per queued item. Capture-control RPC keeps its own unchanged 2000 ms deadline. Queue submission/completion, failed attempts and stop settlement are distinct measurements.',
'The raw load_context string was based on an earlier coordination message and is inaccurate for these runs. Separate `load-context-correction.json` files preserve the later clarification that repair06 regression was concurrent. Host samples and local monitoring are not an isolated benchmark. At least one candidate host-CPU sample exceeds 100%; those samples are invalid and are not used to prove load or a product defect. No raw sample is clamped or rewritten.',
'The file inventories differ by one real newly seeded fixture, and task/session counts also increase through actual operations. This is the same action sequence, not an identical-data latency benchmark.',
'', '## Results: backlog versus failed HTTP attempts','',
'| Cohort / run | Files/tasks/sessions before UI | Failed native HTTP attempts | Native errors after stop | Native pending after stop | Stop target/completed/pending | Status |',
'| --- | --- | ---: | ---: | ---: | --- | --- |']
for label,identity,run,a,r,life in loaded:
    h=r['after_stop_health'];s=r['producer_settlement'];c=r['native_data_cardinality']
    text.append(f"| {label} / {identity} | {c['files']}/{c['tasks']}/{c['sessions']} | {len(a['failures'])} | {h['errors']} | {h['pending']} | {s['target']}/{s['completed']}/{s['pending']} | {r['status']} |")
text+=['','A failed first HTTP attempt may recover on retry and therefore does not necessarily increment BOProbe.errors. Both failed attempts for the same observation increment the item-level transport error once. `queue_completed` also advances after a failed item; zero pending would not by itself prove success. Recording-boundary aggregate health and the subsequent native health query are retained separately because the queue continues moving.',
'','## Actual timed-out requests','',
'| Cohort | Observation node / phase / producer seq | Attempt elapsed ms | Endpoint | Request audit ID |','| --- | --- | ---: | --- | --- |']
for label,identity,run,a,r,life in loaded:
    for item in a['failures']:
        text.append(f"| {label} | `{item.get('node')}` / `{item.get('phase')}` / {item.get('seq')} | {item['elapsed_ms']:.2f} | `{item['endpoint']}` | `{item['request_id']}` |")
text+=['','The earlier unprofiled single-parent run `unified-1795145145` separately recorded three timed-out attempts: `list_tasks/return/227` once, and `policy:is_owner/decision/428` twice. Its raw request audit and interrupted recording `a616123956f741a3a994c98f682e1f09` are preserved. The initially reported zero failures was an intermediate read; the complete log established all three.',
'','## Measured calls and lock boundaries','',
'Times below come from completed calls in process-local Python 3.13 monitoring. Canonical functions are executed unchanged. They are diagnostic wall times with monitoring and concurrent load, not isolated speed claims.',
'','| Function | Old calls / median / max ms | Candidate calls / median / max ms |','| --- | --- | --- |']
names=['GraphSession.event','GraphSession.snapshot','GraphSession.binding','CodeGraph.refresh','overlay_model','read_names','BehaviorContext.view','BehaviorContext.last_verification']
for name in names:
    cells=[]
    for _,_,_,a,_,_ in loaded:
        value=next((value for key,value in a['function_statistics'].items() if key.endswith('::'+name)),None)
        cells.append(f"{value['calls']} / {value['median_ms']:.2f} / {value['max_ms']:.2f}" if value else 'not captured')
    text.append('| `'+name+'` | '+' | '.join(cells)+' |')
for label,identity,run,a,r,life in loaded:
    waits=[x for x in a['longest_lock_waits'] if x['function']=='GraphSession.event']
    holds=[x for x in a['longest_lock_holds'] if x['function']=='GraphSession.event']
    text+=['',f"**{label}:** longest captured event lock wait {max([x['wait_ms'] for x in waits],default=0):.2f} ms; longest captured event lock hold {max([x['held_ms'] for x in holds],default=0):.2f} ms."]
text+=['','The candidate still has long `GraphSession.binding` and event critical sections. In its seq 244 and seq 460 timeout windows, the trace contains event critical sections of about 1521 ms and 1261 ms respectively, with overlapping binding calls of about 1405 ms and 1174 ms. These are temporal overlaps, not a fabricated one-to-one request attribution.',
'The completed server trace did not capture payload event IDs correctly (`observation_id` is null). It has thread/frame/path/time boundaries, while the native audit has exact event/request IDs. Therefore `temporal_event_calls` and `overlapping_lock_holds` in transport-analysis.json are explicitly candidate overlaps; they do not uniquely identify the server frame for each failed request. The external monitor has since been corrected to read event/snapshot arguments directly for a future targeted run, but it has not been rerun blindly and does not backfill old logs.',
'The main repair conversation independently reported a deterministic delayed-reader/session-lock reproduction. That establishes a general concurrency defect, but is not substituted for the original recording’s missing per-request identity.',
'','## Source scanning: invocation count and trigger','']
for label,identity,run,a,r,life in loaded:
    counts=Counter((item['function'],item.get('request_path')) for item in a['scan_triggers'])
    text+=['',f'**{label} / {identity}:**']
    for (function,path),count in sorted(counts.items(),key=lambda item:str(item[0])):
        text.append(f"- `{function}`: {count} completed calls attributed to `{path or 'startup/background (no HTTP ancestor captured)'}`.")
text+=['','`scan` is the selected `sources.scan` callable (its concrete source file is retained in each trace row). A scan invocation is not proof that every unchanged file was reparsed. The observed HTTP triggers are live `/api/view` projection and the recording start’s initial static context; source-tree timing is not conflated with a session-lock hold. Recording checkpoints have their own no-HTTP-ancestor view calls.',
'','## Reproduction and evidence files','',
'From this app directory, with all four intended trial ports free, the diagnostic command is:',
'','```powershell',
"$env:BO_DIAGNOSTIC_SKILL = '<selected external frozen provider>'",
"& '<supplied Python>' -B tooling/unified_browser_run.py --transport-repro --profile-viewer",
'```','',
'Do not rerun the same workload blindly while repair regression is competing for resources. Each run folder contains lifecycle/readiness/cleanup records, an exact copy and hashes of diagnostic source, native-fetch.jsonl, browser-network.jsonl, viewer-calls.jsonl, raw recording.json, transport-result.json, transport-analysis.json and screenshots. Tokens, passwords and arbitrary request bodies are excluded from the request audit.',
'','Old evidence seals:',
'- `old-provider-transport-20261120.zip`, SHA256 `5483150f3167a02c4e754c1ac7c2e441ab60f4ae1a10a67e95bb7ffded003570`.',
'- `old-provider-local-monitor-1795146229.zip`, SHA256 `8595d82ed45f5f29bc152cc07a6aa52fd0774ced415364cae437a3f3ecd25f2c`.',
'','Earlier failed diagnostic setup is separate: `unified-1795145021` failed before app readiness due to the audit loader’s Windows path form; `unified-1795145365` did not enter the recorded case before its UI-ready wait ended; `unified-1795145807` held a read-only sqlite3 connection open and caused the login persistence operation to fail. The diagnostic connection is now explicitly closed before browser operations. None of these are presented as framework transport reproductions or app business regressions.',
'','## Independent native/business boundary','',
'The original HTTP/SQLite/disk business suite passed 13 tests. The single-parent native UI run `unified-1795144920` passed on/off/fault preparation and identical file hashes, real upload/named sharing, recipient restrictions, revocation hiding files while preserving repeated collection, editor file independence, and board publish/edit/read/delete. Its recording_validation is explicitly not_run. These successes do not override failed recording, mapping or final acceptance gates.',
'','Final recording/mapping acceptance remains pending. No `change_sync accept` has been issued on the strength of this candidate comparison.']
(OUT/'TRANSPORT_DIAGNOSIS_20261120.md').write_text('\n'.join(text)+'\n',encoding='utf-8')
print(json.dumps({'report':str(OUT/'TRANSPORT_DIAGNOSIS_20261120.md'),'recording_gate':'not_passed','raw_files_rewritten':False}))
