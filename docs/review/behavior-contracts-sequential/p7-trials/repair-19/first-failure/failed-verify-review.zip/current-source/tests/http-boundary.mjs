import assert from 'node:assert/strict';
import { mkdtemp, readFile, writeFile } from 'node:fs/promises';
import { createHash, randomUUID } from 'node:crypto';
import path from 'node:path';
import http from 'node:http';
import { Store, TEST_PASSWORD } from '../src/store.mjs';
import { FileService } from '../src/service.mjs';
import { createApp } from '../src/http.mjs';
import { bo_create } from '../integrations/bo_observe.mjs';
import { readSessionPrincipal } from './native_reader.mjs';

const stage=process.argv[2] || 'after';
assert.ok(['before','after'].includes(stage));
const root=path.resolve('.'), data=await mkdtemp(path.join(root,'review/runtime/http-'+stage+'-'));
const project=JSON.parse(await readFile(path.join(root,'bo_stategraph/project.json'),'utf8'));
const settings=JSON.parse(await readFile(path.join(root,'review/native-test-settings.json'),'utf8'));
const events=[],snapshots=[],native=[];
const store=new Store(path.join(data,'db/application.sqlite')),service=new FileService(store,data);
service.workerDelay=60000;
const observer=await bo_create(service,root,{project,buildId:settings.build_id,policyHash:settings.policy_hash,sink:async(body,kind)=>(kind==='events'?events:snapshots).push(body)});
const unsubscribe=service.subscribe(event=>{if(['enter','return','error','http_started','http_return'].includes(event.phase))native.push({name:event.name,phase:event.phase,invocation_id:event.invocationId,status:event.status,completed:event.completed});});
const server=createApp(service,path.join(root,'public'),observer).listen(0,'127.0.0.1');
await new Promise(resolve=>server.once('listening',resolve));
const url='http://127.0.0.1:'+server.address().port;
const checks=[];
let aliceCookie;
try{
  for(const [id,body,origin,status] of [
    ['early_origin_403',JSON.stringify({username:'alice',password:TEST_PASSWORD}),'http://unrelated.invalid',403],
    ['parser_400','{broken',null,400],
    ['credentials_401',JSON.stringify({username:'alice',password:'invalid'}),null,401],
    ['valid_200',JSON.stringify({username:'alice',password:TEST_PASSWORD}),null,200]
  ]){
    const eventStart=events.length,nativeStart=native.length;
    const response=await fetch(url+'/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json',...(origin?{Origin:origin}:{})},body});
    assert.equal(response.status,status);
    if(id==='valid_200')aliceCookie=response.headers.get('set-cookie')?.split(';')[0];
    await response.arrayBuffer();await observer.probe.flush(10000);
    const captured=events.slice(eventStart).filter(event=>event.node==='api_login');
    const entered=native.slice(nativeStart).filter(event=>event.name==='login'&&event.phase==='enter');
    const returned=captured.filter(event=>event.phase==='return');
    const expectedApi=stage==='before' && status===403?0:1;
    assert.equal(returned.length,expectedApi);assert.equal(entered.length,status===400||status===403?0:1);
    if(returned.length){
      assert.equal(returned[0].outputs.status,status);
      assert.equal(captured.filter(event=>event.phase==='enter').length,1);
      assert.equal(new Set(captured.map(event=>event.call_id)).size,1);
      assert.ok(returned[0].outputs.duration_ms>=0);
      if(stage==='after')assert.equal(returned[0].outputs.completed,true);
    }
    checks.push({id,actual_http_status:response.status,api_intervals:returned.length,native_login_invocations:entered.length,events:captured});
  }
  if(stage==='after'){
    const before=readSessionPrincipal(store,aliceCookie);assert.equal(before.user_id,'alice');
    const rejected=await fetch(url+'/api/auth/login',{method:'POST',headers:{Cookie:aliceCookie,'Content-Type':'application/json'},body:JSON.stringify({username:'alice',password:'invalid'})});
    assert.equal(rejected.status,401);assert.equal(rejected.headers.get('set-cookie'),null);await rejected.arrayBuffer();
    assert.deepEqual(readSessionPrincipal(store,aliceCookie),before);
    const reauthenticated=await fetch(url+'/api/auth/login',{method:'POST',headers:{Cookie:aliceCookie,'Content-Type':'application/json'},body:JSON.stringify({username:'bob',password:TEST_PASSWORD})});
    assert.equal(reauthenticated.status,200);const bobCookie=reauthenticated.headers.get('set-cookie').split(';')[0];await reauthenticated.arrayBuffer();
    const after=readSessionPrincipal(store,bobCookie);assert.equal(after.user_id,'bob');assert.equal(after.active,true);
    checks.push({id:'reauthentication_native_principals',rejected_http_status:401,reauthenticated_http_status:200,before,after});
    const eventStart=events.length,nativeStart=native.length;
    const entered=new Promise(resolve=>{
      const detach=service.subscribe(event=>{if(event.name==='api_upload'&&event.phase==='http_started'){detach();resolve();}});
    });
    const request=http.request(url+'/api/files?name=aborted.txt',{method:'POST',headers:{Cookie:bobCookie,'Content-Type':'application/octet-stream','Content-Length':1048576}});
    request.on('error',()=>{});request.flushHeaders();request.write(Buffer.from('Incomplete synthetic upload.'));
    await entered;request.destroy();
    for(let attempt=0;attempt<100&&!native.slice(nativeStart).some(event=>event.name==='api_upload'&&event.phase==='http_return');attempt++)await new Promise(resolve=>setTimeout(resolve,10));
    await observer.probe.flush(10000);
    const actual=native.slice(nativeStart).filter(event=>event.name==='api_upload'&&event.phase==='http_return');
    const captured=events.slice(eventStart).filter(event=>event.node==='api_upload');
    const terminal=captured.filter(event=>event.phase==='return');
    assert.equal(actual.length,1);assert.equal(terminal.length,1);assert.equal(actual[0].completed,false);assert.equal(terminal[0].outputs.completed,false);
    if(actual[0].status===null)assert.equal(Object.hasOwn(terminal[0].outputs,'status'),false);else assert.equal(terminal[0].outputs.status,actual[0].status);
    assert.equal(new Set(captured.map(event=>event.call_id)).size,1);assert.equal(captured.filter(event=>event.phase==='enter').length,1);
    assert.equal(native.slice(nativeStart).filter(event=>event.name==='upload_file'&&event.phase==='enter').length,0);
    checks.push({id:'interrupted_before_upload_business',native_response:actual[0],api_interval:captured,native_upload_invocations:0});
    const observerStart=events.length;
    const config=await fetch(url+'/api/bo/config');assert.equal(config.status,200);await config.arrayBuffer();await observer.probe.flush(10000);
    assert.equal(events.length,observerStart);checks.push({id:'observer_endpoint_excluded',http_status:200,business_events:0});
    const logout=await fetch(url+'/api/auth/logout',{method:'POST',headers:{Cookie:bobCookie}});assert.equal(logout.status,204);await logout.arrayBuffer();
    assert.equal(readSessionPrincipal(store,bobCookie).active,false);
    checks.push({id:'logout_native_completion',http_status:204,principal:readSessionPrincipal(store,bobCookie)});
    await observer.probe.flush(10000);
  }
  const health=observer.health();assert.equal(health.errors,0);assert.equal(health.dropped,0);
  assert.equal(health.tracing.open_spans,0);assert.equal(health.pending,0);
  const sourceHash=createHash('sha256').update(await readFile(path.join(root,'src/http.mjs'))).digest('hex');
  const report={stage,record_id:randomUUID(),source_sha256:sourceHash,build_id:settings.build_id,checks,health,events,snapshots,known_failure:stage==='before'?'Real 403 origin rejection has no API interval; parser 400 and native credentials 401 are captured.':null};
  const encoded=JSON.stringify(report,null,2);
  await writeFile(path.join(root,'review/runtime/http-'+stage+'.json'),encoded,{flag:stage==='before'?'wx':'w'});
  await writeFile(path.join(root,'review/runtime/http-'+stage+'-'+report.record_id+'.json'),encoded,{flag:'wx'});
  console.log(JSON.stringify({stage,checks:checks.map(({events,api_interval,...values})=>values),health}));
}finally{unsubscribe();await service.stop();await new Promise(resolve=>server.close(resolve));await observer.close();store.close();}
