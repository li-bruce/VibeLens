// integrations/bo_client.mjs
import { BOProbe } from "/api/bo/native-runtime.mjs";
import { BOCaptureClient } from "/api/bo/native-capture.mjs";

// node_modules/@opentelemetry/api/build/esm/platform/browser/globalThis.js
var _globalThis = typeof globalThis === "object" ? globalThis : typeof self === "object" ? self : typeof window === "object" ? window : typeof global === "object" ? global : {};

// node_modules/@opentelemetry/api/build/esm/version.js
var VERSION = "1.9.0";

// node_modules/@opentelemetry/api/build/esm/internal/semver.js
var re = /^(\d+)\.(\d+)\.(\d+)(-(.+))?$/;
function _makeCompatibilityCheck(ownVersion) {
  var acceptedVersions = /* @__PURE__ */ new Set([ownVersion]);
  var rejectedVersions = /* @__PURE__ */ new Set();
  var myVersionMatch = ownVersion.match(re);
  if (!myVersionMatch) {
    return function() {
      return false;
    };
  }
  var ownVersionParsed = {
    major: +myVersionMatch[1],
    minor: +myVersionMatch[2],
    patch: +myVersionMatch[3],
    prerelease: myVersionMatch[4]
  };
  if (ownVersionParsed.prerelease != null) {
    return function isExactmatch(globalVersion) {
      return globalVersion === ownVersion;
    };
  }
  function _reject(v) {
    rejectedVersions.add(v);
    return false;
  }
  function _accept(v) {
    acceptedVersions.add(v);
    return true;
  }
  return function isCompatible3(globalVersion) {
    if (acceptedVersions.has(globalVersion)) {
      return true;
    }
    if (rejectedVersions.has(globalVersion)) {
      return false;
    }
    var globalVersionMatch = globalVersion.match(re);
    if (!globalVersionMatch) {
      return _reject(globalVersion);
    }
    var globalVersionParsed = {
      major: +globalVersionMatch[1],
      minor: +globalVersionMatch[2],
      patch: +globalVersionMatch[3],
      prerelease: globalVersionMatch[4]
    };
    if (globalVersionParsed.prerelease != null) {
      return _reject(globalVersion);
    }
    if (ownVersionParsed.major !== globalVersionParsed.major) {
      return _reject(globalVersion);
    }
    if (ownVersionParsed.major === 0) {
      if (ownVersionParsed.minor === globalVersionParsed.minor && ownVersionParsed.patch <= globalVersionParsed.patch) {
        return _accept(globalVersion);
      }
      return _reject(globalVersion);
    }
    if (ownVersionParsed.minor <= globalVersionParsed.minor) {
      return _accept(globalVersion);
    }
    return _reject(globalVersion);
  };
}
var isCompatible = _makeCompatibilityCheck(VERSION);

// node_modules/@opentelemetry/api/build/esm/internal/global-utils.js
var major = VERSION.split(".")[0];
var GLOBAL_OPENTELEMETRY_API_KEY = /* @__PURE__ */ Symbol.for("opentelemetry.js.api." + major);
var _global = _globalThis;
function registerGlobal(type, instance, diag2, allowOverride) {
  var _a;
  if (allowOverride === void 0) {
    allowOverride = false;
  }
  var api = _global[GLOBAL_OPENTELEMETRY_API_KEY] = (_a = _global[GLOBAL_OPENTELEMETRY_API_KEY]) !== null && _a !== void 0 ? _a : {
    version: VERSION
  };
  if (!allowOverride && api[type]) {
    var err = new Error("@opentelemetry/api: Attempted duplicate registration of API: " + type);
    diag2.error(err.stack || err.message);
    return false;
  }
  if (api.version !== VERSION) {
    var err = new Error("@opentelemetry/api: Registration of version v" + api.version + " for " + type + " does not match previously registered API v" + VERSION);
    diag2.error(err.stack || err.message);
    return false;
  }
  api[type] = instance;
  diag2.debug("@opentelemetry/api: Registered a global for " + type + " v" + VERSION + ".");
  return true;
}
function getGlobal(type) {
  var _a, _b;
  var globalVersion = (_a = _global[GLOBAL_OPENTELEMETRY_API_KEY]) === null || _a === void 0 ? void 0 : _a.version;
  if (!globalVersion || !isCompatible(globalVersion)) {
    return;
  }
  return (_b = _global[GLOBAL_OPENTELEMETRY_API_KEY]) === null || _b === void 0 ? void 0 : _b[type];
}
function unregisterGlobal(type, diag2) {
  diag2.debug("@opentelemetry/api: Unregistering a global for " + type + " v" + VERSION + ".");
  var api = _global[GLOBAL_OPENTELEMETRY_API_KEY];
  if (api) {
    delete api[type];
  }
}

// node_modules/@opentelemetry/api/build/esm/diag/ComponentLogger.js
var __read = function(o, n) {
  var m = typeof Symbol === "function" && o[Symbol.iterator];
  if (!m) return o;
  var i = m.call(o), r, ar = [], e;
  try {
    while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
  } catch (error) {
    e = { error };
  } finally {
    try {
      if (r && !r.done && (m = i["return"])) m.call(i);
    } finally {
      if (e) throw e.error;
    }
  }
  return ar;
};
var __spreadArray = function(to, from, pack) {
  if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
    if (ar || !(i in from)) {
      if (!ar) ar = Array.prototype.slice.call(from, 0, i);
      ar[i] = from[i];
    }
  }
  return to.concat(ar || Array.prototype.slice.call(from));
};
var DiagComponentLogger = (
  /** @class */
  (function() {
    function DiagComponentLogger3(props) {
      this._namespace = props.namespace || "DiagComponentLogger";
    }
    DiagComponentLogger3.prototype.debug = function() {
      var args = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
      }
      return logProxy("debug", this._namespace, args);
    };
    DiagComponentLogger3.prototype.error = function() {
      var args = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
      }
      return logProxy("error", this._namespace, args);
    };
    DiagComponentLogger3.prototype.info = function() {
      var args = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
      }
      return logProxy("info", this._namespace, args);
    };
    DiagComponentLogger3.prototype.warn = function() {
      var args = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
      }
      return logProxy("warn", this._namespace, args);
    };
    DiagComponentLogger3.prototype.verbose = function() {
      var args = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
      }
      return logProxy("verbose", this._namespace, args);
    };
    return DiagComponentLogger3;
  })()
);
function logProxy(funcName, namespace, args) {
  var logger = getGlobal("diag");
  if (!logger) {
    return;
  }
  args.unshift(namespace);
  return logger[funcName].apply(logger, __spreadArray([], __read(args), false));
}

// node_modules/@opentelemetry/api/build/esm/diag/types.js
var DiagLogLevel;
(function(DiagLogLevel3) {
  DiagLogLevel3[DiagLogLevel3["NONE"] = 0] = "NONE";
  DiagLogLevel3[DiagLogLevel3["ERROR"] = 30] = "ERROR";
  DiagLogLevel3[DiagLogLevel3["WARN"] = 50] = "WARN";
  DiagLogLevel3[DiagLogLevel3["INFO"] = 60] = "INFO";
  DiagLogLevel3[DiagLogLevel3["DEBUG"] = 70] = "DEBUG";
  DiagLogLevel3[DiagLogLevel3["VERBOSE"] = 80] = "VERBOSE";
  DiagLogLevel3[DiagLogLevel3["ALL"] = 9999] = "ALL";
})(DiagLogLevel || (DiagLogLevel = {}));

// node_modules/@opentelemetry/api/build/esm/diag/internal/logLevelLogger.js
function createLogLevelDiagLogger(maxLevel, logger) {
  if (maxLevel < DiagLogLevel.NONE) {
    maxLevel = DiagLogLevel.NONE;
  } else if (maxLevel > DiagLogLevel.ALL) {
    maxLevel = DiagLogLevel.ALL;
  }
  logger = logger || {};
  function _filterFunc(funcName, theLevel) {
    var theFunc = logger[funcName];
    if (typeof theFunc === "function" && maxLevel >= theLevel) {
      return theFunc.bind(logger);
    }
    return function() {
    };
  }
  return {
    error: _filterFunc("error", DiagLogLevel.ERROR),
    warn: _filterFunc("warn", DiagLogLevel.WARN),
    info: _filterFunc("info", DiagLogLevel.INFO),
    debug: _filterFunc("debug", DiagLogLevel.DEBUG),
    verbose: _filterFunc("verbose", DiagLogLevel.VERBOSE)
  };
}

// node_modules/@opentelemetry/api/build/esm/api/diag.js
var __read2 = function(o, n) {
  var m = typeof Symbol === "function" && o[Symbol.iterator];
  if (!m) return o;
  var i = m.call(o), r, ar = [], e;
  try {
    while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
  } catch (error) {
    e = { error };
  } finally {
    try {
      if (r && !r.done && (m = i["return"])) m.call(i);
    } finally {
      if (e) throw e.error;
    }
  }
  return ar;
};
var __spreadArray2 = function(to, from, pack) {
  if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
    if (ar || !(i in from)) {
      if (!ar) ar = Array.prototype.slice.call(from, 0, i);
      ar[i] = from[i];
    }
  }
  return to.concat(ar || Array.prototype.slice.call(from));
};
var API_NAME = "diag";
var DiagAPI = (
  /** @class */
  (function() {
    function DiagAPI3() {
      function _logProxy(funcName) {
        return function() {
          var args = [];
          for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
          }
          var logger = getGlobal("diag");
          if (!logger)
            return;
          return logger[funcName].apply(logger, __spreadArray2([], __read2(args), false));
        };
      }
      var self2 = this;
      var setLogger = function(logger, optionsOrLogLevel) {
        var _a, _b, _c;
        if (optionsOrLogLevel === void 0) {
          optionsOrLogLevel = { logLevel: DiagLogLevel.INFO };
        }
        if (logger === self2) {
          var err = new Error("Cannot use diag as the logger for itself. Please use a DiagLogger implementation like ConsoleDiagLogger or a custom implementation");
          self2.error((_a = err.stack) !== null && _a !== void 0 ? _a : err.message);
          return false;
        }
        if (typeof optionsOrLogLevel === "number") {
          optionsOrLogLevel = {
            logLevel: optionsOrLogLevel
          };
        }
        var oldLogger = getGlobal("diag");
        var newLogger = createLogLevelDiagLogger((_b = optionsOrLogLevel.logLevel) !== null && _b !== void 0 ? _b : DiagLogLevel.INFO, logger);
        if (oldLogger && !optionsOrLogLevel.suppressOverrideMessage) {
          var stack = (_c = new Error().stack) !== null && _c !== void 0 ? _c : "<failed to generate stacktrace>";
          oldLogger.warn("Current logger will be overwritten from " + stack);
          newLogger.warn("Current logger will overwrite one already registered from " + stack);
        }
        return registerGlobal("diag", newLogger, self2, true);
      };
      self2.setLogger = setLogger;
      self2.disable = function() {
        unregisterGlobal(API_NAME, self2);
      };
      self2.createComponentLogger = function(options) {
        return new DiagComponentLogger(options);
      };
      self2.verbose = _logProxy("verbose");
      self2.debug = _logProxy("debug");
      self2.info = _logProxy("info");
      self2.warn = _logProxy("warn");
      self2.error = _logProxy("error");
    }
    DiagAPI3.instance = function() {
      if (!this._instance) {
        this._instance = new DiagAPI3();
      }
      return this._instance;
    };
    return DiagAPI3;
  })()
);

// node_modules/@opentelemetry/api/build/esm/context/context.js
function createContextKey(description) {
  return Symbol.for(description);
}
var BaseContext = (
  /** @class */
  /* @__PURE__ */ (function() {
    function BaseContext3(parentContext) {
      var self2 = this;
      self2._currentContext = parentContext ? new Map(parentContext) : /* @__PURE__ */ new Map();
      self2.getValue = function(key) {
        return self2._currentContext.get(key);
      };
      self2.setValue = function(key, value) {
        var context3 = new BaseContext3(self2._currentContext);
        context3._currentContext.set(key, value);
        return context3;
      };
      self2.deleteValue = function(key) {
        var context3 = new BaseContext3(self2._currentContext);
        context3._currentContext.delete(key);
        return context3;
      };
    }
    return BaseContext3;
  })()
);
var ROOT_CONTEXT = new BaseContext();

// node_modules/@opentelemetry/api/build/esm/metrics/NoopMeter.js
var __extends = /* @__PURE__ */ (function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
})();
var NoopMeter = (
  /** @class */
  (function() {
    function NoopMeter2() {
    }
    NoopMeter2.prototype.createGauge = function(_name, _options) {
      return NOOP_GAUGE_METRIC;
    };
    NoopMeter2.prototype.createHistogram = function(_name, _options) {
      return NOOP_HISTOGRAM_METRIC;
    };
    NoopMeter2.prototype.createCounter = function(_name, _options) {
      return NOOP_COUNTER_METRIC;
    };
    NoopMeter2.prototype.createUpDownCounter = function(_name, _options) {
      return NOOP_UP_DOWN_COUNTER_METRIC;
    };
    NoopMeter2.prototype.createObservableGauge = function(_name, _options) {
      return NOOP_OBSERVABLE_GAUGE_METRIC;
    };
    NoopMeter2.prototype.createObservableCounter = function(_name, _options) {
      return NOOP_OBSERVABLE_COUNTER_METRIC;
    };
    NoopMeter2.prototype.createObservableUpDownCounter = function(_name, _options) {
      return NOOP_OBSERVABLE_UP_DOWN_COUNTER_METRIC;
    };
    NoopMeter2.prototype.addBatchObservableCallback = function(_callback, _observables) {
    };
    NoopMeter2.prototype.removeBatchObservableCallback = function(_callback) {
    };
    return NoopMeter2;
  })()
);
var NoopMetric = (
  /** @class */
  /* @__PURE__ */ (function() {
    function NoopMetric2() {
    }
    return NoopMetric2;
  })()
);
var NoopCounterMetric = (
  /** @class */
  (function(_super) {
    __extends(NoopCounterMetric2, _super);
    function NoopCounterMetric2() {
      return _super !== null && _super.apply(this, arguments) || this;
    }
    NoopCounterMetric2.prototype.add = function(_value, _attributes) {
    };
    return NoopCounterMetric2;
  })(NoopMetric)
);
var NoopUpDownCounterMetric = (
  /** @class */
  (function(_super) {
    __extends(NoopUpDownCounterMetric2, _super);
    function NoopUpDownCounterMetric2() {
      return _super !== null && _super.apply(this, arguments) || this;
    }
    NoopUpDownCounterMetric2.prototype.add = function(_value, _attributes) {
    };
    return NoopUpDownCounterMetric2;
  })(NoopMetric)
);
var NoopGaugeMetric = (
  /** @class */
  (function(_super) {
    __extends(NoopGaugeMetric2, _super);
    function NoopGaugeMetric2() {
      return _super !== null && _super.apply(this, arguments) || this;
    }
    NoopGaugeMetric2.prototype.record = function(_value, _attributes) {
    };
    return NoopGaugeMetric2;
  })(NoopMetric)
);
var NoopHistogramMetric = (
  /** @class */
  (function(_super) {
    __extends(NoopHistogramMetric2, _super);
    function NoopHistogramMetric2() {
      return _super !== null && _super.apply(this, arguments) || this;
    }
    NoopHistogramMetric2.prototype.record = function(_value, _attributes) {
    };
    return NoopHistogramMetric2;
  })(NoopMetric)
);
var NoopObservableMetric = (
  /** @class */
  (function() {
    function NoopObservableMetric2() {
    }
    NoopObservableMetric2.prototype.addCallback = function(_callback) {
    };
    NoopObservableMetric2.prototype.removeCallback = function(_callback) {
    };
    return NoopObservableMetric2;
  })()
);
var NoopObservableCounterMetric = (
  /** @class */
  (function(_super) {
    __extends(NoopObservableCounterMetric2, _super);
    function NoopObservableCounterMetric2() {
      return _super !== null && _super.apply(this, arguments) || this;
    }
    return NoopObservableCounterMetric2;
  })(NoopObservableMetric)
);
var NoopObservableGaugeMetric = (
  /** @class */
  (function(_super) {
    __extends(NoopObservableGaugeMetric2, _super);
    function NoopObservableGaugeMetric2() {
      return _super !== null && _super.apply(this, arguments) || this;
    }
    return NoopObservableGaugeMetric2;
  })(NoopObservableMetric)
);
var NoopObservableUpDownCounterMetric = (
  /** @class */
  (function(_super) {
    __extends(NoopObservableUpDownCounterMetric2, _super);
    function NoopObservableUpDownCounterMetric2() {
      return _super !== null && _super.apply(this, arguments) || this;
    }
    return NoopObservableUpDownCounterMetric2;
  })(NoopObservableMetric)
);
var NOOP_METER = new NoopMeter();
var NOOP_COUNTER_METRIC = new NoopCounterMetric();
var NOOP_GAUGE_METRIC = new NoopGaugeMetric();
var NOOP_HISTOGRAM_METRIC = new NoopHistogramMetric();
var NOOP_UP_DOWN_COUNTER_METRIC = new NoopUpDownCounterMetric();
var NOOP_OBSERVABLE_COUNTER_METRIC = new NoopObservableCounterMetric();
var NOOP_OBSERVABLE_GAUGE_METRIC = new NoopObservableGaugeMetric();
var NOOP_OBSERVABLE_UP_DOWN_COUNTER_METRIC = new NoopObservableUpDownCounterMetric();
function createNoopMeter() {
  return NOOP_METER;
}

// node_modules/@opentelemetry/api/build/esm/context/NoopContextManager.js
var __read3 = function(o, n) {
  var m = typeof Symbol === "function" && o[Symbol.iterator];
  if (!m) return o;
  var i = m.call(o), r, ar = [], e;
  try {
    while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
  } catch (error) {
    e = { error };
  } finally {
    try {
      if (r && !r.done && (m = i["return"])) m.call(i);
    } finally {
      if (e) throw e.error;
    }
  }
  return ar;
};
var __spreadArray3 = function(to, from, pack) {
  if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
    if (ar || !(i in from)) {
      if (!ar) ar = Array.prototype.slice.call(from, 0, i);
      ar[i] = from[i];
    }
  }
  return to.concat(ar || Array.prototype.slice.call(from));
};
var NoopContextManager = (
  /** @class */
  (function() {
    function NoopContextManager3() {
    }
    NoopContextManager3.prototype.active = function() {
      return ROOT_CONTEXT;
    };
    NoopContextManager3.prototype.with = function(_context, fn, thisArg) {
      var args = [];
      for (var _i = 3; _i < arguments.length; _i++) {
        args[_i - 3] = arguments[_i];
      }
      return fn.call.apply(fn, __spreadArray3([thisArg], __read3(args), false));
    };
    NoopContextManager3.prototype.bind = function(_context, target) {
      return target;
    };
    NoopContextManager3.prototype.enable = function() {
      return this;
    };
    NoopContextManager3.prototype.disable = function() {
      return this;
    };
    return NoopContextManager3;
  })()
);

// node_modules/@opentelemetry/api/build/esm/api/context.js
var __read4 = function(o, n) {
  var m = typeof Symbol === "function" && o[Symbol.iterator];
  if (!m) return o;
  var i = m.call(o), r, ar = [], e;
  try {
    while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
  } catch (error) {
    e = { error };
  } finally {
    try {
      if (r && !r.done && (m = i["return"])) m.call(i);
    } finally {
      if (e) throw e.error;
    }
  }
  return ar;
};
var __spreadArray4 = function(to, from, pack) {
  if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
    if (ar || !(i in from)) {
      if (!ar) ar = Array.prototype.slice.call(from, 0, i);
      ar[i] = from[i];
    }
  }
  return to.concat(ar || Array.prototype.slice.call(from));
};
var API_NAME2 = "context";
var NOOP_CONTEXT_MANAGER = new NoopContextManager();
var ContextAPI = (
  /** @class */
  (function() {
    function ContextAPI3() {
    }
    ContextAPI3.getInstance = function() {
      if (!this._instance) {
        this._instance = new ContextAPI3();
      }
      return this._instance;
    };
    ContextAPI3.prototype.setGlobalContextManager = function(contextManager) {
      return registerGlobal(API_NAME2, contextManager, DiagAPI.instance());
    };
    ContextAPI3.prototype.active = function() {
      return this._getContextManager().active();
    };
    ContextAPI3.prototype.with = function(context3, fn, thisArg) {
      var _a;
      var args = [];
      for (var _i = 3; _i < arguments.length; _i++) {
        args[_i - 3] = arguments[_i];
      }
      return (_a = this._getContextManager()).with.apply(_a, __spreadArray4([context3, fn, thisArg], __read4(args), false));
    };
    ContextAPI3.prototype.bind = function(context3, target) {
      return this._getContextManager().bind(context3, target);
    };
    ContextAPI3.prototype._getContextManager = function() {
      return getGlobal(API_NAME2) || NOOP_CONTEXT_MANAGER;
    };
    ContextAPI3.prototype.disable = function() {
      this._getContextManager().disable();
      unregisterGlobal(API_NAME2, DiagAPI.instance());
    };
    return ContextAPI3;
  })()
);

// node_modules/@opentelemetry/api/build/esm/trace/trace_flags.js
var TraceFlags;
(function(TraceFlags3) {
  TraceFlags3[TraceFlags3["NONE"] = 0] = "NONE";
  TraceFlags3[TraceFlags3["SAMPLED"] = 1] = "SAMPLED";
})(TraceFlags || (TraceFlags = {}));

// node_modules/@opentelemetry/api/build/esm/trace/invalid-span-constants.js
var INVALID_SPANID = "0000000000000000";
var INVALID_TRACEID = "00000000000000000000000000000000";
var INVALID_SPAN_CONTEXT = {
  traceId: INVALID_TRACEID,
  spanId: INVALID_SPANID,
  traceFlags: TraceFlags.NONE
};

// node_modules/@opentelemetry/api/build/esm/trace/NonRecordingSpan.js
var NonRecordingSpan = (
  /** @class */
  (function() {
    function NonRecordingSpan3(_spanContext) {
      if (_spanContext === void 0) {
        _spanContext = INVALID_SPAN_CONTEXT;
      }
      this._spanContext = _spanContext;
    }
    NonRecordingSpan3.prototype.spanContext = function() {
      return this._spanContext;
    };
    NonRecordingSpan3.prototype.setAttribute = function(_key, _value) {
      return this;
    };
    NonRecordingSpan3.prototype.setAttributes = function(_attributes) {
      return this;
    };
    NonRecordingSpan3.prototype.addEvent = function(_name, _attributes) {
      return this;
    };
    NonRecordingSpan3.prototype.addLink = function(_link) {
      return this;
    };
    NonRecordingSpan3.prototype.addLinks = function(_links) {
      return this;
    };
    NonRecordingSpan3.prototype.setStatus = function(_status) {
      return this;
    };
    NonRecordingSpan3.prototype.updateName = function(_name) {
      return this;
    };
    NonRecordingSpan3.prototype.end = function(_endTime) {
    };
    NonRecordingSpan3.prototype.isRecording = function() {
      return false;
    };
    NonRecordingSpan3.prototype.recordException = function(_exception, _time) {
    };
    return NonRecordingSpan3;
  })()
);

// node_modules/@opentelemetry/api/build/esm/trace/context-utils.js
var SPAN_KEY = createContextKey("OpenTelemetry Context Key SPAN");
function getSpan(context3) {
  return context3.getValue(SPAN_KEY) || void 0;
}
function getActiveSpan() {
  return getSpan(ContextAPI.getInstance().active());
}
function setSpan(context3, span) {
  return context3.setValue(SPAN_KEY, span);
}
function deleteSpan(context3) {
  return context3.deleteValue(SPAN_KEY);
}
function setSpanContext(context3, spanContext) {
  return setSpan(context3, new NonRecordingSpan(spanContext));
}
function getSpanContext(context3) {
  var _a;
  return (_a = getSpan(context3)) === null || _a === void 0 ? void 0 : _a.spanContext();
}

// node_modules/@opentelemetry/api/build/esm/trace/spancontext-utils.js
var VALID_TRACEID_REGEX = /^([0-9a-f]{32})$/i;
var VALID_SPANID_REGEX = /^[0-9a-f]{16}$/i;
function isValidTraceId(traceId) {
  return VALID_TRACEID_REGEX.test(traceId) && traceId !== INVALID_TRACEID;
}
function isValidSpanId(spanId) {
  return VALID_SPANID_REGEX.test(spanId) && spanId !== INVALID_SPANID;
}
function isSpanContextValid(spanContext) {
  return isValidTraceId(spanContext.traceId) && isValidSpanId(spanContext.spanId);
}
function wrapSpanContext(spanContext) {
  return new NonRecordingSpan(spanContext);
}

// node_modules/@opentelemetry/api/build/esm/trace/NoopTracer.js
var contextApi = ContextAPI.getInstance();
var NoopTracer = (
  /** @class */
  (function() {
    function NoopTracer3() {
    }
    NoopTracer3.prototype.startSpan = function(name, options, context3) {
      if (context3 === void 0) {
        context3 = contextApi.active();
      }
      var root = Boolean(options === null || options === void 0 ? void 0 : options.root);
      if (root) {
        return new NonRecordingSpan();
      }
      var parentFromContext = context3 && getSpanContext(context3);
      if (isSpanContext(parentFromContext) && isSpanContextValid(parentFromContext)) {
        return new NonRecordingSpan(parentFromContext);
      } else {
        return new NonRecordingSpan();
      }
    };
    NoopTracer3.prototype.startActiveSpan = function(name, arg2, arg3, arg4) {
      var opts;
      var ctx;
      var fn;
      if (arguments.length < 2) {
        return;
      } else if (arguments.length === 2) {
        fn = arg2;
      } else if (arguments.length === 3) {
        opts = arg2;
        fn = arg3;
      } else {
        opts = arg2;
        ctx = arg3;
        fn = arg4;
      }
      var parentContext = ctx !== null && ctx !== void 0 ? ctx : contextApi.active();
      var span = this.startSpan(name, opts, parentContext);
      var contextWithSpanSet = setSpan(parentContext, span);
      return contextApi.with(contextWithSpanSet, fn, void 0, span);
    };
    return NoopTracer3;
  })()
);
function isSpanContext(spanContext) {
  return typeof spanContext === "object" && typeof spanContext["spanId"] === "string" && typeof spanContext["traceId"] === "string" && typeof spanContext["traceFlags"] === "number";
}

// node_modules/@opentelemetry/api/build/esm/trace/ProxyTracer.js
var NOOP_TRACER = new NoopTracer();
var ProxyTracer = (
  /** @class */
  (function() {
    function ProxyTracer3(_provider, name, version, options) {
      this._provider = _provider;
      this.name = name;
      this.version = version;
      this.options = options;
    }
    ProxyTracer3.prototype.startSpan = function(name, options, context3) {
      return this._getTracer().startSpan(name, options, context3);
    };
    ProxyTracer3.prototype.startActiveSpan = function(_name, _options, _context, _fn) {
      var tracer = this._getTracer();
      return Reflect.apply(tracer.startActiveSpan, tracer, arguments);
    };
    ProxyTracer3.prototype._getTracer = function() {
      if (this._delegate) {
        return this._delegate;
      }
      var tracer = this._provider.getDelegateTracer(this.name, this.version, this.options);
      if (!tracer) {
        return NOOP_TRACER;
      }
      this._delegate = tracer;
      return this._delegate;
    };
    return ProxyTracer3;
  })()
);

// node_modules/@opentelemetry/api/build/esm/trace/NoopTracerProvider.js
var NoopTracerProvider = (
  /** @class */
  (function() {
    function NoopTracerProvider3() {
    }
    NoopTracerProvider3.prototype.getTracer = function(_name, _version, _options) {
      return new NoopTracer();
    };
    return NoopTracerProvider3;
  })()
);

// node_modules/@opentelemetry/api/build/esm/trace/ProxyTracerProvider.js
var NOOP_TRACER_PROVIDER = new NoopTracerProvider();
var ProxyTracerProvider = (
  /** @class */
  (function() {
    function ProxyTracerProvider3() {
    }
    ProxyTracerProvider3.prototype.getTracer = function(name, version, options) {
      var _a;
      return (_a = this.getDelegateTracer(name, version, options)) !== null && _a !== void 0 ? _a : new ProxyTracer(this, name, version, options);
    };
    ProxyTracerProvider3.prototype.getDelegate = function() {
      var _a;
      return (_a = this._delegate) !== null && _a !== void 0 ? _a : NOOP_TRACER_PROVIDER;
    };
    ProxyTracerProvider3.prototype.setDelegate = function(delegate) {
      this._delegate = delegate;
    };
    ProxyTracerProvider3.prototype.getDelegateTracer = function(name, version, options) {
      var _a;
      return (_a = this._delegate) === null || _a === void 0 ? void 0 : _a.getTracer(name, version, options);
    };
    return ProxyTracerProvider3;
  })()
);

// node_modules/@opentelemetry/api/build/esm/trace/SamplingResult.js
var SamplingDecision;
(function(SamplingDecision3) {
  SamplingDecision3[SamplingDecision3["NOT_RECORD"] = 0] = "NOT_RECORD";
  SamplingDecision3[SamplingDecision3["RECORD"] = 1] = "RECORD";
  SamplingDecision3[SamplingDecision3["RECORD_AND_SAMPLED"] = 2] = "RECORD_AND_SAMPLED";
})(SamplingDecision || (SamplingDecision = {}));

// node_modules/@opentelemetry/api/build/esm/trace/span_kind.js
var SpanKind;
(function(SpanKind2) {
  SpanKind2[SpanKind2["INTERNAL"] = 0] = "INTERNAL";
  SpanKind2[SpanKind2["SERVER"] = 1] = "SERVER";
  SpanKind2[SpanKind2["CLIENT"] = 2] = "CLIENT";
  SpanKind2[SpanKind2["PRODUCER"] = 3] = "PRODUCER";
  SpanKind2[SpanKind2["CONSUMER"] = 4] = "CONSUMER";
})(SpanKind || (SpanKind = {}));

// node_modules/@opentelemetry/api/build/esm/trace/status.js
var SpanStatusCode;
(function(SpanStatusCode3) {
  SpanStatusCode3[SpanStatusCode3["UNSET"] = 0] = "UNSET";
  SpanStatusCode3[SpanStatusCode3["OK"] = 1] = "OK";
  SpanStatusCode3[SpanStatusCode3["ERROR"] = 2] = "ERROR";
})(SpanStatusCode || (SpanStatusCode = {}));

// node_modules/@opentelemetry/api/build/esm/context-api.js
var context = ContextAPI.getInstance();

// node_modules/@opentelemetry/api/build/esm/diag-api.js
var diag = DiagAPI.instance();

// node_modules/@opentelemetry/api/build/esm/api/trace.js
var API_NAME3 = "trace";
var TraceAPI = (
  /** @class */
  (function() {
    function TraceAPI3() {
      this._proxyTracerProvider = new ProxyTracerProvider();
      this.wrapSpanContext = wrapSpanContext;
      this.isSpanContextValid = isSpanContextValid;
      this.deleteSpan = deleteSpan;
      this.getSpan = getSpan;
      this.getActiveSpan = getActiveSpan;
      this.getSpanContext = getSpanContext;
      this.setSpan = setSpan;
      this.setSpanContext = setSpanContext;
    }
    TraceAPI3.getInstance = function() {
      if (!this._instance) {
        this._instance = new TraceAPI3();
      }
      return this._instance;
    };
    TraceAPI3.prototype.setGlobalTracerProvider = function(provider) {
      var success = registerGlobal(API_NAME3, this._proxyTracerProvider, DiagAPI.instance());
      if (success) {
        this._proxyTracerProvider.setDelegate(provider);
      }
      return success;
    };
    TraceAPI3.prototype.getTracerProvider = function() {
      return getGlobal(API_NAME3) || this._proxyTracerProvider;
    };
    TraceAPI3.prototype.getTracer = function(name, version) {
      return this.getTracerProvider().getTracer(name, version);
    };
    TraceAPI3.prototype.disable = function() {
      unregisterGlobal(API_NAME3, DiagAPI.instance());
      this._proxyTracerProvider = new ProxyTracerProvider();
    };
    return TraceAPI3;
  })()
);

// node_modules/@opentelemetry/api/build/esm/trace-api.js
var trace = TraceAPI.getInstance();

// node_modules/@opentelemetry/core/build/esm/trace/suppress-tracing.js
var SUPPRESS_TRACING_KEY = createContextKey("OpenTelemetry SDK Context Key SUPPRESS_TRACING");
function isTracingSuppressed(context3) {
  return context3.getValue(SUPPRESS_TRACING_KEY) === true;
}

// node_modules/@opentelemetry/core/build/esm/common/attributes.js
function sanitizeAttributes(attributes) {
  const out = {};
  if (typeof attributes !== "object" || attributes == null) {
    return out;
  }
  for (const key in attributes) {
    if (!Object.prototype.hasOwnProperty.call(attributes, key)) {
      continue;
    }
    if (!isAttributeKey(key)) {
      diag.warn(`Invalid attribute key: ${key}`);
      continue;
    }
    const val = attributes[key];
    if (!isAttributeValue(val)) {
      diag.warn(`Invalid attribute value set for key: ${key}`);
      continue;
    }
    if (Array.isArray(val)) {
      out[key] = val.slice();
    } else {
      out[key] = val;
    }
  }
  return out;
}
function isAttributeKey(key) {
  return typeof key === "string" && key !== "";
}
function isAttributeValue(val) {
  if (val == null) {
    return true;
  }
  if (Array.isArray(val)) {
    return isHomogeneousAttributeValueArray(val);
  }
  return isValidPrimitiveAttributeValueType(typeof val);
}
function isHomogeneousAttributeValueArray(arr) {
  let type;
  for (const element of arr) {
    if (element == null)
      continue;
    const elementType = typeof element;
    if (elementType === type) {
      continue;
    }
    if (!type) {
      if (isValidPrimitiveAttributeValueType(elementType)) {
        type = elementType;
        continue;
      }
      return false;
    }
    return false;
  }
  return true;
}
function isValidPrimitiveAttributeValueType(valType) {
  switch (valType) {
    case "number":
    case "boolean":
    case "string":
      return true;
  }
  return false;
}

// node_modules/@opentelemetry/core/build/esm/common/logging-error-handler.js
function loggingErrorHandler() {
  return (ex) => {
    diag.error(stringifyException(ex));
  };
}
function stringifyException(ex) {
  if (typeof ex === "string") {
    return ex;
  } else {
    return JSON.stringify(flattenException(ex));
  }
}
function flattenException(ex) {
  const result = {};
  let current = ex;
  while (current !== null) {
    Object.getOwnPropertyNames(current).forEach((propertyName) => {
      if (result[propertyName])
        return;
      const value = current[propertyName];
      if (value) {
        result[propertyName] = String(value);
      }
    });
    current = Object.getPrototypeOf(current);
  }
  return result;
}

// node_modules/@opentelemetry/core/build/esm/common/global-error-handler.js
var delegateHandler = loggingErrorHandler();
function globalErrorHandler(ex) {
  try {
    delegateHandler(ex);
  } catch {
  }
}

// node_modules/@opentelemetry/core/build/esm/version.js
var VERSION2 = "2.12.0";

// node_modules/@opentelemetry/semantic-conventions/dist/stable_attributes.mjs
var ATTR_EXCEPTION_MESSAGE = "exception.message";
var ATTR_EXCEPTION_STACKTRACE = "exception.stacktrace";
var ATTR_EXCEPTION_TYPE = "exception.type";
var ATTR_SERVICE_NAME = "service.name";
var ATTR_TELEMETRY_SDK_LANGUAGE = "telemetry.sdk.language";
var TELEMETRY_SDK_LANGUAGE_VALUE_WEBJS = "webjs";
var ATTR_TELEMETRY_SDK_NAME = "telemetry.sdk.name";
var ATTR_TELEMETRY_SDK_VERSION = "telemetry.sdk.version";

// node_modules/@opentelemetry/core/build/esm/semconv.js
var ATTR_PROCESS_RUNTIME_NAME = "process.runtime.name";

// node_modules/@opentelemetry/core/build/esm/platform/browser/sdk-info.js
var SDK_INFO = {
  [ATTR_TELEMETRY_SDK_NAME]: "opentelemetry",
  [ATTR_PROCESS_RUNTIME_NAME]: "browser",
  [ATTR_TELEMETRY_SDK_LANGUAGE]: TELEMETRY_SDK_LANGUAGE_VALUE_WEBJS,
  [ATTR_TELEMETRY_SDK_VERSION]: VERSION2
};

// node_modules/@opentelemetry/core/build/esm/platform/browser/index.js
var otperformance = performance;

// node_modules/@opentelemetry/core/build/esm/common/time.js
var NANOSECOND_DIGITS = 9;
var NANOSECOND_DIGITS_IN_MILLIS = 6;
var MILLISECONDS_TO_NANOSECONDS = Math.pow(10, NANOSECOND_DIGITS_IN_MILLIS);
var SECOND_TO_NANOSECONDS = Math.pow(10, NANOSECOND_DIGITS);
function millisToHrTime(epochMillis) {
  const epochSeconds = epochMillis / 1e3;
  const seconds = Math.trunc(epochSeconds);
  const nanos = Math.round(epochMillis % 1e3 * MILLISECONDS_TO_NANOSECONDS);
  return [seconds, nanos];
}
function hrTime(performanceNow) {
  const timeOrigin = millisToHrTime(otperformance.timeOrigin);
  const now = millisToHrTime(typeof performanceNow === "number" ? performanceNow : otperformance.now());
  return addHrTimes(timeOrigin, now);
}
function hrTimeDuration(startTime, endTime) {
  let seconds = endTime[0] - startTime[0];
  let nanos = endTime[1] - startTime[1];
  if (nanos < 0) {
    seconds -= 1;
    nanos += SECOND_TO_NANOSECONDS;
  }
  return [seconds, nanos];
}
function isTimeInputHrTime(value) {
  return Array.isArray(value) && value.length === 2 && typeof value[0] === "number" && typeof value[1] === "number";
}
function isTimeInput(value) {
  return isTimeInputHrTime(value) || typeof value === "number" || value instanceof Date;
}
function addHrTimes(time1, time2) {
  const out = [time1[0] + time2[0], time1[1] + time2[1]];
  if (out[1] >= SECOND_TO_NANOSECONDS) {
    out[1] -= SECOND_TO_NANOSECONDS;
    out[0] += 1;
  }
  return out;
}

// node_modules/@opentelemetry/resources/build/esm/default-service-name.js
var serviceName;
function defaultServiceName() {
  if (serviceName === void 0) {
    try {
      const argv0 = globalThis.process.argv0;
      serviceName = argv0 ? `unknown_service:${argv0}` : "unknown_service";
    } catch {
      serviceName = "unknown_service";
    }
  }
  return serviceName;
}

// node_modules/@opentelemetry/resources/build/esm/utils.js
var isPromiseLike = (val) => {
  return val !== null && typeof val === "object" && typeof val.then === "function";
};

// node_modules/@opentelemetry/resources/build/esm/ResourceImpl.js
var ResourceImpl = class _ResourceImpl {
  _rawAttributes;
  _asyncAttributesPending = false;
  _schemaUrl;
  _memoizedAttributes;
  static FromAttributeList(attributes, options) {
    const res = new _ResourceImpl({}, options);
    res._rawAttributes = guardedRawAttributes(attributes);
    res._asyncAttributesPending = attributes.filter(([_, val]) => isPromiseLike(val)).length > 0;
    return res;
  }
  constructor(resource, options) {
    const attributes = resource.attributes ?? {};
    this._rawAttributes = Object.entries(attributes).map(([k, v]) => {
      if (isPromiseLike(v)) {
        this._asyncAttributesPending = true;
      }
      return [k, v];
    });
    this._rawAttributes = guardedRawAttributes(this._rawAttributes);
    this._schemaUrl = validateSchemaUrl(options?.schemaUrl);
  }
  get asyncAttributesPending() {
    return this._asyncAttributesPending;
  }
  async waitForAsyncAttributes() {
    if (!this.asyncAttributesPending) {
      return;
    }
    for (let i = 0; i < this._rawAttributes.length; i++) {
      const [k, v] = this._rawAttributes[i];
      this._rawAttributes[i] = [k, isPromiseLike(v) ? await v : v];
    }
    this._asyncAttributesPending = false;
  }
  get attributes() {
    if (this.asyncAttributesPending) {
      diag.error("Accessing resource attributes before async attributes settled");
    }
    if (this._memoizedAttributes) {
      return this._memoizedAttributes;
    }
    const attrs = {};
    for (const [k, v] of this._rawAttributes) {
      if (isPromiseLike(v)) {
        diag.debug(`Unsettled resource attribute ${k} skipped`);
        continue;
      }
      if (v != null) {
        attrs[k] ??= v;
      }
    }
    if (!this._asyncAttributesPending) {
      this._memoizedAttributes = attrs;
    }
    return attrs;
  }
  getRawAttributes() {
    return this._rawAttributes;
  }
  get schemaUrl() {
    return this._schemaUrl;
  }
  merge(resource) {
    if (resource == null)
      return this;
    const mergedSchemaUrl = mergeSchemaUrl(this, resource);
    const mergedOptions = mergedSchemaUrl ? { schemaUrl: mergedSchemaUrl } : void 0;
    return _ResourceImpl.FromAttributeList([...resource.getRawAttributes(), ...this.getRawAttributes()], mergedOptions);
  }
};
function resourceFromAttributes(attributes, options) {
  return ResourceImpl.FromAttributeList(Object.entries(attributes), options);
}
function defaultResource() {
  return resourceFromAttributes({
    [ATTR_SERVICE_NAME]: defaultServiceName(),
    [ATTR_TELEMETRY_SDK_LANGUAGE]: SDK_INFO[ATTR_TELEMETRY_SDK_LANGUAGE],
    [ATTR_TELEMETRY_SDK_NAME]: SDK_INFO[ATTR_TELEMETRY_SDK_NAME],
    [ATTR_TELEMETRY_SDK_VERSION]: SDK_INFO[ATTR_TELEMETRY_SDK_VERSION]
  });
}
function guardedRawAttributes(attributes) {
  return attributes.map(([k, v]) => {
    if (isPromiseLike(v)) {
      return [
        k,
        v.catch((err) => {
          diag.debug("promise rejection for resource attribute: %s - %s", k, err);
          return void 0;
        })
      ];
    }
    return [k, v];
  });
}
function validateSchemaUrl(schemaUrl) {
  if (typeof schemaUrl === "string" || schemaUrl === void 0) {
    return schemaUrl;
  }
  diag.warn("Schema URL must be string or undefined, got %s. Schema URL will be ignored.", schemaUrl);
  return void 0;
}
function mergeSchemaUrl(old, updating) {
  const oldSchemaUrl = old?.schemaUrl;
  const updatingSchemaUrl = updating?.schemaUrl;
  const isOldEmpty = oldSchemaUrl === void 0 || oldSchemaUrl === "";
  const isUpdatingEmpty = updatingSchemaUrl === void 0 || updatingSchemaUrl === "";
  if (isOldEmpty) {
    return updatingSchemaUrl;
  }
  if (isUpdatingEmpty) {
    return oldSchemaUrl;
  }
  if (oldSchemaUrl === updatingSchemaUrl) {
    return oldSchemaUrl;
  }
  diag.warn('Schema URL merge conflict: old resource has "%s", updating resource has "%s". Resulting resource will have undefined Schema URL.', oldSchemaUrl, updatingSchemaUrl);
  return void 0;
}

// node_modules/@opentelemetry/sdk-trace/build/esm/enums.js
var ExceptionEventName = "exception";

// node_modules/@opentelemetry/sdk-trace/build/esm/inspect.js
var inspectCustom = /* @__PURE__ */ Symbol.for("nodejs.util.inspect.custom");
function settledResourceAttributes(resource) {
  const attrs = {};
  for (const [k, v] of resource.getRawAttributes()) {
    if (typeof v?.then === "function") {
      continue;
    }
    if (v != null) {
      attrs[k] ??= v;
    }
  }
  return attrs;
}
function formatInspect(className, payload, depth, options, inspect) {
  if (typeof depth === "number" && depth < 0) {
    const tag = `[${className}]`;
    return options?.stylize ? options.stylize(tag, "special") : tag;
  }
  if (typeof inspect !== "function" || !options) {
    return payload;
  }
  const childOptions = {
    ...options,
    depth: options.depth == null ? options.depth : options.depth - 1
  };
  return `${className} ${inspect(payload, childOptions)}`;
}

// node_modules/@opentelemetry/sdk-trace/build/esm/Span.js
var SpanImpl = class {
  // Below properties are included to implement ReadableSpan for export
  // purposes but are not intended to be written-to directly.
  _spanContext;
  kind;
  parentSpanContext;
  attributes = {};
  links = [];
  events = [];
  startTime;
  resource;
  instrumentationScope;
  _droppedAttributesCount = 0;
  _droppedEventsCount = 0;
  _droppedLinksCount = 0;
  _attributesCount = 0;
  name;
  status = {
    code: SpanStatusCode.UNSET
  };
  endTime = [0, 0];
  _ended = false;
  _duration = [-1, -1];
  _spanProcessor;
  _spanLimits;
  _attributeValueLengthLimit;
  _recordEndMetrics;
  _performanceStartTime;
  _performanceOffset;
  _startTimeProvided;
  /**
   * Constructs a new SpanImpl instance.
   */
  constructor(opts) {
    const now = Date.now();
    this._spanContext = opts.spanContext;
    this._performanceStartTime = otperformance.now();
    this._performanceOffset = now - (this._performanceStartTime + otperformance.timeOrigin);
    this._startTimeProvided = opts.startTime != null;
    this._spanLimits = opts.spanLimits;
    this._attributeValueLengthLimit = this._spanLimits.attributeValueLengthLimit ?? 0;
    this._spanProcessor = opts.spanProcessor;
    this.name = opts.name;
    this.parentSpanContext = opts.parentSpanContext;
    this.kind = opts.kind;
    if (opts.links) {
      for (const link of opts.links) {
        this.addLink(link);
      }
    }
    this.startTime = this._getTime(opts.startTime ?? now);
    this.resource = opts.resource;
    this.instrumentationScope = opts.scope;
    this._recordEndMetrics = opts.recordEndMetrics;
    if (opts.attributes != null) {
      this.setAttributes(opts.attributes);
    }
    this._spanProcessor.onStart(this, opts.context);
  }
  spanContext() {
    return this._spanContext;
  }
  setAttribute(key, value) {
    if (value == null || this._isSpanEnded())
      return this;
    if (key.length === 0) {
      diag.warn(`Invalid attribute key: ${key}`);
      return this;
    }
    if (!isAttributeValue(value)) {
      diag.warn(`Invalid attribute value set for key: ${key}`);
      return this;
    }
    const { attributeCountLimit } = this._spanLimits;
    const isNewKey = !Object.prototype.hasOwnProperty.call(this.attributes, key);
    if (attributeCountLimit !== void 0 && this._attributesCount >= attributeCountLimit && isNewKey) {
      this._droppedAttributesCount++;
      return this;
    }
    this.attributes[key] = this._truncateToSize(value);
    if (isNewKey) {
      this._attributesCount++;
    }
    return this;
  }
  setAttributes(attributes) {
    for (const key in attributes) {
      if (Object.prototype.hasOwnProperty.call(attributes, key)) {
        this.setAttribute(key, attributes[key]);
      }
    }
    return this;
  }
  /**
   *
   * @param name Span Name
   * @param [attributesOrStartTime] Span attributes or start time
   *     if type is {@type TimeInput} and 3rd param is undefined
   * @param [timeStamp] Specified time stamp for the event
   */
  addEvent(name, attributesOrStartTime, timeStamp) {
    if (this._isSpanEnded())
      return this;
    const { eventCountLimit } = this._spanLimits;
    if (eventCountLimit === 0) {
      diag.warn("No events allowed.");
      this._droppedEventsCount++;
      return this;
    }
    if (eventCountLimit !== void 0 && this.events.length >= eventCountLimit) {
      if (this._droppedEventsCount === 0) {
        diag.debug("Dropping extra events.");
      }
      this.events.shift();
      this._droppedEventsCount++;
    }
    if (isTimeInput(attributesOrStartTime)) {
      if (!isTimeInput(timeStamp)) {
        timeStamp = attributesOrStartTime;
      }
      attributesOrStartTime = void 0;
    }
    const sanitized = sanitizeAttributes(attributesOrStartTime);
    const { attributePerEventCountLimit } = this._spanLimits;
    const attributes = {};
    let droppedAttributesCount = 0;
    let eventAttributesCount = 0;
    for (const attr in sanitized) {
      if (!Object.prototype.hasOwnProperty.call(sanitized, attr)) {
        continue;
      }
      const attrVal = sanitized[attr];
      if (attributePerEventCountLimit !== void 0 && eventAttributesCount >= attributePerEventCountLimit) {
        droppedAttributesCount++;
        continue;
      }
      attributes[attr] = this._truncateToSize(attrVal);
      eventAttributesCount++;
    }
    this.events.push({
      name,
      attributes,
      time: this._getTime(timeStamp),
      droppedAttributesCount
    });
    return this;
  }
  addLink(link) {
    if (this._isSpanEnded())
      return this;
    const { linkCountLimit } = this._spanLimits;
    if (linkCountLimit === 0) {
      this._droppedLinksCount++;
      return this;
    }
    if (linkCountLimit !== void 0 && this.links.length >= linkCountLimit) {
      if (this._droppedLinksCount === 0) {
        diag.debug("Dropping extra links.");
      }
      this.links.shift();
      this._droppedLinksCount++;
    }
    const { attributePerLinkCountLimit } = this._spanLimits;
    const sanitized = sanitizeAttributes(link.attributes);
    const attributes = {};
    let droppedAttributesCount = 0;
    let linkAttributesCount = 0;
    for (const attr in sanitized) {
      if (!Object.prototype.hasOwnProperty.call(sanitized, attr)) {
        continue;
      }
      const attrVal = sanitized[attr];
      if (attributePerLinkCountLimit !== void 0 && linkAttributesCount >= attributePerLinkCountLimit) {
        droppedAttributesCount++;
        continue;
      }
      attributes[attr] = this._truncateToSize(attrVal);
      linkAttributesCount++;
    }
    const processedLink = { context: link.context };
    if (linkAttributesCount > 0) {
      processedLink.attributes = attributes;
    }
    if (droppedAttributesCount > 0) {
      processedLink.droppedAttributesCount = droppedAttributesCount;
    }
    this.links.push(processedLink);
    return this;
  }
  addLinks(links) {
    for (const link of links) {
      this.addLink(link);
    }
    return this;
  }
  setStatus(status) {
    if (this._isSpanEnded())
      return this;
    if (status.code === SpanStatusCode.UNSET)
      return this;
    if (this.status.code === SpanStatusCode.OK)
      return this;
    const newStatus = { code: status.code };
    if (status.code === SpanStatusCode.ERROR) {
      if (typeof status.message === "string") {
        newStatus.message = status.message;
      } else if (status.message != null) {
        diag.warn(`Dropping invalid status.message of type '${typeof status.message}', expected 'string'`);
      }
    }
    this.status = newStatus;
    return this;
  }
  updateName(name) {
    if (this._isSpanEnded())
      return this;
    this.name = name;
    return this;
  }
  end(endTime) {
    if (this._isSpanEnded()) {
      diag.error(`${this.name} ${this._spanContext.traceId}-${this._spanContext.spanId} - You can only call end() on a span once.`);
      return;
    }
    this.endTime = this._getTime(endTime);
    this._duration = hrTimeDuration(this.startTime, this.endTime);
    if (this._duration[0] < 0) {
      diag.warn("Inconsistent start and end time, startTime > endTime. Setting span duration to 0ms.", this.startTime, this.endTime);
      this.endTime = this.startTime.slice();
      this._duration = [0, 0];
    }
    if (this._droppedEventsCount > 0) {
      diag.warn(`Dropped ${this._droppedEventsCount} events because eventCountLimit reached`);
    }
    if (this._droppedLinksCount > 0) {
      diag.warn(`Dropped ${this._droppedLinksCount} links because linkCountLimit reached`);
    }
    if (this._spanProcessor.onEnding) {
      this._spanProcessor.onEnding(this);
    }
    this._recordEndMetrics?.();
    this._ended = true;
    this._spanProcessor.onEnd(this);
  }
  _getTime(inp) {
    if (typeof inp === "number" && inp <= otperformance.now()) {
      return hrTime(inp + this._performanceOffset);
    }
    if (typeof inp === "number") {
      return millisToHrTime(inp);
    }
    if (inp instanceof Date) {
      return millisToHrTime(inp.getTime());
    }
    if (isTimeInputHrTime(inp)) {
      return inp;
    }
    if (this._startTimeProvided) {
      return millisToHrTime(Date.now());
    }
    const msDuration = otperformance.now() - this._performanceStartTime;
    return addHrTimes(this.startTime, millisToHrTime(msDuration));
  }
  isRecording() {
    return this._ended === false;
  }
  recordException(exception, time) {
    const attributes = {};
    if (typeof exception === "string") {
      attributes[ATTR_EXCEPTION_MESSAGE] = exception;
    } else if (exception) {
      if (exception.code) {
        attributes[ATTR_EXCEPTION_TYPE] = exception.code.toString();
      } else if (exception.name) {
        attributes[ATTR_EXCEPTION_TYPE] = exception.name;
      }
      if (exception.message) {
        attributes[ATTR_EXCEPTION_MESSAGE] = exception.message;
      }
      if (exception.stack) {
        attributes[ATTR_EXCEPTION_STACKTRACE] = exception.stack;
      }
    }
    if (attributes[ATTR_EXCEPTION_TYPE] || attributes[ATTR_EXCEPTION_MESSAGE]) {
      this.addEvent(ExceptionEventName, attributes, time);
    } else {
      diag.warn(`Failed to record an exception ${exception}`);
    }
  }
  get duration() {
    return this._duration;
  }
  get ended() {
    return this._ended;
  }
  get droppedAttributesCount() {
    return this._droppedAttributesCount;
  }
  get droppedEventsCount() {
    return this._droppedEventsCount;
  }
  get droppedLinksCount() {
    return this._droppedLinksCount;
  }
  _isSpanEnded() {
    if (this._ended) {
      const error = new Error(`Operation attempted on ended Span {traceId: ${this._spanContext.traceId}, spanId: ${this._spanContext.spanId}}`);
      diag.warn(`Cannot execute the operation on ended Span {traceId: ${this._spanContext.traceId}, spanId: ${this._spanContext.spanId}}`, error);
    }
    return this._ended;
  }
  // Utility function to truncate given value within size
  // for value type of string, will truncate to given limit
  // for type of non-string, will return same value
  _truncateToLimitUtil(value, limit) {
    if (value.length <= limit) {
      return value;
    }
    return value.substring(0, limit);
  }
  /**
   * If the given attribute value is of type string and has more characters than given {@code attributeValueLengthLimit} then
   * return string with truncated to {@code attributeValueLengthLimit} characters
   *
   * If the given attribute value is array of strings then
   * return new array of strings with each element truncated to {@code attributeValueLengthLimit} characters
   *
   * Otherwise return same Attribute {@code value}
   *
   * @param value Attribute value
   * @returns truncated attribute value if required, otherwise same value
   */
  _truncateToSize(value) {
    const limit = this._attributeValueLengthLimit;
    if (limit <= 0) {
      diag.warn(`Attribute value limit must be positive, got ${limit}`);
      return value;
    }
    if (typeof value === "string") {
      return this._truncateToLimitUtil(value, limit);
    }
    if (Array.isArray(value)) {
      return value.map((val) => typeof val === "string" ? this._truncateToLimitUtil(val, limit) : val);
    }
    return value;
  }
  [inspectCustom](depth, options, inspect) {
    const payload = {
      name: this.name,
      kind: this.kind,
      spanContext: this._spanContext,
      parentSpanContext: this.parentSpanContext,
      status: this.status,
      startTime: this.startTime,
      endTime: this.endTime,
      duration: this._duration,
      ended: this._ended,
      attributes: this.attributes,
      events: this.events,
      links: this.links,
      droppedAttributesCount: this._droppedAttributesCount,
      droppedEventsCount: this._droppedEventsCount,
      droppedLinksCount: this._droppedLinksCount,
      instrumentationScope: this.instrumentationScope,
      resource: { attributes: settledResourceAttributes(this.resource) }
    };
    return formatInspect("SpanImpl", payload, depth, options, inspect);
  }
};

// node_modules/@opentelemetry/sdk-trace/build/esm/Sampler.js
var SamplingDecision2;
(function(SamplingDecision3) {
  SamplingDecision3[SamplingDecision3["NOT_RECORD"] = 0] = "NOT_RECORD";
  SamplingDecision3[SamplingDecision3["RECORD"] = 1] = "RECORD";
  SamplingDecision3[SamplingDecision3["RECORD_AND_SAMPLED"] = 2] = "RECORD_AND_SAMPLED";
})(SamplingDecision2 || (SamplingDecision2 = {}));

// node_modules/@opentelemetry/sdk-trace/build/esm/semconv.js
var ATTR_OTEL_SPAN_PARENT_ORIGIN = "otel.span.parent.origin";
var ATTR_OTEL_SPAN_SAMPLING_RESULT = "otel.span.sampling_result";
var METRIC_OTEL_SDK_SPAN_LIVE = "otel.sdk.span.live";
var METRIC_OTEL_SDK_SPAN_STARTED = "otel.sdk.span.started";

// node_modules/@opentelemetry/sdk-trace/build/esm/TracerMetrics.js
var TracerMetrics = class {
  startedSpans;
  liveSpans;
  constructor(meter) {
    this.startedSpans = meter.createCounter(METRIC_OTEL_SDK_SPAN_STARTED, {
      unit: "{span}",
      description: "The number of created spans."
    });
    this.liveSpans = meter.createUpDownCounter(METRIC_OTEL_SDK_SPAN_LIVE, {
      unit: "{span}",
      description: "The number of currently live spans."
    });
  }
  startSpan(parentSpanCtx, samplingDecision) {
    const samplingDecisionStr = samplingDecisionToString(samplingDecision);
    this.startedSpans.add(1, {
      [ATTR_OTEL_SPAN_PARENT_ORIGIN]: parentOrigin(parentSpanCtx),
      [ATTR_OTEL_SPAN_SAMPLING_RESULT]: samplingDecisionStr
    });
    if (samplingDecision === SamplingDecision2.NOT_RECORD) {
      return () => {
      };
    }
    const liveSpanAttributes = {
      [ATTR_OTEL_SPAN_SAMPLING_RESULT]: samplingDecisionStr
    };
    this.liveSpans.add(1, liveSpanAttributes);
    return () => {
      this.liveSpans.add(-1, liveSpanAttributes);
    };
  }
};
function parentOrigin(parentSpanContext) {
  if (!parentSpanContext) {
    return "none";
  }
  if (parentSpanContext.isRemote) {
    return "remote";
  }
  return "local";
}
function samplingDecisionToString(decision) {
  switch (decision) {
    case SamplingDecision2.RECORD_AND_SAMPLED:
      return "RECORD_AND_SAMPLE";
    case SamplingDecision2.RECORD:
      return "RECORD_ONLY";
    case SamplingDecision2.NOT_RECORD:
      return "DROP";
  }
}

// node_modules/@opentelemetry/sdk-trace/build/esm/version.js
var VERSION3 = "2.12.0";

// node_modules/@opentelemetry/sdk-trace/build/esm/Tracer.js
var Tracer = class {
  _sampler;
  _spanLimits;
  _idGenerator;
  instrumentationScope;
  _resource;
  _spanProcessor;
  _tracerMetrics;
  /**
   * Constructs a new Tracer instance.
   */
  constructor(instrumentationScope, options) {
    this.instrumentationScope = instrumentationScope;
    this._sampler = options.sampler;
    this._spanLimits = options.spanLimits;
    this._resource = options.resource;
    this._idGenerator = options.idGenerator;
    this._spanProcessor = options.spanProcessor;
    const meter = options.meterProvider.getMeter("@opentelemetry/sdk-trace", VERSION3);
    this._tracerMetrics = new TracerMetrics(meter);
  }
  /**
   * Starts a new Span or returns the default NoopSpan based on the sampling
   * decision.
   */
  startSpan(name, options = {}, context3 = context.active()) {
    if (options.root) {
      context3 = trace.deleteSpan(context3);
    }
    const parentSpan = trace.getSpan(context3);
    if (isTracingSuppressed(context3)) {
      diag.debug("Instrumentation suppressed, returning Noop Span");
      const nonRecordingSpan = trace.wrapSpanContext(INVALID_SPAN_CONTEXT);
      return nonRecordingSpan;
    }
    const parentSpanContext = parentSpan?.spanContext();
    const spanId = this._idGenerator.generateSpanId();
    let validParentSpanContext;
    let traceId;
    let traceState;
    if (!parentSpanContext || !trace.isSpanContextValid(parentSpanContext)) {
      traceId = this._idGenerator.generateTraceId();
    } else {
      traceId = parentSpanContext.traceId;
      traceState = parentSpanContext.traceState;
      validParentSpanContext = parentSpanContext;
    }
    const spanKind = options.kind ?? SpanKind.INTERNAL;
    const links = (options.links ?? []).map((link) => {
      return {
        context: link.context,
        attributes: sanitizeAttributes(link.attributes)
      };
    });
    const attributes = sanitizeAttributes(options.attributes);
    const samplingResult = this._sampler.shouldSample(context3, traceId, name, spanKind, attributes, links);
    const recordEndMetrics = this._tracerMetrics.startSpan(parentSpanContext, samplingResult.decision);
    traceState = samplingResult.traceState ?? traceState;
    const traceFlags = samplingResult.decision === SamplingDecision.RECORD_AND_SAMPLED ? TraceFlags.SAMPLED : TraceFlags.NONE;
    const spanContext = { traceId, spanId, traceFlags, traceState };
    if (samplingResult.decision === SamplingDecision.NOT_RECORD) {
      diag.debug("Recording is off, propagating context in a non-recording span");
      const nonRecordingSpan = trace.wrapSpanContext(spanContext);
      return nonRecordingSpan;
    }
    const initAttributes = sanitizeAttributes(Object.assign(attributes, samplingResult.attributes));
    const span = new SpanImpl({
      resource: this._resource,
      scope: this.instrumentationScope,
      context: context3,
      spanContext,
      name,
      kind: spanKind,
      links,
      parentSpanContext: validParentSpanContext,
      attributes: initAttributes,
      startTime: options.startTime,
      spanProcessor: this._spanProcessor,
      spanLimits: this._spanLimits,
      recordEndMetrics
    });
    return span;
  }
  startActiveSpan(name, arg2, arg3, arg4) {
    let opts;
    let ctx;
    let fn;
    if (arguments.length < 2) {
      return;
    } else if (arguments.length === 2) {
      fn = arg2;
    } else if (arguments.length === 3) {
      opts = arg2;
      fn = arg3;
    } else {
      opts = arg2;
      ctx = arg3;
      fn = arg4;
    }
    const parentContext = ctx ?? context.active();
    const span = this.startSpan(name, opts, parentContext);
    const contextWithSpanSet = trace.setSpan(parentContext, span);
    return context.with(contextWithSpanSet, fn, void 0, span);
  }
  [inspectCustom](depth, options, inspect) {
    const payload = {
      instrumentationScope: this.instrumentationScope,
      resource: { attributes: settledResourceAttributes(this._resource) },
      spanLimits: this._spanLimits
    };
    return formatInspect("Tracer", payload, depth, options, inspect);
  }
};

// node_modules/@opentelemetry/sdk-trace/build/esm/MultiSpanProcessor.js
var MultiSpanProcessor = class {
  _spanProcessors;
  constructor(spanProcessors) {
    this._spanProcessors = spanProcessors;
  }
  forceFlush() {
    const promises = [];
    for (const spanProcessor of this._spanProcessors) {
      promises.push(spanProcessor.forceFlush());
    }
    return new Promise((resolve) => {
      Promise.all(promises).then(() => {
        resolve();
      }).catch((error) => {
        globalErrorHandler(error || new Error("MultiSpanProcessor: forceFlush failed"));
        resolve();
      });
    });
  }
  onStart(span, context3) {
    for (const spanProcessor of this._spanProcessors) {
      spanProcessor.onStart(span, context3);
    }
  }
  onEnding(span) {
    for (const spanProcessor of this._spanProcessors) {
      if (spanProcessor.onEnding) {
        spanProcessor.onEnding(span);
      }
    }
  }
  onEnd(span) {
    for (const spanProcessor of this._spanProcessors) {
      spanProcessor.onEnd(span);
    }
  }
  shutdown() {
    const promises = [];
    for (const spanProcessor of this._spanProcessors) {
      promises.push(spanProcessor.shutdown());
    }
    return new Promise((resolve, reject) => {
      Promise.all(promises).then(() => {
        resolve();
      }, reject);
    });
  }
};

// node_modules/@opentelemetry/sdk-trace/build/esm/sampler/AlwaysOffSampler.js
var AlwaysOffSampler = class {
  shouldSample() {
    return {
      decision: SamplingDecision2.NOT_RECORD
    };
  }
  toString() {
    return "AlwaysOffSampler";
  }
};

// node_modules/@opentelemetry/sdk-trace/build/esm/sampler/AlwaysOnSampler.js
var AlwaysOnSampler = class {
  shouldSample() {
    return {
      decision: SamplingDecision2.RECORD_AND_SAMPLED
    };
  }
  toString() {
    return "AlwaysOnSampler";
  }
};

// node_modules/@opentelemetry/sdk-trace/build/esm/sampler/ParentBasedSampler.js
var ParentBasedSampler = class {
  _root;
  _remoteParentSampled;
  _remoteParentNotSampled;
  _localParentSampled;
  _localParentNotSampled;
  constructor(config) {
    this._root = config.root;
    if (!this._root) {
      globalErrorHandler(new Error("ParentBasedSampler must have a root sampler configured"));
      this._root = new AlwaysOnSampler();
    }
    this._remoteParentSampled = config.remoteParentSampled ?? new AlwaysOnSampler();
    this._remoteParentNotSampled = config.remoteParentNotSampled ?? new AlwaysOffSampler();
    this._localParentSampled = config.localParentSampled ?? new AlwaysOnSampler();
    this._localParentNotSampled = config.localParentNotSampled ?? new AlwaysOffSampler();
  }
  shouldSample(context3, traceId, spanName, spanKind, attributes, links) {
    const parentContext = trace.getSpanContext(context3);
    if (!parentContext || !isSpanContextValid(parentContext)) {
      return this._root.shouldSample(context3, traceId, spanName, spanKind, attributes, links);
    }
    if (parentContext.isRemote) {
      if (parentContext.traceFlags & TraceFlags.SAMPLED) {
        return this._remoteParentSampled.shouldSample(context3, traceId, spanName, spanKind, attributes, links);
      }
      return this._remoteParentNotSampled.shouldSample(context3, traceId, spanName, spanKind, attributes, links);
    }
    if (parentContext.traceFlags & TraceFlags.SAMPLED) {
      return this._localParentSampled.shouldSample(context3, traceId, spanName, spanKind, attributes, links);
    }
    return this._localParentNotSampled.shouldSample(context3, traceId, spanName, spanKind, attributes, links);
  }
  toString() {
    return `ParentBased{root=${this._root.toString()}, remoteParentSampled=${this._remoteParentSampled.toString()}, remoteParentNotSampled=${this._remoteParentNotSampled.toString()}, localParentSampled=${this._localParentSampled.toString()}, localParentNotSampled=${this._localParentNotSampled.toString()}}`;
  }
};

// node_modules/@opentelemetry/sdk-trace/build/esm/platform/browser/RandomIdGenerator.js
var TRACE_ID_BYTES = 16;
var SPAN_ID_BYTES = 8;
var TRACE_BUFFER = new Uint8Array(TRACE_ID_BYTES);
var SPAN_BUFFER = new Uint8Array(SPAN_ID_BYTES);
var HEX = Array.from({ length: 256 }, (_, i) => i.toString(16).padStart(2, "0"));
function randomFill(buf) {
  for (let i = 0; i < buf.length; i++) {
    buf[i] = Math.random() * 256 >>> 0;
  }
  for (let i = 0; i < buf.length; i++) {
    if (buf[i] > 0)
      return;
  }
  buf[buf.length - 1] = 1;
}
function toHex(buf) {
  let hex = "";
  for (let i = 0; i < buf.length; i++) {
    hex += HEX[buf[i]];
  }
  return hex;
}
var RandomIdGenerator = class {
  /**
   * Returns a random 16-byte trace ID formatted/encoded as a 32 lowercase hex
   * characters corresponding to 128 bits.
   */
  generateTraceId() {
    randomFill(TRACE_BUFFER);
    return toHex(TRACE_BUFFER);
  }
  /**
   * Returns a random 8-byte span ID formatted/encoded as a 16 lowercase hex
   * characters corresponding to 64 bits.
   */
  generateSpanId() {
    randomFill(SPAN_BUFFER);
    return toHex(SPAN_BUFFER);
  }
};

// node_modules/@opentelemetry/sdk-trace/build/esm/TracerProvider.js
var ForceFlushState;
(function(ForceFlushState2) {
  ForceFlushState2[ForceFlushState2["resolved"] = 0] = "resolved";
  ForceFlushState2[ForceFlushState2["timeout"] = 1] = "timeout";
  ForceFlushState2[ForceFlushState2["error"] = 2] = "error";
  ForceFlushState2[ForceFlushState2["unresolved"] = 3] = "unresolved";
})(ForceFlushState || (ForceFlushState = {}));
var TracerProvider = class {
  _resource;
  _activeSpanProcessor;
  _forceFlushTimeoutMillis;
  _tracerOptions;
  _tracers = /* @__PURE__ */ new Map();
  constructor(options = {}) {
    this._forceFlushTimeoutMillis = options.forceFlushTimeoutMillis ?? 3e4;
    this._resource = options.resource ?? defaultResource();
    const spanProcessors = options.spanProcessors ?? [];
    this._activeSpanProcessor = new MultiSpanProcessor(spanProcessors);
    this._tracerOptions = {
      resource: this._resource,
      sampler: options.sampler ?? new ParentBasedSampler({
        root: new AlwaysOnSampler()
      }),
      spanLimits: {
        attributeCountLimit: options.spanLimits?.attributeCountLimit ?? 128,
        attributeValueLengthLimit: options.spanLimits?.attributeValueLengthLimit ?? Infinity,
        eventCountLimit: options.spanLimits?.eventCountLimit ?? 128,
        linkCountLimit: options.spanLimits?.linkCountLimit ?? 128,
        attributePerEventCountLimit: options.spanLimits?.attributePerEventCountLimit ?? 128,
        attributePerLinkCountLimit: options.spanLimits?.attributePerLinkCountLimit ?? 128
      },
      idGenerator: options.idGenerator || new RandomIdGenerator(),
      spanProcessor: this._activeSpanProcessor,
      meterProvider: options.meterProvider ?? {
        getMeter() {
          return createNoopMeter();
        }
      }
    };
  }
  getTracer(name, version, options) {
    const key = `${name}@${version || ""}:${options?.schemaUrl || ""}`;
    if (!this._tracers.has(key)) {
      this._tracers.set(key, new Tracer({ name, version, schemaUrl: options?.schemaUrl }, this._tracerOptions));
    }
    return this._tracers.get(key);
  }
  forceFlush(options) {
    const timeout = options?.timeoutMillis ?? this._forceFlushTimeoutMillis;
    const promises = this._activeSpanProcessor["_spanProcessors"].map((spanProcessor) => {
      return new Promise((resolve) => {
        let state;
        const timeoutInterval = setTimeout(() => {
          resolve(new Error(`Span processor did not completed within timeout period of ${timeout} ms`));
          state = ForceFlushState.timeout;
        }, timeout);
        spanProcessor.forceFlush().then(() => {
          clearTimeout(timeoutInterval);
          if (state !== ForceFlushState.timeout) {
            state = ForceFlushState.resolved;
            resolve(state);
          }
        }).catch((error) => {
          clearTimeout(timeoutInterval);
          state = ForceFlushState.error;
          resolve(error);
        });
      });
    });
    return new Promise((resolve, reject) => {
      Promise.all(promises).then((results) => {
        const errors = results.filter((result) => result !== ForceFlushState.resolved);
        if (errors.length > 0) {
          reject(errors);
        } else {
          resolve();
        }
      }).catch((error) => reject([error]));
    });
  }
  shutdown() {
    return this._activeSpanProcessor.shutdown();
  }
  [inspectCustom](depth, options, inspect) {
    const processors = this._activeSpanProcessor["_spanProcessors"];
    const payload = {
      resource: { attributes: settledResourceAttributes(this._resource) },
      tracers: Array.from(this._tracers.keys()),
      spanProcessors: processors.map((p) => p.constructor?.name ?? "SpanProcessor")
    };
    return formatInspect("TracerProvider", payload, depth, options, inspect);
  }
};

// ../node-migration-final-skills/vibelens/scripts/bo_observer/adapters/javascript/node_modules/@opentelemetry/api/build/esm/platform/browser/globalThis.js
var _globalThis3 = typeof globalThis === "object" ? globalThis : typeof self === "object" ? self : typeof window === "object" ? window : typeof global === "object" ? global : {};

// ../node-migration-final-skills/vibelens/scripts/bo_observer/adapters/javascript/node_modules/@opentelemetry/api/build/esm/version.js
var VERSION4 = "1.9.0";

// ../node-migration-final-skills/vibelens/scripts/bo_observer/adapters/javascript/node_modules/@opentelemetry/api/build/esm/internal/semver.js
var re2 = /^(\d+)\.(\d+)\.(\d+)(-(.+))?$/;
function _makeCompatibilityCheck2(ownVersion) {
  var acceptedVersions = /* @__PURE__ */ new Set([ownVersion]);
  var rejectedVersions = /* @__PURE__ */ new Set();
  var myVersionMatch = ownVersion.match(re2);
  if (!myVersionMatch) {
    return function() {
      return false;
    };
  }
  var ownVersionParsed = {
    major: +myVersionMatch[1],
    minor: +myVersionMatch[2],
    patch: +myVersionMatch[3],
    prerelease: myVersionMatch[4]
  };
  if (ownVersionParsed.prerelease != null) {
    return function isExactmatch(globalVersion) {
      return globalVersion === ownVersion;
    };
  }
  function _reject(v) {
    rejectedVersions.add(v);
    return false;
  }
  function _accept(v) {
    acceptedVersions.add(v);
    return true;
  }
  return function isCompatible3(globalVersion) {
    if (acceptedVersions.has(globalVersion)) {
      return true;
    }
    if (rejectedVersions.has(globalVersion)) {
      return false;
    }
    var globalVersionMatch = globalVersion.match(re2);
    if (!globalVersionMatch) {
      return _reject(globalVersion);
    }
    var globalVersionParsed = {
      major: +globalVersionMatch[1],
      minor: +globalVersionMatch[2],
      patch: +globalVersionMatch[3],
      prerelease: globalVersionMatch[4]
    };
    if (globalVersionParsed.prerelease != null) {
      return _reject(globalVersion);
    }
    if (ownVersionParsed.major !== globalVersionParsed.major) {
      return _reject(globalVersion);
    }
    if (ownVersionParsed.major === 0) {
      if (ownVersionParsed.minor === globalVersionParsed.minor && ownVersionParsed.patch <= globalVersionParsed.patch) {
        return _accept(globalVersion);
      }
      return _reject(globalVersion);
    }
    if (ownVersionParsed.minor <= globalVersionParsed.minor) {
      return _accept(globalVersion);
    }
    return _reject(globalVersion);
  };
}
var isCompatible2 = _makeCompatibilityCheck2(VERSION4);

// ../node-migration-final-skills/vibelens/scripts/bo_observer/adapters/javascript/node_modules/@opentelemetry/api/build/esm/internal/global-utils.js
var major2 = VERSION4.split(".")[0];
var GLOBAL_OPENTELEMETRY_API_KEY2 = /* @__PURE__ */ Symbol.for("opentelemetry.js.api." + major2);
var _global2 = _globalThis3;
function registerGlobal2(type, instance, diag2, allowOverride) {
  var _a;
  if (allowOverride === void 0) {
    allowOverride = false;
  }
  var api = _global2[GLOBAL_OPENTELEMETRY_API_KEY2] = (_a = _global2[GLOBAL_OPENTELEMETRY_API_KEY2]) !== null && _a !== void 0 ? _a : {
    version: VERSION4
  };
  if (!allowOverride && api[type]) {
    var err = new Error("@opentelemetry/api: Attempted duplicate registration of API: " + type);
    diag2.error(err.stack || err.message);
    return false;
  }
  if (api.version !== VERSION4) {
    var err = new Error("@opentelemetry/api: Registration of version v" + api.version + " for " + type + " does not match previously registered API v" + VERSION4);
    diag2.error(err.stack || err.message);
    return false;
  }
  api[type] = instance;
  diag2.debug("@opentelemetry/api: Registered a global for " + type + " v" + VERSION4 + ".");
  return true;
}
function getGlobal2(type) {
  var _a, _b;
  var globalVersion = (_a = _global2[GLOBAL_OPENTELEMETRY_API_KEY2]) === null || _a === void 0 ? void 0 : _a.version;
  if (!globalVersion || !isCompatible2(globalVersion)) {
    return;
  }
  return (_b = _global2[GLOBAL_OPENTELEMETRY_API_KEY2]) === null || _b === void 0 ? void 0 : _b[type];
}
function unregisterGlobal2(type, diag2) {
  diag2.debug("@opentelemetry/api: Unregistering a global for " + type + " v" + VERSION4 + ".");
  var api = _global2[GLOBAL_OPENTELEMETRY_API_KEY2];
  if (api) {
    delete api[type];
  }
}

// ../node-migration-final-skills/vibelens/scripts/bo_observer/adapters/javascript/node_modules/@opentelemetry/api/build/esm/diag/ComponentLogger.js
var __read5 = function(o, n) {
  var m = typeof Symbol === "function" && o[Symbol.iterator];
  if (!m) return o;
  var i = m.call(o), r, ar = [], e;
  try {
    while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
  } catch (error) {
    e = { error };
  } finally {
    try {
      if (r && !r.done && (m = i["return"])) m.call(i);
    } finally {
      if (e) throw e.error;
    }
  }
  return ar;
};
var __spreadArray5 = function(to, from, pack) {
  if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
    if (ar || !(i in from)) {
      if (!ar) ar = Array.prototype.slice.call(from, 0, i);
      ar[i] = from[i];
    }
  }
  return to.concat(ar || Array.prototype.slice.call(from));
};
var DiagComponentLogger2 = (
  /** @class */
  (function() {
    function DiagComponentLogger3(props) {
      this._namespace = props.namespace || "DiagComponentLogger";
    }
    DiagComponentLogger3.prototype.debug = function() {
      var args = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
      }
      return logProxy2("debug", this._namespace, args);
    };
    DiagComponentLogger3.prototype.error = function() {
      var args = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
      }
      return logProxy2("error", this._namespace, args);
    };
    DiagComponentLogger3.prototype.info = function() {
      var args = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
      }
      return logProxy2("info", this._namespace, args);
    };
    DiagComponentLogger3.prototype.warn = function() {
      var args = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
      }
      return logProxy2("warn", this._namespace, args);
    };
    DiagComponentLogger3.prototype.verbose = function() {
      var args = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
      }
      return logProxy2("verbose", this._namespace, args);
    };
    return DiagComponentLogger3;
  })()
);
function logProxy2(funcName, namespace, args) {
  var logger = getGlobal2("diag");
  if (!logger) {
    return;
  }
  args.unshift(namespace);
  return logger[funcName].apply(logger, __spreadArray5([], __read5(args), false));
}

// ../node-migration-final-skills/vibelens/scripts/bo_observer/adapters/javascript/node_modules/@opentelemetry/api/build/esm/diag/types.js
var DiagLogLevel2;
(function(DiagLogLevel3) {
  DiagLogLevel3[DiagLogLevel3["NONE"] = 0] = "NONE";
  DiagLogLevel3[DiagLogLevel3["ERROR"] = 30] = "ERROR";
  DiagLogLevel3[DiagLogLevel3["WARN"] = 50] = "WARN";
  DiagLogLevel3[DiagLogLevel3["INFO"] = 60] = "INFO";
  DiagLogLevel3[DiagLogLevel3["DEBUG"] = 70] = "DEBUG";
  DiagLogLevel3[DiagLogLevel3["VERBOSE"] = 80] = "VERBOSE";
  DiagLogLevel3[DiagLogLevel3["ALL"] = 9999] = "ALL";
})(DiagLogLevel2 || (DiagLogLevel2 = {}));

// ../node-migration-final-skills/vibelens/scripts/bo_observer/adapters/javascript/node_modules/@opentelemetry/api/build/esm/diag/internal/logLevelLogger.js
function createLogLevelDiagLogger2(maxLevel, logger) {
  if (maxLevel < DiagLogLevel2.NONE) {
    maxLevel = DiagLogLevel2.NONE;
  } else if (maxLevel > DiagLogLevel2.ALL) {
    maxLevel = DiagLogLevel2.ALL;
  }
  logger = logger || {};
  function _filterFunc(funcName, theLevel) {
    var theFunc = logger[funcName];
    if (typeof theFunc === "function" && maxLevel >= theLevel) {
      return theFunc.bind(logger);
    }
    return function() {
    };
  }
  return {
    error: _filterFunc("error", DiagLogLevel2.ERROR),
    warn: _filterFunc("warn", DiagLogLevel2.WARN),
    info: _filterFunc("info", DiagLogLevel2.INFO),
    debug: _filterFunc("debug", DiagLogLevel2.DEBUG),
    verbose: _filterFunc("verbose", DiagLogLevel2.VERBOSE)
  };
}

// ../node-migration-final-skills/vibelens/scripts/bo_observer/adapters/javascript/node_modules/@opentelemetry/api/build/esm/api/diag.js
var __read6 = function(o, n) {
  var m = typeof Symbol === "function" && o[Symbol.iterator];
  if (!m) return o;
  var i = m.call(o), r, ar = [], e;
  try {
    while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
  } catch (error) {
    e = { error };
  } finally {
    try {
      if (r && !r.done && (m = i["return"])) m.call(i);
    } finally {
      if (e) throw e.error;
    }
  }
  return ar;
};
var __spreadArray6 = function(to, from, pack) {
  if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
    if (ar || !(i in from)) {
      if (!ar) ar = Array.prototype.slice.call(from, 0, i);
      ar[i] = from[i];
    }
  }
  return to.concat(ar || Array.prototype.slice.call(from));
};
var API_NAME4 = "diag";
var DiagAPI2 = (
  /** @class */
  (function() {
    function DiagAPI3() {
      function _logProxy(funcName) {
        return function() {
          var args = [];
          for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
          }
          var logger = getGlobal2("diag");
          if (!logger)
            return;
          return logger[funcName].apply(logger, __spreadArray6([], __read6(args), false));
        };
      }
      var self2 = this;
      var setLogger = function(logger, optionsOrLogLevel) {
        var _a, _b, _c;
        if (optionsOrLogLevel === void 0) {
          optionsOrLogLevel = { logLevel: DiagLogLevel2.INFO };
        }
        if (logger === self2) {
          var err = new Error("Cannot use diag as the logger for itself. Please use a DiagLogger implementation like ConsoleDiagLogger or a custom implementation");
          self2.error((_a = err.stack) !== null && _a !== void 0 ? _a : err.message);
          return false;
        }
        if (typeof optionsOrLogLevel === "number") {
          optionsOrLogLevel = {
            logLevel: optionsOrLogLevel
          };
        }
        var oldLogger = getGlobal2("diag");
        var newLogger = createLogLevelDiagLogger2((_b = optionsOrLogLevel.logLevel) !== null && _b !== void 0 ? _b : DiagLogLevel2.INFO, logger);
        if (oldLogger && !optionsOrLogLevel.suppressOverrideMessage) {
          var stack = (_c = new Error().stack) !== null && _c !== void 0 ? _c : "<failed to generate stacktrace>";
          oldLogger.warn("Current logger will be overwritten from " + stack);
          newLogger.warn("Current logger will overwrite one already registered from " + stack);
        }
        return registerGlobal2("diag", newLogger, self2, true);
      };
      self2.setLogger = setLogger;
      self2.disable = function() {
        unregisterGlobal2(API_NAME4, self2);
      };
      self2.createComponentLogger = function(options) {
        return new DiagComponentLogger2(options);
      };
      self2.verbose = _logProxy("verbose");
      self2.debug = _logProxy("debug");
      self2.info = _logProxy("info");
      self2.warn = _logProxy("warn");
      self2.error = _logProxy("error");
    }
    DiagAPI3.instance = function() {
      if (!this._instance) {
        this._instance = new DiagAPI3();
      }
      return this._instance;
    };
    return DiagAPI3;
  })()
);

// ../node-migration-final-skills/vibelens/scripts/bo_observer/adapters/javascript/node_modules/@opentelemetry/api/build/esm/context/context.js
function createContextKey2(description) {
  return Symbol.for(description);
}
var BaseContext2 = (
  /** @class */
  /* @__PURE__ */ (function() {
    function BaseContext3(parentContext) {
      var self2 = this;
      self2._currentContext = parentContext ? new Map(parentContext) : /* @__PURE__ */ new Map();
      self2.getValue = function(key) {
        return self2._currentContext.get(key);
      };
      self2.setValue = function(key, value) {
        var context3 = new BaseContext3(self2._currentContext);
        context3._currentContext.set(key, value);
        return context3;
      };
      self2.deleteValue = function(key) {
        var context3 = new BaseContext3(self2._currentContext);
        context3._currentContext.delete(key);
        return context3;
      };
    }
    return BaseContext3;
  })()
);
var ROOT_CONTEXT2 = new BaseContext2();

// ../node-migration-final-skills/vibelens/scripts/bo_observer/adapters/javascript/node_modules/@opentelemetry/api/build/esm/context/NoopContextManager.js
var __read7 = function(o, n) {
  var m = typeof Symbol === "function" && o[Symbol.iterator];
  if (!m) return o;
  var i = m.call(o), r, ar = [], e;
  try {
    while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
  } catch (error) {
    e = { error };
  } finally {
    try {
      if (r && !r.done && (m = i["return"])) m.call(i);
    } finally {
      if (e) throw e.error;
    }
  }
  return ar;
};
var __spreadArray7 = function(to, from, pack) {
  if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
    if (ar || !(i in from)) {
      if (!ar) ar = Array.prototype.slice.call(from, 0, i);
      ar[i] = from[i];
    }
  }
  return to.concat(ar || Array.prototype.slice.call(from));
};
var NoopContextManager2 = (
  /** @class */
  (function() {
    function NoopContextManager3() {
    }
    NoopContextManager3.prototype.active = function() {
      return ROOT_CONTEXT2;
    };
    NoopContextManager3.prototype.with = function(_context, fn, thisArg) {
      var args = [];
      for (var _i = 3; _i < arguments.length; _i++) {
        args[_i - 3] = arguments[_i];
      }
      return fn.call.apply(fn, __spreadArray7([thisArg], __read7(args), false));
    };
    NoopContextManager3.prototype.bind = function(_context, target) {
      return target;
    };
    NoopContextManager3.prototype.enable = function() {
      return this;
    };
    NoopContextManager3.prototype.disable = function() {
      return this;
    };
    return NoopContextManager3;
  })()
);

// ../node-migration-final-skills/vibelens/scripts/bo_observer/adapters/javascript/node_modules/@opentelemetry/api/build/esm/api/context.js
var __read8 = function(o, n) {
  var m = typeof Symbol === "function" && o[Symbol.iterator];
  if (!m) return o;
  var i = m.call(o), r, ar = [], e;
  try {
    while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
  } catch (error) {
    e = { error };
  } finally {
    try {
      if (r && !r.done && (m = i["return"])) m.call(i);
    } finally {
      if (e) throw e.error;
    }
  }
  return ar;
};
var __spreadArray8 = function(to, from, pack) {
  if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
    if (ar || !(i in from)) {
      if (!ar) ar = Array.prototype.slice.call(from, 0, i);
      ar[i] = from[i];
    }
  }
  return to.concat(ar || Array.prototype.slice.call(from));
};
var API_NAME5 = "context";
var NOOP_CONTEXT_MANAGER2 = new NoopContextManager2();
var ContextAPI2 = (
  /** @class */
  (function() {
    function ContextAPI3() {
    }
    ContextAPI3.getInstance = function() {
      if (!this._instance) {
        this._instance = new ContextAPI3();
      }
      return this._instance;
    };
    ContextAPI3.prototype.setGlobalContextManager = function(contextManager) {
      return registerGlobal2(API_NAME5, contextManager, DiagAPI2.instance());
    };
    ContextAPI3.prototype.active = function() {
      return this._getContextManager().active();
    };
    ContextAPI3.prototype.with = function(context3, fn, thisArg) {
      var _a;
      var args = [];
      for (var _i = 3; _i < arguments.length; _i++) {
        args[_i - 3] = arguments[_i];
      }
      return (_a = this._getContextManager()).with.apply(_a, __spreadArray8([context3, fn, thisArg], __read8(args), false));
    };
    ContextAPI3.prototype.bind = function(context3, target) {
      return this._getContextManager().bind(context3, target);
    };
    ContextAPI3.prototype._getContextManager = function() {
      return getGlobal2(API_NAME5) || NOOP_CONTEXT_MANAGER2;
    };
    ContextAPI3.prototype.disable = function() {
      this._getContextManager().disable();
      unregisterGlobal2(API_NAME5, DiagAPI2.instance());
    };
    return ContextAPI3;
  })()
);

// ../node-migration-final-skills/vibelens/scripts/bo_observer/adapters/javascript/node_modules/@opentelemetry/api/build/esm/trace/trace_flags.js
var TraceFlags2;
(function(TraceFlags3) {
  TraceFlags3[TraceFlags3["NONE"] = 0] = "NONE";
  TraceFlags3[TraceFlags3["SAMPLED"] = 1] = "SAMPLED";
})(TraceFlags2 || (TraceFlags2 = {}));

// ../node-migration-final-skills/vibelens/scripts/bo_observer/adapters/javascript/node_modules/@opentelemetry/api/build/esm/trace/invalid-span-constants.js
var INVALID_SPANID2 = "0000000000000000";
var INVALID_TRACEID2 = "00000000000000000000000000000000";
var INVALID_SPAN_CONTEXT2 = {
  traceId: INVALID_TRACEID2,
  spanId: INVALID_SPANID2,
  traceFlags: TraceFlags2.NONE
};

// ../node-migration-final-skills/vibelens/scripts/bo_observer/adapters/javascript/node_modules/@opentelemetry/api/build/esm/trace/NonRecordingSpan.js
var NonRecordingSpan2 = (
  /** @class */
  (function() {
    function NonRecordingSpan3(_spanContext) {
      if (_spanContext === void 0) {
        _spanContext = INVALID_SPAN_CONTEXT2;
      }
      this._spanContext = _spanContext;
    }
    NonRecordingSpan3.prototype.spanContext = function() {
      return this._spanContext;
    };
    NonRecordingSpan3.prototype.setAttribute = function(_key, _value) {
      return this;
    };
    NonRecordingSpan3.prototype.setAttributes = function(_attributes) {
      return this;
    };
    NonRecordingSpan3.prototype.addEvent = function(_name, _attributes) {
      return this;
    };
    NonRecordingSpan3.prototype.addLink = function(_link) {
      return this;
    };
    NonRecordingSpan3.prototype.addLinks = function(_links) {
      return this;
    };
    NonRecordingSpan3.prototype.setStatus = function(_status) {
      return this;
    };
    NonRecordingSpan3.prototype.updateName = function(_name) {
      return this;
    };
    NonRecordingSpan3.prototype.end = function(_endTime) {
    };
    NonRecordingSpan3.prototype.isRecording = function() {
      return false;
    };
    NonRecordingSpan3.prototype.recordException = function(_exception, _time) {
    };
    return NonRecordingSpan3;
  })()
);

// ../node-migration-final-skills/vibelens/scripts/bo_observer/adapters/javascript/node_modules/@opentelemetry/api/build/esm/trace/context-utils.js
var SPAN_KEY2 = createContextKey2("OpenTelemetry Context Key SPAN");
function getSpan2(context3) {
  return context3.getValue(SPAN_KEY2) || void 0;
}
function getActiveSpan2() {
  return getSpan2(ContextAPI2.getInstance().active());
}
function setSpan2(context3, span) {
  return context3.setValue(SPAN_KEY2, span);
}
function deleteSpan2(context3) {
  return context3.deleteValue(SPAN_KEY2);
}
function setSpanContext2(context3, spanContext) {
  return setSpan2(context3, new NonRecordingSpan2(spanContext));
}
function getSpanContext2(context3) {
  var _a;
  return (_a = getSpan2(context3)) === null || _a === void 0 ? void 0 : _a.spanContext();
}

// ../node-migration-final-skills/vibelens/scripts/bo_observer/adapters/javascript/node_modules/@opentelemetry/api/build/esm/trace/spancontext-utils.js
var VALID_TRACEID_REGEX2 = /^([0-9a-f]{32})$/i;
var VALID_SPANID_REGEX2 = /^[0-9a-f]{16}$/i;
function isValidTraceId2(traceId) {
  return VALID_TRACEID_REGEX2.test(traceId) && traceId !== INVALID_TRACEID2;
}
function isValidSpanId2(spanId) {
  return VALID_SPANID_REGEX2.test(spanId) && spanId !== INVALID_SPANID2;
}
function isSpanContextValid2(spanContext) {
  return isValidTraceId2(spanContext.traceId) && isValidSpanId2(spanContext.spanId);
}
function wrapSpanContext2(spanContext) {
  return new NonRecordingSpan2(spanContext);
}

// ../node-migration-final-skills/vibelens/scripts/bo_observer/adapters/javascript/node_modules/@opentelemetry/api/build/esm/trace/NoopTracer.js
var contextApi2 = ContextAPI2.getInstance();
var NoopTracer2 = (
  /** @class */
  (function() {
    function NoopTracer3() {
    }
    NoopTracer3.prototype.startSpan = function(name, options, context3) {
      if (context3 === void 0) {
        context3 = contextApi2.active();
      }
      var root = Boolean(options === null || options === void 0 ? void 0 : options.root);
      if (root) {
        return new NonRecordingSpan2();
      }
      var parentFromContext = context3 && getSpanContext2(context3);
      if (isSpanContext2(parentFromContext) && isSpanContextValid2(parentFromContext)) {
        return new NonRecordingSpan2(parentFromContext);
      } else {
        return new NonRecordingSpan2();
      }
    };
    NoopTracer3.prototype.startActiveSpan = function(name, arg2, arg3, arg4) {
      var opts;
      var ctx;
      var fn;
      if (arguments.length < 2) {
        return;
      } else if (arguments.length === 2) {
        fn = arg2;
      } else if (arguments.length === 3) {
        opts = arg2;
        fn = arg3;
      } else {
        opts = arg2;
        ctx = arg3;
        fn = arg4;
      }
      var parentContext = ctx !== null && ctx !== void 0 ? ctx : contextApi2.active();
      var span = this.startSpan(name, opts, parentContext);
      var contextWithSpanSet = setSpan2(parentContext, span);
      return contextApi2.with(contextWithSpanSet, fn, void 0, span);
    };
    return NoopTracer3;
  })()
);
function isSpanContext2(spanContext) {
  return typeof spanContext === "object" && typeof spanContext["spanId"] === "string" && typeof spanContext["traceId"] === "string" && typeof spanContext["traceFlags"] === "number";
}

// ../node-migration-final-skills/vibelens/scripts/bo_observer/adapters/javascript/node_modules/@opentelemetry/api/build/esm/trace/ProxyTracer.js
var NOOP_TRACER2 = new NoopTracer2();
var ProxyTracer2 = (
  /** @class */
  (function() {
    function ProxyTracer3(_provider, name, version, options) {
      this._provider = _provider;
      this.name = name;
      this.version = version;
      this.options = options;
    }
    ProxyTracer3.prototype.startSpan = function(name, options, context3) {
      return this._getTracer().startSpan(name, options, context3);
    };
    ProxyTracer3.prototype.startActiveSpan = function(_name, _options, _context, _fn) {
      var tracer = this._getTracer();
      return Reflect.apply(tracer.startActiveSpan, tracer, arguments);
    };
    ProxyTracer3.prototype._getTracer = function() {
      if (this._delegate) {
        return this._delegate;
      }
      var tracer = this._provider.getDelegateTracer(this.name, this.version, this.options);
      if (!tracer) {
        return NOOP_TRACER2;
      }
      this._delegate = tracer;
      return this._delegate;
    };
    return ProxyTracer3;
  })()
);

// ../node-migration-final-skills/vibelens/scripts/bo_observer/adapters/javascript/node_modules/@opentelemetry/api/build/esm/trace/NoopTracerProvider.js
var NoopTracerProvider2 = (
  /** @class */
  (function() {
    function NoopTracerProvider3() {
    }
    NoopTracerProvider3.prototype.getTracer = function(_name, _version, _options) {
      return new NoopTracer2();
    };
    return NoopTracerProvider3;
  })()
);

// ../node-migration-final-skills/vibelens/scripts/bo_observer/adapters/javascript/node_modules/@opentelemetry/api/build/esm/trace/ProxyTracerProvider.js
var NOOP_TRACER_PROVIDER2 = new NoopTracerProvider2();
var ProxyTracerProvider2 = (
  /** @class */
  (function() {
    function ProxyTracerProvider3() {
    }
    ProxyTracerProvider3.prototype.getTracer = function(name, version, options) {
      var _a;
      return (_a = this.getDelegateTracer(name, version, options)) !== null && _a !== void 0 ? _a : new ProxyTracer2(this, name, version, options);
    };
    ProxyTracerProvider3.prototype.getDelegate = function() {
      var _a;
      return (_a = this._delegate) !== null && _a !== void 0 ? _a : NOOP_TRACER_PROVIDER2;
    };
    ProxyTracerProvider3.prototype.setDelegate = function(delegate) {
      this._delegate = delegate;
    };
    ProxyTracerProvider3.prototype.getDelegateTracer = function(name, version, options) {
      var _a;
      return (_a = this._delegate) === null || _a === void 0 ? void 0 : _a.getTracer(name, version, options);
    };
    return ProxyTracerProvider3;
  })()
);

// ../node-migration-final-skills/vibelens/scripts/bo_observer/adapters/javascript/node_modules/@opentelemetry/api/build/esm/trace/status.js
var SpanStatusCode2;
(function(SpanStatusCode3) {
  SpanStatusCode3[SpanStatusCode3["UNSET"] = 0] = "UNSET";
  SpanStatusCode3[SpanStatusCode3["OK"] = 1] = "OK";
  SpanStatusCode3[SpanStatusCode3["ERROR"] = 2] = "ERROR";
})(SpanStatusCode2 || (SpanStatusCode2 = {}));

// ../node-migration-final-skills/vibelens/scripts/bo_observer/adapters/javascript/node_modules/@opentelemetry/api/build/esm/context-api.js
var context2 = ContextAPI2.getInstance();

// ../node-migration-final-skills/vibelens/scripts/bo_observer/adapters/javascript/node_modules/@opentelemetry/api/build/esm/api/trace.js
var API_NAME6 = "trace";
var TraceAPI2 = (
  /** @class */
  (function() {
    function TraceAPI3() {
      this._proxyTracerProvider = new ProxyTracerProvider2();
      this.wrapSpanContext = wrapSpanContext2;
      this.isSpanContextValid = isSpanContextValid2;
      this.deleteSpan = deleteSpan2;
      this.getSpan = getSpan2;
      this.getActiveSpan = getActiveSpan2;
      this.getSpanContext = getSpanContext2;
      this.setSpan = setSpan2;
      this.setSpanContext = setSpanContext2;
    }
    TraceAPI3.getInstance = function() {
      if (!this._instance) {
        this._instance = new TraceAPI3();
      }
      return this._instance;
    };
    TraceAPI3.prototype.setGlobalTracerProvider = function(provider) {
      var success = registerGlobal2(API_NAME6, this._proxyTracerProvider, DiagAPI2.instance());
      if (success) {
        this._proxyTracerProvider.setDelegate(provider);
      }
      return success;
    };
    TraceAPI3.prototype.getTracerProvider = function() {
      return getGlobal2(API_NAME6) || this._proxyTracerProvider;
    };
    TraceAPI3.prototype.getTracer = function(name, version) {
      return this.getTracerProvider().getTracer(name, version);
    };
    TraceAPI3.prototype.disable = function() {
      unregisterGlobal2(API_NAME6, DiagAPI2.instance());
      this._proxyTracerProvider = new ProxyTracerProvider2();
    };
    return TraceAPI3;
  })()
);

// ../node-migration-final-skills/vibelens/scripts/bo_observer/adapters/javascript/node_modules/@opentelemetry/api/build/esm/trace-api.js
var trace2 = TraceAPI2.getInstance();

// ../node-migration-final-skills/vibelens/scripts/bo_observer/adapters/javascript/node_modules/@opentelemetry/core/build/esm/trace/suppress-tracing.js
var SUPPRESS_TRACING_KEY2 = createContextKey2("OpenTelemetry SDK Context Key SUPPRESS_TRACING");
function suppressTracing2(context3) {
  return context3.setValue(SUPPRESS_TRACING_KEY2, true);
}
function isTracingSuppressed2(context3) {
  return context3.getValue(SUPPRESS_TRACING_KEY2) === true;
}

// ../node-migration-final-skills/vibelens/scripts/bo_observer/adapters/javascript/node_modules/@opentelemetry/core/build/esm/internal/validators.js
var VALID_KEY_CHAR_RANGE = "[_0-9a-z-*/]";
var VALID_KEY = `[a-z]${VALID_KEY_CHAR_RANGE}{0,255}`;
var VALID_VENDOR_KEY = `[a-z0-9]${VALID_KEY_CHAR_RANGE}{0,240}@[a-z]${VALID_KEY_CHAR_RANGE}{0,13}`;
var VALID_KEY_REGEX = new RegExp(`^(?:${VALID_KEY}|${VALID_VENDOR_KEY})$`);
var VALID_VALUE_BASE_REGEX = /^[ -~]{0,255}[!-~]$/;
var INVALID_VALUE_COMMA_EQUAL_REGEX = /,|=/;
function validateKey(key) {
  return VALID_KEY_REGEX.test(key);
}
function validateValue(value) {
  return VALID_VALUE_BASE_REGEX.test(value) && !INVALID_VALUE_COMMA_EQUAL_REGEX.test(value);
}

// ../node-migration-final-skills/vibelens/scripts/bo_observer/adapters/javascript/node_modules/@opentelemetry/core/build/esm/trace/TraceState.js
var MAX_TRACE_STATE_ITEMS = 32;
var MAX_TRACE_STATE_LEN = 512;
var LIST_MEMBERS_SEPARATOR = ",";
var LIST_MEMBER_KEY_VALUE_SPLITTER = "=";
var TraceState = class _TraceState {
  _length;
  _rawTraceState;
  _internalState;
  constructor(rawTraceState) {
    this._rawTraceState = typeof rawTraceState === "string" ? rawTraceState : "";
    this._length = this._rawTraceState.length;
  }
  set(key, value) {
    if (!validateKey(key) || !validateValue(value)) {
      return this;
    }
    const currState = this._getState();
    const currValue = currState.get(key);
    let newLength = this._length;
    if (typeof currValue === "string") {
      newLength += value.length - currValue.length;
    } else {
      newLength += key.length + value.length + (currState.size > 0 ? 2 : 1);
    }
    if (newLength > MAX_TRACE_STATE_LEN) {
      return this;
    }
    const newState = new Map(currState);
    newState.delete(key);
    newState.set(key, value);
    return this._fromState(newState, newLength);
  }
  unset(key) {
    const currState = this._getState();
    const currValue = currState.get(key);
    if (typeof currValue !== "string") {
      return this;
    }
    let newLength = this._length - (key.length + currValue.length + 1);
    if (currState.size > 1) {
      newLength = newLength - 1;
    }
    const newState = new Map(currState);
    newState.delete(key);
    return this._fromState(newState, newLength);
  }
  get(key) {
    const currState = this._getState();
    return currState.get(key);
  }
  serialize() {
    let serialized = "";
    let index = 0;
    for (const entry of this._getState()) {
      if (index > 0) {
        serialized = LIST_MEMBERS_SEPARATOR + serialized;
      }
      serialized = `${entry[0]}${LIST_MEMBER_KEY_VALUE_SPLITTER}${entry[1]}` + serialized;
      index++;
    }
    return serialized;
  }
  _getState() {
    if (this._internalState) {
      return this._internalState;
    }
    const vendorMembers = this._rawTraceState.split(LIST_MEMBERS_SEPARATOR);
    const vendorEntries = /* @__PURE__ */ new Map();
    let currentLength = 0;
    for (const member of vendorMembers) {
      const m = member.trim();
      const idx = m.indexOf(LIST_MEMBER_KEY_VALUE_SPLITTER);
      if (idx === -1) {
        continue;
      }
      const key = m.slice(0, idx);
      const value = m.slice(idx + 1);
      if (!validateKey(key) || !validateValue(value)) {
        continue;
      }
      const futureLength = currentLength + m.length + (vendorEntries.size > 0 ? 1 : 0);
      if (futureLength > MAX_TRACE_STATE_LEN) {
        continue;
      }
      vendorEntries.set(key, value);
      currentLength = futureLength;
      if (vendorEntries.size >= MAX_TRACE_STATE_ITEMS) {
        break;
      }
    }
    this._length = currentLength;
    this._internalState = new Map(Array.from(vendorEntries.entries()).reverse());
    return this._internalState;
  }
  _fromState(state, length) {
    const traceState = Object.create(_TraceState.prototype);
    traceState._internalState = state;
    traceState._length = length;
    return traceState;
  }
};

// ../node-migration-final-skills/vibelens/scripts/bo_observer/adapters/javascript/node_modules/@opentelemetry/core/build/esm/trace/W3CTraceContextPropagator.js
var TRACE_PARENT_HEADER = "traceparent";
var TRACE_STATE_HEADER = "tracestate";
var VERSION5 = "00";
var VERSION_PART = "(?!ff)[\\da-f]{2}";
var TRACE_ID_PART = "(?![0]{32})[\\da-f]{32}";
var PARENT_ID_PART = "(?![0]{16})[\\da-f]{16}";
var FLAGS_PART = "[\\da-f]{2}";
var TRACE_PARENT_REGEX = new RegExp(`^\\s?(${VERSION_PART})-(${TRACE_ID_PART})-(${PARENT_ID_PART})-(${FLAGS_PART})(-.*)?\\s?$`);
function parseTraceParent(traceParent) {
  const match = TRACE_PARENT_REGEX.exec(traceParent);
  if (!match)
    return null;
  if (match[1] === "00" && match[5])
    return null;
  return {
    traceId: match[2],
    spanId: match[3],
    traceFlags: parseInt(match[4], 16)
  };
}
var W3CTraceContextPropagator = class {
  inject(context3, carrier, setter) {
    const spanContext = trace2.getSpanContext(context3);
    if (!spanContext || isTracingSuppressed2(context3) || !isSpanContextValid2(spanContext))
      return;
    const traceParent = `${VERSION5}-${spanContext.traceId}-${spanContext.spanId}-0${Number(spanContext.traceFlags || TraceFlags2.NONE).toString(16)}`;
    setter.set(carrier, TRACE_PARENT_HEADER, traceParent);
    if (spanContext.traceState) {
      setter.set(carrier, TRACE_STATE_HEADER, spanContext.traceState.serialize());
    }
  }
  extract(context3, carrier, getter) {
    const traceParentHeader = getter.get(carrier, TRACE_PARENT_HEADER);
    if (!traceParentHeader)
      return context3;
    const traceParent = Array.isArray(traceParentHeader) ? traceParentHeader[0] : traceParentHeader;
    if (typeof traceParent !== "string")
      return context3;
    const spanContext = parseTraceParent(traceParent);
    if (!spanContext)
      return context3;
    spanContext.isRemote = true;
    const traceStateHeader = getter.get(carrier, TRACE_STATE_HEADER);
    if (traceStateHeader) {
      const state = Array.isArray(traceStateHeader) ? traceStateHeader.join(",") : traceStateHeader;
      spanContext.traceState = new TraceState(typeof state === "string" ? state : void 0);
    }
    return trace2.setSpanContext(context3, spanContext);
  }
  fields() {
    return [TRACE_PARENT_HEADER, TRACE_STATE_HEADER];
  }
};

// ../node-migration-final-skills/vibelens/scripts/bo_observer/adapters/javascript/bo_otel.mjs
var activationKey = /* @__PURE__ */ Symbol.for("vibelens.otel.activation");
var linksKey = /* @__PURE__ */ Symbol.for("vibelens.otel.links");
var carrierKey = "vibelens-context";
function bo_fields(value, allowed) {
  return value && typeof value === "object" && !Array.isArray(value) && Object.keys(value).every((key) => allowed.includes(key));
}
function bo_context_provenance(value) {
  if (!bo_fields(value, ["workflow_id", "objects"])) throw Error("Invalid internal provenance");
  const valid = (item) => typeof item === "string" && item.trim().length > 0 && item.length <= 256;
  if (Object.hasOwn(value, "workflow_id") && !valid(value.workflow_id))
    throw Error("Invalid internal workflow identity");
  const objects = Object.hasOwn(value, "objects") ? value.objects : [];
  if (!Array.isArray(objects) || objects.length > 64) throw Error("Invalid internal objects");
  const seen = /* @__PURE__ */ new Set();
  for (const item of objects) {
    if (!bo_fields(item, ["id", "type", "role", "version"]) || ![item.id, item.type, item.role].every(valid) || Object.hasOwn(item, "version") && !valid(item.version))
      throw Error("Invalid internal object reference");
    const key = JSON.stringify([item.type, item.id, item.version ?? null, item.role]);
    if (seen.has(key)) throw Error("Duplicate internal object reference");
    seen.add(key);
  }
}
function bo_span_metadata(span, parent = span.parentSpanContext, links = span.links || []) {
  const sc = span.spanContext();
  if (!sc?.traceId || /^0+$/.test(sc.traceId)) return null;
  return {
    trace_id: sc.traceId,
    span_id: sc.spanId,
    trace_flags: sc.traceFlags,
    parent_span_id: parent?.spanId || null,
    tracestate: sc.traceState?.serialize() || "",
    links: links.map((link) => ({
      trace_id: link.context.traceId,
      span_id: link.context.spanId,
      relation: link.attributes?.["vibelens.relation"] || "trigger",
      ...link.attributes?.["vibelens.source_build_id"] ? { source_build_id: link.attributes["vibelens.source_build_id"] } : {}
    }))
  };
}
var BOOpenTelemetry = class {
  constructor(tracer, { limit = 1e4 } = {}) {
    this.tracer = tracer;
    this.limit = limit;
    this.probe = null;
    this.spans = /* @__PURE__ */ new Map();
    this.automatic = /* @__PURE__ */ new Map();
    this.processors = [];
    this.externalBuildContexts = 0;
    this.propagator = new W3CTraceContextPropagator();
  }
  bind(probe) {
    if (this.probe) throw Error("Tracing backend already bound to a producer");
    this.probe = probe;
  }
  /** Annotate an actual escaping exception; do not add deprecated span exception events. */
  exception(callId, value) {
    const span = this.spans.get(callId)?.span;
    span?.setAttribute("error.type", value.type);
    span?.setStatus({ code: SpanStatusCode2.ERROR });
  }
  health() {
    return {
      backend: "opentelemetry",
      open_spans: this.spans.size,
      automatic_open: this.processors.reduce((sum, p) => sum + p.open.size, 0),
      automatic_errors: this.processors.reduce((sum, p) => sum + p.errors, 0),
      ignored: this.processors.reduce((sum, p) => sum + p.ignored, 0),
      external_build_contexts: this.externalBuildContexts
    };
  }
  /** Suppress observer HTTP/export work through the upstream context convention. */
  internal(operation) {
    return context2.with(suppressTracing2(context2.active()), operation);
  }
  current() {
    const sc = trace2.getSpan(context2.active())?.spanContext();
    return this.automatic.get(`${sc?.traceId}:${sc?.spanId}`) || context2.active().getValue(activationKey);
  }
  /** SDK async context follows real callbacks and promises, including detached tasks. */
  run(activation, operation) {
    let ctx = context2.active().setValue(activationKey, activation);
    const record = this.spans.get(activation.callId);
    if (record) ctx = trace2.setSpan(ctx, record.span).deleteValue(linksKey);
    return context2.with(ctx, operation);
  }
  observe(node, phase, callId, boundary) {
    let record = this.spans.get(callId);
    if (boundary === "start" && !record && callId) {
      if (this.spans.size >= this.limit) throw Error("Open telemetry span limit reached");
      const parent = trace2.getSpan(context2.active())?.spanContext();
      const links = context2.active().getValue(linksKey) || [];
      const span = this.tracer.startSpan(node, { attributes: { "vibelens.node_id": node }, links });
      record = { span, parent, links };
      this.spans.set(callId, record);
    }
    if (record) {
      const metadata = bo_span_metadata(record.span, record.parent, record.links);
      if (!metadata) throw Error("Selected tracing backend lacks a configured SDK SpanContext");
      return metadata;
    }
    const current = trace2.getSpan(context2.active());
    return current ? bo_span_metadata(current) : null;
  }
  complete(callId, phase, boundary) {
    if (boundary !== "end") return;
    const record = this.spans.get(callId);
    this.spans.delete(callId);
    record?.span.end();
  }
  /** W3C propagation plus explicit project metadata for internal jobs. Actor is omitted. */
  inject() {
    const carrier = {};
    this.propagator.inject(context2.active(), carrier, {
      set: (c, k, v) => {
        c[k] = v;
      }
    });
    const activation = this.current();
    if (activation?.probe === this.probe) {
      const identity = Object.fromEntries(
        ["entity", "attempt", "scope"].filter((key) => Object.hasOwn(activation.identity, key)).map((key) => [key, activation.identity[key]])
      );
      if (activation.identity.provenance) {
        identity.provenance = structuredClone(activation.identity.provenance);
        delete identity.provenance.actor;
      }
      carrier[carrierKey] = JSON.stringify({
        project_id: this.probe.bo_project.project_id,
        build_id: this.probe.bo_build,
        model_revision: this.probe.bo_project.model.revision,
        call_id: activation.callId,
        entry_id: activation.entryId,
        identity
      });
    }
    return carrier;
  }
  /** Extract public trace context; opt into application-owned queue metadata explicitly. */
  receiveContext(carrier, { trusted = false, link = false, strict = false } = {}) {
    let ctx = this.propagator.extract(ROOT_CONTEXT2, carrier, {
      get: (c, k) => c[k],
      keys: (c) => Object.keys(c)
    });
    const sc = trace2.getSpan(ctx)?.spanContext();
    let activation, sourceBuild;
    if (trusted && Object.hasOwn(carrier, carrierKey)) {
      if (!sc?.traceId || /^0+$/.test(sc.traceId)) throw Error("Invalid W3C trace context");
      if (typeof carrier[carrierKey] !== "string" || carrier[carrierKey].length > 16384)
        throw Error("Invalid internal trace carrier");
      const value = JSON.parse(carrier[carrierKey]);
      if (!value || Array.isArray(value) || Object.keys(value).sort().join() !== ["project_id", "build_id", "model_revision", "call_id", "entry_id", "identity"].sort().join() || [value.call_id, value.entry_id].some(
        (id) => typeof id !== "string" || !id || id.length > 512
      ))
        throw Error("Invalid internal invocation reference");
      if (value.project_id !== this.probe.bo_project.project_id)
        throw Error("Internal trace carrier belongs to another project");
      if ([value.build_id, value.model_revision].some((item) => typeof item !== "string" || !item))
        throw Error("Invalid internal build identity");
      const changedBuild = value.build_id !== this.probe.bo_build || value.model_revision !== this.probe.bo_project.model.revision;
      if (!value.identity || typeof value.identity !== "object" || Array.isArray(value.identity) || Object.keys(value.identity).some(
        (key) => !["entity", "attempt", "scope", "provenance"].includes(key)
      ) || Object.hasOwn(value.identity.provenance || {}, "actor"))
        throw Error("Invalid internal observation identity");
      if (["entity", "attempt"].some(
        (key) => Object.hasOwn(value.identity, key) && (typeof value.identity[key] !== "string" || !value.identity[key] || value.identity[key].length > 256)
      ) || Object.hasOwn(value.identity, "scope") && !["application", "entity", "attempt"].includes(value.identity.scope))
        throw Error("Invalid internal business instance reference");
      if (Object.hasOwn(value.identity, "provenance"))
        bo_context_provenance(value.identity.provenance);
      activation = {
        probe: this.probe,
        identity: value.identity,
        callId: value.call_id,
        entryId: value.entry_id,
        active: false
      };
      if (changedBuild) {
        if (strict || value.build_id.length > 256)
          throw Error("Internal trace carrier belongs to another graph build");
        sourceBuild = value.build_id;
        this.externalBuildContexts++;
        activation = void 0;
        link = true;
      }
    }
    if (link) {
      ctx = ROOT_CONTEXT2.setValue(
        linksKey,
        sc ? [
          {
            context: sc,
            attributes: {
              "vibelens.relation": "trigger",
              ...sourceBuild ? { "vibelens.source_build_id": sourceBuild } : {}
            }
          }
        ] : []
      );
      if (activation) activation = { ...activation, callId: null, entryId: null };
    }
    return ctx.setValue(activationKey, activation);
  }
  receive(carrier, operation, options = {}) {
    let ctx;
    try {
      ctx = this.receiveContext(carrier, options);
    } catch (error) {
      this.probe.bo_errors++;
      this.probe.bo_last_error = { stage: "trace_context", type: "Error" };
      if (options.strict) throw error;
      ctx = ROOT_CONTEXT2;
    }
    return context2.with(ctx, operation);
  }
  /** Fan-in links several causes; no actor or business instance is guessed from them. */
  linked(carriers, operation) {
    if (!Array.isArray(carriers) || !carriers.length || carriers.length > 32)
      throw Error("Linked execution requires 1 to 32 carriers");
    const links = carriers.map((carrier) => {
      const ctx = this.propagator.extract(ROOT_CONTEXT2, carrier, {
        get: (c, k) => c[k],
        keys: Object.keys
      });
      const sc = trace2.getSpan(ctx)?.spanContext();
      if (!sc?.traceId || /^0+$/.test(sc.traceId)) throw Error("Invalid linked W3C context");
      return { context: sc, attributes: { "vibelens.relation": "trigger" } };
    });
    return context2.with(ROOT_CONTEXT2.setValue(linksKey, links), operation);
  }
};

// integrations/bo_client.mjs
var bo_probe = null;
var bo_capture = null;
try {
  const response = await fetch("/api/bo/config", { credentials: "same-origin" });
  if (response.ok) {
    const settings = await response.json();
    bo_probe = new BOProbe(settings);
    const provider = new TracerProvider();
    bo_probe.bo_bind_tracing(new BOOpenTelemetry(provider.getTracer("team-files-browser")));
    bo_capture = await new BOCaptureClient(bo_probe).start();
  }
} catch (error) {
  console.warn("VibeLens browser initialization unavailable:", error.message);
}
function bo_start_ui(action, eventType, target) {
  if (!bo_probe) return null;
  const node = action === "row-action" ? "ui_row_action" : action === "navigation" ? "ui_navigation" : "ui_callback";
  const span = bo_probe.startSpan(node, () => ({ inputs: { action, event_type: eventType, target } }), { scope: "application" });
  return (completed) => span.finish(() => ({ outputs: { completed } }));
}
export {
  bo_start_ui
};
