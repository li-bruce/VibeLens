'use strict';
const bo_ui = await import('/api/bo/client.mjs').catch(/** Allow the workspace to start when the optional observer client is unavailable. */ error => { console.warn('VibeLens browser module unavailable:', error.message); return {}; });
const state = { user: null, view: 'files', members: [], files: [], editId: null, shareFile: null };
const $ = /** Find one application element by its stable DOM ID. */ id => document.getElementById(id);
const errors = {
  INVALID_CREDENTIALS: '用户名或密码不正确。', LOGIN_REQUIRED: '登录已失效，请重新登录。',
  ACCESS_DENIED: '你当前没有执行这项操作的权限。', FILE_NOT_FOUND: '文件不存在。',
  INVALID_RECIPIENT: '请选择其他团队成员。', UPLOAD_TOO_LARGE: '文件超过 50 MB，请选择较小的文件。',
  FILE_BYTES_REQUIRED: '请选择需要上传的文件。', INVALID_FILENAME: '文件名不能为空，且不能超过 180 个字符。',
  INVALID_ANNOUNCEMENT: '公告需要标题和内容，请检查长度。', TASK_NOT_FOUND: '下载任务不存在。',
  ORIGIN_REJECTED: '请求来源不匹配，请从当前应用页面操作。'
};

/** Call the real authenticated API and preserve its actual rejection. */
async function api(url, options = {}) {
  const response = await fetch(url, { credentials: 'same-origin', ...options });
  if (!response.ok) {
    const body = await response.json().catch(/** Retain a public fallback code when an error response is not JSON. */ () => ({ error: 'INTERNAL_ERROR' }));
    if (response.status === 401) showLogin();
    throw new Error(errors[body.error] || '操作未完成，请刷新后重试。');
  }
  return response.status === 204 ? null : response.json();
}
/** Build JSON request options without using inline scripts or user-authored HTML. */
function jsonRequest(method, value) { return { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(value) }; }
/** Create a safe text node element. */
function element(tag, text = '', className = '') {
  const node = document.createElement(tag); node.textContent = text; if (className) node.className = className; return node;
}
/** Display a meaningful result without hiding the current page. */
function notice(message, failure = false) { $('notice').textContent = message; $('notice').className = 'notice' + (failure ? ' failure' : ''); $('notice').hidden = false; }
/** Restore the login screen after real logout or a rejected session. */
function showLogin() { state.user = null; $('workspace').hidden = true; $('login-screen').hidden = false; }
/** Format file sizes for compact list rows. */
function size(value) { return value < 1024 ? value + ' B' : value < 1048576 ? (value / 1024).toFixed(1) + ' KB' : (value / 1048576).toFixed(1) + ' MB'; }
/** Format native UTC timestamps in the browser's local timezone. */
function time(value) { return new Date(value).toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }); }
/** Run one action and retain visible error feedback. */
async function perform(operation, button = null) {
  if (button) button.disabled = true;
  try { await operation(); } catch (error) { notice(error.message, true); }
  finally { if (button) button.disabled = false; }
}
/** Build a native button whose action remains explicitly associated with its row. */
function action(text, callback, className = 'secondary') {
  const button = element('button', text, className); button.type = 'button';
  /** Execute the actual row-button callback. @param {Event} event Native click event. */
  function rowActionHandler(event) { return dispatchUi('row-action', event, /** Run the selected row action with visible error feedback. */ () => perform(/** Invoke this row action with the button that initiated it. */ () => callback(button), button)); }
  button.addEventListener('click', rowActionHandler); return button;
}
/** Run the real UI callback while isolating optional observer failures. */
async function dispatchUi(id, event, callback) {
  let finish; try { finish = bo_ui.bo_start_ui?.(id, event.type, event.target.id || ''); } catch { /* Observation only. */ }
  try { const result = await callback(event); try { finish?.(true); } catch { /* Observation only. */ } return result; }
  catch (error) { try { finish?.(false); } catch { /* Observation only. */ } throw error; }
}
/** Register a native element callback with its public element identity. */
function bind(id, type, callback) {
  /** Execute the actual bound form/control callback. @param {Event} event Native DOM event. */
  function uiCallback(event) { return dispatchUi(id, event, callback); }
  $(id).addEventListener(type, uiCallback);
}
/** Open the actual selected view. @param {Event} event Native navigation click. */
function navigationHandler(event) {
  const view = event.currentTarget.dataset.view;
  return dispatchUi('navigation', event, /** Apply the clicked navigation choice with visible error feedback. */ () => perform(/** Load the view selected by the native navigation button. */ () => selectView(view)));
}
/** Enter the workspace only with an authenticated API response. */
async function enter(user) {
  state.user = user;
  $('login-screen').hidden = true; $('workspace').hidden = false;
  $('display-name').textContent = user.display_name; $('avatar').textContent = user.display_name.slice(0, 1);
  $('role-label').textContent = user.editor ? '团队成员 · 公告编辑员' : '团队成员';
  $('announcement-form').hidden = !user.editor;
  state.members = (await api('/api/members')).members;
  await selectView(state.view);
}
/** Keep independent files, download tasks and announcements in separate views. */
async function selectView(view) {
  state.view = view;
  for (const name of ['files', 'tasks', 'board']) $(name + '-view').hidden = name !== view;
  document.querySelectorAll('[data-view]').forEach(/** Highlight only the navigation button for the selected view. */ button => button.classList.toggle('active', button.dataset.view === view));
  $('breadcrumb').textContent = '团队空间 / ' + ({ files: '文件', tasks: '我的下载', board: '公告板' })[view];
  if (view === 'files') await refreshFiles(); else if (view === 'tasks') await refreshTasks(); else await refreshBoard();
}
/** Render only server-authorized file rows and owner-only grant controls. */
async function refreshFiles() {
  const data = await api('/api/files'); state.files = data.files;
  $('file-count').textContent = data.count + ' 个文件'; $('file-list').replaceChildren();
  if (!data.files.length) {
    const empty = element('div', '', 'empty'); empty.append(element('strong', '文件柜还没有可访问的文件'), element('p', '上传一个文件，或请同事把文件分享给你。')); $('file-list').append(empty); return;
  }
  for (const file of data.files) {
    const row = element('article', '', 'file-row'), top = element('div', '', 'file-top'), info = element('div', '', 'file-info');
    top.append(element('span', file.name.split('.').at(-1).slice(0, 5).toUpperCase() || 'FILE', 'file-icon'));
    info.append(element('strong', file.name), element('div', size(file.size) + ' · ' + file.owner_name + ' 上传 · ' + time(file.created_at), 'file-meta'));
    top.append(info, element('span', file.mine ? '我上传的' : '同事共享', 'badge' + (file.mine ? '' : ' teal'))); row.append(top);
    const controls = element('div', '', 'file-actions');
    controls.append(action('准备下载', /** Submit a preparation task for this visible file. */ async () => { await api('/api/tasks', jsonRequest('POST', { file_id: file.id })); notice('下载任务已提交。可在“我的下载”查看进度。'); }));
    if (file.mine) controls.append(action('分享给同事', /** Open the named-recipient dialog for this uploader-owned file. */ async () => openShare(file), 'quiet'));
    row.append(controls);
    const grants = element('div', '', 'grant-list');
    for (const grant of file.grants.filter(/** Render access chips only for currently active recipient grants. */ value => value.active)) {
      const chip = element('span', grant.display_name + ' 可访问', 'grant-chip');
      chip.append(action('撤销', /** Revoke this recipient grant through the API and refresh visible files. */ async () => { await api('/api/files/' + file.id + '/shares/' + grant.recipient_id, { method: 'DELETE' }); notice('已撤销共享；对方已获准的下载任务仍可领取。'); await refreshFiles(); }, 'quiet')); grants.append(chip);
    }
    if (grants.childElementCount) row.append(grants); $('file-list').append(row);
  }
}
/** Show the uploader's explicit named-recipient picker. */
function openShare(file) {
  state.shareFile = file; $('share-filename').textContent = file.name; $('share-recipient').replaceChildren();
  for (const member of state.members.filter(/** Offer colleagues other than the current uploader as recipients. */ value => value.id !== state.user.id)) {
    const option = element('option', member.display_name + ' · ' + member.username); option.value = member.id; $('share-recipient').append(option);
  }
  $('share-dialog').showModal();
}
/** Render actual queued/preparing/ready states without consuming ready tasks. */
async function refreshTasks() {
  const data = await api('/api/tasks'); $('task-list').replaceChildren();
  if (!data.tasks.length) { const empty = element('div', '', 'paper empty'); empty.append(element('strong', '还没有下载任务'), element('p', '在团队文件里选择“准备下载”，完成后到这里领取。')); $('task-list').append(empty); return; }
  for (const task of data.tasks) {
    const card = element('article', '', 'paper task-card'), head = element('div', '', 'task-heading'), title = element('div');
    title.append(element('strong', task.name), element('p', size(task.size) + ' · 提交于 ' + time(task.created_at), 'file-meta')); head.append(title);
    if (task.status === 'ready') {
      const link = element('a', '领取文件', 'primary'); link.href = '/api/tasks/' + task.id + '/download'; link.download = task.name; head.append(link);
    } else head.append(element('span', task.last_error ? '准备遇到错误' : task.status === 'queued' ? '正在排队' : '正在准备', 'badge'));
    card.append(head); const rail = element('div', '', 'stage-rail'), stages = ['queued', 'preparing', 'ready'];
    for (const [index, stage] of stages.entries()) rail.append(element('span', ['排队中', '准备中', '可重复领取'][index], 'stage' + (stages.indexOf(task.status) >= index ? ' done' : '')));
    card.append(rail);
    const meta = element('div', '任务 ' + task.id.slice(0, 8), 'task-meta'); meta.append(element('span', '提交时已获准 · 授权随这一单保留')); card.append(meta);
    if (task.last_error) card.append(element('p', '准备未完成：' + task.last_error, 'error')); $('task-list').append(card);
  }
}
/** Reset only the announcement composition form. */
function resetEditor() { state.editId = null; $('announcement-form').reset(); $('editor-mode').textContent = '发布新公告'; $('publish-button').textContent = '发布公告'; $('cancel-edit').hidden = true; }
/** Render the independent board and restrict edit controls to editor-authored content. */
async function refreshBoard() {
  const data = await api('/api/announcements'); $('announcement-list').replaceChildren();
  if (!data.announcements.length) { const empty = element('div', '', 'paper empty'); empty.append(element('strong', '公告板暂时没有消息'), element('p', state.user.editor ? '在右侧发布第一条团队公告。' : '公告编辑员发布后，登录同事即可在这里阅读。')); $('announcement-list').append(empty); }
  for (const entry of data.announcements) {
    const article = element('article', '', 'paper announcement'); article.append(element('span', '团队公告', 'badge'), element('h2', entry.title), element('div', entry.body, 'body-copy'));
    const footer = element('footer', time(entry.updated_at) + ' · ' + entry.author_name);
    if (state.user.editor && entry.author_id === state.user.id) {
      const buttons = element('div');
      buttons.append(action('修改', /** Load this editor-authored announcement into the edit form. */ async () => { state.editId = entry.id; $('announcement-title').value = entry.title; $('announcement-body').value = entry.body; $('editor-mode').textContent = '修改自己的公告'; $('publish-button').textContent = '保存修改'; $('cancel-edit').hidden = false; $('announcement-title').focus(); }, 'quiet'));
      buttons.append(action('删除', /** Delete this announcement through the API and refresh the board. */ async () => { await api('/api/announcements/' + entry.id, { method: 'DELETE' }); if (state.editId === entry.id) resetEditor(); notice('公告已删除。'); await refreshBoard(); }, 'quiet')); footer.append(buttons);
    }
    article.append(footer); $('announcement-list').append(article);
  }
}
/** Restore an existing real session on page load. */
async function boot() {
  try { const data = await api('/api/auth/session'); if (data.user) await enter(data.user); else showLogin(); }
  catch (error) { showLogin(); $('login-error').textContent = error.message; }
}
bind('login-form', 'submit', /** Submit the real login form and enter only after authenticated success. */ async event => {
  event.preventDefault(); const button = event.submitter; button.disabled = true; $('login-error').textContent = '';
  try { const data = await api('/api/auth/login', jsonRequest('POST', { username: $('username').value.trim(), password: $('password').value })); $('password').value = ''; await enter(data.user); }
  catch (error) { $('login-error').textContent = error.message; } finally { button.disabled = false; }
});
bind('logout', 'click', /** Run logout with visible error feedback. */ () => perform(/** End the native session and restore the login screen. */ async () => { await api('/api/auth/logout', { method: 'POST' }); $('notice').hidden = true; showLogin(); }, $('logout')));
document.querySelectorAll('[data-view]').forEach(/** Register each native navigation button with the shared click handler. */ button => button.addEventListener('click', navigationHandler));
bind('refresh-files', 'click', /** Refresh authorized file rows after the refresh click. */ () => perform(refreshFiles));
bind('refresh-tasks', 'click', /** Refresh this requester task list after the refresh click. */ () => perform(refreshTasks));
bind('refresh-board', 'click', /** Refresh the authenticated announcement board after the refresh click. */ () => perform(refreshBoard));
bind('upload-file', 'change', /** Display the actual chosen upload filename and byte size. */ () => { const file = $('upload-file').files[0]; $('chosen-file').textContent = file ? file.name + ' · ' + size(file.size) : '单个文件最多 50 MB'; });
bind('upload-form', 'submit', /** Submit the selected upload through the bounded native API. */ event => {
  event.preventDefault(); return perform(/** Upload the selected real file bytes and refresh authorized files. */ async () => {
    const file = $('upload-file').files[0]; if (!file) return;
    if (file.size > 50 * 1024 * 1024) throw new Error(errors.UPLOAD_TOO_LARGE);
    $('upload-status').textContent = '正在上传…';
    try { await api('/api/files?name=' + encodeURIComponent(file.name), { method: 'POST', headers: { 'Content-Type': 'application/octet-stream' }, body: file }); $('upload-form').reset(); $('chosen-file').textContent = '单个文件最多 50 MB'; notice('文件已上传。现在可以分享给指定同事。'); await refreshFiles(); }
    finally { $('upload-status').textContent = ''; }
  }, event.submitter);
});
bind('share-form', 'submit', /** Submit this named-recipient share form. */ event => { event.preventDefault(); return perform(/** Create the selected recipient grant and close the share dialog after success. */ async () => { await api('/api/files/' + state.shareFile.id + '/shares', jsonRequest('POST', { recipient_id: $('share-recipient').value })); $('share-dialog').close(); notice('已授予共享。'); await refreshFiles(); }, event.submitter); });
bind('close-share', 'click', /** Close the recipient picker without submitting a grant. */ () => $('share-dialog').close());
bind('announcement-form', 'submit', /** Submit this editor announcement form. */ event => {
  event.preventDefault(); return perform(/** Publish or save the editor own announcement through the native API. */ async () => {
    const editing = Boolean(state.editId); await api('/api/announcements' + (editing ? '/' + state.editId : ''), jsonRequest(editing ? 'PUT' : 'POST', { title: $('announcement-title').value, body: $('announcement-body').value }));
    resetEditor(); notice(editing ? '公告已修改。' : '公告已发布。'); await refreshBoard();
  }, event.submitter);
});
bind('cancel-edit', 'click', resetEditor);
setInterval(/** Refresh tasks only while a logged-in user is viewing the visible task page. */ () => { if (state.user && state.view === 'tasks' && !document.hidden) perform(refreshTasks); }, 1800);
boot();
