import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { createHash, randomUUID } from 'node:crypto';
import { mkdtemp, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { Store, TEST_PASSWORD } from '../src/store.mjs';
import { FileService } from '../src/service.mjs';
import { createApp } from '../src/http.mjs';
import { bo_create } from '../integrations/bo_observe.mjs';
import { nativeAuditor, readSessionPrincipal, readPersistedInstances } from './native_reader.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const skill = process.env.VIBELENS_SKILL || path.resolve(ROOT, '../node-migration-final-skills/vibelens');
const { bo_internal } = await import(pathToFileURL(path.join(skill, 'scripts/bo_observer/adapters/javascript/bo_data.mjs')).href);
const sha = value => createHash('sha256').update(value).digest('hex');

/** Hold actual request streams one JSON byte short; no application callback is replaced. */
function bodyBarrier(expected) {
  const streams = [], phase = { released: false };
  let resolve, reject;
  const ready = new Promise((yes, no) => { resolve = yes; reject = no; });
  const timer = setTimeout(() => reject(new Error('Two real incomplete request bodies did not reach the barrier')), 5000);
  const observe = (request, response) => {
    if (phase.released || request.method !== 'POST' || request.url !== '/api/tasks') return;
    const selected = expected.get(request.headers.cookie);
    if (!selected) return;
    const state = { request, response, actor: selected.actor, bytes: 0, chunks: [], arrived: false };
    streams.push(state);
    request.on('data', chunk => {
      state.bytes += chunk.length; state.chunks.push(Buffer.from(chunk));
      if (!state.arrived && state.bytes === selected.prefix.length) {
        state.arrived = true;
        if (streams.filter(item => item.arrived).length === 2) { clearTimeout(timer); resolve(); }
      }
    });
  };
  return { ready, streams, observe, release() { phase.released = true; }, close() { clearTimeout(timer); } };
}

/** Send real headers and a partial body on a separate TCP connection. */
function partialRequest(port, cookie, body) {
  const bytes = Buffer.from(JSON.stringify(body));
  const request = http.request({ host: '127.0.0.1', port, path: '/api/tasks', method: 'POST', agent: false,
    headers: { Cookie: cookie, 'Content-Type': 'application/json', 'Content-Length': bytes.length } });
  const response = new Promise((resolve, reject) => {
    request.once('error', reject);
    request.once('response', message => {
      const chunks = []; message.on('data', value => chunks.push(value)); message.once('error', reject);
      message.once('end', () => {
        try { resolve({ status: message.statusCode, body: JSON.parse(Buffer.concat(chunks).toString('utf8')) }); }
        catch (error) { reject(error); }
      });
    });
  });
  // Keep teardown failures handled while the original promise remains awaitable.
  response.catch(() => {});
  request.flushHeaders(); request.write(bytes.subarray(0, -1));
  return { request, response, prefix: bytes.subarray(0, -1), release() { request.end(bytes.subarray(-1)); } };
}

/** Exercise actual overlapping HTTP requests against the existing serial native admission/worker boundary. */
async function scenario(mode) {
  const data = await mkdtemp(path.join(ROOT, 'review/runtime/concurrency-' + mode + '-'));
  const settings = JSON.parse(await readFile(path.join(ROOT, 'review/native-test-settings.json'), 'utf8'));
  const project = JSON.parse(await readFile(path.join(ROOT, 'bo_stategraph/project.json'), 'utf8'));
  const store = new Store(path.join(data, 'db/application.sqlite')), service = new FileService(store, data);
  service.workerDelay = 60000; // The existing fixture control keeps the single worker queued until inspection.
  const events = [], snapshots = [], native = [];
  const observer = await bo_create(service, ROOT, { project, buildId: settings.build_id, policyHash: settings.policy_hash,
    enabled: mode !== 'off', capacity: 4096, sink: async (body, kind) => {
      if (mode === 'fault') throw new Error('Deliberate local observer sink outage');
      (kind === 'events' ? events : snapshots).push(body);
    } });
  const auditor = nativeAuditor(service, settings.build_id);
  let activeTransactions = 0, maximumTransactions = 0, activePreparations = 0, maximumPreparations = 0;
  const detach = service.subscribe(event => {
    if (event.phase === 'transaction_enter') { activeTransactions++; maximumTransactions = Math.max(maximumTransactions, activeTransactions); }
    if (event.phase === 'commit' || event.phase === 'rollback') activeTransactions--;
    if (event.name === 'prepare_download' && event.phase === 'enter') { activePreparations++; maximumPreparations = Math.max(maximumPreparations, activePreparations); }
    if (event.name === 'prepare_download' && ['return', 'error'].includes(event.phase)) activePreparations--;
    if (event.name === 'request_download' || ['transaction_enter', 'commit', 'rollback'].includes(event.phase)) {
      native.push({ name: event.name, phase: event.phase, invocation_id: event.invocationId,
        actor_id: event.inputs?.actor_id, file_id: event.inputs?.file_id,
        task_id: event.task_id || event.outputs?.task_id, transaction_id: event.transaction_id || event.outputs?.transaction_id,
        committed: event.committed ?? event.outputs?.committed });
    }
  });
  const server = createApp(service, path.join(ROOT, 'public'), observer).listen(0, '127.0.0.1');
  await new Promise(resolve => server.once('listening', resolve));
  const port = server.address().port, url = 'http://127.0.0.1:' + port, cookies = {}, controls = [];
  const readRows = (sql, ...args) => bo_internal(() => store.all(sql, ...args));
  const call = async (actor, route, method = 'GET', value, extra = {}) => {
    const headers = { ...(cookies[actor] ? { Cookie: cookies[actor] } : {}), ...extra };
    if (value && !Buffer.isBuffer(value)) headers['Content-Type'] = 'application/json';
    return fetch(url + route, { method, headers, body: value === undefined ? undefined : Buffer.isBuffer(value) ? value : JSON.stringify(value) });
  };
  let barrier, barrierWitness;
  try {
    for (const actor of ['alice', 'bob', 'editor']) {
      const response = await call(actor, '/api/auth/login', 'POST', { username: actor, password: TEST_PASSWORD });
      assert.equal(response.status, 200); await response.arrayBuffer();
      cookies[actor] = response.headers.get('set-cookie').split(';')[0];
      assert.equal(readSessionPrincipal(store, cookies[actor]).user_id, actor);
    }
    const cases = [];
    for (const actor of ['bob', 'editor']) {
      const bytes = Buffer.from('Distinct real prepared bytes for ' + actor + '.\n');
      const response = await call('alice', '/api/files?name=' + actor + '.txt', 'POST', bytes, { 'Content-Type': 'application/octet-stream' });
      assert.equal(response.status, 201); const file = await response.json();
      const grant = await call('alice', '/api/files/' + file.id + '/shares', 'POST', { recipient_id: actor });
      assert.equal(grant.status, 200); await grant.arrayBuffer();
      cases.push({ actor, file_id: file.id, bytes, expected_sha256: sha(bytes) });
    }
    await observer.probe.flush(10000);
    const eventStart = events.length, nativeStart = native.length, expected = new Map();
    for (const item of cases) expected.set(cookies[item.actor], { actor: item.actor, prefix: Buffer.from(JSON.stringify({ file_id: item.file_id })).subarray(0, -1) });
    barrier = bodyBarrier(expected); server.on('request', barrier.observe);
    for (const item of cases) controls.push(partialRequest(port, cookies[item.actor], { file_id: item.file_id }));
    await barrier.ready;
    assert.equal(barrier.streams.length, 2);
    assert.equal(new Set(barrier.streams.map(item => item.actor)).size, 2);
    assert.equal(new Set(barrier.streams.map(item => item.request.socket.remotePort)).size, 2);
    for (const item of barrier.streams) {
      assert.equal(item.request.complete, false); assert.equal(item.response.headersSent, false);
      assert.equal(item.response.writableEnded, false);
      assert.deepEqual(Buffer.concat(item.chunks), expected.get(cookies[item.actor]).prefix);
    }
    assert.equal(native.slice(nativeStart).filter(item => item.phase === 'enter').length, 0);
    assert.equal(readRows('SELECT id FROM tasks').length, 0);
    await observer.probe.flush(10000);
    const httpRoots = events.slice(eventStart).filter(event => event.node === 'api_request' && event.phase === 'enter');
    if (mode === 'on') assert.equal(httpRoots.length, 2);
    barrierWitness = { basis: 'Two actual distinct TCP request streams have supplied all but their final JSON byte; both remain unfinished before the release.',
      incomplete_requests: barrier.streams.map(item => ({ actor: item.actor, received_bytes: item.bytes,
        declared_bytes: Number(item.request.headers['content-length']), prefix_sha256: sha(Buffer.concat(item.chunks)),
        request_complete: item.request.complete, response_headers_sent: item.response.headersSent,
        response_ended: item.response.writableEnded, remote_port: item.request.socket.remotePort })),
      native_admissions_before_release: 0, stored_tasks_before_release: 0,
      actual_http_entry_ids: httpRoots.map(event => event.id), released_only_after_both_arrived: true };
    barrier.release(); for (const control of controls) control.release();
    const responses = await Promise.all(controls.map(control => control.response));
    assert.equal(new Set(responses.map(response => response.body.task_id)).size, 2);
    for (let index = 0; index < cases.length; index++) {
      assert.equal(responses[index].status, 202); assert.equal(responses[index].body.committed, true);
      assert.equal(responses[index].body.authorized_at_submission, true);
      cases[index].task_id = responses[index].body.task_id;
    }
    const admitted = readRows('SELECT * FROM tasks'); assert.equal(admitted.length, 2);
    for (const item of cases) {
      const row = admitted.find(row => row.id === item.task_id);
      assert.equal(row.requester_id, item.actor); assert.equal(row.file_id, item.file_id);
      assert.equal(row.authorized_at_submission, 1); assert.equal(row.status, 'queued');
      const listed = await call(item.actor, '/api/tasks'); assert.equal(listed.status, 200);
      assert.deepEqual((await listed.json()).tasks.map(task => task.id), [item.task_id]);
    }
    const revoked = await call('alice', '/api/files/' + cases[0].file_id + '/shares/bob', 'DELETE');
    assert.equal(revoked.status, 200); await revoked.arrayBuffer();
    const denied = await call('bob', '/api/tasks', 'POST', { file_id: cases[0].file_id });
    assert.equal(denied.status, 403); await denied.arrayBuffer();
    clearTimeout(service.workerTimer); service.workerBusy = false; await service.drainWorker();
    assert.equal(maximumTransactions, 1); assert.equal(activeTransactions, 0);
    assert.equal(maximumPreparations, 1); assert.equal(activePreparations, 0);
    const ready = readRows('SELECT * FROM tasks'); assert.equal(ready.length, 2);
    assert.equal(new Set(ready.map(row => row.prepared_path)).size, 2);
    for (const item of cases) {
      const row = ready.find(row => row.id === item.task_id); assert.equal(row.status, 'ready');
      assert.deepEqual(await readFile(row.prepared_path), item.bytes); assert.equal(row.sha256, item.expected_sha256);
      for (let repeat = 0; repeat < 2; repeat++) {
        const response = await call(item.actor, '/api/tasks/' + item.task_id + '/download');
        assert.equal(response.status, 200); assert.equal(sha(Buffer.from(await response.arrayBuffer())), item.expected_sha256);
      }
      const other = cases.find(value => value.actor !== item.actor).actor;
      const cross = await call(other, '/api/tasks/' + item.task_id + '/download');
      assert.equal(cross.status, 403); await cross.arrayBuffer();
    }
    await observer.probe.flush(10000);
    const ownership = [];
    for (const item of cases) {
      const actual = native.filter(event => event.name === 'request_download' && event.phase === 'return' && event.task_id === item.task_id);
      assert.equal(actual.length, 1);
      const entered = native.find(event => event.phase === 'enter' && event.invocation_id === actual[0].invocation_id);
      assert.equal(entered.actor_id, item.actor); assert.equal(entered.file_id, item.file_id);
      if (mode === 'on') {
        const entry = events.find(event => event.node === 'request_download' && event.phase === 'enter' && event.call_id === actual[0].invocation_id);
        const terminal = events.find(event => event.node === 'request_download' && event.phase === 'return' && event.call_id === entry.call_id);
        assert.equal(terminal.outputs.task_id, item.task_id);
        const sdk = auditor.sdk.request_download.enter.find(value => value.invocation_id === entry.call_id);
        assert.equal(entry.trace.trace_id, sdk.trace_id); assert.equal(entry.trace.span_id, sdk.span_id);
        const parent = httpRoots.find(root => root.trace.trace_id === entry.trace.trace_id && root.trace.span_id === entry.trace.parent_span_id);
        assert.ok(parent, 'Actual native SDK invocation lost its original overlapping HTTP parent');
        const completed = events.find(event => event.node === 'api_request' && event.phase === 'return' && event.call_id === parent.call_id);
        assert.equal(completed.outputs.status, 202); assert.equal(completed.outputs.completed, true);
        const transaction = events.find(event => event.node === 'task_commit' && event.phase === 'enter' && event.parent_call_id === entry.call_id);
        assert.equal(transaction.inputs.task_id, item.task_id);
        const committed = events.find(event => event.node === 'task_commit' && event.phase === 'return' && event.call_id === transaction.call_id);
        assert.equal(committed.outputs.transaction_id, transaction.inputs.transaction_id); assert.equal(committed.outputs.committed, true);
        ownership.push({ actor: item.actor, task_id: item.task_id, native_call_id: entry.call_id, http_call_id: parent.call_id,
          sdk_trace_id: sdk.trace_id, sdk_span_id: sdk.span_id, transaction_id: transaction.inputs.transaction_id });
      }
    }
    if (mode === 'on') assert.equal(new Set(ownership.map(value => value.http_call_id)).size, 2);
    const selection = { grant: cases.map(item => item.file_id + '/' + item.actor), download_task: cases.map(item => item.task_id), announcement: [], session: [] };
    const persisted = await readPersistedInstances(path.join(data, 'db/application.sqlite'), settings.build_id, selection);
    assert.equal(persisted.instances.filter(row => row.state_model_id === 'download_task' && row.state === 'ready').length, 2);
    for (const item of cases) {
      const row = persisted.instances.find(row => row.state_model_id === 'download_task' && row.id === item.task_id);
      assert.equal(row.context.requester_id, item.actor); assert.equal(row.context.file_id, item.file_id);
      assert.equal(row.context.authorized_at_submission, true);
    }
    assert.deepEqual(auditor.errors, []);
    const health = observer.health(); assert.equal(health.pending, 0); assert.equal(health.dropped, 0);
    assert.equal(health.tracing.open_spans, 0);
    if (mode === 'on') assert.equal(health.errors, 0);
    if (mode === 'off') assert.equal(events.length, 0);
    if (mode === 'fault') assert.ok(health.errors > 0);
    const report = { case: 'concurrent_request_isolation', mode, record_id: randomUUID(), build_id: settings.build_id,
      barrier: barrierWitness, maximum_native_transactions: maximumTransactions, maximum_native_preparations: maximumPreparations,
      execution_boundary: 'Real HTTP requests overlap at the controlled body barrier. Native SQLite admission is synchronous and the existing single worker prepares sequentially. No parallel-worker capability is claimed.',
      tasks: cases.map(({ bytes, ...item }) => item), ownership, persisted_native: persisted, native,
      health, events, snapshots, native_sdk: auditor.sdk,
      outcomes: { distinct_owned_tasks: 2, ready_tasks: 2, stored_authorization: true, revoked_new_request_denied: true,
        original_requesters_repeat_collect: true, cross_task_collection_denied: true, distinct_prepared_paths_and_bytes: true } };
    await writeFile(path.join(data, 'result.json'), JSON.stringify(report, null, 2), { flag: 'wx' });
    return { mode, data, outcomes: report.outcomes, barrier: barrierWitness, maximumTransactions, maximumPreparations };
  } catch (error) {
    await writeFile(path.join(data, 'failure.json'), JSON.stringify({ error: error.stack, barrier: barrierWitness, native, events, snapshots, native_sdk: auditor.sdk }, null, 2), { flag: 'wx' });
    throw error;
  } finally {
    barrier?.close(); if (barrier) server.off('request', barrier.observe);
    for (const control of controls) control.request.destroy();
    server.closeAllConnections(); await new Promise(resolve => server.close(resolve));
    detach(); auditor.close(); await service.stop(); await observer.close(); store.close();
  }
}

test('overlapping authenticated task requests preserve native isolation', { timeout: 45000 }, async t => {
  const results = [];
  for (const mode of ['on', 'off', 'fault']) await t.test(mode, async () => { results.push(await scenario(mode)); });
  assert.equal(results.length, 3); assert.deepEqual(results[0].outcomes, results[1].outcomes); assert.deepEqual(results[0].outcomes, results[2].outcomes);
  const record = { valid: true, modes: results, native_outcomes_equal: true, browser_or_recording_started: false };
  await writeFile(path.join(ROOT, 'review/runtime/concurrency-current.json'), JSON.stringify(record, null, 2));
});
