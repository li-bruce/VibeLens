/** Process-local request audit. Preserve fetch, signals, retries and response values exactly. */
import { appendFile } from 'node:fs';
import { createHash, randomUUID } from 'node:crypto';
import { AsyncLocalStorage } from 'node:async_hooks';
import { channel } from 'node:diagnostics_channel';

if(process.env.BO_TRANSPORT_AUDIT){
  const originalFetch=globalThis.fetch;
  const destination=process.env.BO_TRANSPORT_AUDIT;
  const write=value=>appendFile(destination,JSON.stringify({wall_ms:Date.now(),pid:process.pid,...value})+'\n',()=>{});
  const fetchScope=process.env.BO_HTTP_TIMING_LINKS==='1'?new AsyncLocalStorage():null;
  if(fetchScope){
    const requestIds=new WeakMap(),connections=new WeakMap();let connectionId=0;
    channel('undici:request:create').subscribe(message=>{
      try{const meta=fetchScope.getStore();if(meta&&message.request)requestIds.set(message.request,meta);}catch{}
    });
    channel('undici:client:sendHeaders').subscribe(message=>{
      try{
        const {request,socket}=message;
        let connection=connections.get(socket);
        if(!connection){connection={id:process.pid+':'+(++connectionId),requests:0};connections.set(socket,connection);}
        const ordinal=++connection.requests,meta=requestIds.get(request);
        if(meta)write({event:'transport_send_headers',request_id:meta.request_id,method:meta.method,endpoint:meta.endpoint,connection_id:connection.id,connection_request_index:ordinal,local_address:socket.localAddress,local_port:socket.localPort,remote_address:socket.remoteAddress,remote_port:socket.remotePort});
      }catch{}
    });
  }
  globalThis.fetch=async function(input,options){
    let url;
    try{url=new URL(typeof input==='string'?input:input.url);}catch{return originalFetch(input,options);}
    if(!['127.0.0.1','localhost'].includes(url.hostname) || !['/api/bo/events','/api/bo/events/batch','/api/bo/snapshots','/api/bo/capture'].includes(url.pathname))return originalFetch(input,options);
    const request_id=randomUUID(),started=performance.now();
    let identity={};
    try{
      const body=JSON.parse(options?.body || '{}');
      for(const key of ['protocol','action','id','node','phase','seq','run_id','producer_id','evidence_id','build_id'])if(Object.hasOwn(body,key))identity[key]=body[key];
      if(Array.isArray(body.events)){
        identity.batch_items=body.events.length;
        identity.batch_members=body.events.map(item=>({id:item.id,node:item.node,phase:item.phase,seq:item.seq,run_id:item.run_id,producer_id:item.producer_id,build_id:item.build_id}));
      }
      if(body.action==='ack'&&body.ack)identity.ack={id:body.ack.id,ok:body.ack.ok,health:body.ack.health};
    }catch{}
    const raw=options?.body || '';
    const common={request_id,method:options?.method || 'GET',endpoint:url.origin+url.pathname,...identity,body_bytes:Buffer.byteLength(raw),request_sha256:createHash('sha256').update(raw).digest('hex')};
    write({...common,event:'request'});
    try{
      const send=()=>originalFetch(input,options);
      const response=await (fetchScope?fetchScope.run(common,send):send());
      write({...common,event:'response',status:response.status,elapsed_ms:performance.now()-started});
      if(url.pathname!=='/api/bo/capture'){
        // Read a separate bounded protocol receipt. The SDK receives the original
        // response immediately and retains its own parsing, deadline and retries.
        response.clone().text().then(receipt=>{
          let value,parsed=false;
          try{value=JSON.parse(receipt);parsed=true;}catch{}
          // These are the owned collector's ingress receipts, never request
          // payloads or capture-control responses containing SDK configuration.
          write({...common,event:'receipt',status:response.status,elapsed_ms:performance.now()-started,receipt_bytes:Buffer.byteLength(receipt),receipt_sha256:createHash('sha256').update(receipt).digest('hex'),receipt_body_complete:true,receipt_raw:receipt,...(parsed?{receipt_body:value}:{receipt_json_parse_failed:true})});
        }).catch(error=>write({...common,event:'receipt_read_failure',error_type:error.name,elapsed_ms:performance.now()-started}));
      }
      return response;
    }catch(error){
      write({...common,event:'failure',error_type:error.name,elapsed_ms:performance.now()-started});
      throw error;
    }
  };
}
