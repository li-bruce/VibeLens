import { spawn } from 'node:child_process';
import { mkdir, mkdtemp, readFile, writeFile } from 'node:fs/promises';
import { openSync } from 'node:fs';
import http from 'node:http';
import net from 'node:net';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const runtime=path.join(root,'review/runtime');await mkdir(runtime,{recursive:true});
const fixture=Buffer.from('Desktop browser resilience fixture.\n');
const settings=JSON.parse(await readFile(path.join(root,'.stategraph/collector.json'),'utf8'));
const skillProvider=process.env.VIBELENS_SKILL || path.resolve(root,'../node-migration-final-skills/vibelens');
const filename='Browser fixture '+settings.build_id.slice(0,8)+(process.env.BROWSER_TRIAL_ID?'-'+process.env.BROWSER_TRIAL_ID:'')+'.txt';
const modes={on:{url:'http://127.0.0.1:8925',data_root:process.env.APP_DATA_ROOT || path.join(root,'var'),skill_provider:skillProvider}};
const children=[],faultCounts={};
/** Refuse to replace a listener owned by another command. */
async function occupied(port){return await new Promise(resolve=>{const socket=net.connect(port,'127.0.0.1');socket.once('connect',()=>{socket.destroy();resolve(true);});socket.once('error',()=>resolve(false));});}
for(const port of [8935,8936])if(await occupied(port))throw new Error('Browser trial port is occupied: '+port);
const faultServer=http.createServer((request,response)=>{
  if(request.url==='/fixture-health'){response.writeHead(200,{'Content-Type':'application/json'});response.end(JSON.stringify(faultCounts));return;}
  const origin=request.headers.origin || 'native-node',key=request.method+' '+request.url;
  faultCounts[origin] ||= {};faultCounts[origin][key]=(faultCounts[origin][key] || 0)+1;
  if(request.headers.origin==='http://127.0.0.1:8936')response.setHeader('Access-Control-Allow-Origin',request.headers.origin);
  response.setHeader('Access-Control-Allow-Headers','Content-Type,X-BO-Token');response.setHeader('Access-Control-Allow-Methods','POST,OPTIONS');
  request.resume();response.writeHead(request.method==='OPTIONS'?204:503,{'Content-Type':'application/json'});response.end(request.method==='OPTIONS'?'':JSON.stringify({error:'deliberate-observer-transport-failure'}));
});
await new Promise(resolve=>faultServer.listen(0,'127.0.0.1',resolve));
const faultEndpoint='http://127.0.0.1:'+faultServer.address().port;
/** Await actual native HTTP readiness before creating synthetic setup data. */
async function ready(url,child){for(let i=0;i<100;i++){if(child?.exitCode!==null&&child)throw new Error('Trial app exited');try{if((await fetch(url,{signal:AbortSignal.timeout(500)})).ok)return;}catch{}await new Promise(resolve=>setTimeout(resolve,200));}throw new Error('Trial readiness timeout');}
/** Stop only child handles and the fault listener owned by this invocation. */
function stop(){for(const child of children)if(child.exitCode===null)child.kill();faultServer.close();}
process.once('SIGINT',()=>{stop();process.exit(0);});process.once('SIGTERM',()=>{stop();process.exit(0);});process.once('exit',stop);
try{
  for(const [mode,port] of [['off',8935],['fault',8936]]){
    const dataRoot=await mkdtemp(path.join(runtime,'browser-'+mode+'-'));
    const env={...process.env,PORT:String(port),APP_DATA_ROOT:dataRoot,VIBELENS_ENABLED:mode==='off'?'0':'1',VIBELENS_ENDPOINT:faultEndpoint,VIBELENS_SKILL:skillProvider};
    const child=spawn(process.execPath,['src/server.mjs'],{cwd:root,env,windowsHide:true,stdio:['ignore',openSync(path.join(dataRoot,'app.stdout.log'),'a'),openSync(path.join(dataRoot,'app.stderr.log'),'a')]});children.push(child);
    const url='http://127.0.0.1:'+port;await ready(url,child);
    modes[mode]={url,data_root:dataRoot,pid:child.pid,skill_provider:skillProvider};
  }
  for(const [mode,trial] of Object.entries(modes)){
    const login=await fetch(trial.url+'/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:'alice',password:'DemoPass!2026'})});
    if(login.status!==200)throw new Error('Synthetic setup login failed: '+mode);
    const cookie=login.headers.get('set-cookie').split(';')[0];
    const upload=await fetch(trial.url+'/api/files?name='+encodeURIComponent(filename),{method:'POST',headers:{Cookie:cookie,'Content-Type':'application/octet-stream'},body:fixture});
    if(upload.status!==201)throw new Error('Synthetic setup upload failed: '+mode);
    trial.fixture_file_id=(await upload.json()).id;
  }
  const report={launcher_pid:process.pid,build_id:settings.build_id,filename,sha256:createHash('sha256').update(fixture).digest('hex'),modes,fault_endpoint:faultEndpoint,fault_fixture:'Owned local observer endpoint acknowledges CORS preflight and returns real HTTP 503 for capture/transport; it never accepts events or writes business data.'};
  await writeFile(path.join(runtime,'browser-trials.json'),JSON.stringify(report,null,2));
  console.log(JSON.stringify(report));
}catch(error){stop();throw error;}
