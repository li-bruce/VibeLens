"""Derive a bounded diagnosis from the preserved batch run, without starting services."""
from collections import Counter
from datetime import datetime
import hashlib
import json
from pathlib import Path
import statistics
import sqlite3
from urllib.parse import urlsplit
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'review/runtime'
RUN = OUT / 'unified-1795147982'
PROVIDER = ROOT.parent / 'node-batch-candidate-skills/vibelens'
FIRST = '80c79457da6d458e98f08ed95a8aeaf1'
FAILED = '2bfbcf27b8db42d490f3b19c5ac3abb8'
SOURCE_ARCHIVE = OUT / 'batch-candidate-failure-1795147982.zip'


def source_bytes(path):
    """Prefer immutable run bytes after later project builds replace shared outputs."""
    if SOURCE_ARCHIVE.exists() and path.is_relative_to(ROOT):
        with ZipFile(SOURCE_ARCHIVE) as zip_file:
            try:
                return zip_file.read(path.relative_to(ROOT).as_posix())
            except KeyError:
                pass
    return path.read_bytes()


def read(path):
    return json.loads(source_bytes(path).decode('utf-8'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


rows = [json.loads(line) for line in source_bytes(RUN / 'native-fetch.jsonl').decode('utf-8').splitlines() if line]
requests = {row['request_id']: row for row in rows if row['event'] == 'request'}
responses = [row for row in rows if row['event'] == 'response']
failures = [{**row, 'body_bytes': requests[row['request_id']]['body_bytes']} for row in rows if row['event'] == 'failure']
endpoint = lambda row: urlsplit(row['endpoint']).path
stats = {}
for name in ['capture', 'events/batch', 'events', 'snapshots']:
    path = '/api/bo/' + name
    submitted = [row for row in requests.values() if endpoint(row) == path]
    returned = [row for row in responses if endpoint(row) == path]
    latency = sorted(row['elapsed_ms'] for row in returned)
    sizes = [row['body_bytes'] for row in submitted]
    stats[path] = {
        'requests': len(submitted), 'responses': len(returned),
        'status_counts': dict(Counter(str(row['status']) for row in returned)),
        'failures': len([row for row in failures if endpoint(row) == path]),
        'response_header_ms': {'median': statistics.median(latency), 'p95': latency[int(.95 * (len(latency) - 1))], 'max': max(latency), 'sum': sum(latency)},
        'request_bytes': {'min': min(sizes), 'median': statistics.median(sizes), 'max': max(sizes), 'sum': sum(sizes)},
    }
    if name == 'events/batch':
        stats[path].update(items_including_retries=sum(row['batch_items'] for row in submitted), batch_item_counts=dict(Counter(row['batch_items'] for row in submitted)))

life = read(RUN / 'lifecycle.json')
first = read(OUT / ('independent-recording-' + FIRST + '.json'))
failed = read(OUT / ('failed-recording-' + FAILED + '.json'))
acceptance = read(OUT / 'browser-acceptance.json')
events = failed['events']
latest = max(row['observed_at'] for row in events)
latest_ms = datetime.fromisoformat(latest.replace('Z', '+00:00')).timestamp() * 1000
progress = []
for offset in range(0, 50, 5):
    selected = [row for row in rows if latest_ms + offset * 1000 <= row['wall_ms'] < latest_ms + (offset + 5) * 1000]
    counts = Counter(endpoint(row) + ' ' + row['event'] for row in selected)
    progress.append({'seconds_after_last_received_event_was_produced': offset, 'counts': dict(counts)})

sdk = {}
for name in ['bo_runtime.mjs', 'bo_capture.mjs', 'bo_http.mjs']:
    local = ROOT / 'bo_stategraph' / name
    installed = PROVIDER / 'scripts/bo_observer/adapters/javascript' / name
    sdk[name] = {'project_sha256': hashlib.sha256(source_bytes(local)).hexdigest(), 'candidate_sha256': sha(installed), 'identical': source_bytes(local) == installed.read_bytes()}
schema = PROVIDER / 'scripts/bo_observer/schemas/event-batch.schema.json'
snapshot_failure_id = next(row['evidence_id'] for row in failures if endpoint(row).endswith('/snapshots'))
snapshot_event = next(row for row in events if row['id'] == snapshot_failure_id)
database = sqlite3.connect(':memory:')
try:
    database.deserialize(source_bytes(ROOT / 'var/db/application.sqlite'))
    native_counts = {name: database.execute('SELECT COUNT(*) FROM ' + name).fetchone()[0] for name in ['users', 'sessions', 'files', 'grants', 'tasks', 'announcements']}
    task_states = dict(database.execute('SELECT status,COUNT(*) FROM tasks GROUP BY status'))
finally:
    database.close()
analysis = {
    'schema': 'project-batch-diagnosis/v1', 'diagnostic_only': True, 'run_id': life['run_id'], 'build_id': life['build_id'],
    'first_recording': {'id': FIRST, 'status': first['status'], 'events': len(first['events']), 'gaps': first['gaps'], 'settlement': first['producer_settlement']},
    'failed_recording': {'id': FAILED, 'status': failed['status'], 'events': len(events), 'gaps': failed['gaps'], 'settlement': failed['producer_settlement'], 'final_health': failed['final']['health'],
        'failure_stage': 'Second recording: native_idle before the second stop control was clicked; exception cleanup subsequently stopped it.',
        'exact_wait_timeout_health_retained': False, 'final_health_boundary': 'Later recording-stop boundary during exception cleanup; not the exact native_idle failure instant.',
        'page': 'Team files; confirmed by preserved screenshot and archived source line 204.',
        'received_event_production_start': min(row['observed_at'] for row in events), 'received_event_production_end': latest,
        'task_api_enter_times': [row['observed_at'] for row in events if row['node'] == 'api_tasks' and row['phase'] == 'enter'],
        'per_node_counts': dict(Counter(row['node'] for row in events)),
        'api_enter_counts': dict(Counter(row['node'] for row in events if row['node'].startswith('api_') and row['phase'] == 'enter')),
    },
    'sealed_native_database': {'counts': native_counts, 'task_states_at_cleanup': task_states, 'sha256': hashlib.sha256(source_bytes(ROOT / 'var/db/application.sqlite')).hexdigest()},
    'business_checks': acceptance['checks'], 'all_checks_true': all(acceptance['checks'].values()),
    'http': stats, 'failed_attempts': failures,
    'double_failed_snapshot': {'id': snapshot_failure_id, 'node': snapshot_event['node'], 'phase': snapshot_event['phase'], 'produced_at': snapshot_event['observed_at'],
        'attempts': [row for row in failures if row.get('evidence_id') == snapshot_failure_id]},
    'delivery_progress_after_last_received_event_was_produced': progress,
    'provider': {'viewer': life['skill_provider'], 'managed_adapters': sdk, 'event_batch_schema': {'path': str(schema), 'sha256': sha(schema), 'exists': schema.exists()},
        'on_off_fault_provider_consistent': False, 'off_fault_issue': 'Archived browser_trials.mjs explicitly overrides VIBELENS_SKILL with node-migration-final-skills. The project managed runtime is still the new shared file. These three business outcomes do not establish provider-consistent candidate acceptance.'},
    'receipts': {'http_statuses_retained': True, 'receipt_bodies_retained': False, 'batch_member_ids_retained': False,
        'sdk_source_contract': 'The selected SDK parses each batch response and requires one accepted:true receipt per submitted item. This source contract does not recreate the missing actual response bodies.'},
    'liveness': {'all_ready_ms': life['all_ready_ms'], 'children': [{key: item[key] for key in ['label', 'pid', 'pre_cleanup_exit_code', 'termination', 'exit_code']} for item in life['children']], 'cleaned_up_ms': life['cleaned_up_ms']},
    'load_context_correction': 'The orchestration chat reported a short overlap with managed-example checks, not a human report or a concurrent full root regression. The full root regression had not been started during this run. No resource isolation or CPU attribution is claimed.',
    'findings': [
        'The successful first recording must remain successful and separate from the failed second recording.',
        'The second native_idle predicate waits for global pending==0, not a finite flush-prefix target. However, this particular wait followed navigation to Team files. The preserved received events were produced within about five seconds, and transport continued for over forty seconds afterward. No evidence supports ongoing task-page polling as the cause of this failure.',
        'The observed queue was draining a finite burst, not proven deadlocked: many batch/snapshot responses continued throughout the 35-second wait and subsequent exception cleanup. Exact pending and enqueue rates during the wait were not retained.',
        'Snapshot evidence 2200 (native_state:session:absent) exhausted both original 1000ms attempts, at 572 bytes. This is an actual observer transport error independent of the project wait predicate. Its receipt may have been lost after admission; raw evidence does not prove whether the server committed it.',
        'All observed HTTP responses were 200, but ten request attempts timed out. Later batch retry and single-event fallback continued. The exact slow server function or lock owner is not identified by this unprofiled run.',
        'The native reader archived with this run imported bo_internal from an older provider URL while project data wiring imported the selected provider. Its module-local AsyncLocalStorage could not suppress the other module instance. This inflated native verification capture; it does not explain the live-browser backlog because the live app does not import the reader.',
    ],
    'acceptance': {'whole_candidate_round_passed': False, 'final_change_sync_gate_passed': False, 'recording_or_health_cleared_to_claim_success': False, 'performance_rerun_started_by_this_analysis': False},
}
json_path = OUT / 'batch-candidate-1795147982-analysis.json'
save(json_path, analysis)
report = f"""# Batch candidate: preserved partial success and failure

Diagnostic only. Build `{life['build_id']}`. No services were started for this analysis.

The first recording `{FIRST}` completed: {len(first['events'])} events, no gaps, producer target/completed 857/857, pending 0. All {len(acceptance['checks'])} recorded business-check groups are true. The entire candidate round has not passed.

The failure is the **second recording's end-before-stop native_idle**, at browser_acceptance.py:205 -> stop_record:74 -> native_idle:55 -> until:31. Its preserved screenshot shows Team files. Exception cleanup later stopped `{FAILED}` as interrupted: {len(events)} received events, completed/target 4241/4389, pending 148, producer errors 1, and two explicit gaps. The helper did not retain its last health value at the exact 35-second timeout. The final recording health is a later boundary; it cannot substitute for that missing value.

Received events were produced from {analysis['failed_recording']['received_event_production_start']} through {latest}. Task API calls appear only within that short business sequence. The sealed database contains 13 files and 15 tasks, all ready at cleanup. Repeated file-list queries generated actual per-file policy/data work (see API/node counts in JSON). Native transport continued delivering the existing burst for over forty seconds afterward. The screenshot, source and event timestamps do not support ongoing task-page polling as this failure's cause. Exact per-poll enqueue/pending rates are unavailable. The global pending==0 test is conceptually different from the SDK's finite flush prefix, but changing that test would not repair the observed transport error.

Snapshot `{snapshot_failure_id}` belongs to `{snapshot_event['node']}` / `{snapshot_event['phase']}`. Both 572-byte attempts timed out at 1005.93 and 1010.41 ms. Original SDK deadlines and retries were unchanged. The native SDK records an item transport error after exhausting those two attempts, then continues delivery. Later batch attempts also timed out and triggered identity-preserving single-item fallback. Those later attempts include work after the helper had already failed, so they cannot all be assigned to its initial 35-second wait.

The audit contains 234 batch attempts and 4213 summed items **including retries**, with 229 HTTP 200 batch responses. Batch request sizes range from 1833 to 24536 bytes (median 23858). It also contains 48 single-event attempts and 41 snapshot attempts. Across all four endpoints there are 1249 observed responses, all 200, and ten TimeoutError attempts. Two final requests had no result before owned cleanup. Actual response receipt bodies and batch member lists were not retained. HTTP 200 alone is not a substitute for those bodies. The selected SDK source validates their length and accepted flags, but missing bodies cannot be reconstructed.

The viewer launch path is the batch candidate; its batch schema exists. All three managed JavaScript files match candidate bytes (see JSON hashes and existing canonical check). Actual /api/bo/events/batch responses establish use of the new ingress. Off/fault child configuration still points to the old provider, although the project managed runtime file is shared. Existing equal native business outcomes therefore remain evidence of those runs, not a provider-consistent candidate round.

All owned services were alive at readiness and before parent cleanup (pre_cleanup_exit_code null). Their later exit code 1 is recorded as owned_parent_cleanup. No startup connection-refused failure occurred in this run. The original lifecycle load label was overly broad: an orchestration message reported only a short overlap with managed-example checks; full root regression had not run concurrently. No CPU or specific server-function attribution is established.

Two project-owned harness corrections are indicated: inherit one provider in all three browser modes, and import the selected provider's bo_internal in the native reader. The latter fixes observer-query exclusion and does not explain the live application backlog. Before any authorized targeted rerun, retain per-wait health samples, exact exception stack, active page and safe batch/receipt identities. Preserve failed recordings and default deadlines. Do not accept this diagnostic candidate based only on its successful first recording.
"""
md_path = OUT / 'BATCH_CANDIDATE_1795147982_DIAGNOSIS.md'
md_path.write_text(report, encoding='utf-8')
save(RUN / 'load-context-correction.json', {'source': 'orchestration-chat clarification', 'raw_lifecycle_unchanged': True, 'correction': analysis['load_context_correction']})

archive = OUT / 'batch-candidate-failure-1795147982.zip'
seal = OUT / 'batch-candidate-failure-1795147982-seal.json'
if not archive.exists():
    paths = list(RUN.rglob('*'))
    names = ['browser-acceptance.json', 'browser-trials.json', 'browser-capture.json', 'browser-on-recording.json',
             'independent-recording-' + FIRST + '.json', 'failed-recording-' + FAILED + '.json',
             'browser-failure.jpg', 'graph-failure.jpg', 'batch-candidate-real-recording-command.log',
             json_path.name, md_path.name]
    paths += [OUT / name for name in names]
    paths += [ROOT / folder / name for folder, name in [('tests', 'native_reader.mjs'), ('tests', 'observe.mjs'), ('tooling', 'analyze_batch_run.py'), ('initial-node-app', 'baseline.json')]]
    paths += list((ROOT / 'src').glob('*')) + list((ROOT / 'public').glob('*')) + list((ROOT / 'integrations').glob('*'))
    paths += [ROOT / 'bo_stategraph' / name for name in ['bo_runtime.mjs', 'bo_capture.mjs', 'bo_http.mjs', 'integration.json']]
    paths += [ROOT / 'review' / name for name in ['batch-candidate-plan.json', 'batch-candidate-apply.json', 'batch-candidate-check.json']]
    paths += [ROOT / 'var/db/application.sqlite']
    paths = sorted(set(path for path in paths if path.is_file()))
    manifest = {path.relative_to(ROOT).as_posix(): {'sha256': sha(path), 'bytes': path.stat().st_size} for path in paths}
    with ZipFile(archive, 'x', compression=ZIP_DEFLATED) as zip_file:
        for path in paths:
            zip_file.write(path, path.relative_to(ROOT).as_posix())
    save(seal, {'diagnostic_only': True, 'whole_candidate_round_passed': False, 'archive': str(archive), 'sha256': sha(archive), 'files': manifest})
print(json.dumps({'analysis': str(md_path), 'first_recording_success': True, 'whole_candidate_round_passed': False, 'archive_sha256': sha(archive), 'seal': str(seal)}, ensure_ascii=False))
