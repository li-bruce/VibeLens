"""Keep the actual graph display open and audit one real native recording."""
import json
import os
from pathlib import Path
import time
import sqlite3
import urllib.request
from urllib.parse import urlsplit
from playwright.sync_api import sync_playwright,expect

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'review/runtime';RUN=Path(os.environ['BO_UNIFIED_RUN'])
TRIAL=json.loads((OUT/'browser-trials.json').read_text(encoding='utf-8'))
APP=TRIAL['modes']['on']['url'];GRAPH='http://127.0.0.1:8926'
result={'source':'actual-independent-browser-with-live-viewer','build_id':TRIAL['build_id'],'default_native_transport_timeout_ms':1000,'managed_attempts_per_item':2,'deadlines_changed':False,'concurrent_framework_regression_reported_by_user':os.environ.get('BO_REGRESSION_LOAD')!='ended'}
database=sqlite3.connect((Path(TRIAL['modes']['on']['data_root'])/'db/application.sqlite').as_uri()+'?mode=ro',uri=True)
try:
    result['native_data_cardinality']={table:database.execute('SELECT COUNT(*) FROM '+table).fetchone()[0] for table in ['files','tasks','sessions']}
finally:database.close()

def read(url):
    with urllib.request.urlopen(url,timeout=25) as response:return json.load(response)

def save(name,value):(RUN/name).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')

with (RUN/'browser-network.jsonl').open('w',encoding='utf-8',buffering=1) as stream,sync_playwright() as pw:
    browser=pw.chromium.launch(channel='chrome',headless=True)
    context=browser.new_context(accept_downloads=True,viewport={'width':1440,'height':1000})
    app=context.new_page();graph=context.new_page();starts={}
    def note(request,event,status=None):
        if not request.url.startswith(GRAPH):return
        key=id(request)
        if event=='request':starts[key]=time.perf_counter()
        timing=request.timing
        value={'observed_wall_ms':time.time_ns()/1e6,'network_start_ms':timing['startTime'],'event':event,'method':request.method,'path':urlsplit(request.url).path,'request_key':key}
        if status is not None:value['status']=status
        if timing.get('responseEnd',-1)>=0:
            value['elapsed_ms']=timing['responseEnd'];value['network_end_ms']=timing['startTime']+timing['responseEnd']
        elif key in starts:value['callback_elapsed_ms']=(time.perf_counter()-starts[key])*1000
        if event=='failed':value['failure']=request.failure
        stream.write(json.dumps(value)+'\n')
    for page in [app,graph]:
        page.on('request',lambda request:note(request,'request'))
        page.on('response',lambda response:note(response.request,'response',response.status))
        page.on('requestfinished',lambda request:note(request,'finished'))
        page.on('requestfailed',lambda request:note(request,'failed'))
    identity=None
    try:
        app.goto(APP,wait_until='domcontentloaded');expect(app.locator('#login-form')).to_be_visible()
        graph.goto(GRAPH+'/graph',wait_until='domcontentloaded')
        graph.locator('#analysis-view option').first.wait_for(state='attached',timeout=40000)
        if graph.get_by_role('button',name='返回实时观察',exact=True).is_visible():graph.get_by_role('button',name='返回实时观察',exact=True).click()
        expect(graph.locator('#record-start')).to_be_enabled(timeout=40000)
        result['before_start_health']=read(APP+'/api/bo/health')
        graph.locator('#record-start').click()
        expect(graph.locator('#record-stop')).to_be_enabled(timeout=40000)
        identity=read(GRAPH+'/api/recordings')['active']['id'];result['recording_id']=identity
        app.bring_to_front()
        app.get_by_role('textbox',name='用户名',exact=True).fill('alice')
        app.get_by_role('textbox',name='密码',exact=True).fill('DemoPass!2026')
        app.get_by_role('button',name='登录',exact=True).click()
        target=app.get_by_role('article').filter(has_text=TRIAL['filename'])
        expect(target).to_be_visible()
        with app.expect_response(lambda response:response.url.endswith('/api/tasks') and response.request.method=='POST') as response:
            target.get_by_role('button',name='准备下载',exact=True).click()
        body=response.value.json();assert response.value.status==202;result['native_submission']=body
        app.get_by_role('button',name='↓ 我的下载',exact=True).click()
        app.get_by_role('button',name='刷新进度',exact=True).click()
        expect(app.locator('a[href="/api/tasks/'+body['task_id']+'/download"]')).to_be_visible(timeout=15000)
        app.screenshot(path=str(RUN/'native-ready.jpg'),full_page=True,type='jpeg')
        save('native-ready-ui.json',{'source':'automated-desktop-browser-playwright','url':app.url,'observed_at':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'dom_excerpt':app.locator('body').inner_text()})
        result['native_ready_visible']=True
        app.get_by_role('button',name='▤ 团队文件',exact=True).click()
        for _ in range(1):
            with app.expect_response(lambda response:response.url.endswith('/api/files') and response.request.method=='GET'):
                app.get_by_role('button',name='刷新列表',exact=True).click()
        deadline=time.monotonic()+30
        while time.monotonic()<deadline:
            health=read(APP+'/api/bo/health')
            if health['pending']==0:break
            time.sleep(.15)
        result['before_stop_health']=health
        result['queue_idle_before_stop']=health['pending']==0
        graph.bring_to_front();graph.locator('#record-stop').click()
        deadline=time.monotonic()+35
        while time.monotonic()<deadline and read(GRAPH+'/api/recordings')['active'] is not None:time.sleep(.15)
        recording=read(GRAPH+'/api/recordings/'+identity);save('recording.json',recording)
        result.update(status=recording['status'],gaps=recording['gaps'],producer_settlement=recording['producer_settlement'],recording_health=recording['final']['health'])
        result['after_stop_health']=read(APP+'/api/bo/health')
        graph.screenshot(path=str(RUN/'recording-result.jpg'),full_page=True,type='jpeg')
    except Exception as error:
        result['error']=str(error)
        try:
            app.screenshot(path=str(RUN/'repro-error.jpg'),full_page=True,type='jpeg')
            graph.screenshot(path=str(RUN/'viewer-error.jpg'),full_page=True,type='jpeg')
            save('viewer-error-dom.json',{'body':graph.locator('body').inner_text()})
            if identity:save('recording-at-error.json',read(GRAPH+'/api/recordings/'+identity))
        except Exception:pass
        raise
    finally:
        save('transport-result.json',result);browser.close()
        print(json.dumps({k:result.get(k) for k in ['recording_id','status','gaps','native_ready_visible','error']}),flush=True)
