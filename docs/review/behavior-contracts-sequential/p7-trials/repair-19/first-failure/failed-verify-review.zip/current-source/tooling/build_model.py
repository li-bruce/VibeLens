"""Build project-owned native mappings using the installed canonical VibeLens projectors."""
import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
SKILL = Path(os.environ.get("VIBELENS_SKILL", ROOT.parent / "node-migration-final-skills/vibelens")).resolve()
sys.path.insert(0, str(SKILL / "scripts"))
from bo_observer.concepts.semantics import snapshot
from bo_observer.policy.projection import project as policy_project

def read(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8-sig"))
def write(name, value):
    target = ROOT / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
def sha(name):
    return hashlib.sha256((ROOT / name).read_bytes()).hexdigest()

d = read("discovery.json")
project_id = d["project_id"]
actions = {
    "login":"FileService.login", "logout":"FileService.logout",
    "upload_file":"FileService.upload", "view_file":"FileService.viewFile",
    "share_file":"FileService.setGrant", "revoke_share":"FileService.setGrant",
    "request_download":"FileService.requestDownload", "prepare_download":"FileService.drainWorker",
    "mark_download_ready":"FileService.drainWorker", "collect_download":"FileService.collect",
    "read_announcements":"FileService.announcements", "publish_announcement":"FileService.publish",
    "edit_announcement":"FileService.mutateAnnouncement", "delete_announcement":"FileService.mutateAnnouncement",
    "list_files":"FileService.listFiles", "list_tasks":"FileService.listTasks"
}
input_fields = {
    "login":{"username":"string","password_supplied":"boolean"}, "logout":{"actor_id":"string"},
    "upload_file":{"actor_id":"string","name":"string","byte_count":"number"},
    "view_file":{"actor_id":"string","file_id":"string"},
    "share_file":{"actor_id":"string","file_id":"string","recipient_id":"string"},
    "revoke_share":{"actor_id":"string","file_id":"string","recipient_id":"string"},
    "request_download":{"actor_id":"string","file_id":"string"},
    "prepare_download":{"task_id":"string","requester_id":"string","file_id":"string"},
    "mark_download_ready":{"task_id":"string"}, "collect_download":{"actor_id":"string","task_id":"string"},
    "read_announcements":{"actor_id":"string"}, "publish_announcement":{"actor_id":"string","title":"string","body_length":"number"},
    "edit_announcement":{"actor_id":"string","announcement_id":"string","title":"string","body_length":"number"},
    "delete_announcement":{"actor_id":"string","announcement_id":"string","title":"string","body_length":"number"},
    "list_files":{"actor_id":"string"},"list_tasks":{"actor_id":"string"}
}
output_fields = {
    "login":{"allowed":"boolean","user_id":"string","editor":"boolean","session_id":"string"},
    "logout":{"allowed":"boolean","user_id":"string"},
    "upload_file":{"id":"string","name":"string","size":"number","sha256":"string","owner_id":"string","allowed":"boolean"},
    "view_file":{"id":"string","name":"string","size":"number","owner_id":"string","allowed":"boolean"},
    "share_file":{"file_id":"string","recipient_id":"string","active":"boolean","revision":"number","allowed":"boolean"},
    "revoke_share":{"file_id":"string","recipient_id":"string","active":"boolean","revision":"number","allowed":"boolean"},
    "request_download":{"task_id":"string","file_id":"string","requester_id":"string","status":"string","authorized_at_submission":"boolean","transaction_id":"string","committed":"boolean","allowed":"boolean"},
    "prepare_download":{"task_id":"string","status":"string","sha256":"string","allowed":"boolean"},
    "mark_download_ready":{"task_id":"string","status":"string","sha256":"string","allowed":"boolean"},
    "collect_download":{"task_id":"string","requester_id":"string","status":"string","byte_count":"number","sha256":"string","allowed":"boolean"},
    "read_announcements":{"count":"number"}, "publish_announcement":{"id":"string","author_id":"string","title":"string","status":"string","revision":"number","allowed":"boolean"},
    "edit_announcement":{"id":"string","status":"string","revision":"number","allowed":"boolean"},
    "delete_announcement":{"id":"string","status":"string","revision":"number","allowed":"boolean"},
    "list_files":{"count":"number"}, "list_tasks":{"count":"number"}
}
labels = {node["id"]:node["label"] for net in d["networks"] for node in net["nodes"]}
source = lambda symbol: {"path":"src/service.mjs","symbol":symbol}
nodes = []
for ident, symbol in actions.items():
    nodes.append({"id":ident,"kind":"action","label":labels.get(ident,ident),"summary":"Observe the actual native operation and its selected outcome.","source":source(symbol),"requirements":["R_AUTH" if ident in {"login","logout"} else "R_BOARD" if "announcement" in ident else "R_DOWNLOAD" if "download" in ident or ident=="list_tasks" else "R_FILES"],"capture":{"in":input_fields[ident],"out":{**output_fields[ident],"error":"string","http_status":"number"}}})
nodes.append({"id":"policy_facts","kind":"function","label":"Native authorization facts","source":source("FileService.authorize"),"capture":{"in":{"operation":"string"},"out":dict(d["policy"]["inputs"])}})
for operation in d["policy"]["operations"]:
    nodes.append({"id":"guard_"+operation["id"],"kind":"decision","label":"Native decision "+operation["id"],"source":source("FileService.authorize"),"policy_operation":operation["id"],"capture":{"in":{"operation":"string"},"out":{"value":"boolean"}}})
nodes.append({"id":"task_commit","kind":"effect","label":"Commit admitted task","source":source("FileService.requestDownload"),"capture":{"in":{"task_id":"string","transaction_id":"string"},"out":{"committed":"boolean","authorized_at_submission":"boolean","transaction_id":"string"}}})
machines = {}
for model in d["state_models"]:
    guards = {name:{"source":source("FileService.authorize")} for name in model["guards"]}
    machines[model["id"]] = {"engine":"bo.fsm","version":"1","states":model["states"],"values":model["states"],"initial":model["initial"],"state_type":"enum","context":model["context"],"events":model["events"],"guards":guards,"transitions":[{k:copy.deepcopy(t[k]) for k in ("source","dest","trigger","conditions") if k in t} for t in model["transitions"]]}
    for value in model["states"]:
        nodes.append({"id":"native_state:"+model["id"]+":"+value,"kind":"state","label":model["label"]+" / "+value,"value":value,"state_model_id":model["id"],"source":source("FileService.state"),"capture":{"in":{},"out":{"state":"string","revision":"number","state_model_id":"string",**{key:spec["type"] for key,spec in model["context"].items()}}}})
api = {
 "api_session":("GET","/api/auth/session","sessionHandler"),"api_login":("POST","/api/auth/login","loginHandler"),
 "api_logout":("POST","/api/auth/logout","logoutHandler"),"api_members":("GET","/api/members","membersHandler"),
 "api_files":("GET","/api/files","filesHandler"),"api_file":("GET","/api/files/:id","fileHandler"),
 "api_upload":("POST","/api/files","uploadHandler"),"api_share":("POST","/api/files/:id/shares","shareHandler"),
 "api_revoke":("DELETE","/api/files/:id/shares/:recipient","revokeHandler"),"api_request":("POST","/api/tasks","requestHandler"),
 "api_tasks":("GET","/api/tasks","tasksHandler"),"api_collect":("GET","/api/tasks/:id/download","collectHandler"),
 "api_board":("GET","/api/announcements","boardHandler"),"api_publish":("POST","/api/announcements","publishHandler"),
 "api_edit":("PUT","/api/announcements/:id","editHandler"),"api_delete":("DELETE","/api/announcements/:id","deleteHandler")}
for ident,(method,route,handler) in api.items():
    nodes.append({"id":ident,"kind":"function","label":method+" "+route,"source":{"path":"src/http.mjs","symbol":"createApp."+handler},"capture":{"in":{"method":"string","path":"string"},"out":{"status":"number","duration_ms":"number"}}})
edges = []
for net in d["networks"]:
    for edge in net["edges"]:
        edges.append({"id":"native:"+edge["id"],"from":edge["from"],"to":edge["to"],"type":"flow" if edge["relation"]=="flow" else "data","label":edge["label"],"evidence":"Declared confirmed business route; actual calls are captured separately."})
policy = copy.deepcopy(d["policy"])
policy["stage"]="bound"
for pred in policy["predicates"]:
    pred["source"]={"path":"src/policy.mjs","symbol":"sameIdentity"}
for op in policy["operations"]:
    op["cases"]=["workflow"]
model = {"schema_version":3,"revision":"native-1","project_id":project_id,"intent":"intent.json","source_files":["src/store.mjs","src/policy.mjs","src/service.mjs","src/http.mjs","src/server.mjs","public/app.js","public/index.html","public/app.css","discovery.json","implementation.json"],"nodes":nodes,"edges":edges,"overview":list(actions),"scope":{"exclude":[]},"machines":machines,"policy":policy,"presentation":{"subject":"Team file sharing","layout_id":d["layout_id"]}}
# Canonical policy projection is used unchanged; this file does not implement a projector.
model = policy_project(model)
for ident in ["share_file", "revoke_share"]:
    input_fields[ident]["active"]="boolean"
input_fields["logout"]["token_present"]="boolean"
for ident in ["edit_announcement", "delete_announcement"]:
    input_fields[ident]["action"]="string"
for node in model["nodes"]:
    if node["id"] in input_fields:
        node["capture"]["in"]=input_fields[node["id"]]
    if node["id"] in {"prepare_download","mark_download_ready","list_files","list_tasks","read_announcements"}:
        node["capture"]["out"].pop("error",None)
        node["capture"]["out"].pop("http_status",None)
model["scope"]["unknowns"] = ["Only registered native scenarios establish executed dynamic callback paths."]
model["overview"] = [{"node":ident,"x":30+(index%4)*210,"y":40+(index//4)*150} for index,ident in enumerate(actions)]
for node in model["nodes"]:
    node.setdefault("summary", node["label"])
    if node.get("kind") == "state":
        node["layer"] = "state"
requirements = [
 {"id":"R_AUTH","text":"Real username/password sessions and logout; three test accounts, one announcement editor; no registration or account management UI.","status":"confirmed","source_refs":["U4"]},
 {"id":"R_FILES","text":"Only uploader/current recipients see files; only uploader manages grants; no recipient re-sharing.","status":"confirmed","source_refs":["U2"]},
 {"id":"R_DOWNLOAD","text":"Authorize at submission, preserve an admitted task after revocation and allow repeated collection by its original requester; deny new tasks after revocation.","status":"confirmed","source_refs":["U2","U3"]},
 {"id":"R_BOARD","text":"Independent authenticated board; designated editor manages only own announcements; role adds no file rights.","status":"confirmed","source_refs":["U2"]}
]
write("intent.json",{"project_id":project_id,"goal":d["goal"],"requirements":requirements,"out_of_scope":["Registration","Account management","Recipient re-sharing"]})
for requirement in requirements:
    requirement["source"] = "Actual user statements in discovery.json: " + ", ".join(requirement["source_refs"])
write("intent.json",{"intent_id":project_id,"project_id":project_id,"revision":"1","goal":d["goal"],"requirements":requirements,"exclusions":["Registration","Account management","Recipient re-sharing"]})
write("implementation.json",{"schema":"bo-implementation/v1","features":[],"support":{},"excluded":{}})
envelope = {"protocol":"bo-project/v2","project_id":project_id,"selection":{"mode":"observe","source":"user","answer":"应用沿用自身的业务逻辑，VibeLens 用 observe 模式。","locator":"U1 in discovery.json"},"model":model,"contracts":{"discovery":{"path":"discovery.json","sha256":sha("discovery.json"),"schema":d["schema"]},"behavior":None,"analysis_profiles":[]}}
write("bo_stategraph/project.json",envelope)
sync=read("sync.json")
sync.update({"model":"bo_stategraph/project.json","manifest":"manifest.json","intent":"intent.json","code_files":["src/store.mjs","src/policy.mjs","src/service.mjs","src/http.mjs","src/server.mjs","public/app.js"],"watch_files":["public/index.html","public/app.css","discovery.json","implementation.json","package.json","package-lock.json"],"stategraph":{"module":"bo_stategraph/bo_runtime.mjs","development_mode":"observe","execution_mode":"observe","decision_source":"user","decision":"U1: 应用沿用自身的业务逻辑，VibeLens 用 observe 模式。"},"require_probe_health":True,"require_observation_closure":True,"require_mapping_witnesses":True,"mapping_contract":"mapping.json","acceptance":"acceptance.json","probe_modes":["on","off","fault"],"observations_command":["{python}","-B","tools/observe.py"],"test_commands":[["node","--test","tests/business.test.mjs"],["node","tests/http-boundary.mjs","after"],["{python}","-B","tooling/project_checks.py"]],"timeout_seconds":180})
sync["source_scope"]["require_symbol_classification"]=True
write("sync.json",sync)
write("review/native-node-index.json",{"actions":actions,"api":api,"input_fields":input_fields,"output_fields":output_fields})
write("bo_stategraph/native-bindings.json",{"guards":{m["id"]:{name:spec["decision"].split(":")[-1] for name,spec in m["guards"].items()} for m in d["state_models"]}})
from bo_observer.policy.definition import fingerprint
write("review/policy-fingerprint.json",{"hash":fingerprint(policy)})
print(json.dumps({"valid":True,"nodes":len(model["nodes"]),"edges":len(model["edges"]),"models":list(machines)}))
# Source-first inventory: application helpers remain support mappings, never exclusions.
from bo_observer.sources import scan as source_scan
from implementation_coverage import functional_symbols
app_paths=["src/store.mjs","src/policy.mjs","src/service.mjs","src/http.mjs","src/server.mjs","public/app.js"]
index=source_scan(ROOT,app_paths)
write("review/source-index.json",index)
symbols=functional_symbols(index)
ui_sources={"ui_row_action":"action.rowActionHandler","ui_callback":"bind.uiCallback","ui_navigation":"navigationHandler"}
api["api_upload_actor"]=("POST","/api/files","uploadActor")
model["nodes"].append({"id":"api_upload_actor","kind":"function","label":"POST /api/files · authentication","summary":"Observe the matched upload route including its authentication middleware.","source":{"path":"src/http.mjs","symbol":"createApp.uploadActor"},"capture":{"in":{"method":"string","path":"string"},"out":{"status":"number","duration_ms":"number"}}})
for ident,symbol in ui_sources.items():
    model["nodes"].append({"id":ident,"kind":"function","label":"Browser "+ident.removeprefix("ui_"),"summary":"Observe the real browser callback interval and public element identity.","source":{"path":"public/app.js","symbol":symbol},"capture":{"in":{"action":"string","event_type":"string","target":"string"},"out":{"completed":"boolean"}}})
plan={"schema":"bo-implementation/v1","features":[],"support":{},"excluded":{}}
owned=set()
parameter_fields={"actor":"actor_id","fileId":"file_id","recipientId":"recipient_id","taskId":"task_id","name":"name","bytes":"byte_count","username":"username","password":"password_supplied","token":"token_present","title":"title","body":"body_length","id":"announcement_id","action":"action","active":"active"}
def feature(ident,path,symbol,case):
    sid=path+"::"+symbol
    if sid not in symbols:
        raise ValueError("Missing independently parsed source: "+sid)
    node=next(n for n in model["nodes"] if n["id"]==ident)
    parameters=[]
    for parameter in symbols[sid]["parameters"]:
        name=parameter["name"]
        if name in {"self","cls"}: continue
        if path=="src/http.mjs":
            field="path" if name=="req" else "status" if name=="res" else "method"
            direction="out" if name=="res" else "in"
            reason="HTTP object represented by its selected path/method or real response status; business payload is separately captured at its native operation."
        elif path=="public/app.js":
            field="event_type";direction="in";reason="Native DOM event represented only by event type; form data and credentials are not collected."
        else:
            field=parameter_fields[name];direction="in";reason="Select the actual identity, byte/text length or credential presence from this native argument."
        parameters.append({"source":sid,"name":name,"node":ident,"direction":direction,"field":field,"policy":"derived","reason":reason})
    cases=[{"case":case,"node":ident,"phase":"enter"},{"case":case,"node":ident,"phase":"return"}]
    if "error" in node["capture"].get("out",{}):
        cases.append({"case":case,"node":ident,"phase":"error"})
    plan["features"].append({"id":ident,"label":node["label"],"business_node":ident,"nodes":[ident],"sources":[sid],"parameters":parameters,"cases":cases,"requirements":node.get("requirements",[])})
    owned.add(sid)
for ident,symbol in actions.items():feature(ident,"src/service.mjs",symbol,"workflow")
for ident,(_,_,handler) in api.items():feature(ident,"src/http.mjs","createApp."+handler,"workflow")
for ident,symbol in ui_sources.items():feature(ident,"public/app.js",symbol,"browser")
for sid,record in symbols.items():
    if sid in owned:continue
    filename,symbol=record["path"],record["symbol"]
    if filename=="public/app.js":
        node="ui_callback"
    elif filename=="src/policy.mjs":
        node="policy_facts"
    elif filename=="src/store.mjs":
        node="task_commit"
    elif filename=="src/http.mjs":
        node="api_session"
    elif filename=="src/server.mjs":
        node="login"
    else:
        candidates=[(name,ident) for ident,name in actions.items() if symbol.startswith(name)]
        node=max(candidates,default=("", "policy_facts"))[1]
    plan["support"][sid]={"node":node,"reason":"Project-owned helper statically supports the mapped application feature; no execution is inferred from this source relation."}
write("implementation.json",plan)
model["implementation"]=plan
extra_files=["integrations/bo_observe.mjs","integrations/bo_web_routes.mjs","integrations/bo_client.mjs","bo_stategraph/native-bindings.json"]
model["source_files"] += [name for name in extra_files if name not in model["source_files"]]
envelope["model"]=model
write("bo_stategraph/project.json",envelope)
sync["source_scope"]["exclude"]={
    "tests/**":"Independent scenario and native-reader infrastructure; never used as application entrypoints.",
    "tools/**":"Observer declaration generation, immutable confirmation records and validation orchestration; not production application behavior.",
    "integrations/bo_*.mjs":"Isolated observer-only native transport, UI hooks and local observer assets. /api/bo routes perform no business operations."
}
sync["watch_files"] += extra_files
write("sync.json",sync)
write("review/native-node-index.json",{"actions":actions,"api":api,"ui_sources":ui_sources,"input_fields":input_fields,"output_fields":output_fields})
print(json.dumps({"inventory_features":len(plan["features"]),"support_symbols":len(plan["support"]),"parsed_errors":index["errors"]}))
# Classify observation implementation by exact source; observer routes never become business features.
observer_paths=["integrations/bo_observe.mjs","integrations/bo_web_routes.mjs","integrations/bo_client.mjs","integrations/bo_data_wiring.mjs","integrations/bo_http_wiring.mjs","integrations/bo_export_schema.py"]
observer_index=source_scan(ROOT,observer_paths)
from observation_scope import endpoint_paths
for sid,record in functional_symbols(observer_index).items():
    routes=sorted(endpoint_paths(record))
    item={"category":"observer","reason":"Observer-only capture, local asset delivery, report formatting or acknowledged control. No application authorization or business mutation."}
    if routes:item["routes"]=routes
    plan["excluded"][sid]=item
# Keep genuine user-facing operations in business; API and UI calls remain separate implementation nodes.
for node in model["nodes"]:
    if node["id"] in actions:node["layer"]="business"
extra_business=[
 {"id":"workspace_ui","kind":"action","layer":"business","label":"操作团队空间","summary":"Use file, task and announcement controls through real browser callbacks.","source":{"path":"public/app.js","symbol":"dispatchUi"},"capture":{"in":{},"out":{}}},
 {"id":"read_session","kind":"action","layer":"business","label":"查看登录状态","summary":"Read the actual current login session without exposing its cookie.","source":source("FileService.session"),"capture":{"in":{},"out":{}}},
 {"id":"list_members","kind":"action","layer":"business","label":"查看共享同事","summary":"List public colleagues available for a named share.","source":source("FileService.members"),"capture":{"in":{},"out":{}}}
]
model["nodes"].extend(extra_business)
api_business={"api_session":"read_session","api_members":"list_members","api_files":"list_files","api_tasks":"list_tasks","api_login":"login","api_logout":"logout","api_file":"view_file","api_upload":"upload_file","api_upload_actor":"upload_file","api_share":"share_file","api_revoke":"revoke_share","api_request":"request_download","api_collect":"collect_download","api_board":"read_announcements","api_publish":"publish_announcement","api_edit":"edit_announcement","api_delete":"delete_announcement"}
for f in plan["features"]:
    if f["id"] in api_business:f["business_node"]=api_business[f["id"]]
    if f["id"].startswith("ui_"):f["business_node"]="workspace_ui"
facts_node=next(n for n in model["nodes"] if n["id"]=="policy_facts")
facts_node["capture"]["in"]["invocation_id"]="string"
auth_sid="src/service.mjs::FileService.authorize"
auth_nodes=["policy_facts"]+[n["id"] for n in model["nodes"] if n["id"].startswith("guard_") or n.get("origin")=="policy-definition" and any(n.get("capture",{}).values())]
auth_parameters=[
 {"source":auth_sid,"name":"operation","node":"policy_facts","direction":"in","field":"operation","policy":"value"},
 {"source":auth_sid,"name":"facts","node":"policy_facts","direction":"out","field":"member","policy":"derived","reason":"Select only declared scalar facts from the actual supplied fact object. Complete typed facts remain in the node capture and concept fact bindings."},
 {"source":auth_sid,"name":"context","node":"policy_facts","direction":"in","field":"invocation_id","policy":"derived","reason":"Select the actual enclosing native invocation identity, excluding callback objects."}
]
plan["features"].append({"id":"native_authorization","label":"Shared native authorization","business_node":"request_download","nodes":auth_nodes,"sources":[auth_sid],"parameters":auth_parameters,"cases":[{"case":"workflow","node":nid,"phase":"read" if nid=="policy_facts" else "decision"} for nid in auth_nodes],"requirements":["R_AUTH","R_FILES","R_DOWNLOAD","R_BOARD"]})
owned.add(auth_sid);plan["support"].pop(auth_sid,None)
request_feature=next(f for f in plan["features"] if f["id"]=="request_download")
request_feature["nodes"].append("task_commit")
request_feature["cases"] += [{"case":"workflow","node":"task_commit","phase":phase} for phase in ["enter","return","error"]]
for state_model in d["state_models"]:
    ident=state_model["id"]; state_nodes=[n for n in model["nodes"] if n.get("state_model_id")==ident]
    for n in state_nodes:
        n["capture"]["in"]={"instance_id":"string","invocation_id":"string"}
        n["capture"]["out"].update({"event_name":"scalar","before":"scalar"})
    anchor=next(n for n in state_nodes if n["value"]==state_model["initial"])["id"]
    sid="src/service.mjs::FileService.state"
    fields={"model":("out","state_model_id"),"id":("in","instance_id"),"row":("out","state"),"event":("out","event_name"),"context":("in","invocation_id"),"before":("out","before")}
    params=[{"source":sid,"name":name,"node":anchor,"direction":direction,"field":field,"policy":"derived","reason":"Select the actual native model, instance, state, event or enclosing operation identity at this observed row boundary."} for name,(direction,field) in fields.items()]
    plan["features"].append({"id":"state_"+ident,"label":state_model["label"],"business_node":{"grant":"share_file","download_task":"request_download","announcement":"publish_announcement","session":"login"}[ident],"nodes":[n["id"] for n in state_nodes],"sources":[sid],"parameters":params,"cases":[{"case":"workflow","node":n["id"],"phase":"read" if n["value"]==state_model["initial"] else "change"} for n in state_nodes]})
plan["support"].pop("src/service.mjs::FileService.state",None)
model["implementation"]=plan
write("implementation.json",plan)
envelope["model"]=model
write("bo_stategraph/project.json",envelope)
sync["source_scope"]["exclude"]={"tests/business.test.mjs":"Independent native and HTTP test scenarios.","tests/observe.mjs":"Independent scenario orchestration; its native readers are separately mapped and documented.","tooling/**":"Observer declaration generation, original-answer evidence and verification orchestration."}
sync["source_scope"]["roots"]=[".","tests/native_reader.mjs"]
if not any(item["path"]=="initial-node-app" for item in sync["source_scope"]["prune"]):
    sync["source_scope"]["prune"].append({"path":"initial-node-app","category":"artifact","reason":"Immutable coding baseline, candidate snapshots and verification receipts; never application implementation."})
sync["code_files"]=app_paths+observer_paths
sync["code_files"].append("tests/native_reader.mjs")
reader_index=source_scan(ROOT,["tests/native_reader.mjs"])
for sid in functional_symbols(reader_index):
    plan["support"][sid]={"node":"request_download","reason":"Independent verification and native SDK/SQLite reading infrastructure; source association does not claim application execution."}
write("implementation.json",plan)
model["implementation"]=plan
sync["observations_command"]=["{python}","-B","tooling/observe.py"]
write("sync.json",sync)
print(json.dumps({"complete_features":len(plan["features"]),"observer_symbols":len(plan["excluded"])}))
# Qualify each native HTTP entry hook by its actual handler, method and literal route.
registrations=[]
for ident,(method,route,handler) in api.items():
    node=next(n for n in model["nodes"] if n["id"]==ident)
    node["layer"]="function" if ident=="api_upload_actor" else "api"
    if ident=="api_upload_actor":
        node["label"]="Upload authentication middleware"
        node["summary"]="Observe this entered native upload-authentication request scope; it is separate from the outer HTTP request boundary."
    node["capture"]["out"]["completed"]="boolean"
    registrations.append({"node":ident,"source":copy.deepcopy(node["source"]),"match":{"name":ident,"attributes":{"http.request.method":method,"http.route":route}},"capture":{"in":{"method":"http.request.method","path":"http.target"},"out":{"status":"http.response.status_code","completed":"http.response.completed","duration_ms":"duration_ms"}}})
write("bo_stategraph/telemetry.json",{"protocol":"bo-telemetry/v1","backend":"opentelemetry","registrations":registrations})
for name in ["bo_stategraph/telemetry.json","review/native-node-index.json"]:
    if name not in model["source_files"]:model["source_files"].append(name)
from code_structure import enrich
for state_model in d["state_models"]:
    ident = state_model["id"]
    model["nodes"].append({"id":"state_value:"+ident,"kind":"function","layer":"function","label":"Read native "+ident+" state","summary":"Observe the actual committed native row state and its enclosing invocation.","source":source("FileService.state"),"capture":{"in":{"instance_id":"string","invocation_id":"string"},"out":{"model_ref":"string","state":"string","revision":"number","event_name":"string",**{k:v["type"] for k,v in state_model["context"].items()}}}})
    feature_plan=next(f for f in plan["features"] if f["id"]=="state_"+ident)
    feature_plan["nodes"].append("state_value:"+ident)
    feature_plan["cases"].append({"case":"workflow","node":"state_value:"+ident,"phase":"change"})
write("implementation.json",plan)
model["implementation"]=plan
for name in ["tests/native_reader.mjs"]:
    if name not in model["source_files"]:model["source_files"].append(name)
full_index=source_scan(ROOT,app_paths+observer_paths)
model=enrich(model,full_index)
envelope["model"]=model
write("bo_stategraph/project.json",envelope)
sync["stategraph"]["decision"]=envelope["selection"]["answer"]
for name in ["bo_stategraph/bo_runtime.mjs","bo_stategraph/bo_capture.mjs","bo_stategraph/bo_http.mjs","tooling/observe.py","tooling/project_checks.py","tests/observe.mjs","tests/native_reader.mjs","tests/http-boundary.mjs","bo_stategraph/telemetry.json","review/native-node-index.json"]:
    if name not in sync["watch_files"]:sync["watch_files"].append(name)
for name in ["tests/concurrency.test.mjs","tooling/build_model.py"]:
    if name not in sync["watch_files"]:sync["watch_files"].append(name)
concurrency_command=["node","--test","tests/concurrency.test.mjs"]
if concurrency_command not in sync["test_commands"]:sync["test_commands"].append(concurrency_command)
write("sync.json",sync)
print(json.dumps({"enriched_nodes":len(model["nodes"]),"qualified_api_entries":len(registrations)}))
subprocess.run([sys.executable, "-B", str(ROOT / "tooling/bind_concepts.py")], check=True)
subprocess.run([sys.executable, "-B", str(ROOT / "tooling/bind_behavior.py")], check=True)
subprocess.run([sys.executable, "-B", str(ROOT / "tooling/configure_database.py")], check=True)
# Concept and behavior bindings add concrete source relationships. Enrich the
# final authored graph so the static slice matches that complete selection.
envelope=read("bo_stategraph/project.json")
for name in [*sync["code_files"],"src/schema.sql","bo_stategraph/databases.json","bo_stategraph/bo_runtime.mjs","bo_stategraph/bo_capture.mjs","bo_stategraph/bo_http.mjs"]:
    if name not in envelope["model"]["source_files"]:envelope["model"]["source_files"].append(name)
envelope["model"]=enrich(envelope["model"],source_scan(ROOT,app_paths+observer_paths+["tests/native_reader.mjs"]))
envelope["model"]["source_files"]=sorted(set(envelope["model"]["source_files"]))
write("bo_stategraph/project.json",envelope)
