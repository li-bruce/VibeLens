import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile } from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { Store, TEST_PASSWORD } from '../src/store.mjs';
import { FileService } from '../src/service.mjs';
import { createApp } from '../src/http.mjs';

/** Exercise real HTTP and native storage against synthetic project-local files. */
test('confirmed team-file business rules', async t => {
  const root = await mkdtemp(path.resolve('review/runtime/business-'));
  const store = new Store(path.join(root, 'db', 'application.sqlite'));
  const service = new FileService(store, root);
  service.workerDelay = 60000;
  const server = createApp(service, path.resolve('public')).listen(0, '127.0.0.1');
  await new Promise(resolve => server.once('listening', resolve));
  const url = 'http://127.0.0.1:' + server.address().port;
  const cookies = {};
  const payload = Buffer.from('Synthetic team file. Not a real user document.\n', 'utf8');
  let fileId, taskId, announcementId;
  const call = async (who, route, method = 'GET', body, extra = {}) => {
    const headers = { ...(cookies[who] ? { Cookie: cookies[who] } : {}), ...extra };
    if (body && !Buffer.isBuffer(body)) headers['Content-Type'] = 'application/json';
    const response = await fetch(url + route, { method, headers, body: body === undefined ? undefined : Buffer.isBuffer(body) ? body : JSON.stringify(body) });
    const cookie = response.headers.get('set-cookie'); if (cookie) cookies[who] = cookie.split(';')[0];
    return response;
  };
  const login = async who => {
    const response = await call(who, '/api/auth/login', 'POST', { username: who, password: TEST_PASSWORD });
    assert.equal(response.status, 200); return (await response.json()).user;
  };
  try {
    await t.test('real authentication rejects anonymous and incorrect passwords', async () => {
      assert.equal((await call('anonymous', '/api/files')).status, 401);
      assert.equal((await call('anonymous', '/api/auth/login', 'POST', { username: 'alice', password: 'incorrect' })).status, 401);
      assert.equal((await login('alice')).editor, false);
      assert.equal((await login('bob')).editor, false);
      assert.equal((await login('editor')).editor, true);
      assert.equal(store.get('SELECT count(*) AS total FROM users').total, 3);
    });
    await t.test('upload persists exact file bytes and SQLite metadata', async () => {
      const response = await call('alice', '/api/files?name=' + encodeURIComponent('团队样例.txt'), 'POST', payload, { 'Content-Type': 'application/octet-stream' });
      assert.equal(response.status, 201); const body = await response.json(); fileId = body.id;
      assert.equal(body.size, payload.length);
      assert.equal(body.sha256, createHash('sha256').update(payload).digest('hex'));
      const native = store.get('SELECT * FROM files WHERE id=?', fileId);
      assert.deepEqual(await readFile(native.storage_path), payload);
      assert.equal((await readFile(path.join(root, 'db/application.sqlite'))).subarray(0, 15).toString(), 'SQLite format 3');
    });
    await t.test('unrelated colleagues including an announcement editor cannot see the file', async () => {
      assert.equal((await (await call('alice', '/api/files')).json()).files.length, 1);
      assert.equal((await (await call('bob', '/api/files')).json()).files.length, 0);
      assert.equal((await (await call('editor', '/api/files')).json()).files.length, 0);
      assert.equal((await call('editor', '/api/files/' + fileId)).status, 403);
      assert.equal((await call('editor', '/api/tasks', 'POST', { file_id: fileId })).status, 403);
    });
    await t.test('uploader may grant access; recipients cannot re-share or revoke', async () => {
      assert.equal((await call('alice', '/api/files/' + fileId + '/shares', 'POST', { recipient_id: 'bob' })).status, 200);
      assert.equal((await (await call('bob', '/api/files')).json()).files.length, 1);
      assert.equal((await call('bob', '/api/files/' + fileId + '/shares', 'POST', { recipient_id: 'editor' })).status, 403);
      assert.equal((await call('bob', '/api/files/' + fileId + '/shares/bob', 'DELETE')).status, 403);
      assert.equal((await call('editor', '/api/files/' + fileId + '/shares', 'POST', { recipient_id: 'editor' })).status, 403);
    });
    await t.test('task admission commits its own submission authorization', async () => {
      const response = await call('bob', '/api/tasks', 'POST', { file_id: fileId });
      assert.equal(response.status, 202); taskId = (await response.json()).task_id;
      assert.equal(store.get('SELECT status FROM tasks WHERE id=?', taskId).status, 'queued');
      assert.equal(store.get('SELECT authorized_at_submission FROM tasks WHERE id=?', taskId).authorized_at_submission, 1);
      assert.equal((await call('bob', '/api/tasks/' + taskId + '/download')).status, 403);
    });
    await t.test('revocation removes visibility and denies new tasks without deleting the admitted task', async () => {
      assert.equal((await call('alice', '/api/files/' + fileId + '/shares/bob', 'DELETE')).status, 200);
      assert.equal((await (await call('bob', '/api/files')).json()).files.length, 0);
      assert.equal((await call('bob', '/api/tasks', 'POST', { file_id: fileId })).status, 403);
      assert.equal(store.get('SELECT count(*) AS total FROM tasks').total, 1);
      assert.equal((await (await call('bob', '/api/tasks')).json()).tasks[0].id, taskId);
    });
    await t.test('actual background copying finishes after share revocation', async () => {
      clearTimeout(service.workerTimer); service.workerBusy = false;
      await service.drainWorker();
      const row = store.get('SELECT * FROM tasks WHERE id=?', taskId);
      assert.equal(row.status, 'ready'); assert.equal(row.revision, 3);
      assert.deepEqual(await readFile(row.prepared_path), payload);
      assert.equal(row.sha256, createHash('sha256').update(payload).digest('hex'));
    });
    await t.test('original requester may repeatedly collect; other accounts are denied', async () => {
      for (let index = 0; index < 2; index++) {
        const response = await call('bob', '/api/tasks/' + taskId + '/download');
        assert.equal(response.status, 200); assert.deepEqual(Buffer.from(await response.arrayBuffer()), payload);
      }
      assert.equal((await call('editor', '/api/tasks/' + taskId + '/download')).status, 403);
      assert.equal((await call('alice', '/api/tasks/' + taskId + '/download')).status, 403);
      assert.equal(store.get('SELECT status,revision FROM tasks WHERE id=?', taskId).status, 'ready');
    });
    await t.test('announcement readership requires login and publishing requires editor role', async () => {
      assert.equal((await call('anonymous', '/api/announcements')).status, 401);
      assert.equal((await call('alice', '/api/announcements', 'POST', { title: 'Rejected', body: 'No editor role.' })).status, 403);
      const response = await call('editor', '/api/announcements', 'POST', { title: '团队测试公告', body: 'Synthetic local trial announcement.' });
      assert.equal(response.status, 201); announcementId = (await response.json()).id;
      assert.equal((await (await call('bob', '/api/announcements')).json()).announcements.length, 1);
    });
    await t.test('editor may edit own announcement but cannot mutate another author fixture', async () => {
      assert.equal((await call('editor', '/api/announcements/' + announcementId, 'PUT', { title: 'Updated', body: 'Updated native content.' })).status, 200);
      const now = new Date().toISOString();
      store.run("INSERT INTO announcements VALUES('historical-fixture','alice','Historical fixture','Synthetic setup for author-boundary rejection.','published',?,?,1)", now, now);
      assert.equal((await call('editor', '/api/announcements/historical-fixture', 'PUT', { title: 'No', body: 'No' })).status, 403);
      assert.equal((await call('editor', '/api/announcements/historical-fixture', 'DELETE')).status, 403);
      assert.equal(store.get("SELECT revision FROM announcements WHERE id='historical-fixture'").revision, 1);
      assert.equal((await call('alice', '/api/announcements/' + announcementId, 'DELETE')).status, 403);
      assert.equal((await call('editor', '/api/announcements/' + announcementId, 'DELETE')).status, 200);
      assert.equal(store.get('SELECT status FROM announcements WHERE id=?', announcementId).status, 'deleted');
    });
    await t.test('framework malformed JSON is an actual HTTP 400 and cross-origin mutation is rejected', async () => {
      const malformed = await fetch(url + '/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{broken' });
      assert.equal(malformed.status, 400);
      assert.equal((await call('editor', '/api/announcements', 'POST', { title: 'No', body: 'No' }, { Origin: 'https://unrelated.invalid' })).status, 403);
    });
    await t.test('real logout invalidates the old cookie', async () => {
      const oldCookie = cookies.bob;
      assert.equal((await call('bob', '/api/auth/logout', 'POST')).status, 204);
      const response = await fetch(url + '/api/tasks', { headers: { Cookie: oldCookie } });
      assert.equal(response.status, 401);
      assert.equal(store.get("SELECT count(*) AS total FROM sessions WHERE user_id='bob' AND status='active'").total, 0);
    });
  } finally {
    await service.stop(); await new Promise(resolve => server.close(resolve)); store.close();
  }
});
