"""Correlate retained request timings with actual viewer calls and lock waits."""
import json
from pathlib import Path
import sys
import math
import statistics

RUN=Path(sys.argv[1])
def lines(name):
    path=RUN/name
    if not path.exists():return []
    result=[]
    for line in path.read_text(encoding='utf-8').splitlines():
        try:result.append(json.loads(line))
        except json.JSONDecodeError:pass
    return result
native=lines('native-fetch.jsonl');viewer=lines('viewer-calls.jsonl');network=lines('browser-network.jsonl')
failures=[item for item in native if item['event']=='failure']
active={};calls=[];waiting={};waits=[];held={};holds=[]
for item in viewer:
    key=(item.get('thread'),item.get('frame'))
    if item['event']=='call':active[key]=item
    elif item['event']=='return' and key in active:
        start=active.pop(key);calls.append({**start,'ended_ms':item['wall_ms'],'elapsed_ms':item['wall_ms']-start['wall_ms']})
        if key in held:
            acquired=held.pop(key);holds.append({**acquired,'released_ms':item['wall_ms'],'held_ms':item['wall_ms']-acquired['wall_ms'],'release_boundary':'function_return'})
    elif item['event']=='lock_request':waiting[key]=item
    elif item['event']=='lock_acquired' and key in waiting:
        start=waiting.pop(key);waits.append({**start,'acquired_ms':item['wall_ms'],'wait_ms':item['wall_ms']-start['wall_ms']})
        held[key]=item
    elif item['event']=='lock_released' and key in held:
        acquired=held.pop(key);holds.append({**acquired,'released_ms':item['wall_ms'],'held_ms':item['wall_ms']-acquired['wall_ms'],'release_boundary':'first_line_after_with'})
for failure in failures:
    start=failure['wall_ms']-failure['elapsed_ms'];end=failure['wall_ms']
    failure['overlapping_viewer_calls']=[item for item in calls if item['wall_ms']<=end and item['ended_ms']>=start and item['function'] in {'GraphSession.view','CodeGraph.refresh','CodeGraph.view'}]
    failure['overlapping_lock_waits']=[item for item in waits if item['wall_ms']<=end and item['acquired_ms']>=start and item['wait_ms']>=10]
    failure['same_observation_calls']=[item for item in calls if item.get('observation_id')==failure.get('id')]
    failure['same_observation_lock_waits']=[item for item in waits if item.get('observation_id')==failure.get('id')]
    failure['temporal_event_calls']=[item for item in calls if item['wall_ms']<=end and item['ended_ms']>=start and item['function'] in {'GraphSession.event','GraphSession.snapshot','GraphSession.binding'}]
    failure['overlapping_lock_holds']=[item for item in holds if item['wall_ms']<=end and item['released_ms']>=start]
groups={}
for item in calls:
    source=item.get('source_file','').replace('\\','/').split('/scripts/')[-1]
    groups.setdefault(source+'::'+item['function'],[]).append(item['elapsed_ms'])
stats={}
for label,values in groups.items():
    values.sort();stats[label]={'calls':len(values),'median_ms':statistics.median(values),'p95_ms':values[max(0,math.ceil(len(values)*.95)-1)],'max_ms':max(values),'total_ms':sum(values)}
result={'source':'actual-process-local-audits','original_recording_request_unknown':True,'configuration':{'managed_timeout_ms':1000,'attempts':2,'changed':False},'function_statistics':stats,'failures':failures,'slow_viewer_network':[item for item in network if item['event']=='finished' and item['path']=='/api/view' and item.get('elapsed_ms',0)>=500],'longest_lock_waits':sorted(waits,key=lambda item:item['wait_ms'],reverse=True)[:15],'longest_refresh_calls':sorted([item for item in calls if item['function']=='CodeGraph.refresh'],key=lambda item:item['elapsed_ms'],reverse=True)[:15],'limits':['The original recording retained aggregate TimeoutError health, not a per-request audit.','The request/lock audit run is a separate reproduction with distinct process and recording identities.','Instrumentation adds overhead; timings are not an isolated performance benchmark.','See lifecycle and host-load samples for the reported regression context; resource contention is not excluded.']}
result['longest_lock_holds']=sorted(holds,key=lambda item:item['held_ms'],reverse=True)[:20]
result['scan_triggers']=[{'function':item['function'],'source_file':item.get('source_file'),'request_path':item.get('request_path'),'wall_ms':item['wall_ms'],'elapsed_ms':item['elapsed_ms']} for item in calls if item['function'] in {'scan','CodeGraph.refresh'}]
(RUN/'transport-analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'native_failed_requests':len(failures),'failed_nodes':sorted({item.get('node','snapshot-or-control') for item in failures}),'slow_viewer_requests':len(result['slow_viewer_network']),'max_lock_wait_ms':max([item['wait_ms'] for item in waits],default=None),'max_refresh_ms':max([item['elapsed_ms'] for item in calls if item['function']=='CodeGraph.refresh'],default=None)}))
