import { spawn } from 'node:child_process';
import { openSync, mkdirSync, existsSync, readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import net from 'node:net';
import { fileURLToPath } from 'node:url';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const skill=process.env.VIBELENS_SKILL || path.resolve(root,'../node-migration-final-skills/vibelens');
const python=process.env.VIBELENS_PYTHON || path.resolve(root,'../../../.venv/Scripts/python.exe');
const appPort=Number(process.env.PORT || 8925),graphPort=Number(process.env.VIBELENS_PORT || 8926);
const runtime=path.join(root,'review/runtime');mkdirSync(runtime,{recursive:true});
const children=[];
const env={...process.env,PYTHONDONTWRITEBYTECODE:'1',PYTHONIOENCODING:'utf-8',VIBELENS_SKILL:skill,TEAM_FILES_SQLITE_URL:'sqlite:///var/db/application.sqlite'};
/** Check a selected loopback port before starting any process; never stop another listener. */
function occupied(port){return new Promise(resolve=>{const socket=net.connect(port,'127.0.0.1');socket.once('connect',()=>{socket.destroy();resolve(true);});socket.once('error',()=>resolve(false));});}
/** Start and track only this launcher's own hidden child process. */
function start(command,args,label){
  const child=spawn(command,args,{cwd:root,env,windowsHide:true,stdio:['ignore',openSync(path.join(runtime,label+'.stdout.log'),'a'),openSync(path.join(runtime,label+'.stderr.log'),'a')]});
  children.push(child);child.on('error',error=>console.error(label+': '+error.message));return child;
}
/** Wait for a real HTTP readiness response, bounded by the owned process lifetime. */
async function ready(url,child){
  for(let attempt=0;attempt<150;attempt++){
    if(child.exitCode!==null)throw new Error('Process exited before HTTP readiness: '+child.exitCode);
    try{const response=await fetch(url,{signal:AbortSignal.timeout(1000)});if(response.ok)return;}catch{}
    await new Promise(resolve=>setTimeout(resolve,200));
  }
  throw new Error('Timed out waiting for '+url);
}
/** Terminate only child handles created by this invocation. */
function stop(){for(const child of children)if(child.exitCode===null)child.kill();}
process.once('SIGINT',()=>{stop();process.exit(0);});process.once('SIGTERM',()=>{stop();process.exit(0);});
process.once('exit',stop);
try{
  if(await occupied(appPort)||await occupied(graphPort))throw new Error('A requested port is already occupied. Stop its known owner or select other PORT/VIBELENS_PORT values.');
  if(!existsSync(python))throw new Error('Set VIBELENS_PYTHON to the supplied Python environment.');
  const graph=start(python,['-B',path.join(skill,'scripts/bo.py'),'serve','--root',root,'--port',String(graphPort),'--origin','http://127.0.0.1:'+appPort],'viewer');
  await ready('http://127.0.0.1:'+graphPort+'/graph',graph);
  const settings=JSON.parse(readFileSync(path.join(root,'.stategraph/collector.json'),'utf8'));
  if(settings.endpoint!=='http://127.0.0.1:'+graphPort)throw new Error('Collector settings do not match this launcher.');
  env.VIBELENS_ENABLED='1';env.PORT=String(appPort);
  const app=start(process.execPath,['src/server.mjs'],'app');
  await ready('http://127.0.0.1:'+appPort,app);
  writeFileSync(path.join(root,'review/app.pid'),String(app.pid));writeFileSync(path.join(root,'review/viewer.pid'),String(graph.pid));
  writeFileSync(path.join(root,'review/runtime/dev-processes.json'),JSON.stringify({launcher:process.pid,app:app.pid,viewer:graph.pid,app_url:'http://127.0.0.1:'+appPort,graph_url:'http://127.0.0.1:'+graphPort+'/graph',build_id:settings.build_id},null,2));
  console.log('Application: http://127.0.0.1:'+appPort);
  console.log('VibeLens: http://127.0.0.1:'+graphPort+'/graph');
  console.log('Test accounts: alice, bob, editor / DemoPass!2026');
  console.log('Press Ctrl+C to stop only the two processes started by this command.');
  for(const child of children)child.on('exit',(code)=>{if(code!==0){console.error('Owned child exited: '+code);stop();process.exitCode=1;}});
}catch(error){stop();console.error(error.message);process.exitCode=1;}
