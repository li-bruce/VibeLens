"""Add the user's explicit authentication scope without rewriting confirmed peers."""
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
path = root / "discovery.json"
d = json.loads(path.read_text(encoding="utf-8"))
if not any(n["id"] == "authentication" for n in d["networks"]):
    d["sources"].append({"id":"A_AUTH_1","kind":"assistant","text":"登录补充按你的明确要求处理：凭据校验成功后建立会话，退出后该会话失效；密码和会话令牌不会进入观察数据。登录 -> 会话有效 -> 退出 -> 会话失效。文件权限仍取决于上传者或当前共享关系，公告编辑员身份只影响公告操作。","locator":"Current assistant commentary: displayed authentication diagram; U4 already directly authorizes this exact behavior"})
    d["networks"].append({"id":"authentication","title":"登录与退出","actors":["测试同事"],"trigger":"提交用户名密码或退出当前会话","outcome":"正确凭据建立会话；退出使当前会话失效；三个测试账号中一个为公告编辑员。","nodes":[{"id":"login","kind":"action","label":"登录","meaning":"Validate the submitted username and password and create a real session only when valid. Never observe passwords or session tokens.","source_refs":["U4"]},{"id":"logout","kind":"action","label":"退出登录","meaning":"Invalidate the current authenticated session.","source_refs":["U4"]}],"edges":[{"id":"auth-login-logout","from":"login","to":"logout","relation":"flow","label":"退出当前会话","source_refs":["U4"]}]})
    d["objects"].append({"id":"session","identity":{"trace_id":"string"},"fields":{"user_id":"string","status":"string"},"source_refs":["U4"]})
    d["objects"].append({"id":"login_attempt","identity":{"attempt_id":"string"},"fields":{"credentials_valid":"boolean"},"source_refs":["U4"]})
    d["facts"].append({"id":"credentials-valid","object":"login_attempt","field":"credentials_valid","type":"boolean","read_basis":{"timing":"after_native_password_verification","scope":"current_login_attempt","version":"attempt_id"},"source_refs":["U4"]})
    d["policy"]["inputs"]["credentials_valid"]="boolean"
    d["policy"]["nodes"].append({"id":"credentials_valid","op":"input","name":"credentials_valid","source_refs":["U4"]})
    d["policy"]["operations"] += [{"id":"login","root":"credentials_valid","business_nodes":["login"],"source_refs":["U4"]},{"id":"logout","root":"member","business_nodes":["logout"],"source_refs":["U4"]}]
    d["state_models"].append({"id":"session","label":"登录会话","subject":{"object":"session","identity":["trace_id"]},"states":["absent","active","ended"],"initial":"absent","events":{"login":{"payload":{}},"logout":{"payload":{}}},"context":{"user_id":{"type":"string"}},"guards":{"valid_credentials":{"decision":"policy:operation:login","source_refs":["U4"]},"authenticated":{"decision":"policy:operation:logout","source_refs":["U4"]}},"effects":{},"transitions":[{"id":"login","source":"absent","dest":"active","trigger":"login","conditions":["valid_credentials"],"source_refs":["U4"]},{"id":"logout","source":"active","dest":"ended","trigger":"logout","conditions":["authenticated"],"source_refs":["U4"]}],"source_refs":["U4"]})
    d["applicability"] += [{"operation":op,"state":{"status":"applicable","models":["session"],"mode":"change"},"rules":{"status":"applicable","operations":[op]},"source_refs":["U4"]} for op in ["login","logout"]]
    d["crosslinks"] += [{"id":"auth-"+op+"-event","from":op,"to":"event:session:"+op,"relation":"action_requests_event","source_refs":["U4"]} for op in ["login","logout"]]
    d["crosslinks"] += [{"id":"auth-"+op+"-guard","from":"transition:session:"+op,"to":"policy:operation:"+op,"relation":"transition_guarded_by","source_refs":["U4"]} for op in ["login","logout"]]
    d["crosslinks"].append({"id":"read-credentials-valid","from":"policy:credentials_valid","to":"fact:credentials-valid","relation":"decision_reads_fact","source_refs":["U4"]})
    d["construction"]["obligations"] += [{"id":"O_AUTH_NETWORK","kind":"model","target_ref":"business-network:authentication","target_kind":"business_network","meaning":"Real username/password login and logout, without registration or account management.","source_refs":["U4"]},{"id":"O_AUTH_SESSION","kind":"state_owner","object_ref":"object:session","meaning":"Each actual session retains its independent nonsecret trace identity and active/ended state.","source_refs":["U4"]}]
    d["expectations"].append({"id":"logout-invalidates-session","scope":["login","logout","state-model:session"],"given":{"valid_credentials":True},"when":{"operations":["login","logout"]},"then":[{"path":["session","status"],"equals":"ended"}],"source_refs":["U4"]})
    path.write_text(json.dumps(d,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"valid":True,"state_models":[m["id"] for m in d["state_models"]]}))
