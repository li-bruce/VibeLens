"""Exercise real local pages in a fresh, independently launched browser."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time
import sys
import traceback
import urllib.request
from playwright.sync_api import sync_playwright, expect, TimeoutError as PlaywrightTimeout

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'review/runtime'
TRACE=Path(os.environ.get('BO_UNIFIED_RUN',str(OUT)))
TRIAL=json.loads((OUT/'browser-trials.json').read_text(encoding='utf-8'))
GRAPH='http://127.0.0.1:8926'
RESULT={'source':'independent-python-playwright','build_id':TRIAL['build_id'],'checks':{},'recordings':[],'console':[],'idle_waits':[],'stop_receipts':[]}
NATIVE_ONLY='--native-only' in sys.argv
FIRST_RECORDING_ONLY='--first-recording-only' in sys.argv
if FIRST_RECORDING_ONLY:RESULT['scope']='first-recording-only'
RESULT['recording_validation']='not_run' if NATIVE_ONLY else 'required'

def save(name,value):
    content=json.dumps(value,ensure_ascii=False,indent=2)+'\n'
    (OUT/name).write_text(content,encoding='utf-8')
    if TRACE!=OUT:(TRACE/name).write_text(content,encoding='utf-8')

def http(url):
    with urllib.request.urlopen(url,timeout=20) as response:return json.load(response)

def until(read,predicate,description,seconds=35):
    deadline=time.monotonic()+seconds
    while time.monotonic()<deadline:
        value=read()
        if predicate(value):return value
        time.sleep(.15)
    raise AssertionError(description)

def page_ready(page,url):
    page.goto(url,wait_until='domcontentloaded')
    # The real acknowledged producer polls every 100 ms. It intentionally
    # prevents networkidle; use visible DOM and actual control acknowledgments.
    try:page.wait_for_load_state('networkidle',timeout=900)
    except PlaywrightTimeout:pass
    page.locator('#login-form').wait_for(state='visible')

def login(page,username):
    page.bring_to_front()
    if page.get_by_role('button',name='退出',exact=True).is_visible():
        page.get_by_role('button',name='退出',exact=True).click()
    page.get_by_role('textbox',name='用户名',exact=True).fill(username)
    page.get_by_role('textbox',name='密码',exact=True).fill('DemoPass!2026')
    page.get_by_role('button',name='登录',exact=True).click()
    expect(page.locator('#workspace')).to_be_visible()
    page.get_by_role('button',name='▤ 团队文件',exact=True).click()
    expect(page.get_by_role('heading',name='团队文件',exact=True)).to_be_visible()

def row(page,filename):return page.get_by_role('article').filter(has_text=filename)

def native_page_state():
    """Retain the actual selected page without changing its business activity."""
    try:
        return {'url':page.url,'visible_view':next((name for name in ['files','tasks','board'] if page.locator('#'+name+'-view').is_visible()),None),'document_hidden':page.evaluate('document.hidden')}
    except Exception as error:return {'read_error':type(error).__name__}

def native_idle(stage):
    """Keep the original pending-zero gate and retain every health sample."""
    started=time.monotonic()
    summary={'stage':stage,'started_ms':time.time_ns()/1e6,'samples':0,'first_health':None,'last_health':None}
    def sample():
        health=http(TRIAL['modes']['on']['url']+'/api/bo/health')
        entry={'wall_ms':time.time_ns()/1e6,'stage':stage,'health':health}
        with (TRACE/'native-idle.jsonl').open('a',encoding='utf-8') as stream:stream.write(json.dumps(entry,ensure_ascii=False)+'\n')
        summary['samples']+=1
        if summary['first_health'] is None:summary['first_health']=health
        summary['last_health']=health
        return health
    try:
        health=until(sample,lambda h:h['pending']==0,'Native queue did not settle')
        summary['result']='pending_zero'
        return health
    except Exception as error:
        summary.update(result='failed',error=str(error),traceback=traceback.format_exc())
        raise
    finally:
        summary.update(ended_ms=time.time_ns()/1e6,elapsed_ms=(time.monotonic()-started)*1000,page=native_page_state())
        RESULT['idle_waits'].append(summary)
        save('native-idle-summary.json',RESULT['idle_waits'])

def start_record(graph):
    if not graph.url.startswith(GRAPH+'/graph'):
        graph.goto(GRAPH+'/graph',wait_until='domcontentloaded')
    if graph.get_by_role('button',name='返回实时观察',exact=True).is_visible():
        graph.get_by_role('button',name='返回实时观察',exact=True).click()
    start=graph.get_by_role('button',name='开始记录',exact=True)
    expect(start).to_be_enabled(timeout=35000)
    before=native_idle('before-start-'+str(len(RESULT['recordings'])+1))['enqueued']
    start.click()
    expect(graph.get_by_role('button',name='结束记录',exact=True)).to_be_enabled(timeout=35000)
    active=until(lambda:http(GRAPH+'/api/recordings'),lambda d:d.get('active') is not None,'No active recording')['active']
    assert active['build_id']==TRIAL['build_id']
    assert native_idle('after-start-'+active['id'])['enqueued']==before,'Viewer start created native business events'
    print(json.dumps({'recording_started':active['id'],'viewer_display':'open_during_native_operations'}),flush=True)
    return active['id']

def click_stop(graph,identity,boundary):
    """Retain the actual stop response without issuing a second control request."""
    started=time.monotonic()
    with graph.expect_response(lambda response:response.url==GRAPH+'/api/recordings/stop' and response.request.method=='POST') as stopped:
        graph.get_by_role('button',name='结束记录',exact=True).click()
    response=stopped.value
    meta={'recording_id':identity,'boundary':boundary,'url':response.url,'status':response.status,'content_type':response.headers.get('content-type'),'response_at_ms':time.time_ns()/1e6,'elapsed_ms':(time.monotonic()-started)*1000}
    try:
        body=response.body();name='stop-receipt-'+identity+'-'+boundary+'.body'
        (OUT/name).write_bytes(body)
        if TRACE!=OUT:(TRACE/name).write_bytes(body)
        meta.update(body_file=name,body_bytes=len(body),body_sha256=hashlib.sha256(body).hexdigest())
    except Exception as error:
        meta.update(body_read_error=type(error).__name__)
        raise
    finally:
        RESULT['stop_receipts'].append(meta)
        save('browser-stop-receipts.json',RESULT['stop_receipts'])

def stop_record(graph,identity):
    native_idle('before-stop-'+identity)
    if not graph.url.startswith(GRAPH+'/graph'):graph.goto(GRAPH+'/graph',wait_until='domcontentloaded')
    expect(graph.get_by_role('button',name='结束记录',exact=True)).to_be_enabled(timeout=35000)
    before=http(TRIAL['modes']['on']['url']+'/api/bo/health')['enqueued']
    click_stop(graph,identity,'normal')
    until(lambda:http(GRAPH+'/api/recordings'),lambda d:d['active'] is None,'Recording stop did not settle')
    record=http(GRAPH+'/api/recordings/'+identity)
    save('independent-recording-'+identity+'.json',record)
    assert http(TRIAL['modes']['on']['url']+'/api/bo/health')['enqueued']==before,'Viewer stop created native business events'
    RESULT['recordings'].append({'id':identity,'status':record['status'],'events':len(record['events']),'gaps':record['gaps'],'settlement':record['producer_settlement']})
    assert record['status']=='stopped',record['gaps']
    assert record['gaps']==[],record['gaps']
    assert record['producer_settlement']['flushed'] is True
    return record

def request_task(page,filename):
    with page.expect_response(lambda response:response.url.endswith('/api/tasks') and response.request.method=='POST') as submitted:
        row(page,filename).get_by_role('button',name='准备下载',exact=True).click()
    response=submitted.value
    assert response.status==202
    return response.json()['task_id']

def capture_mode(page,mode,task_id):
    page.bring_to_front()
    page.get_by_role('button',name='↓ 我的下载',exact=True).click()
    card=page.get_by_role('article').filter(has=page.locator('a[href="/api/tasks/'+task_id+'/download"]'))
    expect(card.get_by_role('link',name='领取文件',exact=True)).to_be_visible(timeout=15000)
    dom=page.locator('body').inner_text()
    page.screenshot(path=str(OUT/('browser-'+mode+'.jpg')),full_page=True,type='jpeg')
    save('browser-ui-'+mode+'.json',{'source':'automated-desktop-browser-playwright','url':page.url,'observed_at':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'dom_excerpt':dom})
    with page.expect_download() as transfer:card.get_by_role('link',name='领取文件',exact=True).click()
    filename=OUT/('browser-'+mode+'-download.txt');transfer.value.save_as(str(filename))
    assert hashlib.sha256(filename.read_bytes()).hexdigest()==TRIAL['sha256']
    page.get_by_role('button',name='▤ 团队文件',exact=True).click()
    expect(page.get_by_role('heading',name='团队文件',exact=True)).to_be_visible()

def evidence(mode,identity=None):
    args=['node','tooling/browser_evidence.mjs','native' if NATIVE_ONLY else 'capture',mode]
    if identity:args.append(identity)
    run=subprocess.run(args,cwd=ROOT,capture_output=True,text=True,encoding='utf-8')
    (OUT/('browser-evidence-'+mode+'.log')).write_text(run.stdout+run.stderr,encoding='utf-8')
    assert run.returncode==0,run.stdout+run.stderr
    print(run.stdout.strip(),flush=True)

with sync_playwright() as pw:
    browser=pw.chromium.launch(channel='chrome',headless=True)
    on_context=browser.new_context(accept_downloads=True,viewport={'width':1440,'height':1000})
    page=on_context.new_page();graph=on_context.new_page()
    page.on('console',lambda msg:RESULT['console'].append({'type':msg.type,'text':msg.text[:600]}))
    try:
        page_ready(page,TRIAL['modes']['on']['url'])
        if not NATIVE_ONLY:graph.goto(GRAPH+'/graph',wait_until='domcontentloaded')
        identity=start_record(graph) if not NATIVE_ONLY else None
        login(page,'alice')
        page.get_by_role('button',name='刷新列表',exact=True).click()
        task_id=request_task(page,TRIAL['filename'])
        capture_mode(page,'on',task_id)
        if not NATIVE_ONLY:record=stop_record(graph,identity)
        evidence('on',identity)
        RESULT['checks']['browser_on']=True
        save('browser-acceptance.json',RESULT)
        if FIRST_RECORDING_ONLY:
            print(json.dumps({'scope':'first-recording-only','recordings':RESULT['recordings'],'final_accept':False}),flush=True)
        if not FIRST_RECORDING_ONLY:
            for mode in ['off','fault']:
                context=browser.new_context(accept_downloads=True,viewport={'width':1440,'height':1000})
                trial_page=context.new_page();page_ready(trial_page,TRIAL['modes'][mode]['url']);login(trial_page,'alice')
                task_id=request_task(trial_page,TRIAL['filename'])
                capture_mode(trial_page,mode,task_id);evidence(mode)
                context.close();RESULT['checks']['browser_'+mode]=True
            run=subprocess.run(['node','tooling/browser_evidence.mjs','assemble-native' if NATIVE_ONLY else 'assemble'],cwd=ROOT,capture_output=True,text=True,encoding='utf-8')
            assert run.returncode==0,run.stdout+run.stderr
            print(run.stdout.strip(),flush=True)

            # Every following operation enters through actual rendered controls.
            identity=start_record(graph) if not NATIVE_ONLY else None
            login(page,'alice')
            upload=OUT/('GUI_acceptance_'+TRIAL['build_id'][:8]+'_'+str(int(time.time()))+'.txt')
            upload.write_text('Synthetic desktop-browser acceptance.\nAn admitted task remains collectable after revocation.\n',encoding='utf-8')
            with page.expect_file_chooser() as chooser:page.locator('input[type=file]').click()
            chooser.value.set_files(str(upload))
            page.get_by_role('button',name='上传到文件柜',exact=True).click()
            own=row(page,upload.name);expect(own).to_be_visible()
            own.get_by_role('button',name='分享给同事',exact=True).click()
            page.get_by_label('选择接收人',exact=True).select_option('bob')
            page.get_by_role('button',name='授予共享',exact=True).click()
            expect(own.get_by_role('button',name='撤销',exact=True)).to_be_visible()
            page.screenshot(path=str(OUT/'gui-uploader-share.jpg'),full_page=True,type='jpeg')
            RESULT['checks']['upload_and_named_share']=True
            login(page,'bob')
            received=row(page,upload.name);expect(received).to_be_visible()
            assert received.get_by_role('button',name='分享给同事',exact=True).count()==0
            received.get_by_role('button',name='准备下载',exact=True).click()
            page.get_by_role('button',name='↓ 我的下载',exact=True).click()
            expect(row(page,upload.name).get_by_role('link',name='领取文件',exact=True)).to_be_visible(timeout=15000)
            login(page,'alice')
            row(page,upload.name).get_by_role('button',name='撤销',exact=True).click()
            expect(page.get_by_role('status').filter(has_text='已撤销共享')).to_be_visible()
            login(page,'bob')
            expect(row(page,upload.name)).to_have_count(0)
            page.get_by_role('button',name='↓ 我的下载',exact=True).click()
            ready=row(page,upload.name).get_by_role('link',name='领取文件',exact=True)
            expect(ready).to_be_visible()
            downloads=[]
            for ordinal in [1,2]:
                with page.expect_download() as transfer:ready.click()
                target=OUT/('repeat-collection-'+str(ordinal)+'.txt');transfer.value.save_as(str(target))
                assert target.read_bytes()==upload.read_bytes();downloads.append(str(target))
            page.screenshot(path=str(OUT/'gui-after-revoke-repeat.jpg'),full_page=True,type='jpeg')
            RESULT['checks']['revoke_hides_file_but_preserves_repeat_collection']=True
            RESULT['repeat_downloads']=downloads
            login(page,'editor')
            expect(row(page,upload.name)).to_have_count(0)
            RESULT['checks']['editor_has_no_file_privilege']=True
            page.get_by_role('button',name='▧ 公告板',exact=True).click()
            title='GUI acceptance '+TRIAL['build_id'][:8]+' '+str(int(time.time()))
            page.get_by_label('标题',exact=True).fill(title)
            page.get_by_label('内容',exact=True).fill('Synthetic announcement for the real browser acceptance.')
            page.get_by_role('button',name='发布公告',exact=True).click()
            announcement=row(page,title);expect(announcement).to_be_visible()
            announcement.get_by_role('button',name='修改',exact=True).click()
            title+=' edited';page.get_by_label('标题',exact=True).fill(title)
            page.get_by_role('button',name='保存修改',exact=True).click()
            expect(row(page,title)).to_be_visible()
            page.screenshot(path=str(OUT/'gui-announcement-edited.jpg'),full_page=True,type='jpeg')
            login(page,'bob');page.get_by_role('button',name='▧ 公告板',exact=True).click()
            expect(row(page,title)).to_be_visible()
            assert row(page,title).get_by_role('button',name='修改',exact=True).count()==0
            expect(page.locator('#announcement-form')).to_be_hidden()
            login(page,'editor');page.get_by_role('button',name='▧ 公告板',exact=True).click()
            row(page,title).get_by_role('button',name='删除',exact=True).click()
            expect(row(page,title)).to_have_count(0)
            RESULT['checks']['independent_board_publish_edit_read_delete']=True
            page.get_by_role('button',name='▤ 团队文件',exact=True).click()
            if not NATIVE_ONLY:stop_record(graph,identity)
            save('browser-acceptance.json',RESULT)
            print(json.dumps({'valid':True,'checks':RESULT['checks'],'recordings':RESULT['recordings']}),flush=True)
    except Exception as error:
        RESULT.update(error=str(error),exception_type=type(error).__name__,exception_traceback=traceback.format_exc(),failed_at_ms=time.time_ns()/1e6,page_at_failure=native_page_state())
        save('browser-acceptance.json',RESULT)
        save('browser-failure-'+str(int(time.time()))+'.json',RESULT)
        page.screenshot(path=str(OUT/'browser-failure.jpg'),full_page=True,type='jpeg')
        graph.screenshot(path=str(OUT/'graph-failure.jpg'),full_page=True,type='jpeg')
        if TRACE!=OUT:
            page.screenshot(path=str(TRACE/'browser-failure.jpg'),full_page=True,type='jpeg')
            graph.screenshot(path=str(TRACE/'graph-failure.jpg'),full_page=True,type='jpeg')
        try:
            active=http(GRAPH+'/api/recordings')['active']
            if active:
                click_stop(graph,active['id'],'exception-cleanup')
                until(lambda:http(GRAPH+'/api/recordings'),lambda d:d['active'] is None,'Failed run stop did not settle')
                save('failed-recording-'+active['id']+'.json',http(GRAPH+'/api/recordings/'+active['id']))
        except Exception as cleanup:save('browser-cleanup-failure.json',{'error':str(cleanup)})
        raise
    finally:browser.close()
