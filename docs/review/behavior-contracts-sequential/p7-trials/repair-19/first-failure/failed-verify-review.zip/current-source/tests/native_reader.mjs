import { trace, context } from '@opentelemetry/api';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import initSqlJs from 'sql.js';
const bo_provider = process.env.VIBELENS_SKILL || fileURLToPath(new URL('../../node-migration-final-skills/vibelens/', import.meta.url));
const { bo_internal } = await import(pathToFileURL(path.join(bo_provider, 'scripts/bo_observer/adapters/javascript/bo_data.mjs')).href);

/** Read selected real native rows independently of graph frames and captured values. */
export function readInstances(store, buildId, selection) {
  return bo_internal(/** Mark independent verification reads as non-business observer work. */ () => {
  const rows = [];
  for (const row of store.all('SELECT * FROM grants')) {
    const id = row.file_id + '/' + row.recipient_id;
    if (selection.grant.includes(id)) rows.push({ id, state_model_id: 'grant', state: row.active ? 'active' : 'inactive', revision: row.revision, build_id: buildId, context: {} });
  }
  for (const row of store.all('SELECT * FROM tasks')) if (selection.download_task.includes(row.id)) rows.push({ id: row.id, state_model_id: 'download_task', state: row.status, revision: row.revision, build_id: buildId, context: { file_id: row.file_id, requester_id: row.requester_id, authorized_at_submission: Boolean(row.authorized_at_submission) } });
  for (const row of store.all('SELECT * FROM announcements')) if (selection.announcement.includes(row.id)) rows.push({ id: row.id, state_model_id: 'announcement', state: row.status, revision: row.revision, build_id: buildId, context: { author_id: row.author_id } });
  for (const row of store.all('SELECT trace_id,user_id,status,revision FROM sessions')) if (selection.session.includes(row.trace_id)) rows.push({ id: row.trace_id, state_model_id: 'session', state: row.status, revision: row.revision, build_id: buildId, context: { user_id: row.user_id } });
  return { instances: rows };
  });
}
/** Read a completed browser trial's persisted SQLite bytes without opening an application store or writing rows. */
export async function readPersistedInstances(filename,buildId,selection) {
  const require=createRequire(import.meta.url);
  const SQL=await initSqlJs({locateFile:/** Resolve the already installed SQLite WebAssembly asset. */ name=>require.resolve('sql.js/dist/'+name)});
  const database=new SQL.Database(await readFile(filename));
  const native={
    /** Consume a bound read from this independent in-memory copy of actual SQLite bytes. */
    all(sql,...parameters){
    const query=database.prepare(sql),rows=[];
    try{query.bind(parameters);while(query.step())rows.push(query.getAsObject());}finally{query.free();}return rows;
    }
  };
  try{return readInstances(native,buildId,selection);}finally{database.close();}
}
/** Read the SDK's actual current context, independently of VibeLens metadata formatting. */
export function readSdkContext() {
  const span = trace.getSpan(context.active());
  if (!span) return null;
  const native = span.spanContext();
  return { trace_id: native.traceId, span_id: native.spanId, trace_flags: native.traceFlags };
}
/** Independently read the actual principal for a synthetic request cookie without exporting its credential. */
export function readSessionPrincipal(store,cookie) {
  return bo_internal(/** Keep independent authentication reads outside business capture. */ ()=>{
    const token=cookie?.split(';')[0].replace(/^team_session=/,'') || '';
    if(!token)return null;
    const hash=createHash('sha256').update(token).digest('hex');
    const row=store.get('SELECT user_id,trace_id,status FROM sessions WHERE token_hash=?',hash);
    return row?{user_id:row.user_id,session_id:row.trace_id,active:row.status==='active'}:null;
  });
}
/** Join native operation boundaries to their independently read SDK context. */
export function nativeAuditor(service, buildId) {
  const sdk = {}, contexts = new Map(), inputs = new Map(), stateValues = {}, completions = {}, factBasis = {}, errors = [], entries=[];
  const add = /** Retain the actual SDK context with its native invocation identity. */ (node, phase, invocation, value) => {
    sdk[node] ||= {}; sdk[node][phase] ||= [];
    sdk[node][phase].push({ invocation_id: invocation, ...value });
  };
  const inspect = /** Inspect one actual native operation fact independently of graph events. */ event => {
    if (event.phase === 'enter') { inputs.set(event.invocationId, event.inputs);entries.push({name:event.name,invocation_id:event.invocationId}); }
    if (['started','http_started'].includes(event.phase)) {
      const value = readSdkContext();
      if (value) { contexts.set(event.invocationId, value); add(event.name, 'enter', event.invocationId, value); }
    } else if (['return','error','http_return'].includes(event.phase)) {
      const value = contexts.get(event.invocationId);
      if (value) add(event.name, event.phase === 'error' ? 'error' : 'return', event.invocationId, value);
    }
    if (event.phase === 'state' && event.event) {
      const row = readStateBoundary(service.store, event, buildId);
      (stateValues[event.model] ||= []).push(row);
      (completions[event.model + ':' + event.event] ||= []).push(row);
    }
    if (event.phase === 'policy') readPolicyBasis(service.store, event, inputs.get(event.invocationId), factBasis);
  };
  const unsubscribe = service.subscribe(/** Collect independent audit errors without changing native execution. */ event => { try { bo_internal(/** Exclude native-reader metadata and verification reads from business capture. */ ()=>inspect(event)); } catch(error) { errors.push({phase:event.phase,operation:event.name,message:error.message}); } });
  return { sdk, stateValues, completions, factBasis, errors, entries, close: unsubscribe };
}

/** Independently read the committed SQLite row at the actual native state boundary. */
export function readStateBoundary(store, event, buildId) {
  let row, state;
  if (event.model === 'grant') {
    const [file, recipient] = event.id.split('/');
    row = store.get('SELECT active,revision FROM grants WHERE file_id=? AND recipient_id=?', file, recipient);
    state = row.active ? 'active' : 'inactive';
  } else {
    const table = { download_task:'tasks', announcement:'announcements', session:'sessions' }[event.model];
    row = store.get('SELECT status,revision FROM ' + table + ' WHERE ' + (event.model === 'session' ? 'trace_id' : 'id') + '=?', event.id);
    state = row.status;
  }
  assert.equal(state, event.state); assert.equal(row.revision, event.revision);
  return { model:'state-model:' + event.model, instance:event.id, invocation:event.invocationId,
    attempt:'application', build:buildId, sample:row.revision, value:state };
}

/** Verify native policy fact acquisition against independent SQLite reads before returning its basis. */
export function readPolicyBasis(store, event, input, result) {
  const facts = event.decision.facts, operation = event.decision.operation;
  const mark = /** Record a basis only after the native selected values have been independently checked. */ (id, field, timing, scope, version) => {
    result[id] = { node:'policy_facts', direction:'out', field, read_basis:{timing,scope,version} };
  };
  if (input?.actor_id) {
    const user = store.get('SELECT id,editor FROM users WHERE id=?',input.actor_id);
    const session = store.get("SELECT status FROM sessions WHERE user_id=? AND status='active'",input.actor_id);
    assert.ok(user && session);
    if (Object.hasOwn(facts,'actor')) { assert.equal(facts.actor,user.id); mark('actor-id','actor','before_current_operation','current_authenticated_request','session_revision'); }
    if (Object.hasOwn(facts,'member')) { assert.equal(facts.member,true); mark('actor-member','member','before_current_operation','current_authenticated_request','session_revision'); }
    if (Object.hasOwn(facts,'editor')) { assert.equal(facts.editor,Boolean(user.editor)); mark('actor-editor','editor','before_announcement_mutation','current_authenticated_request','role_revision'); }
  }
  if (input?.file_id && ['view_file','request_download','manage_share'].includes(operation)) {
    const file = store.get('SELECT owner_id FROM files WHERE id=?',input.file_id);
    if (Object.hasOwn(facts,'owner')) { assert.equal(facts.owner,file.owner_id); mark('file-owner','owner','before_file_view_share_or_task_submission','current_file_operation','file_revision'); }
    if (['view_file','request_download'].includes(operation)) {
      const grant = store.get('SELECT recipient_id,active FROM grants WHERE file_id=? AND recipient_id=?',input.file_id,input.actor_id);
      assert.equal(facts.recipient,input.actor_id); assert.equal(facts.active,Boolean(grant?.active));
      mark('grant-recipient','recipient','before_file_view_or_task_submission','current_file_operation','grant_revision');
      mark('grant-active','active','before_file_view_or_task_submission','current_file_operation','grant_revision');
    }
  }
  if (operation === 'collect_download') {
    const row = store.get('SELECT requester_id,authorized_at_submission,status FROM tasks WHERE id=?',input.task_id);
    assert.equal(facts.requester,row.requester_id); assert.equal(facts.submission_authorized,Boolean(row.authorized_at_submission)); assert.equal(facts.task_state,row.status);
    mark('task-requester','requester','before_collection','selected_download_task','task_revision');
    mark('task-submission-authorized','submission_authorized','before_collection','persisted_submission_authorization','task_revision');
    mark('task-state','task_state','before_collection','selected_download_task','task_revision');
  }
  if (operation === 'manage_announcement') {
    const row = store.get('SELECT author_id,status FROM announcements WHERE id=?',input.announcement_id);
    assert.equal(facts.author,row.author_id); assert.equal(facts.announcement_state,row.status);
    mark('announcement-author','author','before_announcement_mutation','selected_announcement','announcement_revision');
    mark('announcement-state','announcement_state','before_announcement_read_or_mutation','selected_announcement','announcement_revision');
  }
  if (operation === 'login') {
    // Real HTTP password success/rejection is asserted by the scenario. The audit
    // reads the completed native password decision before session insertion.
    assert.equal(typeof facts.credentials_valid,'boolean');
    mark('credentials-valid','credentials_valid','after_native_password_verification','current_login_attempt','attempt_id');
  }
}
