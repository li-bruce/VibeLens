# Implementation plan

Objective: deliver the confirmed Node.js team file-sharing application with real login/logout, three synthetic accounts, SQLite/local files, independent announcements and external VibeLens observe-mode evidence.

Protected boundaries: work only in node-retest-app; do not change other applications or maintained VibeLens code. Managed native adapters and installed tool dependencies are allowed only through canonical Skill interfaces. No ARIS.

1. Record the actual graph confirmation and login instruction; preserve the semantic baseline. complete
2. Implement native storage, sessions, file permissions, queued preparation and announcements. complete
3. Build the Chinese browser UI with separate files/tasks/board views. complete
4. Connect canonical external observation, state/rule/data/source mappings and independent cases. in_progress
5. Run business, mapping, native-state and project checks; inspect browser behavior; fix failures. in_progress
6. Deliver running URLs, three test accounts, commands and bounded results. pending

No prior code baseline exists. Establish change_sync begin only after a parseable native scaffold and mappings exist; later edits use the active immutable baseline.

Current baseline is established and immutable: initial-node-app/baseline.json,
e7b11f4d284aee13d86d26183ea94b7219114d7994bec8cf632726e0981ab0bb.

2026-11-20 steering: preserve pre-repair source/model/evidence; finish early HTTP
rejection capture, selected fields, lifecycle and existing acceptance. The first
upgrade rejection and supported migration are retained. The final user-selected
provider is node-migration-final-skills/vibelens (reported export commit 9ddd6661).
All three managed adapters pass its integrity check and remain unedited.

Real browser trials exposed and retained project wiring failures: canonical
build_id needed conversion to the native buildId option, absolute asset paths
under .validation returned 404, and duplicate state-value witnesses incorrectly
claimed native state-frame boundaries. These are repaired in project-owned code;
all selected state/revision outputs remain. One actual rapid stop retained an
interrupted recording with an explicit undrained-queue gap. No failed recording
was rewritten. Native nine-case evidence and baseline integrity are retained.

After the desktop control session expired, the user explicitly authorized an
independent Playwright browser. Fresh real-page trials, screenshots, downloads
and current-build recording acceptance are in progress. Do not advance business
semantics until mapping and final verify/accept/check finish.

The batch provider is currently diagnostic only. Its first recording passed;
its second finite burst exceeded the unchanged pending-zero wait and retained
an actual double-timeout snapshot error. The preserved diagnosis, raw seal and
harness provider/health/receipt corrections are in progress.md. Do not promote
this candidate or reuse the old browser build after the reader-source change.

Current diagnostic provider is admission-candidate-skills/vibelens (repair09),
selected process-locally; canonical JS adapters are unchanged. Its one timed
first-recording retest is interrupted from a double receipt timeout at seq34,
although all events ultimately arrived. The09 watcher memo was observed to avoid
repeated full project validation. Residual tick/binding subphases remain under
maintenance investigation. Preserve all prior raw recordings/seals and keep
full browser/replay and final verify/accept/check pending. Do not run another
diagnostic or begin business changes without the next maintenance instruction.


Current maintenance status (2026-11-20): the requested canonical upgrade and strict-only checks are complete, with inspect/verify failed and preserved. Integration/docs/API/database pass. Registration/review/naming metadata need a separate maintenance step; runtime evidence remains pending. Preserve the admission/revocation distinction, all570 captures and the immutable baseline. No new recording or accept until the coordinating instruction. Detailed handoff: review/runtime/INTERACTIVE_UPGRADE_20261120.md.


Current scoped repair: policy witness IDs/data dependencies and the existing list/detail shared viewing-rule binding are repaired, confirmed through C_LIST_VIEW and compared in direct-native on/off/fault regressions. Preserve570 captures and all original checks. No service/HTTP/browser/recording/accept this round. Full-suite acceptance and transaction gate repair await the next independently installed provider. Exact current receipts and report: review/runtime/policy-listing-repair-20261120.


Current repair16 maintenance: the coordinator authorized effect-evidence-skills/vibelens (reported commit d42a106), canonical external-provider upgrade and the original complete verify including its local native/HTTP tests. This explicitly replaces the previous temporary no-HTTP restriction. Keep C_LIST_VIEW, the actual policy emitter fix, four models, all570 captures and every original assertion. Interactive browser, recording, new business iteration and accept remain unapproved. Current receipts/report: review/runtime/effect-evidence-upgrade-20261120.


Current P7 concurrency follow-up: the completed repair16 full verification and four strict negative controls are sealed (25859a6b...). A separate real HTTP body barrier now tests two authenticated colleagues and their own tasks on/off/fault using current services/storage. The native SQL transaction and single worker remain serial. The new tests/concurrency.test.mjs command and watched source, plus its generator registration, extend rather than replace all prior checks. Original model IDs/captures, C_LIST_VIEW and business expectations remain unchanged. Current audit, real barrier records, negative access cases and exact-candidate receipts: review/runtime/concurrency-evidence-20261120. No browser/recording/accept pending the next maintenance instruction.


Latest coordination freeze: keep the exact first successful concurrency test source (SHA2565db30738...), complete registration/source checks and current review only, then stop ready for the next provider upgrade. Unexecuted incremental assertions/second negative wave are archived separately and are not active. No new full verify has started after registering this test; it is deferred to the imminent installation. Browser/recording/accept remain off.


Latest repair17 coordination (2026-11-20): use asset-transport-skills/vibelens as the independent provider (reported maintained commit 844b878d). Perform only canonical managed plan/apply/check and recall/scan/review/inspect plus source checks. Preserve the exact sealed first concurrency source, all four test commands, 570 physical nodes and 519 explicit capture fields, the four state models, C_LIST_VIEW, every prior assertion and the immutable initial baseline. Mode remains observe and authorization is committed at admission time. Full verify, heavyweight/native test runs, browser and recording are deferred until the coordinator separately authorizes the Node retest. No installed source is edited. Current receipts and handoff: review/runtime/asset-transport-upgrade-20261120.


Latest repair17 native/browser retest authorization (2026-11-20): the coordinator reports the Python recording has ended. Run the unchanged complete verify first, preserve its genuine missing-browser failures, then the complete unified_browser_run.py --recording / browser_acceptance.py path with the native viewer and all on/off/fault/browser cases. Keep all four test commands, model/capture scope, frozen first concurrency evidence and admission-time observe semantics. Do not use timing/profile wrappers, extend stop deadlines, backfill events, patch the installation or accept. After normal stop run full verify again, audit actual HTTP/SQLite/file/identity/lifecycle evidence, and retain the actual application and capture service for independent UI inspection. Receipts: review/runtime/repair17-native-browser-20261120.


Latest atomic-catalog maintenance (2026-11-20): isolated v2 validation of atomic-catalog-skills/vibelens passed with real hard-link snapshot handles and real SQLAlchemy reflection barriers. Unmodified Store.persist replaces while either barrier is held; the current snapshot remains the old complete image and the next actual catalog detects the new fixture table. Register application.sqlite_file_mode=atomic_replace from src/store.mjs export/full-image rename and preserve it in tooling/configure_database.py. Upgrade only through canonical managed plan/apply/check, then source scan/review/inspect and all existing non-browser commands. Preserve 570 physical nodes, 519 explicit captures, four models, frozen concurrency evidence and admission-time observe rules. Do not run browser recording, full verify or accept before the coordinating approval. Old failed recordings/database/.tmp and the v1 diagnostic remain sealed and untouched. Receipts: review/runtime/atomic-catalog-upgrade-20261120.


Latest repair18 formal-recording authorization (2026-11-20): the coordinating chat reported full regression/clean export complete and no concurrent heavy regression. The isolated snapshot-handle/reflection validation, normal managed upgrade, atomic_replace registration, source checks and all four original non-browser commands have passed. Formal full unified_browser_run.py --recording is now explicitly authorized with both provider variables set to atomic-catalog-skills/vibelens, every original case/capture and fixed stop deadline. Preserve an exception and do not blindly rerun. After success run full verify, then start the normal app/viewer on the same build/provider/var data, create new live history through actual page login/list controls, and keep services available for independent inspection. No accept or admission-time business-rule change. Receipts: review/runtime/repair18-formal-recording-20261120.
