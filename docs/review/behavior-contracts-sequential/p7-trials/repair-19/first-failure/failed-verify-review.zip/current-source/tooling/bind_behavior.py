"""Pin the exact four native state lifecycles and their independent value witnesses."""
import hashlib
import json
import os
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
SKILL=Path(os.environ.get("VIBELENS_SKILL",ROOT.parent/"node-migration-final-skills/vibelens"))
sys.path.insert(0,str(SKILL/"scripts"))
from bo_observer.behavior.contract import assess

def read(name): return json.loads((ROOT/name).read_text(encoding="utf-8-sig"))
def write(name,value): (ROOT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")

doc=read("discovery.json"); project=read("bo_stategraph/project.json"); model=project["model"]
contract={"schema":"bo-behavior/v1","project_id":doc["project_id"],"revision":"native-state-lifecycles-1",
 "scope":{"model_refs":["state-model:"+m["id"] for m in doc["state_models"]],"object_refs":[],"unresolved":[],
          "exclusions":["This contract selects state lifecycles. Permission expressions, input facts, task admission commit, HTTP and UI callbacks remain required by the complete concept, implementation, mapping and independent business gates.","No finite analysis, refinement proof, distributed atomicity or exactly-once guarantee is configured."]},
 "domains":[{"id":"boolean","type":"boolean","source_refs":["U4"]}],"variables":[],"initial":{"op":"literal","domain":"boolean","value":True},"actions":[],"properties":[]}
all_variables=[m["id"]+"_state" for m in doc["state_models"]]
for machine in doc["state_models"]:
    ident=machine["id"]; variable=ident+"_state"; owner="state-model:"+ident
    contract["domains"].append({"id":ident+"_states","type":"enum","values":machine["states"],"source_refs":machine["source_refs"]})
    contract["variables"].append({"id":variable,"domain":ident+"_states","owner":owner,"concept_ref":owner,"persistence":"persistent","source_refs":machine["source_refs"]})
    for transition in machine["transitions"]:
        source=transition["source"]
        enabled={"op":"eq","args":[{"op":"var","id":variable,"phase":"before"},{"op":"literal","domain":ident+"_states","value":source}]}
        contract["actions"].append({"id":ident+"."+transition["id"],"model_refs":[owner],"transition_ref":"transition:"+ident+":"+transition["id"],"parameters":{},"enabled":enabled,"reads":[variable],"writes":[variable],"updates":{},"unchanged":[v for v in all_variables if v!=variable],"completion":{"kind":"event","meaning":"The actual committed SQLite state is observed at the native transition boundary; native guards retain their separately checked canonical decisions."},"source_refs":transition["source_refs"]})
definition=assess(contract,doc)
if not definition["valid"]: raise ValueError(definition["errors"])
write("behavior.json",contract)
reader={"path":"tests/native_reader.mjs","symbol":"readStateBoundary"}
keys=[{"name":name,"actual":[name],"observed":path} for name,path in {
    "model":["outputs","model_ref"],"instance":["inputs","instance_id"],"invocation":["inputs","invocation_id"],
    "attempt":["attempt"],"build":["build_id"],"sample":["outputs","revision"]}.items()]
def witness(ident,collection,when=None):
    site={"node":"state_value:"+ident,"phase":"change"}
    if when: site["when"]=when
    writers=[]
    machine=next(m for m in doc["state_models"] if m["id"]==ident)
    for trigger in machine["events"]:
        node=model["concepts"]["events"]["event:"+ident+":"+trigger]["node"]
        source=next(n["source"] for n in model["nodes"] if n["id"]==node)
        if source not in writers: writers.append(source)
    return {"reader":reader,"writers":writers,"observation":{**site,"path":["outputs","state"]},
            "native":{"collection":collection,"value":["value"],"keys":keys},"cases":["state_lifecycles"]}
binding={"schema":"bo-behavior-bindings/v1","definition_sha256":definition["definition_sha256"],"variables":{},"actions":{},"interactions":{}}
for machine in doc["state_models"]:
    ident=machine["id"]
    binding["variables"][ident+"_state"]=witness(ident,["native_states",ident])
    for transition in machine["transitions"]:
        trigger=transition["trigger"]
        when=[{"path":["outputs","event_name"],"equals":trigger}]
        native_node=model["concepts"]["events"]["event:"+ident+":"+trigger]["node"]
        binding["actions"][ident+"."+transition["id"]]={"entry":{"node":native_node,"phase":"enter"},
            "completion":{"node":"state_value:"+ident,"phase":"change","when":when},
            "completion_witness":witness(ident,["native_completions",ident+":"+trigger],when),
            "parameters":{},"exits":[],"cases":[{"id":"state_lifecycles","boundaries":["complete"]}]}
model["behavior_bindings"]=binding
if "behavior.json" not in model["source_files"]:model["source_files"].append("behavior.json")
project["contracts"]["behavior"]={"path":"behavior.json","sha256":hashlib.sha256((ROOT/"behavior.json").read_bytes()).hexdigest(),"schema":"bo-behavior/v1"}
write("bo_stategraph/project.json",project)
sync=read("sync.json")
if "behavior.json" not in sync["watch_files"]:sync["watch_files"].append("behavior.json")
write("sync.json",sync)
acceptance=read("acceptance.json"); checks={c["id"]:c for c in acceptance["checks"]}
checks["positive-lifecycles"]={"id":"positive-lifecycles","requirement":"R_DOWNLOAD","case":"state_lifecycles","path":["native_lifecycles_completed"],"equals":True}
acceptance["checks"]=list(checks.values());write("acceptance.json",acceptance)
print(json.dumps({"behavior_definition":definition["definition_sha256"],"variables":len(binding["variables"]),"actions":len(binding["actions"])}))
