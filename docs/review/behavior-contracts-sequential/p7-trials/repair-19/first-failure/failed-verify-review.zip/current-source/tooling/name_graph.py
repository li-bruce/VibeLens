"""Maintain bilingual names for reviewed business meanings and exact source contexts."""
import json
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
def read(name):return json.loads((root/name).read_text(encoding="utf-8"))
inventory=read("review/name-inventory.json")["items"]
prior=read("bo_stategraph/config/semantic-names.json")
items={(i["category"],i["id"]):i for i in inventory}
actions={
"login":("Sign in","登录"),"logout":("Sign out","退出登录"),"upload_file":("Upload file","上传文件"),"view_file":("View file","查看文件"),
"share_file":("Share with colleague","指定同事共享"),"revoke_share":("Revoke share","撤销共享"),"request_download":("Request preparation","提交下载任务"),
"prepare_download":("Prepare artifact","后台准备文件"),"mark_download_ready":("Mark artifact ready","确认文件准备完成"),"collect_download":("Collect prepared file","领取已准备文件"),
"read_announcements":("Read board","阅读公告板"),"publish_announcement":("Publish announcement","发布公告"),"edit_announcement":("Edit own announcement","修改自己的公告"),
"delete_announcement":("Delete own announcement","删除自己的公告"),"list_files":("List visible files","列出可访问文件"),"list_tasks":("List my tasks","列出我的任务"),
"task_commit":("Commit admitted task","保存已授权任务"),"policy_facts":("Read native authorization facts","读取原生授权事实"),
"workspace_ui":("Use team workspace","操作团队空间"),"read_session":("Read current session","读取当前会话"),"list_members":("List colleagues","列出团队同事"),
"ui_callback":("Run form or control callback","执行表单或控件回调"),"ui_row_action":("Run row action","执行列表行操作"),"ui_navigation":("Change workspace view","切换空间视图"),
"data_read":("Read native SQLite rows","读取原生 SQLite 记录"),"data_write":("Write native SQLite rows","写入原生 SQLite 记录"),"data_admission_transaction":("Commit or roll back task admission","提交或回滚下载任务受理")}
functions={
"createApp":("Build application routes","建立应用路由"),"sessionCookie":("Read session cookie","读取当前会话凭据"),"sameIdentity":("Compare native identities","比较原生身份"),"decide":("Evaluate native permission","执行原生权限判断"),
"operation":("Run native operation once","执行一次原生业务操作"),"authorize":("Check native permission result","核对原生授权结果"),"state":("Publish actual native state","发布实际原生状态"),
"publicUser":("Select public member fields","选择成员公开信息"),"tokenHash":("Hash session token","计算会话凭据摘要"),"session":("Read active session","读取有效会话"),"requireActor":("Require authenticated member","确认当前成员已登录"),
"fileFacts":("Read current file access facts","读取当前文件访问事实"),"members":actions["list_members"],"listFiles":actions["list_files"],"listTasks":actions["list_tasks"],
"upload":actions["upload_file"],"viewFile":actions["view_file"],"setGrant":("Change named recipient grant","变更指定同事的授权"),"requestDownload":actions["request_download"],"drainWorker":actions["prepare_download"],"collect":actions["collect_download"],
"announcements":actions["read_announcements"],"publish":actions["publish_announcement"],"mutateAnnouncement":("Change editor own announcement","修改或删除编辑员自己的公告"),"validateAnnouncement":("Validate announcement input","检查公告输入"),
"scheduleWorker":("Schedule queued preparation","调度排队的准备任务"),"stop":("Stop native worker","停止原生后台任务"),"shutdown":("Close application resources","关闭应用资源"),
"all":("Read bound SQLite rows","读取绑定查询的 SQLite 记录"),"get":("Read one SQLite row","读取一条 SQLite 记录"),"run":("Execute bound SQLite mutation","执行绑定的 SQLite 写入"),"transaction":("Commit or restore native transaction","提交或恢复原生事务"),"persist":("Persist committed SQLite bytes","保存已提交的 SQLite 数据"),"nativeData":("Preserve one native data call","保持原生数据调用只执行一次"),"close":("Close owned resource","关闭当前资源"),
"subscribe":("Subscribe to native facts","订阅原生执行事实"),"notify":("Publish native fact","发布原生执行事实"),"readInstances":("Read independent native instances","独立读取原生实例"),"readStateBoundary":("Read committed state independently","独立读取已提交状态"),"readPolicyBasis":("Verify native read basis","独立核对事实读取依据"),"readSdkContext":("Read SDK trace context","独立读取 SDK 跟踪上下文"),"nativeAuditor":("Audit native boundaries","核对原生执行边界"),
"api":("Call authenticated API","调用需要登录的接口"),"jsonRequest":("Build JSON request","构造 JSON 请求"),"element":("Create safe text element","创建安全文本元素"),"notice":("Show operation feedback","显示操作结果"),"showLogin":("Show login screen","显示登录页"),"size":("Format byte size","格式化文件大小"),"time":("Format local time","格式化本地时间"),"perform":("Run action with error feedback","执行操作并反馈错误"),"action":("Build row action button","创建列表行操作按钮"),"rowActionHandler":actions["ui_row_action"],"dispatchUi":("Observe actual UI callback","观察实际页面回调"),"bind":("Bind native control callback","绑定原生控件回调"),"uiCallback":actions["ui_callback"],"navigationHandler":actions["ui_navigation"],"enter":("Enter authenticated workspace","进入已登录空间"),"selectView":("Load selected workspace view","加载选定空间视图"),"refreshFiles":("Refresh visible files","刷新可访问文件"),"openShare":("Choose named recipient","选择指定共享同事"),"refreshTasks":("Refresh my download tasks","刷新我的下载任务"),"resetEditor":("Reset announcement form","重置公告编辑表单"),"refreshBoard":("Refresh independent board","刷新独立公告板"),"boot":("Restore real login session","恢复真实登录会话"),"$":("Find application element","查找应用元素")}
api_actions={"session":"read_session","members":"list_members","files":"list_files","file":"view_file","tasks":"list_tasks","request":"request_download","collect":"collect_download","board":"read_announcements","publish":"publish_announcement","edit":"edit_announcement","delete":"delete_announcement","upload":"upload_file","upload_actor":"upload_file","share":"share_file","revoke":"revoke_share","login":"login","logout":"logout"}
fields={
"actor":"当前操作人","actor_id":"操作人标识","user":"成员","user_id":"成员标识","username":"用户名","display_name":"显示名称","editor":"公告编辑员身份","member":"已登录成员","credentials_valid":"凭据校验结果","password_supplied":"是否提交密码","token_present":"是否带有会话凭据","password_salt":"口令盐值","password_hash":"口令摘要","token_hash":"会话凭据摘要","trace_id":"非秘密会话标识",
"file":"文件","file_id":"文件标识","owner":"文件上传者","owner_id":"上传者标识","recipient":"指定接收人","recipient_id":"接收人标识","active":"共享当前有效","grant":"指定共享授权","grants":"共享授权记录","task":"下载任务","task_id":"下载任务标识","requester":"原申请人","requester_id":"原申请人标识","submission_authorized":"提交时已获准","authorized_at_submission":"随任务保存的提交授权","task_state":"任务当前状态","status":"当前状态","state":"状态值","revision":"原生修订号","build_id":"构建标识","state_model_id":"状态模型标识","model_ref":"概念模型标识","instance_id":"独立实例标识","invocation_id":"原生调用标识","event_name":"实际转换事件","before":"变更前的值","value":"实际值","allowed":"本次允许执行","committed":"事务已成功提交","transaction_id":"原生事务标识",
"announcement":"公告","announcement_id":"公告标识","author":"公告作者","author_id":"作者标识","announcement_state":"公告当前状态","title":"公告标题","body":"公告内容","body_length":"公告内容长度","operation":"原生操作类别","name":"名称","size":"文件字节数","byte_count":"实际字节数","sha256":"文件校验摘要","storage_path":"本地原始文件路径","prepared_path":"本地准备结果路径","last_error":"最近准备错误","created_at":"创建时间","started_at":"开始准备时间","ready_at":"准备完成时间","updated_at":"最近修改时间",
"method":"实际 HTTP 方法","path":"实际请求路径","duration_ms":"实际耗时（毫秒）","http_status":"实际 HTTP 状态","error":"公开错误代码","error_type":"原生异常类型","count":"实际记录数","rows":"实际消耗行数","rows_known":"是否已知行数","targets":"实际数据目标","target_access":"数据目标访问角色","unknown_targets":"未确定的数据目标","target_source":"数据目标依据","statement":"脱敏操作名称","parameters":"脱敏绑定参数","result":"已选择的结果","input_count":"输入数量","output_count":"输出数量","event_type":"原生事件类型","target":"操作控件标识","action":"当前动作","completed":"页面回调已完成","left":"比较左值","right":"比较右值","bo_check":"本次规则核对标识","bo_basis":"本次事实依据标识","in":"输入","out":"输出","inputs":"实际输入","outputs":"实际输出","context":"当前调用上下文","model":"状态模型","id":"当前对象标识","event":"实际事件","root":"本地数据根目录","filename":"本地 SQLite 文件名","sql":"原生绑定 SQL","bytes":"实际文件字节","fileId":"文件标识","recipientId":"接收人标识","taskId":"下载任务标识","req":"原生 HTTP 请求","res":"原生 HTTP 响应","next":"Express 后续处理","callback":"实际回调","execute":"原生执行回调","functions":"有序条件回调","leftName":"左侧事实名称","rightName":"右侧事实名称","facts":"原生授权事实","node":"观察节点标识","phase":"实际执行阶段","listener":"事实订阅者","store":"原生 SQLite 存储","service":"原生业务服务","publicRoot":"页面资源目录","observer":"可选观察器","url":"接口地址","options":"调用选项","button":"当前操作按钮","message":"公开反馈内容","failure":"操作失败标记","view":"选定空间视图","tag":"元素类型","text":"安全显示文本","className":"显示样式类","eventType":"原生事件类型","buildId":"当前构建标识","selection":"实际实例选择范围"}
states={"grant":"共享授权","download_task":"下载任务","announcement":"公告","session":"登录会话","inactive":"当前无共享","active":"当前有效","created":"任务已分配","queued":"任务排队中","preparing":"正在准备文件","ready":"结果可重复领取","absent":"尚未建立","published":"已发布","deleted":"已删除","ended":"已退出"}
roles={"directory":"目录","file":"源码","parameter":"参数","declaration":"声明","reference":"静态引用","unresolved":"未解析引用","module":"模块","property":"字段","variable":"局部值","import":"导入"}
relations={"contains":"包含","flow":"随后执行","data":"使用数据","guard":"满足条件才执行","calls":"静态调用","uses":"使用","declares":"声明","has_parameter":"具有参数","writes":"写入","reads":"读取","applies_to":"适用于","action_requests_event":"请求转换事件","transition_guarded_by":"转换受规则约束","transition_has_effect":"转换完成效果","decision_reads_fact":"判断读取事实"}

def source_name(item):
    source=item.get("source") or {};symbol=source.get("symbol",item.get("label",""))
    base=symbol.split(".<callback:",1)[0].split(".<object:",1)[0]
    tail=base.split(".")[-1]
    if tail in functions:
        en,zh=functions[tail]
        if "<callback:" in symbol:return en+" callback",zh+"回调"
        return en,zh
    if tail.endswith("Handler"):
        entry=tail.removesuffix("Handler")
        action=api_actions.get(entry)
        if action:return actions[action][0]+" handler",actions[action][1]+"接口处理"
    if symbol.startswith("bo_") or ".bo_" in symbol:
        return "Observer · "+base,"观察器 · "+base
    if "<callback:" in symbol:return "Callback · "+base,"回调 · "+base
    return symbol,"声明 · "+symbol

def name(item):
    identity=item["id"];category=item["category"];label=str(item.get("label") or identity)
    old=prior.get("names",{}).get(category,{}).get(identity)
    if old and item.get("basis")==prior.get("basis",{}).get(category,{}).get(identity):return old
    if identity in actions:return dict(zip(("en","zh-CN"),actions[identity]))
    if identity.startswith("api_"):
        action=api_actions.get(identity.removeprefix("api_"))
        if action:return {"en":actions[action][0]+" API","zh-CN":actions[action][1]+"接口"}
    if category in {"concepts","states","events"} and old:return old
    if identity.startswith("native_state:"):
        _,owner,value=identity.split(":",2)
        return {"en":owner+" · "+value,"zh-CN":states[owner]+" · "+states[value]}
    if identity.startswith("state_value:"):
        owner=identity.split(":",1)[1];return {"en":"Read "+owner+" state","zh-CN":"读取"+states[owner]+"原生状态"}
    if item.get("layer")=="symbols":
        owner=item.get("owner","");term=fields.get(label,label)
        owner_label=actions.get(owner,(owner,owner))[1]
        return {"en":owner+" · "+label,"zh-CN":owner_label+" · "+term}
    if category=="edges":
        word=relations.get(label,relations.get(str(item.get("type")),label))
        return {"en":label,"zh-CN":word}
    if item.get("source"):
        en,zh=source_name(item)
        if item.get("code_role")=="parameter":
            en=label+" argument";zh=fields.get(label,label)+"参数"
        return {"en":en,"zh-CN":zh}
    if label in fields:return {"en":label,"zh-CN":fields[label]}
    if item.get("code_role"):
        role=item["code_role"]
        return {"en":label,"zh-CN":roles.get(role,"源码")+" · "+label}
    if old:return old
    # Exact technical names remain visible for unresolved/external symbols. Do
    # not invent a business explanation for a source symbol with no exact binding.
    return {"en":label,"zh-CN":label}

result={"schema":"bo-semantic-names/v1","locales":["en","zh-CN"],"names":{},"basis":{}}
for item in inventory:
    category,identity=item["category"],item["id"]
    labels=name(item)
    for locale,value in labels.items():
        text=re.sub(r"\s+"," ",value).strip()
        if len(text)>60:
            # Technical callback namespaces can contain an entire source
            # expression. Keep the concise owner name; exact source is separate.
            text=text.split(".<callback:",1)[0].split(".<object:",1)[0]
            if len(text)>60:text=text[:57]+"..."
        labels[locale]=text
    result["names"].setdefault(category,{})[identity]=labels
    result["basis"].setdefault(category,{})[identity]=item["basis"]
(root/"review/semantic-names.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"named":len(inventory),"categories":{k:len(v) for k,v in result["names"].items()}}))
