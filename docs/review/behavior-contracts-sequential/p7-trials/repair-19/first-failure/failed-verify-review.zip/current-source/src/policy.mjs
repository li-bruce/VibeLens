/** Compare actual supplied identities or enum values without hidden data reads.
 * @param {string} left First actual identity or enum value supplied by the native policy.
 * @param {string} right Second actual identity or enum value supplied by the native policy.
 */
export function sameIdentity(left, right) { return left === right; }

/**
 * Evaluate the application's own policy once, retaining visited expressions.
 * @param {string} operation Native operation name.
 * @param {object} facts Actual facts acquired by the application at this operation's boundary.
 */
export function decide(operation, facts) {
  const steps = [], cache = new Map();
  const input = /** Read and cache one actual input fact for this native policy evaluation. */ name => {
    if (cache.has(name)) return cache.get(name);
    const value = facts[name];
    steps.push({ id: name, op: 'input', value });
    cache.set(name, value);
    return value;
  };
  const predicate = /** Compare the supplied identity facts and retain the actual predicate result. */ (id, leftName, rightName) => {
    const left = input(leftName), right = input(rightName);
    const value = sameIdentity(left, right);
    steps.push({ id, op: 'predicate', predicate: 'same_identity', arguments: { left, right }, value });
    return value;
  };
  const group = /** Evaluate ordered native conditions with the declared all-or-any short circuit. */ (id, op, functions) => {
    let value = op === 'all';
    const visited = [];
    for (const [child, callback] of functions) {
      value = callback(); visited.push(child);
      if ((op === 'all' && !value) || (op === 'any' && value)) break;
    }
    steps.push({ id, op, value, visited, skipped: functions.map(/** Select the declared identity of an ordered condition. */ ([id]) => id).filter(/** Retain condition identities skipped by native short-circuit evaluation. */ id => !visited.includes(id)) });
    return value;
  };
  const owner = /** Compare the current actor with the actual file uploader. */ () => predicate('is_owner', 'actor', 'owner');
  const recipient = /** Compare the current actor with the selected grant recipient. */ () => predicate('is_recipient', 'actor', 'recipient');
  const grant = /** Require both the matching recipient identity and an active grant. */ () => group('has_grant', 'all', [['is_recipient', recipient], ['active', /** Read the actual active-grant input when the recipient branch is reached. */ () => input('active')]]);
  const fileAccess = /** Allow the actual uploader or a currently active named recipient. */ () => group('file_access', 'any', [['is_owner', owner], ['has_grant', grant]]);
  const access = /** Require membership before evaluating native file access. */ () => group('may_access', 'all', [['member', /** Read native membership before the file-access branch. */ () => input('member')], ['file_access', fileAccess]]);
  const ready = /** Compare the stored task status with ready and retain that actual result. */ () => {
    const state = input('task_state'), value = sameIdentity(state, 'ready');
    steps.push({ id: 'ready_value', op: 'constant', value: 'ready' });
    steps.push({ id: 'task_is_ready', op: 'predicate', predicate: 'same_identity', arguments: { left: state, right: 'ready' }, value });
    return value;
  };
  const published = /** Compare the stored announcement status with published. */ () => {
    const state = input('announcement_state'), value = sameIdentity(state, 'published');
    steps.push({ id: 'published_value', op: 'constant', value: 'published' });
    steps.push({ id: 'announcement_is_published', op: 'predicate', predicate: 'same_identity', arguments: { left: state, right: 'published' }, value });
    return value;
  };
  let allowed;
  if (operation === 'login') allowed = input('credentials_valid');
  else if (['upload','logout','read_announcements','list_tasks','list_members'].includes(operation)) allowed = input('member');
  else if (operation === 'manage_share') allowed = group('may_manage', 'all', [['member', /** Read membership for native share management. */ () => input('member')], ['is_owner', owner]]);
  else if (['view_file','request_download'].includes(operation)) allowed = access();
  else if (operation === 'collect_download') allowed = group('may_collect', 'all', [
    ['member', /** Compare the actor with the original task requester. */ () => input('member')], ['task_is_mine', /** Read membership for native artifact collection. */ () => predicate('task_is_mine','actor','requester')],
    ['submission_authorized', /** Read the task authorization persisted at submission. */ () => input('submission_authorized')], ['task_is_ready', ready]
  ]);
  else if (operation === 'publish_announcement') allowed = group('may_publish', 'all', [['member', /** Read membership for native announcement publication. */ () => input('member')], ['editor', /** Read the designated announcement-editor role for publication. */ () => input('editor')]]);
  else if (operation === 'manage_announcement') allowed = group('may_manage_announcement', 'all', [
    ['member', /** Read membership for native announcement modification. */ () => input('member')], ['editor', /** Read the designated announcement-editor role for modification. */ () => input('editor')],
    ['is_author', /** Compare the actor with the actual announcement author. */ () => predicate('is_author','actor','author')], ['announcement_is_published', published]
  ]);
  else throw new Error('UNKNOWN_POLICY_OPERATION');
  return { operation, allowed: Boolean(allowed), facts: { ...facts }, steps };
}
