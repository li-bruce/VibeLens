/** Compare actual supplied identities or enum values without hidden data reads. */
export function sameIdentity(left, right) { return left === right; }

/**
 * Evaluate the application's own policy once, retaining visited expressions.
 * @param {string} operation Native operation name.
 * @param {object} facts Actual facts acquired by the application at this operation's boundary.
 */
export function decide(operation, facts) {
  const steps = [];
  const input = name => {
    const value = facts[name];
    steps.push({ id: name, op: 'input', value });
    return value;
  };
  const predicate = (id, leftName, rightName) => {
    const left = input(leftName), right = input(rightName);
    const value = sameIdentity(left, right);
    steps.push({ id, op: 'predicate', predicate: 'same_identity', arguments: { left, right }, value });
    return value;
  };
  const group = (id, op, functions) => {
    let value = op === 'all';
    const visited = [];
    for (const [child, callback] of functions) {
      value = callback(); visited.push(child);
      if ((op === 'all' && !value) || (op === 'any' && value)) break;
    }
    steps.push({ id, op, value, visited, skipped: functions.map(([id]) => id).filter(id => !visited.includes(id)) });
    return value;
  };
  const owner = () => predicate('is_owner', 'actor', 'owner');
  const recipient = () => predicate('is_recipient', 'actor', 'recipient');
  const grant = () => group('has_grant', 'all', [['is_recipient', recipient], ['active', () => input('active')]]);
  const fileAccess = () => group('file_access', 'any', [['is_owner', owner], ['has_grant', grant]]);
  const access = () => group('may_access', 'all', [['member', () => input('member')], ['file_access', fileAccess]]);
  const ready = () => {
    const state = input('task_state'), value = sameIdentity(state, 'ready');
    steps.push({ id: 'ready_value', op: 'constant', value: 'ready' });
    steps.push({ id: 'task_is_ready', op: 'predicate', predicate: 'same_identity', arguments: { left: state, right: 'ready' }, value });
    return value;
  };
  const published = () => {
    const state = input('announcement_state'), value = sameIdentity(state, 'published');
    steps.push({ id: 'published_value', op: 'constant', value: 'published' });
    steps.push({ id: 'announcement_is_published', op: 'predicate', predicate: 'same_identity', arguments: { left: state, right: 'published' }, value });
    return value;
  };
  let allowed;
  if (operation === 'login') allowed = input('credentials_valid');
  else if (['upload','logout','read_announcements','list_tasks','list_members'].includes(operation)) allowed = input('member');
  else if (operation === 'manage_share') allowed = group('may_manage', 'all', [['member', () => input('member')], ['is_owner', owner]]);
  else if (['view_file','request_download'].includes(operation)) allowed = access();
  else if (operation === 'collect_download') allowed = group('may_collect', 'all', [
    ['member', () => input('member')], ['task_is_mine', () => predicate('task_is_mine','actor','requester')],
    ['submission_authorized', () => input('submission_authorized')], ['task_is_ready', ready]
  ]);
  else if (operation === 'publish_announcement') allowed = group('may_publish', 'all', [['member', () => input('member')], ['editor', () => input('editor')]]);
  else if (operation === 'manage_announcement') allowed = group('may_manage_announcement', 'all', [
    ['member', () => input('member')], ['editor', () => input('editor')],
    ['is_author', () => predicate('is_author','actor','author')], ['announcement_is_published', published]
  ]);
  else throw new Error('UNKNOWN_POLICY_OPERATION');
  return { operation, allowed: Boolean(allowed), facts: { ...facts }, steps };
}
