import express from 'express';
import path from 'node:path';
import { AppError, publicUser } from './service.mjs';

/** Read the application's own session cookie without exposing it to observation. */
export function sessionCookie(req) {
  const value = req.headers.cookie?.split(';').map(value => value.trim()).find(value => value.startsWith('team_session='));
  return value ? value.slice('team_session='.length) : '';
}
/** Build HTTP routes around native business methods; optional observation cannot change decisions. */
export function createApp(service, publicRoot, observer = null) {
  const app = express();
  app.disable('x-powered-by');
  app.use(function originBoundary(req, res, next) {
    res.set('Cache-Control', 'no-store');
    res.set('X-Content-Type-Options', 'nosniff');
    res.set('Referrer-Policy', 'same-origin');
    res.set('Content-Security-Policy', "default-src 'self'; connect-src 'self'; style-src 'self'; script-src 'self'; base-uri 'none'; frame-ancestors 'none'");
    const origin = req.headers.origin;
    if (!['GET','HEAD','OPTIONS'].includes(req.method) && origin && origin !== req.protocol + '://' + req.get('host')) return res.status(403).json({ error: 'ORIGIN_REJECTED' });
    next();
  });
  /** Bind the real matched API boundary before parsers so framework errors remain observable. */
  function observed(id) {
    return function apiBoundary(req, res, next) {
      const complete = observer?.httpStart?.(id, req.method, req.path);
      res.once('finish', () => { try { complete?.(res.statusCode); } catch { /* Observation only. */ } });
      next();
    };
  }
  /** Read the current authenticated member or null for the login screen. */
  async function sessionHandler(req, res) { res.json({ user: publicUser(service.session(sessionCookie(req))) }); }
  /** Authenticate real credentials and issue an HTTP-only session cookie. */
  async function loginHandler(req, res) {
    const result = await service.login(String(req.body?.username || ''), String(req.body?.password || ''));
    res.set('Set-Cookie', 'team_session=' + result.token + '; Path=/; HttpOnly; SameSite=Strict');
    res.json({ user: result.user });
  }
  /** Invalidate the current session and remove its browser cookie. */
  async function logoutHandler(req, res) {
    await service.logout(sessionCookie(req));
    res.set('Set-Cookie', 'team_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0'); res.status(204).end();
  }
  /** List public colleagues for a named sharing action. */
  async function membersHandler(req, res) { res.json({ members: service.members(service.requireActor(sessionCookie(req))) }); }
  /** List the current member's visible file metadata. */
  async function filesHandler(req, res) { res.json(await service.listFiles(service.requireActor(sessionCookie(req)))); }
  /** Return one file only after the native permission check. */
  async function fileHandler(req, res) { res.json(await service.viewFile(service.requireActor(sessionCookie(req)), req.params.id)); }
  /** Accept bounded raw file bytes after authentication. */
  async function uploadHandler(req, res) {
    if (!Buffer.isBuffer(req.body)) throw new AppError(400, 'FILE_BYTES_REQUIRED');
    res.status(201).json(await service.upload(req.actor, String(req.query.name || ''), req.body));
  }
  /** Create an uploader-owned named recipient grant. */
  async function shareHandler(req, res) { res.json(await service.setGrant(service.requireActor(sessionCookie(req)), req.params.id, String(req.body?.recipient_id || ''), true)); }
  /** Revoke one grant without touching already admitted tasks. */
  async function revokeHandler(req, res) { res.json(await service.setGrant(service.requireActor(sessionCookie(req)), req.params.id, req.params.recipient, false)); }
  /** Admit a new preparation task using current file access. */
  async function requestHandler(req, res) { res.status(202).json(await service.requestDownload(service.requireActor(sessionCookie(req)), String(req.body?.file_id || ''))); }
  /** Return only the current requester's task records. */
  async function tasksHandler(req, res) { res.json(await service.listTasks(service.requireActor(sessionCookie(req)))); }
  /** Deliver an actual prepared artifact without consuming the task. */
  async function collectHandler(req, res) {
    const result = await service.collect(service.requireActor(sessionCookie(req)), req.params.id);
    res.set('Content-Type', 'application/octet-stream');
    res.set('Content-Disposition', "attachment; filename*=UTF-8''" + encodeURIComponent(result.name));
    res.send(result.bytes);
  }
  /** Return published announcements to logged-in colleagues. */
  async function boardHandler(req, res) { res.json(await service.announcements(service.requireActor(sessionCookie(req)))); }
  /** Publish under the native editor role check. */
  async function publishHandler(req, res) { res.status(201).json(await service.publish(service.requireActor(sessionCookie(req)), String(req.body?.title || ''), String(req.body?.body || ''))); }
  /** Update only an editor's own announcement. */
  async function editHandler(req, res) { res.json(await service.mutateAnnouncement(service.requireActor(sessionCookie(req)), req.params.id, 'edit', String(req.body?.title || ''), String(req.body?.body || ''))); }
  /** Delete only an editor's own announcement. */
  async function deleteHandler(req, res) { res.json(await service.mutateAnnouncement(service.requireActor(sessionCookie(req)), req.params.id, 'delete')); }
  /** Authenticate before reading uploaded bytes into memory. */
  function uploadActor(req, res, next) { req.actor = service.requireActor(sessionCookie(req)); next(); }

  app.get('/api/auth/session', observed('api_session'), sessionHandler);
  app.post('/api/auth/login', observed('api_login'), express.json({limit:'16kb'}), loginHandler);
  app.post('/api/auth/logout', observed('api_logout'), logoutHandler);
  app.get('/api/members', observed('api_members'), membersHandler);
  app.get('/api/files', observed('api_files'), filesHandler);
  app.get('/api/files/:id', observed('api_file'), fileHandler);
  app.post('/api/files', observed('api_upload'), uploadActor, express.raw({type:'application/octet-stream',limit:'50mb'}), uploadHandler);
  app.post('/api/files/:id/shares', observed('api_share'), express.json({limit:'4kb'}), shareHandler);
  app.delete('/api/files/:id/shares/:recipient', observed('api_revoke'), revokeHandler);
  app.post('/api/tasks', observed('api_request'), express.json({limit:'4kb'}), requestHandler);
  app.get('/api/tasks', observed('api_tasks'), tasksHandler);
  app.get('/api/tasks/:id/download', observed('api_collect'), collectHandler);
  app.get('/api/announcements', observed('api_board'), boardHandler);
  app.post('/api/announcements', observed('api_publish'), express.json({limit:'32kb'}), publishHandler);
  app.put('/api/announcements/:id', observed('api_edit'), express.json({limit:'32kb'}), editHandler);
  app.delete('/api/announcements/:id', observed('api_delete'), deleteHandler);
  app.use('/api', function unknownApi(req, res) { res.status(404).json({ error: 'API_NOT_FOUND' }); });
  app.use(express.static(path.resolve(publicRoot), { index: 'index.html' }));
  /** Preserve framework/parser failures as their real HTTP errors. */
  app.use(function errorHandler(error, req, res, next) {
    if (res.headersSent) return next(error);
    const status = error.status || 500;
    const code = error.code || (status === 413 ? 'UPLOAD_TOO_LARGE' : status === 400 ? 'INVALID_REQUEST' : 'INTERNAL_ERROR');
    res.status(status).json({ error: code });
  });
  return app;
}
