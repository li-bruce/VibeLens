import Database from 'better-sqlite3';
import { mkdirSync } from 'node:fs';
import path from 'node:path';
import { randomBytes, scryptSync } from 'node:crypto';

/** Three synthetic accounts for the explicitly requested local trial. */
export const TEST_ACCOUNTS = [
  { id: 'alice', username: 'alice', display_name: '林澈', editor: false },
  { id: 'bob', username: 'bob', display_name: '陈可', editor: false },
  { id: 'editor', username: 'editor', display_name: '叶青', editor: true }
];
export const TEST_PASSWORD = 'DemoPass!2026';

/** Create the application's SQLite store and retain normal native transaction semantics. */
export class Store {
  /** @param {string} filename Project-local SQLite filename. */
  constructor(filename) {
    mkdirSync(path.dirname(filename), { recursive: true });
    this.db = new Database(filename);
    this.db.pragma('journal_mode = WAL');
    this.db.pragma('foreign_keys = ON');
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY, username TEXT NOT NULL UNIQUE, display_name TEXT NOT NULL,
        password_salt TEXT NOT NULL, password_hash TEXT NOT NULL, editor INTEGER NOT NULL CHECK(editor IN (0,1))
      );
      CREATE TABLE IF NOT EXISTS sessions (
        token_hash TEXT PRIMARY KEY, trace_id TEXT NOT NULL UNIQUE, user_id TEXT NOT NULL REFERENCES users(id),
        status TEXT NOT NULL CHECK(status IN ('active','ended')), revision INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL
      );
      CREATE TABLE IF NOT EXISTS files (
        id TEXT PRIMARY KEY, owner_id TEXT NOT NULL REFERENCES users(id), name TEXT NOT NULL,
        size INTEGER NOT NULL CHECK(size >= 0), sha256 TEXT NOT NULL, storage_path TEXT NOT NULL,
        created_at TEXT NOT NULL, revision INTEGER NOT NULL DEFAULT 1
      );
      CREATE TABLE IF NOT EXISTS grants (
        file_id TEXT NOT NULL REFERENCES files(id), recipient_id TEXT NOT NULL REFERENCES users(id),
        active INTEGER NOT NULL CHECK(active IN (0,1)), revision INTEGER NOT NULL DEFAULT 1,
        PRIMARY KEY(file_id, recipient_id)
      );
      CREATE TABLE IF NOT EXISTS tasks (
        id TEXT PRIMARY KEY, file_id TEXT NOT NULL REFERENCES files(id), requester_id TEXT NOT NULL REFERENCES users(id),
        authorized_at_submission INTEGER NOT NULL CHECK(authorized_at_submission=1),
        status TEXT NOT NULL CHECK(status IN ('queued','preparing','ready')),
        prepared_path TEXT, sha256 TEXT, last_error TEXT, created_at TEXT NOT NULL,
        started_at TEXT, ready_at TEXT, revision INTEGER NOT NULL DEFAULT 1
      );
      CREATE TABLE IF NOT EXISTS announcements (
        id TEXT PRIMARY KEY, author_id TEXT NOT NULL REFERENCES users(id), title TEXT NOT NULL,
        body TEXT NOT NULL, status TEXT NOT NULL CHECK(status IN ('published','deleted')),
        created_at TEXT NOT NULL, updated_at TEXT NOT NULL, revision INTEGER NOT NULL DEFAULT 1
      );
    `);
    const insert = this.db.prepare('INSERT OR IGNORE INTO users VALUES (@id,@username,@display_name,@salt,@hash,@editor)');
    this.db.transaction(() => {
      for (const account of TEST_ACCOUNTS) {
        const salt = randomBytes(16).toString('hex');
        insert.run({ ...account, editor: Number(account.editor), salt, hash: scryptSync(TEST_PASSWORD, salt, 32).toString('hex') });
      }
    })();
  }
  /** Read one native SQLite row; callers select fields before observation. */
  get(sql, ...parameters) { return this.db.prepare(sql).get(...parameters); }
  /** Read native SQLite rows without an observer-owned second business query. */
  all(sql, ...parameters) { return this.db.prepare(sql).all(...parameters); }
  /** Execute a bound native SQLite mutation. */
  run(sql, ...parameters) { return this.db.prepare(sql).run(...parameters); }
  /** Commit or roll back the actual synchronous database transaction. */
  transaction(operation) { return this.db.transaction(operation).immediate(); }
  /** Close this application's database connection. */
  close() { this.db.close(); }
}
