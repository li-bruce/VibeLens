import { randomUUID, randomBytes, createHash, scryptSync, timingSafeEqual } from 'node:crypto';
import { mkdir, writeFile, copyFile, readFile, rename, unlink } from 'node:fs/promises';
import path from 'node:path';
import { AsyncLocalStorage } from 'node:async_hooks';
import { decide } from './policy.mjs';

/** A typed application error with a stable public code and actual HTTP outcome. */
export class AppError extends Error {
  constructor(status, code) { super(code); this.status = status; this.code = code; }
}
/** Select public member fields; credentials and session identifiers remain private. */
export function publicUser(user) {
  return user ? { id: user.id, username: user.username, display_name: user.display_name, editor: Boolean(user.editor) } : null;
}
/** Hash a session token for lookup; never return its hash through observations. */
export function tokenHash(token) { return createHash('sha256').update(token || '').digest('hex'); }

/** Native business service; observation callbacks never authorize or execute operations. */
export class FileService {
  /** @param {Store} store Actual SQLite store. @param {string} root Local application data root. */
  constructor(store, root) {
    this.store = store; this.root = path.resolve(root);
    this.listeners = new Set(); this.context = new AsyncLocalStorage(); this.workerBusy = false; this.stopped = false;
    this.workerDelay = 20;
  }
  /** Subscribe to selected domain facts; subscriber failure is isolated. */
  subscribe(listener) { this.listeners.add(listener); return () => this.listeners.delete(listener); }
  /** Publish a fact already produced by native execution. */
  notify(event) { for (const listener of this.listeners) { try { listener(event); } catch { /* Observation cannot change business execution. */ } } }
  /** Own the real native operation lifetime and return its actual outcome. */
  async operation(name, inputs, action) {
    const invocationId = randomUUID(), candidateParent = this.context.getStore();
    const parent = candidateParent?.active ? candidateParent : null;
    const context = { invocationId, parentInvocationId: parent?.invocationId || null, name, active: true };
    this.notify({ ...context, phase: 'enter', inputs });
    try {
      const result = await this.context.run(context, () => action(context));
      context.active = false;
      this.notify({ ...context, phase: 'return', inputs, outputs: result?.observation || result || {} });
      return result;
    } catch (error) {
      context.active = false;
      this.notify({ ...context, phase: 'error', inputs, outputs: { error: error.code || 'INTERNAL_ERROR', status: error.status || 500 }, exception: error.name });
      throw error;
    }
  }
  /** Evaluate actual native policy and preserve its selected facts and short circuits. */
  authorize(operation, facts, context) {
    const decision = decide(operation, facts);
    this.notify({ ...context, phase: 'policy', decision });
    if (!decision.allowed) throw new AppError(403, 'ACCESS_DENIED');
    return decision;
  }
  /** Publish the actual native row state at a completed storage boundary. */
  state(model, id, row, event, context, before = null, committed = true) {
    this.notify({ ...context, phase: 'state', model, id, state: row.status, revision: row.revision, row, event, before, committed });
  }
  /** Read the actual current user for an active session token. */
  session(token) {
    if (!token) return null;
    const row = this.store.get("SELECT s.trace_id,s.status,s.revision,u.* FROM sessions s JOIN users u ON s.user_id=u.id WHERE s.token_hash=? AND s.status='active'", tokenHash(token));
    return row || null;
  }
  /** Verify a real password and persist a new session. Passwords never enter selected facts. */
  async login(username, password) {
    return this.operation('login', { username, password_supplied: Boolean(password) }, async context => {
      const user = this.store.get('SELECT * FROM users WHERE username=?', username);
      const actual = scryptSync(password || '', user?.password_salt || 'missing-user-salt', 32);
      const expected = user ? Buffer.from(user.password_hash, 'hex') : Buffer.alloc(32);
      const valid = Boolean(user) && timingSafeEqual(actual, expected);
      try { this.authorize('login', { credentials_valid: valid }, context); }
      catch { throw new AppError(401, 'INVALID_CREDENTIALS'); }
      const token = randomBytes(32).toString('hex'), id = randomUUID();
      this.state('session', id, { status: 'absent', revision: 0, user_id: user.id }, null, context);
      this.store.run("INSERT INTO sessions VALUES (?, ?, ?, 'active', 1, ?)", tokenHash(token), id, user.id, new Date().toISOString());
      this.state('session', id, { status: 'active', revision: 1, user_id: user.id }, 'login', context, 'absent');
      return { token, user: publicUser(user), observation: { allowed: true, user_id: user.id, editor: Boolean(user.editor), session_id: id } };
    });
  }
  /** End only the current session and retain its native nonsecret state identity. */
  async logout(token) {
    const actor = this.session(token);
    return this.operation('logout', { actor_id: actor?.id || '' }, async context => {
      this.authorize('logout', { member: Boolean(actor) }, context);
      this.store.run("UPDATE sessions SET status='ended',revision=revision+1 WHERE token_hash=?", tokenHash(token));
      this.state('session', actor.trace_id, { status: 'ended', revision: actor.revision + 1, user_id: actor.id }, 'logout', context, 'active');
      return { allowed: true, user_id: actor.id };
    });
  }
  /** Require a genuine active session for protected application operations. */
  requireActor(token) { const actor = this.session(token); if (!actor) throw new AppError(401, 'LOGIN_REQUIRED'); return actor; }
  /** Return public teammates for the uploader's named-recipient picker. */
  members(actor) { if (!actor) throw new AppError(401, 'LOGIN_REQUIRED'); return this.store.all('SELECT id,username,display_name,editor FROM users ORDER BY username').map(publicUser); }
  /** Acquire the current file and grant facts at the native authorization boundary. */
  fileFacts(actor, fileId) {
    const file = this.store.get('SELECT * FROM files WHERE id=?', fileId);
    if (!file) throw new AppError(404, 'FILE_NOT_FOUND');
    const grant = this.store.get('SELECT * FROM grants WHERE file_id=? AND recipient_id=?', fileId, actor.id);
    return { file, grant, facts: { member: true, actor: actor.id, owner: file.owner_id, recipient: actor.id, active: Boolean(grant?.active) } };
  }
  /** List only files the current colleague can see; do not expose hidden metadata. */
  async listFiles(actor) {
    return this.operation('list_files', { actor_id: actor.id }, async context => {
      const rows = this.store.all('SELECT f.*,u.display_name AS owner_name FROM files f JOIN users u ON f.owner_id=u.id ORDER BY f.created_at DESC');
      const visible = [];
      for (const file of rows) {
        const { facts } = this.fileFacts(actor, file.id), decision = decide('view_file', facts);
        this.notify({ ...context, phase: 'policy', decision });
        if (decision.allowed) {
          const grants = file.owner_id === actor.id ? this.store.all('SELECT g.recipient_id,g.active,u.display_name FROM grants g JOIN users u ON u.id=g.recipient_id WHERE g.file_id=?', file.id) : [];
          visible.push({ id: file.id, name: file.name, size: file.size, sha256: file.sha256, owner_id: file.owner_id, owner_name: file.owner_name, created_at: file.created_at, mine: file.owner_id === actor.id, grants });
        }
      }
      return { files: visible, count: visible.length };
    });
  }
  /** Read one visible file without returning its private storage path. */
  async viewFile(actor, fileId) {
    return this.operation('view_file', { actor_id: actor.id, file_id: fileId }, async context => {
      const { file, facts } = this.fileFacts(actor, fileId); this.authorize('view_file', facts, context);
      return { id: file.id, name: file.name, size: file.size, owner_id: file.owner_id, allowed: true };
    });
  }
  /** Persist uploaded bytes under a generated filename and their actual metadata. */
  async upload(actor, name, bytes) {
    return this.operation('upload_file', { actor_id: actor.id, name, byte_count: bytes.length }, async context => {
      this.authorize('upload', { member: true }, context);
      if (!name.trim() || name.length > 180) throw new AppError(400, 'INVALID_FILENAME');
      const id = randomUUID(), storagePath = path.join(this.root, 'uploads', id);
      await mkdir(path.dirname(storagePath), { recursive: true });
      await writeFile(storagePath, bytes, { flag: 'wx' });
      const sha = createHash('sha256').update(bytes).digest('hex');
      try { this.store.run('INSERT INTO files(id,owner_id,name,size,sha256,storage_path,created_at) VALUES (?,?,?,?,?,?,?)', id, actor.id, name, bytes.length, sha, storagePath, new Date().toISOString()); }
      catch (error) { await unlink(storagePath).catch(() => {}); throw error; }
      return { id, name, size: bytes.length, sha256: sha, owner_id: actor.id, allowed: true };
    });
  }
  /** Create or revoke one named grant; recipient role never permits this operation. */
  async setGrant(actor, fileId, recipientId, active) {
    return this.operation(active ? 'share_file' : 'revoke_share', { actor_id: actor.id, file_id: fileId, recipient_id: recipientId }, async context => {
      const { facts } = this.fileFacts(actor, fileId); this.authorize('manage_share', facts, context);
      if (!this.store.get('SELECT id FROM users WHERE id=?', recipientId) || recipientId === actor.id) throw new AppError(400, 'INVALID_RECIPIENT');
      const prior = this.store.get('SELECT * FROM grants WHERE file_id=? AND recipient_id=?', fileId, recipientId);
      const before = prior?.active ? 'active' : 'inactive', revision = (prior?.revision || 0) + 1;
      if (!prior) this.state('grant', fileId + '/' + recipientId, { status: 'inactive', revision: 0 }, null, context);
      this.store.run('INSERT INTO grants(file_id,recipient_id,active,revision) VALUES(?,?,?,?) ON CONFLICT(file_id,recipient_id) DO UPDATE SET active=excluded.active,revision=excluded.revision', fileId, recipientId, Number(active), revision);
      this.state('grant', fileId + '/' + recipientId, { status: active ? 'active' : 'inactive', revision }, active ? 'share' : 'revoke', context, before);
      return { file_id: fileId, recipient_id: recipientId, active, revision, allowed: true };
    });
  }
  /** Atomically admit one task using current file access and persist that task's authorization. */
  async requestDownload(actor, fileId) {
    const result = await this.operation('request_download', { actor_id: actor.id, file_id: fileId }, async context => {
      const id = randomUUID(), transactionId = randomUUID();
      this.state('download_task', id, { status: 'created', revision: 0, authorized_at_submission: false, requester_id: actor.id, file_id: fileId }, null, context);
      this.store.transaction(() => {
        const { facts } = this.fileFacts(actor, fileId); this.authorize('request_download', facts, context);
        this.store.run("INSERT INTO tasks(id,file_id,requester_id,authorized_at_submission,status,created_at) VALUES(?,?,?,1,'queued',?)", id, fileId, actor.id, new Date().toISOString());
      });
      const row = this.store.get('SELECT * FROM tasks WHERE id=?', id);
      this.notify({ ...context, phase: 'commit', transaction_id: transactionId, task_id: id, committed: true, authorized_at_submission: true });
      this.state('download_task', id, row, 'enqueue', context, 'created');
      return { task_id: id, file_id: fileId, requester_id: actor.id, status: row.status, authorized_at_submission: true, transaction_id: transactionId, committed: true, allowed: true };
    });
    this.scheduleWorker(); return result;
  }
  /** List this requester's own task records independently of current file visibility. */
  async listTasks(actor) {
    return this.operation('list_tasks', { actor_id: actor.id }, async () => ({
      tasks: this.store.all('SELECT t.id,t.file_id,t.requester_id,t.authorized_at_submission,t.status,t.sha256,t.last_error,t.created_at,t.started_at,t.ready_at,t.revision,f.name,f.size FROM tasks t JOIN files f ON f.id=t.file_id WHERE t.requester_id=? ORDER BY t.created_at DESC', actor.id)
    }));
  }
  /** Schedule real preparation after request completion; a task retains its original authorization. */
  scheduleWorker() {
    if (!this.workerBusy && !this.stopped) {
      this.workerBusy = true;
      this.workerTimer = setTimeout(() => { this.workerRunning = this.drainWorker().finally(() => { this.workerBusy = false; if (!this.stopped && this.store.get("SELECT id FROM tasks WHERE status='queued'")) this.scheduleWorker(); }); }, this.workerDelay);
    }
  }
  /** Prepare each queued file through actual filesystem copying and integrity verification. */
  async drainWorker() {
    while (!this.stopped) {
      const row = this.store.get("SELECT * FROM tasks WHERE status='queued' ORDER BY created_at,id LIMIT 1");
      if (!row) break;
      try {
        await this.operation('prepare_download', { task_id: row.id, requester_id: row.requester_id, file_id: row.file_id }, async context => {
          this.store.run("UPDATE tasks SET status='preparing',started_at=?,revision=revision+1 WHERE id=?", new Date().toISOString(), row.id);
          this.state('download_task', row.id, this.store.get('SELECT * FROM tasks WHERE id=?', row.id), 'start', context, 'queued');
          const file = this.store.get('SELECT * FROM files WHERE id=?', row.file_id);
          const target = path.join(this.root, 'prepared', row.id), temporary = target + '.part';
          await mkdir(path.dirname(target), { recursive: true }); await copyFile(file.storage_path, temporary);
          const actual = createHash('sha256').update(await readFile(temporary)).digest('hex');
          if (actual !== file.sha256) throw new AppError(500, 'PREPARATION_CHECKSUM_MISMATCH');
          await rename(temporary, target);
          return await this.operation('mark_download_ready', { task_id: row.id }, async done => {
            this.store.run("UPDATE tasks SET status='ready',prepared_path=?,sha256=?,ready_at=?,last_error=NULL,revision=revision+1 WHERE id=?", target, actual, new Date().toISOString(), row.id);
            const ready = this.store.get('SELECT * FROM tasks WHERE id=?', row.id);
            this.state('download_task', row.id, ready, 'finish', done, 'preparing');
            return { task_id: row.id, status: 'ready', sha256: actual, allowed: true };
          });
        });
      } catch (error) {
        this.store.run('UPDATE tasks SET last_error=? WHERE id=?', error.code || 'PREPARATION_ERROR', row.id);
        this.notify({ name: 'worker_error', phase: 'diagnostic', task_id: row.id, error: error.code || 'PREPARATION_ERROR' });
      }
    }
  }
  /** Recheck requester/session/readiness, using persisted submission authorization instead of current grants. */
  async collect(actor, taskId) {
    return this.operation('collect_download', { actor_id: actor.id, task_id: taskId }, async context => {
      const row = this.store.get('SELECT t.*,f.name,f.size FROM tasks t JOIN files f ON f.id=t.file_id WHERE t.id=?', taskId);
      if (!row) throw new AppError(404, 'TASK_NOT_FOUND');
      this.authorize('collect_download', { member: true, actor: actor.id, requester: row.requester_id, submission_authorized: Boolean(row.authorized_at_submission), task_state: row.status }, context);
      const bytes = await readFile(row.prepared_path);
      return { bytes, name: row.name, observation: { task_id: row.id, requester_id: row.requester_id, status: row.status, byte_count: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex'), allowed: true } };
    });
  }
  /** Read the independent board for authenticated colleagues. */
  async announcements(actor) {
    return this.operation('read_announcements', { actor_id: actor.id }, async context => {
      this.authorize('read_announcements', { member: true }, context);
      return { announcements: this.store.all("SELECT a.*,u.display_name AS author_name FROM announcements a JOIN users u ON u.id=a.author_id WHERE a.status='published' ORDER BY a.updated_at DESC") };
    });
  }
  /** Publish one announcement as its designated editor author. */
  async publish(actor, title, body) {
    return this.operation('publish_announcement', { actor_id: actor.id, title, body_length: body.length }, async context => {
      this.authorize('publish_announcement', { member: true, editor: Boolean(actor.editor) }, context);
      this.validateAnnouncement(title, body); const id = randomUUID(), now = new Date().toISOString();
      this.state('announcement', id, { status: 'absent', revision: 0, author_id: actor.id }, null, context);
      this.store.run("INSERT INTO announcements VALUES(?,?,?,?,'published',?,?,1)", id, actor.id, title.trim(), body, now, now);
      const row = this.store.get('SELECT * FROM announcements WHERE id=?', id); this.state('announcement', id, row, 'publish', context, 'absent');
      return { id, author_id: actor.id, title: row.title, status: row.status, revision: row.revision, allowed: true };
    });
  }
  /** Edit/delete only the authenticated editor's own published announcement. */
  async mutateAnnouncement(actor, id, action, title = '', body = '') {
    return this.operation(action === 'delete' ? 'delete_announcement' : 'edit_announcement', { actor_id: actor.id, announcement_id: id, title, body_length: body.length }, async context => {
      const row = this.store.get('SELECT * FROM announcements WHERE id=?', id); if (!row) throw new AppError(404, 'ANNOUNCEMENT_NOT_FOUND');
      this.authorize('manage_announcement', { member: true, editor: Boolean(actor.editor), actor: actor.id, author: row.author_id, announcement_state: row.status }, context);
      if (action === 'edit') { this.validateAnnouncement(title, body); this.store.run('UPDATE announcements SET title=?,body=?,updated_at=?,revision=revision+1 WHERE id=?', title.trim(), body, new Date().toISOString(), id); }
      else this.store.run("UPDATE announcements SET status='deleted',updated_at=?,revision=revision+1 WHERE id=?", new Date().toISOString(), id);
      const changed = this.store.get('SELECT * FROM announcements WHERE id=?', id); this.state('announcement', id, changed, action, context, row.status);
      return { id, status: changed.status, revision: changed.revision, allowed: true };
    });
  }
  /** Validate bounded announcement input without rendering it as HTML. */
  validateAnnouncement(title, body) {
    if (!title.trim() || title.length > 120 || !body.trim() || body.length > 8000) throw new AppError(400, 'INVALID_ANNOUNCEMENT');
  }
  /** Stop task scheduling before closing native storage. */
  async stop() { this.stopped = true; clearTimeout(this.workerTimer); while (this.workerBusy && this.workerRunning) await this.workerRunning; }
}
