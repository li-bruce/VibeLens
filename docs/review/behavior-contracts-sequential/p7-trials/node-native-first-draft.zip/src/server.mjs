import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Store } from './store.mjs';
import { FileService } from './service.mjs';
import { createApp } from './http.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const data = path.resolve(process.env.APP_DATA_ROOT || path.join(root, 'var'));
const store = new Store(path.join(data, 'db', 'application.sqlite'));
const service = new FileService(store, data);
let observer = null;
if (process.env.VIBELENS_ENABLED === '1') {
  try {
    const module = await import('../integrations/bo_observe.mjs');
    observer = await module.bo_start(service, root);
  } catch (error) {
    console.error('Observer unavailable:', error.message);
  }
}
const app = createApp(service, path.join(root, 'public'), observer);
const server = app.listen(Number(process.env.PORT || 8925), '127.0.0.1', () => {
  console.log('Team files: http://127.0.0.1:' + server.address().port);
});
service.scheduleWorker();
/** Release the native worker and optional observer during controlled shutdown. */
async function shutdown() {
  server.close();
  await service.stop();
  await observer?.close?.();
  store.close();
}
process.once('SIGINT', shutdown);
process.once('SIGTERM', shutdown);
