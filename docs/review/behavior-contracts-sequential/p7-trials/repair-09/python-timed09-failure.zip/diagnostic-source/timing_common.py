"""Opt-in timing metadata. Original calls, payloads, return objects and errors are preserved."""
import atexit
from contextvars import ContextVar
from functools import wraps
from itertools import count
import json
import os
from pathlib import Path
from queue import Queue, Full
import sys
import threading
import time
from urllib.parse import urlsplit
from weakref import WeakKeyDictionary

def safe_url(value):
    parsed=urlsplit(str(value))
    return {"scheme":parsed.scheme,"host":parsed.hostname,"port":parsed.port,"path":parsed.path}

def error_metadata(error,depth=0):
    result={"exception_type":type(error).__name__}
    for key in ("code","errno","winerror"):
        try: value=getattr(error,key,None)
        except Exception: continue
        if type(value) is int: result[key]=value
    try: reason=getattr(error,"reason",None)
    except Exception: reason=None
    if isinstance(reason,BaseException) and reason is not error and depth<2:
        result["reason"]=error_metadata(reason,depth+1)
    return result

def envelope_metadata(value):
    if not isinstance(value,dict): return {}
    result={key:value[key] for key in ("protocol","project_id","build_id","run_id","producer_id") if isinstance(value.get(key),str)}
    if value.get("protocol")=="bo-event-batch/v1":
        events=value.get("events")
        if isinstance(events,list):
            result.update(batch_count=len(events))
            if events and all(isinstance(item,dict) for item in events):
                result.update(first_event_id=events[0].get("id"),last_event_id=events[-1].get("id"),source_sequences=[item.get("seq") for item in events])
                result.update({key:events[0].get(key) for key in ("run_id","producer_id","build_id")})
    elif value.get("protocol")=="bo-event/v1":
        result.update({key:value[key] for key in ("id","node","phase","seq") if key in value})
    elif value.get("protocol") in ("bo-snapshot/v1","bo-snapshot/v2"):
        result.update({key:value[key] for key in ("evidence_id","state_model_id","instance_id","revision") if key in value})
    elif value.get("protocol")=="bo-capture-control/v1":
        result["action"]=value.get("action")
        health=(value.get("ack") or {}).get("health") if isinstance(value.get("ack"),dict) else None
        if isinstance(health,dict):
            result["ack_health"]={key:health[key] for key in ("errors","dropped","pending","queue_submitted","queue_completed","flush_target") if type(health.get(key)) is int}
            last=health.get("last_error")
            if isinstance(last,dict):
                result["ack_health"]["last_error"]={key:last[key] for key in ("stage","type") if isinstance(last.get(key),str)}
    return result

class Recorder:
    """One bounded asynchronous diagnostic writer, separate from native capture."""
    def __init__(self,destination,role):
        self.path=Path(destination)
        self.role=role
        self.sequence=count(1)
        self.queue=Queue(65536)
        self.lost=0
        self.write_errors=[]
        self.http=ContextVar("diag_http",default=None)
        self.calls=ContextVar("diag_calls",default=())
        self.writer=None
        self.closed=False

    def emit(self,event):
        try:
            self.queue.put_nowait({"wall_ms":time.time_ns()/1e6,"mono_ns":str(time.perf_counter_ns()),"pid":os.getpid(),"thread_id":threading.get_ident(),"thread_name":threading.current_thread().name,"role":self.role,**event})
        except Exception:
            self.lost+=1

    def start(self):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        if self.path.exists(): raise FileExistsError("Preserve the previous diagnostic trace")
        def write():
            try:
                with self.path.open("x",encoding="utf-8",buffering=1) as stream:
                    while True:
                        event=self.queue.get()
                        if event is None: break
                        stream.write(json.dumps(event,ensure_ascii=False,allow_nan=False)+"\n")
            except Exception as error:
                self.write_errors.append(type(error).__name__)
        self.writer=threading.Thread(target=write,name="diagnostic-timing-writer",daemon=True)
        self.writer.start()
        atexit.register(self.close)

    def close(self):
        if self.closed: return
        self.closed=True
        self.emit({"event":"diagnostic_shutdown","lost":self.lost,"write_errors":self.write_errors})
        try: self.queue.put_nowait(None)
        except Full: self.lost+=1
        if self.writer: self.writer.join(2)

    def wrap(self,original,name,describe=None):
        @wraps(original)
        def timed(*args,**kwargs):
            identity=next(self.sequence)
            parents=self.calls.get()
            request=self.http.get()
            meta={}
            if describe:
                try: meta=describe(args,kwargs)
                except Exception as error: meta={"metadata_error":type(error).__name__}
            common={"method":name,"diag_call_id":identity,"parent_diag_call_id":parents[-1] if parents else None,"http":dict(request) if request else None,**meta}
            self.emit({"event":"method_start",**common})
            token=self.calls.set(parents+(identity,))
            started=time.perf_counter_ns()
            failure={}
            try: return original(*args,**kwargs)
            except BaseException as error:
                failure=error_metadata(error)
                raise
            finally:
                self.calls.reset(token)
                self.emit({"event":"method_end",**common,"elapsed_ms":(time.perf_counter_ns()-started)/1e6,**failure})
        return timed

def provenance(root,provider):
    manifest=json.loads((root/"manifest.json").read_text(encoding="utf-8"))
    settings_path=root/".stategraph/collector.json"
    settings=json.loads(settings_path.read_text(encoding="utf-8")) if settings_path.exists() else {}
    modules={name:str(Path(module.__file__).resolve()) for name,module in list(sys.modules.items()) if name.startswith("bo_observer") and getattr(module,"__file__",None)}
    wrong={name:path for name,path in modules.items() if not Path(path).is_relative_to(provider/"scripts")}
    if wrong: raise RuntimeError("Loaded observer modules differ from the selected provider")
    return {"root":str(root),"provider":str(provider),"manifest_build":manifest["build_id"],"collector_build":settings.get("build_id"),"external_module_origins":modules,"unexpected_module_origins":wrong}

def install_urllib(recorder):
    """Time standard urllib without changing an argument, response type or retry."""
    import http.client
    import urllib.request
    original_open=urllib.request.urlopen
    original_headers=http.client.HTTPConnection.endheaders
    original_read=http.client.HTTPResponse.read
    responses=WeakKeyDictionary()
    connections=WeakKeyDictionary()
    lock=threading.Lock()
    active=ContextVar("diag_urllib_request",default=None)

    @wraps(original_open)
    def urlopen(*args,**kwargs):
        meta={}
        try:
            request=args[0] if args else kwargs.get("url")
            address=getattr(request,"full_url",request)
            body=getattr(request,"data",None)
            if body is None: body=kwargs.get("data",args[1] if len(args)>1 else None)
            method=request.get_method() if hasattr(request,"get_method") else ("POST" if body is not None else "GET")
            meta.update(method=method,url=safe_url(address))
            if isinstance(body,(bytes,bytearray)):
                meta["body_bytes"]=len(body)
                if len(body)<=262144:
                    try: meta.update(envelope_metadata(json.loads(body)))
                    except Exception: pass
        except Exception as error:
            meta["metadata_error"]=type(error).__name__
        timeout=kwargs.get("timeout",args[2] if len(args)>2 else "global-default")
        if not isinstance(timeout,(int,float,str,type(None))): timeout="global-default"
        identity=next(recorder.sequence)
        state={"request_id":identity,"timeout_seconds":timeout,**meta}
        started=time.perf_counter_ns()
        recorder.emit({"event":"client_open_start",**state})
        token=active.set(state)
        try:
            response=original_open(*args,**kwargs)
            try:
                with lock: responses[response]=(dict(state),started)
            except Exception as error:
                recorder.emit({"event":"response_metadata_error","request_id":identity,"exception_type":type(error).__name__})
            recorder.emit({"event":"client_headers_received",**state,"status":getattr(response,"status",None),"elapsed_ms":(time.perf_counter_ns()-started)/1e6})
            return response
        except BaseException as error:
            recorder.emit({"event":"client_open_error",**state,"elapsed_ms":(time.perf_counter_ns()-started)/1e6,**error_metadata(error)})
            raise
        finally: active.reset(token)

    @wraps(original_headers)
    def endheaders(connection,*args,**kwargs):
        state=active.get()
        started=time.perf_counter_ns()
        try:
            result=original_headers(connection,*args,**kwargs)
        except BaseException as error:
            if state: recorder.emit({"event":"client_send_error",**state,"elapsed_ms":(time.perf_counter_ns()-started)/1e6,**error_metadata(error)})
            raise
        if state:
            endpoint={}
            try:
                if connection.sock is not None:
                    local=connection.sock.getsockname()
                    remote=connection.sock.getpeername()
                    endpoint={"local_address":local[0],"local_port":local[1],"remote_address":remote[0],"remote_port":remote[1]}
                with lock:
                    identity,ordinal=connections.get(connection,(next(recorder.sequence),0))
                    connections[connection]=(identity,ordinal+1)
                endpoint.update(connection_id=identity,connection_request_index=ordinal+1)
            except Exception as error: endpoint={"socket_metadata_error":type(error).__name__}
            recorder.emit({"event":"client_send_headers_complete",**state,**endpoint,"elapsed_ms":(time.perf_counter_ns()-started)/1e6})
        return result

    @wraps(original_read)
    def read(response,*args,**kwargs):
        try:
            with lock: state=responses.get(response)
        except Exception:
            state=None
        if state is None: return original_read(response,*args,**kwargs)
        metadata,request_started=state
        started=time.perf_counter_ns()
        recorder.emit({"event":"client_read_start",**metadata})
        try:
            value=original_read(response,*args,**kwargs)
            recorder.emit({"event":"client_read_end",**metadata,"read_bytes":len(value),"elapsed_ms":(time.perf_counter_ns()-started)/1e6,"request_through_read_ms":(time.perf_counter_ns()-request_started)/1e6})
            return value
        except BaseException as error:
            recorder.emit({"event":"client_read_error",**metadata,"elapsed_ms":(time.perf_counter_ns()-started)/1e6,"request_through_read_ms":(time.perf_counter_ns()-request_started)/1e6,**error_metadata(error)})
            raise

    urllib.request.urlopen=urlopen
    http.client.HTTPConnection.endheaders=endheaders
    http.client.HTTPResponse.read=read
    recorder.emit({"event":"urllib_timing_installed","hooks":["urllib.request.urlopen","http.client.HTTPConnection.endheaders","http.client.HTTPResponse.read"],"headers_or_bodies_changed":False,"response_proxy_used":False,"retry_added":False,"deadlines_changed":False})

def install_server(recorder):
    """Wrap selected installed call sites in this new diagnostic process only."""
    from bo_observer import protocol
    original_validate=protocol.validate_project
    protocol.validate_project=recorder.wrap(original_validate,"protocol.validate_project")
    from bo_observer.observation.session import GraphSession
    from bo_observer.observation.event_batch import BOSessionSink
    from bo_observer.data.watcher import DataWatch
    from bo_observer import service
    aliases=[]
    for name,module in list(sys.modules.items()):
        if not name.startswith("bo_observer.") or module is None: continue
        for key,value in list(vars(module).items()):
            if value is original_validate:
                setattr(module,key,protocol.validate_project)
                aliases.append(name+"."+key)
    def single(args,kwargs): return envelope_metadata(args[1])
    def batch(args,kwargs): return envelope_metadata({"protocol":"bo-event-batch/v1","events":args[1]})
    targets=[(GraphSession,"event",single),(GraphSession,"snapshot",single),(GraphSession,"binding",None),(GraphSession,"_view_model",None),(GraphSession,"view",None),(BOSessionSink,"bo_accept_many",batch),(DataWatch,"tick",None)]
    for owner,name,describe in targets:
        setattr(owner,name,recorder.wrap(getattr(owner,name),owner.__name__+"."+name,describe))
    original_factory=service.make_server

    @wraps(original_factory)
    def make_server(*args,**kwargs):
        server=original_factory(*args,**kwargs)
        handler_class=server.RequestHandlerClass
        original_reply=handler_class.reply
        def reply_meta(values,kw):
            code=values[1]
            body=values[2] if len(values)>2 else kw.get("body")
            meta={"status":code}
            if isinstance(body,dict):
                if type(body.get("accepted")) is bool: meta["accepted"]=body["accepted"]
                if isinstance(body.get("errors"),list): meta["reported_error_count"]=len(body["errors"])
                if isinstance(body.get("commands"),list):
                    meta["control_actions"]=[item.get("action") for item in body["commands"] if isinstance(item,dict)]
                    meta["flush_timeouts_ms"]=[item.get("timeout_ms") for item in body["commands"] if isinstance(item,dict) and item.get("action")=="flush"]
            return meta
        timed_reply=recorder.wrap(original_reply,"Handler.reply",reply_meta)
        @wraps(original_reply)
        def reply(handler,code,*values,**kw):
            state=recorder.http.get()
            if state is not None: state["status"]=code
            return timed_reply(handler,code,*values,**kw)
        handler_class.reply=reply
        for name in ("do_GET","do_POST","do_OPTIONS"):
            original=getattr(handler_class,name)
            def dispatch(original):
                @wraps(original)
                def request(handler,*values,**kw):
                    ordinal=getattr(handler,"_project_diag_ordinal",0)+1
                    handler._project_diag_ordinal=ordinal
                    state={"request_id":next(recorder.sequence),"method":handler.command,"path":urlsplit(handler.path).path,"peer_address":handler.client_address[0],"peer_port":handler.client_address[1],"server_port":handler.server.server_port,"connection_request_index":ordinal,"status":None}
                    token=recorder.http.set(state)
                    recorder.emit({"event":"http_start","http":dict(state)})
                    started=time.perf_counter_ns()
                    failure={}
                    try: return original(handler,*values,**kw)
                    except BaseException as error:
                        failure=error_metadata(error)
                        raise
                    finally:
                        recorder.emit({"event":"http_end","http":dict(state),"elapsed_ms":(time.perf_counter_ns()-started)/1e6,**failure})
                        recorder.http.reset(token)
                return request
            setattr(handler_class,name,dispatch(original))
        try:
            session=server.bo_session
            recorder.emit({"event":"server_bound","project_id":session.project["project_id"],"actual_build":session.manifest["build_id"],"port":server.server_port})
        except Exception as error:
            recorder.emit({"event":"server_identity_metadata_error","exception_type":type(error).__name__})
        return server
    service.make_server=make_server
    recorder.emit({"event":"server_timing_installed","methods":["protocol.validate_project",*[owner.__name__+"."+name for owner,name,_ in targets],"Handler.reply"],"validate_project_aliases":aliases,"http_hooks":["do_GET","do_POST","do_OPTIONS"],"locks_replaced":False,"headers_or_bodies_changed":False})
