# Selected-method timing diagnostic

These project-owned launch wrappers observe the normally selected external provider. They do not modify installed files, managed adapters, business source, validators, payloads, headers, return objects, retries, locks, source checks or SDK deadlines. Hooks exist only inside these new diagnostic processes. No line profiler or stack dumper is used.

`timed_app.py` delegates to the unchanged `run.py`. It installs pass-through timing around urllib open, HTTP header sending and response reads before either probe adapter is imported. It records sanitized URI paths, actual timeout arguments, source event IDs or batch sequence bounds, socket tuples, status/error types and elapsed time. Response objects are returned directly. Headers, input/output values and raw bodies are not logged. The native constructor's actual provider/build is recorded after its unchanged initialization.

`timed_observer.py` delegates to the selected provider's normal `bo.py serve`. It records HTTP dispatch/reply and the requested event/batch/snapshot/binding stages, DataWatch.tick, protocol.validate_project, _view_model and view. Only aliases of the same original validator are wrapped; the original validator still runs once with unchanged arguments. HTTP handling does not reread a request body. Native envelope identity metadata is selected from arguments already passed to the original ingestion methods. No lock is replaced. Diagnostic IDs are separate from native event/call identities.

Each process writes primitive metadata through a separate bounded diagnostic queue. Trace loss or partial start/end pairs must be reported, never converted to a capture pass. Timer overhead is not yet measured. Socket tuple/path/request-index joins must be unique; source identity and UTC overlap are additional evidence, not a reason to guess ambiguous matches.

The structure follows the retained Node trial `node-retest-app/review/runtime/unified-1795152484/diagnostic-source/viewer_timing.py`. Python adds transparent urllib hooks and event identity metadata. Its earlier observations are context, not evidence for the current Python failure.

Module-load validation does not launch a service, create a producer or perform business work:

```powershell
$appRoot = 'C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.validation\p7-trials\python-retest-app'
$toolPython = 'C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.venv\Scripts\python.exe'
& $toolPython -B -X utf8 "$appRoot/review/diagnostics/timed_observer.py" --root $appRoot --trace-file "$appRoot/review/diagnostics/check-observer.jsonl" --check-only
& $toolPython -B -X utf8 "$appRoot/review/diagnostics/timed_app.py" --root $appRoot --trace-file "$appRoot/review/diagnostics/check-app.jsonl" --check-only
```

After the coordinating user authorizes a run, stop only the owned old services, preserve their receipts, and launch the observer first. Use a fresh trace directory so previous logs cannot be overwritten:

```powershell
& $toolPython -B -X utf8 "$appRoot/review/diagnostics/timed_observer.py" --root $appRoot --trace-file "$traceDir/observer.jsonl" --port 8876 --origin http://127.0.0.1:8875
& "$appRoot/.venv/Scripts/python.exe" -B -X utf8 "$appRoot/review/diagnostics/timed_app.py" --root $appRoot --trace-file "$traceDir/client.jsonl" --port 8875
```

Set the existing process-local TEAM_FILES_DATABASE_URL to the same native SQLite path when launching the observer. Do not change poll intervals, transport deadlines, capture range or existing checks. Verify actual provider/build in both traces and exactly one registered producer before the single real UI/recording diagnostic. The existing repair09 failure and its one-attempt marker remain immutable; a separately authorized timed attempt receives its own marker and original artifacts. No full UI loop, new requirements or final accept follows automatically.
