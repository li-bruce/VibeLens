"""Launch the installed observer CLI with selected-method diagnostic timing."""
import argparse
import json
from pathlib import Path
import runpy
import sys
from timing_common import Recorder,install_server,provenance

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root",required=True,type=Path)
    parser.add_argument("--trace-file",required=True,type=Path)
    parser.add_argument("--check-only",action="store_true")
    args,forward=parser.parse_known_args()
    root=args.root.absolute().resolve()
    provider=(root/json.loads((root/"tooling/vibelens.json").read_text(encoding="utf-8"))["skill_root"]).resolve()
    entry=provider/"scripts/bo.py"
    sys.path.insert(0,str(entry.parent))
    recorder=Recorder(args.trace_file,"observer-server")
    recorder.start()
    install_server(recorder)
    recorder.emit({"event":"entrypoint","mode":"check-only" if args.check_only else "timed-runtime","path":str(entry),**provenance(root,provider)})
    if args.check_only:
        recorder.close()
        return
    sys.argv=[str(entry),"serve","--root",str(root),*forward]
    try: runpy.run_path(str(entry),run_name="__main__")
    finally:
        recorder.emit({"event":"entrypoint_returned"})
        recorder.close()

if __name__=="__main__":
    main()
