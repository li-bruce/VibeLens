"""Launch the unchanged native application under explicitly authorized timing hooks."""
import argparse
from functools import wraps
import json
from pathlib import Path
import runpy
import sys
from timing_common import Recorder,install_urllib,provenance,safe_url

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root",required=True,type=Path)
    parser.add_argument("--trace-file",required=True,type=Path)
    parser.add_argument("--check-only",action="store_true")
    args,forward=parser.parse_known_args()
    root=args.root.absolute().resolve()
    provider=(root/json.loads((root/"tooling/vibelens.json").read_text(encoding="utf-8"))["skill_root"]).resolve()
    sys.path.insert(0,str(provider/"scripts"))
    sys.path.insert(0,str(root))
    recorder=Recorder(args.trace_file,"native-client")
    recorder.start()
    install_urllib(recorder)
    from integrations.bo_runtime import BOObservation
    from bo_observer.adapters.python import bo_probe,bo_otel
    original=BOObservation.__init__
    timed=recorder.wrap(original,"app.observation.bootstrap")
    @wraps(original)
    def initialize(instance,*values,**kw):
        result=timed(instance,*values,**kw)
        try:
            probe=instance.bo_probe
            recorder.emit({"event":"native_observer_bound","actual_build":probe.bo_build,"collector":safe_url(probe.bo_endpoint),"probe_module":type(probe).__module__,"probe_source":str(Path(bo_probe.__file__).resolve())})
        except Exception as error:
            recorder.emit({"event":"native_identity_metadata_error","exception_type":type(error).__name__})
        return result
    BOObservation.__init__=initialize
    recorder.emit({"event":"entrypoint","mode":"check-only" if args.check_only else "timed-runtime","path":str(root/"run.py"),**provenance(root,provider)})
    if args.check_only:
        recorder.close()
        return
    sys.argv=[str(root/"run.py"),*forward]
    try: runpy.run_path(str(root/"run.py"),run_name="__main__")
    finally:
        recorder.emit({"event":"entrypoint_returned"})
        recorder.close()

if __name__=="__main__":
    main()
