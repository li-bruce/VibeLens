﻿$ErrorActionPreference='Stop'
$taskRoot='C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.validation\p7-trials\python-retest-app'
$taskCase=Join-Path $taskRoot 'review/download-refactor-v1/repair27-acceptance'
$taskOut=Join-Path $taskCase 'shutdown-01'
if (Test-Path -LiteralPath $taskOut) {throw 'A shutdown attempt already exists; do not overwrite or repeat it.'}
New-Item -ItemType Directory -Path $taskOut -ErrorAction Stop | Out-Null
$taskPython='C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.venv\Scripts\python.exe'
$taskLaunch=Get-Content -Raw -LiteralPath (Join-Path $taskCase 'live-processes.json') | ConvertFrom-Json
$taskProvider='C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.validation\p7-trials\context-closure-skills\vibelens'
$taskAll=@(Get-CimInstance Win32_Process)
$taskListeners=@(Get-NetTCPConnection -LocalPort 8875,8876 -State Listen -ErrorAction Stop | Select-Object LocalAddress,LocalPort,OwningProcess)
if (@($taskListeners | Where-Object LocalPort -eq 8875).Count -ne 1 -or @($taskListeners | Where-Object LocalPort -eq 8876).Count -ne 1) {throw 'Expected exactly one owned listener on each trial port.'}

function Confirm-TrialProcess($taskProcess,[string]$taskRole) {
    if (-not $taskProcess -or $taskProcess.Name -ne 'python.exe' -or -not $taskProcess.CommandLine) {throw 'Missing or non-Python trial process.'}
    $taskCommand=[string]$taskProcess.CommandLine
    if ($taskRole -eq 'app') {
        if ($taskCommand.IndexOf((Join-Path $taskRoot 'run.py'),[StringComparison]::OrdinalIgnoreCase) -lt 0 -or $taskCommand -notmatch '--port\s+8875(?:\s|$)') {throw 'App command line does not match this trial.'}
    } else {
        if ($taskCommand.IndexOf((Join-Path $taskProvider 'scripts\bo.py'),[StringComparison]::OrdinalIgnoreCase) -lt 0 -or $taskCommand.IndexOf(('--root '+$taskRoot),[StringComparison]::OrdinalIgnoreCase) -lt 0 -or $taskCommand -notmatch '--port\s+8876(?:\s|$)' -or $taskCommand -notmatch '\sserve\s') {throw 'Observer command line does not match this trial/provider.'}
    }
}

$taskTargets=@()
foreach ($taskRole in @('app','observer')) {
    $taskPort=if($taskRole -eq 'app'){8875}else{8876}
    $taskLauncherId=if($taskRole -eq 'app'){[int]$taskLaunch.app_pid}else{[int]$taskLaunch.viewer_pid}
    $taskListener=$taskListeners | Where-Object LocalPort -eq $taskPort
    $taskOwner=$taskAll | Where-Object ProcessId -eq $taskListener.OwningProcess
    $taskLauncher=$taskAll | Where-Object ProcessId -eq $taskLauncherId
    Confirm-TrialProcess $taskOwner $taskRole
    Confirm-TrialProcess $taskLauncher $taskRole
    if ($taskOwner.ParentProcessId -ne $taskLauncherId) {throw 'Listener ancestry differs from the original launch receipt.'}
    if ($taskOwner.CommandLine -ne $taskLauncher.CommandLine) {throw 'Launcher and listener command lines differ.'}
    foreach ($taskItem in @($taskOwner,$taskLauncher)) {
        $taskTargets+=[pscustomobject]@{role=$taskRole;ProcessId=[int]$taskItem.ProcessId;ParentProcessId=[int]$taskItem.ParentProcessId;Name=$taskItem.Name;CreationDate=$taskItem.CreationDate;CommandLine=$taskItem.CommandLine}
    }
}
if (@($taskTargets.ProcessId | Select-Object -Unique).Count -ne 4) {throw 'Expected four distinct trial listener/launcher processes.'}
[ordered]@{checked_utc=[DateTime]::UtcNow.ToString('o');listeners=$taskListeners;targets=$taskTargets;scope='Exact trial listener processes and their original Python launchers only';higher_shell_parents_excluded=$true;shutdown_http_request_sent=$false} | ConvertTo-Json -Depth 7 | Set-Content -LiteralPath (Join-Path $taskOut 'processes-before.json') -Encoding utf8
Copy-Item -LiteralPath $PSCommandPath -Destination (Join-Path $taskOut 'executed-shutdown-script.ps1')
& $taskPython -B -X utf8 (Join-Path $taskRoot 'review/download-refactor-v1/repair27-shutdown-snapshot.py') before
if ($LASTEXITCODE -ne 0) {throw 'Unable to preserve protected state; nothing was stopped.'}

# Keep kernel handles so a reused PID cannot change the observed exit result.
$taskHandles=@{}
foreach ($taskTarget in $taskTargets) {
    $taskProcess=Get-Process -Id $taskTarget.ProcessId -ErrorAction Stop
    $null=$taskProcess.Handle
    $taskHandles[$taskTarget.ProcessId]=$taskProcess
}
$taskResults=@()
foreach ($taskTarget in $taskTargets) {
    $taskCurrent=Get-CimInstance Win32_Process -Filter ('ProcessId = '+$taskTarget.ProcessId)
    if ($taskCurrent) {
        Confirm-TrialProcess $taskCurrent $taskTarget.role
        if ($taskCurrent.CreationDate -ne $taskTarget.CreationDate -or $taskCurrent.CommandLine -ne $taskTarget.CommandLine) {throw 'Process identity changed since the ownership snapshot; do not stop it.'}
        $taskCommand=[ordered]@{utc=[DateTime]::UtcNow.ToString('o');command='Stop-Process -InputObject <verified kernel process handle> -ErrorAction Stop';process_id=$taskTarget.ProcessId;role=$taskTarget.role;creation_date=$taskTarget.CreationDate;full_command_line=$taskTarget.CommandLine}
        $taskCommand | ConvertTo-Json -Compress -Depth 4 | Add-Content -LiteralPath (Join-Path $taskOut 'executed-commands.jsonl') -Encoding utf8
        try {
            Stop-Process -InputObject $taskHandles[$taskTarget.ProcessId] -ErrorAction Stop
            $taskAction='Stop-Process issued after immediate identity recheck'
        } catch {
            if (-not $taskHandles[$taskTarget.ProcessId].HasExited) {throw}
            $taskAction='Verified process exited during the stop request; no retry'
        }
    } else {$taskAction='Already exited after its owned child stopped; no extra stop command'}
    $taskProcess=$taskHandles[$taskTarget.ProcessId]
    $taskExited=$taskProcess.WaitForExit(3000)
    $taskExitCode=if($taskExited){$taskProcess.ExitCode}else{$null}
    $taskResults+=[ordered]@{process_id=$taskTarget.ProcessId;role=$taskTarget.role;action=$taskAction;has_exited=$taskExited;exit_code=$taskExitCode}
}
$taskRemaining=@(Get-CimInstance Win32_Process | Where-Object {$_.ProcessId -in @($taskTargets.ProcessId)} | Select-Object ProcessId,ParentProcessId,Name,CreationDate,CommandLine)
$taskListenersAfter=@(Get-NetTCPConnection -LocalPort 8875,8876 -State Listen -ErrorAction SilentlyContinue | Select-Object LocalAddress,LocalPort,OwningProcess)
foreach ($taskName in @('app.stdout.log','app.stderr.log','observer.stdout.log','observer.stderr.log')) {
    Copy-Item -LiteralPath (Join-Path $taskLaunch.runtime_directory $taskName) -Destination (Join-Path $taskOut ('final-'+$taskName))
}
[ordered]@{checked_utc=[DateTime]::UtcNow.ToString('o');remaining_target_processes=$taskRemaining;listeners=$taskListenersAfter;termination_results=$taskResults;only_targeted_trial_process_ids=@($taskTargets.ProcessId);http_control_request_sent=$false;accepted=$true} | ConvertTo-Json -Depth 7 | Set-Content -LiteralPath (Join-Path $taskOut 'processes-after.json') -Encoding utf8
if ($taskRemaining.Count -or $taskListenersAfter.Count -or @($taskResults | Where-Object {-not $_.has_exited}).Count) {throw 'A target process or port remains; preserve receipt without retrying.'}
& $taskPython -B -X utf8 (Join-Path $taskRoot 'review/download-refactor-v1/repair27-shutdown-snapshot.py') after
if ($LASTEXITCODE -ne 0) {throw 'Protected-state difference found; preserve evidence without rollback.'}
$taskProof=Get-Content -Raw -LiteralPath (Join-Path $taskOut 'preservation-proof.json') | ConvertFrom-Json
$taskSummary=[ordered]@{valid=$true;stopped_utc=[DateTime]::UtcNow.ToString('o');stopped_trial_processes=@($taskTargets.ProcessId);ports_released=@(8875,8876);remaining_processes=$taskRemaining;remaining_listeners=$taskListenersAfter;exit_results=$taskResults;preservation=$taskProof;new_tests_run=$false;recording_retried=$false;services_restarted=$false;accepted=$true;next='Accepted Python refactor closed; retain all data and release the runtime slot'}
$taskSummary | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $taskOut 'shutdown-summary.json') -Encoding utf8
$taskSummary | ConvertTo-Json -Depth 8
