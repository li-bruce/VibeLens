# Display-only state and event names

The existing inventory/apply/check interface installed bilingual explanations for all 12 states and 10 events across the four independent native models. The same wording is applied to conceptual states/events/transitions, native state nodes and model-scoped native values: 66 covered entries, 64 changed entries. Every original inventory item, identity and meaning fingerprint is unchanged. Rejection is named **Preparation rejected / 准备被拒绝**; its event is **Reject preparation / 拒绝本次准备**. Specific denial reasons remain in the original decision and recording details.

Only the semantic-name overlay was authored. Application source, generators, rules, executable state declarations, business behavior, IDs, mappings, original tests, baseline and installed provider files remain byte-identical. Normal inspect/verify refreshed derived receipts; `project-before.zip` preserves their previous bytes. No framework or installed-copy edits, new recording, business iteration, refactor, service restart or final accept occurred.

`check-after.json` has no missing/stale names. Existing `change_sync inspect` and `verify` pass with the unchanged candidate and build. All five strict reports pass. The browser exercised the actual local viewer: Chinese and English concept/native networks for every model (16 screenshots before, 16 after), plus four native source-name screenshots after. All 110 checks against rendered page text pass, with no page JavaScript errors. Screenshots were visually reviewed, including both languages, source mode and recipient-grant concepts. Raw `phase` values and exact provenance identifiers in implementation details remain original. The screenshot task does not claim to fix the framework's model-folding or graph-layout behavior.

The first after-change browser pass reached English before its new document initialized the view options. Its partial evidence is retained in `after-screens`; the completed pass in `after-screens-complete` explicitly waits for navigation and initialization. This correction changes only the screenshot harness. All original recording/frame files retained their hashes. Real UI preferences were restored through the normal revision-checked API; entry values are identical, while the preference revision advanced normally.

Services remain on app port **8875**, listener PID **24088**, and viewer port **8876**, listener PID **16980**. See `live-services-after.json` for the final process receipt. P7 final accept remains pending the coordinating chat.

## Evidence

- `inventory-before.json`, `inventory-after.json`, `apply.json`, `check-after.json`
- `semantic-names-before.json`, `semantic-names-after.json`, `semantic-names-authored.json`, `name-diff.json`
- `state-event-name-coverage.json`, `browser-name-checks.json`
- `before-screens/`, `after-screens-complete/`
- `inspect-after.json`, `verify-after.json`, `protected-before.json`, `recordings-before.json`, `provider-before.json`, `summary.json`

## Names

| Model | Kind | Native value | English | Chinese |
|---|---|---|---|---|
| file | state | `absent` | File not stored | 文件尚未保存 |
| file | state | `available` | File stored | 文件已保存 |
| grant | state | `inactive` | No recipient access | 该同事无共享权限 |
| grant | state | `active` | Recipient has access | 该同事有共享权限 |
| download-job | state | `not_requested` | Download not requested | 尚未申请下载 |
| download-job | state | `queued` | Queued for preparation | 排队等待准备 |
| download-job | state | `preparing` | Preparing download | 正在准备下载包 |
| download-job | state | `ready` | Ready to collect | 下载结果可领取 |
| download-job | state | `rejected` | Preparation rejected | 准备被拒绝 |
| announcement | state | `unpublished` | Announcement unpublished | 公告尚未发布 |
| announcement | state | `published` | Announcement published | 公告已发布 |
| announcement | state | `deleted` | Announcement deleted | 公告已删除 |
| file | event | `upload` | Store uploaded file | 保存上传文件 |
| grant | event | `share` | Grant recipient access | 授予该同事共享权限 |
| grant | event | `revoke` | Revoke recipient access | 撤销该同事共享权限 |
| download-job | event | `request` | Request download | 申请本次下载 |
| download-job | event | `start` | Admit and start preparation | 获准并开始准备 |
| download-job | event | `reject` | Reject preparation | 拒绝本次准备 |
| download-job | event | `complete` | Finish download preparation | 完成本次下载准备 |
| announcement | event | `publish` | Publish announcement | 发布公告 |
| announcement | event | `edit` | Edit own announcement | 修改自己的公告 |
| announcement | event | `delete` | Delete own announcement | 删除自己的公告 |
