/** Offline comparison using a frozen native recording, never a substituted UI response. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {layoutGraph as before} from './p7-trials/interactive-capture-skills/vibelens/assets/stategraph-viewer/graph-core.js';
import {layoutGraph as after} from '../skills/vibelens/assets/stategraph-viewer/graph-core.js';
import {profileFor, matchingNodes} from '../skills/vibelens/assets/stategraph-viewer/analysis.js';
import {refreshHierarchy, presentationGraph} from '../skills/vibelens/assets/stategraph-viewer/layout.js';

const source='.validation/p7-trials/python-retest-app/review/browser/interactive-recording-20261120T104548/recording-original.json';
const view=JSON.parse(fs.readFileSync(source,'utf8')).context;
const profile=profileFor('states');
function project(make, expanded=new Set(), layered=false) {
  const graph=make(view, expanded,new Set(),new Map(),'latest','latest',{
    match:(all,events,status,relations)=>matchingNodes(all,view,events,profile,status,relations)
  });
  graph.layered=layered;
  refreshHierarchy(graph);
  const shown=presentationGraph(graph,profile);
  return {all:[...graph.all.keys()].sort(), relations:graph.rawEdges.map(e=>e.id).sort(),
    visible:[...new Set([...shown.glyphs,...shown.regions])].filter(id=>graph.all.get(id).layer==='state').sort(),
    roots:graph.boxes.filter(b=>b.node.concept_kind==='state_model').map(b=>b.id).sort()};
}
const old=project(before), current=project(after);
assert.deepEqual(current.all,old.all);
assert.deepEqual(current.relations,old.relations);
assert.deepEqual(current.visible,current.roots);
assert.equal(current.roots.length,4);
const modes=[];
for(const layered of [false,true]) {
  const opened=project(after,new Set(current.roots),layered);
  assert.ok(opened.visible.length>current.visible.length);
  modes.push(opened);
}
assert.deepEqual(modes[0].visible,modes[1].visible);
const result={valid:true,scope:'Offline projection of actual native recording; not a fresh runtime or browser acceptance',
  source, before:old,after:current,expanded:modes};
fs.writeFileSync('docs/review/behavior-contracts-sequential/p7-trials/repair-15/state-groups-native-context.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({before:old.visible.length,after:current.visible.length,expanded:modes[0].visible.length}));
