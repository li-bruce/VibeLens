"""Read rendered model membership and captions without changing project definitions."""
import json
from pathlib import Path
from playwright.sync_api import sync_playwright

out = Path('.validation/p7-native-ui/python/state-inspection')
out.mkdir(parents=True, exist_ok=False)
with sync_playwright() as driver:
    browser = driver.chromium.launch(executable_path='C:/Program Files/Google/Chrome/Application/chrome.exe', headless=True, args=['--enable-unsafe-swiftshader'])
    page = browser.new_page(viewport={'width': 1600, 'height': 1050})
    page.goto('http://127.0.0.1:8876/graph?lang=zh-CN', wait_until='domcontentloaded')
    page.wait_for_function('window.graphDebug?.graph && !graphDebug.sourceBusy && !graphDebug.layoutBusy && !graphDebug.geometryBusy')
    page.select_option('#analysis-view', 'states')
    page.click('#collapse')
    page.wait_for_function('!graphDebug.sourceBusy && !graphDebug.layoutBusy && !graphDebug.geometryBusy')
    value = page.evaluate('''() => ({
      nodes: [...graphDebug.graph.all.values()].filter(n=>n.layer==='state').map(n=>({
        id:n.id, label:n.label, kind:n.kind, concept_kind:n.concept_kind, state_model_id:n.state_model_id,
        parent:n.parent, concept_id:n.concept_id, concept_definition:n.concept_definition,
        machine_state:n.machine_state, value:n.value,
        shown:graphDebug.presentation.glyphs.has(n.id)||graphDebug.presentation.regions.has(n.id)})),
      concept_edges:graphDebug.view.concept_structure.edges.filter(e=>e.from.startsWith('state-model')),
      networks:graphDebug.view.concept_structure.networks
    })''')
    (out/'inventory.json').write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'states':len(value['nodes']), 'roots':[n for n in value['nodes'] if n.get('concept_kind')=='state_model']}))
    browser.close()
