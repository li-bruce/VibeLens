// Attach reviewed descriptions to the exact independently indexed JavaScript functions.
const fs = require('node:fs');
const path = require('node:path');
const { bo_provider_file } = require('../integrations/bo_provider.cjs');
const ts = require(bo_provider_file('scripts/bo_observer/adapters/javascript/node_modules/typescript'));
const root = path.resolve(__dirname, '..');
const index = JSON.parse(fs.readFileSync(path.join(root, 'review/source-index.json'), 'utf8'));
const report = JSON.parse(fs.readFileSync(path.join(root, 'review/source-docs.json'), 'utf8'));
const exact = {
  '$': 'Find one application element by its stable DOM ID.',
  'action.rowActionHandler.<callback:dispatchUi:2:1>': 'Run the selected row action with visible error feedback.',
  'action.rowActionHandler.<callback:dispatchUi:2:1>.<callback:perform:0:1>': 'Invoke this row action with the button that initiated it.',
  'api.<callback:response.json().catch:0:1>': 'Retain a public fallback code when an error response is not JSON.',
  'navigationHandler.<callback:dispatchUi:2:1>': 'Apply the clicked navigation choice with visible error feedback.',
  'navigationHandler.<callback:dispatchUi:2:1>.<callback:perform:0:1>': 'Load the view selected by the native navigation button.',
  'openShare.<callback:state.members.filter:0:1>': 'Offer colleagues other than the current uploader as recipients.',
  'refreshBoard.<callback:action:1:1>': 'Load this editor-authored announcement into the edit form.',
  'refreshBoard.<callback:action:1:2>': 'Delete this announcement through the API and refresh the board.',
  'refreshFiles.<callback:action:1:1>': 'Submit a preparation task for this visible file.',
  'refreshFiles.<callback:action:1:2>': 'Open the named-recipient dialog for this uploader-owned file.',
  'refreshFiles.<callback:action:1:3>': 'Revoke this recipient grant through the API and refresh visible files.',
  'refreshFiles.<callback:file.grants.filter:0:1>': 'Render access chips only for currently active recipient grants.',
  "selectView.<callback:document.querySelectorAll('[data-view]').forEach:0:1>": 'Highlight only the navigation button for the selected view.',
  "<callback:document.querySelectorAll('[data-view]').forEach:0:1>": 'Register each native navigation button with the shared click handler.',
  "<callback:import('/api/bo/client.mjs').catch:0:1>": 'Allow the workspace to start when the optional observer client is unavailable.',
  '<callback:setInterval:0:1>': 'Refresh tasks only while a logged-in user is viewing the visible task page.',
  'createApp.errorHandler': 'Return the actual application or parser error as its public HTTP status and code.',
  'createApp.originBoundary': 'Set local application response headers and reject mismatched mutation origins.',
  'createApp.unknownApi': 'Return a public 404 for an unmatched API path.',
  'createApp.observed.apiBoundary': 'Wrap this matched native API invocation before body parsing.',
  'createApp.observed.apiBoundary.<callback:res.once:1:1>': 'Publish the real completed HTTP status without changing the response.',
  'createApp.observed.apiBoundary.proceed': 'Enter the native Express continuation in its actual invocation context.',
  "sessionCookie.<callback:req.headers.cookie?.split(';').map:0:1>": 'Trim whitespace around one native cookie segment.',
  "sessionCookie.<callback:req.headers.cookie?.split(';').map(value => value.trim()).find:0:1>": 'Select only the application session-cookie segment.',
  'decide.input': 'Read and cache one actual input fact for this native policy evaluation.',
  'decide.predicate': 'Compare the supplied identity facts and retain the actual predicate result.',
  'decide.group': 'Evaluate ordered native conditions with the declared all-or-any short circuit.',
  'decide.owner': 'Compare the current actor with the actual file uploader.',
  'decide.recipient': 'Compare the current actor with the selected grant recipient.',
  'decide.grant': 'Require both the matching recipient identity and an active grant.',
  'decide.grant.<callback:anonymous:1>': 'Read the actual active-grant input when the recipient branch is reached.',
  'decide.fileAccess': 'Allow the actual uploader or a currently active named recipient.',
  'decide.access': 'Require membership before evaluating native file access.',
  'decide.access.<callback:anonymous:1>': 'Read native membership before the file-access branch.',
  'decide.ready': 'Compare the stored task status with ready and retain that actual result.',
  'decide.published': 'Compare the stored announcement status with published.',
  'decide.group.<object:1>.<callback:functions.map:0:1>': 'Select the declared identity of an ordered condition.',
  'decide.group.<object:1>.<callback:functions.map(([id]) => id).filter:0:1>': 'Retain condition identities skipped by native short-circuit evaluation.',
  'decide.<callback:anonymous:1>': 'Read membership for native share management.',
  'decide.<callback:anonymous:2>': 'Read membership for native artifact collection.',
  'decide.<callback:anonymous:3>': 'Compare the actor with the original task requester.',
  'decide.<callback:anonymous:4>': 'Read the task authorization persisted at submission.',
  'decide.<callback:anonymous:5>': 'Read membership for native announcement publication.',
  'decide.<callback:anonymous:6>': 'Read the designated announcement-editor role for publication.',
  'decide.<callback:anonymous:7>': 'Read membership for native announcement modification.',
  'decide.<callback:anonymous:8>': 'Read the designated announcement-editor role for modification.',
  'decide.<callback:anonymous:9>': 'Compare the actor with the actual announcement author.',
  '<callback:app.listen:2:1>': 'Report the loopback address only after the native HTTP server starts.',
  'AppError.constructor': 'Create a native error with its public HTTP status and stable code.',
  'FileService.constructor': 'Initialize native storage, operation context and the single preparation worker.',
  'FileService.operation.executeOnce': 'Cache one promise so an optional instrumentation failure cannot execute a mutation twice.',
  'FileService.operation.executeOnce.<callback:Promise.resolve().then:0:1>': 'Start the native action within its asynchronous operation context.',
  'FileService.operation.executeOnce.<callback:Promise.resolve().then:0:1>.<callback:this.context.run:1:1>': 'Publish native entry and invoke the real business action once.',
  'FileService.requestDownload.<callback:this.operation:2:1>.<callback:this.store.transaction:0:1>': 'Authorize current file access and commit the task with its original requester and saved authorization.',
  'FileService.scheduleWorker.<callback:setTimeout:0:1>': 'Start the real preparation worker after the queued admission has returned.',
  'FileService.scheduleWorker.<callback:setTimeout:0:1>.<callback:this.drainWorker().finally:0:1>': 'Clear the active worker promise when native preparation settles.',
  'FileService.subscribe.<callback:anonymous:1>': 'Detach only this optional fact subscriber.',
  'FileService.upload.<callback:this.operation:2:1>.<callback:unlink(storagePath).catch:0:1>': 'Ignore cleanup failure while preserving the original upload-storage error.',
  '<object:1>.locateFile': 'Resolve the installed SQLite WebAssembly asset from this project dependency.',
  'Store.constructor': 'Open the native SQLite database, create its schema and seed the requested synthetic accounts.',
  'Store.constructor.<callback:this.transaction:0:1>': 'Seed missing synthetic accounts with salted password hashes in one native transaction.',
  'Store.run.<callback:this.transaction:0:1>': 'Execute this bound mutation inside a native transaction when no transaction is active.'
};
const operations = {
  announcements: 'Read published announcements after the native membership decision.',
  collect: 'Authorize the original requester and read the actual prepared bytes without consuming the task.',
  drainWorker: 'Move the stored queued task into preparation and verify its real copied artifact.',
  listFiles: 'Select native file rows visible to the current member.',
  listTasks: 'Read only tasks belonging to the authenticated requester.',
  login: 'Verify the real password and persist a new native session.',
  logout: 'Authorize and persist the end of this current native session.',
  mutateAnnouncement: 'Authorize authorship and persist the selected edit or deletion.',
  publish: 'Authorize the editor role and persist this new announcement.',
  requestDownload: 'Admit the task through an actual native transaction and schedule preparation after commit.',
  setGrant: 'Authorize uploader ownership and persist this recipient grant change.',
  upload: 'Authorize the member, write actual bytes and persist their metadata.',
  viewFile: 'Authorize current file access before returning selected metadata.'
};
const forms = {
  1: ['Submit the real login form and enter only after authenticated success.'],
  2: ['Run logout with visible error feedback.', 'End the native session and restore the login screen.'],
  3: ['Refresh authorized file rows after the refresh click.'],
  4: ['Refresh this requester task list after the refresh click.'],
  5: ['Refresh the authenticated announcement board after the refresh click.'],
  6: ['Display the actual chosen upload filename and byte size.'],
  7: ['Submit the selected upload through the bounded native API.', 'Upload the selected real file bytes and refresh authorized files.'],
  8: ['Submit this named-recipient share form.', 'Create the selected recipient grant and close the share dialog after success.'],
  9: ['Close the recipient picker without submitting a grant.'],
  10: ['Submit this editor announcement form.', 'Publish or save the editor own announcement through the native API.']
};
function summary(symbol) {
  if (exact[symbol]) return exact[symbol];
  const form = symbol.match(/^<callback:bind:2:(\d+)>(.*)$/);
  if (form) return forms[form[1]]?.[form[2] ? 1 : 0];
  const op = symbol.match(/^FileService\.(\w+)\.<callback:this.operation:2:1>$/);
  if (op) return operations[op[1]];
  if (symbol === 'FileService.drainWorker.<callback:this.operation:2:1>.<callback:this.operation:2:1>') return 'Persist ready only after the actual prepared artifact has passed its checksum check.';
  throw new Error('No reviewed description: ' + symbol);
}
const grouped = new Map();
for (const missing of report.missing.filter(item => item.reason === 'source_summary_missing')) {
  const record = index.symbols[missing.symbol];
  if (!record) throw new Error('Missing indexed declaration: ' + missing.symbol);
  const items = grouped.get(record.path) || []; items.push(record); grouped.set(record.path, items);
}
let count = 0;
for (const [filename, records] of grouped) {
  const target = path.join(root, filename), source = fs.readFileSync(target, 'utf8');
  const ast = ts.createSourceFile(filename, source, ts.ScriptTarget.Latest, true);
  const nodes = [];
  function visit(node) { if (ts.isFunctionLike(node) && node.body) nodes.push(node); ts.forEachChild(node, visit); }
  visit(ast);
  const edits = [];
  const selected = new Set();
  for (const record of records) {
    const matches = nodes.filter(node => {
      if (selected.has(node)) return false;
      const start = ast.getLineAndCharacterOfPosition(node.getStart(ast));
      const end = ast.getLineAndCharacterOfPosition(node.end);
      if (start.line + 1 !== record.line || end.line + 1 !== record.end_line) return false;
      return node.parameters.length === record.parameters.length && node.parameters.every((parameter, i) => {
        const pos = ast.getLineAndCharacterOfPosition(parameter.name.getStart(ast));
        return pos.line + 1 === record.parameters[i].selection.line && pos.character === record.parameters[i].selection.column;
      });
    });
    // The inventory lists a containing callback before its nested callback. On a
    // single line, their parameter-free ranges share line coordinates; retain nesting.
    matches.sort((a, b) => (b.end - b.getStart(ast)) - (a.end - a.getStart(ast)));
    if (!matches.length) throw new Error('Missing source position: ' + record.id);
    const node = matches[0], description = summary(record.symbol);
    selected.add(node);
    const docs = ts.getJSDocCommentsAndTags(node).filter(doc => doc.kind === ts.SyntaxKind.JSDoc);
    if (docs.length) {
      const doc = docs[0]; edits.push({ position: doc.pos + 3, value: ' ' + description });
    } else edits.push({ position: node.getStart(ast), value: '/** ' + description + ' */ ' });
    count++;
  }
  let updated = source;
  for (const edit of edits.sort((a, b) => b.position - a.position)) updated = updated.slice(0, edit.position) + edit.value + updated.slice(edit.position);
  fs.writeFileSync(target, updated);
}
console.log(JSON.stringify({ documented_callbacks_and_helpers: count }));
