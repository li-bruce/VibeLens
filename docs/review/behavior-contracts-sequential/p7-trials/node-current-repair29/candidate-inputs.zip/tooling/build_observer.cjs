/** Bundle the optional browser tracer from the same installed provider as native launch/checks. */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const esbuild = require('esbuild');
const { bo_resolve_provider, bo_provider_selection, bo_provider_file, bo_provider_hashes } = require('../integrations/bo_provider.cjs');
const root = path.resolve(__dirname, '..');

/** Build only project-owned output; preserve resolved inputs and hashes as a distinct receipt. */
async function buildObserver() {
  const provider = bo_resolve_provider();
  const result = await esbuild.build({ absWorkingDir: root, entryPoints: ['integrations/bo_client.mjs'], bundle: true,
    format: 'esm', platform: 'browser', external: ['/api/bo/*'], outfile: 'bo_stategraph/config/assets/client.mjs',
    metafile: true, plugins: [{ name: 'vibelens-selected-provider', setup(build) {
      build.onResolve({ filter: /^vibelens:otel$/ }, () => ({ path: bo_provider_file('scripts/bo_observer/adapters/javascript/bo_otel.mjs') }));
    } }] });
  const hash = filename => crypto.createHash('sha256').update(fs.readFileSync(filename)).digest('hex');
  const inputs = Object.fromEntries(Object.keys(result.metafile.inputs).map(name => [path.resolve(root, name), hash(path.resolve(root, name))]));
  const out = path.join(root, 'review/runtime/provider-entrypoints'); fs.mkdirSync(out, { recursive: true });
  const receipt = path.join(out, 'build-' + Date.now() + '-' + process.pid + '.json');
  fs.writeFileSync(receipt, JSON.stringify({ kind: 'ordinary-npm-build', command: 'npm run build:observer',
    selection: bo_provider_selection(), provider, inputs, metafile: result.metafile,
    entrypoint_hashes: Object.fromEntries(['package.json','integrations/provider.json','integrations/bo_provider.cjs','tooling/build_observer.cjs'].map(name => [name,hash(path.join(root,name))])),
    dependencies: bo_provider_hashes(['scripts/bo_observer/adapters/javascript/bo_otel.mjs',
      'scripts/bo_observer/adapters/javascript/package-lock.json']),
    output: { path: 'bo_stategraph/config/assets/client.mjs', sha256: hash(path.join(root, 'bo_stategraph/config/assets/client.mjs')) } }, null, 2));
  fs.writeFileSync(path.join(out, 'build-latest.json'), JSON.stringify({ path: receipt }));
  console.log(JSON.stringify({ provider_build_receipt: receipt, selected_provider: provider, source: bo_provider_selection().source }));
}
buildObserver().catch(error => { console.error(error.message); process.exitCode = 1; });
