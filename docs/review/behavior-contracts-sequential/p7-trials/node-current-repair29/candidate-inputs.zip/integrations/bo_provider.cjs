/** Resolve this project's observer installation; business code does not own provider paths. */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const bo_root = path.resolve(__dirname, '..');
const bo_config = path.join(__dirname, 'provider.json');
let bo_selected;

/** Resolve a configured or environment path relative to this project, never the caller's cwd.
 * @param {string} value Selected installed directory or its project-relative path.
 * @returns {string} Existing canonical filesystem path.
 */
function bo_canonical(value) {
  if (typeof value !== 'string' || !value.trim()) throw new Error('BO_PROVIDER_PATH: expected an installed Skill directory');
  return fs.realpathSync(path.resolve(bo_root, value));
}

/** Select once per process; the legacy diagnostic variable may agree, but cannot override.
 * @returns {string} Canonical immutable installed provider directory.
 */
function bo_resolve_provider() {
  if (bo_selected) return bo_selected.provider;
  const config = JSON.parse(fs.readFileSync(bo_config, 'utf8'));
  const requested = process.env.VIBELENS_SKILL || null;
  const diagnostic = process.env.BO_DIAGNOSTIC_SKILL || null;
  const selected = bo_canonical(requested || config.skill);
  const comparable = value => process.platform === 'win32' ? value.toLowerCase() : value;
  if (diagnostic && comparable(bo_canonical(diagnostic)) !== comparable(selected)) {
    throw new Error('BO_PROVIDER_CONFLICT: BO_DIAGNOSTIC_SKILL differs from VIBELENS_SKILL or integrations/provider.json');
  }
  if (!fs.existsSync(path.join(selected, 'scripts/bo.py'))) throw new Error('BO_PROVIDER_PATH: selected directory has no scripts/bo.py');
  bo_selected = { provider: selected, source: requested ? 'VIBELENS_SKILL' : 'integrations/provider.json',
    config: bo_config, configured_skill: config.skill, requested_skill: requested, requested_diagnostic_skill: diagnostic };
  return selected;
}

/** Return build/launch selection provenance without reading any application credentials.
 * @returns {object} The resolved path, default/override source and original environment choices.
 */
function bo_provider_selection() { bo_resolve_provider(); return { ...bo_selected }; }

/** Locate an existing optional dependency inside the selected provider.
 * @param {string} relative Project-owned reference relative to the installed provider.
 * @returns {string} The resolved dependency path.
 */
function bo_provider_file(relative) {
  const root = bo_resolve_provider(), target = fs.realpathSync(path.resolve(root, relative));
  const child = path.relative(root, target);
  if (child.startsWith('..') || path.isAbsolute(child)) throw new Error('BO_PROVIDER_PATH: dependency escapes the selected provider');
  return target;
}

/** Bind the exact installed dependencies used by an entrypoint to its receipt.
 * @param {Array<string>} files Provider-relative dependency filenames.
 * @returns {object} SHA-256 values keyed by the original provider-relative reference.
 */
function bo_provider_hashes(files) {
  return Object.fromEntries(files.map(relative => [relative, crypto.createHash('sha256').update(fs.readFileSync(bo_provider_file(relative))).digest('hex')]));
}

exports.bo_resolve_provider = bo_resolve_provider;
exports.bo_provider_selection = bo_provider_selection;
exports.bo_provider_file = bo_provider_file;
exports.bo_provider_hashes = bo_provider_hashes;
