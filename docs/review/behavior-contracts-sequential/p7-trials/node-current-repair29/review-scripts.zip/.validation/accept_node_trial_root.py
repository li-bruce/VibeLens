"""Run canonical Node-trial acceptance after the root's independent desktop review.

Only canonical accept/check may create accepted-state receipts. This reviewer
checks exact candidate/source/UI evidence first and retains each original command.
The trial's business assertions, native database and personal views are unchanged.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import zipfile
from native_browser_gate import check_browser_outcome

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / '.validation/p7-trials/node-retest-app'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--provider', type=Path, required=True)
for name in ('change', 'candidate', 'build'):
    parser.add_argument('--' + name, required=True)
for name in ('post', 'ui', 'captions', 'scope', 'preferences', 'out', 'native-browser', 'native-command'):
    parser.add_argument('--' + name, type=Path, required=True)
args = parser.parse_args()
PROVIDER = args.provider.resolve()
assert (PROVIDER / 'scripts/change_sync.py').is_file()
args.out.mkdir(parents=True, exist_ok=False)


def write(name, value):
    (args.out / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


post = read(args.post)
assert post['valid'] and post['candidate_id'] == args.candidate
assert all(report['status'] == 'passed' for report in post['reports'].values())
native_errors = check_browser_outcome(read(args.native_browser), read(args.native_command), args.build)
write('native-browser-gate.json', {'valid': not native_errors, 'errors': native_errors,
    'browser_receipt_sha256': digest(args.native_browser),
    'command_receipt_sha256': digest(args.native_command)})
assert not native_errors, native_errors
assert read(APP / '.stategraph/active.json')['change'] == args.change
assert read(APP / 'manifest.json')['build_id'] == args.build
accepted_path = APP / args.change / 'accepted.json'
assert not accepted_path.exists(), 'Review an existing acceptance instead of overwriting it'
scope = read(args.scope)
assert digest(APP / 'bo_stategraph/project.json') == scope['project_sha256']
for relative, expected in scope['source_hashes'].items():
    assert expected is not None and digest(APP / relative) == expected, relative
assert read(args.ui / 'sequence.json')['valid']
assert read(args.captions / 'result.json')['valid']
continuity = read(args.preferences)
personal = APP / 'bo_stategraph/config/views/local.json'
assert continuity['valid']
assert digest(personal) == continuity['after_sha256']
assert read(personal)['revision'] == continuity['after_revision']

before = {}
with zipfile.ZipFile(args.out / 'before-accept-local.zip', 'x', zipfile.ZIP_DEFLATED) as archive:
    for relative in ('manifest.json', '.stategraph/source-baseline.json',
                     '.stategraph/maintenance.json', 'bo_stategraph/config/views/local.json'):
        path = APP / relative
        if path.exists():
            before[relative] = digest(path)
            archive.write(path, relative)
write('preflight.json', {'valid': True, 'candidate_id': args.candidate, 'build_id': args.build,
    'reports': {key: value['status'] for key, value in post['reports'].items()},
    'before': before, 'preferences_revision': continuity['after_revision']})

env = dict(os.environ, VIBELENS_SKILL=str(PROVIDER), BO_DIAGNOSTIC_SKILL=str(PROVIDER),
    VIBELENS_PYTHON=sys.executable, PYTHONDONTWRITEBYTECODE='1', PYTHONUTF8='1',
    PYTHONIOENCODING='utf-8', TEAM_FILES_SQLITE_URL='sqlite:///var/db/application.sqlite',
    APP_DATA_ROOT=str(APP / 'var'))
env.pop('VIBELENS_ENDPOINT', None)
for action in ('accept', 'check'):
    argv = [sys.executable, '-B', '-X', 'utf8', str(PROVIDER / 'scripts/change_sync.py'),
            action, '--root', str(APP)]
    result = subprocess.run(argv, cwd=APP, env=env, capture_output=True,
                            encoding='utf-8', errors='replace', timeout=420, shell=False)
    (args.out / (action + '.stdout.log')).write_text(result.stdout, encoding='utf-8')
    (args.out / (action + '.stderr.log')).write_text(result.stderr, encoding='utf-8')
    write(action + '-command.json', {'argv': argv, 'exit_code': result.returncode})
    parsed = json.loads(result.stdout)
    write(action + '.json', parsed)
    print(json.dumps({'command': action, 'exit_code': result.returncode,
                      'valid': parsed.get('valid'), 'candidate_id': parsed.get('candidate_id')}), flush=True)
    assert result.returncode == 0 and parsed['valid'] and parsed['candidate_id'] == args.candidate
accepted = read(accepted_path)
assert accepted['candidate_id'] == args.candidate and accepted['build_id'] == args.build
assert digest(personal) == continuity['after_sha256']
write('result.json', {'valid': True, 'accepted': accepted,
    'preferences_revision': continuity['after_revision'], 'preferences_sha256': digest(personal),
    'services_left_running': True, 'formal_receipts_created_by': 'canonical change_sync.py accept/check'})
