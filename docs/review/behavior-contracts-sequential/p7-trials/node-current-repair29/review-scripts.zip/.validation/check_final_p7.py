"""Check the completed ledger and documentation without repeating native trials."""
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'docs/review/behavior-contracts-sequential/p7-trials/consolidated-review/final-checks'
OUT.mkdir(exist_ok=False)
checks = []
for name, script in (
    ('ledger', 'tools/check_behavior_plan.py'),
    ('ledger-regression', 'tests/test_behavior_plan.py'),
    ('document-links', 'tests/test_document_links.py'),
):
    argv = [sys.executable, '-B', '-X', 'utf8', script]
    result = subprocess.run(argv, cwd=ROOT, capture_output=True, text=True,
                            encoding='utf-8', errors='replace', timeout=120)
    (OUT / (name + '.stdout.log')).write_text(result.stdout, encoding='utf-8')
    (OUT / (name + '.stderr.log')).write_text(result.stderr, encoding='utf-8')
    checks.append({'name': name, 'command': argv, 'exit_code': result.returncode})
    print(json.dumps(checks[-1]), flush=True)
    (OUT / 'results.json').write_text(json.dumps({'valid': len(checks) == 3 and all(c['exit_code'] == 0 for c in checks),
        'checks': checks}, indent=2) + '\n', encoding='utf-8')
raise SystemExit(any(c['exit_code'] for c in checks))
