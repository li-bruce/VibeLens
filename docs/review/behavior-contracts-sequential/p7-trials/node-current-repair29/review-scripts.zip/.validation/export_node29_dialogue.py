"""Preserve public messages from the existing, completed Node trial only."""
import hashlib
import json
from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
from export_trial_dialogue import export

OUT = ROOT / 'docs/review/behavior-contracts-sequential/p7-trials/node-current-repair29'
LOCAL = ROOT / '.validation/p7-node-dialogue-repair29'
APP = ROOT / '.validation/p7-trials/node-retest-app'
SESSION = Path('C:/Users/Lvi_P/.codex/sessions/2026/11/19/rollout-2026-11-19T21-53-57-01a1f415-e2a9-7171-86f8-ec87707ead07.jsonl')
assert json.loads((OUT / 'results.json').read_text(encoding='utf-8'))['valid']
aliases = [(APP.as_posix(), 'WORKSPACE'), (str(APP), 'WORKSPACE'),
           (ROOT.as_posix(), 'REPOSITORY'), (str(ROOT), 'REPOSITORY')]
summary = export([SESSION], LOCAL, 'VibeLens P7 Node observe: design, iteration and consolidated acceptance', aliases)
report = json.loads((LOCAL / 'dialogue.json').read_text(encoding='utf-8'))
assert report['dialogue'] and 'observe' in report['dialogue'][0]['text']
members = []
archive = OUT / 'completed-dialogue.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as bundle:
    files = {name: LOCAL / name for name in ('dialogue.json', 'dialogue.md')}
    files['export_trial_dialogue.py'] = ROOT / 'tools/export_trial_dialogue.py'
    for name, path in files.items():
        data = path.read_bytes()
        bundle.writestr(name, data)
        members.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
index = {'archive': archive.name, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    **summary, 'files': members, 'source_sessions': report['source_sessions'],
    'provenance': 'Visible messages, questions, delivered simulated-user replies and usage metadata from the existing authorized chat. No reasoning or arbitrary tool output.',
    'interpretation': [
        'The initial admission-time policy and subsequent preparation-start policy are different confirmed requirements, not a rewritten initial expectation.',
        'Independent announcement and session capabilities retain their own model identities.',
        'The source-only refactor exposed a real announcement frontend failure; the subsequent complete run exposed producer overflow. Both failed candidates remain archived.',
        'Repair29 used consolidated repairs, targeted checks and one final native batch in the existing chat. No new dialogue was opened for individual defects.',
        'Technical maintenance, host approvals and reviewer coordination are not user business confirmations. Total usage does not estimate normal onboarding cost or token efficiency.',
    ]}
(OUT / 'completed-dialogue.json').write_text(json.dumps(index, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print(json.dumps(summary))
