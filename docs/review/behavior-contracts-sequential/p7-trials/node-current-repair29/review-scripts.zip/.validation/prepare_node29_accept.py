"""Freeze independent desktop results before canonical Node acceptance.

This receipt records reviewer actions. It cannot accept an application, revise
its native outcomes, or fill missing events in an existing recording.
"""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / '.validation/p7-trials/node-retest-app'
OUT = ROOT / '.validation/p7-trials/node-repair29-desktop'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


sequence = read(OUT / 'sequence.json')
assert sequence['valid']
checks = []
for name in ('readiness', 'layers', 'timeline', 'arrows', 'controls', 'captions', 'range'):
    receipt = name + ('/report.json' if name == 'readiness' else '/result.json')
    result = read(OUT / receipt)
    assert result['valid'], (name, result.get('failure'))
    checks.append({'name': name, 'valid': True, 'receipt': receipt,
                   'sha256': hashlib.sha256((OUT / receipt).read_bytes()).hexdigest()})
save('independent-desktop.json', {'valid': True, 'checks': checks,
    'scope': 'Actual desktop review on one recorded repair29 candidate; native acceptance remains separate.'})

controls = read(OUT / 'controls/result.json')
assert controls['native_exclusion_status'] == 'passed'
assert controls['native_before'] == controls['native_after']
assert not controls['observer_requests']
personal = APP / 'bo_stategraph/config/views/local.json'
save('preferences-before-accept.json', {'valid': True,
    'meaning': 'Desktop checks intentionally saved views, positions and an annotation. Freeze the resulting settings for acceptance; do not claim equality to the pre-UI settings.',
    'controls_receipt': 'controls/result.json',
    'after_sha256': hashlib.sha256(personal.read_bytes()).hexdigest(),
    'after_revision': read(personal)['revision']})
print(json.dumps({'valid': True, 'checks': len(checks), 'preferences_revision': read(personal)['revision']}))
