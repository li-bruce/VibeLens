"""Publish the final scoped review only after both canonical acceptances exist."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
P7 = ROOT / 'docs/review/behavior-contracts-sequential/p7-trials'
APP = ROOT / '.validation/p7-trials/node-retest-app'
RUN = APP / 'review/runtime/repair29-provider-unification-20261122'
OUT = P7 / 'node-current-repair29'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def replace(path, old, new):
    text = path.read_text(encoding='utf-8')
    assert old in text, (path, old)
    path.write_text(text.replace(old, new, 1), encoding='utf-8')


py = read(P7 / 'python-current-repair29/results.json')
js = read(OUT / 'results.json')
assert py['valid'] and js['valid'] and py['accepted'] and js['accepted']
assert read(ROOT / '.validation/p7-trials/node-repair29-accept/check.json')['valid']

# Include every candidate input, not just files classified as graph source.
# Raw runtime archives already retain the sealed copies; this separate package
# gives reviewers one directly indexed set of all 73 verified current inputs.
members = []
snapshot = read(RUN / 'current-static-snapshot.json')
with zipfile.ZipFile(OUT / 'candidate-inputs.zip', 'x', zipfile.ZIP_DEFLATED) as bundle:
    for name, expected in sorted(snapshot['files'].items()):
        assert expected is not None
        data = (APP / name).read_bytes()
        actual = hashlib.sha256(data).hexdigest()
        assert actual == expected, name
        bundle.writestr(name, data)
        members.append({'member': name, 'bytes': len(data), 'sha256': actual})
archive = OUT / 'candidate-inputs.zip'
entry = {'archive': archive.name, 'bytes': archive.stat().st_size,
         'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}
save(OUT / 'candidate-inputs.json', {**entry, 'members': members})
js['archives'].append({**entry, 'members': len(members)})
js['verified_candidate_inputs'] = len(members)
js['nonblocking_findings'] = [
    'The supplementary fresh-live smoke logged one resource 404 without its URL. Required UI actions passed; the resource cause is not established.',
    'The full viewer replay toolbar may cover the upper canvas; focused product scenes avoid that layout.']
save(OUT / 'results.json', js)

replace(OUT / 'README.md', '# Node observe — consolidated repair 29 acceptance',
        '# Node observe — consolidated repair 29 acceptance\n\n[中文审阅](README.zh-CN.md)')
replace(OUT / 'README.md', '- [Source and models](source-and-models.json): the accepted configured source and declarations.',
        '- [Source and models](source-and-models.json): the accepted graph sources and declarations.\n'
        '- [All candidate inputs](candidate-inputs.json): all 73 verified source, integration, documentation and test inputs, with exact candidate hashes.')
replace(OUT / 'README.md', 'Native databases and collector secrets remain local.',
        'Native databases and collector secrets remain local.\n\n'
        'The supplementary fresh-live smoke retained one resource-404 console message\n'
        'without its URL. Required login/list actions passed and the viewer tests had\n'
        'no JavaScript page errors; the resource cause remains a follow-up finding.\n'
        'The full viewer replay toolbar can cover the upper canvas, as already\n'
        'recorded in the product review. Neither finding is described as repaired.')

status = read(P7 / 'batch-status.json')
status['previous_provider_commit'] = status['provider_commit']
status['provider_commit'] = status['candidate_provider_commit']
status['phase_status'] = 'complete'
status['pending'] = []
for row in status['issues']:
    if row['id'] in {'R27-09', 'R28-01', 'R28-02', 'R29-01', 'R29-02'}:
        row['status'] = 'verified_for_repair29_provider'
        row['previous_scope'] = row['scope']
        row['scope'] = ('Consolidated provider/application repairs, original checks, two gap-free native recordings, '
                        'seven independent desktop groups and canonical accept/check passed on the exact repair29 candidate. '
                        'Earlier failures and the stronger overflowing synthetic burst remain preserved.')
        row['previous_evidence'] = row['evidence']
        row['evidence'] = 'node-current-repair29/results.json'
status['follow_up_findings'] = js['nonblocking_findings']
status['completion_scope'] = 'The planned P0-P7 acceptance scope; optional formal-analysis fixtures remain distinct from the real application trials.'
save(P7 / 'batch-status.json', status)

replace(P7 / 'README.md', 'Current evidence:',
        '**P7 complete.** Both current-provider trials passed native and independent desktop acceptance.\n'
        'The [final scoped A01–A34 review](consolidated-review/README.md) distinguishes actual application results from fixtures.\n\n'
        'Current evidence:')
replace(P7 / 'README.md', '  passed. [Python drive maintenance](python-current-repair29/README.md) is accepted\n'
        '  on this provider. The existing Node observe trial is completing its same-batch\n'
        '  wiring repairs and native acceptance.',
        '  passed. [Python drive](python-current-repair29/README.md) and\n'
        '  [Node observe](node-current-repair29/README.md) are accepted on this provider.\n'
        '  The current batch opened no new chats; original failed records remain unchanged.')
replace(P7 / 'README.md', 'Node\'s latest refactor/capture acceptance, final-provider compatibility and the\n'
        'consolidated matrix remain open. The accepted semantic iteration and\n'
        '[product scene checks](product-forest-27/results.json) are preserved separately.',
        'Final-provider compatibility, native capture and the consolidated matrix are complete.\n'
        'The earlier accepted semantic iteration and [product scene checks](product-forest-27/results.json)\n'
        'retain their own source identities. Follow-up usability findings are listed in the final review.')
replace(P7 / 'README.md', 'Status: in progress. P0–P6 were implemented, regressed and committed before',
        '## Historical development record\n\nP0–P6 were implemented, regressed and committed before')

plan = ROOT / 'docs/development/behavior-contracts'
replace(plan / 'README.md', '**Current status: P0–P6 implemented and regressed; P7 independent trials in progress.**',
        '**Current status: P0–P7 complete within the documented acceptance scope.**\n'
        '[Final review](../../review/behavior-contracts-sequential/p7-trials/consolidated-review/README.md) retains failures, repairs and exact-candidate retests.')
replace(plan / 'README.zh-CN.md', '**当前进度：P0–P6 已完成实现与回归，P7 正在进行独立对话试用。**',
        '**当前进度：P0–P7 已按约定验收范围完成。**\n'
        '[最终审查](../../review/behavior-contracts-sequential/p7-trials/consolidated-review/README.md)保留失败、修复、准确候选版本的复测和后续体验问题；本轮没有新建复测对话。')

replace(P7 / 'repair-29/README.md', '## Remaining work', '## Final native acceptance')
replace(P7 / 'repair-29/README.md', 'accepted receipts were frozen. Next, review provider maintenance and all remaining\n'
        'Node issues together before one native/desktop acceptance batch. Keep the accepted Python provider evidence separate from new-provider\n'
        'results. A24–A34 remain tied to exact source, provider, candidate and recording\n'
        'identities. No main merge, release or site deployment is included.',
        'accepted receipts were frozen. [Python drive](../python-current-repair29/README.md)\n'
        'and [Node observe](../node-current-repair29/README.md) then passed complete native,\n'
        'recording, independent desktop and canonical acceptance on provider `0ac64bc0`.\n'
        'Node retained all 666 fields and original limits; its two records contain\n'
        '2,514 and 9,882 events without gaps. The stronger synthetic overflow above\n'
        'remains a capacity boundary, separate from the accepted real workload.\n'
        'No main merge, release or site deployment is included.')
repair = read(P7 / 'repair-29/results.json')
repair['final_native_acceptance'] = {'status': 'passed', 'python': '../python-current-repair29/results.json',
    'node': '../node-current-repair29/results.json', 'note': 'Original pending fields describe the earlier repository-gate checkpoint.'}
save(P7 / 'repair-29/results.json', repair)
print(json.dumps({'documents_updated': True, 'candidate_inputs': len(members)}))
