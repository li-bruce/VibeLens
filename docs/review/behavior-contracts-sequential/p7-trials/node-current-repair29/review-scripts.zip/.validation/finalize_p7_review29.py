"""Record the reviewer's scoped A-case decisions after all final receipts exist.

This is a repository review ledger, not an application acceptance authority.
Canonical trial accept/check must already have succeeded on exact candidates.
"""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE = 'docs/review/behavior-contracts-sequential/'
P7 = BASE + 'p7-trials/'
OUT = ROOT / P7 / 'consolidated-review'
read = lambda path: json.loads((ROOT / path).read_text(encoding='utf-8'))
save = lambda path, value: (ROOT / path).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

python = read(P7 + 'python-current-repair29/results.json')
node = read(P7 + 'node-current-repair29/results.json')
product = read(P7 + 'product-forest-27/results.json')
targeted = read(P7 + 'consolidated-review/targeted-results.json')
assert python['valid'] and node['valid']
assert node['accepted']['candidate_id'] and python['accepted']['candidate_id']
assert node['desktop']['valid'] and node['range']['valid']
assert python['desktop']['valid'] and python['range']['valid']
assert targeted['status'] == 'passed' and all(row['passed'] for row in targeted['checks'])
assert product['presentation_gate'] == 'passed'
shared = read(P7 + 'repair-29/results.json')
assert shared['targeted']['valid'] and shared['full_repository_gate']['valid']
assert python['provider_commit'] == node['provider_commit'] == '0ac64bc0074abb4509def9b135a4fdfd1fc81c39'

phase = lambda name: BASE + name + '/results.json'
p1, p2, p3 = [phase(x) for x in ('p1-completion', 'p2-routing', 'p3-native')]
p4, p5, p6 = [phase(x) for x in ('p4-closure', 'p5-viewer', 'p6-analysis')]
py, js = P7 + 'python-current-repair29/results.json', P7 + 'node-current-repair29/results.json'
focused = P7 + 'consolidated-review/targeted-results.json'
full = P7 + 'repair-29/results.json'
story = P7 + 'product-forest-27/results.json'
cases = {}


def case(identity, evidence, scope):
    """Keep the actual support and limits adjacent to each acceptance decision."""
    for path in evidence:
        assert (ROOT / path).is_file(), path
    cases[identity] = {'status': 'passed', 'evidence': evidence, 'scope': scope}


case('A01', [p2, focused, py, js], 'Actual product-oriented Python and developer-oriented Node dialogue; all supported role, skipped preference and changed-preference semantics additionally use labeled routing fixtures, not fresh chats for every role.')
case('A02', [p2, focused], 'Separate human intent, agent implementation work and source-backed facts; role never grants authority and unanswered facts cannot become user confirmation.')
case('A03', [p2, focused, py, js], 'More than three obligations persist across small rounds; partial/conditional replies, silence, corrections and restart retain history. Actual trials include repeated semantic clarification.')
case('A04', [p1, full], 'Strict version/type/reference/ownership/frame validation and source-free drafts; the complete current-provider gate retains negative cases.')
case('A05', [p1, p6, full], 'Finite admission rejects unbounded selected domains and identity histories. The two application trials do not claim finite exhaustive analysis.')
case('A06', [p1, p3, p6], 'Analysis bounds and abstraction remain separate from actual application capacity and concrete-value correspondence.')
case('A07', [p1, p3, py, js, story], 'Multiple model-qualified local state names and runtime instances stay distinct; unrelated models persist through iteration. Product activity uses the same qualified identities.')
case('A08', [p3, py, js], 'Native controlled revoke-before-start, restore/new-request and started-before-revoke cases complement actual ordinary scheduling. Initial and changed trial policies remain distinct.')
case('A09', [p3, full], 'Real native interaction/barrier fixtures check resource, join, cancellation and ownership witnesses. Unsupported native engine semantics remain rejected; these are separately scoped fixture results.')
case('A10', [p1, p3, p6, full], 'Selected recovery/environment/message behaviors are explicit in contract and native fixtures; empty/impossible initial models and unsupported analysis are rejected. Neither file-sharing trial claims arbitrary distributed delivery guarantees.')
case('A11', [p3, p5, py, js], 'Actual nested calls, reads and action completion retain distinct invocation/model identities; recorded positive business lifetimes and causal routes are inspected in Graph/Timeline.')
case('A12', [p3, py, js, full], 'Native on/off/fault parity, capture failure/gap tests and observer exclusion pass. Viewer actions preserve native rows; optional analysis does not execute business effects.')
case('A13', [p3, py, js, full], 'Actual early/error HTTP responses, completion and detached native ownership are checked. Failed/incomplete ordinary recording evidence remains labeled incomplete.')
case('A14', [p3, p4, full, py, js], 'Owned-source inventory is independent of existing graph nodes; missing mapped source/action/capture obligations are rejected. Both real source refactors regenerate mappings.')
case('A15', [p3, p4, py, js], 'Retained negative probe/value/commit cases fail strict gates; detached-copy omissions do not modify the accepted application or fabricate missing events.')
case('A16', [p4, focused, py, js], 'Source moves/rebinding are separated from meaning changes; shared-rule consumers are invalidated. Native refactors and the frontend dependency failure/recovery have distinct evidence.')
case('A17', [p2, p4, full, py, js], 'Durable recall, scope and freshness gates plus managed-provider integrity preserve obligations across interruption and host execution. Activation remains explicitly scoped; no automatic host hook is claimed.')
case('A18', [p3, p4, py, js, P7 + 'consolidated-review/targeted/native-browser-gate-regression.json'], 'Mapping/capture/business/project outcomes remain separate. A real GUI failure with passing native verification is retained and rejected by complete acceptance.')
for identity in ('A19', 'A20', 'A21', 'A22'):
    prior = read(p6)['case_results'][identity]
    assert prior['status'] == 'passed' and prior['evidence']
    case(identity, [p6, full], 'Retain the executed P6 case and its original raw TLC/native/Graph/Timeline evidence; no TLC analysis is attributed to the two file-sharing applications.')
case('A23', [p1, full, py, js], 'Actual migration/rollback/stale-writer/overlap tests and unchanged host retest; accepted trial identities, previous records and personal views survive generation/refactoring.')
case('A24', [P7 + 'architecture-review.md', full, py, js], 'Reviewed source ownership, comments, native adapter boundary and clean installed provider. JSON dictionaries still require boundary validation; formatting is not treated as architecture proof.')
case('A25', [py, js, p5, story], 'Independent actual desktop layers, expansion/camera, saved controls/annotations, locales, arrows, lifetimes and nonempty Timeline range. Upper floating control occlusion remains a documented usability limit.')
case('A26', [story], 'Bilingual focused scenes preserve every declared state/guard and actual record hashes; original homepage/legacy/loading/startup checks also passed. No public deployment performed.')
case('A27', [p3, full, py, js], 'Real Python drive and Node observe trials; reverse modes and React/Vue adapters use existing executed fixtures. No arbitrary frontend-framework equivalence claim.')
case('A28', [py, js, full, story], 'Two authorized existing fresh-start chats, real design/build/observation, semantic changes, source-only refactors, clean provider installation and complete repaired-candidate checks. No new chat per defect.')
case('A29', [p1, p2, focused, py, js], 'Source-free independent capabilities and shared predicates match the test requests; each trial retains four state models without forcing one connected route.')
case('A30', [p1, p2, focused], 'Source-backed missing model/relation obligations survive empty questions and target promotion; containment cannot satisfy a required semantic relation.')
case('A31', [p2, focused, py, js], 'Actual two-role conversations plus labeled role/grouped/partial/conditional/resume fixtures preserve common semantics and decision history; browser remains a viewer.')
case('A32', [p1, p2, p5, focused], 'Exact reviewed scope, explicit omissions, stale snapshot rejection and canonical model identities; hiding a network does not erase its validation obligations.')
case('A33', [p4, focused, py, js], 'Explicit business-network split/retirement regressions, independent capability addition, shared-rule impact and actual pure-source refactors. No redundant intent confirmation for unchanged code meaning.')
case('A34', [py, js, story, full], 'Both accepted complete native trials cover their selected models and boundary obligations; prepared scenes retain accepted epoch definitions. Optional TLC and interaction-fixture support are identified separately.')
assert set(cases) == {f'A{i:02}' for i in range(1, 35)}
evidence = sorted({path for row in cases.values() for path in row['evidence']})
result = {
    'schema': 'vibelens-development-evidence/v1', 'phase': 'P7', 'status': 'complete',
    'branch': 'feat/behavior-contracts-sequential',
    'provider_commit': '0ac64bc0074abb4509def9b135a4fdfd1fc81c39',
    'python_candidate': python['accepted'], 'node_candidate': node['accepted'],
    'new_chats_this_repair_batch': 0, 'case_results': cases,
    'evidence_files': [{'path': path, 'sha256': hashlib.sha256((ROOT / path).read_bytes()).hexdigest()}
                       for path in evidence],
    'interpretation': 'Scoped repository acceptance decisions based on retained executed tests and independent review; not a proof of arbitrary generated-program correctness.',
}
result_path = P7 + 'consolidated-review/results.json'
save(result_path, result)
plan_path = 'docs/development/behavior-contracts/progress.json'
plan = read(plan_path)
for row in plan['cases']:
    row['status'] = 'passed'
    if result_path not in row['evidence']:
        row['evidence'].append(result_path)
for row in plan['phases']:
    if row['id'] == 'P7':
        row['status'] = 'complete'
        if result_path not in row['evidence']:
            row['evidence'].append(result_path)
save(plan_path, plan)
print(json.dumps({'phase': 'P7', 'status': 'complete', 'cases': len(cases)}))
