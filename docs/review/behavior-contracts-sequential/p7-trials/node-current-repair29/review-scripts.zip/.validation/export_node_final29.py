"""Archive a completed Node candidate without mixing it with failed epochs.

Native databases and installed dependencies stay local. Each exported original
has an immutable member digest; known collector secrets are checked before writing.
"""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / '.validation/p7-trials/node-retest-app'
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda data: hashlib.sha256(data).hexdigest()

parser = argparse.ArgumentParser(description=__doc__)
for key in ('runtime', 'ui', 'accept', 'out'):
    parser.add_argument('--' + key, type=Path, required=True)
args = parser.parse_args()
assert read(args.accept / 'result.json')['valid']
assert read(args.ui / 'sequence.json')['valid']
assert read(args.ui / 'range/result.json')['valid']
post = read(args.runtime / 'verify-after-browser.json')
accepted = read(args.accept / 'result.json')['accepted']
assert post['valid'] and post['candidate_id'] == accepted['candidate_id']
args.out.mkdir(exist_ok=False)
secrets = []
collector = APP / '.stategraph/collector.json'
if collector.exists():
    token = read(collector).get('token')
    if isinstance(token, str) and len(token) >= 8:
        secrets.append(token.encode())


def save(name, value):
    (args.out / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def selected(folder, recursive=False):
    """Select bounded review artifacts, never database/account/cache files."""
    paths = folder.rglob('*') if recursive else folder.iterdir()
    allowed = {'.json', '.jsonl', '.log', '.md', '.py', '.png', '.jpg', '.mjs', '.js', '.html', '.css', '.body'}
    return {p.relative_to(folder).as_posix(): p for p in paths
            if p.is_file() and p.suffix in allowed and '__pycache__' not in p.parts}


def archive(name, paths):
    rows = []
    target = args.out / (name + '.zip')
    with zipfile.ZipFile(target, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as bundle:
        for member, path in sorted(paths.items()):
            data = path.read_bytes()
            assert not any(secret in data for secret in secrets), member
            bundle.writestr(member, data)
            rows.append({'member': member, 'bytes': len(data), 'sha256': sha(data)})
    with zipfile.ZipFile(target) as bundle:
        assert bundle.testzip() is None
        assert all(sha(bundle.read(row['member'])) == row['sha256'] for row in rows)
    index = {'archive': target.name, 'bytes': target.stat().st_size,
             'sha256': sha(target.read_bytes()), 'members': rows}
    save(name + '.json', index)
    return {**{key: index[key] for key in ('archive', 'bytes', 'sha256')}, 'members': len(rows)}


ordinary = Path(read(args.runtime / 'ordinary-unified-pointer.json')['path'])
browser = read(ordinary / 'browser-acceptance.json')
assert browser['build_id'] == accepted['build_id'] and not browser.get('error')
native_files = selected(args.runtime, recursive=True)
native_files.update({'ordinary/' + name: path for name, path in selected(ordinary).items()})
for record in browser['recordings']:
    path = APP / 'bo_stategraph/data/recordings' / (record['id'] + '.json')
    value = read(path)
    assert value['status'] == 'stopped' and not value['gaps']
    native_files['recordings/' + path.name] = path
native = archive('native-evidence', native_files)
desktop = archive('desktop-evidence', selected(args.ui, recursive=True))
# Earlier failed epochs already have immutable public archives under repair-28.
# The current runtime folder contains this batch's original failures and repairs.
scope = read(args.ui / 'scope-before-accept/scope.json')
change = read(APP / '.stategraph/active.json')['change']
paths = set(scope['source_hashes']) | {
    'bo_stategraph/project.json', 'manifest.json', 'discovery.json', 'intent.json',
    'acceptance.json', 'behavior.json', change + '/accepted.json', change + '/review.json',
}
source = archive('source-and-models', {name: APP / name for name in paths})
root_accept = archive('root-acceptance', {p.name: p for p in args.accept.iterdir() if p.is_file()})
provider_review = read(ROOT / '.validation/p7-trials/node-repair29-provider-review.json')
assert provider_review['valid'] and provider_review['owned_files_checked'] == 467
save('provider-review.json', provider_review)
shots = args.out / 'screenshots'
shots.mkdir()
for name in ('layers/business-2D.png', 'layers/states-3D-expanded.png',
             'timeline/timeline-causal-links.png', 'range/selected-native-interval.png',
             'captions/source-visible.png', 'controls/retained-annotation.png'):
    shutil.copy2(args.ui / name, shots / name.replace('/', '-'))
save('results.json', {
    'valid': True, 'phase': 'P7', 'phase_status': 'in_progress', 'new_chats': 0,
    'provider_commit': '0ac64bc0074abb4509def9b135a4fdfd1fc81c39', 'accepted': accepted,
    'reports': {key: value['status'] for key, value in post['reports'].items()},
    'native_browser_checks': browser['checks'], 'records': browser['recordings'],
    'business_assertions': post['reports']['business']['assertions'],
    'provider_review': provider_review,
    'desktop': read(args.ui / 'sequence.json'), 'range': read(args.ui / 'range/result.json'),
    'source_inputs': len(scope['source_hashes']),
    'archives': [native, desktop, source, root_accept],
    'prior_failed_epochs': '../repair-28/native-results.json',
    'privacy': {'native_database_exported': False, 'known_collector_secret_matches': 0},
    'interpretation': 'Failed prior ordinary recording and successful targeted repairs are separate epochs. Complete final native/browser/viewer evidence belongs to this exact accepted candidate.',
})
print(json.dumps({'valid': True, 'archives': [native, desktop, source, root_accept]}))
