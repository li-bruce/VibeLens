"""Review the stable repair29 source with standard tools and bind the exact build for one batch."""
from collections import Counter
import shutil
import sys
from repair_tools import APP, PACK, RUN, CHANGE, PY, load, save, sha, cli, execute

assert load(RUN / "targeted-entry-build-summary.json")["valid"]
assert not load(RUN / "ordinary-default-dev-stop.json")["remaining_listeners"]
cli("final-source-scan", "bo_sync.py", "scan")
cli("final-code-scan", "bo_code.py", "scan")
cli("final-documentation", "bo_code.py", "docs", "--strict")
cli("final-api", "bo_code.py", "api-check", "--strict")
cli("provider3-name-inventory", "bo_names.py", "inventory")
execute("provider3-name-review", [PY, "-B", "-X", "utf8", RUN / "update_names.py", "provider3"])
inspection = cli("final-inspect-before-review", "change_sync.py", "inspect", allow_failure=True)
assert not inspection["errors"] and inspection["review_errors"] == ["review belongs to an older candidate"]
review = load(APP / CHANGE / "review.json")
review["candidate_id"] = inspection["candidate_id"]
review["provider_unification"] = {
    "request_source": "Same-chat main-session explicit repair29 D1/P1/P2/B1/B2/D2 instruction",
    "default_configuration": "integrations/provider.json",
    "provider_commit": "0ac64bc0074abb4509def9b135a4fdfd1fc81c39",
    "behavior": "Retain the confirmed preparation-start recheck, announcement and login behavior; update misleading current documentation without rewriting historical evidence.",
    "implementation": "Common process-local Python/Node resolver, explicit conflict failure, provider-selected optional OTel/TypeScript, default npm build/dev selection and dependency/metafile receipts.",
    "targeted": "Ten default/override/conflict resolver cases; actual ordinary npm build and dev with both provider variables absent; actual conflicting npm build/dev reject before services or bundle writes.",
    "scope": "No new business meaning, native field, command-array, queue, batch, envelope, request deadline, retry or 180-second limit change. Continue original baseline; no accept.",
}
save(APP / CHANGE / "review.json", review)
ready = cli("final-inspect-ready", "change_sync.py", "inspect")
assert ready["candidate_id"] == inspection["candidate_id"]
sys.path.insert(0, str(PACK / "scripts"))
from sync_config import config, snapshot
from behavior_model import capture
from bo_observer.model_io import read_model
snap = snapshot(APP, config(APP, "sync.json"), load(APP / CHANGE / "baseline.json"))
assert snap["id"] == ready["candidate_id"]
build = capture(APP, read_model(APP / "bo_stategraph/project.json", project_root=APP))
assert build == load(RUN / "generated-manifest-before-default-dev.json")
before = load(RUN / "before-seal.json")
old = load(RUN / "before/bo_stategraph/project.json")["model"]
model = snap["model"]
def fields(value):
    return {(node["id"], direction, key): item for node in value["nodes"] for direction in ("in", "out")
            for key, item in node.get("capture", {}).get(direction, {}).items()}
assert fields(model) == fields(old) and len(fields(model)) == 666
assert all(model[key] == old[key] for key in ("machines", "policy", "concepts"))
assert all(sha(APP / name) == value for name, value in before["record_hashes"].items())
assert sha(APP / "var/db/application.sqlite") == before["database_sha256"]
assert sha(APP / "bo_stategraph/config/views/local.json") == before["source_hashes"]["bo_stategraph/config/views/local.json"]
assert sha(APP / CHANGE / "baseline.json") == before["active_baseline_sha256"]
for name in before["source_hashes"]:
    if name.startswith(("src/", "public/")):
        assert sha(APP / name) == before["source_hashes"][name], name
    if name.startswith("tests/"):
        old_lines = (RUN / "before" / name).read_text(encoding="utf-8").splitlines()
        now_lines = (APP / name).read_text(encoding="utf-8").splitlines()
        assert Counter(line.strip() for line in old_lines if "assert" in line) == Counter(line.strip() for line in now_lines if "assert" in line)
assert load(APP / "sync.json")["test_commands"] == before["test_commands"]
assert load(APP / "sync.json")["timeout_seconds"] == 180
assert all(sha(PACK / name) == value for name, value in load(RUN / "provider-files-before.json").items())
save(RUN / "current-static-snapshot.json", snap)
save(RUN / "derived-build.json", build)
save(RUN / "candidate-build.json", {"candidate_id": snap["id"], "build_id": build["build_id"],
    "provider_commit": "0ac64bc0074abb4509def9b135a4fdfd1fc81c39", "full_runtime_verified": False, "accept_executed": False})
save(RUN / "runtime-before-seal.json", {**before, "source_hashes": snap["files"]})
save(RUN / "static-preservation.json", {"valid": True, "candidate_id": snap["id"], "build_id": build["build_id"],
    "source_files_checked": len(snap["files"]), "fields_identical": 666, "model_nodes": len(model["nodes"]),
    "business_code_assertions_and_native_declarations_unchanged": True,
    "database_views_39_records_original_baseline_unchanged": True,
    "provider_initial_file_bytes_unchanged": len(load(RUN / "provider-files-before.json")),
    "original_six_arrays_and_180s_unchanged": True,
    "real_default_build_dev_and_conflict_cases_passed": True, "accept_executed": False})
out = RUN / "sealed-source"
out.mkdir(exist_ok=False)
for name in snap["files"]:
    if (APP / name).is_file():
        target = out / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(APP / name, target)
print({"candidate_sealed": True, "candidate_id": snap["id"], "build_id": build["build_id"], "fields": 666,
       "default_entrypoints_tested": True, "full_batch_pending": True}, flush=True)
