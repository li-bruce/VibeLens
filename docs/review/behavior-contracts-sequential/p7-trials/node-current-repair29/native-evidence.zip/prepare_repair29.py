"""Seal current source/data/history and restore the existing change without resetting it."""
import importlib.metadata
import shutil
import urllib.request
from repair_tools import APP, PACK, RUN, CHANGE, load, save, sha, cli

def get(url):
    with urllib.request.urlopen(url, timeout=35) as response:
        return __import__("json").load(response)

health = get("http://127.0.0.1:8925/api/bo/health")
recordings = get("http://127.0.0.1:8926/api/recordings")
assert recordings["active"] is None and health["pending"] == 0 and health["tracing"]["open_spans"] == 0
assert load(APP / ".stategraph/active.json")["change"] == CHANGE
assert not (APP / CHANGE / "accepted.json").exists()
save(RUN / "health-before.json", health)
save(RUN / "recordings-before.json", recordings)
paths = {path.relative_to(APP).as_posix() for folder in ("src", "public", "integrations", "tests", "tooling")
         for path in (APP / folder).rglob("*") if path.is_file() and "__pycache__" not in path.parts}
paths.update(path.name for path in APP.iterdir() if path.is_file())
paths.update(("bo_stategraph/project.json", "bo_stategraph/integration.json", "bo_stategraph/native-bindings.json",
    "bo_stategraph/bo_runtime.mjs", "bo_stategraph/bo_capture.mjs", "bo_stategraph/bo_http.mjs",
    "bo_stategraph/config/views/local.json", "bo_stategraph/config/semantic-names.json", "bo_stategraph/config/assets/client.mjs",
    "bo_stategraph/databases.json", "bo_stategraph/database-catalog.json", "bo_stategraph/database-declaration.json"))
out = RUN / "before"
out.mkdir(exist_ok=False)
for name in sorted(paths):
    destination = out / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(APP / name, destination)
shutil.copy2(APP / "var/db/application.sqlite", RUN / "database-before.sqlite")
for name in ("baseline.json", "review.json", "verification.json"):
    shutil.copy2(APP / CHANGE / name, RUN / ("previous-change-" + name))
records = {path.relative_to(APP).as_posix(): sha(path) for path in (APP / "bo_stategraph/data/recordings").glob("*.json")}
assert len(records) == 39
provider = {path.relative_to(PACK).as_posix(): sha(path) for path in PACK.rglob("*")
            if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc"}
save(RUN / "provider-files-before.json", provider)
save(RUN / "before-seal.json", {"source_hashes": {name: sha(APP / name) for name in sorted(paths)},
    "record_hashes": records, "database_sha256": sha(APP / "var/db/application.sqlite"),
    "personal_view_revision": load(APP / "bo_stategraph/config/views/local.json")["revision"],
    "test_commands": load(APP / "sync.json")["test_commands"], "timeout_seconds": load(APP / "sync.json")["timeout_seconds"],
    "active_change": CHANGE, "active_baseline_sha256": sha(APP / CHANGE / "baseline.json"),
    "previous_accepted_hashes": {path.relative_to(APP).as_posix(): sha(path)
        for path in (APP / "download-start-permission-20261121").glob("*.json")},
    "provider": str(PACK), "reported_commit": "0ac64bc0074abb4509def9b135a4fdfd1fc81c39",
    "reported_maintained_files": 467, "all_provider_files_baseline": len(provider),
    "jsonschema_rs_version": importlib.metadata.version("jsonschema-rs"), "no_accept": True})
save(RUN / "request-supplement.json", {"scope": "D1/P1/P2/B1/B2/D2 unified provider and current documentation repair; keep all confirmed application behavior.",
    "provider": str(PACK), "same_chat": True, "continue_active_change": True,
    "baseline_replacement_allowed": False, "new_business_requirements": [],
    "full_acceptance_authorized": True, "ordinary_attempts_allowed": 1, "accept_allowed": False,
    "preserve": "39 raw records, actual SQL, latest personal views, original six arrays/assertions/666 definitions and all original queue/batch/time limits."})
recall = cli("recall-before", "change_sync.py", "recall")
print({"sealed": True, "old_records": len(records), "preferences_revision": load(RUN / "before-seal.json")["personal_view_revision"],
       "provider_files": len(provider), "jsonschema_rs": importlib.metadata.version("jsonschema-rs"),
       "recall_valid": recall.get("valid")}, flush=True)
