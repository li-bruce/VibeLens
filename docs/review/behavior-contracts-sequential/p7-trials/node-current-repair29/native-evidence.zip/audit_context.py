"""Read-only comparison of new context boundaries with witnessed original events."""
from pathlib import Path
from runtime_tools import APP, RUN, load, save, sha

seal = load(RUN / "normal-stop-original-seal.json")
unified = Path(seal["unified_run"])
records = [load(unified / ("independent-recording-" + item["id"] + ".json")) for item in seal["recordings"]]
earlier = {}
results = []
omitted = {"context_only", "context_boundary", "inputs", "outputs", "depends", "basis", "revision", "provenance", "exception"}
for position, record in enumerate(records):
    context, own = record["context"]["events"], record["events"]
    combined = {event["id"]: event for event in [*context, *own]}
    missing = [{"event_id": event["id"], "parent_event_id": event["parent_event_id"]}
               for event in combined.values() if event.get("parent_event_id") and event["parent_event_id"] not in combined]
    assert not missing, missing[:10]
    headers = [event for event in context if event.get("context_only") is True]
    compared = []
    for event in headers:
        assert event["inputs"] == event["outputs"] == event["basis"] == {}
        assert event["depends"] == [] and event["context_boundary"] in {"start", "end"}
        assert "revision" not in event and "provenance" not in event and "exception" not in event
        if position:
            source = earlier.get(event["id"])
            assert source is not None, event["id"]
            assert {k: v for k, v in event.items() if k not in omitted} == {k: v for k, v in source.items() if k not in omitted}
            compared.append({"id": event["id"], "seq": event["seq"], "node": event["node"],
                             "phase": event["phase"], "call_id": event["call_id"], "boundary": event["context_boundary"]})
    selection = record["context_selection"]
    assert selection["recent_value_limit"] == 2000
    assert selection["older_value_events_omitted"] == max(0, selection["available_history_events"] - 2000)
    assert len([event for event in context if not event.get("context_only")]) <= 2000
    assert record["status"] == "stopped" and record["gaps"] == []
    results.append({"id": record["id"], "own_events": len(own), "context_events": len(context),
                    "recent_full_value_events": sum(not event.get("context_only") for event in context),
                    "metadata_only_boundaries": len(headers), "context_selection": selection,
                    "missing_parent_references": len(missing), "older_boundaries_compared_to_previous_original": compared})
    earlier.update(combined)
assert all(sha(APP / name) == value for name, value in seal["record_file_sha256"].items())
save(RUN / "independent-context-closure-audit.json", {
    "valid": True, "records": results, "recent_value_limit_unchanged": True,
    "all_parent_references_retained": True, "older_boundary_metadata_matches_witnessed_originals": True,
    "source": "Unmodified consecutive exports. Older headers are compared with the first export's true event identities, phases, sequences, times and call metadata; no event is inserted or rewritten.",
})
print({"context_audit_valid": True, "records": [{k: value for k, value in row.items() if k != "older_boundaries_compared_to_previous_original"} for row in results]}, flush=True)
