"""Register the observer-only resolver/build inputs, then run the established project generator."""
from collections import Counter
from pathlib import Path
from repair_tools import APP, PACK, RUN, PY, load, save, sha, execute

cfg = load(APP / "sync.json")
model_document = load(APP / "bo_stategraph/project.json")
model = model_document["model"]
for name in ("integrations/bo_provider.cjs", "integrations/bo_provider.py"):
    if name not in cfg["code_files"]:
        cfg["code_files"].append(name)
    if name not in model["source_files"]:
        model["source_files"].append(name)
extra = ["integrations/provider.json", "tooling/build_observer.cjs", "tooling/provider_entry_checks.py",
         "tooling/dev.mjs", "tooling/document_callbacks.cjs", "README.md", "CURRENT_STATUS.md"]
extra += load(RUN / "entrypoint-source-update.json")["changed_files"]
for name in sorted(set(extra)):
    if name not in cfg["watch_files"]:
        cfg["watch_files"].append(name)
if "integrations/provider.json" not in model["source_files"]:
    model["source_files"].append("integrations/provider.json")
save(APP / "sync.json", cfg)
save(APP / "bo_stategraph/project.json", model_document)
before = load(RUN / "before-seal.json")
assert cfg["test_commands"] == before["test_commands"] and cfg["timeout_seconds"] == 180
execute("standard-project-generation", [PY, "-B", "-X", "utf8", "tooling/build_model.py"])
current = load(APP / "bo_stategraph/project.json")["model"]
old = load(RUN / "before/bo_stategraph/project.json")["model"]
def fields(value):
    return {(node["id"], direction, key): item for node in value["nodes"] for direction in ("in", "out")
            for key, item in node.get("capture", {}).get(direction, {}).items()}
assert fields(current) == fields(old) and len(fields(current)) == 666
for name in ("machines", "policy", "concepts"):
    assert current[name] == old[name], name
assert all(sha(APP / name) == digest for name, digest in before["record_hashes"].items())
assert sha(APP / "bo_stategraph/config/views/local.json") == before["source_hashes"]["bo_stategraph/config/views/local.json"]
assert sha(APP / "var/db/application.sqlite") == before["database_sha256"]
save(RUN / "standard-generation-preservation.json", {"valid": True, "fields": 666,
    "old_nodes": len(old["nodes"]), "current_nodes": len(current["nodes"]),
    "machines_policy_concepts_identical": True, "test_commands_identical": True,
    "case_timeout_seconds": 180, "database_views_and_39_records_unchanged": True,
    "new_code_files": ["integrations/bo_provider.cjs", "integrations/bo_provider.py"],
    "new_verified_inputs": sorted(set(extra))})
print({"standard_generation_valid": True, "fields": 666, "nodes": len(current["nodes"]),
       "business_declarations_unchanged": True}, flush=True)
