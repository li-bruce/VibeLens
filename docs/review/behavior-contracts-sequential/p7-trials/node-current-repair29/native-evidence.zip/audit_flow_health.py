"""Summarize only the preserved unprofiled ordinary run, retaining exact health and limits."""
from collections import Counter
from pathlib import Path
import json
from runtime_tools import APP, RUN, load, save, sha

seal = load(RUN / "normal-stop-original-seal.json")
unified = Path(seal["unified_run"])
lifecycle = load(unified / "lifecycle.json")
acceptance = load(unified / "artifacts/browser-acceptance.json")
assert lifecycle["completed"] and all(acceptance["checks"].values())
health = lifecycle["pre_cleanup_native_health"]
assert health["pending"] == health["errors"] == health["dropped"] == 0
assert health["tracing"]["open_spans"] == health["capture_control_errors"] == 0
samples = [json.loads(line) for line in (unified / "native-idle.jsonl").read_text(encoding="utf-8").splitlines()]
assert all(row["health"]["dropped"] == row["health"]["errors"] == 0 for row in samples)
for item in seal["recordings"]:
    assert item["status"] == "stopped" and item["gaps"] == []
    assert item["settlement"]["flushed"] and item["settlement"]["pending"] == 0
limits = {"native_waiting_queue": 8192, "browser_waiting_queue": 4096,
    "batch_events": 64, "batch_bytes": 262144, "envelope_bytes": 24576,
    "request_deadline_ms": 1000, "request_attempts": 2, "case_timeout_seconds": 180,
    "recent_full_value_context": 2000}
assert load(APP / "sync.json")["timeout_seconds"] == 180
assert "capacity: options.capacity || 8192" in (APP / "integrations/bo_observe.mjs").read_text(encoding="utf-8")
assert "capacity: 4096" in (APP / "integrations/bo_observe.mjs").read_text(encoding="utf-8")
sdk = (APP / "bo_stategraph/bo_runtime.mjs").read_text(encoding="utf-8")
assert "256 * 1024" in sdk and "timeout = 1000" in sdk and "attempt < 2" in sdk and "Math.min(64, prefix)" in sdk
waits = [{"stage": row["stage"], "started_ms": row["started_ms"], "ended_ms": row["ended_ms"],
    "elapsed_ms": row["elapsed_ms"], "result": row["result"],
    "first_health": row["first_health"], "last_health": row["last_health"]} for row in acceptance["idle_waits"]]
save(RUN / "ordinary-flow-health-audit.json", {"valid": True, "candidate_id": seal["candidate_id"],
    "build_id": seal["build_id"], "ordinary_command_exit_code": load(RUN / "ordinary-browser-recording-command.json")["exit_code"],
    "original_seven_groups": acceptance["checks"], "records": seal["recordings"],
    "native_health_at_stop": health, "health_sample_count": len(samples),
    "max_sampled_pending": max(row["health"]["pending"] for row in samples),
    "dropped_in_all_native_health_samples": 0, "unchanged_limits": limits, "idle_waits": waits,
    "stop_http_receipts": load(unified / "browser-stop-receipts.json"),
    "source_sdk_sha256": sha(APP / "bo_stategraph/bo_runtime.mjs"),
    "original_recording_files_unchanged": all(sha(APP / name) == value for name, value in seal["record_file_sha256"].items()),
    "scope": "Actual unprofiled original ordinary attempt only; fault/queue-limited controlled tests remain separate. No per-request collector timings or causal benchmark are inferred. Both old failed batches retain their original loss/gaps and bytes."})
print({"ordinary_health_valid": True, "seven_groups": len(acceptance["checks"]),
    "native_dropped": health["dropped"], "native_errors": health["errors"], "native_pending": health["pending"],
    "max_sampled_pending": max(row["health"]["pending"] for row in samples), "recordings": len(seal["recordings"])}, flush=True)
