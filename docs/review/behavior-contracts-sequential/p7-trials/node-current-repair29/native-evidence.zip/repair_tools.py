"""Run only the selected immutable repair29 provider and preserve distinct receipts."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

RUN = Path(__file__).resolve().parent
APP = RUN.parents[2]
REPOSITORY = APP.parents[2]
PACK = APP.parent / "admission-repair29-skills/vibelens"
PY = REPOSITORY / ".venv/Scripts/python.exe"
CHANGE = ".stategraph/announcement-module-bootstrap-20261122"
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1", PYTHONIOENCODING="utf-8",
           VIBELENS_PYTHON=str(PY), TEAM_FILES_SQLITE_URL="sqlite:///var/db/application.sqlite", APP_DATA_ROOT=str(APP / "var"))
for key in ("VIBELENS_SKILL", "BO_DIAGNOSTIC_SKILL", "VIBELENS_ENDPOINT"):
    ENV.pop(key, None)
ENV["BO_LOAD_CONTEXT"] = "Main session released this same-chat repair29 batch after complete provider, default-entry and browser-build fixes and targeted checks. Provider 0ac64bc is immutable. Keep all 666 fields, original six commands/180s, original seven browser checks, native8192/browser4096, 64-event/256KiB batch, 24KiB envelope, 1000ms/two attempts. Execute one ordinary two-recording attempt; retain any failure and perform valid independent audits. Preserve 39 raw records and actual data/preferences. No accept."

def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))

def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def execute(label, command, *, allow_failure=False, timeout=1200, env=None):
    output = RUN / (label + ".stdout.log")
    error = RUN / (label + ".stderr.log")
    assert not output.exists() and not error.exists(), label
    started = datetime.now(timezone.utc).isoformat()
    with output.open("xb") as out, error.open("xb") as err:
        result = subprocess.run([str(value) for value in command], cwd=APP, env=env or ENV,
            stdout=out, stderr=err, timeout=timeout, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    save(RUN / (label + "-command.json"), {"command": list(map(str, command)), "exit_code": result.returncode,
        "started_at": started, "finished_at": datetime.now(timezone.utc).isoformat(),
        "entry_environment": {key: (env or ENV).get(key) for key in ("VIBELENS_SKILL", "BO_DIAGNOSTIC_SKILL", "VIBELENS_PYTHON")}})
    print({"label": label, "exit_code": result.returncode}, flush=True)
    if result.returncode and not allow_failure:
        print((output.read_text(encoding="utf-8-sig") + error.read_text(encoding="utf-8-sig"))[-3500:], flush=True)
        raise RuntimeError("Preserved command failure: " + label)
    return result.returncode

def cli(label, script, *arguments, allow_failure=False):
    assert not (script == "change_sync.py" and arguments and arguments[0] == "accept")
    if script == "change_sync.py" and arguments and arguments[0] == "verify":
        assert load(RUN / "static-preservation.json")["valid"]
        assert load(RUN / "runtime-slot-status.json")["available_to_trial"]
    output = RUN / (label + ".json")
    assert not output.exists(), label
    command = [str(PY), "-B", "-X", "utf8", str(PACK / "scripts" / script), *map(str, arguments), "--root", str(APP)]
    started = datetime.now(timezone.utc).isoformat()
    with output.open("xb") as out, (RUN / (label + ".stderr.log")).open("xb") as err:
        result = subprocess.run(command, cwd=APP, env=ENV, stdout=out, stderr=err, timeout=1200,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    save(RUN / (label + "-command.json"), {"command": command, "exit_code": result.returncode,
        "started_at": started, "finished_at": datetime.now(timezone.utc).isoformat(), "provider": str(PACK)})
    try:
        value = load(output)
    except json.JSONDecodeError:
        value = {"valid": False, "errors": [(RUN / (label + ".stderr.log")).read_text(encoding="utf-8-sig")[-3000:]],
                 "non_json_cli_failure": True}
        save(RUN / (label + "-non-json-result.json"), value)
    print({"label": label, "exit_code": result.returncode, "valid": value.get("valid"),
           "candidate_id": value.get("candidate_id"), "errors_count": len(value.get("errors", [])),
           "review_errors_count": len(value.get("review_errors", []))}, flush=True)
    if result.returncode and not allow_failure:
        raise RuntimeError("Preserved canonical failure: " + label)
    return value
