"""Index existing same-run native cases, raw frames and independent stored task rows."""
from contextlib import closing
from pathlib import Path
import hashlib
import json
import shutil
import sqlite3
from runtime_tools import APP, RUN, load, save, sha

assert load(RUN / "verify-after-browser.json")["valid"]
out = RUN / "controlled-permission-evidence"
out.mkdir(exist_ok=False)
source = APP / "review/runtime/native-runs.json"
shutil.copy2(source, out / "native-runs-original.json")
payload = load(source)
build = load(RUN / "candidate-build.json")["build_id"]
assert payload["build_id"] == build
result = []
for run in payload["runs"]:
    if run["case"] != "controlled_start_permissions":
        continue
    root = Path(run["native_database"]).parent.parent
    original = load(root / "result.json")
    assert original == run
    mode_out = out / run["mode"]
    mode_out.mkdir()
    shutil.copy2(root / "result.json", mode_out / "result-original.json")
    shutil.copy2(run["native_database"], mode_out / "application.sqlite")
    shutil.copy2(run["native_order_file"], mode_out / "native-order-original.jsonl")
    image = (mode_out / "application.sqlite").read_bytes()
    with closing(sqlite3.connect(":memory:")) as db:
        db.deserialize(image)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA query_only=ON")
        tasks = {row["id"]: dict(row) for row in db.execute("SELECT * FROM tasks")}
    cases = {case["id"]: case for case in run["controlled_cases"]}
    denied = cases["start_denied"]
    denied_id = denied["task_id"]
    denied_row = tasks[denied_id]
    assert denied_row["status"] == "cancelled" and denied_row["revision"] == 2
    assert denied_row["authorized_at_submission"] == 1 and denied_row["last_error"] == "SHARING_REVOKED"
    assert all(denied_row[key] is None for key in ("started_at", "prepared_path", "sha256"))
    assert denied["pre_start_witness"]["grant"]["active"] == 0
    unchanged = cases["cancelled_no_revival"]
    assert unchanged["stored_before"] == unchanged["stored_after"] == denied_row
    assert unchanged["new_start_checks"] == 0
    # Same original result stores the replacement task between the cancelled task
    # and the following restored-before-start task in the independently selected SQL instances.
    bob_tasks = [instance for instance in run["authority_snapshot"]["instances"]
                 if instance.get("state_model_id") == "download_task" and instance.get("context", {}).get("requester_id") == "bob"]
    fixed_ids = {denied_id, cases["restored_before_start"]["task_id"], cases["started_before_revoke"]["task_id"]}
    replacement_ids = [ident for ident, row in tasks.items() if row["requester_id"] == "bob" and ident not in fixed_ids]
    assert len(replacement_ids) == 1
    replacement_id = replacement_ids[0]
    replacement = tasks[replacement_id]
    assert replacement_id != denied_id and replacement["status"] == "ready" and replacement["authorized_at_submission"] == 1
    assert replacement["file_id"] == denied_row["file_id"]
    assert hashlib.sha256(Path(replacement["prepared_path"]).read_bytes()).hexdigest() == replacement["sha256"]
    replacement_check = next(row for row in run["native_order"] if row["phase"] == "preparation_check" and row["task_id"] == replacement_id)
    assert replacement_check["grant"]["active"] == 1 and replacement_check["task"]["status"] == "queued"
    started = cases["started_before_revoke"]
    started_id = started["task_id"]
    assert tasks[started_id]["status"] == "ready"
    assert started["start"]["task"]["status"] == "preparing"
    assert next(row for row in started["revoke"]["tasks_at_grant"] if row["id"] == started_id)["status"] == "preparing"
    order = started["explicit_native_order"]
    assert order[0] < order[1] < order[2]
    assert run["observations"]["started_then_revoked"] == {"ready": True, "repeat_bytes_match": True}
    branches = []
    for name, ident, status in (("revoked_at_preparation_start", denied_id, "cancelled"),
                                ("reshared_new_request", replacement_id, "ready"),
                                ("started_before_revoke", started_id, "ready")):
        selected = [event for event in run["events"] if ident in str(event.get("inputs", {})) or ident in str(event.get("outputs", {}))]
        event_ids = {event["id"] for event in selected}
        snapshots = [frame for frame in run["snapshots"] if frame.get("instance_id") == ident]
        for frame in snapshots:
            assert frame["evidence_id"] in {event["id"] for event in run["events"]}
        raw_frames = [frame for frame in run["frames"]
                      if frame.get("kind") == "snapshots" and frame["body"].get("instance_id") == ident]
        if run["mode"] == "on":
            assert any(frame["state"] == status for frame in snapshots)
            assert any(event["node"] == "preparation_start_check" for event in selected)
            assert any(event["node"] == "preparation_start_commit" for event in selected)
            assert any(event["node"] == "state_value:download_task" for event in selected)
        save(mode_out / (name + "-raw-evidence.json"), {"case": run["case"], "mode": run["mode"],
            "branch": name, "task_id": ident, "events": selected, "snapshots": snapshots,
            "raw_submitted_state_frames": raw_frames,
            "native_order": [row for row in run["native_order"] if row.get("task_id") == ident or
                             any(task.get("id") == ident for task in row.get("tasks_at_grant", []))],
            "independent_sql_row": tasks[ident], "sql_query": "SELECT * FROM tasks WHERE id=?",
            "sql_parameters": [ident], "database_fixture": str(mode_out / "application.sqlite"),
            "database_sha256": sha(mode_out / "application.sqlite"),
            "no_historical_state_reconstruction": True})
        branches.append({"branch": name, "task_id": ident, "status": status,
            "event_ids_by_node": {node: [event["id"] for event in selected if event["node"] == node]
                                  for node in sorted({event["node"] for event in selected})},
            "state_frames": [{"state": frame["state"], "revision": frame["revision"],
                              "evidence_id": frame["evidence_id"]} for frame in snapshots],
            "raw_evidence": str(mode_out / (name + "-raw-evidence.json"))})
    result.append({"case": run["case"], "mode": run["mode"], "same_run_fixture": str(root),
        "same_run_result_sha256": sha(root / "result.json"), "branches": branches,
        "independent_sql_assertions_passed": True, "cancelled_task_not_revived": True,
        "started_native_sequence": order})
assert {item["mode"] for item in result} == {"on", "off", "fault"}
lines = (APP / "tests/queue_start_scenario.mjs").read_text(encoding="utf-8").splitlines()
needles = ["cancelled.status, 'cancelled'", "cancelled.last_error, 'SHARING_REVOKED'", "cancelled.started_at, null",
           "const replacement = await", "replacement.task_id, submitted.task_id", "task(replacement.task_id).status, 'ready'",
           "start.task.status, 'preparing'", "start.native_sequence < revoke.native_sequence", "repeat < 2"]
assertions = [{"path": str(APP / "tests/queue_start_scenario.mjs"), "line": number, "text": line.strip()}
              for number, line in enumerate(lines, 1) if any(needle in line for needle in needles)]
save(out / "index.json", {"valid": True, "build_id": build, "original_native_runs_sha256": sha(source),
    "runs": result, "existing_native_assertion_locations": assertions,
    "evidence_boundary": "These are existing controlled native fixtures. Ordinary browser scheduling is reported separately. No added demonstration recording, fabricated native event or changed test source."})
print({"controlled_permission_audit_valid": True, "modes": len(result), "branches_per_mode": 3,
       "index": str(out / "index.json")}, flush=True)
