"""Bind the original workflow/audits to the reviewed repair29 source, without changing business tests."""
import shutil
from repair_tools import APP, PACK, RUN, load, save, sha

assert load(RUN / "static-preservation.json")["valid"]
source = RUN.parent / "announcement-module-bootstrap-20261122"
for name in ("ordinary_browser_once.py", "seal_browser.py", "post_verify.py", "audit_recordings.py",
             "audit_context.py", "audit_preservation.py", "audit_final_preservation.py", "audit_controlled_permissions.py",
             "fresh_live_ui.py"):
    text = (source / name).read_text(encoding="utf-8")
    text = text.replace("context-closure-skills/vibelens", "admission-repair29-skills/vibelens")
    text = text.replace("66efb5e24ae4b702bfa8f0515c90a3f2c2e637c4", "0ac64bc0074abb4509def9b135a4fdfd1fc81c39")
    if name == "seal_browser.py":
        text = text.replace('"inspect-ready-native.json"', '"final-inspect-ready.json"')
    if name == "audit_final_preservation.py":
        text = text.replace('"current-static-snapshot.json"', '"current-static-snapshot.json"')
    (RUN / name).write_text(text, encoding="utf-8", newline="\n")
provider = {path.relative_to(PACK).as_posix(): sha(path) for path in PACK.rglob("*")
            if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc"}
assert all(provider.get(name) == value for name, value in load(RUN / "provider-files-before.json").items())
save(RUN / "provider-files-runtime-baseline.json", provider)
save(RUN / "runtime-release.json", {"authorized": True, "ordinary_attempts_allowed": 1,
    "authority": "Main session completed/accepted Python and released this machine; after targeted/default-entry/static repair proceed with one same-candidate full Node batch in this chat.",
    "provider_environment_not_preselected": True, "accept_allowed": False})
save(RUN / "runtime-slot-status.json", {"available_to_trial": True, "main_session_released": True,
    "ordinary_attempts_allowed": 1, "provider": str(PACK)})
print({"full_batch_prepared": True, "provider_files": len(provider), "initial_provider_source_files_unchanged": True,
       "original_workflow_path_preserved": True, "entry_provider_environment_unset": True}, flush=True)
