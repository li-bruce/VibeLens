# Repair29 Node provider unification handoff

The one authorized complete runtime batch passed, followed by the planned real fresh-live login/list refresh. The ordinary workflow, original seven browser groups, original six post-verify commands, two full recordings, and independent audits are all retained together. Services remain running for the main session. No canonical accept/check or final P7 completion is claimed here.

## Identity and continuity

- Project: `C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.validation\p7-trials\node-retest-app`
- Existing active change: `.stategraph/announcement-module-bootstrap-20261122`; original begin/baseline retained. Canonical begin-on-existing rejection remains in the evidence.
- Candidate C: `82e5caa3af9b07538a33224b89186de4288f89caa2a135fd5a6d627ec92aa41b`
- Build B: `e44dfd04e1cb902c1d755eb3e9c0707d42700574e40ce920a185a59c9a5aacc7`
- Immutable repair29 provider: `C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.validation\p7-trials\admission-repair29-skills\vibelens`
- Reported provider commit: `0ac64bc0074abb4509def9b135a4fdfd1fc81c39`
- No new business requirement, replacement baseline, source modification after the seal, or accept was introduced.

`candidate-build.json` remains the original pre-runtime receipt with `full_runtime_verified=false`. The completed outcome is recorded by [FINAL_HANDOFF.json](<C:/Users/Lvi_P/Documents/Work/CF/平台软著/SoftwareStatusObserverSkill/.validation/p7-trials/node-retest-app/review/runtime/repair29-provider-unification-20261122/FINAL_HANDOFF.json>), [ordinary-browser-recording-command.json](<C:/Users/Lvi_P/Documents/Work/CF/平台软著/SoftwareStatusObserverSkill/.validation/p7-trials/node-retest-app/review/runtime/repair29-provider-unification-20261122/ordinary-browser-recording-command.json>), [verify-after-browser.json](<C:/Users/Lvi_P/Documents/Work/CF/平台软著/SoftwareStatusObserverSkill/.validation/p7-trials/node-retest-app/review/runtime/repair29-provider-unification-20261122/verify-after-browser.json>), and [runtime-audits-summary.json](<C:/Users/Lvi_P/Documents/Work/CF/平台软著/SoftwareStatusObserverSkill/.validation/p7-trials/node-retest-app/review/runtime/repair29-provider-unification-20261122/runtime-audits-summary.json>); the earlier receipt was not rewritten.

## Retained ordinary services

- App: [http://127.0.0.1:8925/](http://127.0.0.1:8925/)
- Graph: [http://127.0.0.1:8926/graph](http://127.0.0.1:8926/graph)
- Actual ordinary command: `cmd.exe /d /c npm run dev`
- Root command PID: `25340`; Node dev launcher PID: `57096`; viewer Python launcher PID: `56440`.
- Both provider environment variables were absent at entry. The project config selected repair29.
- Existing data root: `C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.validation\p7-trials\node-retest-app\var`
- Existing database: `C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.validation\p7-trials\node-retest-app\var\db\application.sqlite`

| Port | Actual listener PID | Parent PID | Ordinary launcher descendant |
| --- | --- | --- | --- |
| 8925 | 4372 | 57096 | True |
| 8926 | 29736 | 56440 | True |

[listener-identity.json](<C:/Users/Lvi_P/Documents/Work/CF/平台软著/SoftwareStatusObserverSkill/.validation/p7-trials/node-retest-app/review/runtime/repair29-provider-unification-20261122/live/listener-identity.json>) records the actual process tree and provider command; [ordinary-npm-dev-receipt.json](<C:/Users/Lvi_P/Documents/Work/CF/平台软著/SoftwareStatusObserverSkill/.validation/p7-trials/node-retest-app/review/runtime/repair29-provider-unification-20261122/live/ordinary-npm-dev-receipt.json>) records the selected files and hashes. Do not substitute the earlier targeted-dev PIDs. Services are deliberately retained; main-session review takes over these existing processes.

## Implemented checklist mapping

| Readonly checklist | Implemented result | Evidence |
| --- | --- | --- |
| D1 | README now states submission authorization plus preparation-start recheck. Revocation before real start cancels without an artifact; re-share requires a new request after cancellation. Already-started/ready tasks retain collection by the original authorized requester. | README; controlled permission evidence |
| P1 | One project-relative `integrations/provider.json` default; Node and Python process-cached selectors. `VIBELENS_SKILL` overrides; conflicting `BO_DIAGNOSTIC_SKILL` explicitly errors. | shared resolver sources; ten targeted cases |
| P2 | Runtime, generation, checks, optional wrappers and diagnostics resolve through that choice. The fixed historical report analyzer remains historical. | changed source seal; provider entry checks |
| B1 | Ordinary `npm run build:observer` resolves `vibelens:otel` through the selected provider and retains actual esbuild input/hash receipts. | ordinary default build receipt |
| B2 | Actual default `npm run dev`, with both provider variables absent, verifies bundle selection/hash and launches the same provider. Conflicting build/dev attempts exit before mutation/start. | targeted and final default dev receipts; conflict receipts |
| D2 | Stable current-status pointers added; root coordination documents retain their historical bodies and link this batch. Original readonly report remains untouched. | CURRENT_STATUS.md; sealed source |

The readonly checklist itself remains at [PENDING_FIXES.md](<C:/Users/Lvi_P/Documents/Work/CF/平台软著/SoftwareStatusObserverSkill/.validation/p7-trials/node-retest-app/review/provider-doc-readonly-20261122-052651/PENDING_FIXES.md>). Managed SDK work used canonical plan/apply/check and existing standard generation; no copied provider/SDK source was hand edited. Browser output was produced by the selected esbuild route. The source snapshot contains 647 model nodes and the exact original 666 capture definitions. Original business assertions and the original six command arrays remain intact.

## Complete batch outcome

Ordinary raw run: [unified-1795299077](<C:/Users/Lvi_P/Documents/Work/CF/平台软著/SoftwareStatusObserverSkill/.validation/p7-trials/node-retest-app/review/runtime/unified-1795299077>). Original workflow exit code: **0**. Post-verify: **valid**, all six commands exit **0**, same C. The main session independently reported **147/147**.

| Original command | Arguments | Exit |
| --- | --- | --- |
| 1 | `node --test tests/business.test.mjs` | 0 |
| 2 | `node tests/http-boundary.mjs after` | 0 |
| 3 | `{python} -B tooling/project_checks.py` | 0 |
| 4 | `node --test tests/concurrency.test.mjs` | 0 |
| 5 | `node --test tests/queue-start.test.mjs` | 0 |
| 6 | `{python} -B tooling/frontend_session_checks.py` | 0 |

| Original browser group | Result |
| --- | --- |
| `browser_on` | passed |
| `browser_off` | passed |
| `browser_fault` | passed |
| `upload_and_named_share` | passed |
| `revoke_hides_file_but_preserves_repeat_collection` | passed |
| `editor_has_no_file_privilege` | passed |
| `independent_board_publish_edit_read_delete` | passed |

This includes actual frontend file submission/share/revoke/collection and announcement publish/edit/read/delete with persisted SQL. Full GUI outcome is supported by the ordinary workflow and `browser-acceptance.json` together with post-verify; post-verify alone is not used as the GUI receipt.

| Recording | Own events | Closed calls | Status | Completed / target | Pending |
| --- | --- | --- | --- | --- | --- |
| `70c1c77aa82b4f768bb0248539b76125` | 2514 | 563 | stopped | 2555 / 2555 | 0 |
| `49e70b20dc444f2c9ecdbfafb0571169` | 9882 | 1746 | stopped | 12469 / 12469 | 0 |

Both raw recordings have empty gaps, normal stop receipts and `flushed=true`. Exact raw-file hashes, stop-receipt hashes and independent frame/identity/SQL links are in [normal-stop-original-seal.json](<C:/Users/Lvi_P/Documents/Work/CF/平台软著/SoftwareStatusObserverSkill/.validation/p7-trials/node-retest-app/review/runtime/repair29-provider-unification-20261122/normal-stop-original-seal.json>) and [independent-recording-audit.json](<C:/Users/Lvi_P/Documents/Work/CF/平台软著/SoftwareStatusObserverSkill/.validation/p7-trials/node-retest-app/review/runtime/repair29-provider-unification-20261122/independent-recording-audit.json>). Context audit preserved all parent references; the second record retained 2 metadata boundaries beyond its unchanged 2000 recent-value context limit.

Native health at ordinary stop: errors **0**, dropped **0**, pending **0**, open spans **0**, capture-control errors **0**, transport retries **1**. All 122 sampled health observations had zero drops. Maximum sampled pending was **8213**; this metric includes in-flight work. Waiting capacity remains **8192**, browser capacity **4096**, batch **64 / 256 KiB**, envelope **24 KiB**, request deadline **1000 ms / 2 attempts**, case timeout **180 s**. No limit was raised. See [ordinary-flow-health-audit.json](<C:/Users/Lvi_P/Documents/Work/CF/平台软著/SoftwareStatusObserverSkill/.validation/p7-trials/node-retest-app/review/runtime/repair29-provider-unification-20261122/ordinary-flow-health-audit.json>).

## Independent audits and preservation

All required audits passed: recording closure, context, old SQL rows, personal views, native-order prefix, source/provider/raw-record preservation, controlled permission cases and flow health. [runtime-audits-summary.json](<C:/Users/Lvi_P/Documents/Work/CF/平台软著/SoftwareStatusObserverSkill/.validation/p7-trials/node-retest-app/review/runtime/repair29-provider-unification-20261122/runtime-audits-summary.json>) indexes their results.

- 39 preexisting raw records are byte unchanged, including failed/interrupted records. All 73 sealed source files and the managed SDK remain matched to the current source seal.
- Dynamic package comparison checked **2782** noncache installed files, unchanged. The original pre-dependency package seal had 477 files. These counts have distinct scopes.
- The main session independently checked the actual installation manifest's **467 maintained files**, all equal. `audit_final_preservation.py` has an inherited `owned_files_checked=466` constant; its original JSON remains unchanged. The main session will attach the actual manifest correction. The dynamic 2782-file comparison is independent of that constant.
- Personal-view revision **538 → 538**, no value changes, no restoring old revisions or preferences.
- The protected native-order bytes remain an exact prefix. Old accepted data and the earlier archive remain unchanged; no repacking.
- Original users/sessions/files/grants/tasks/announcements were compared by primary key and complete values using query-only SQLite handles. No old rows were missing or changed at the independent ordinary audit.

| Table | Original rows | Rows at ordinary audit | Missing old | Changed old |
| --- | --- | --- | --- | --- |
| users | 3 | 3 | 0 | 0 |
| sessions | 155 | 164 | 0 | 0 |
| files | 41 | 43 | 0 | 0 |
| grants | 15 | 16 | 0 | 0 |
| tasks | 42 | 44 | 0 | 0 |
| announcements | 13 | 14 | 0 | 0 |

The fresh-live login below then creates its own actual session; the ordinary audit snapshot is retained as such. No database restore or additional acceptance run followed.

Controlled permission cases retain original on/off/fault run results, SQL copies, raw event IDs and state frames at [index.json](<C:/Users/Lvi_P/Documents/Work/CF/平台软著/SoftwareStatusObserverSkill/.validation/p7-trials/node-retest-app/review/runtime/repair29-provider-unification-20261122/controlled-permission-evidence/index.json>). They cover cancellation at preparation start with no artifact, re-share plus new request, and a task started before revoke completing with repeat byte collection. They introduce no new business semantics.

## Planned fresh-live outcome

[fresh-live-ui-summary.json](<C:/Users/Lvi_P/Documents/Work/CF/平台软著/SoftwareStatusObserverSkill/.validation/p7-trials/node-retest-app/review/runtime/repair29-provider-unification-20261122/live/fresh-live-ui-summary.json>) records the real Chrome login and list refresh on the retained ordinary services:

- HTTP login and both observed list responses: **200**; actual rendered list: **43 files**.
- Live viewer event count: **4 → 1250**, new ID delta **1246**, native events for this producer/run **1242**.
- Native run: `1709eff1-b872-490a-97a9-ada22fe6b993`; producer: `f50b86f5-fa8c-4386-8a0e-587c336ef6cd`.
- Binding: **current**, same B; recording active: **none**.
- Native errors/drops/pending/open spans/capture-control errors: **0**; page JavaScript exceptions: **0**.
- One console resource message reports HTTP **404**. The helper did not capture that resource URL; no cause is inferred. It did not fail login/list refresh. The original message, screenshot, DOM, HTTP responses and new events are retained for the main desktop review.
- [fresh-live-files.png](<C:/Users/Lvi_P/Documents/Work/CF/平台软著/SoftwareStatusObserverSkill/.validation/p7-trials/node-retest-app/review/runtime/repair29-provider-unification-20261122/live/fresh-live-files.png>) and [new-live-events.json](<C:/Users/Lvi_P/Documents/Work/CF/平台软著/SoftwareStatusObserverSkill/.validation/p7-trials/node-retest-app/review/runtime/repair29-provider-unification-20261122/live/new-live-events.json>) are new actual live evidence. No recording replay or synthetic events were injected.

## Historical failures retained

The original module batch and its failure/targeted-fix evidence remain at [announcement-module-bootstrap-20261122](<C:/Users/Lvi_P/Documents/Work/CF/平台软著/SoftwareStatusObserverSkill/.validation/p7-trials/node-retest-app/review/runtime/announcement-module-bootstrap-20261122>). Its first interrupted second recording had a flush failure/pending982. The repaired prior batch at [announcement-module-bootstrap-repaired-20261122](<C:/Users/Lvi_P/Documents/Work/CF/平台软著/SoftwareStatusObserverSkill/.validation/p7-trials/node-retest-app/review/runtime/announcement-module-bootstrap-repaired-20261122>) remains a separate failure: second recording `1a56737f20d34900bbecd418eb18836b` dropped421, even though later flushing completed. This successful repair29 batch does not rewrite either result.

No further ordinary recording, test suite or source modification followed the final main-session handoff instruction. Remaining ownership is exclusively the main session's **seven independent desktop groups**, **canonical accept/check**, and **final P7 archive** on the retained services.
