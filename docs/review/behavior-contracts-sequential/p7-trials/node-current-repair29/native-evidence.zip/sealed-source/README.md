# Team File Sharing

A Chinese-language Node.js application with real password sessions, uploader-owned
file sharing, durable download preparation and an independent announcement board.
SQLite and all uploaded/prepared bytes remain inside the project. VibeLens observes
the native implementation; the native service owns authorization and state.

Run from this project directory with Node.js 20.19 or newer:

```powershell
npm ci
npm run build:observer
npm run dev
```

The development command starts the application at http://127.0.0.1:8925 and the
external graph at http://127.0.0.1:8926/graph. It prints both URLs and tracks only
its own child processes. Ctrl+C stops those children. All ordinary launch,
generation, check, optional adapter and browser-build entrypoints resolve the
default provider from `integrations/provider.json`, relative to this project.
It currently selects `../admission-repair29-skills/vibelens`. `VIBELENS_SKILL`
overrides that choice consistently. The legacy `BO_DIAGNOSTIC_SKILL` is only an
agreement check: a different value fails explicitly and never selects a fallback.
Restart processes after changing the configuration or environment.

The supplied Python defaults to `../../../.venv/Scripts/python.exe`;
`VIBELENS_PYTHON` can override the development launcher and native policy helper.
`npm run model` uses the Python executable on the caller's PATH, so invoke the
supplied interpreter explicitly for the canonical maintenance workflow.
No installed Skill source needs editing. Install missing dependencies only with
the selected package's locked commands.

`npm run build:observer` resolves the optional tracer from that same provider and
records the esbuild inputs, resolved paths and SHA-256 values under
`review/runtime/provider-entrypoints/`. The two native browser SDK imports stay
external and are served from the project's canonically managed adapters.
`npm run dev` checks the selected provider against that build receipt and records
its own resolved provider, Python, dependencies and child process IDs there.
These are entrypoint receipts, not business or recording acceptance.

| Username | Display name | Role |
| --- | --- | --- |
| alice | 林澈 | Member |
| bob | 陈可 | Member |
| editor | 叶青 | Announcement editor |

All three synthetic test passwords are `DemoPass!2026`. There is no registration or
account-management page. Only an uploader can grant/revoke file access. The editor
can manage their own announcements and has no additional file privilege.

A download submission commits the task, its requester and the submission-time
authorization together before acknowledgment. Revocation blocks new requests
and file visibility. A still-queued task rechecks its current owner/named-recipient
permission at the actual preparation start. A denied start cancels that task
without producing an artifact. Restoring sharing does not revive a cancelled task;
a new authorized request is required. An uncancelled queued task can start if
sharing is active again at its start check. Already started/ready tasks may finish,
and their original authenticated requester may collect the ready artifact repeatedly.

For native operation without the observer, use `npm start` (observation is disabled
by default). `PORT` and `APP_DATA_ROOT` select a loopback port and local storage
directory. Data defaults to `var/db/application.sqlite`, `var/uploads` and
`var/prepared`. Do not remove `var` when retaining application records.

`npm test` exercises real HTTP, SQLite and disk behavior. The independent observation
runner is `tooling/observe.py`, executed with the supplied Python environment and
the selected external Skill. `tooling/project_checks.py` runs canonical adapter,
database, documentation and API checks, isolated omission/wrong-value/stale-source
cases, and the native business suite with observer modules absent.

Canonical meaning and original user evidence remain in `discovery.json`,
`intent.json`, `behavior.json` and `review/`. `initial-node-app/baseline.json` is the
immutable initial coding baseline. Managed native observer files are installed or
migrated only through `bo_integrate.py`; previous receipts are retained under
`bo_stategraph/migrations/`. The pre-HTTP-repair archive, actual failure/retest
records, independent native captures and desktop-browser evidence remain in
`review/runtime/`. Automated checks and browser trials are not human usability
testing or a proof of arbitrary business semantics.

Current coordination and evidence pointers are in `CURRENT_STATUS.md`. Historical
dialogues, confirmations, failed recordings and dated notes retain their original
wording. A passing post-verify alone does not override a failed ordinary GUI or
recording result; final acceptance belongs to the independent main-session review.
