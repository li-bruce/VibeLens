"""Run canonical source/adapter/database checks and isolated sensitivity cases."""
import copy
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import shutil

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'integrations'))
from bo_provider import bo_resolve_provider
SKILL = bo_resolve_provider()
sys.path.insert(0,str(SKILL/"scripts"))
os.environ.setdefault("TEAM_FILES_SQLITE_URL","sqlite:///var/db/application.sqlite")
from bo_observer.sources import scan
from bo_observer.graph.source_documentation import report as documentation
from bo_observer.code_graph.service import CodeGraph
from bo_observer.model_io import read_model
from bo_observer.behavior.native_runtime import assess_runtime
from behavior_model import capture

def read(name):return json.loads((ROOT/name).read_text(encoding="utf-8-sig"))
def write(name,value):(ROOT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
results={}
provider_checks = subprocess.run([sys.executable, "-B", "-X", "utf8", str(ROOT / "tooling/provider_entry_checks.py")],
    cwd=ROOT, capture_output=True, text=True, encoding="utf-8", timeout=60)
provider_result = json.loads(provider_checks.stdout) if provider_checks.stdout.strip() else {"valid": False, "error": provider_checks.stderr[-2000:]}
write("review/runtime/provider-entrypoints/project-checks-latest.json", provider_result)
results["provider_entrypoints"] = {"valid": provider_checks.returncode == 0 and provider_result.get("valid") is True,
                                   "cases": len(provider_result.get("cases", []))}
for identity,script,args in [
 ("framework","bo_integrate.py",["check"]),
 ("database","bo_db.py",["check"]),
 ("documentation","bo_code.py",["docs","--strict"]),
 ("api","bo_code.py",["api-check","--strict"])
]:
    run=subprocess.run([sys.executable,"-B",str(SKILL/"scripts"/script),*args,"--root",str(ROOT)],capture_output=True,text=True,encoding="utf-8",env={**os.environ,"PYTHONIOENCODING":"utf-8","PYTHONDONTWRITEBYTECODE":"1"})
    value=json.loads(run.stdout);write("review/check-"+identity+".json",value)
    results[identity]={"valid":run.returncode==0 and value.get("valid",True),"errors":value.get("errors",[]),"missing_count":len(value.get("missing",[]))}

# A real source edit in a separate fixture must invalidate the saved source
# index. The missing documentation is a deliberate test input, not an omission
# hidden in application coverage. No app source or raw recording is mutated.
fixture=Path(tempfile.mkdtemp(prefix="source-sensitivity-",dir=ROOT/"review/runtime"))
sample=fixture/"sample.py";sample.write_text("def square(value):\n    return value * value\n",encoding="utf-8")
model={"schema_version":3,"revision":"fixture","intent":"intent.json","source_files":["sample.py"],"nodes":[{"id":"square","kind":"function","label":"Square a number","summary":"An isolated source-check fixture.","source":{"path":"sample.py","symbol":"square"},"capture":{"in":{"value":"number"},"out":{}}}],"edges":[],"overview":[{"node":"square","x":0,"y":0}],"scope":{"exclude":[]}}
(fixture/"model.json").write_text(json.dumps(model),encoding="utf-8")
(fixture/"intent.json").write_text(json.dumps({"intent_id":"source-fixture","goal":"Check source freshness","requirements":[]}),encoding="utf-8")
(fixture/"sync.json").write_text(json.dumps({"model":"model.json","code_files":["sample.py"],"source_scope":{"roots":["."],"prune":[]}}),encoding="utf-8")
missing=documentation(scan(fixture,["sample.py"]),model)
assert not missing["valid"] and any(item["reason"]=="source_summary_missing" for item in missing["missing"])
CodeGraph(fixture).refresh()
sample.write_text('def square(value):\n    """Square the supplied numeric value.\n\n    Args:\n        value: Numeric value supplied to this fixture.\n    """\n    return value * value\n',encoding="utf-8")
stale=CodeGraph(fixture,persist=False).check()
assert not stale["valid"] and any("differs from current source" in str(error) for error in stale["errors"])
assert documentation(scan(fixture,["sample.py"]),model)["valid"]
results["source_sensitivity"]={"valid":True,"missing_documentation_detected":True,"edited_source_invalidates_saved_index":True,"stale_errors":stale["errors"]}

payload=read("review/runtime/observations.json");contract=read("behavior.json");discovery=read("discovery.json")
model=read_model(ROOT/"bo_stategraph/project.json",project_root=ROOT)
assert payload["build_id"]==capture(ROOT,model)["build_id"],"Native evidence belongs to a different source build"
cfg=read("sync.json");acceptance=read("acceptance.json")
kwargs={"index":scan(ROOT,cfg["code_files"]),"case_ids":{check["case"] for check in acceptance["checks"]}}
base=assess_runtime(contract,discovery,model,payload,**kwargs)
assert base["valid"],base["errors"]
wrong=copy.deepcopy(payload)
run=next(r for r in wrong["runs"] if r["case"]=="state_lifecycles" and r["mode"]=="on")
event=next(e for e in run["events"] if e["node"]=="state_value:download_task" and e["phase"]=="change")
event["outputs"]["state"]="created"
bad=assess_runtime(contract,discovery,model,wrong,**kwargs)
assert not bad["valid"] and any(e["code"]=="native_value_differs" for e in bad["errors"])
omitted=copy.deepcopy(payload)
run=next(r for r in omitted["runs"] if r["case"]=="state_lifecycles" and r["mode"]=="on")
target=next(e for e in run["events"] if e["node"]=="state_value:download_task" and e["outputs"].get("event_name")=="finish")
run["events"]=[e for e in run["events"] if e["id"]!=target["id"]]
gap=assess_runtime(contract,discovery,model,omitted,**kwargs)
assert not gap["valid"] and any(e["code"] in {"native_value_not_captured","action_boundary_missing_or_duplicate"} for e in gap["errors"])
results["runtime_sensitivity"]={"valid":True,"base_actual_capture_valid":True,"wrong_value_errors":bad["errors"],"removed_witness_errors":gap["errors"],"scope":"Only in-memory copies of retained real captures were changed; original events and native database files remain untouched."}

# The native business service never imports or evaluates the observer's state
# or policy declarations. Managed dependency integrity is checked independently.
native=(ROOT/"src/service.mjs").read_text(encoding="utf-8")+(ROOT/"src/policy.mjs").read_text(encoding="utf-8")
assert "bo_stategraph" not in native and "bo_observer" not in native
results["ownership"]={"valid":True,"native_service_has_no_observer_declaration_dependency":True}
standalone=Path(tempfile.mkdtemp(prefix="native-without-observer-",dir=ROOT/"review/runtime"))
for directory in ["src","public"]:shutil.copytree(ROOT/directory,standalone/directory)
(standalone/"integrations").mkdir();shutil.copy2(ROOT/"integrations/bo_web_routes.mjs",standalone/"integrations/bo_web_routes.mjs")
(standalone/"tests").mkdir();shutil.copy2(ROOT/"tests/business.test.mjs",standalone/"tests/business.test.mjs")
(standalone/"review/runtime").mkdir(parents=True)
native_run=subprocess.run(["node","--test","tests/business.test.mjs"],cwd=standalone,capture_output=True,text=True,encoding="utf-8",env={**os.environ,"VIBELENS_ENABLED":"0"},creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
write("review/native-without-observer.json",{"exit_code":native_run.returncode,"stdout":native_run.stdout,"stderr":native_run.stderr,"fixture":str(standalone),"omitted":["Managed native observer modules","Observer implementation","External Skill/viewer resources"]})
assert native_run.returncode==0,native_run.stderr or native_run.stdout
results["native_without_observer"]={"valid":True,"business_suite_passed":True,"copied_native_sources_unchanged":True,"observer_modules_present":False}
output={"valid":all(r["valid"] for r in results.values()),"checks":results}
write("review/project-checks.json",output)
print(json.dumps({"valid":output["valid"],"checks":{k:v["valid"] for k,v in results.items()}}))
raise SystemExit(0 if output["valid"] else 1)
