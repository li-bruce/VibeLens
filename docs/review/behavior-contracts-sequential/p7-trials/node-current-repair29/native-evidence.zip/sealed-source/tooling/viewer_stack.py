"""Sample all Python thread stacks while executing the unchanged installed entrypoint."""
import faulthandler
import json
import os
from pathlib import Path
import runpy
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'integrations'))
from bo_provider import bo_resolve_provider
SKILL = bo_resolve_provider()
ENTRY=SKILL/'scripts/bo.py'
DESTINATION=Path(os.environ['BO_VIEWER_STACK'])
sys.path.insert(0,str(ENTRY.parent))
sys.argv=[str(ENTRY),'serve','--root',str(ROOT),'--port','8926','--origin','http://127.0.0.1:8925']
with DESTINATION.open('w',encoding='utf-8',buffering=1) as stream:
    stream.write(json.dumps({'sampling':'faulthandler.dump_traceback_later','interval_seconds':1,'repeat':True,'pid':os.getpid(),'wall_ms':time.time_ns()/1e6,'monotonic_ms':time.monotonic_ns()/1e6,'entrypoint':str(ENTRY),'argv':sys.argv})+'\n')
    stream.flush()
    faulthandler.dump_traceback_later(1,repeat=True,file=stream)
    try:
        runpy.run_path(str(ENTRY),run_name='__main__')
    finally:
        faulthandler.cancel_dump_traceback_later()
