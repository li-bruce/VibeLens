"""Own app, viewer, trial servers and independent browser in one process tree."""
import json
import ctypes
from ctypes import wintypes
import hashlib
import os
from pathlib import Path
import runpy
import socket
import subprocess
import shutil
import sys
import threading
import time
import urllib.request

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'review/runtime'
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'integrations'))
from bo_provider import bo_resolve_provider
SKILL = bo_resolve_provider()
identity=str(int(time.time()))
RUN=OUT/('unified-'+identity);RUN.mkdir()
started_ns=time.time_ns()
children=[];handles=[]
recording='--recording' in sys.argv
first_recording_only='--first-recording-only' in sys.argv
if first_recording_only and not recording:raise ValueError('First-recording scope requires the original recording flow')
log={'run_id':identity,'parent_pid':os.getpid(),'source':'single-parent-process','started_ms':started_ns/1e6,'mode':'transport-repro' if '--transport-repro' in sys.argv else 'recording' if recording else 'native-ui','profiled_viewer':'--profile-viewer' in sys.argv,'children':[]}
log['skill_provider']=str(SKILL)
log['diagnostic_only']=True
log['recording_scope']='first-recording-only' if first_recording_only else 'full'
log['stack_sampled_viewer']='--stack-viewer' in sys.argv
log['timed_viewer']='--timing-viewer' in sys.argv
if sum([log['stack_sampled_viewer'],log['profiled_viewer'],log['timed_viewer']])>1:raise ValueError('Choose exactly one diagnostic method')
if log['timed_viewer'] and '--audit-network' not in sys.argv:raise ValueError('Selected-method timing requires the existing network audit')
log['load_context']=os.environ.get('BO_LOAD_CONTEXT','No concurrent-regression status was supplied; resource isolation is not established.')
log['load_context_source']='process environment supplied by task coordination' if 'BO_LOAD_CONTEXT' in os.environ else 'not_recorded'
log['low_load_option_requested']='--low-load' in sys.argv
archive=RUN/'diagnostic-source';archive.mkdir()
log['diagnostic_sources']={}
for name in ['unified_browser_run.py','transport_repro.py','viewer_profile.py','viewer_stack.py','viewer_timing.py','audit_fetch.mjs','browser_acceptance.py','browser_evidence.mjs','browser_trials.mjs']:
    path=ROOT/'tooling'/name;shutil.copy2(path,archive/name);log['diagnostic_sources'][name]=hashlib.sha256(path.read_bytes()).hexdigest()
for name in ['native_reader.mjs','observe.mjs']:
    path=ROOT/'tests'/name;shutil.copy2(path,archive/name);log['diagnostic_sources']['tests/'+name]=hashlib.sha256(path.read_bytes()).hexdigest()
log['managed_sdk']={}
for name in ['bo_runtime.mjs','bo_capture.mjs','bo_http.mjs']:
    local=ROOT/'bo_stategraph'/name;installed=SKILL/'scripts/bo_observer/adapters/javascript'/name
    log['managed_sdk'][name]={'project_sha256':hashlib.sha256(local.read_bytes()).hexdigest(),'provider_sha256':hashlib.sha256(installed.read_bytes()).hexdigest(),'identical':local.read_bytes()==installed.read_bytes()}
batch_schema=SKILL/'scripts/bo_observer/schemas/event-batch.schema.json'
log['event_batch_schema']={'exists':batch_schema.exists(),'sha256':hashlib.sha256(batch_schema.read_bytes()).hexdigest() if batch_schema.exists() else None}
load_stop=threading.Event()
stack_stop=threading.Event()
stack_thread=None

def observe_stack_writes():
    """Timestamp watchdog output from this separate parent, outside the viewer GIL."""
    source=RUN/'viewer-stacks.log';offset=0;tail=b'';ordinal=0;marker=b'Timeout ('
    with (RUN/'viewer-stack-times.jsonl').open('w',encoding='utf-8',buffering=1) as stream:
        while not stack_stop.is_set():
            if source.exists():
                with source.open('rb') as reader:reader.seek(offset);chunk=reader.read()
                if chunk:
                    data=tail+chunk;position=0;stamp=source.stat().st_mtime_ns
                    while True:
                        found=data.find(marker,position)
                        if found<0:break
                        ordinal+=1
                        stream.write(json.dumps({'dump_ordinal':ordinal,'observed_wall_ms':time.time_ns()/1e6,'file_mtime_ms':stamp/1e6,'marker_byte_offset':offset-len(tail)+found,'observed_file_bytes':offset+len(chunk)})+'\n')
                        position=found+len(marker)
                    offset+=len(chunk);tail=data[-(len(marker)-1):]
            stack_stop.wait(.1)
def system_times():
    idle=wintypes.FILETIME();kernel=wintypes.FILETIME();user=wintypes.FILETIME()
    if not ctypes.windll.kernel32.GetSystemTimes(ctypes.byref(idle),ctypes.byref(kernel),ctypes.byref(user)):raise OSError('GetSystemTimes failed')
    value=lambda stamp:(stamp.dwHighDateTime<<32)|stamp.dwLowDateTime
    return value(idle),value(kernel)+value(user)
def sample_load():
    with (RUN/'system-load.jsonl').open('w',encoding='utf-8',buffering=1) as stream:
        while not load_stop.is_set():
            first=system_times();started=time.monotonic();time.sleep(.25);second=system_times();total=second[1]-first[1]
            stream.write(json.dumps({'wall_ms':time.time_ns()/1e6,'window_ms':(time.monotonic()-started)*1000,'system_cpu_percent':100*(1-(second[0]-first[0])/total) if total else None})+'\n')
            load_stop.wait(1.75)
env={**os.environ,'VIBELENS_SKILL':str(SKILL),'PYTHONDONTWRITEBYTECODE':'1','PYTHONIOENCODING':'utf-8','APP_DATA_ROOT':str(ROOT/'var'),'VIBELENS_ENABLED':'1','PORT':'8925','TEAM_FILES_SQLITE_URL':'sqlite:///var/db/application.sqlite','BROWSER_TRIAL_ID':identity}
env['BO_REGRESSION_LOAD']=os.environ.get('BO_REGRESSION_LOAD','not_recorded')
if '--transport-repro' in sys.argv or '--audit-network' in sys.argv:
    env['BO_TRANSPORT_AUDIT']=str(RUN/'native-fetch.jsonl')
if '--transport-repro' in sys.argv:
    env['BO_VIEWER_AUDIT']=str(RUN/'viewer-calls.jsonl')
if '--stack-viewer' in sys.argv:
    env['BO_VIEWER_STACK']=str(RUN/'viewer-stacks.log')
if '--timing-viewer' in sys.argv:
    env['BO_VIEWER_TIMING']=str(RUN/'viewer-method-timing.jsonl')
    env['BO_HTTP_TIMING_LINKS']='1'

def save():
    (RUN/'lifecycle.json').write_text(json.dumps(log,ensure_ascii=False,indent=2),encoding='utf-8')
    (OUT/'latest-unified-run.json').write_text(json.dumps({'path':str(RUN),'run_id':identity}),encoding='utf-8')

def start(command,label):
    stdout=(RUN/(label+'.stdout.log')).open('w',encoding='utf-8');stderr=(RUN/(label+'.stderr.log')).open('w',encoding='utf-8');handles.extend([stdout,stderr])
    process=subprocess.Popen(command,cwd=ROOT,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    children.append(process);log['children'].append({'label':label,'pid':process.pid,'started_ms':time.time_ns()/1e6,'command':command});save();return process

def ready(url,process):
    deadline=time.monotonic()+40
    while time.monotonic()<deadline:
        if process.poll() is not None:raise RuntimeError('Owned service exited before ready: '+url)
        try:
            with urllib.request.urlopen(url,timeout=1) as response:
                if response.status==200:return
        except OSError:pass
        time.sleep(.1)
    raise TimeoutError('Owned service readiness failed: '+url)

for port in [8925,8926,8935,8936]:
    with socket.socket() as client:
        if client.connect_ex(('127.0.0.1',port))==0:raise RuntimeError('Refuse to replace an existing listener: '+str(port))
try:
    if '--stack-viewer' in sys.argv:
        stack_thread=threading.Thread(target=observe_stack_writes,daemon=True);stack_thread.start()
    viewer_command=[sys.executable,'-B',str(ROOT/'tooling/viewer_timing.py')] if '--timing-viewer' in sys.argv else [sys.executable,'-B',str(ROOT/'tooling/viewer_stack.py')] if '--stack-viewer' in sys.argv else [sys.executable,'-B',str(ROOT/'tooling/viewer_profile.py')] if '--profile-viewer' in sys.argv else [sys.executable,'-B',str(SKILL/'scripts/bo.py'),'serve','--root',str(ROOT),'--port','8926','--origin','http://127.0.0.1:8925']
    viewer=start(viewer_command,'viewer')
    ready('http://127.0.0.1:8926/graph',viewer)
    node=['node']
    if '--transport-repro' in sys.argv or '--audit-network' in sys.argv:node+=['--import',(ROOT/'tooling/audit_fetch.mjs').as_uri()]
    app=start([*node,'src/server.mjs'],'app');ready('http://127.0.0.1:8925/api/bo/health',app)
    previous=(OUT/'browser-trials.json').stat().st_mtime_ns if (OUT/'browser-trials.json').exists() else 0
    trials=start(['node','tooling/browser_trials.mjs'],'trials')
    deadline=time.monotonic()+30
    while not (OUT/'browser-trials.json').exists() or (OUT/'browser-trials.json').stat().st_mtime_ns==previous:
        if trials.poll() is not None or time.monotonic()>deadline:raise RuntimeError('Owned trial fixtures failed')
        time.sleep(.1)
    metadata=json.loads((OUT/'browser-trials.json').read_text(encoding='utf-8'))
    assert metadata['launcher_pid']==trials.pid
    assert {trial['skill_provider'] for trial in metadata['modes'].values()}=={str(SKILL)},'Browser modes selected different providers'
    log['browser_mode_providers']={mode:trial['skill_provider'] for mode,trial in metadata['modes'].items()}
    log['served_sdk']={}
    for resource,name in [('native-runtime.mjs','bo_runtime.mjs'),('native-capture.mjs','bo_capture.mjs')]:
        with urllib.request.urlopen('http://127.0.0.1:8925/api/bo/'+resource,timeout=2) as response:
            received=hashlib.sha256(response.read()).hexdigest()
        assert received==log['managed_sdk'][name]['provider_sha256'],'App served SDK bytes differ from selected provider'
        log['served_sdk'][name]=received
    log.update(build_id=metadata['build_id'],all_ready_ms=time.time_ns()/1e6)
    try:
        import psutil
        log['system_cpu_percent_at_start']=psutil.cpu_percent(interval=.15)
    except ImportError:log['system_cpu_percent_at_start']=None
    save();threading.Thread(target=sample_load,daemon=True).start();print(json.dumps({'run':str(RUN),'ready':True,'build_id':metadata['build_id']}),flush=True)
    os.environ.update(env);os.environ['BO_UNIFIED_RUN']=str(RUN)
    sys.argv=['transport_repro.py'] if '--transport-repro' in sys.argv else ['browser_acceptance.py'] if recording else ['browser_acceptance.py','--native-only']
    if first_recording_only:sys.argv.append('--first-recording-only')
    runpy.run_path(str(ROOT/'tooling'/sys.argv[0]),run_name='__main__')
    log['completed']=True
except BaseException as error:
    log['completed']=False;log['error']=str(error);raise
finally:
    load_stop.set()
    if any(item['label']=='app' and process.poll() is None for item,process in zip(log['children'],children)):
        try:
            with urllib.request.urlopen('http://127.0.0.1:8925/api/bo/health',timeout=2) as response:log['pre_cleanup_native_health']=json.load(response)
        except Exception as error:log['pre_cleanup_health_read_error']={'type':type(error).__name__,'message':str(error)}
    for item,process in zip(log['children'],children):
        item['pre_cleanup_exit_code']=process.poll()
        item['termination']='owned_parent_cleanup' if process.poll() is None else 'exited_before_cleanup'
    for process in reversed(children):
        if process.poll() is None:
            subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        try:process.wait(timeout=5)
        except subprocess.TimeoutExpired:pass
    for item,process in zip(log['children'],children):item['exit_code']=process.poll()
    stack_stop.set()
    if stack_thread:stack_thread.join(timeout=2)
    log['cleaned_up_ms']=time.time_ns()/1e6;save()
    for stream in handles:stream.close()
    artifacts=RUN/'artifacts';artifacts.mkdir()
    log['artifacts']={}
    patterns=['browser*.json','browser*.jpg','failed-recording-*.json','independent-recording-*.json','stop-receipt-*','native-idle-summary.json','gui-*.jpg','graph-failure.jpg','repeat-collection-*.txt','GUI_acceptance_*.txt']
    for path in sorted({path for pattern in patterns for path in OUT.glob(pattern) if path.is_file() and path.stat().st_mtime_ns>=started_ns}):
        shutil.copy2(path,artifacts/path.name);log['artifacts'][path.name]=hashlib.sha256(path.read_bytes()).hexdigest()
    save()
