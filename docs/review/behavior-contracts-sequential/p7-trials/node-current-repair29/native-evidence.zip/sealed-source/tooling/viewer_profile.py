"""Trace selected canonical calls/lock boundaries without replacing their code."""
import ast
import json
import os
from pathlib import Path
import queue
import runpy
import sys
import threading
import time
from urllib.parse import urlsplit

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'integrations'))
from bo_provider import bo_resolve_provider
SKILL = bo_resolve_provider()
DEST=Path(os.environ['BO_VIEWER_AUDIT'])
SESSION=SKILL/'scripts/bo_observer/observation/session.py'
locks={}
for owner in ast.parse(SESSION.read_text(encoding='utf-8')).body:
    if not isinstance(owner,ast.ClassDef):continue
    for method in owner.body:
        if not isinstance(method,ast.FunctionDef) or method.name not in {'view','event','snapshot'}:continue
        for node in ast.walk(method):
            if isinstance(node,ast.With) and any(ast.unparse(item.context_expr)=='self.lock' for item in node.items):
                locks[(method.name,node.lineno)]='lock_request'
                locks[(method.name,node.body[0].lineno)]='lock_acquired'
                if node in method.body and method.body.index(node)+1<len(method.body):
                    locks[(method.name,method.body[method.body.index(node)+1].lineno)]='lock_released'
events=queue.SimpleQueue()
def writer():
    with DEST.open('a',encoding='utf-8',buffering=1) as stream:
        while True:stream.write(json.dumps(events.get(),ensure_ascii=False)+'\n')
threading.Thread(target=writer,daemon=True).start()
def emit(frame,event,line=None):
    code=frame.f_code
    request_path=None;observation_id=None;parent=frame
    for _ in range(40):
        if parent is None:break
        if observation_id is None:
            for name in ['event','value','packet','body']:
                payload=parent.f_locals.get(name)
                if isinstance(payload,dict) and payload.get('protocol') in {'bo-event/v1','bo-snapshot/v1','bo-snapshot/v2'}:
                    observation_id=payload.get('id') or payload.get('evidence_id');break
        if parent.f_code.co_name in {'do_GET','do_POST'}:
            handler=parent.f_locals.get('self');request_path=urlsplit(getattr(handler,'path','')).path
            break
        parent=parent.f_back
    events.put({'wall_ms':time.time_ns()/1e6,'pid':os.getpid(),'thread':threading.get_ident(),'frame':id(frame),'event':event,'function':code.co_qualname,'source_file':code.co_filename,'line':frame.f_lineno if line is None else line,'request_path':request_path,'observation_id':observation_id})

sys.path.insert(0,str(SKILL/'scripts'))
from bo_observer.observation.session import GraphSession
from bo_observer.observation.behavior_context import BehaviorContext
from bo_observer.code_graph.service import CodeGraph
from bo_observer.web import semantic_names
from bo_observer import sources

monitor=sys.monitoring;tool=3
monitor.use_tool_id(tool,'project-local-observation-audit')
def started(code,offset):emit(sys._getframe(1),'call')
def returned(code,offset,value):emit(sys._getframe(1),'return')
def line_event(code,line):
    kind=locks.get((code.co_name,line))
    if kind:emit(sys._getframe(1),kind,line)
monitor.register_callback(tool,monitor.events.PY_START,started)
monitor.register_callback(tool,monitor.events.PY_RETURN,returned)
monitor.register_callback(tool,monitor.events.LINE,line_event)
targets=[GraphSession.view,GraphSession.event,GraphSession.snapshot,GraphSession.binding,CodeGraph.view,CodeGraph.refresh,BehaviorContext.view,BehaviorContext.last_verification,semantic_names.overlay_model,semantic_names.read_names,semantic_names.validate,sources.scan]
for target in targets:
    selected=monitor.events.PY_START|monitor.events.PY_RETURN
    if target in [GraphSession.view,GraphSession.event,GraphSession.snapshot]:selected|=monitor.events.LINE
    monitor.set_local_events(tool,target.__code__,selected)
events.put({'wall_ms':time.time_ns()/1e6,'event':'profile_configuration','method':'Python 3.13 local sys.monitoring events','targets':[target.__qualname__ for target in targets],'note':'Only selected canonical code objects are monitored. Functions and return values are unmodified; monitoring overhead still precludes an isolated benchmark claim.'})
sys.argv=[str(SKILL/'scripts/bo.py'),'serve','--root',str(ROOT),'--port','8926','--origin','http://127.0.0.1:8925']
runpy.run_path(sys.argv[0],run_name='__main__')
