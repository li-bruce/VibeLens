"""Check provider defaults/overrides/conflicts and current real bundle provenance, without business work."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "integrations"))
from bo_provider import bo_resolve_provider

def run_resolver(root, language, values, cwd):
    """Run an exact copied or actual resolver in a clean child; never import a provider."""
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1", PYTHONIOENCODING="utf-8")
    for key in ("VIBELENS_SKILL", "BO_DIAGNOSTIC_SKILL"):
        env.pop(key, None)
    env.update(values)
    if language == "javascript":
        code = "console.log(JSON.stringify(require(" + json.dumps(str(root / "integrations/bo_provider.cjs")) + ").bo_provider_selection()))"
        command = ["node", "-e", code]
    else:
        code = "import sys,json;sys.path.insert(0," + repr(str(root / "integrations")) + ");from bo_provider import bo_resolve_provider;print(json.dumps({'provider':str(bo_resolve_provider())}))"
        command = [sys.executable, "-B", "-X", "utf8", "-c", code]
    result = subprocess.run(command, cwd=cwd, env=env, capture_output=True, text=True, encoding="utf-8", timeout=20)
    return {"exit_code": result.returncode, "stdout": result.stdout, "stderr": result.stderr}

def main():
    """Retain default selection tests independently of the caller's environment override."""
    current = bo_resolve_provider()
    default = (ROOT / json.loads((ROOT / "integrations/provider.json").read_text(encoding="utf-8"))["skill"]).resolve()
    cases = []
    with tempfile.TemporaryDirectory(prefix="provider-check-", dir=ROOT / "review/runtime") as name:
        fixture = Path(name)
        assert fixture.resolve().is_relative_to((ROOT / "review/runtime").resolve())
        (fixture / "integrations").mkdir()
        for filename in ("bo_provider.py", "bo_provider.cjs"):
            shutil.copy2(ROOT / "integrations" / filename, fixture / "integrations" / filename)
        (fixture / "integrations/provider.json").write_text('{"skill":"missing-default"}', encoding="utf-8")
        other = fixture / "different-provider"
        (other / "scripts").mkdir(parents=True)
        (other / "scripts/bo.py").write_text("# Path-only conflict fixture; never executed.\n", encoding="utf-8")
        specifications = [
            ("default-without-provider-environment", ROOT, {}, default, False),
            ("override-invalid-fixture-default", fixture, {"VIBELENS_SKILL": str(current)}, current, False),
            ("matching-legacy-alias", ROOT, {"VIBELENS_SKILL": str(current), "BO_DIAGNOSTIC_SKILL": str(current)}, current, False),
            ("conflicting-alias", ROOT, {"VIBELENS_SKILL": str(current), "BO_DIAGNOSTIC_SKILL": str(other)}, current, True),
            ("legacy-only-cannot-replace-default", ROOT, {"BO_DIAGNOSTIC_SKILL": str(other)}, default, True),
        ]
        for identity, root, values, expected, rejected in specifications:
            for language in ("javascript", "python"):
                result = run_resolver(root, language, values, fixture)
                if rejected:
                    passed = result["exit_code"] != 0 and "BO_PROVIDER_CONFLICT" in result["stderr"]
                else:
                    passed = result["exit_code"] == 0 and Path(json.loads(result["stdout"])["provider"]).resolve() == expected
                cases.append({"case": identity, "language": language, "passed": passed, **result})
    pointer = json.loads((ROOT / "review/runtime/provider-entrypoints/build-latest.json").read_text(encoding="utf-8"))
    build = json.loads(Path(pointer["path"]).read_text(encoding="utf-8"))
    digest = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    assert Path(build["provider"]).resolve() == current
    assert digest(ROOT / build["output"]["path"]) == build["output"]["sha256"]
    assert all(digest(Path(filename)) == value for filename, value in build["inputs"].items())
    assert all(digest(ROOT / filename) == value for filename, value in build["entrypoint_hashes"].items())
    provider_inputs = [Path(name).resolve() for name in build["inputs"] if "-skills" in name]
    assert provider_inputs and all(path.is_relative_to(current) for path in provider_inputs)
    assert "vibelens:otel" in (ROOT / "integrations/bo_client.mjs").read_text(encoding="utf-8")
    historical = {"tooling/analyze_batch_run.py", "tooling/provider_entry_checks.py"}
    stale = []
    for folder in ("src", "integrations", "tests", "tooling"):
        for path in (ROOT / folder).glob("*"):
            if path.suffix not in (".py", ".mjs", ".cjs") or path.relative_to(ROOT).as_posix() in historical:
                continue
            if "node-migration-final-skills/vibelens" in path.read_text(encoding="utf-8-sig") or "ordered-evidence-skills/vibelens" in path.read_text(encoding="utf-8-sig"):
                stale.append(path.relative_to(ROOT).as_posix())
    assert stale == [], stale
    result = {"valid": all(case["passed"] for case in cases), "cases": cases,
        "actual_bundle_receipt": pointer["path"], "provider_inputs_checked": len(provider_inputs),
        "default_provider": str(default), "selected_provider": str(current),
        "business_server_database_recording_used": False,
        "scope": "Real resolver subprocesses and previously executed ordinary build provenance; minimal path-only conflict fixture is never a provider runtime."}
    print(json.dumps(result, ensure_ascii=False))
    return 0 if result["valid"] else 1

if __name__ == "__main__":
    raise SystemExit(main())
