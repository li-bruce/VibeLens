"""Write the coding review for the inspected candidate without changing its baseline."""
import json
import os
from pathlib import Path
import sys
root=Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'integrations'))
from bo_provider import bo_resolve_provider
skill = bo_resolve_provider()
sys.path.insert(0,str(skill/"scripts"))
from bo_observer.workflow.sync_config import config,snapshot
from bo_observer.workflow.change_sync import inspect
def read(name):return json.loads((root/name).read_text(encoding="utf-8-sig"))
active=read(".stategraph/active.json")["change"]
change=root/active
base,current,inspection=inspect(root,config(root,"sync.json"),change)
old=base["structure"]["symbols"];new=current["structure"]["symbols"]
moves=[]
for identity,record in old.items():
    if identity in new:continue
    matching=[v for k,v in new.items() if k not in old and v["path"]==record["path"] and v.get("ast_hash")==record.get("ast_hash") and v.get("signature")==record.get("signature")]
    if len(matching)==1:
        target=matching[0]
        moves.append({"from":{"path":record["path"],"symbol":record["symbol"]},"to":{"path":target["path"],"symbol":target["symbol"]},"reason":"Exact AST/signature match: adding adjacent source JSDoc changed a chained callback textual namespace; its function behavior and protected capture remain represented."})
plan=current["model"]["implementation"]
excluded={}
for identity in inspection["required_classification"]:
    if identity in plan.get("excluded",{}):continue
    if identity in plan.get("support",{}):excluded[identity]=plan["support"][identity]["reason"]
    else:excluded[identity]="Static declaration or module startup outside the selected runtime slice; independently inventoried source and its owning feature remain represented. No execution is inferred from this source association."
review={"candidate_id":inspection["candidate_id"],"decisions":{
 "business":{"action":"updated","reason":"Initial implementation of the actual U1-U5 confirmed login, file grants, durable task admission, preparation, repeat collection and independent board. U5 explicitly confirms commit-before-ack; original messages and scoped confirmations are preserved."},
 "state_machine":{"action":"updated","reason":"Observe mode retains four independent native identities and all confirmed states/events/guards. FileService and SQLite remain authoritative; independent native reads cover all ten transitions."},
 "abstraction":{"action":"updated","reason":"Explicit bo-mapping/v2 binds native state/model/revision/build/context and SDK context. SQLite 0/1 is projected to declared Boolean values; real originals are independently read. The observer-loaded declaration is labeled separately from native authority."},
 "probes":{"action":"updated","reason":"Isolated project bo_ wiring uses exact installed native adapters, actual SDK spans, native decisions, state reads, SQLite operations and real transaction completion. Native on/off/fault and queue-limited cases preserve native outcomes. The current browser recording gate remains failed; old successful recordings stay bound to their original builds. This review does not accept recording transport or authorize final accept."}},
 "requirement_changes":{
 "R_AUTH":"Implement the actual U4 authentication instruction with synthetic accounts; preserve all earlier assertions and safe credential projections.",
 "R_FILES":"Implement the actual U2 uploader/current-recipient boundary and preserve uploader-only grant management; later changes only document and bind native implementation.",
 "R_DOWNLOAD":"Implement U1-U3 and the actual U5 explicit commit-before-ack expectation; add real persistence/SQLite failure counterexamples and retain revocation/repeat-collection assertions.",
 "R_BOARD":"Implement the actual U2 independent authenticated board and editor-own-author boundary; no file privilege is added."},
 "excluded_symbols":excluded,"source_moves":moves}
(change/"review.json").write_text(json.dumps(review,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"candidate":review["candidate_id"],"classified_static":len(excluded),"exact_source_moves":len(moves)}))
