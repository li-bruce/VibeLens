"""Preserve the actual current-chat answer about durable task acceptance."""
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'integrations'))
from bo_provider import bo_resolve_provider
skill = bo_resolve_provider()
target = root / "discovery.json"
doc = json.loads(target.read_text(encoding="utf-8"))
if not any(s["id"] == "U5_ADMISSION" for s in doc["sources"]):
    doc["sources"].extend([
        {"id":"A_ADMISSION_REVIEW","kind":"assistant","text":"请确认这条验收项是否符合原意：下载任务提交获准后，任务、原申请人和‘提交时已授权’在同一事务中保存；提交成功后才返回任务已受理。","locator":"Current chat: actual asynchronous question accompanying review/admission-expectation-review.md"},
        {"id":"U5_ADMISSION","kind":"user","text":"符合我的意思。只有任务和原申请人、提交时已经获准的结果都保存好了，才告诉我‘任务已受理’。不能页面说受理了，后来却找不到任务。下载规则仍按之前确认的：已受理的任务可以继续完成，撤销共享后新申请的任务要拒绝；原申请人可以重复领取已完成的结果。继续完成这一版，并保留真实运行和检查记录。","locator":"Actual current-chat answer delivered from source chat 01a1439a-dceb-7ba2-bada-546619caf220 through Codex thread coordination; quotation punctuation normalized only in this evidence copy"}
    ])
    doc["expectations"].append({"id":"task-admission-committed","scope":["transition:download_task:enqueue","effect:download_task:persist_authorized_task"],"given":{"requester_allowed":True},"when":{"operation":"request_download","boundary":"transaction commit"},"then":[{"path":["admission","committed"],"equals":True}],"source_refs":["U5_ADMISSION"]})
    target.write_text(json.dumps(doc,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")

def call(action, *args):
    completed = subprocess.run([sys.executable,"-B",str(skill / "scripts/bo_concepts.py"),action,"--root",str(root),*args],capture_output=True,text=True,encoding="utf-8",env={**os.environ,"PYTHONIOENCODING":"utf-8"})
    value = json.loads(completed.stdout)
    if completed.returncode: raise RuntimeError(value)
    return value

if not any(c["id"] == "C_ADMISSION" for c in doc["confirmations"]):
    selected = call("snapshot","--scope","expectation:task-admission-committed")
    call("present","--scope","expectation:task-admission-committed","--explained",*selected["scope"],"--sources","A_ADMISSION_REVIEW","--id","P_ADMISSION","--out","review/admission-presentation.json")
    call("confirm","--stage","during_coding","--scope","expectation:task-admission-committed","--presentation","P_ADMISSION","--sources","U5_ADMISSION","--id","C_ADMISSION","--out","review/admission-confirmation.json")
current=json.loads(target.read_text(encoding="utf-8"))
if not any(s["id"] == "U5_RETAIN" for s in current["sources"]):
    current["sources"].append({"id":"U5_RETAIN","kind":"user","text":"下载规则仍按之前确认的：已受理的任务可以继续完成，撤销共享后新申请的任务要拒绝；原申请人可以重复领取已完成的结果。","locator":"Exact separate download-rule sentence in the same actual U5 answer; review/user-admission-answer.txt; not a second reply"})
    target.write_text(json.dumps(current,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
if not any(c["id"] == "C_ADMISSION_RELATION" for c in current["confirmations"]):
    # The user's same answer explicitly retained the reviewed share/revoke and
    # download rules. Recheck the shared relation closure against both actual
    # presentations, without rewriting their historical confirmations.
    selected=call("snapshot","--scope","file-share-revoke")
    call("present","--scope","file-share-revoke","--explained",*selected["scope"],"--sources","A_REVIEW_1","A_ADMISSION_REVIEW","--id","P_ADMISSION_RELATION","--out","review/admission-relation-presentation.json")
    call("confirm","--stage","during_coding","--scope","file-share-revoke","--presentation","P_ADMISSION_RELATION","--sources","U5_RETAIN","--id","C_ADMISSION_RELATION","--out","review/admission-relation-confirmation.json")
print(json.dumps({"recorded":"C_ADMISSION","source":"Actual current-chat answer U5_ADMISSION"}))
