"""Independently inventory current project source through the canonical language adapters."""
import json
import os
from pathlib import Path
import sys
root=Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'integrations'))
from bo_provider import bo_resolve_provider
skill = bo_resolve_provider()
sys.path.insert(0,str(skill/"scripts"))
from bo_observer.sources import scan
paths=["src/store.mjs","src/policy.mjs","src/service.mjs","src/http.mjs","src/server.mjs","public/app.js"]
result=scan(root,paths)
(root/"review/source-index.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"keys":list(result),"errors":result.get("errors"),"symbols":len(result.get("symbols",{})),"samples":[{k:v.get(k) for k in ("path","symbol","parameters")} for v in list(result.get("symbols",{}).values())[:3]]}))
