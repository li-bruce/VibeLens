# Current coordination — repair29 provider unification

The active change remains `.stategraph/announcement-module-bootstrap-20261122`.
Its original baseline and all prior acceptance/failure evidence are retained.
Business semantics remain the confirmed preparation-start permission check;
the announcement module and login-input repairs are carried forward unchanged.

The project-local default is `integrations/provider.json`, currently pointing to
the immutable `admission-repair29-skills/vibelens` package supplied at commit
`0ac64bc0074abb4509def9b135a4fdfd1fc81c39`. `VIBELENS_SKILL` is the consistent
override; a conflicting diagnostic alias is rejected. No old package supplies
missing dependencies. Native SDK maintenance uses the package's standard commands.

Current batch evidence: `review/runtime/repair29-provider-unification-20261122/`.
Provider entrypoint/build receipts: `review/runtime/provider-entrypoints/`.
Execution results and unresolved items are recorded in that batch's `HANDOFF.md`
and command receipts. Targeted/default-entry checks and current candidate
maintenance precede the one coordinated ordinary acceptance attempt. A full
ordinary result and post-verify are separate requirements. The trial does not
perform accept; the main session owns final independent review.

The preceding repaired batch remains in
`review/runtime/announcement-module-bootstrap-repaired-20261122/HANDOFF.md`.
Its real announcement GUI flow and post-verify passed, but its second recording
remains interrupted after 421 native queue drops. That failure is not promoted
to a pass. All 39 historical raw records remain unchanged.

The new batch sealed the actual database and preferences revision 538 before
editing. That is a point-in-time baseline, not a layout revision to restore later.
All saved positions, annotations and views are retained. The original six command
arrays, business assertions, 666 captured field definitions, native8192/browser4096
queues and original batch/envelope/request/case limits remain required.

Older `task_plan.md`, `findings.md` and `progress.md` entries below their current
pointers are dated historical evidence, including earlier providers and revisions.
