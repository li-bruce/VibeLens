"""Collect the complete static batch before correcting any discovered source issue."""
from repair_tools import RUN, cli, load, save

commands = [
    ("source-scan", "bo_sync.py", ["scan"]),
    ("code-scan", "bo_code.py", ["scan"]),
    ("database-check", "bo_db.py", ["check"]),
    ("documentation-check", "bo_code.py", ["docs", "--strict"]),
    ("api-check", "bo_code.py", ["api-check", "--strict"]),
    ("provider-name-inventory", "bo_names.py", ["inventory"]),
    ("inspect-before-provider-review", "change_sync.py", ["inspect"]),
]
summary = []
for label, script, arguments in commands:
    value = cli(label, script, *arguments, allow_failure=True)
    summary.append({"label": label, "valid": value.get("valid"),
        "errors": value.get("errors", []), "review_errors": value.get("review_errors", []),
        "missing_count": len(value.get("missing", []))})
save(RUN / "static-batch-findings.json", summary)
print({"static_batch_collected": True, "failed": [item["label"] for item in summary if item["valid"] is False]}, flush=True)
