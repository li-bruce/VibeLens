"""Freeze native evidence, then run the unchanged original ordinary workload once."""
import shutil
from runtime_tools import APP, RUN, PY, CHANGE, load, save, sha, run

assert load(RUN / "runtime-slot-status.json")["available_to_trial"]
value = load(RUN / "verify-before-browser-current.json")
assert value["candidate_id"] == load(RUN / "candidate-build.json")["candidate_id"]
assert len(value["tests"]) == 6 and all(item["exit_code"] == 0 for item in value["tests"])
for name in ("state_rules", "business", "project_checks", "concepts"):
    assert value["reports"][name]["status"] == "passed", (name, value["reports"][name])
allowed_nodes = {"ui_row_action", "ui_callback", "ui_navigation"}
for error in value["errors"]:
    if isinstance(error, str):
        assert error == "invalid or incomplete implementation mapping: mapping scenario coverage differs from protected plan", error
    else:
        assert (error.get("feature_event_missing") in allowed_nodes or error.get("feature_field_not_observed") in allowed_nodes), error

mapping = load(APP / "mapping.json")
expected = {(case, mode) for case in mapping["cases"] for mode in mapping["modes"]}
native = load(APP / "review/runtime/native-runs.json")
actual = {(item["case"], item["mode"]) for item in native["runs"]}
assert len(expected) == 18 and len(actual) == 15
assert expected - actual == {("browser", mode) for mode in ("on", "off", "fault")}
assert not actual - expected
observations = load(APP / "review/runtime/observations.json")
combined = {(item["case"], item["mode"]) for item in observations["runs"]}
proof = {"protected_plan_combinations": len(expected), "fresh_native_combinations": len(actual),
         "missing_from_fresh_native": sorted(expected - actual), "extra": sorted(actual - expected),
         "prebrowser_combined_observations_combinations": len(combined),
         "canonical_prebrowser_valid": value["valid"], "errors": value["errors"],
         "classification": "Fifteen fresh native cases completed. Any same-build retained browser input is historical; this attempt must still execute its own three real browser modes and two consecutive recordings."}
save(RUN / "pending-browser-evidence-proof.json", proof)
out = RUN / "native-before-browser"
out.mkdir(exist_ok=False)
for source in (APP / CHANGE / "checks").glob("*.json"):
    shutil.copy2(source, out / source.name)
for name in ("manifest.json", "review/native-test-settings.json", "review/project-checks.json",
             "review/runtime/native-command.log", "review/runtime/native-runs.json", "review/runtime/observations.json",
             "review/runtime/browser-capture.json"):
    source = APP / name
    if source.exists():
        target = out / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
shutil.copy2(APP / "bo_stategraph/config/views/local.json", RUN / "personal-views-before-ordinary.json")
log = APP / "var/native-order.jsonl"
save(RUN / "ordinary-browser-start.json", {
    "identity": load(RUN / "candidate-build.json"), "pending_gate": proof,
    "personal_revision": load(APP / "bo_stategraph/config/views/local.json")["revision"],
    "personal_sha256": sha(APP / "bo_stategraph/config/views/local.json"),
    "original_native_order_prefix": {"bytes": log.stat().st_size, "sha256": sha(log)},
    "only_original_unprofiled_command": True, "old_runtime_failures_not_counted_as_this_pass": True,
    "execution_environment": "Explicitly authorized Windows host after preserved sandbox snapshot failure",
})
print({"native_cases": len(actual), "six_commands_passed": True, "historical_browser_combinations": len(combined - actual),
       "ordinary_command_unchanged": True}, flush=True)
exit_code = run("ordinary-browser-recording", [PY, "-B", "-X", "utf8", "tooling/unified_browser_run.py", "--recording"], allow_failure=True)
print({"ordinary_exit_code": exit_code, "repeated": False}, flush=True)
