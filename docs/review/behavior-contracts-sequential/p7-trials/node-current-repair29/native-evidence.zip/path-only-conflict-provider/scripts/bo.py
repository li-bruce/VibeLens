# Path-only negative fixture; no provider code is executed.
