"""Compatibility import for the existing scoped bilingual-name review helper."""
from repair_tools import *
