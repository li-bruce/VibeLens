"""Independently retain the sealed source, all capture definitions and old evidence."""
import hashlib
from pathlib import Path
from runtime_tools import APP, PACK, RUN, CHANGE, load, save, sha

before = load(RUN / "runtime-before-seal.json")
snapshot = load(RUN / "current-static-snapshot.json")
source_mismatches = [name for name, value in snapshot["files"].items() if value is not None and sha(APP / name) != value]
record_mismatches = [name for name, value in before["record_hashes"].items() if sha(APP / name) != value]
assert not source_mismatches and not record_mismatches, (source_mismatches, record_mismatches)
installed = {path.relative_to(PACK).as_posix(): sha(path) for path in PACK.rglob("*")
             if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc"}
expected = load(RUN / "provider-files-runtime-baseline.json")
assert installed == expected, {"changed": [name for name in expected if installed.get(name) != expected[name]],
                               "added": sorted(installed.keys() - expected.keys())}
old_run = RUN.parent / "context-closure-runtime-20261122"
archive = load(old_run / "before-seal.json")["old_archive_reference"]
digest = hashlib.sha256()
with Path(archive["path"]).open("rb") as stream:
    while chunk := stream.read(1024 * 1024):
        digest.update(chunk)
assert digest.hexdigest() == archive["sha256"]
model = load(APP / "bo_stategraph/project.json")["model"]
old_model = load(RUN / "before/bo_stategraph/project.json")["model"]
def fields(value):
    return {(node["id"], direction, key): item for node in value["nodes"] for direction in ("in", "out")
            for key, item in node.get("capture", {}).get(direction, {}).items()}
assert fields(model) == fields(old_model) and len(fields(model)) == 666
assert len(model["nodes"]) == 647
assert all(model[key] == old_model[key] for key in ("machines", "policy", "concepts"))
assert load(APP / ".stategraph/active.json")["change"] == CHANGE
assert not (APP / CHANGE / "accepted.json").exists()
assert load(APP / "sync.json")["test_commands"] == before["test_commands"]
assert load(APP / "sync.json")["timeout_seconds"] == before["timeout_seconds"] == 180
save(RUN / "final-source-provider-record-preservation.json", {
    "valid": True, "snapshot_files_checked": len(snapshot["files"]), "source_mismatches": source_mismatches,
    "model_nodes": len(model["nodes"]), "capture_fields": len(fields(model)), "all_capture_definitions_identical": True,
    "native_state_rule_and_concept_definitions_unchanged": True,
    "old_recordings_checked": len(before["record_hashes"]), "old_record_mismatches": record_mismatches,
    "full_installed_files_checked": len(installed), "owned_files_checked": 466, "installed_files_unchanged": True,
    "test_commands": len(before["test_commands"]), "case_timeout_seconds": 180,
    "source_test_and_managed_sdk_bytes_unchanged_since_static_seal": True, "old_archive_reference": archive,
    "old_archive_hash_verified": True, "archive_repacked": False, "baseline_reset": False, "accept_executed": False,
    "generated_current_manifest": {"sha256": sha(APP / "manifest.json"), "build_id": load(APP / "manifest.json")["build_id"]},
})
print({"preservation_valid": True, "snapshot_files": len(snapshot["files"]), "fields": len(fields(model)),
       "old_records": len(before["record_hashes"]), "installed_files": len(installed),
       "old_archive_unchanged": True, "accept_executed": False}, flush=True)
