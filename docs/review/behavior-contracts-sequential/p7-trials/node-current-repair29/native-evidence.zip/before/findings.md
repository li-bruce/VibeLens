# Findings

- User U4 explicitly confirms the displayed business/state/rule graph and authorizes implementation.
- User additionally requires real username/password login/logout; three test accounts, one announcement editor; no registration/account management UI.
- Node v20.19.6, npm 10.8.2 are installed. Node 20 does not supply the newer built-in SQLite API, so use a project-declared native SQLite dependency.
- The selected external Skill is v0.15.0 in ../node-retest-skills/vibelens. Supplied Python is ../../../../.venv/Scripts/python.exe by absolute path in the environment.
- Managed JavaScript BO runtime/capture modules installed through bo_integrate.py apply; framework source is untouched.
- Existing design-only graph is http://127.0.0.1:8926/graph. Host-launched processes are reachable by Chrome; sandbox-launched servers timed out. Keep this distinction when launching the application/observer.
SQLite implementation decision: use sql.js (SQLite compiled to WebAssembly) with project-local SQLite-file persistence. This avoids installing C++ tooling after the native-addon download failure. Native SQLite transactions and a commit-time atomic file replacement remain application-owned.

- The early origin guard precedes the original route-local HTTP probe; a real
  forbidden login request therefore returned 403 with no API return event. This
  was independently reproduced, rather than inferred from middleware order.
- The new managed bo_http adapter observes a native listener before middleware,
  closes once on response finish/close, and uses completed=false with no status
  if headers were never sent. Its route resolver must reuse native registrations.
- The new provider's current bo_integrate plan rejects addition of bo_http.mjs to
  the two-file receipt. This is a managed migration gap, not business permission
  ambiguity. The old installation and pre-repair native files remain unchanged.
- In this Windows Python environment, Path('.').resolve() unexpectedly appends
  the workspace basename. Use an explicit absolute root (or Path(os.getcwd()))
  in diagnostics; the project helpers use their absolute __file__ parent.

- Batch candidate unified-1795147982 has a successful first recording and a
  separate failed second recording. Do not flatten these into one outcome.
- The second wait failed before stop while Team files was visible. Received
  native events were produced within five seconds, then drained for over forty
  seconds. Exact timeout health was not retained; later stop health is labeled
  separately. A session-absent snapshot (evidence sequence 2200, 572 bytes) timed
  out twice. Actual server admission and the exact slow function are unresolved.
- All returned native observer HTTP responses were 200; ten attempts timed out.
  The 234 batch attempts contain 4213 items including retries. Request sizes and
  response-header latencies are retained; receipt bodies and exact batch members
  were absent in that original audit. New audit instrumentation does not recreate
  those missing historical values.
- A static old-provider bo_internal import has a distinct AsyncLocalStorage
  instance from dynamically selected data wiring, even when module bytes match.
  Aligning the reader's provider fixes independent-query suppression and requires
  fresh native evidence. The live browser app never imports that reader.
- Off/fault child environments formerly overrode the selected provider. They
  now inherit it, and future single-parent runs assert provider and served-SDK
  equality. Previous equal business results remain mixed-provider observations.


Ordered-evidence iteration preflight: current access at the actual start boundary controls uncancelled queued tasks; no historical revocation latch. Re-sharing does not revive cancelled tasks. The new installed guidance requires real synchronization/transaction boundaries for controlled cases and independent native order for ordinary worker results; unchanged screen/read timing is not a barrier. Preserve each required assertion and record branches not exercised by a particular recording. Package is a guidance-only delta from repair23, not independent proof of this Node application's new behavior.


Provider transition preflight (2026-11-21): new canonical check is stale because only tool-manifest entries bo_observer/service.py and web/bo_design.py differ; all other snapshot inputs equal accepted initial. Managed plan/apply/check valid with changes empty. The subsequent real canonical begin exits1 at change_sync.py:555-560 because accepted.candidate_id != current tool-aware snapshot ID. New change directory absent; active/accepted/baseline/source/current UI bytes unchanged. This is an official begin-transition prerequisite, not random identity drift. Do not edit installed framework, hand-copy baseline/active, or overwrite old receipts. Minimal evidence: review/runtime/queue-start-permission-20261121/provider-begin-transition-issue.json. Source implementation and tests have not started. An original-assertion inventory and controlled/ordinary evidence mapping plan are saved separately while awaiting a supported transition.


Static confirmation audit: concept-confirmed-validation is valid but ready=false, 86 blocked records all locally unchanged. The announcement closure selects file-owner/grant-recipient/grant-active through an existing cross-domain editor/file-authority expectation. Extending their read_basis.timing for background preparation caused dependent old confirmations to stop matching. Initial announcement/state/rule definitions and confirmations themselves remain unchanged. No announcement re-confirmation is synthesized. Frozen old/current discovery and canonical dependency comparison: review/runtime/queue-start-permission-20261121/unchanged-subsystem-confirmation-repro.json. Continue native implementation; preparation-specific qualified read facts versus this global timing extension remains a focused modeling obligation.


The canonical source enrichment must use the same previous baseline structure cache as change_sync snapshot. A fresh uncached source scan produced the same edge identities/values but a different order, correctly failing strict projection freshness. Reusing the actual immutable active baseline index and the canonical stable projector aligns the declaration without hand-editing generated identities. The old initial change impact.json was legitimately recomputed by the pre-begin canonical check at 2026-11-20T21:29:34Z: its current candidate 0ce12b... equals that retained check, while the frozen original a8f0eec8... remains in before-iteration.zip. Treat this as an explicitly disclosed derived diagnostic update; accepted, baseline, review, verification and all old raw evidence are separately protected. No restore was performed.
