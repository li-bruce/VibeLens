import assert from 'node:assert/strict';
import { mkdtemp, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { Store, TEST_PASSWORD } from '../src/store.mjs';
import { FileService } from '../src/service.mjs';
import { createApp } from '../src/http.mjs';
import { bo_create } from '../integrations/bo_observe.mjs';
import { readInstances, nativeAuditor } from './native_reader.mjs';
import { queueStartScenario } from './queue_start_scenario.mjs';

const projectRoot = path.resolve('.');
const settings = JSON.parse(await readFile('review/native-test-settings.json', 'utf8'));
const project = JSON.parse(await readFile('bo_stategraph/project.json', 'utf8'));

/** Fail if independent verification reads are captured as native business queries. */
function readAuthority(observer, store, buildId, selection) {
  const before = observer.probe.bo_health().enqueued;
  const authority = readInstances(store, buildId, selection);
  const after = observer.probe.bo_health().enqueued;
  assert.equal(after, before, 'Independent SQLite verification reads emitted business events');
  return { authority, exclusion: { before, after, emitted: after - before } };
}

/** Run real native/HTTP operations under one actual observation mode. */
async function workflow(mode, limited = false) {
  const root = await mkdtemp(path.join(projectRoot, 'review/runtime/native-' + mode + '-'));
  const store = new Store(path.join(root, 'db/application.sqlite'));
  const service = new FileService(store, root); service.workerDelay = 60000;
  const events = [], snapshots = [], frames = [];
  const observer = await bo_create(service, projectRoot, {
    project, buildId: settings.build_id, policyHash: settings.policy_hash,
    enabled: mode !== 'off', capacity: limited ? 2 : 4096,
    sink: async (body, kind) => {
      if (mode === 'fault') throw new Error('Injected transport outage');
      if (limited) await new Promise(resolve => setTimeout(resolve, 25));
      (kind === 'events' ? events : snapshots).push(body);
      frames.push({kind,body});
    }
  });
  const auditor = nativeAuditor(service, settings.build_id);
  const server = createApp(service, path.join(projectRoot, 'public'), observer).listen(0, '127.0.0.1');
  await new Promise(resolve => server.once('listening', resolve));
  const url = 'http://127.0.0.1:' + server.address().port;
  const cookies = {}, payload = Buffer.from('Independent synthetic file-sharing acceptance payload.\n');
  const expectedSha = createHash('sha256').update(payload).digest('hex');
  const o = {}, selection = { grant: [], download_task: [], announcement: [], session: [] };
  const call = async (who, route, method = 'GET', value, extra = {}) => {
    const headers = { ...(cookies[who] ? { Cookie: cookies[who] } : {}), ...extra };
    if (value && !Buffer.isBuffer(value)) headers['Content-Type'] = 'application/json';
    const response = await fetch(url + route, { method, headers, body: value === undefined ? undefined : Buffer.isBuffer(value) ? value : JSON.stringify(value) });
    const cookie = response.headers.get('set-cookie'); if (cookie) cookies[who] = cookie.split(';')[0];
    return response;
  };
  const login = async who => {
    const result = await call(who, '/api/auth/login', 'POST', { username: who, password: TEST_PASSWORD });
    assert.equal(result.status, 200); await result.json();
    const session = service.session(cookies[who].slice('team_session='.length)); selection.session.push(session.trace_id);
  };
  let fileId, taskId, annId;
  try {
    const eventStart=events.length,nativeStart=auditor.entries.length;
    const early=await call('anonymous','/api/auth/login','POST',{username:'alice',password:TEST_PASSWORD},{Origin:'http://unrelated.invalid'});
    o.early_origin_status=early.status;
    await early.arrayBuffer();await observer.probe.flush(10000);
    o.early_origin_native_login=auditor.entries.slice(nativeStart).filter(entry=>entry.name==='login').length;
    assert.equal(o.early_origin_status,403);assert.equal(o.early_origin_native_login,0);
    if(mode==='on'&&!limited){
      const response=events.slice(eventStart).filter(event=>event.node==='api_login'&&event.phase==='return');
      assert.equal(response.length,1);assert.equal(response[0].outputs.status,403);assert.equal(response[0].outputs.completed,true);
    }
    assert.equal((await call('anonymous', '/api/files')).status, 401);
    assert.equal((await call('anonymous', '/api/auth/login', 'POST', { username: 'alice', password: 'incorrect' })).status, 401);
    for (const who of ['alice', 'bob', 'editor']) await login(who);
    assert.equal((await call('alice', '/api/auth/session')).status, 200);
    assert.equal((await call('alice', '/api/members')).status, 200);
    assert.equal((await call('alice', '/api/files?name=', 'POST', payload, { 'Content-Type':'application/octet-stream' })).status, 400);
    const upload = await call('alice', '/api/files?name=acceptance.txt', 'POST', payload, { 'Content-Type':'application/octet-stream' });
    assert.equal(upload.status, 201); fileId = (await upload.json()).id;
    assert.equal((await call('alice', '/api/files/' + fileId)).status, 200);
    o.editor_file_status = (await call('editor', '/api/files/' + fileId)).status;
    o.unrelated_file_count = (await (await call('editor', '/api/files')).json()).files.length;
    assert.equal((await call('editor', '/api/tasks', 'POST', { file_id:fileId })).status, 403);
    assert.equal((await call('alice', '/api/files/' + fileId + '/shares', 'POST', { recipient_id:'bob' })).status, 200);
    selection.grant.push(fileId + '/bob');
    o.recipient_reshare_status = (await call('bob', '/api/files/' + fileId + '/shares', 'POST', { recipient_id:'editor' })).status;
    assert.equal((await call('bob', '/api/files/' + fileId + '/shares/bob', 'DELETE')).status, 403);
    const request = await call('bob', '/api/tasks', 'POST', { file_id:fileId }); assert.equal(request.status, 202);
    const requestBody = await request.json(); taskId = requestBody.task_id; selection.download_task.push(taskId);
    o.native_task_committed = Boolean(store.get('SELECT authorized_at_submission FROM tasks WHERE id=?',taskId)?.authorized_at_submission);
    o.admission={committed:request.status===202 && o.native_task_committed && store.get('SELECT requester_id FROM tasks WHERE id=?',taskId)?.requester_id==='bob'};
    assert.equal((await call('bob', '/api/tasks/' + taskId + '/download')).status, 403);
    assert.equal((await call('alice', '/api/files/' + fileId + '/shares/bob', 'DELETE')).status, 200);
    o.new_task_after_revoke_status = (await call('bob', '/api/tasks', 'POST', { file_id:fileId })).status;
    assert.equal((await call('bob', '/api/tasks')).status, 200);
    clearTimeout(service.workerTimer); service.workerBusy = false;
    await service.setGrant(service.session(cookies.alice.slice('team_session='.length)), fileId, 'bob', true);
    await service.drainWorker();
    await service.setGrant(service.session(cookies.alice.slice('team_session='.length)), fileId, 'bob', false);
    const collection1 = await call('bob', '/api/tasks/' + taskId + '/download'); o.collect_after_revoke_status = collection1.status;
    assert.deepEqual(Buffer.from(await collection1.arrayBuffer()), payload);
    const collection2 = await call('bob', '/api/tasks/' + taskId + '/download'); o.repeat_collect_status = collection2.status;
    assert.equal(createHash('sha256').update(Buffer.from(await collection2.arrayBuffer())).digest('hex'), expectedSha);
    o.other_requester_collect_status = (await call('editor', '/api/tasks/' + taskId + '/download')).status;
    assert.equal((await call('alice', '/api/announcements', 'POST', { title:'Denied',body:'No role.' })).status, 403);
    const published = await call('editor', '/api/announcements', 'POST', { title:'Acceptance notice',body:'Synthetic local content.' });
    assert.equal(published.status,201); annId=(await published.json()).id;selection.announcement.push(annId);
    const board = await call('bob','/api/announcements'); const boardRows = await board.json();
    o.requires_file_grant = !(board.status===200 && boardRows.announcements.some(row=>row.id===annId) && !store.get('SELECT active FROM grants WHERE file_id=? AND recipient_id=?',fileId,'bob').active);
    assert.equal((await call('editor','/api/announcements/'+annId,'PUT',{title:'Updated notice',body:'Updated synthetic content.'})).status,200);
    const now=new Date().toISOString();
    store.run("INSERT INTO announcements VALUES('historical-fixture','alice','Fixture','Independent setup for author-boundary rejection.','published',?,?,1)",now,now);
    o.allowed=(await call('editor','/api/announcements/historical-fixture','PUT',{title:'Denied',body:'Other author.'})).status===200;
    assert.equal((await call('editor','/api/announcements/historical-fixture','DELETE')).status,403);
    assert.equal((await call('editor','/api/announcements/'+annId,'DELETE')).status,200);
    const malformed=await fetch(url+'/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:'{broken'});o.malformed_json_status=malformed.status;
    const oldCookie=cookies.bob;assert.equal((await call('bob','/api/auth/logout','POST')).status,204);
    o.logout_old_cookie_status=(await fetch(url+'/api/tasks',{headers:{Cookie:oldCookie}})).status;
    assert.equal((await call('anonymous','/api/auth/logout','POST')).status,403);
    const task=store.get('SELECT status FROM tasks WHERE id=?',taskId);
    const session=store.get("SELECT status FROM sessions WHERE user_id='bob' ORDER BY created_at DESC LIMIT 1");
    o.task={status:task.status};o.session={status:session.status};
    o.existing_task_collect_allowed=o.collect_after_revoke_status===200;
    o.new_task_allowed=o.new_task_after_revoke_status===202;
    o.may_manage_file=(await call('editor','/api/files/'+fileId+'/shares','POST',{recipient_id:'editor'})).status===200;
    o.may_request_file=(await call('editor','/api/tasks','POST',{file_id:fileId})).status===202;
    o.collections={'0':{allowed:o.collect_after_revoke_status===200},'1':{allowed:o.repeat_collect_status===200}};
    const {authority,exclusion}=readAuthority(observer,store,settings.build_id,selection);
    o.fact_basis=auditor.factBasis;
    assert.deepEqual(auditor.errors,[]);
    assert.equal(new Set(authority.instances.map(row=>row.state_model_id)).size,4);
    await observer.probe.flush(20000);
    const health=observer.health();
    if(mode==='on'&&!limited){assert.equal(health.errors,0);assert.equal(health.dropped,0);assert.ok(events.length>100);}
    if(mode==='off')assert.equal(events.length,0);
    if(mode==='fault'){assert.equal(events.length,0);assert.ok(health.errors>0);}
    if(limited)assert.ok(health.dropped>0);
    return {case:limited?'queue_limited':'workflow',mode,observations:o,authority_snapshot:authority,observer_query_exclusion:exclusion,events,snapshots,frames,policy_evaluations:observer.evaluations,probe_health:health,native_sdk:auditor.sdk,native_states:auditor.stateValues,native_completions:auditor.completions,state_frames:observer.stateFrames,selection,native_database:path.join(root,'db/application.sqlite')};
  } finally {
    auditor.close();await service.stop();await new Promise(resolve=>server.close(resolve));await observer.close();store.close();
  }
}
const runs=[];
for(const mode of ['on','off','fault'])runs.push(await workflow(mode));
assert.deepEqual(runs[0].observations,runs[1].observations);
assert.deepEqual(runs[0].observations,runs[2].observations);
const limited=await workflow('on',true);
assert.deepEqual(runs[0].observations,limited.observations);
/** Execute one successful real lifecycle per transition without mixed rejection outcomes. */
async function stateLifecycles(mode) {
  const root=await mkdtemp(path.join(projectRoot,'review/runtime/lifecycles-'));
  const store=new Store(path.join(root,'db/application.sqlite')), service=new FileService(store,root);
  service.workerDelay=60000;
  const events=[],snapshots=[],frames=[];
  const observer=await bo_create(service,projectRoot,{project,buildId:settings.build_id,policyHash:settings.policy_hash,enabled:mode!=='off',sink:async(body,kind)=>{if(mode==='fault')throw new Error('Injected transport outage');(kind==='events'?events:snapshots).push(body);frames.push({kind,body});}});
  const auditor=nativeAuditor(service,settings.build_id), selection={grant:[],download_task:[],announcement:[],session:[]};
  try {
    const sessions={};
    for(const who of ['alice','bob','editor']){sessions[who]=await service.login(who,TEST_PASSWORD);selection.session.push(sessions[who].observation.session_id);}
    const alice=service.session(sessions.alice.token),bob=service.session(sessions.bob.token),editor=service.session(sessions.editor.token);
    const bytes=Buffer.from('Real state-lifecycle fixture.\n');
    const file=await service.upload(alice,'lifecycle.txt',bytes);
    await service.setGrant(alice,file.id,'bob',true);selection.grant.push(file.id+'/bob');
    const task=await service.requestDownload(bob,file.id);selection.download_task.push(task.task_id);
    await service.setGrant(alice,file.id,'bob',false);
    await service.setGrant(alice,file.id,'bob',true);
    clearTimeout(service.workerTimer);service.workerBusy=false;await service.drainWorker();
    await service.setGrant(alice,file.id,'bob',false);
    assert.deepEqual((await service.collect(bob,task.task_id)).bytes,bytes);
    const announcement=await service.publish(editor,'Lifecycle fixture','Synthetic content.');selection.announcement.push(announcement.id);
    await service.mutateAnnouncement(editor,announcement.id,'edit','Edited fixture','Updated synthetic content.');
    await service.mutateAnnouncement(editor,announcement.id,'delete');
    for(const who of ['alice','bob','editor'])await service.logout(sessions[who].token);
    const {authority,exclusion}=readAuthority(observer,store,settings.build_id,selection);
    assert.equal(authority.instances.find(row=>row.state_model_id==='download_task').state,'ready');
    assert.equal(authority.instances.find(row=>row.state_model_id==='grant').state,'inactive');
    assert.equal(authority.instances.find(row=>row.state_model_id==='announcement').state,'deleted');
    assert.ok(authority.instances.filter(row=>row.state_model_id==='session').every(row=>row.state==='ended'));
    assert.deepEqual(auditor.errors,[]);
    await observer.probe.flush(20000);
    const health=observer.health();if(mode==='on')assert.equal(health.errors,0);assert.equal(health.dropped,0);
    return {case:'state_lifecycles',mode,observations:{native_lifecycles_completed:true},authority_snapshot:authority,observer_query_exclusion:exclusion,events,snapshots,frames,policy_evaluations:observer.evaluations,probe_health:health,native_sdk:auditor.sdk,native_states:auditor.stateValues,native_completions:auditor.completions};
  } finally {auditor.close();await service.stop();await observer.close();store.close();}
}
for(const mode of ['on','off','fault'])runs.push(await stateLifecycles(mode));
/** Exercise actual disk persistence failure and actual SQLite read/write failures. */
async function storageFailure(mode) {
  const root=await mkdtemp(path.join(projectRoot,'review/runtime/storage-failure-'));
  const store=new Store(path.join(root,'db/application.sqlite')),service=new FileService(store,root);
  service.workerDelay=60000;
  const events=[],snapshots=[],frames=[];
  const observer=await bo_create(service,projectRoot,{project,buildId:settings.build_id,policyHash:settings.policy_hash,enabled:mode!=='off',sink:async(body,kind)=>{if(mode==='fault')throw new Error('Injected transport outage');(kind==='events'?events:snapshots).push(body);frames.push({kind,body});}});
  const server=createApp(service,path.join(projectRoot,'public'),observer).listen(0,'127.0.0.1');
  await new Promise(resolve=>server.once('listening',resolve));
  try {
    const session=await service.login('alice',TEST_PASSWORD),actor=service.session(session.token);
    const file=await service.upload(actor,'failure.txt',Buffer.from('Native storage failure fixture.'));
    const nativePersist=store.persist;
    store.persist=()=>{throw new Error('Injected disk persistence failure');};
    const response=await fetch('http://127.0.0.1:'+server.address().port+'/api/tasks',{method:'POST',headers:{Cookie:'team_session='+session.token,'Content-Type':'application/json'},body:JSON.stringify({file_id:file.id})});
    store.persist=nativePersist;
    assert.equal(response.status,500);
    const taskCount=store.get('SELECT COUNT(*) AS count FROM tasks').count;assert.equal(taskCount,0);
    assert.throws(()=>store.all('SELECT missing_column FROM users'));
    assert.throws(()=>store.run("INSERT INTO grants(file_id,recipient_id,active) VALUES(?,?,2)",file.id,'bob'));
    assert.equal(store.get('SELECT COUNT(*) AS count FROM grants').count,0);
    await observer.probe.flush(20000);const health=observer.health();if(mode==='on')assert.equal(health.errors,0);assert.equal(health.dropped,0);
    return {case:'storage_failure',mode,observations:{persist_http_status:response.status,task_count:taskCount,sql_read_failed:true,sql_write_failed:true},events,snapshots,frames,probe_health:health,policy_evaluations:observer.evaluations,authority_snapshot:{instances:[]}};
  } finally {await service.stop();await new Promise(resolve=>server.close(resolve));await observer.close();store.close();}
}
for(const mode of ['on','off','fault'])runs.push(await storageFailure(mode));
for(const mode of ['on','off','fault'])runs.push(await queueStartScenario(mode,'start_denied'));
for(const mode of ['on','off','fault'])runs.push(await queueStartScenario(mode,'all'));
for(const name of ['state_lifecycles','storage_failure','start_denied','controlled_start_permissions']){
  const selected=runs.filter(run=>run.case===name);
  assert.deepEqual(selected[0].observations,selected[1].observations);assert.deepEqual(selected[0].observations,selected[2].observations);
}
await writeFile('review/runtime/queue-limited.json',JSON.stringify(limited,null,2));
await writeFile('review/runtime/native-runs.json',JSON.stringify({build_id:settings.build_id,machine:{machines:project.model.machines},machine_evidence:'Actual observer declaration loaded by the native adapter; native business authority remains FileService and SQLite. Native state values and effects are read independently.',runs,resilience:{queue_limited:{business_equal:true,capture_dropped:limited.probe_health.dropped,complete_capture:false}}},null,2));
console.log(JSON.stringify({valid:true,runs:runs.map(run=>({mode:run.mode,events:run.events.length,errors:run.probe_health.errors,dropped:run.probe_health.dropped})),queue_limited_dropped:limited.probe_health.dropped}));
