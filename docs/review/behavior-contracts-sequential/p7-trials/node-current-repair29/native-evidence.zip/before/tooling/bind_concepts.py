"""Bind confirmed concepts to source-backed native operations and independent cases."""
import copy
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
SKILL = Path(os.environ.get("VIBELENS_SKILL", ROOT.parent / "node-migration-final-skills/vibelens"))
sys.path.insert(0, str(SKILL / "scripts"))
from bo_observer.concepts.model import build
from bo_observer.concepts.semantics import check_confirmations, snapshot_records
from bo_observer.concepts.common import canonical_id
from bo_observer.concepts.anchors import native_anchors

def read(name): return json.loads((ROOT / name).read_text(encoding="utf-8-sig"))
def write(name, value): (ROOT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

doc = read("discovery.json")
project = read("bo_stategraph/project.json")
model = project["model"]
data = build(doc)
confirmation = check_confirmations(doc)
fact_fields = {
    "actor-id": "actor", "actor-member": "member", "actor-editor": "editor",
    "file-owner": "owner", "grant-recipient": "recipient", "grant-active": "active",
    "task-requester": "requester", "task-submission-authorized": "submission_authorized",
    "task-state": "task_state", "announcement-author": "author", "announcement-state": "announcement_state",
    "credentials-valid": "credentials_valid",
    "preparation-requester": "preparation_requester", "preparation-file-owner": "preparation_owner",
    "preparation-grant-recipient": "preparation_recipient", "preparation-grant-active": "preparation_active",
    "preparation-task-state": "preparation_task_state"
}
events = {
    "grant": {"share": "share_file", "revoke": "revoke_share"},
    "download_task": {"enqueue": "request_download", "start": "prepare_download", "finish": "mark_download_ready", "cancel": "prepare_download"},
    "announcement": {"publish": "publish_announcement", "edit": "edit_announcement", "delete": "delete_announcement"},
    "session": {"login": "login", "logout": "logout"}
}
binding = {
    "schema": "bo-concept-bindings/v2", "semantic_revision": snapshot_records({k: data["records"][k] for k in confirmation["coverage_scope"]})["semantic_revision"],
    "state_models": {m["id"]: m["id"] for m in doc["state_models"]},
    "objects": {m["id"]: m["subject"] for m in doc["state_models"]},
    "business": {n["id"]: ["prepare_download" if n["id"] == "download_cancelled" else n["id"]] for network in doc["networks"] for n in network["nodes"]},
    "facts": {f["id"]: [{"node": "policy_facts", "direction": "out", "field": fact_fields[f["id"]],
                          "basis_checks": [{"case": "workflow", "path": ["fact_basis", f["id"]]}]}] for f in doc["facts"]},
    "events": {}, "guards": {}, "effects": {"effect:download_task:persist_authorized_task": ["task_commit"]},
    "expectations": {e["id"]: ["workflow"] for e in doc["expectations"]},
    "crosslinks": {}, "transition_effects": {}
}
preparation_cases = {"start-denied-cancels": "start_denied", "restored-before-start": "controlled_start_permissions", "cancelled-no-revival": "controlled_start_permissions"}
for ident, case in preparation_cases.items():
    binding["expectations"][ident] = [case]
for machine in doc["state_models"]:
    ident = machine["id"]
    for event, node in events[ident].items():
        binding["events"][canonical_id("event", ident, event)] = {"node": node, "event": event}
    for name, guard in machine["guards"].items():
        operation = guard["decision"].split(":")[-1]
        key = canonical_id("guard", ident, name)
        binding["guards"][key] = {"node": "guard_" + operation, "decision": data["records"][key]["decision"], "field": "value"}

# Replace only this generator's typed binding edges, preserving all original IDs.
model["edges"] = [edge for edge in model["edges"] if not edge["id"].startswith("binding:")]
errors = []
anchors = native_anchors(doc, model, binding, data, lambda code, item: errors.append({"code": code, "item": item}))
if errors: raise ValueError(errors)
from bo_observer.concepts.semantics import resolve_index
for link in doc["crosslinks"]:
    left = anchors[resolve_index(data["index"], link["from"])]
    right = anchors[resolve_index(data["index"], link["to"])]
    if link["relation"] == "action_requests_event" and left == right:
        native = binding["events"][resolve_index(data["index"], link["to"])]
        binding["crosslinks"][link["id"]] = {"relation": link["relation"], "from": left, "to": right, "native_event": native["event"], "edges": []}
        continue
    starts, ends = (right, left) if link["relation"] in {"transition_guarded_by", "decision_reads_fact"} else (left, right)
    references = []
    for start in starts:
        for end in ends:
            ident = "binding:" + link["id"] + ":" + start + ":" + end
            model["edges"].append({"id": ident, "from": start, "to": end,
                                   "type": "guard" if link["relation"] == "transition_guarded_by" else "data",
                                   "label": link["relation"], "evidence": "Source binding of the confirmed typed relation; runtime calls and values are checked separately."})
            references.append(ident)
    binding["crosslinks"][link["id"]] = references

# The admission effect is observed at the actual inner SQLite commit. Its
# independently confirmed expectation is selected explicitly, never fabricated.
effect_expectation = next((e for e in doc["expectations"] if "effect:download_task:persist_authorized_task" in e["scope"]), None)
if effect_expectation:
    assertion = next(a for a in effect_expectation["then"] if a["equals"] is True)
    binding["transition_effects"]["transition:download_task:enqueue"] = [{
        "effect": "effect:download_task:persist_authorized_task",
        "edges": binding["crosslinks"]["enqueue-authorized-effect"],
        "completion": {"node": "task_commit", "phase": "return", "field": "committed", "equals": True,
                       "identity_field": "transaction_id", "boundary": data["records"]["effect:download_task:persist_authorized_task"]["completion"],
                       "expectation": effect_expectation["id"], "path": assertion["path"]}
    }]
model["concepts"] = binding
write("bo_stategraph/project.json", project)

acceptance = read("acceptance.json")
checks = {c["id"]: c for c in acceptance["checks"]}
for expected in doc["expectations"]:
    if expected["id"] not in preparation_cases:
        continue
    for position, assertion in enumerate(expected["then"]):
        ident = expected["id"] + "-" + str(position)
        checks[ident] = {"id": ident, "requirement": "R_DOWNLOAD", "case": preparation_cases[expected["id"]], **copy.deepcopy(assertion)}
for fact in doc["facts"]:
    checks["basis-" + fact["id"]] = {"id": "basis-" + fact["id"], "requirement": "R_DOWNLOAD" if fact["id"].startswith("preparation-") else "R_AUTH" if fact["id"] == "credentials-valid" else "R_BOARD" if "announcement" in fact["id"] or fact["id"] == "actor-editor" else "R_FILES",
        "case": "workflow", "path": ["fact_basis", fact["id"]],
        "equals": {"node": "policy_facts", "direction": "out", "field": fact_fields[fact["id"]], "read_basis": copy.deepcopy(fact["read_basis"])}}
acceptance["checks"] = list(checks.values())
write("acceptance.json", acceptance)
print(json.dumps({"state_models": len(binding["state_models"]), "facts": len(binding["facts"]), "crosslinks": len(binding["crosslinks"]), "effect_expectation": effect_expectation is not None}))
