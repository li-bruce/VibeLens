import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { readFile, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import initSqlJs from 'sql.js';
import { readPersistedInstances } from '../tests/native_reader.mjs';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),runtime=path.join(root,'review/runtime');
const [command,mode,recordingId]=process.argv.slice(2);
const trials=JSON.parse(await readFile(path.join(runtime,'browser-trials.json'),'utf8'));
const selectedProvider=process.env.VIBELENS_SKILL || path.resolve(root,'../node-migration-final-skills/vibelens');
const json=async url=>{const response=await fetch(url);assert.ok(response.ok,'HTTP evidence query failed: '+url);return response.json();};
if(command==='capture' || command==='native'){
  assert.ok(['on','off','fault'].includes(mode));
  const ui=JSON.parse(await readFile(path.join(runtime,'browser-ui-'+mode+'.json'),'utf8'));
  assert.ok(['automated-desktop-browser-cua','automated-desktop-browser-playwright'].includes(ui.source));
  assert.ok(ui.dom_excerpt.includes(trials.filename) && ui.dom_excerpt.includes('领取文件'));
  const trial=trials.modes[mode],filename=path.join(trial.data_root,'db/application.sqlite');
  assert.equal(trial.skill_provider,selectedProvider,'Browser trial did not use the selected provider');
  const require=createRequire(import.meta.url),SQL=await initSqlJs({locateFile:name=>require.resolve('sql.js/dist/'+name)});
  const database=new SQL.Database(await readFile(filename));
  const rows=(sql,...values)=>{const statement=database.prepare(sql),result=[];try{statement.bind(values);while(statement.step())result.push(statement.getAsObject());}finally{statement.free();}return result;};
  const task=rows("SELECT * FROM tasks WHERE file_id=? AND requester_id='alice' ORDER BY created_at DESC LIMIT 1",trial.fixture_file_id)[0];
  const session=rows("SELECT trace_id,user_id,status FROM sessions WHERE user_id='alice' ORDER BY created_at DESC LIMIT 1")[0];
  database.close();
  assert.equal(task.status,'ready');assert.equal(task.authorized_at_submission,1);assert.equal(session.status,'active');
  assert.ok(path.resolve(task.prepared_path).startsWith(path.resolve(trial.data_root)+path.sep));
  const sha=createHash('sha256').update(await readFile(task.prepared_path)).digest('hex');assert.equal(sha,trials.sha256);
  const authority=await readPersistedInstances(filename,trials.build_id,{grant:[],download_task:[task.id],announcement:[],session:[session.trace_id]});
  const run={case:'browser',mode,skill_provider:trial.skill_provider,observations:{user_id:session.user_id,task_status:task.status,authorized_at_submission:Boolean(task.authorized_at_submission),prepared_sha256:sha},authority_snapshot:authority,events:[],snapshots:[],policy_evaluations:[],native_database:filename,gui_evidence:ui};
  if(mode==='on' && command==='native'){
    run.capture_status={validation:'not_asserted',reason:'This native GUI run does not execute the recording gate.'};
  }else if(mode==='on'){
    assert.ok(recordingId,'Use the actual recording ID returned by the canonical viewer');
    const recording=await json('http://127.0.0.1:8926/api/recordings/'+recordingId);
    await writeFile(path.join(runtime,'browser-recording-'+recordingId+'.json'),JSON.stringify(recording,null,2));
    assert.equal(recording.context.manifest.build_id,trials.build_id);assert.equal(recording.status,'stopped');assert.deepEqual(recording.gaps,[]);assert.equal(recording.producer_settlement.flushed,true);
    const original=path.join(runtime,'browser-recording-'+recordingId+'.json');
    const exported=path.join(runtime,'browser-recording-'+recordingId+'-native-evidence.json');
    const python=process.env.VIBELENS_PYTHON || path.resolve(root,'../../../.venv/Scripts/python.exe');
    await promisify(execFile)(python,['-B','-X','utf8',path.join(selectedProvider,'scripts/bo_trace.py'),'evidence','--root',root,'--recording',original,'--out',exported],{cwd:root,encoding:'utf8',windowsHide:true,maxBuffer:1024*1024,env:{...process.env,PYTHONDONTWRITEBYTECODE:'1',PYTHONIOENCODING:'utf-8'}});
    const nativeEvidence=JSON.parse(await readFile(exported,'utf8'));
    assert.equal(nativeEvidence.recording_id,recordingId);
    run.events=nativeEvidence.events;run.snapshots=nativeEvidence.snapshots;run.probe_health=nativeEvidence.probe_health;
    run.runtime_frames=recording.runtime_frames;
    assert.equal(run.probe_health.errors,0);assert.equal(run.probe_health.dropped,0);
    const evidence=await json(trial.url+'/api/bo/evidence');
    const checks=new Set(run.events.map(event=>event.inputs?.bo_check).filter(Boolean));
    run.policy_evaluations=evidence.policy_evaluations.filter(evaluation=>checks.has(evaluation.check_id));
    run.recording_id=recordingId;
    await writeFile(path.join(runtime,'browser-on-recording.json'),JSON.stringify(recording,null,2));
    for(const node of ['ui_callback','ui_navigation','ui_row_action'])assert.ok(run.events.some(event=>event.node===node&&event.phase==='return'&&event.outputs.completed===true),'Missing actual UI callback '+node);
  }else if(mode==='off'){
    const response=await fetch(trial.url+'/api/bo/config');assert.equal(response.status,404);
    run.capture_status={configured:false,config_http_status:response.status};
  }else{
    const health=await json(trial.url+'/api/bo/health');assert.ok(health.errors>0 || health.capture_control_errors>0);
    const attempts=await json(trials.fault_endpoint+'/fixture-health');
    assert.ok(attempts[trial.url] && Object.keys(attempts[trial.url]).some(key=>['POST /api/bo/events','POST /api/bo/events/batch'].includes(key)));
    run.capture_status={configured:true,transport:'real-http-503-fault-fixture',native_health:health,attempts};
  }
  await writeFile(path.join(runtime,(command==='native'?'browser-native-run-':'browser-run-')+mode+'.json'),JSON.stringify({build_id:trials.build_id,run},null,2));
  console.log(JSON.stringify({mode,build_id:trials.build_id,observations:run.observations,events:run.events.length,recording:run.recording_id}));
}else if(command==='assemble' || command==='assemble-native'){
  const native=command==='assemble-native';
  const files=await Promise.all(['on','off','fault'].map(async value=>JSON.parse(await readFile(path.join(runtime,(native?'browser-native-run-':'browser-run-')+value+'.json'),'utf8'))));
  for(const file of files){assert.equal(file.build_id,trials.build_id);assert.equal(file.run.skill_provider,selectedProvider);assert.equal(trials.modes[file.run.mode].skill_provider,selectedProvider);}
  assert.deepEqual(files[0].run.observations,files[1].run.observations);assert.deepEqual(files[0].run.observations,files[2].run.observations);
  await writeFile(path.join(runtime,native?'browser-native-capture.json':'browser-capture.json'),JSON.stringify({build_id:trials.build_id,skill_provider:selectedProvider,provider_consistent:true,runs:files.map(file=>file.run),recording_validated:!native,source:'Actual desktop browser callbacks and independent persisted SQLite/file reads; disabled/failing capture is explicitly retained.'},null,2));
  console.log(JSON.stringify({browser_modes:files.map(file=>file.run.mode),business_equal:true,recording_validated:!native}));
}else throw new Error('Use capture on|off|fault [actual-recording-id] or assemble');
