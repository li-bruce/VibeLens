"""Create distinct live evidence through real native login/list controls only."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import time
import urllib.request
from playwright.sync_api import sync_playwright, expect

RUN = Path(__file__).resolve().parent
APP = RUN.parents[2]
OUT = RUN / "live"
BASE = "http://127.0.0.1:8925"
GRAPH = "http://127.0.0.1:8926"
load = lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
services = load(OUT / "services.json")
def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
def get(url):
    with urllib.request.urlopen(url, timeout=35) as response:
        return json.load(response)
before = get(GRAPH + "/api/view")
save("view-before-ui.json", before)
before_ids = {event["id"] for event in before["events"]}
started = datetime.now(timezone.utc).isoformat()
http_responses, console_errors, page_errors = [], [], []
def response_seen(response):
    if response.url in (BASE + "/api/auth/login", BASE + "/api/files"):
        http_responses.append({"url": response.url, "method": response.request.method, "status": response.status, "body": response.json()})
with sync_playwright() as playwright:
    browser = playwright.chromium.launch(channel="chrome", headless=True)
    context = browser.new_context(viewport={"width": 1440, "height": 1000})
    page = context.new_page()
    page.on("response", response_seen)
    page.on("console", lambda message: console_errors.append(message.text) if message.type == "error" else None)
    page.on("pageerror", lambda error: page_errors.append(str(error)))
    page.goto(BASE + "/", wait_until="domcontentloaded")
    page.evaluate("import('/app.js').then(() => true)")
    expect(page.locator("#login-form")).to_be_visible()
    page.get_by_role("textbox", name="用户名", exact=True).fill("alice")
    page.get_by_role("textbox", name="密码", exact=True).fill("DemoPass!2026")
    with page.expect_response(lambda r: r.url == BASE + "/api/auth/login" and r.request.method == "POST") as login_response:
        page.get_by_role("button", name="登录", exact=True).click()
    assert login_response.value.status == 200
    expect(page.locator("#workspace")).to_be_visible()
    expect(page.get_by_role("heading", name="团队文件", exact=True)).to_be_visible()
    expect(page.locator("#file-list article").first).to_be_visible()
    with page.expect_response(lambda r: r.url == BASE + "/api/files" and r.request.method == "GET") as list_response:
        page.get_by_role("button", name="刷新列表", exact=True).click()
    assert list_response.value.status == 200
    body = list_response.value.json()
    expect(page.locator("#file-count")).to_have_text(str(body["count"]) + " 个文件")
    dom = {"url": page.url, "title": page.title(), "heading": page.locator("h1").filter(has_text="团队文件").inner_text(), "display_name": page.locator("#display-name").inner_text(), "file_count": page.locator("#file-count").inner_text(), "rendered_rows": page.locator("#file-list article").count(), "visible": page.locator("#files-view").is_visible()}
    assert dom["rendered_rows"] == body["count"] and body["count"] > 0
    page.screenshot(path=str(OUT / "fresh-live-files.png"), full_page=True)
    (OUT / "fresh-live-files.html").write_text(page.content(), encoding="utf-8")
    context.close()
    browser.close()
deadline = time.monotonic() + 35
while True:
    health = get(BASE + "/api/bo/health")
    after = get(GRAPH + "/api/view")
    new = [event for event in after["events"] if event["id"] not in before_ids]
    native = [event for event in new if event.get("run_id") == health["run_id"] and event.get("producer_id") == health["producer_id"]]
    if health["pending"] == 0 and all(any(event["node"] == name and event["phase"] == "return" for event in native) for name in ("login", "list_files")):
        break
    if time.monotonic() >= deadline:
        raise AssertionError("New native login/list events did not arrive in the live viewer")
    time.sleep(.2)
recordings = get(GRAPH + "/api/recordings")
assert recordings["active"] is None
assert after["binding_status"]["status"] == "current"
assert after["manifest"]["build_id"] == services["build_id"]
assert not health["errors"] and not health["dropped"] and not health["capture_control_errors"]
assert health["tracing"]["open_spans"] == 0 and health["tracing"]["automatic_errors"] == 0
assert all(event["build_id"] == services["build_id"] for event in new)
assert not page_errors
save("view-after-ui.json", after)
save("native-health-after-ui.json", health)
save("recordings-after-ui.json", recordings)
save("new-live-events.json", new)
save("http-login-list-responses.json", http_responses)
result = {"valid": True, "started_at": started, "finished_at": datetime.now(timezone.utc).isoformat(), "build_id": services["build_id"], "candidate_id": services["candidate_id"], "provider": services["provider"], "database": services["database"], "before_live_events": len(before["events"]), "after_live_events": len(after["events"]), "new_live_events": len(new), "new_native_events": len(native), "run_id": health["run_id"], "producer_id": health["producer_id"], "new_event_ids": [event["id"] for event in new], "native_login_list_event_ids": [event["id"] for event in native if event["node"] in ("login", "list_files")], "dom": dom, "http_statuses": [{"method": response["method"], "url": response["url"], "status": response["status"]} for response in http_responses], "page_errors": page_errors, "console_errors": console_errors, "recording_active": None, "health": health, "binding_status": after["binding_status"], "event_provenance": "Actual new live viewer event-ID delta from this fresh native app producer/run, created by a real Chrome login and file-list refresh. No historical record replay, recording start, or manufactured events.", "services_left_running": True}
save("fresh-live-ui-summary.json", result)
print(json.dumps({key: result[key] for key in ("valid", "before_live_events", "after_live_events", "new_live_events", "new_native_events", "run_id", "producer_id", "dom", "console_errors", "services_left_running")}, ensure_ascii=False))
