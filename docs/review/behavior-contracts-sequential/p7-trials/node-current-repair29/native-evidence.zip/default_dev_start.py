"""Start the ordinary npm dev command with provider variables absent; leave it for PID verification."""
from datetime import datetime, timezone
import os
import socket
import subprocess
import sys
import time
import urllib.request
from repair_tools import APP, PACK, RUN, ENV, load, save, sha

sys.path.insert(0, str(PACK / "scripts"))
from bo_observer.model_io import read_model
from behavior_model import capture
manifest = capture(APP, read_model(APP / "bo_stategraph/project.json", project_root=APP))
save(APP / "manifest.json", manifest)
save(RUN / "generated-manifest-before-default-dev.json", manifest)
for port in (8925, 8926):
    with socket.socket() as probe:
        assert probe.connect_ex(("127.0.0.1", port)) != 0, port
assert "VIBELENS_SKILL" not in ENV and "BO_DIAGNOSTIC_SKILL" not in ENV
command = [os.environ["ComSpec"], "/d", "/c", "npm", "run", "dev"]
startup = subprocess.STARTUPINFO()
startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow = subprocess.SW_HIDE
with (RUN / "ordinary-default-dev.stdout.log").open("xb") as out, (RUN / "ordinary-default-dev.stderr.log").open("xb") as err:
    child = subprocess.Popen(command, cwd=APP, env=ENV, stdin=subprocess.DEVNULL, stdout=out, stderr=err,
        close_fds=True, startupinfo=startup,
        creationflags=subprocess.CREATE_NO_WINDOW | subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP)
save(RUN / "ordinary-default-dev-start.json", {"command": command, "root_pid": child.pid,
    "started_at": datetime.now(timezone.utc).isoformat(), "provider_environment": {"VIBELENS_SKILL": None, "BO_DIAGNOSTIC_SKILL": None}})
pointer = APP / "review/runtime/provider-entrypoints/dev-latest.json"
deadline = time.monotonic() + 60
while time.monotonic() < deadline:
    if child.poll() is not None:
        raise RuntimeError("Ordinary npm dev exited: " + str(child.returncode))
    if pointer.exists():
        value = load(load(pointer)["path"])
        if value["provider"] == str(PACK):
            break
    time.sleep(.2)
else:
    raise RuntimeError("Ordinary npm dev did not produce its readiness/selection receipt")
assert value["selection"]["source"] == "integrations/provider.json"
assert value["selection"]["requested_skill"] is None and value["selection"]["requested_diagnostic_skill"] is None
assert value["build_id"] == manifest["build_id"]
save(RUN / "ordinary-default-dev-receipt.json", value)
def get(url):
    with urllib.request.urlopen(url, timeout=35) as response:
        return __import__("json").load(response)
health = get("http://127.0.0.1:8925/api/bo/health")
view = get("http://127.0.0.1:8926/api/view")
assert view["binding_status"]["status"] == "current" and view["manifest"]["build_id"] == manifest["build_id"]
assert health["enabled"] and health["dropped"] == health["errors"] == 0
save(RUN / "ordinary-default-dev-health.json", health)
save(RUN / "ordinary-default-dev-view-identity.json", {"binding": view["binding_status"], "build_id": view["manifest"]["build_id"], "live_events": len(view.get("events", []))})
print({"ordinary_npm_dev_ready": True, "root_pid": child.pid, "app_pid": value["app"], "viewer_launcher_pid": value["viewer"],
    "provider": value["provider"], "source": value["selection"]["source"], "build_id": value["build_id"],
    "provider_environment_at_entry_absent": True, "business_actions_executed": False}, flush=True)
