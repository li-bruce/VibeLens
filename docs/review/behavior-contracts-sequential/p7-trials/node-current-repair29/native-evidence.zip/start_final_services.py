"""Leave the ordinary default npm launcher on actual data for independent main-session review."""
from datetime import datetime, timezone
import json
import os
import socket
import subprocess
import time
import urllib.request
from repair_tools import APP, PACK, RUN, ENV, load, save

post = load(RUN / "verify-after-browser.json")
ordinary = load(RUN / "ordinary-browser-recording-command.json")
audits = load(RUN / "runtime-audits-summary.json")
assert audits["completed"]
identity = load(RUN / "candidate-build.json")
assert identity["candidate_id"] == post["candidate_id"]
for port in (8925, 8926):
    with socket.socket() as probe:
        assert probe.connect_ex(("127.0.0.1", port)) != 0, port
out = RUN / "live"
out.mkdir(exist_ok=False)
command = [os.environ["ComSpec"], "/d", "/c", "npm", "run", "dev"]
assert "VIBELENS_SKILL" not in ENV and "BO_DIAGNOSTIC_SKILL" not in ENV
started = time.time()
startup = subprocess.STARTUPINFO()
startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow = subprocess.SW_HIDE
with (out / "npm-dev.stdout.log").open("xb") as stdout, (out / "npm-dev.stderr.log").open("xb") as stderr:
    child = subprocess.Popen(command, cwd=APP, env=ENV, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
        startupinfo=startup, close_fds=True,
        creationflags=subprocess.CREATE_NO_WINDOW | subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP)
save(out / "launcher-start.json", {"command": command, "root_pid": child.pid, "started_at": datetime.now(timezone.utc).isoformat(),
    "entry_provider_environment": {"VIBELENS_SKILL": None, "BO_DIAGNOSTIC_SKILL": None}})
pointer = APP / "review/runtime/provider-entrypoints/dev-latest.json"
deadline = time.monotonic() + 60
while time.monotonic() < deadline:
    if child.poll() is not None:
        raise RuntimeError("Ordinary npm dev exited before handoff: " + str(child.returncode))
    if pointer.exists() and pointer.stat().st_mtime >= started:
        try:
            value = load(load(pointer)["path"])
        except (OSError, json.JSONDecodeError):
            time.sleep(.2)
            continue
        if value["provider"] == str(PACK):
            break
    time.sleep(.2)
else:
    raise RuntimeError("No fresh ordinary npm dev receipt")
assert value["build_id"] == identity["build_id"]
assert value["selection"]["source"] == "integrations/provider.json"
assert value["selection"]["requested_skill"] is None and value["selection"]["requested_diagnostic_skill"] is None
save(out / "ordinary-npm-dev-receipt.json", value)
def get(url):
    with urllib.request.urlopen(url, timeout=35) as response:
        return __import__("json").load(response)
health = get("http://127.0.0.1:8925/api/bo/health")
view = get("http://127.0.0.1:8926/api/view")
records = get("http://127.0.0.1:8926/api/recordings")
assert view["binding_status"]["status"] == "current" and view["manifest"]["build_id"] == identity["build_id"]
assert records["active"] is None and health["errors"] == health["dropped"] == 0
success = ordinary["exit_code"] == 0 and post["valid"] and audits["all_required_passed"]
save(out / "services.json", {"candidate_id": identity["candidate_id"], "build_id": identity["build_id"],
    "root_pid": child.pid, "dev_launcher": value["launcher"], "app": value["app"], "viewer": value["viewer"],
    "app_url": "http://127.0.0.1:8925/", "graph_url": "http://127.0.0.1:8926/graph",
    "provider": str(PACK), "data_root": str(APP / "var"), "database": str(APP / "var/db/application.sqlite"),
    "commands": {"ordinary_launcher": command}, "entry_provider_environment_unset": True,
    "native_health": health, "binding_status": view["binding_status"], "initial_live_events": len(view.get("events", [])),
    "recording_active": None, "ordinary_acceptance_valid": success,
    "purpose": "Existing actual-data ordinary default services retained for independent main-session review; no accept."})
save(out / "native-health-at-start.json", health)
save(out / "recordings-at-start.json", records)
print({"services_running": True, "ordinary_npm_default": True, "app_pid": value["app"], "viewer_launcher_pid": value["viewer"],
       "build_id": identity["build_id"], "ordinary_acceptance_valid": success, "recording_active": None}, flush=True)
