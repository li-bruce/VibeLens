"""Replace operational provider choices, retaining historical run-specific analysis verbatim."""
from collections import Counter
import re
from repair_tools import APP, RUN, load, save

changed = []
for folder in ("integrations", "tests", "tooling"):
    for path in (APP / folder).glob("*"):
        if path.suffix not in (".mjs", ".py", ".cjs") or path.name in ("bo_provider.cjs", "bo_provider.py", "build_observer.cjs"):
            continue
        text = path.read_text(encoding="utf-8-sig")
        lines = text.splitlines()
        original = text
        if path.suffix == ".mjs":
            matched = False
            for number, line in enumerate(lines):
                if "process.env.VIBELENS_SKILL ||" in line:
                    name = re.search(r"const\s+(\w+)\s*=", line).group(1)
                    indent = line[:len(line) - len(line.lstrip())]
                    lines[number] = indent + "const " + name + " = bo_resolve_provider();"
                    matched = True
            if matched:
                relative = "./bo_provider.cjs" if folder == "integrations" else "../integrations/bo_provider.cjs"
                text = "import { bo_resolve_provider } from '" + relative + "';\n" + "\n".join(lines) + "\n"
        elif path.suffix == ".py":
            for number, line in enumerate(lines):
                selector = ("os.environ.get(\"VIBELENS_SKILL\"" in line or "os.environ['VIBELENS_SKILL']" in line
                            or "os.environ[\"VIBELENS_SKILL\"]" in line or "os.environ.get('BO_DIAGNOSTIC_SKILL'" in line)
                if selector and re.match(r"\s*(SKILL|skill)\s*=", line):
                    indent = line[:len(line) - len(line.lstrip())]
                    name = line.strip().split("=", 1)[0].strip()
                    lines[number] = (indent + "sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'integrations'))\n"
                        + indent + "from bo_provider import bo_resolve_provider\n"
                        + indent + name + " = bo_resolve_provider()")
            text = "\n".join(lines) + "\n"
            if path.name == "record_confirmation.py":
                text = text.replace("skill = Path(sys.argv[1])", "sys.path.insert(0, str(root / 'integrations'))\nfrom bo_provider import bo_resolve_provider\nskill = bo_resolve_provider()\nif len(sys.argv) > 1 and Path(sys.argv[1]).resolve() != skill:\n    raise ValueError('BO_PROVIDER_CONFLICT: legacy provider argument differs; use VIBELENS_SKILL consistently')")
        elif path.name == "document_callbacks.cjs":
            old = "const ts = require('../../node-migration-final-skills/vibelens/scripts/bo_observer/adapters/javascript/node_modules/typescript');"
            assert old in text
            text = text.replace(old, "const { bo_provider_file } = require('../integrations/bo_provider.cjs');\nconst ts = require(bo_provider_file('scripts/bo_observer/adapters/javascript/node_modules/typescript'));")
        if text != original:
            # Unchanged historical/source files must not receive newline-only edits.
            if text.replace("\r\n", "\n") == original.replace("\r\n", "\n"):
                continue
            path.write_text(text, encoding="utf-8", newline="\n")
            changed.append(path.relative_to(APP).as_posix())
before = load(RUN / "before-seal.json")
for filename in before["source_hashes"]:
    if filename.startswith("tests/"):
        old = (RUN / "before" / filename).read_text(encoding="utf-8").splitlines()
        current = (APP / filename).read_text(encoding="utf-8").splitlines()
        assert Counter(line.strip() for line in old if "assert" in line) == Counter(line.strip() for line in current if "assert" in line), filename
assert load(APP / "sync.json")["test_commands"] == before["test_commands"]
save(RUN / "entrypoint-source-update.json", {"changed_files": changed, "original_test_assertion_lines_preserved": True,
    "six_commands_unchanged": True, "historical_analysis_provider_unchanged": True})
print({"provider_entrypoints_updated": len(changed), "test_assertions_unchanged": True}, flush=True)
