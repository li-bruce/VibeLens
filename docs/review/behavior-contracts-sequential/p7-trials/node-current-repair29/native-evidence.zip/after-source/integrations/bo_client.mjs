import { BOProbe } from '/api/bo/native-runtime.mjs';
import { BOCaptureClient } from '/api/bo/native-capture.mjs';
import { TracerProvider } from '@opentelemetry/sdk-trace';
import { BOOpenTelemetry } from 'vibelens:otel';

let bo_probe = null, bo_capture = null;
try {
  const response = await fetch('/api/bo/config', { credentials: 'same-origin' });
  if (response.ok) {
    const settings = await response.json();
    bo_probe = new BOProbe(settings);
    const provider = new TracerProvider();
    bo_probe.bo_bind_tracing(new BOOpenTelemetry(provider.getTracer('team-files-browser')));
    bo_capture = await new BOCaptureClient(bo_probe).start();
  }
} catch (error) { console.warn('VibeLens browser initialization unavailable:', error.message); }

/** Observe the actual browser callback interval, selecting only public element identities. */
export function bo_start_ui(action, eventType, target) {
  if (!bo_probe) return null;
  const node = action === 'row-action' ? 'ui_row_action' : action === 'navigation' ? 'ui_navigation' : 'ui_callback';
  const span = bo_probe.startSpan(node, () => ({ inputs: { action, event_type: eventType, target } }), { scope: 'application' });
  return completed => span.finish(() => ({ outputs: { completed } }));
}
