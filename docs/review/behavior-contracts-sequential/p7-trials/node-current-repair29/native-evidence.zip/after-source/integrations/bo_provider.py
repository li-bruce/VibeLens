"""Resolve the same project-local observer choice as bo_provider.cjs, without loading it."""
from functools import lru_cache
import json
import os
from pathlib import Path

_BO_ROOT = Path(__file__).resolve().parents[1]

@lru_cache(maxsize=1)
def bo_resolve_provider() -> Path:
    """Resolve once per process; conflicting diagnostic aliases fail before any provider import."""
    config = json.loads((_BO_ROOT / "integrations/provider.json").read_text(encoding="utf-8-sig"))
    value = os.environ.get("VIBELENS_SKILL") or config["skill"]
    if not isinstance(value, str) or not value.strip():
        raise ValueError("BO_PROVIDER_PATH: expected an installed Skill directory")
    selected = (_BO_ROOT / value).resolve(strict=True)
    diagnostic = os.environ.get("BO_DIAGNOSTIC_SKILL")
    if diagnostic and os.path.normcase(str((_BO_ROOT / diagnostic).resolve(strict=True))) != os.path.normcase(str(selected)):
        raise ValueError("BO_PROVIDER_CONFLICT: BO_DIAGNOSTIC_SKILL differs from VIBELENS_SKILL or integrations/provider.json")
    if not (selected / "scripts/bo.py").is_file():
        raise ValueError("BO_PROVIDER_PATH: selected directory has no scripts/bo.py")
    return selected
