"""Incrementally synchronize the confirmed preparation-start change without rebuilding old captures."""
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'integrations'))
from bo_provider import bo_resolve_provider
SKILL = bo_resolve_provider()
sys.path.insert(0, str(SKILL / "scripts"))
from bo_observer.policy.projection import project as project_policy
from bo_observer.sources import scan as scan_source
from bo_observer.graph.code_structure import enrich
from implementation_coverage import functional_symbols

def read(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8-sig"))

def write(name, value):
    (ROOT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

doc = read("discovery.json")
envelope = read("bo_stategraph/project.json")
model = envelope["model"]
plan = read("implementation.json")
sync = read("sync.json")
old_nodes = {row["id"]: deepcopy(row) for row in model["nodes"]}
old_policy = model["policy"]
policy = deepcopy(doc["policy"])
policy["stage"] = "bound"
for predicate in policy["predicates"]:
    original = next(row for row in old_policy["predicates"] if row["id"] == predicate["id"])
    for key in ("source", "implementation_node"):
        if key in original:
            predicate[key] = deepcopy(original[key])
for operation in policy["operations"]:
    prior = next((row for row in old_policy["operations"] if row["id"] == operation["id"]), None)
    operation["cases"] = deepcopy(prior["cases"]) if prior else ["workflow", "start_denied"]
model["policy"] = policy
task = next(row for row in doc["state_models"] if row["id"] == "download_task")
machine = model["machines"]["download_task"]
machine["states"] = deepcopy(task["states"])
machine["values"] = deepcopy(task["states"])
machine["events"] = deepcopy(task["events"])
machine["guards"] = {key: {"source": {"path": "src/service.mjs", "symbol": "FileService.authorize"}} for key in task["guards"]}
machine["transitions"] = [{key: deepcopy(row[key]) for key in ("source", "dest", "trigger", "conditions") if key in row} for row in task["transitions"]]
if "native_state:download_task:cancelled" not in old_nodes:
    node = deepcopy(old_nodes["native_state:download_task:ready"])
    node.update(id="native_state:download_task:cancelled", value="cancelled", label="Preparation cancelled", summary="This queued task was cancelled by the preparation-start permission check.")
    model["nodes"].append(node)
if "guard_prepare_download" not in old_nodes:
    node = deepcopy(old_nodes["guard_request_download"])
    node.update(id="guard_prepare_download", policy_operation="prepare_download", label="May start preparation", summary="Actual current permission for this queued task's original requester and file.")
    model["nodes"].append(node)
next(node for node in model["nodes"] if node["id"] == "policy_facts")["capture"]["out"].update(policy["inputs"])
next(node for node in model["nodes"] if node["id"] == "prepare_download")["capture"]["out"]["cancel_reason"] = "string"
common_inputs = {"task_id": "string", "file_id": "string", "requester_id": "string", "transaction_id": "string"}
common_outputs = {"task_state": "string", "task_revision": "number", "native_run_id": "string", "native_sequence": "number", "grant_active": "boolean", "grant_revision": "number"}
for ident, label, outputs in [
    ("preparation_start_check", "Read permission at preparation start", {"authorized_at_submission": "boolean", "owner_id": "string", "grant_present": "boolean"}),
    ("preparation_start_commit", "Commit preparation start or cancellation", {"committed": "boolean", "before_state": "string", "before_revision": "number"}),
]:
    if ident not in old_nodes:
        model["nodes"].append({"id": ident, "kind": "function", "layer": "function", "label": label,
            "summary": "Observe the actual synchronous native task/grant read or completed transaction; native sequence is independent of observer arrival order.",
            "source": {"path": "src/service.mjs", "symbol": "FileService.drainWorker"}, "requirements": ["R_DOWNLOAD"],
            "capture": {"in": common_inputs, "out": {**common_outputs, **outputs}}})
model = project_policy(model)
for node in model["nodes"]:
    if node["id"] not in old_nodes:
        continue
    for direction, fields in old_nodes[node["id"]].get("capture", {}).items():
        assert all(node.get("capture", {}).get(direction, {}).get(name) == spec for name, spec in fields.items()), node["id"]
prepare = next(feature for feature in plan["features"] if feature["id"] == "prepare_download")
for phase in ("enter", "return"):
    record = {"case": "start_denied", "node": "prepare_download", "phase": phase}
    if record not in prepare["cases"]:
        prepare["cases"].append(record)
for ident, phase in (("preparation_start_check", "read"), ("preparation_start_commit", "change")):
    if ident not in prepare["nodes"]:
        prepare["nodes"].append(ident)
    for case in ("workflow", "start_denied"):
        record = {"case": case, "node": ident, "phase": phase}
        if record not in prepare["cases"]:
            prepare["cases"].append(record)
states = next(feature for feature in plan["features"] if feature["id"] == "state_download_task")
if "native_state:download_task:cancelled" not in states["nodes"]:
    states["nodes"].append("native_state:download_task:cancelled")
    states["cases"].append({"case": "start_denied", "node": "native_state:download_task:cancelled", "phase": "change"})
authorization = next(feature for feature in plan["features"] if feature["id"] == "native_authorization")
for node in model["nodes"]:
    if node["id"] == "guard_prepare_download" or node.get("origin") == "policy-definition" and any(node.get("capture", {}).values()):
        if node["id"] not in authorization["nodes"]:
            authorization["nodes"].append(node["id"])
            authorization["cases"].append({"case": "workflow", "node": node["id"], "phase": "decision"})

new_observer = "integrations/bo_order_witness.mjs"
if new_observer not in sync["code_files"]:
    sync["code_files"].append(new_observer)
for name in (new_observer, "tooling/sync_preparation_start.py", "tooling/native_order.py", "tests/queue-start.test.mjs", "tests/queue_start_scenario.mjs", "review/native-migration-fixture.json"):
    if name not in sync["watch_files"]:
        sync["watch_files"].append(name)
    if name not in model["source_files"]:
        model["source_files"].append(name)
new_test = ["node", "--test", "tests/queue-start.test.mjs"]
if new_test not in sync["test_commands"]:
    sync["test_commands"].append(new_test)
for name in ("tests/queue-start.test.mjs", "tests/queue_start_scenario.mjs"):
    sync["source_scope"]["exclude"][name] = "Independent controlled native/HTTP branch scenarios; application source remains fully inventoried and mapped."
if not any(row["path"] == "download-start-permission-20261121" for row in sync["source_scope"]["prune"]):
    sync["source_scope"]["prune"].append({"path": "download-start-permission-20261121", "category": "artifact", "reason": "Immutable change baseline and generated review/verification receipts; no application implementation."})
active_change = read(".stategraph/active.json")["change"]
baseline_index = read(active_change + "/baseline.json").get("structure")
index = scan_source(ROOT, sync["code_files"], baseline_index)
if index["errors"]:
    raise ValueError(index["errors"])
known_sources = {source for feature in plan["features"] for source in feature.get("sources", [])}
for ident, record in functional_symbols(index).items():
    if ident in known_sources or ident in plan["support"] or ident in plan["excluded"]:
        continue
    if record["path"] == new_observer:
        plan["excluded"][ident] = {"category": "observer", "reason": "Independent read-only native order/SQLite witness. Its queries are excluded with the canonical bo_internal interface; it never authorizes, schedules or mutates business state."}
    elif record["path"].startswith("integrations/"):
        plan["excluded"][ident] = {"category": "observer", "reason": "Project-owned observation callback or selected-value builder; no business authorization or mutation."}
    else:
        anchor = "prepare_download" if record["path"] == "src/service.mjs" else "policy_facts" if record["path"] == "src/policy.mjs" else "data_write" if record["path"] == "src/store.mjs" else "request_download" if record["path"] == "tests/native_reader.mjs" else "ui_callback"
        plan["support"][ident] = {"node": anchor, "reason": "Source-inventoried helper for the preparation-start increment. This static association does not claim that an unexecuted branch ran."}
model["implementation"] = plan
model["revision"] = "native-start-permission-2"
model["source_files"] = sorted(set(model["source_files"]))
envelope["model"] = model
envelope["contracts"]["discovery"]["sha256"] = hashlib.sha256((ROOT / "discovery.json").read_bytes()).hexdigest()
write("bo_stategraph/project.json", envelope)
write("implementation.json", plan)
write("sync.json", sync)
write("bo_stategraph/native-bindings.json", {"guards": {row["id"]: {key: value["decision"].split(":")[-1] for key, value in row["guards"].items()} for row in doc["state_models"]}})
mapping = read("mapping.json")
for case in ("start_denied", "controlled_start_permissions"):
    if case not in mapping["cases"]:
        mapping["cases"].append(case)
write("mapping.json", mapping)
for helper in ("bind_concepts.py", "bind_behavior.py"):
    subprocess.run([sys.executable, "-B", "-X", "utf8", str(ROOT / "tooling" / helper)], cwd=ROOT, check=True)
envelope = read("bo_stategraph/project.json")
envelope["model"] = enrich(envelope["model"], index)
# Canonical declaration edges settle after the generated static slice is
# reattached. Preserve the projector's own stable ordering for strict inspect.
envelope["model"] = enrich(envelope["model"], index)
assert enrich(envelope["model"], index) == envelope["model"]
current_nodes = {row["id"]: row for row in envelope["model"]["nodes"]}
for ident, prior in old_nodes.items():
    for direction, fields in prior.get("capture", {}).items():
        assert all(current_nodes.get(ident, {}).get("capture", {}).get(direction, {}).get(name) == spec for name, spec in fields.items()), ident
write("bo_stategraph/project.json", envelope)
print(json.dumps({"incremental_model_sync": True, "old_capture_fields_retained": True, "new_state": "cancelled", "new_boundary_nodes": 2, "new_qualified_read_facts": 5, "native_tests_run": False}))
