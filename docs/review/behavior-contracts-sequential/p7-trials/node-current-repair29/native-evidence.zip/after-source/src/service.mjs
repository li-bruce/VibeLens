import { randomUUID, randomBytes, createHash, scryptSync, timingSafeEqual } from 'node:crypto';
import { mkdir, writeFile, copyFile, readFile, rename, unlink } from 'node:fs/promises';
import path from 'node:path';
import { AsyncLocalStorage } from 'node:async_hooks';
import { decide } from './policy.mjs';
import { AnnouncementService } from './announcements.mjs';

/** A typed application error with a stable public code and actual HTTP outcome. */
export class AppError extends Error {
  /** Create a native error with its public HTTP status and stable code. */ constructor(status, code) { super(code); this.name = 'AppError'; this.status = status; this.code = code; }
}
/** Select public member fields; credentials and session identifiers remain private. */
export function publicUser(user) {
  return user ? { id: user.id, username: user.username, display_name: user.display_name, editor: Boolean(user.editor) } : null;
}
/** Hash a session token for lookup; never return its hash through observations.
 * @param {string} token Opaque current session cookie; observation selects only its presence.
 */
export function tokenHash(token) { return createHash('sha256').update(token || '').digest('hex'); }

/** Native business service; observation callbacks never authorize or execute operations. */
export class FileService {
  /** Initialize native storage, operation context and the single preparation worker. @param {Store} store Actual SQLite store. @param {string} root Local application data root. */
  constructor(store, root) {
    this.store = store; this.root = path.resolve(root);
    this.listeners = new Set(); this.context = new AsyncLocalStorage(); this.workerBusy = false; this.stopped = false;
    this.nativeRunId = randomUUID(); this.nativeSequence = 0;
    this.workerDelay = 20;
    this.announcementBoard = new AnnouncementService(this, AppError);
  }
  /** Subscribe to selected domain facts; subscriber failure is isolated. */
  subscribe(listener) { this.listeners.add(listener); return /** Detach only this optional fact subscriber. */ () => this.listeners.delete(listener); }
  /** Publish a fact already produced by native execution.
   * @param {object} event Fact already produced by a native operation, transition or transaction boundary.
   */
  notify(event) {
    const actual = { ...event, native_run_id: this.nativeRunId, native_sequence: ++this.nativeSequence };
    for (const listener of this.listeners) { try { listener(actual); } catch { /* Observation cannot change business execution. */ } }
  }
  /** Own the real native operation lifetime and return its actual outcome.
   * @param {string} name Stable name of the native business operation.
   * @param {object} inputs Selected public inputs for this operation; credentials and cookie values are omitted.
   * @param {Function} action Real native business callback receiving this invocation context.
   */
  async operation(name, inputs, action) {
    const invocationId = randomUUID(), candidateParent = this.context.getStore();
    const parent = candidateParent?.active ? candidateParent : null;
    const context = { invocationId, parentInvocationId: parent?.invocationId || null, name, active: true };
    this.notify({ ...context, phase: 'enter', inputs });
    try {
      let pending;
      const executeOnce = /** Cache one promise so an optional instrumentation failure cannot execute a mutation twice. */ () => pending || (pending = Promise.resolve().then(/** Start the native action within its asynchronous operation context. */ () => this.context.run(context, /** Publish native entry and invoke the real business action once. */ () => { this.notify({ ...context, phase: 'started' }); return action(context); })));
      let result;
      try { result = this.instrumentation?.around ? await this.instrumentation.around(context, executeOnce) : await executeOnce(); }
      catch (observationOrBusinessError) { if (!pending) result = await executeOnce(); else result = await pending; }
      context.active = false;
      this.notify({ ...context, phase: 'return', inputs, outputs: result?.observation || result || {} });
      return result;
    } catch (error) {
      context.active = false;
      this.notify({ ...context, phase: 'error', inputs, outputs: { error: error.code || 'INTERNAL_ERROR', http_status: error.status || 500 }, exception: error.name });
      throw error;
    }
  }
  /** Evaluate actual native policy and preserve its selected facts and short circuits.
   * @param {string} operation Native permission operation whose actual decision is being checked.
   * @param {object} facts Actual scalar authorization facts acquired for this operation; no credentials or cookie values.
   * @param {object} context Enclosing native operation context carrying its invocation identity.
   */
  authorize(operation, facts, context) {
    const decision = decide(operation, facts);
    context.native_decisions ||= {};
    context.native_decisions[operation] = decision.allowed;
    this.notify({ ...context, phase: 'policy', decision });
    if (!decision.allowed) throw new AppError(403, 'ACCESS_DENIED');
    return decision;
  }
  /** Publish the actual native row state at a completed storage boundary.
   * @param {string} model Native state-model identity: grant, download_task, announcement or session.
   * @param {string} id Model-qualified native instance identity.
   * @param {object} row Actual native allocation or stored row at the observed state boundary.
   * @param {?string} event Actual transition event, or null for an initial allocation read.
   * @param {object} context Enclosing native operation context carrying its invocation identity.
   * @param {?string} before State read before the native change, or null for initial allocation.
   */
  state(model, id, row, event, context, before = null) {
    this.notify({ ...context, phase: 'state', model, id, state: row.status, revision: row.revision, row, event, before });
  }
  /** Read the actual current user for an active session token.
   * @param {string} token Opaque current session cookie; observation selects only its presence.
   */
  session(token) {
    if (!token) return null;
    const row = this.store.get("SELECT s.trace_id,s.status,s.revision,u.* FROM sessions s JOIN users u ON s.user_id=u.id WHERE s.token_hash=? AND s.status='active'", tokenHash(token));
    return row || null;
  }
  /** Verify a real password and persist a new session. Passwords never enter selected facts.
   * @param {string} username Username submitted for real password authentication.
   * @param {string} password Submitted password; observation selects only whether it was supplied.
   */
  async login(username, password) {
    return this.operation('login', { username, password_supplied: Boolean(password) }, /** Verify the real password and persist a new native session. */ async context => {
      const user = this.store.get('SELECT * FROM users WHERE username=?', username);
      const actual = scryptSync(password || '', user?.password_salt || 'missing-user-salt', 32);
      const expected = user ? Buffer.from(user.password_hash, 'hex') : Buffer.alloc(32);
      const valid = Boolean(user) && timingSafeEqual(actual, expected);
      try { this.authorize('login', { credentials_valid: valid }, context); }
      catch { throw new AppError(401, 'INVALID_CREDENTIALS'); }
      const token = randomBytes(32).toString('hex'), id = randomUUID();
      this.state('session', id, { status: 'absent', revision: 0, user_id: user.id }, null, context);
      this.store.run("INSERT INTO sessions VALUES (?, ?, ?, 'active', 1, ?)", tokenHash(token), id, user.id, new Date().toISOString());
      this.state('session', id, { status: 'active', revision: 1, user_id: user.id }, 'login', context, 'absent');
      return { token, user: publicUser(user), observation: { allowed: true, user_id: user.id, editor: Boolean(user.editor), session_id: id } };
    });
  }
  /** End only the current session and retain its native nonsecret state identity.
   * @param {string} token Opaque current session cookie; observation selects only its presence.
   */
  async logout(token) {
    const actor = this.session(token);
    return this.operation('logout', { actor_id: actor?.id || '', token_present: Boolean(token) }, /** Authorize and persist the end of this current native session. */ async context => {
      this.authorize('logout', { member: Boolean(actor) }, context);
      this.store.run("UPDATE sessions SET status='ended',revision=revision+1 WHERE token_hash=?", tokenHash(token));
      this.state('session', actor.trace_id, { status: 'ended', revision: actor.revision + 1, user_id: actor.id }, 'logout', context, 'active');
      return { allowed: true, user_id: actor.id };
    });
  }
  /** Require a genuine active session for protected application operations.
   * @param {string} token Opaque current session cookie; observation selects only its presence.
   */
  requireActor(token) { const actor = this.session(token); if (!actor) throw new AppError(401, 'LOGIN_REQUIRED'); return actor; }
  /** Return public teammates for the uploader's named-recipient picker.
   * @param {object} actor Current authenticated native member; its id determines file/task ownership.
   */
  members(actor) { if (!actor) throw new AppError(401, 'LOGIN_REQUIRED'); return this.store.all('SELECT id,username,display_name,editor FROM users ORDER BY username').map(publicUser); }
  /** Acquire the current file and grant facts at the native authorization boundary.
   * @param {object} actor Current authenticated native member; its id determines file/task ownership.
   * @param {string} fileId Stored file identity whose current uploader and recipient grant are read.
   */
  fileFacts(actor, fileId) {
    const file = this.store.get('SELECT * FROM files WHERE id=?', fileId);
    if (!file) throw new AppError(404, 'FILE_NOT_FOUND');
    const grant = this.store.get('SELECT * FROM grants WHERE file_id=? AND recipient_id=?', fileId, actor.id);
    return { file, grant, facts: { member: true, actor: actor.id, owner: file.owner_id, recipient: actor.id, active: Boolean(grant?.active) } };
  }
  /** List only files the current colleague can see; do not expose hidden metadata.
   * @param {object} actor Current authenticated native member; its id determines file/task ownership.
   */
  async listFiles(actor) {
    return this.operation('list_files', { actor_id: actor.id }, /** Select native file rows visible to the current member. */ async context => {
      const rows = this.store.all('SELECT f.*,u.display_name AS owner_name FROM files f JOIN users u ON f.owner_id=u.id ORDER BY f.created_at DESC');
      const visible = [];
      for (const file of rows) {
        const { facts } = this.fileFacts(actor, file.id), decision = decide('view_file', facts);
        this.notify({ ...context, phase: 'policy', decision });
        if (decision.allowed) {
          const grants = file.owner_id === actor.id ? this.store.all('SELECT g.recipient_id,g.active,u.display_name FROM grants g JOIN users u ON u.id=g.recipient_id WHERE g.file_id=?', file.id) : [];
          visible.push({ id: file.id, name: file.name, size: file.size, sha256: file.sha256, owner_id: file.owner_id, owner_name: file.owner_name, created_at: file.created_at, mine: file.owner_id === actor.id, grants });
        }
      }
      return { files: visible, count: visible.length };
    });
  }
  /** Read one visible file without returning its private storage path.
   * @param {object} actor Current authenticated native member; its id determines file/task ownership.
   * @param {string} fileId Stored file identity whose current uploader and recipient grant are read.
   */
  async viewFile(actor, fileId) {
    return this.operation('view_file', { actor_id: actor.id, file_id: fileId }, /** Authorize current file access before returning selected metadata. */ async context => {
      const { file, facts } = this.fileFacts(actor, fileId); this.authorize('view_file', facts, context);
      return { id: file.id, name: file.name, size: file.size, owner_id: file.owner_id, allowed: true };
    });
  }
  /** Persist uploaded bytes under a generated filename and their actual metadata.
   * @param {object} actor Current authenticated native member; its id determines file/task ownership.
   * @param {string} name Original upload filename, bounded to 180 characters and kept separate from its storage name.
   * @param {Buffer} bytes Uploaded bytes, bounded to 50 MB by HTTP; only byte count is observed.
   */
  async upload(actor, name, bytes) {
    return this.operation('upload_file', { actor_id: actor.id, name, byte_count: bytes.length }, /** Authorize the member, write actual bytes and persist their metadata. */ async context => {
      this.authorize('upload', { member: true }, context);
      if (!name.trim() || name.length > 180) throw new AppError(400, 'INVALID_FILENAME');
      const id = randomUUID(), storagePath = path.join(this.root, 'uploads', id);
      await mkdir(path.dirname(storagePath), { recursive: true });
      await writeFile(storagePath, bytes, { flag: 'wx' });
      const sha = createHash('sha256').update(bytes).digest('hex');
      try { this.store.run('INSERT INTO files(id,owner_id,name,size,sha256,storage_path,created_at) VALUES (?,?,?,?,?,?,?)', id, actor.id, name, bytes.length, sha, storagePath, new Date().toISOString()); }
      catch (error) { await unlink(storagePath).catch(/** Ignore cleanup failure while preserving the original upload-storage error. */ () => {}); throw error; }
      return { id, name, size: bytes.length, sha256: sha, owner_id: actor.id, allowed: true };
    });
  }
  /** Create or revoke one named grant; recipient role never permits this operation.
   * @param {object} actor Current authenticated native member; its id determines file/task ownership.
   * @param {string} fileId Stored file identity whose current uploader and recipient grant are read.
   * @param {string} recipientId Named colleague receiving or losing access to the selected file.
   * @param {boolean} active Requested grant state: true grants sharing; false revokes it.
   */
  async setGrant(actor, fileId, recipientId, active) {
    return this.operation(active ? 'share_file' : 'revoke_share', { actor_id: actor.id, file_id: fileId, recipient_id: recipientId, active }, /** Authorize uploader ownership and persist this recipient grant change. */ async context => {
      const { facts } = this.fileFacts(actor, fileId); this.authorize('manage_share', facts, context);
      if (!this.store.get('SELECT id FROM users WHERE id=?', recipientId) || recipientId === actor.id) throw new AppError(400, 'INVALID_RECIPIENT');
      const prior = this.store.get('SELECT * FROM grants WHERE file_id=? AND recipient_id=?', fileId, recipientId);
      const before = prior?.active ? 'active' : 'inactive', revision = (prior?.revision || 0) + 1;
      if (Boolean(prior?.active) === active) return { file_id: fileId, recipient_id: recipientId, active, revision: prior?.revision || 0, unchanged: true, allowed: true };
      if (!prior) this.state('grant', fileId + '/' + recipientId, { status: 'inactive', revision: 0 }, null, context);
      this.store.run('INSERT INTO grants(file_id,recipient_id,active,revision) VALUES(?,?,?,?) ON CONFLICT(file_id,recipient_id) DO UPDATE SET active=excluded.active,revision=excluded.revision', fileId, recipientId, Number(active), revision);
      this.state('grant', fileId + '/' + recipientId, { status: active ? 'active' : 'inactive', revision }, active ? 'share' : 'revoke', context, before);
      return { file_id: fileId, recipient_id: recipientId, active, revision, allowed: true };
    });
  }
  /** Atomically admit one task using current file access and persist that task's authorization.
   * @param {object} actor Current authenticated native member; its id determines file/task ownership.
   * @param {string} fileId Stored file identity whose current uploader and recipient grant are read.
   */
  async requestDownload(actor, fileId) {
    const result = await this.operation('request_download', { actor_id: actor.id, file_id: fileId }, /** Admit the task through an actual native transaction and schedule preparation after commit. */ async context => {
      const id = randomUUID(), transactionId = randomUUID();
      this.notify({ ...context, phase: 'transaction_enter', transaction_id: transactionId, task_id: id });
      try { this.store.transaction(/** Authorize current file access and commit the task with its original requester and saved authorization. */ () => {
        const { facts } = this.fileFacts(actor, fileId); this.authorize('request_download', facts, context);
        this.state('download_task', id, { status: 'created', revision: 0, authorized_at_submission: false, requester_id: actor.id, file_id: fileId }, null, context);
        this.store.run("INSERT INTO tasks(id,file_id,requester_id,authorized_at_submission,status,created_at) VALUES(?,?,?,1,'queued',?)", id, fileId, actor.id, new Date().toISOString());
      }); } catch (error) {
        this.notify({ ...context, phase: 'rollback', transaction_id: transactionId, task_id: id, committed: false, error: error.code || 'TRANSACTION_ERROR', error_type:error.name });
        throw error;
      }
      const row = this.store.get('SELECT * FROM tasks WHERE id=?', id);
      this.notify({ ...context, phase: 'commit', transaction_id: transactionId, task_id: id, committed: true, authorized_at_submission: true });
      this.state('download_task', id, row, 'enqueue', context, 'created');
      return { task_id: id, file_id: fileId, requester_id: actor.id, status: row.status, authorized_at_submission: true, transaction_id: transactionId, committed: true, allowed: true };
    });
    this.scheduleWorker(); return result;
  }
  /** List this requester's own task records independently of current file visibility.
   * @param {object} actor Current authenticated native member; its id determines file/task ownership.
   */
  async listTasks(actor) {
    return this.operation('list_tasks', { actor_id: actor.id }, /** Read only tasks belonging to the authenticated requester. */ async () => ({
      tasks: this.store.all('SELECT t.id,t.file_id,t.requester_id,t.authorized_at_submission,t.status,t.sha256,t.last_error,t.created_at,t.started_at,t.ready_at,t.revision,f.name,f.size FROM tasks t JOIN files f ON f.id=t.file_id WHERE t.requester_id=? ORDER BY t.created_at DESC', actor.id)
    }));
  }
  /** Schedule real preparation after request completion; current access is checked when the worker starts each queued task. */
  scheduleWorker() {
    if (!this.workerBusy && !this.stopped) {
      this.workerBusy = true;
      this.workerTimer = setTimeout(/** Start the real preparation worker after the queued admission has returned. */ () => { this.workerRunning = this.drainWorker().finally(/** Clear the active worker promise when native preparation settles. */ () => { this.workerBusy = false; if (!this.stopped && this.store.get("SELECT id FROM tasks WHERE status='queued'")) this.scheduleWorker(); }); }, this.workerDelay);
    }
  }
  /** Check current requester access atomically at start, then prepare or cancel that queued task. */
  async drainWorker() {
    while (!this.stopped) {
      const row = this.store.get("SELECT * FROM tasks WHERE status='queued' ORDER BY created_at,id LIMIT 1");
      if (!row) break;
      try {
        await this.operation('prepare_download', { task_id: row.id, requester_id: row.requester_id, file_id: row.file_id }, /** Move the stored queued task into preparation and verify its real copied artifact. */ async context => {
          const transactionId = randomUUID();
          let current, started, facts, grant, fileOwner;
          this.store.transaction(/** Read the current grant and commit this task's start or cancellation without an intervening worker step. */ () => {
            current = this.store.get('SELECT * FROM tasks WHERE id=?', row.id);
            if (current.status !== 'queued') return;
            const file = this.store.get('SELECT owner_id FROM files WHERE id=?', current.file_id);
            grant = this.store.get('SELECT recipient_id,active,revision FROM grants WHERE file_id=? AND recipient_id=?', current.file_id, current.requester_id);
            fileOwner = file.owner_id;
            facts = { preparation_requester: current.requester_id, preparation_owner: file.owner_id, preparation_recipient: current.requester_id,
              preparation_active: Boolean(grant?.active), preparation_task_state: current.status };
            this.notify({ ...context, phase: 'preparation_check', task_id: current.id, file_id: current.file_id, requester_id: current.requester_id,
              transaction_id: transactionId, task_state: current.status, task_revision: current.revision,
              authorized_at_submission: Boolean(current.authorized_at_submission), owner_id: file.owner_id,
              grant_present: Boolean(grant), grant_active: Boolean(grant?.active), grant_revision: grant?.revision });
            let allowed = false;
            try { allowed = this.authorize('prepare_download', facts, context).allowed; }
            catch (error) { if (!(error instanceof AppError) || error.code !== 'ACCESS_DENIED') throw error; }
            this.store.run('UPDATE tasks SET status=?,started_at=?,last_error=?,revision=revision+1 WHERE id=?',
              allowed ? 'preparing' : 'cancelled', allowed ? new Date().toISOString() : null,
              allowed ? null : grant && !grant.active ? 'SHARING_REVOKED' : 'PREPARATION_ACCESS_DENIED', current.id);
            started = this.store.get('SELECT * FROM tasks WHERE id=?', current.id);
          });
          if (!started) return { task_id: row.id, status: current.status, allowed: false, skipped: true };
          this.notify({ ...context, phase: 'preparation_commit', transaction_id: transactionId, committed: true,
            task_id: started.id, file_id: started.file_id, requester_id: started.requester_id,
            before_state: current.status, before_revision: current.revision, task_state: started.status, task_revision: started.revision,
            owner_id: fileOwner, grant_active: facts.preparation_active, grant_revision: grant?.revision });
          this.state('download_task', row.id, started, started.status === 'cancelled' ? 'cancel' : 'start', context, 'queued');
          if (started.status === 'cancelled') return { task_id: started.id, status: started.status, allowed: false, cancel_reason: started.last_error };
          const file = this.store.get('SELECT * FROM files WHERE id=?', row.file_id);
          const target = path.join(this.root, 'prepared', row.id), temporary = target + '.part';
          await mkdir(path.dirname(target), { recursive: true }); await copyFile(file.storage_path, temporary);
          const actual = createHash('sha256').update(await readFile(temporary)).digest('hex');
          if (actual !== file.sha256) throw new AppError(500, 'PREPARATION_CHECKSUM_MISMATCH');
          await rename(temporary, target);
          return await this.operation('mark_download_ready', { task_id: row.id }, /** Persist ready only after the actual prepared artifact has passed its checksum check. */ async done => {
            this.store.run("UPDATE tasks SET status='ready',prepared_path=?,sha256=?,ready_at=?,last_error=NULL,revision=revision+1 WHERE id=?", target, actual, new Date().toISOString(), row.id);
            const ready = this.store.get('SELECT * FROM tasks WHERE id=?', row.id);
            this.state('download_task', row.id, ready, 'finish', done, 'preparing');
            return { task_id: row.id, status: 'ready', sha256: actual, allowed: true };
          });
        });
      } catch (error) {
        this.store.run('UPDATE tasks SET last_error=? WHERE id=?', error.code || 'PREPARATION_ERROR', row.id);
        this.notify({ name: 'worker_error', phase: 'diagnostic', task_id: row.id, error: error.code || 'PREPARATION_ERROR' });
      }
    }
  }
  /** Recheck requester/session/readiness, using persisted submission authorization instead of current grants.
   * @param {object} actor Current authenticated native member; its id determines file/task ownership.
   * @param {string} taskId Identity of an already submitted download preparation task.
   */
  async collect(actor, taskId) {
    return this.operation('collect_download', { actor_id: actor.id, task_id: taskId }, /** Authorize the original requester and read the actual prepared bytes without consuming the task. */ async context => {
      const row = this.store.get('SELECT t.*,f.name,f.size FROM tasks t JOIN files f ON f.id=t.file_id WHERE t.id=?', taskId);
      if (!row) throw new AppError(404, 'TASK_NOT_FOUND');
      this.authorize('collect_download', { member: true, actor: actor.id, requester: row.requester_id, submission_authorized: Boolean(row.authorized_at_submission), task_state: row.status }, context);
      const bytes = await readFile(row.prepared_path);
      return { bytes, name: row.name, observation: { task_id: row.id, requester_id: row.requester_id, status: row.status, byte_count: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex'), allowed: true } };
    });
  }
  /** Delegate authenticated board reads to the independent announcement service.
   * @param {object} actor Current authenticated native member.
   */
  async announcements(actor) { return this.announcementBoard.announcements(actor); }
  /** Delegate publication without changing the public method or editor rule.
   * @param {object} actor Current authenticated native member.
   * @param {string} title Announcement title, bounded to 120 characters.
   * @param {string} body Announcement content, bounded to 8000 characters.
   */
  async publish(actor, title, body) { return this.announcementBoard.publish(actor, title, body); }
  /** Delegate the selected own-announcement mutation without changing its arguments.
   * @param {object} actor Current authenticated native member.
   * @param {string} id Identity of the selected announcement.
   * @param {string} action Selected mutation: edit or delete.
   * @param {string} title Announcement title, bounded to 120 characters.
   * @param {string} body Announcement content, bounded to 8000 characters.
   */
  async mutateAnnouncement(actor, id, action, title = '', body = '') { return this.announcementBoard.mutateAnnouncement(actor, id, action, title, body); }
  /** Delegate the original announcement input bounds.
   * @param {string} title Announcement title, bounded to 120 characters.
   * @param {string} body Announcement content, bounded to 8000 characters.
   */
  validateAnnouncement(title, body) { return this.announcementBoard.validateAnnouncement(title, body); }
  /** Stop task scheduling before closing native storage. */
  async stop() { this.stopped = true; clearTimeout(this.workerTimer); while (this.workerBusy && this.workerRunning) await this.workerRunning; }
}
