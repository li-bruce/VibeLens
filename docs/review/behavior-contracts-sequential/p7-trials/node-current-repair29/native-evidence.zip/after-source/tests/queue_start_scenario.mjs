import { bo_resolve_provider } from '../integrations/bo_provider.cjs';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { Store, TEST_PASSWORD } from '../src/store.mjs';
import { FileService } from '../src/service.mjs';
import { bo_create } from '../integrations/bo_observe.mjs';
import { nativeAuditor, readInstances } from './native_reader.mjs';
import { pathToFileURL } from 'node:url';

const ROOT = path.resolve('.');
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const selectedSkill = bo_resolve_provider();
const { bo_internal } = await import(pathToFileURL(path.join(selectedSkill, 'scripts/bo_observer/adapters/javascript/bo_data.mjs')).href);

/** Establish real native grant/worker boundaries and retain each executed branch independently. */
export async function queueStartScenario(mode, scope = 'start_denied') {
  const settings = JSON.parse(await readFile(path.join(ROOT, 'review/native-test-settings.json'), 'utf8'));
  const project = JSON.parse(await readFile(path.join(ROOT, 'bo_stategraph/project.json'), 'utf8'));
  const root = await mkdtemp(path.join(ROOT, 'review/runtime/queue-start-' + mode + '-'));
  const store = new Store(path.join(root, 'db/application.sqlite')), service = new FileService(store, root);
  service.workerDelay = 60000; // Retain the existing controlled fixture's explicit worker ownership.
  const events = [], snapshots = [], frames = [];
  const observer = await bo_create(service, ROOT, { project, buildId: settings.build_id, policyHash: settings.policy_hash,
    enabled: mode !== 'off', capacity: 4096, sink: async (body, kind) => {
      if (mode === 'fault') throw new Error('Deliberate local observer sink outage');
      (kind === 'events' ? events : snapshots).push(body); frames.push({ kind, body });
    } });
  const auditor = nativeAuditor(service, settings.build_id);
  const selection = { grant: [], download_task: [], announcement: [], session: [] };
  const observations = {}, cases = [];
  const payload = Buffer.from('Controlled preparation-start permission fixture.\n');
  const expectedSha = hash(payload);
  const actors = {};
  /** Release only the already controlled real worker after all prerequisite native transactions completed. */
  const drain = async () => { clearTimeout(service.workerTimer); service.workerBusy = false; await service.drainWorker(); };
  /** Read one actual stored task without calling a graph or policy projector. */
  const task = id => bo_internal(() => store.get('SELECT * FROM tasks WHERE id=?', id));
  /** Select the independent pre-state read, not the task's later status, as the start oracle. */
  const checkpoint = id => observer.orderWitness.records.filter(row => row.phase === 'preparation_check' && row.task_id === id);
  try {
    for (const name of ['alice', 'bob', 'editor']) {
      const session = await service.login(name, TEST_PASSWORD);
      actors[name] = service.session(session.token); selection.session.push(session.observation.session_id);
    }
    const file = await service.upload(actors.alice, 'start-permission.txt', payload);
    await service.setGrant(actors.alice, file.id, 'bob', true); selection.grant.push(file.id + '/bob');
    const submitted = await service.requestDownload(actors.bob, file.id); selection.download_task.push(submitted.task_id);
    assert.equal(task(submitted.task_id).status, 'queued');
    await service.setGrant(actors.alice, file.id, 'bob', false);
    assert.equal(task(submitted.task_id).status, 'queued');
    assert.equal(bo_internal(() => store.get('SELECT active FROM grants WHERE file_id=? AND recipient_id=?', file.id, 'bob')).active, 0);
    await drain();
    const checks = checkpoint(submitted.task_id); assert.equal(checks.length, 1);
    const pre = checks[0];
    assert.equal(pre.task.status, 'queued'); assert.equal(pre.task.revision, 1);
    assert.equal(pre.task.authorized_at_submission, 1); assert.equal(pre.task.requester_id, 'bob');
    assert.equal(pre.file.owner_id, 'alice'); assert.equal(pre.grant.active, 0);
    const expectedAllowed = pre.task.status === 'queued' && (pre.task.requester_id === pre.file.owner_id || Boolean(pre.grant?.active));
    assert.equal(expectedAllowed, false);
    const cancelled = task(submitted.task_id);
    assert.equal(cancelled.status, 'cancelled'); assert.equal(cancelled.revision, 2);
    assert.equal(cancelled.authorized_at_submission, 1); assert.equal(cancelled.last_error, 'SHARING_REVOKED');
    assert.equal(cancelled.started_at, null); assert.equal(cancelled.prepared_path, null); assert.equal(cancelled.sha256, null);
    await assert.rejects(service.collect(actors.bob, submitted.task_id), error => error.status === 403);
    observations.start_denied = { status: cancelled.status, authorization_preserved: true, artifact_absent: true };
    cases.push({ id: 'start_denied', task_id: submitted.task_id, pre_start_witness: pre,
      expected_from_independent_pre_state: 'cancelled', actual_status: cancelled.status,
      completion: observer.orderWitness.records.find(row => row.phase === 'preparation_commit' && row.task_id === submitted.task_id) });
    if (scope === 'all') {
      await service.setGrant(actors.alice, file.id, 'bob', true);
      const before = task(submitted.task_id), beforeCount = checkpoint(submitted.task_id).length;
      await drain();
      assert.deepEqual(task(submitted.task_id), before); assert.equal(checkpoint(submitted.task_id).length, beforeCount);
      observations.cancelled_after_reshare = { unchanged: true };
      cases.push({ id: 'cancelled_no_revival', task_id: submitted.task_id, stored_before: before, stored_after: task(submitted.task_id), new_start_checks: 0 });
      const replacement = await service.requestDownload(actors.bob, file.id); selection.download_task.push(replacement.task_id);
      assert.notEqual(replacement.task_id, submitted.task_id); await drain();
      assert.equal(task(replacement.task_id).status, 'ready');
      assert.deepEqual((await service.collect(actors.bob, replacement.task_id)).bytes, payload);
      const restoredTask = await service.requestDownload(actors.bob, file.id); selection.download_task.push(restoredTask.task_id);
      await service.setGrant(actors.alice, file.id, 'bob', false);
      assert.equal(task(restoredTask.task_id).status, 'queued');
      await service.setGrant(actors.alice, file.id, 'bob', true);
      assert.equal(task(restoredTask.task_id).status, 'queued');
      await drain();
      const restoredPre = checkpoint(restoredTask.task_id); assert.equal(restoredPre.length, 1);
      assert.equal(restoredPre[0].grant.active, 1); assert.equal(restoredPre[0].task.status, 'queued');
      assert.equal(task(restoredTask.task_id).status, 'ready'); assert.equal(task(restoredTask.task_id).revision, 3);
      assert.equal(task(restoredTask.task_id).sha256, expectedSha);
      assert.deepEqual(await readFile(task(restoredTask.task_id).prepared_path), payload);
      observations.restored_before_start = { same_task_ready: true };
      cases.push({ id: 'restored_before_start', task_id: restoredTask.task_id, pre_start_witness: restoredPre[0], expected_from_independent_pre_state: 'ready', actual_status: task(restoredTask.task_id).status });

      const startedTask = await service.requestDownload(actors.bob, file.id); selection.download_task.push(startedTask.task_id);
      let revokePromise;
      const detach = service.subscribe(event => {
        if (event.phase === 'state' && event.model === 'download_task' && event.event === 'start' && event.id === startedTask.task_id) {
          detach();
          // The state notification follows the completed native start transaction.
          // Scheduling this real native grant operation occurs before the worker's
          // first filesystem await; no timer or observer control establishes order.
          revokePromise = service.setGrant(actors.alice, file.id, 'bob', false);
        }
      });
      await drain(); await revokePromise; detach();
      assert.ok(revokePromise, 'The real preparing boundary was not reached');
      const ordered = observer.orderWitness.records;
      const start = ordered.find(row => row.phase === 'preparation_commit' && row.task_id === startedTask.task_id);
      const revoke = ordered.find(row => row.phase === 'state' && row.model === 'grant' && row.event === 'revoke' && row.native_sequence > start.native_sequence);
      const finish = ordered.find(row => row.phase === 'state' && row.event === 'finish' && row.task_id === startedTask.task_id);
      assert.equal(start.task.status, 'preparing');
      assert.equal(revoke.tasks_at_grant.find(row => row.id === startedTask.task_id).status, 'preparing');
      assert.ok(start.native_sequence < revoke.native_sequence && revoke.native_sequence < finish.native_sequence);
      for (let repeat = 0; repeat < 2; repeat++) assert.deepEqual((await service.collect(actors.bob, startedTask.task_id)).bytes, payload);
      observations.started_then_revoked = { ready: task(startedTask.task_id).status === 'ready', repeat_bytes_match: true };
      cases.push({ id: 'started_before_revoke', task_id: startedTask.task_id, start, revoke, finish, explicit_native_order: [start.native_sequence, revoke.native_sequence, finish.native_sequence] });

      await service.setGrant(actors.alice, file.id, 'editor', true); selection.grant.push(file.id + '/editor');
      const own = await service.requestDownload(actors.alice, file.id), other = await service.requestDownload(actors.editor, file.id);
      selection.download_task.push(own.task_id, other.task_id); await drain();
      assert.equal(task(own.task_id).status, 'ready'); assert.equal(task(other.task_id).status, 'ready');
      assert.deepEqual(await readFile(task(own.task_id).prepared_path), payload);
      assert.deepEqual(await readFile(task(other.task_id).prepared_path), payload);
      await assert.rejects(service.collect(actors.editor, startedTask.task_id), error => error.status === 403);
      await assert.rejects(service.collect(actors.alice, startedTask.task_id), error => error.status === 403);
      observations.independent_owner_and_recipient = { ready: true, cross_requester_collection_denied: true };
      cases.push({ id: 'owner_and_other_recipient', tasks: [own.task_id, other.task_id], independent_pre_states: [checkpoint(own.task_id)[0], checkpoint(other.task_id)[0]] });
    }
    const beforeRead = observer.probe.bo_health().enqueued;
    const authority = readInstances(store, settings.build_id, selection);
    const afterRead = observer.probe.bo_health().enqueued;
    assert.equal(afterRead, beforeRead); assert.deepEqual(auditor.errors, []); assert.deepEqual(observer.orderWitness.failures, []);
    await observer.probe.flush(20000);
    const health = observer.health(); assert.equal(health.pending, 0); assert.equal(health.dropped, 0); assert.equal(health.tracing.open_spans, 0);
    if (mode === 'on') assert.equal(health.errors, 0);
    if (mode === 'off') assert.equal(events.length, 0);
    if (mode === 'fault') assert.ok(health.errors > 0);
    const result = { case: scope === 'start_denied' ? 'start_denied' : 'controlled_start_permissions', mode,
      scope: 'Controlled native boundaries and completed transactions, not ordinary browser scheduling',
      build_id: settings.build_id, native_database: store.filename, native_order_file: observer.orderWitness.filename,
      observations, controlled_cases: cases, events, snapshots, frames, policy_evaluations: observer.evaluations,
      authority_snapshot: authority, observer_query_exclusion: { before: beforeRead, after: afterRead, emitted: afterRead - beforeRead },
      probe_health: health, native_sdk: auditor.sdk, native_states: auditor.stateValues, native_completions: auditor.completions,
      fact_basis: auditor.factBasis, native_order: observer.orderWitness.records };
    await writeFile(path.join(root, 'result.json'), JSON.stringify(result, null, 2), { flag: 'wx' });
    return result;
  } catch (error) {
    await writeFile(path.join(root, 'failure.json'), JSON.stringify({ error: error.stack, cases, events, snapshots, native_order: observer.orderWitness.records, native_sdk: auditor.sdk }, null, 2), { flag: 'wx' });
    throw error;
  } finally { auditor.close(); await service.stop(); await observer.close(); store.close(); }
}
