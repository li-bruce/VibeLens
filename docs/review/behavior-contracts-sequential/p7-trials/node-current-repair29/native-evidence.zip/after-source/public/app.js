'use strict';
import { createAnnouncementBoard } from './announcements.js';
const bo_ui = await import('/api/bo/client.mjs').catch(/** Allow the workspace to start when the optional observer client is unavailable. */ error => { console.warn('VibeLens browser module unavailable:', error.message); return {}; });
const state = { user: null, view: 'files', members: [], files: [], editId: null, shareFile: null, sessionEpoch: 0, ready: false };
const requestOrder = { files: 0, tasks: 0, board: 0 };
const obsoleteResponse = new Error('Obsolete interface response');
const $ = /** Find one application element by its stable DOM ID. */ id => document.getElementById(id);
const errors = {
  INVALID_CREDENTIALS: '用户名或密码不正确。', LOGIN_REQUIRED: '登录已失效，请重新登录。',
  ACCESS_DENIED: '你当前没有执行这项操作的权限。', FILE_NOT_FOUND: '文件不存在。',
  INVALID_RECIPIENT: '请选择其他团队成员。', UPLOAD_TOO_LARGE: '文件超过 50 MB，请选择较小的文件。',
  FILE_BYTES_REQUIRED: '请选择需要上传的文件。', INVALID_FILENAME: '文件名不能为空，且不能超过 180 个字符。',
  INVALID_ANNOUNCEMENT: '公告需要标题和内容，请检查长度。', TASK_NOT_FOUND: '下载任务不存在。',
  ORIGIN_REJECTED: '请求来源不匹配，请从当前应用页面操作。'
};

/** Discard UI work from an older local session or list request.
 * @param {number} epoch Local authentication attempt that started this work.
 * @param {?object} request Optional list request identity within that session.
 */
function checkCurrent(epoch, request = null) {
  if (epoch !== state.sessionEpoch || (request && request.id !== requestOrder[request.view])) throw obsoleteResponse;
}
/** Allocate an ordered read for one current account list.
 * @param {string} view Files, tasks or board list being refreshed.
 * @param {number} epoch Local authentication attempt that owns this read.
 */
function beginRefresh(view, epoch) { checkCurrent(epoch); return { view, id: ++requestOrder[view] }; }
/** Call the authenticated API and apply rejection feedback only to its current UI.
 * @param {string} url Same-origin native endpoint.
 * @param {object} options Native fetch method, headers and body.
 * @param {number} epoch Local authentication attempt that owns this request.
 * @param {?object} request Optional ordered list request identity.
 */
async function api(url, options = {}, epoch = state.sessionEpoch, request = null) {
  checkCurrent(epoch, request);
  const response = await fetch(url, { credentials: 'same-origin', ...options });
  checkCurrent(epoch, request);
  const body = response.status === 204 ? null : await response.json().catch(/** Retain a public fallback for non-JSON error responses. @param {Error} error Native response parsing failure. */ error => { if (response.ok) throw error; return { error: 'INTERNAL_ERROR' }; });
  checkCurrent(epoch, request);
  if (!response.ok) {
    const message = errors[body.error] || '操作未完成，请刷新后重试。';
    if (response.status === 401) showLogin(message);
    throw new Error(message);
  }
  return body;
}
/** Build JSON request options without using inline scripts or user-authored HTML. */
function jsonRequest(method, value) { return { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(value) }; }
/** Create a safe text node element. */
function element(tag, text = '', className = '') {
  const node = document.createElement(tag); node.textContent = text; if (className) node.className = className; return node;
}
/** Display a meaningful result without hiding the current page. */
function notice(message, failure = false) { $('notice').textContent = message; $('notice').className = 'notice' + (failure ? ' failure' : ''); $('notice').hidden = false; }
/** Remove account-owned data and feedback before another session may be displayed.
 * @param {boolean} preserveLoginInput Keep initial login input while bootstrap is still deciding the session.
 */
function clearAccountUI(preserveLoginInput = false) {
  state.user = null; state.members = []; state.files = []; state.editId = null; state.shareFile = null; state.ready = false;
  $('workspace').hidden = true; $('login-screen').hidden = false;
  for (const id of ['file-list', 'task-list', 'announcement-list', 'share-recipient']) $(id).replaceChildren();
  for (const id of ['display-name', 'avatar', 'role-label', 'share-filename', 'upload-status', 'login-error']) $(id).textContent = '';
  $('file-count').textContent = '0 个文件'; $('notice').hidden = true; $('notice').textContent = '';
  if ($('share-dialog').open) $('share-dialog').close();
  $('upload-form').reset(); $('share-form').reset(); resetEditor();
  $('chosen-file').textContent = '单个文件最多 50 MB'; if (!preserveLoginInput) $('password').value = ''; $('announcement-form').hidden = true;
  for (const id of ['login-form', 'upload-form', 'share-form', 'announcement-form']) {
    for (const button of $(id).querySelectorAll('button')) button.disabled = false;
  }
  $('logout').disabled = false;
}
/** Invalidate every prior UI continuation, including a previous login as the same user.
 * @param {boolean} preserveLoginInput Keep initial form input only for bootstrap; explicit session changes still clear it.
 */
function beginSession(preserveLoginInput = false) { state.sessionEpoch++; clearAccountUI(preserveLoginInput); return state.sessionEpoch; }
/** Restore an empty login screen after logout, expiration or initialization failure.
 * @param {string} message Current-session public error to display on the login screen.
 */
function showLogin(message = '') { beginSession(); $('login-error').textContent = message; }
/** Format file sizes for compact list rows. */
function size(value) { return value < 1024 ? value + ' B' : value < 1048576 ? (value / 1024).toFixed(1) + ' KB' : (value / 1048576).toFixed(1) + ' MB'; }
/** Format native UTC timestamps in the browser's local timezone. */
function time(value) { return new Date(value).toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }); }
/** Run one action and retain visible error feedback. */
async function perform(operation, button = null) {
  const epoch = state.sessionEpoch;
  if (button) button.disabled = true;
  try { await operation(); } catch (error) { if (error !== obsoleteResponse && epoch === state.sessionEpoch) notice(error.message, true); }
  finally { if (button && epoch === state.sessionEpoch) button.disabled = false; }
}
/** Build a native button whose action remains explicitly associated with its row. */
function action(text, callback, className = 'secondary') {
  const button = element('button', text, className); button.type = 'button';
  /** Execute the actual row-button callback. @param {Event} event Native click event. */
  function rowActionHandler(event) { return dispatchUi('row-action', event, /** Run the selected row action with visible error feedback. */ () => perform(/** Invoke this row action with the button that initiated it. */ () => callback(button), button)); }
  button.addEventListener('click', rowActionHandler); return button;
}
/** Run the real UI callback while isolating optional observer failures. */
async function dispatchUi(id, event, callback) {
  let finish; try { finish = bo_ui.bo_start_ui?.(id, event.type, event.target.id || ''); } catch { /* Observation only. */ }
  try { const result = await callback(event); try { finish?.(true); } catch { /* Observation only. */ } return result; }
  catch (error) { try { finish?.(false); } catch { /* Observation only. */ } throw error; }
}
/** Register a native element callback with its public element identity. */
function bind(id, type, callback) {
  /** Execute the actual bound form/control callback. @param {Event} event Native DOM event. */
  function uiCallback(event) { return dispatchUi(id, event, callback); }
  $(id).addEventListener(type, uiCallback);
  /** Detach only this native callback when its owning bootstrap operation finishes. */
  function unbind() { $(id).removeEventListener(type, uiCallback); }
  return unbind;
}
/** Open the actual selected view. @param {Event} event Native navigation click. */
function navigationHandler(event) {
  const view = event.currentTarget.dataset.view;
  return dispatchUi('navigation', event, /** Apply the clicked navigation choice with visible error feedback. */ () => perform(/** Load the view selected by the native navigation button. */ () => selectView(view)));
}
/** Display the authenticated account only after its initial data has loaded.
 * @param {object} user Current user returned by the native session endpoint.
 * @param {number} epoch Authentication attempt that owns this initialization.
 */
async function enter(user, epoch) {
  checkCurrent(epoch);
  state.user = user;
  $('display-name').textContent = user.display_name; $('avatar').textContent = user.display_name.slice(0, 1);
  $('role-label').textContent = user.editor ? '团队成员 · 公告编辑员' : '团队成员';
  $('announcement-form').hidden = !user.editor;
  const data = await api('/api/members', {}, epoch); checkCurrent(epoch); state.members = data.members;
  await selectView(state.view, epoch); checkCurrent(epoch);
  state.ready = true; $('login-screen').hidden = true; $('workspace').hidden = false;
}
/** Keep independent files, download tasks and announcements in separate views.
 * @param {string} view Selected files, tasks or board view.
 * @param {number} epoch Local session that owns this navigation.
 */
async function selectView(view, epoch = state.sessionEpoch) {
  checkCurrent(epoch);
  state.view = view;
  for (const name of ['files', 'tasks', 'board']) $(name + '-view').hidden = name !== view;
  document.querySelectorAll('[data-view]').forEach(/** Highlight only the navigation button for the selected view. */ button => button.classList.toggle('active', button.dataset.view === view));
  $('breadcrumb').textContent = '团队空间 / ' + ({ files: '文件', tasks: '我的下载', board: '公告板' })[view];
  if (view === 'files') await refreshFiles(epoch); else if (view === 'tasks') await refreshTasks(epoch); else await refreshBoard(epoch);
}
/** Render the latest current-session server-authorized file list.
 * @param {number} epoch Local session that owns this list request.
 */
async function refreshFiles(epoch = state.sessionEpoch) {
  const request = beginRefresh('files', epoch);
  const data = await api('/api/files', {}, epoch, request); checkCurrent(epoch, request); state.files = data.files;
  $('file-count').textContent = data.count + ' 个文件'; $('file-list').replaceChildren();
  if (!data.files.length) {
    const empty = element('div', '', 'empty'); empty.append(element('strong', '文件柜还没有可访问的文件'), element('p', '上传一个文件，或请同事把文件分享给你。')); $('file-list').append(empty); return;
  }
  for (const file of data.files) {
    const row = element('article', '', 'file-row'), top = element('div', '', 'file-top'), info = element('div', '', 'file-info');
    top.append(element('span', file.name.split('.').at(-1).slice(0, 5).toUpperCase() || 'FILE', 'file-icon'));
    info.append(element('strong', file.name), element('div', size(file.size) + ' · ' + file.owner_name + ' 上传 · ' + time(file.created_at), 'file-meta'));
    top.append(info, element('span', file.mine ? '我上传的' : '同事共享', 'badge' + (file.mine ? '' : ' teal'))); row.append(top);
    const controls = element('div', '', 'file-actions');
    controls.append(action('准备下载', /** Submit a preparation task for this visible file. */ async () => { await api('/api/tasks', jsonRequest('POST', { file_id: file.id }), epoch); checkCurrent(epoch); notice('下载任务已提交。可在“我的下载”查看进度。'); }));
    if (file.mine) controls.append(action('分享给同事', /** Open the named-recipient dialog for this uploader-owned file. */ async () => { checkCurrent(epoch); openShare(file); }, 'quiet'));
    row.append(controls);
    const grants = element('div', '', 'grant-list');
    for (const grant of file.grants.filter(/** Render access chips only for currently active recipient grants. */ value => value.active)) {
      const chip = element('span', grant.display_name + ' 可访问', 'grant-chip');
      chip.append(action('撤销', /** Revoke this recipient grant through the API and refresh visible files. */ async () => { await api('/api/files/' + file.id + '/shares/' + grant.recipient_id, { method: 'DELETE' }, epoch); checkCurrent(epoch); notice('已撤销共享。排队任务开始准备前会检查权限；已开始准备的任务仍可完成和领取。'); await refreshFiles(epoch); }, 'quiet')); grants.append(chip);
    }
    if (grants.childElementCount) row.append(grants); $('file-list').append(row);
  }
}
/** Show the uploader's explicit named-recipient picker. */
function openShare(file) {
  state.shareFile = file; $('share-filename').textContent = file.name; $('share-recipient').replaceChildren();
  for (const member of state.members.filter(/** Offer colleagues other than the current uploader as recipients. */ value => value.id !== state.user.id)) {
    const option = element('option', member.display_name + ' · ' + member.username); option.value = member.id; $('share-recipient').append(option);
  }
  $('share-dialog').showModal();
}
/** Render the latest requester task list without consuming ready tasks.
 * @param {number} epoch Local session that owns this list request.
 */
async function refreshTasks(epoch = state.sessionEpoch) {
  const request = beginRefresh('tasks', epoch);
  const data = await api('/api/tasks', {}, epoch, request); checkCurrent(epoch, request); $('task-list').replaceChildren();
  if (!data.tasks.length) { const empty = element('div', '', 'paper empty'); empty.append(element('strong', '还没有下载任务'), element('p', '在团队文件里选择“准备下载”，完成后到这里领取。')); $('task-list').append(empty); return; }
  for (const task of data.tasks) {
    const card = element('article', '', 'paper task-card'), head = element('div', '', 'task-heading'), title = element('div');
    title.append(element('strong', task.name), element('p', size(task.size) + ' · 提交于 ' + time(task.created_at), 'file-meta')); head.append(title);
    if (task.status === 'ready') {
      const link = element('a', '领取文件', 'primary'); link.href = '/api/tasks/' + task.id + '/download'; link.download = task.name; head.append(link);
    } else head.append(element('span', task.status === 'cancelled' ? (task.last_error === 'SHARING_REVOKED' ? '已取消：共享已撤销' : '准备已取消') : task.last_error ? '准备遇到错误' : task.status === 'queued' ? '正在排队' : '正在准备', 'badge'));
    card.append(head); const rail = element('div', '', 'stage-rail'), stages = ['queued', 'preparing', 'ready'];
    for (const [index, stage] of stages.entries()) rail.append(element('span', ['排队中', '准备中', '可重复领取'][index], 'stage' + (stages.indexOf(task.status) >= index ? ' done' : '')));
    card.append(rail);
    const meta = element('div', '任务 ' + task.id.slice(0, 8), 'task-meta'); meta.append(element('span', task.status === 'cancelled' ? '这一单已取消；恢复共享后请重新申请。' : '提交时已获准 · 开始准备前检查当前共享')); card.append(meta);
    if (task.last_error && task.status !== 'cancelled') card.append(element('p', '准备未完成：' + task.last_error, 'error')); $('task-list').append(card);
  }
}
const announcementBoard = createAnnouncementBoard({ state, $, api, jsonRequest, checkCurrent, beginRefresh, element, action, notice, time, perform });
/** Reset the independent board composition form through its module. */
function resetEditor() { return announcementBoard.resetEditor(); }
/** Refresh the independent board for the current guarded account.
 * @param {number} epoch Local authentication attempt owning this read.
 */
async function refreshBoard(epoch = state.sessionEpoch) { return announcementBoard.refreshBoard(epoch); }
/** Restore an existing real session on page load. */
async function boot() {
  const alreadyTyping = $('password').value.length > 0 || $('username').value !== $('username').defaultValue;
  const epoch = beginSession(true);
  if (alreadyTyping) return;
  /** Give actual credential input precedence over the initial automatic session result. */
  const preserveInput = () => { if (epoch === state.sessionEpoch) state.sessionEpoch++; };
  const removeInputListeners = [];
  for (const id of ['username', 'password']) { removeInputListeners.push(bind(id, 'input', preserveInput), bind(id, 'change', preserveInput)); }
  try { const data = await api('/api/auth/session', {}, epoch); if (data.user) await enter(data.user, epoch); else showLogin(); }
  catch (error) { if (error !== obsoleteResponse && epoch === state.sessionEpoch) showLogin(error.message); }
  finally { for (const remove of removeInputListeners) remove(); }
}
bind('login-form', 'submit', /** Submit the real login form and enter only after authenticated success. */ async event => {
  event.preventDefault(); const credentials = { username: $('username').value.trim(), password: $('password').value };
  const epoch = beginSession(), button = event.submitter; button.disabled = true;
  try { const data = await api('/api/auth/login', jsonRequest('POST', credentials), epoch); await enter(data.user, epoch); }
  catch (error) { if (error !== obsoleteResponse && epoch === state.sessionEpoch) showLogin(error.message); }
  finally { if (epoch === state.sessionEpoch) button.disabled = false; }
});
bind('logout', 'click', /** Run logout with visible error feedback. */ () => perform(/** End the native session and restore the login screen. */ async () => { const epoch = state.sessionEpoch; await api('/api/auth/logout', { method: 'POST' }, epoch); checkCurrent(epoch); showLogin(); }, $('logout')));
document.querySelectorAll('[data-view]').forEach(/** Register each native navigation button with the shared click handler. */ button => button.addEventListener('click', navigationHandler));
bind('refresh-files', 'click', /** Refresh authorized file rows after the refresh click. */ () => perform(refreshFiles));
bind('refresh-tasks', 'click', /** Refresh this requester task list after the refresh click. */ () => perform(refreshTasks));
bind('refresh-board', 'click', /** Refresh the authenticated announcement board after the refresh click. */ () => perform(refreshBoard));
bind('upload-file', 'change', /** Display the actual chosen upload filename and byte size. */ () => { const file = $('upload-file').files[0]; $('chosen-file').textContent = file ? file.name + ' · ' + size(file.size) : '单个文件最多 50 MB'; });
bind('upload-form', 'submit', /** Submit the selected upload through the bounded native API. */ event => {
  event.preventDefault(); return perform(/** Upload the selected real file bytes and refresh authorized files. */ async () => {
    const epoch = state.sessionEpoch;
    const file = $('upload-file').files[0]; if (!file) return;
    if (file.size > 50 * 1024 * 1024) throw new Error(errors.UPLOAD_TOO_LARGE);
    $('upload-status').textContent = '正在上传…';
    try { await api('/api/files?name=' + encodeURIComponent(file.name), { method: 'POST', headers: { 'Content-Type': 'application/octet-stream' }, body: file }, epoch); checkCurrent(epoch); $('upload-form').reset(); $('chosen-file').textContent = '单个文件最多 50 MB'; notice('文件已上传。现在可以分享给指定同事。'); await refreshFiles(epoch); }
    finally { if (epoch === state.sessionEpoch) $('upload-status').textContent = ''; }
  }, event.submitter);
});
bind('share-form', 'submit', /** Submit this named-recipient share form. */ event => { event.preventDefault(); return perform(/** Create the selected recipient grant and close the share dialog after success. */ async () => { const epoch = state.sessionEpoch; await api('/api/files/' + state.shareFile.id + '/shares', jsonRequest('POST', { recipient_id: $('share-recipient').value }), epoch); checkCurrent(epoch); $('share-dialog').close(); notice('已授予共享。'); await refreshFiles(epoch); }, event.submitter); });
bind('close-share', 'click', /** Close the recipient picker without submitting a grant. */ () => $('share-dialog').close());
bind('announcement-form', 'submit', /** Submit this editor announcement form through its module. */ event => announcementBoard.submitAnnouncement(event));
bind('cancel-edit', 'click', resetEditor);
setInterval(/** Refresh tasks only after the current account is ready on the visible task page. */ () => { if (state.ready && state.user && state.view === 'tasks' && !document.hidden) perform(refreshTasks); }, 1800);
boot();
