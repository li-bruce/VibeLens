"""Maintain actual source locations while retaining authored captures and meaning."""
from copy import deepcopy
import sys
from change_tools import APP, PACK, RUN, CHANGE, load, save
sys.path.insert(0, str(PACK / "scripts"))
from bo_observer.sources import scan
from bo_observer.graph.code_structure import enrich
from implementation_coverage import functional_symbols

stage = sys.argv[1]
cfg = load(APP / "sync.json")
envelope = load(APP / "bo_stategraph/project.json")
model = envelope["model"]
old = deepcopy(model)
base = load(APP / CHANGE / "baseline.json")
for filename in ("src/announcements.mjs", "public/announcements.js"):
    if filename not in cfg["code_files"]:
        cfg["code_files"].append(filename)
    if filename not in model["source_files"]:
        model["source_files"].append(filename)
index = scan(APP, cfg["code_files"], base["structure"])
assert not index["errors"], index["errors"]
save(RUN / (stage + "-source-index.json"), index)
old_symbols, new_symbols = base["structure"]["symbols"], index["symbols"]
moves = {}
for key in old_symbols:
    for name in ("announcements", "publish", "mutateAnnouncement", "validateAnnouncement"):
        prefix = "src/service.mjs::FileService." + name
        if key == prefix or key.startswith(prefix + "."):
            target = key.replace(prefix, "src/announcements.mjs::AnnouncementService." + name, 1)
            assert target in new_symbols, target
            moves[key] = target
for key, symbol in new_symbols.items():
    if symbol["path"] != "public/announcements.js":
        continue
    matches = [old_key for old_key, value in old_symbols.items()
               if value["path"] == "public/app.js" and value["ast_hash"] == symbol["ast_hash"]]
    if len(matches) == 1:
        moves[matches[0]] = key
assert len(set(moves.values())) == len(moves)
def source(key):
    path, symbol = key.split("::", 1)
    return {"path": path, "symbol": symbol}
def relocate(value):
    if isinstance(value, list):
        return [relocate(item) for item in value]
    if not isinstance(value, dict):
        return value
    result = {key: relocate(item) for key, item in value.items()}
    key = value.get("path", "") + "::" + value.get("symbol", "") if isinstance(value.get("path", ""), str) and isinstance(value.get("symbol", ""), str) else ""
    if key in moves:
        result.update(source(moves[key]))
    return result
model = relocate(model)
plan = load(APP / "implementation.json")
for feature in plan["features"]:
    for item in list(feature.get("sources", [])):
        if item in moves and moves[item] not in feature["sources"]:
            feature["sources"].append(moves[item])
    for parameter in list(feature.get("parameters", [])):
        if parameter.get("source") in moves:
            relocated = deepcopy(parameter)
            relocated["source"] = moves[parameter["source"]]
            if relocated not in feature["parameters"]:
                feature["parameters"].append(relocated)
for category in ("support", "excluded"):
    for key, value in list(plan[category].items()):
        if key in moves and moves[key] not in plan[category]:
            plan[category][moves[key]] = deepcopy(value)
        if key not in index["symbols"]:
            assert key in moves, ("unresolved_removed_classification", key)
            del plan[category][key]
known = {item for feature in plan["features"] for item in feature.get("sources", [])} | set(plan["support"]) | set(plan["excluded"])
added = []
for key, record in functional_symbols(index).items():
    if key in known:
        continue
    assert record["path"] in {"src/announcements.mjs", "public/announcements.js", "public/app.js"}, key
    anchor = "read_announcements" if record["path"] == "src/announcements.mjs" else "ui_callback"
    plan["support"][key] = {"node": anchor,
        "reason": "Source-backed shared announcement module or local UI support. This static ownership does not fabricate execution, authorization or captured values."}
    added.append(key)
model["implementation"] = plan
model["source_files"] = sorted(set(model["source_files"]))
model["revision"] = "announcement-modules-" + stage
for probe in cfg.get("required_probes", []):
    if isinstance(probe, dict) and probe.get("symbol") in moves:
        probe["symbol"] = moves[probe["symbol"]]
model = enrich(enrich(model, index), index)
assert enrich(model, index) == model

old_nodes, nodes = {node["id"]: node for node in old["nodes"]}, {node["id"]: node for node in model["nodes"]}
roots = set(model.get("graph_roots") or [item["node"] for item in model["overview"]])
def owner(node, inventory):
    visited = set()
    while node["id"] not in roots and node.get("parent") in inventory:
        assert node["id"] not in visited
        visited.add(node["id"])
        node = inventory[node["parent"]]
    return node["id"]
aliases, dormant = {}, []
for key in old_nodes.keys() - nodes.keys():
    node = old_nodes[key]
    assert not any(node.get("capture", {}).values()), ("lost_captured_node", key)
    original = node.get("source", {})
    old_source = original.get("path", "") + "::" + original.get("symbol", "")
    target = source(moves[old_source]) if old_source in moves else original
    candidates = [item["id"] for item in nodes.values() if item.get("source") == target
                  and item["kind"] == node["kind"] and owner(item, nodes) == owner(node, old_nodes)]
    if len(candidates) == 1:
        aliases[key] = candidates[0]
    else:
        dormant.append({"id": key, "source": original, "moved_source": target, "candidates": candidates,
                        "reason": "Generated static slice changed; no ambiguous alias or execution edge is invented. Original personal settings remain in the untouched view file."})
presentation = model.setdefault("presentation", {})
presentation.setdefault("node_aliases", {}).update(aliases)
current = {node["id"]: node for node in model["nodes"]}
for key, node in old_nodes.items():
    if any(node.get("capture", {}).values()):
        assert current[key]["capture"] == node["capture"], key
for key in ("machines", "policy", "concepts"):
    assert model[key] == old[key], key
envelope["model"] = model
save(APP / "sync.json", cfg)
save(APP / "implementation.json", plan)
save(APP / "bo_stategraph/project.json", envelope)
review_path = APP / CHANGE / "review.json"
review = load(review_path) if review_path.exists() else {"decisions": {
    "business": {"action": "unchanged", "reason": "Announcement entrypoints, role/authorship rules and all file-sharing behavior remain unchanged during pure source modularization."},
    "state_machine": {"action": "unchanged", "reason": "All four native state declarations and their guards/transitions remain unchanged."},
    "abstraction": {"action": "updated", "reason": "Move announcement implementation into independent native/frontend modules while retaining public host/DOM entrypoints."},
    "probes": {"action": "updated", "reason": "Relocate actual source references with explicit one-to-one moves; preserve all six commands, 666 capture definitions, cases, queue bounds and 180-second timeout."}},
    "requirement_changes": {}}
review["source_moves"] = [{"from": source(key), "to": source(target),
    "reason": "Source-only announcement relocation; actual AST identity or explicit method move witnesses this one-to-one binding. Public facade/DOM entrypoints remain."}
    for key, target in sorted(moves.items())]
save(review_path, review)
save(RUN / (stage + "-mapping-refresh.json"), {"valid": True, "old_nodes": len(old_nodes), "new_nodes": len(nodes),
    "source_moves": review["source_moves"], "added_support": added, "node_aliases": aliases, "dormant_generated_slice_nodes": dormant,
    "all_666_capture_definitions_preserved": True, "machines_policy_concepts_unchanged": True,
    "canonical_enrich_idempotent": True, "personal_view_file_written": False})
print({"stage": stage, "source_moves": len(moves), "old_nodes": len(old_nodes), "current_nodes": len(nodes),
       "aliases": len(aliases), "dormant_generated_nodes": len(dormant), "added_support": len(added)}, flush=True)
