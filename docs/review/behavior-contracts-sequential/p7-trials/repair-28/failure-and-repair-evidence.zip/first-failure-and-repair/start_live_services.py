"""Leave native same-data services available after all authorized gates pass."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import time
import urllib.request

RUN = Path(__file__).resolve().parent
APP = RUN.parents[2]
PACK = APP.parent / "context-closure-skills/vibelens"
load = lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
assert load(RUN / "verify-after-browser.json")["valid"]
assert load(RUN / "verify-after-browser-command.json")["exit_code"] == 0
assert load(RUN / "independent-recording-audit.json")["targeted_audit_valid"]
seal = load(RUN / "normal-stop-original-seal.json")
settings = load(APP / ".stategraph/collector.json")
assert settings["build_id"] == seal["build_id"]
assert settings["endpoint"] == "http://127.0.0.1:8926"
assert (APP / "var/db/application.sqlite").is_file()
for port in (8925, 8926):
    with socket.socket() as probe:
        assert probe.connect_ex(("127.0.0.1", port)) != 0, f"Port {port} already occupied; do not replace its owner"
out = RUN / "live"
out.mkdir(exist_ok=False)
env = dict(os.environ, VIBELENS_SKILL=str(PACK), BO_DIAGNOSTIC_SKILL=str(PACK), VIBELENS_PYTHON=sys.executable, PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1", PYTHONIOENCODING="utf-8", TEAM_FILES_SQLITE_URL="sqlite:///var/db/application.sqlite", APP_DATA_ROOT=str(APP / "var"), PORT="8925", VIBELENS_PORT="8926", VIBELENS_ENABLED="1")
env.pop("VIBELENS_ENDPOINT", None)
children = []
def start(label, command):
    startup = subprocess.STARTUPINFO()
    startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    startup.wShowWindow = subprocess.SW_HIDE
    with (out / (label + ".stdout.log")).open("wb") as stdout, (out / (label + ".stderr.log")).open("wb") as stderr:
        child = subprocess.Popen(command, cwd=APP, env=env, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, close_fds=True, startupinfo=startup, creationflags=subprocess.CREATE_NO_WINDOW | subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP)
    children.append(child)
    return child
def ready(url, child):
    deadline = time.monotonic() + 35
    while time.monotonic() < deadline:
        if child.poll() is not None:
            raise RuntimeError(f"Native child {child.pid} exited with {child.returncode}")
        try:
            with urllib.request.urlopen(url, timeout=1) as response:
                if response.status == 200:
                    return
        except OSError:
            pass
        time.sleep(.2)
    raise RuntimeError(f"HTTP readiness failed: {url}")
def get(url):
    with urllib.request.urlopen(url, timeout=30) as response:
        return json.load(response)
graph_command = [sys.executable, "-B", "-X", "utf8", str(PACK / "scripts/bo.py"), "serve", "--root", str(APP), "--port", "8926", "--origin", "http://127.0.0.1:8925"]
app_command = [shutil.which("node"), "src/server.mjs"]
try:
    viewer = start("viewer", graph_command)
    ready("http://127.0.0.1:8926/graph", viewer)
    app = start("app", app_command)
    ready("http://127.0.0.1:8925/", app)
    health = get("http://127.0.0.1:8925/api/bo/health")
    view = get("http://127.0.0.1:8926/api/view")
    recordings = get("http://127.0.0.1:8926/api/recordings")
    assert health["enabled"] and not health["errors"] and not health["dropped"]
    assert view["manifest"]["build_id"] == seal["build_id"]
    assert view["binding_status"]["status"] == "current"
    assert recordings["active"] is None
    result = {"started_at": datetime.now(timezone.utc).isoformat(), "app": app.pid, "viewer": viewer.pid, "app_url": "http://127.0.0.1:8925/", "graph_url": "http://127.0.0.1:8926/graph", "build_id": seal["build_id"], "candidate_id": seal["candidate_id"], "provider": str(PACK), "data_root": str(APP / "var"), "database": str(APP / "var/db/application.sqlite"), "commands": {"app": app_command, "viewer": graph_command}, "native_health": health, "binding_status": view["binding_status"], "initial_live_event_count": len(view.get("events", [])), "recording_active": None, "lifecycle": "Detached hidden native children intentionally retained for independent desktop inspection; no automatic cleanup in this launcher."}
    (out / "services.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for label, child in (("app", app), ("viewer", viewer)):
        (APP / "review" / (label + ".pid")).write_text(str(child.pid), encoding="utf-8")
    (APP / "review/runtime/dev-processes.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"running": True, "app": app.pid, "viewer": viewer.pid, "build_id": seal["build_id"], "initial_live_events": result["initial_live_event_count"]}, ensure_ascii=False))
except BaseException:
    for child in children:
        if child.poll() is None:
            child.terminate()
    raise
