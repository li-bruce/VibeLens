"""Preserve the accepted project, then begin the separately authorized source/UI change."""
import re
import shutil
from change_tools import APP, RUN, PACK, CHANGE, load, save, sha, cli

accepted = APP / "download-start-permission-20261121"
assert load(accepted / "accepted.json")["candidate_id"] == "23029c5f522edebcaad3c23ee0cbab4397219dae31ced0eb2013813492388c1b"
assert load(APP / "review/runtime/context-closure-runtime-20261122/main-session-accept-and-service-stop.json")["valid"]
paths = ["sync.json", "intent.json", "discovery.json", "behavior.json", "acceptance.json", "mapping.json", "implementation.json",
         "bo_stategraph/project.json", "bo_stategraph/config/semantic-names.json", "bo_stategraph/config/views/local.json",
         "bo_stategraph/bo_runtime.mjs", "bo_stategraph/bo_capture.mjs", "bo_stategraph/bo_http.mjs", "bo_stategraph/integration.json",
         "tooling/frontend_session_checks.py", "tooling/browser_acceptance.py", "tooling/unified_browser_run.py"]
paths += [path.relative_to(APP).as_posix() for folder in ("src", "public", "integrations", "tests")
          for path in (APP / folder).rglob("*") if path.is_file() and "__pycache__" not in path.parts]
before = RUN / "before"
before.mkdir(exist_ok=False)
for name in sorted(set(paths)):
    target = before / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(APP / name, target)
shutil.copy2(APP / "var/db/application.sqlite", RUN / "database-before.sqlite")
records = {path.relative_to(APP).as_posix(): sha(path) for path in (APP / "bo_stategraph/data/recordings").glob("*.json")
           if re.fullmatch(r"[0-9a-f]{32}", path.stem)}
save(RUN / "before-seal.json", {"source_hashes": {name: sha(APP / name) for name in sorted(set(paths))},
    "record_hashes": records, "database_sha256": sha(APP / "var/db/application.sqlite"),
    "accepted_previous_change": {path.name: sha(path) for path in accepted.glob("*.json")},
    "personal_view_revision": load(APP / "bo_stategraph/config/views/local.json")["revision"],
    "test_commands": load(APP / "sync.json")["test_commands"], "timeout_seconds": load(APP / "sync.json")["timeout_seconds"],
    "provider_runtime_file_baseline_reference": str(APP / "review/runtime/context-closure-runtime-20261122/provider-files-runtime-baseline.json"),
    "native_runtime_slot_owned_by": "Main session Python", "complete_runtime_gates_authorized": False})
(RUN / "task_plan.md").write_text("# Announcement modularization and bootstrap UI correction\n\n- [x] Verify previous acceptance, stop only owned services, release native slot.\n- [ ] Begin from the accepted source/model and current preferences.\n- [ ] Preserve pure announcement relocation before/after source and model evidence; retain all semantics.\n- [ ] Reproduce the login input race with controlled cases, then implement its separate behavior correction.\n- [ ] Refresh canonical source/mapping/names and run targeted static/controlled checks.\n- [ ] Handoff and stop before native services, full verify, ordinary workload or recording until explicitly released.\n", encoding="utf-8")
request = ("文件共享这部分保持现在确认的行为。公告以后想单独维护，请把发布、修改、删除和读取公告相关实现整理到合适的独立模块，入口、权限和用户操作不变，让图自动跟上文件和函数位置的变化，保留我保存的视图和批注。另把已经复现的登录初始化问题修好：用户开始输入后，不应被迟到的初始会话响应清空密码。\n"
           "Stage authorization: preserve pure announcement source-refactor evidence separately, then fix the bootstrap UI race. Only static and isolated controlled checks now; the main session owns full native runtime. Preserve six commands, original fields/assertions/capacities/180-second deadline, raw history and current personal views; no provider edits or accept.")
value = cli("begin", "change_sync.py", "begin", "--change", CHANGE, "--request", request, "--requirements", "R_AUTH")
print({"new_change": CHANGE, "old_raw_records": len(records), "preference_revision": load(RUN / "before-seal.json")["personal_view_revision"], "begin_valid": value.get("valid")}, flush=True)
