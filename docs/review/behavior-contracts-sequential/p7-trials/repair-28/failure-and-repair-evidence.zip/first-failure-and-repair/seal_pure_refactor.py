"""Seal source-only announcement evidence before any bootstrap behavior edit."""
from copy import deepcopy
import shutil
from change_tools import APP, RUN, CHANGE, load, save, sha, cli

inspection = load(RUN / "pure-parameters-inspect.json")
assert not inspection["errors"] and inspection["review_errors"] == ["review belongs to an older candidate"]
review = load(APP / CHANGE / "review.json")
review["candidate_id"] = inspection["candidate_id"]
review["validation_scope"] = "Pure announcement source relocation only. Bootstrap behavior is unchanged. Syntax, exact core/signature/hook comparison and sixteen isolated simulated frontend cases passed. Full native/browser/recording evidence is pending; later bootstrap behavior correction is a separate phase."
save(APP / CHANGE / "review.json", review)
result = cli("pure-inspect-final", "change_sync.py", "inspect")
before = load(RUN / "before-seal.json")
old = load(RUN / "before/bo_stategraph/project.json")["model"]
current = load(APP / "bo_stategraph/project.json")["model"]
def fields(model):
    return {(node["id"], direction, key): value for node in model["nodes"] for direction in ("in", "out")
            for key, value in node.get("capture", {}).get(direction, {}).items()}
assert fields(old) == fields(current) and len(fields(current)) == 666
for key in ("machines", "policy", "concepts"):
    assert old[key] == current[key], key
assert {node["id"] for node in old["nodes"]} <= ({node["id"] for node in current["nodes"]} | set(current["presentation"]["node_aliases"]))
for filename in ("intent.json", "discovery.json", "behavior.json", "acceptance.json", "mapping.json", "bo_stategraph/config/views/local.json"):
    assert sha(APP / filename) == before["source_hashes"][filename], filename
assert sha(APP / "var/db/application.sqlite") == before["database_sha256"]
assert all(sha(APP / filename) == digest for filename, digest in before["record_hashes"].items())
assert load(APP / "sync.json")["test_commands"] == before["test_commands"]
assert load(APP / "sync.json")["timeout_seconds"] == before["timeout_seconds"] == 180
assert all(load(RUN / name)["valid"] for name in ("pure-core-source-comparison.json", "pure-final-controls/result.json", "pure-docs.json", "pure-api.json"))
assert len(load(RUN / "pure-final-controls/result.json")["cases"]) == 16
source_names = ["src/service.mjs", "src/announcements.mjs", "public/app.js", "public/announcements.js", "tooling/frontend_session_checks.py",
                "sync.json", "implementation.json", "bo_stategraph/project.json", "bo_stategraph/config/semantic-names.json", CHANGE + "/review.json"]
out = RUN / "pure-after"
out.mkdir(exist_ok=False)
for name in source_names:
    target = out / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(APP / name, target)
save(RUN / "pure-refactor-comparison.json", {"valid": True, "candidate_id": result["candidate_id"],
    "before_nodes": len(old["nodes"]), "after_nodes": len(current["nodes"]), "all_old_node_identities_retained_or_explicitly_aliased": True,
    "node_aliases": current["presentation"]["node_aliases"], "all_666_field_definitions_identical": True,
    "business_state_rules_concepts_and_intent_unchanged": True, "bootstrap_behavior_unchanged": True,
    "native_case_plan_and_six_commands_unchanged": True, "case_timeout_seconds": 180,
    "controlled_cases_before": len(load(RUN / "pure-before-controls/result.json")["cases"]), "controlled_cases_after": 16,
    "current_preferences_byte_equal": True, "personal_view_revision": before["personal_view_revision"],
    "database_byte_equal": True, "old_recordings_byte_equal": len(before["record_hashes"]),
    "before_source_reference": str(RUN / "before"), "after_source_reference": str(out),
    "after_hashes": {name: sha(APP / name) for name in source_names}, "source_moves": review["source_moves"],
    "bound_shared_operation_sources": load(RUN / "pure-bound-source-identities.json"),
    "first_failures_preserved": ["pure-core-source-comparison-command.json", "pure-names-apply-command.json", "pure-inspect-before-review.json"],
    "native_or_recording_acceptance_claimed": False})
print({"pure_refactor_sealed": True, "candidate_id": result["candidate_id"], "fields": 666,
       "old_nodes": len(old["nodes"]), "new_nodes": len(current["nodes"]), "bootstrap_change_mixed_into_stage": False}, flush=True)
