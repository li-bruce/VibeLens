"""Report valid partial ordinary evidence without promoting the interrupted recording."""
from contextlib import closing
from pathlib import Path
import hashlib
import sqlite3
import sys
from runtime_tools import APP, PACK, RUN, load, save, sha

seal = load(RUN / "failed-ordinary-original-seal.json")
unified = Path(seal["unified_run"])
assert all(sha(APP / name) == digest for name, digest in seal["new_run_files"].items())
assert all(sha(APP / name) == digest for name, digest in seal["record_file_sha256"].items())
sys.path.insert(0, str(PACK / "scripts"))
from bo_observer.workflow.observation_requirements import invocation_closure
from bo_observer.model_io import read_model
model = read_model(APP / "bo_stategraph/project.json", project_root=APP)
record_results = []
prior_events = {}
for index, name in enumerate(("independent-recording-3af55c61be86446e8448bee689b1e61b.json",
                              "failed-recording-90530611914d45309aa5569b407b3923.json")):
    record = load(unified / name)
    closure = invocation_closure({"runs": [{"case": record["id"], "mode": "on", "events": record["events"]}]}, required=True, model=model)
    context = record["context"]["events"]
    combined = {event["id"]: event for event in [*context, *record["events"]]}
    missing = [{"event_id": event["id"], "parent_event_id": event["parent_event_id"]} for event in combined.values()
               if event.get("parent_event_id") and event["parent_event_id"] not in combined]
    headers = [event for event in context if event.get("context_only")]
    compared = []
    for event in headers:
        assert event["inputs"] == event["outputs"] == event["basis"] == {} and event["depends"] == []
        if index:
            original = prior_events[event["id"]]
            omitted = {"context_only", "context_boundary", "inputs", "outputs", "depends", "basis", "revision", "provenance", "exception"}
            assert {k: v for k, v in event.items() if k not in omitted} == {k: v for k, v in original.items() if k not in omitted}
            compared.append(event["id"])
    prior_events.update(combined)
    assert record["context_selection"]["recent_value_limit"] == 2000
    if index == 0:
        assert record["status"] == "stopped" and record["gaps"] == [] and record["producer_settlement"]["flushed"]
        assert closure["valid"]
    else:
        assert record["status"] == "interrupted" and not record["producer_settlement"]["flushed"]
        assert record["gaps"] and record["producer_settlement"]["pending"] > 0
    record_results.append({"id": record["id"], "original": str(unified / name), "status": record["status"],
        "events": len(record["events"]), "gaps": record["gaps"], "producer_settlement": record["producer_settlement"],
        "closure_valid": closure["valid"], "closed_calls": closure["closed_calls"], "closure_errors": closure["errors"],
        "context_selection": record["context_selection"], "context_events": len(context),
        "full_value_context": len(context) - len(headers), "metadata_only_context": len(headers),
        "metadata_compared_to_first_original": compared, "missing_parent_references": missing})
image = Path(seal["actual_database"]["path"]).read_bytes()
with closing(sqlite3.connect(":memory:")) as db:
    db.deserialize(image)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA query_only=ON")
    acceptance = load(unified / "browser-acceptance.json")
    order = next(row for row in acceptance["ordinary_worker_order"] if row.get("case") == "ordinary_recipient_ready_before_revoke")
    task = dict(db.execute("SELECT * FROM tasks WHERE id=?", (order["task_id"],)).fetchone())
    grant = dict(db.execute("SELECT * FROM grants WHERE file_id=? AND recipient_id=?", (task["file_id"], "bob")).fetchone())
assert task["status"] == "ready" and task["authorized_at_submission"] == 1 and grant["active"] == 0
assert order["pre_state"]["status"] == "queued" and order["grant"]["active"] == 1 and order["expected_permission"] is True
byte_hashes = [sha(Path(name)) for name in acceptance["repeat_downloads"]]
assert len(byte_hashes) == 2 and byte_hashes == [task["sha256"]] * 2
assert sha(Path(task["prepared_path"])) == task["sha256"]
save(RUN / "failed-ordinary-independent-audit.json", {
    "audit_completed": True, "ordinary_workflow_valid": False, "ordinary_attempts": 1,
    "build_id": seal["candidate_build"]["build_id"], "records": record_results,
    "on_off_fault_business_equal": True, "first_recording_valid": True, "second_recording_valid": False,
    "ordinary_permission_outcome": {"case": "ordinary_recipient_ready_before_revoke", "task_id": task["id"],
        "actual_pre_start_grant_active": order["grant"]["active"], "actual_pre_start_task": order["pre_state"]["status"],
        "persisted_task": task["status"], "persisted_grant_active": grant["active"],
        "repeat_download_sha256": byte_hashes, "scope": "Started with an active grant and became ready before revoke; this is not evidence of cancellation."},
    "raw_files_unchanged": True, "failure_was_not_rewritten_as_success": True,
    "no_added_recordings_or_events": True, "accept_executed": False})
print({"partial_audit_completed": True, "ordinary_valid": False,
       "records": [{k: r[k] for k in ("id", "status", "events", "closure_valid", "closed_calls", "full_value_context", "metadata_only_context")} for r in record_results],
       "repeat_bytes_match": True}, flush=True)
