"""Relocate announcement implementation only; bootstrap behavior stays unchanged."""
from textwrap import indent
from change_tools import APP, RUN, load, save, sha

before = load(RUN / "before-seal.json")
for name in ("src/service.mjs", "public/app.js", "tooling/frontend_session_checks.py"):
    assert sha(APP / name) == before["source_hashes"][name], name
service = (APP / "src/service.mjs").read_text(encoding="utf-8")
start = service.index("  /** Read the independent board")
end = service.index("  /** Stop task scheduling", start)
native_block = service[start:end]
native_module = """import { randomUUID } from 'node:crypto';

/** Independent announcement operations using the host's shared native boundaries. */
export class AnnouncementService {
  /** Retain shared storage, operation/authorization/state hooks and the public error type.
   * @param {object} service Existing native host whose common hooks retain their original receiver.
   * @param {Function} ErrorType Existing public application error constructor.
   */
  constructor(service, ErrorType) {
    this.store = service.store;
    this.operation = service.operation.bind(service);
    this.authorize = service.authorize.bind(service);
    this.state = service.state.bind(service);
    this.ErrorType = ErrorType;
  }
""" + native_block.replace("new AppError(", "new this.ErrorType(") + "}\n"
facades = """  /** Delegate authenticated board reads to the independent announcement service.
   * @param {object} actor Current authenticated native member.
   */
  async announcements(actor) { return this.announcementBoard.announcements(actor); }
  /** Delegate publication without changing the public method or editor rule.
   * @param {object} actor Current authenticated native member.
   * @param {string} title Announcement title, bounded to 120 characters.
   * @param {string} body Announcement content, bounded to 8000 characters.
   */
  async publish(actor, title, body) { return this.announcementBoard.publish(actor, title, body); }
  /** Delegate the selected own-announcement mutation without changing its arguments.
   * @param {object} actor Current authenticated native member.
   * @param {string} id Identity of the selected announcement.
   * @param {string} action Selected mutation: edit or delete.
   * @param {string} title Announcement title, bounded to 120 characters.
   * @param {string} body Announcement content, bounded to 8000 characters.
   */
  async mutateAnnouncement(actor, id, action, title = '', body = '') { return this.announcementBoard.mutateAnnouncement(actor, id, action, title, body); }
  /** Delegate the original announcement input bounds.
   * @param {string} title Announcement title, bounded to 120 characters.
   * @param {string} body Announcement content, bounded to 8000 characters.
   */
  validateAnnouncement(title, body) { return this.announcementBoard.validateAnnouncement(title, body); }
"""
service = service[:start] + facades + service[end:]
service = service.replace("import { decide } from './policy.mjs';", "import { decide } from './policy.mjs';\nimport { AnnouncementService } from './announcements.mjs';")
assert service.count("this.workerDelay = 20;") == 1
service = service.replace("this.workerDelay = 20;", "this.workerDelay = 20;\n    this.announcementBoard = new AnnouncementService(this, AppError);")

frontend = (APP / "public/app.js").read_text(encoding="utf-8")
start = frontend.index("/** Reset only the announcement composition form.")
boot = frontend.index("async function boot()", start)
end = frontend.rfind("/**", start, boot)
board_block = frontend[start:end]
start_bind = frontend.index("bind('announcement-form', 'submit'")
end_bind = frontend.index("bind('cancel-edit', 'click', resetEditor);", start_bind) + len("bind('cancel-edit', 'click', resetEditor);")
form_bind = frontend[start_bind:end_bind]
start_refresh = frontend.index("bind('refresh-board', 'click'")
end_refresh = frontend.index("\n", start_refresh)
refresh_bind = frontend[start_refresh:end_refresh]
frontend_module = """/** Create the independent board from the existing session, API and safe DOM helpers.
 * @param {object} ui Shared frontend helpers; this module retains their current session guards.
 */
export function createAnnouncementBoard(ui) {
  const { state, $, api, checkCurrent, beginRefresh, element, action, notice, time, perform, bind } = ui;
""" + indent(board_block + refresh_bind + "\n" + form_bind + "\n", "  ") + "  return { resetEditor, refreshBoard };\n}\n"
delegates = """const announcementBoard = createAnnouncementBoard({ state, $, api, checkCurrent, beginRefresh, element, action, notice, time, perform, bind });
/** Reset the independent board composition form through its module. */
function resetEditor() { return announcementBoard.resetEditor(); }
/** Refresh the independent board for the current guarded account.
 * @param {number} epoch Local authentication attempt owning this read.
 */
async function refreshBoard(epoch = state.sessionEpoch) { return announcementBoard.refreshBoard(epoch); }
"""
frontend = frontend[:start] + delegates + frontend[end:]
frontend = frontend.replace(form_bind, "").replace(refresh_bind + "\n", "")
frontend = frontend.replace("'use strict';", "'use strict';\nimport { createAnnouncementBoard } from './announcements.js';", 1)
old_boot = (RUN / "before/public/app.js").read_text(encoding="utf-8").split("async function boot()", 1)[1].split("bind('login-form'", 1)[0]
assert frontend.split("async function boot()", 1)[1].split("bind('login-form'", 1)[0] == old_boot

fixture = (APP / "tooling/frontend_session_checks.py").read_text(encoding="utf-8")
fixture = fixture.replace('if path in ("/", "/app.js", "/app.css"):\n            name = "index.html" if path == "/" else path[1:]',
                          'name = "index.html" if path == "/" else path[1:]\n        if name in self.source:')
fixture = fixture.replace('source = {name: (source_root / "public" / name).read_bytes() for name in ("index.html", "app.js", "app.css")}',
    'source_names = {"index.html", "app.css"} | {path.name for path in (source_root / "public").glob("*.js")}\n    source = {name: (source_root / "public" / name).read_bytes() for name in sorted(source_names)}')
assert 'if name in self.source:' in fixture and 'source_names =' in fixture
for name, source in (("src/announcements.mjs", native_module), ("src/service.mjs", service),
                     ("public/announcements.js", frontend_module), ("public/app.js", frontend),
                     ("tooling/frontend_session_checks.py", fixture)):
    (APP / name).write_text(source, encoding="utf-8")
save(RUN / "pure-source-move-spec.json", {
    "meaning": "Announcement source modularization only. Routes, public host methods, guards, operation/state hooks, SQL and UI actions are retained. Bootstrap behavior remains byte-identical until the subsequent separate fix.",
    "source_moves": [{"from": {"path": "src/service.mjs", "symbol": "FileService." + name},
        "to": {"path": "src/announcements.mjs", "symbol": "AnnouncementService." + name},
        "reason": "Relocate announcement implementation while retaining stable business/capture identities and public FileService delegation."}
        for name in ("announcements", "publish", "mutateAnnouncement", "validateAnnouncement")],
    "backend_core_transform": "Only native AppError lexical access becomes this.ErrorType; the exact original constructor is explicitly passed and retained. All other moved method text is identical.",
    "frontend_core_moved_verbatim_except_indentation": True, "bootstrap_unchanged": True,
    "frontend_fixture_change": "Serve every exact selected JavaScript module asset; all sixteen original cases/assertions remain unchanged.",
    "original_backend_block_sha256": __import__("hashlib").sha256(native_block.encode()).hexdigest(),
    "original_frontend_block_sha256": __import__("hashlib").sha256(board_block.encode()).hexdigest(),
    "native_runtime_or_recording_executed": False,
})
print({"announcement_source_modules": ["src/announcements.mjs", "public/announcements.js"], "bootstrap_behavior_changed": False,
       "public_entry_methods_retained": True, "original_controlled_cases": 16}, flush=True)
