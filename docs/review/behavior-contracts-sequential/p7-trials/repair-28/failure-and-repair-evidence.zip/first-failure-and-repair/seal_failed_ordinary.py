"""Freeze the first ordinary failure and real stop receipts before any correction."""
from datetime import datetime, timezone
from pathlib import Path
import shutil
from runtime_tools import APP, RUN, CHANGE, load, save, sha

assert load(RUN / "ordinary-browser-recording-command.json")["exit_code"] == 1
unified = Path(load(APP / "review/runtime/latest-unified-run.json")["path"])
assert unified.name == "unified-1795290160"
out = RUN / "failed-ordinary-originals"
out.mkdir(exist_ok=False)
for name in ("lifecycle.json", "browser-acceptance.json", "browser-stop-receipts.json", "browser-failure-1795290242.json"):
    shutil.copy2(unified / name, out / name)
shutil.copy2(APP / "var/db/application.sqlite", out / "application.sqlite")
shutil.copy2(APP / "bo_stategraph/config/views/local.json", out / "personal-views.json")
shutil.copy2(APP / CHANGE / "verification.json", out / "verification-before-ordinary.json")
shutil.copy2(APP / CHANGE / "review.json", out / "review.json")
snapshot = load(RUN / "current-static-snapshot.json")
for name in snapshot["files"]:
    if not (APP / name).is_file():
        continue
    target = out / "source" / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(APP / name, target)
records = {path.relative_to(APP).as_posix(): sha(path) for path in (APP / "bo_stategraph/data/recordings").glob("*.json")}
seal = {"sealed_at": datetime.now(timezone.utc).isoformat(),
    "candidate_build": load(RUN / "candidate-build.json"), "unified_run": str(unified),
    "ordinary_attempts": 1, "rerun_performed": False, "exit_code": 1,
    "failure": "browser_acceptance.py:261; new announcement did not become visible after clicking publish",
    "source_diagnosis": "public/announcements.js submitAnnouncement references jsonRequest, but the factory does not bind that existing shared helper from ui",
    "new_run_files": {path.relative_to(APP).as_posix(): sha(path) for path in unified.rglob("*") if path.is_file()},
    "record_file_sha256": records,
    "actual_database": {"path": str(out / "application.sqlite"), "sha256": sha(out / "application.sqlite")},
    "source_snapshot": str(out / "source"), "source_files": snapshot["files"],
    "preferences": {"path": str(out / "personal-views.json"), "sha256": sha(out / "personal-views.json"),
                    "revision": load(out / "personal-views.json")["revision"]},
    "accept_executed": False,
    "next": "Complete unchanged canonical post-verify once and independent audits whose prerequisites hold. Do not repeat ordinary recordings to select a schedule."}
save(RUN / "failed-ordinary-original-seal.json", seal)
print({"first_ordinary_failure_sealed": True, "run": str(unified), "files": len(seal["new_run_files"]),
       "record_files": len(records), "rerun_performed": False}, flush=True)
