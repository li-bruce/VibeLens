"""Authorized repair27 upgrade and exact-build native/browser validation tools."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

RUN = Path(__file__).resolve().parent
APP = RUN.parents[2]
REPOSITORY = APP.parents[2]
PACK = APP.parent / "context-closure-skills/vibelens"
OLD_PACK = APP.parent / "recording-copy-skills/vibelens"
PY = REPOSITORY / ".venv/Scripts/python.exe"
CHANGE = ".stategraph/announcement-module-bootstrap-20261122"
ENV = dict(os.environ, VIBELENS_SKILL=str(PACK), BO_DIAGNOSTIC_SKILL=str(PACK), VIBELENS_PYTHON=str(PY),
           PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1", PYTHONIOENCODING="utf-8",
           TEAM_FILES_SQLITE_URL="sqlite:///var/db/application.sqlite", APP_DATA_ROOT=str(APP / "var"),
           BO_LOAD_CONTEXT="The main session completed Python repair27 and released the native runtime slot. After separately sealed pure announcement relocation and login input regressions plus canonical static checks, run the original six-command native gate, one original unprofiled ordinary on/off/fault two-recording workload, and complete post-verify in this chat. Preserve every first failure and valid independent audit, 666 field definitions, all old records/views, capacities and the 180-second limit. Do not modify the provider, retry ordinary workloads to select schedules, or accept. Retain actual services and fresh live history only after successful runtime gates for main-session UI inspection.")
ENV.pop("VIBELENS_ENDPOINT", None)


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def cli(label, script, *args, allow_failure=False, provider=PACK):
    assert not (script == "change_sync.py" and args and args[0] == "accept")
    if script == "change_sync.py" and args and args[0] == "verify":
        assert load(RUN / "runtime-release.json")["authorized"]
        assert load(RUN / "ui-static-preservation.json")["valid"]
        assert load(RUN / "runtime-slot-status.json")["available_to_trial"]
    if script == "change_sync.py" and args and args[0] == "begin":
        assert "--change" in args and args[args.index("--change") + 1] == CHANGE
    target = RUN / (label + ".json")
    assert not target.exists(), target
    command = [str(PY), "-B", "-X", "utf8", str(provider / "scripts" / script), *map(str, args), "--root", str(APP)]
    env = dict(ENV, VIBELENS_SKILL=str(provider), BO_DIAGNOSTIC_SKILL=str(provider))
    started = datetime.now(timezone.utc).isoformat()
    with target.open("xb") as out, (RUN / (label + ".stderr.log")).open("xb") as err:
        result = subprocess.run(command, cwd=APP, env=env, stdout=out, stderr=err, timeout=1200,
                                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    save(RUN / (label + "-command.json"), {"command": command, "exit_code": result.returncode,
         "started_at": started, "finished_at": datetime.now(timezone.utc).isoformat(), "provider": str(provider)})
    value = load(target)
    print({"label": label, "exit_code": result.returncode, "valid": value.get("valid"), "status": value.get("status"),
           "candidate_id": value.get("candidate_id"), "errors_count": len(value.get("errors", [])),
           "review_errors_count": len(value.get("review_errors", [])),
           "changes": value.get("changes") if script == "bo_integrate.py" else None}, flush=True)
    if result.returncode and not allow_failure:
        raise RuntimeError("Preserved canonical failure: " + label)
    return value


def run(label, command, *, allow_failure=False, timeout=1200):
    target = RUN / (label + ".stdout.log")
    assert not target.exists(), target
    started = datetime.now(timezone.utc).isoformat()
    with target.open("xb") as out, (RUN / (label + ".stderr.log")).open("xb") as err:
        result = subprocess.run(list(map(str, command)), cwd=APP, env=ENV, stdout=out, stderr=err, timeout=timeout,
                                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    save(RUN / (label + "-command.json"), {"command": list(map(str, command)), "exit_code": result.returncode,
         "started_at": started, "finished_at": datetime.now(timezone.utc).isoformat(), "provider": str(PACK)})
    print({"label": label, "exit_code": result.returncode}, flush=True)
    if result.returncode:
        print((target.read_text(encoding="utf-8-sig") + (RUN / (label + ".stderr.log")).read_text(encoding="utf-8-sig"))[-4500:], flush=True)
        if not allow_failure:
            raise RuntimeError("Preserved runtime failure: " + label)
    return result.returncode
