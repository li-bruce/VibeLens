"""Review the exact generated catalog/newline drift without starting runtime work."""
import copy
import hashlib
import json
import shutil
import sys
from datetime import datetime, timezone
from change_tools import APP, PACK, RUN, CHANGE, load, save, sha, cli

sys.path.insert(0, str(PACK / "scripts"))
from sync_config import config, snapshot
from behavior_model import digest, capture
from bo_observer.model_io import read_model

failed = RUN / "first-full-preflight-failure"
old = load(failed / "reconstructed-prior-snapshot-inputs.json")
current = snapshot(APP, config(APP, "sync.json"), load(APP / CHANGE / "baseline.json"))
assert old["id"] == load(RUN / "inspect-ready-native.json")["candidate_id"]
assert digest({"files": old["files"], "tools": old["tools"], "framework": old["framework"]}) == old["id"]
assert old["tools"] == current["tools"]
assert old["framework"] == current["source_inventory"]["framework"]
changes = [name for name in set(old["files"]) | set(current["files"]) if old["files"].get(name) != current["files"].get(name)]
assert set(changes) == {"bo_stategraph/project.json", "bo_stategraph/database-catalog.json"}
prior_project = load(failed / "reconstructed-prior-project.json")
current_project = load(APP / "bo_stategraph/project.json")
prior_db = prior_project["model"]["database"]
current_db = current_project["model"]["database"]
assert prior_db["catalog_id"] == current_db["catalog_id"]
same = copy.deepcopy(current_project)
same["model"]["database"]["source_id"] = prior_db["source_id"]
assert same == prior_project
old_project_bytes = (failed / "reconstructed-prior-project.json").read_bytes()
assert b"\r\n" in old_project_bytes and b"\r\n" not in (APP / "bo_stategraph/project.json").read_bytes()
catalog_bytes = (APP / "bo_stategraph/database-catalog.json").read_bytes()
old_catalog_bytes = catalog_bytes.replace(current_db["source_id"].encode(), prior_db["source_id"].encode())
assert hashlib.sha256(old_catalog_bytes).hexdigest() == old["files"]["bo_stategraph/database-catalog.json"]
(failed / "reconstructed-prior-catalog.json").write_bytes(old_catalog_bytes)
baseline = load(RUN / "runtime-before-seal.json")
assert all(sha(APP / name) == value for name, value in baseline["source_hashes"].items())
assert sha(APP / "var/db/application.sqlite") == baseline["database_sha256"]
assert all(sha(APP / name) == value for name, value in baseline["record_hashes"].items())
build = capture(APP, read_model(APP / "bo_stategraph/project.json", project_root=APP))
assert build == load(RUN / "derived-build.json")
report = {
    "valid": True, "prior_candidate_id": old["id"], "current_candidate_id": current["id"],
    "exact_prior_candidate_reconstructed": True,
    "changed_snapshot_files": {name: {"before": old["files"][name], "after": current["files"][name]} for name in sorted(changes)},
    "tools_unchanged": True, "framework_unchanged": True,
    "project_semantic_change_only": "model.database.source_id",
    "project_byte_change_also": "CRLF to LF during canonical database synchronization",
    "database_source_id_before": prior_db["source_id"], "database_source_id_after": current_db["source_id"],
    "database_catalog_id_unchanged": current_db["catalog_id"],
    "catalog_semantic_change_only": "source_id",
    "cause": "inspect snapshots first, then maintenance_task synchronizes the database source identity and rewrites its generated project/catalog files; the report therefore preceded that generated refresh",
    "build_unchanged": build["build_id"], "all_sealed_sources_unchanged": True,
    "actual_database_and_old_recordings_byte_equal": True,
    "tests_started": False, "ordinary_workload_started": False,
    "runtime_slot": "temporarily yielded to main-session browser acceptance; wait for explicit restoration",
    "old_review_preserved": str(failed / "review.json"),
    "accept_executed": False,
}
save(RUN / "candidate-drift-exact-diagnosis.json", report)
save(RUN / "current-static-snapshot.json", current)
first = cli("inspect-current-generated-review", "change_sync.py", "inspect", allow_failure=True)
assert first["candidate_id"] == current["id"]
assert not first["errors"] and first["review_errors"] == ["review belongs to an older candidate"]
review = load(APP / CHANGE / "review.json")
review["candidate_id"] = current["id"]
review["generated_refresh_review"] = {
    "evidence": "review/runtime/announcement-module-bootstrap-20261122/candidate-drift-exact-diagnosis.json",
    "reviewed_change": "Database source identity refresh and canonical LF serialization only; database catalog contents, build, business source, tests, captures, permissions, preferences and recordings unchanged.",
    "prior_candidate_id": old["id"], "current_candidate_id": current["id"],
}
save(APP / CHANGE / "review.json", review)
second = cli("inspect-current-generated-ready", "change_sync.py", "inspect")
assert second["valid"] and second["candidate_id"] == current["id"]
after = snapshot(APP, config(APP, "sync.json"), current)
assert after["id"] == current["id"] and after["files"] == current["files"]
save(RUN / "runtime-current-static-review.json", {**report, "canonical_inspect_valid": True,
    "candidate_stable_across_inspect": True, "full_runtime_verified": False})
shutil.copy2(RUN / "candidate-build.json", failed / "candidate-build-before-generated-review.json")
binding = load(RUN / "candidate-build.json")
binding["candidate_id"] = current["id"]
binding["generated_refresh_review"] = "runtime-current-static-review.json"
save(RUN / "candidate-build.json", binding)
save(RUN / "runtime-slot-status.json", {"at": datetime.now(timezone.utc).isoformat(),
    "available_to_trial": False, "reason": "Main session requested temporary native slot for static demo browser acceptance; no native workload has started here."})
print({"exact_diagnosis": True, "candidate_id": current["id"], "build_id": build["build_id"],
       "static_inspect_valid": True, "runtime_started": False}, flush=True)
