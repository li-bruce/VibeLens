"""Add observable input-retention regressions after sealing pure source relocation."""
import shutil
from change_tools import APP, RUN, load, save, sha

assert load(RUN / "pure-refactor-comparison.json")["valid"]
path = APP / "tooling/frontend_session_checks.py"
assert sha(path) == load(RUN / "pure-refactor-comparison.json")["after_hashes"]["tooling/frontend_session_checks.py"]
text = path.read_text(encoding="utf-8")
old = '''        if path == "/api/bo/client.mjs":
            await route.fulfill(status=404, body="Observer unavailable in isolated frontend fixture")
            return'''
new = '''        if path == "/api/bo/client.mjs":
            hold = getattr(self, "client_hold", None)
            if hold:
                hold.update(used=True, request=request)
                hold["arrived"].set()
                await hold["release"].wait()
            await route.fulfill(status=404, body="Observer unavailable in isolated frontend fixture")
            return'''
assert old in text
text = text.replace(old, new, 1)
functions = '''async def bootstrap_typed_input(page, fixture):
    """A known late initial reply must preserve current visible credential input."""
    hold = fixture.bootstrap_hold
    await arrived(hold)
    await page.get_by_role("textbox", name="用户名", exact=True).fill("bob")
    await page.get_by_role("textbox", name="密码", exact=True).fill("Simulated frontend password")
    await release(page, hold)
    await expect(page.get_by_role("textbox", name="用户名", exact=True)).to_have_value("bob")
    await expect(page.get_by_role("textbox", name="密码", exact=True)).to_have_value("Simulated frontend password")
    await expect(page.locator("#login-form")).to_be_visible()
    await expect(page.locator("#workspace")).to_be_hidden()
    await expect(page.locator("#login-error")).to_have_text("")
    await login(page, "bob")


async def bootstrap_input_before_module(page, fixture):
    """Typing before optional-client initialization must survive subsequent bootstrap."""
    await arrived(fixture.client_hold)
    await page.get_by_role("textbox", name="用户名", exact=True).fill("bob")
    await page.get_by_role("textbox", name="密码", exact=True).fill("Simulated frontend password")
    await release(page, fixture.client_hold)
    await page.evaluate("import('/app.js').then(() => true)")
    await expect(page.get_by_role("textbox", name="用户名", exact=True)).to_have_value("bob")
    await expect(page.get_by_role("textbox", name="密码", exact=True)).to_have_value("Simulated frontend password")
    await expect(page.locator("#login-form")).to_be_visible()
    await login(page, "bob")


'''
marker = "async def run_case(browser, source, output, name, action):"
assert marker in text
text = text.replace(marker, functions + marker, 1)
setup = '''    if name in {"bootstrap_input_null", "bootstrap_input_401", "bootstrap_input_existing_session"}:
        fixture.session_user = "alice" if name == "bootstrap_input_existing_session" else None
        fixture.bootstrap_hold = fixture.hold("/api/auth/session", None, status=401 if name == "bootstrap_input_401" else 200)
    if name == "bootstrap_input_before_module":
        fixture.client_hold = fixture.hold("/api/bo/client.mjs", None, status=404)
'''
marker = '    context = await browser.new_context(viewport={"width": 1440, "height": 1000})'
assert text.count(marker) == 1
text = text.replace(marker, setup + marker, 1)
marker = '("independent_board_controls", independent_board_controls)]'
replacement = '''("independent_board_controls", independent_board_controls),
             ("bootstrap_input_null", bootstrap_typed_input), ("bootstrap_input_401", bootstrap_typed_input),
             ("bootstrap_input_existing_session", bootstrap_typed_input),
             ("bootstrap_input_before_module", bootstrap_input_before_module)]'''
assert marker in text
text = text.replace(marker, replacement, 1)
path.write_text(text, encoding="utf-8", newline="\n")
out = RUN / "ui-before"
out.mkdir(exist_ok=False)
for filename in ("public/index.html", "public/app.css", "public/app.js", "public/announcements.js", "tooling/frontend_session_checks.py"):
    target = out / filename
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(APP / filename, target)
save(RUN / "bootstrap-case-definition.json", {"simulated_api_only": True, "original_cases_retained": 16,
    "added_cases": ["bootstrap_input_null", "bootstrap_input_401", "bootstrap_input_existing_session", "bootstrap_input_before_module"],
    "test_basis": "Actual user instruction and earlier real-origin response-barrier diagnosis. Assert credential input/visible account behavior rather than private implementation counters.",
    "source_before_fix": str(out), "native_services_or_recordings_started": False})
print({"original_cases_retained": 16, "added_bootstrap_cases": 4, "production_bootstrap_fixed": False}, flush=True)
