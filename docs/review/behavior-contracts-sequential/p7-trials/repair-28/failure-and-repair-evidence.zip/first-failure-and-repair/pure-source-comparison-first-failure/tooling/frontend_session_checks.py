"""Exercise account isolation through real DOM controls and simulated API barriers.

Serve the exact selected frontend bytes in isolated Chrome contexts. Responses
are explicit test doubles, not native business/permission or capture evidence.
No native server, provider, real database, recording or personal view is used.
"""
import argparse
import asyncio
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import time
from urllib.parse import urlsplit
from playwright.async_api import Error as PlaywrightError, async_playwright, expect

APP = Path(__file__).resolve().parents[1]
ORIGIN = "http://session-regression.test.invalid"
USERS = {name: {"id": name, "username": name, "display_name": "模拟 " + name, "editor": name == "editor"}
         for name in ("alice", "bob", "editor")}


def file_list(actor, visible):
    rows = [{"id": "simulated-file", "name": "simulated-shared.txt", "size": 32, "sha256": "simulated-only",
             "owner_id": "alice", "owner_name": USERS["alice"]["display_name"], "created_at": "2026-11-21T00:00:00Z",
             "mine": actor == "alice", "grants": [{"recipient_id": "bob", "display_name": USERS["bob"]["display_name"], "active": True}] if actor == "alice" else []}] if visible and actor in ("alice", "bob") else []
    return {"files": rows, "count": len(rows)}


class Fixture:
    def __init__(self, source):
        self.source = source
        self.actor = None
        self.session_user = None
        self.holds = []
        self.trace = []
        self.visible = True
        self.closing = False
        self.unexpected = []

    def hold(self, path, actor, status=200, method="GET"):
        item = {"path": path, "actor": actor, "status": status, "method": method,
                "arrived": asyncio.Event(), "release": asyncio.Event(), "used": False}
        self.holds.append(item)
        return item

    async def handle(self, route):
        request = route.request
        url = urlsplit(request.url)
        assert url.scheme + "://" + url.netloc == ORIGIN, request.url
        path, actor = url.path, self.actor
        name = "index.html" if path == "/" else path[1:]
        if name in self.source:
            kind = "text/html" if name.endswith("html") else "text/javascript" if name.endswith("js") else "text/css"
            await route.fulfill(status=200, content_type=kind, body=self.source[name])
            return
        if path == "/api/bo/client.mjs":
            await route.fulfill(status=404, body="Observer unavailable in isolated frontend fixture")
            return
        if path == "/favicon.ico":
            await route.fulfill(status=204)
            return
        status = 200
        if path == "/api/auth/session":
            body = {"user": USERS[self.session_user] if self.session_user else None}
        elif path == "/api/auth/login":
            self.actor = request.post_data_json["username"]
            body = {"user": USERS[self.actor]}
        elif path == "/api/auth/logout":
            self.actor, status, body = None, 204, None
        elif path == "/api/members":
            body = {"members": list(USERS.values())}
        elif path == "/api/files":
            body = file_list(actor, self.visible)
        elif path == "/api/tasks" and request.method == "GET":
            body = {"tasks": [{"id": "simulated-task-" + actor, "name": "simulated-" + actor + "-download.txt",
                    "size": 32, "status": "ready", "created_at": "2026-11-21T00:00:00Z", "last_error": None}]}
        elif path == "/api/tasks" and request.method == "POST":
            status, body = 202, {"task_id": "simulated-task-" + actor}
        elif path == "/api/announcements":
            body = {"announcements": [{"id": "simulated-announcement", "title": "Simulated independent board",
                    "body": "Simulated announcement text", "author_id": "editor", "author_name": USERS["editor"]["display_name"],
                    "updated_at": "2026-11-21T00:00:00Z"}]}
        else:
            self.unexpected.append({"path": path, "method": request.method})
            await route.abort()
            return
        row = {"path": path, "actor_at_request": actor, "method": request.method, "status": status}
        self.trace.append(row)
        hold = next((item for item in self.holds if not item["used"] and item["path"] == path and item["actor"] == actor and item["method"] == request.method), None)
        if hold:
            hold.update(used=True, request=request)
            row["held"] = True
            hold["arrived"].set()
            await hold["release"].wait()
            status = row["status"] = hold["status"]
            if status >= 400:
                body = {"error": "LOGIN_REQUIRED" if status == 401 else "SIMULATED_INITIALIZATION_FAILURE"}
        try:
            if status == 204:
                await route.fulfill(status=204)
            else:
                await route.fulfill(status=status, content_type="application/json", body=json.dumps(body))
            row["fulfilled"] = True
        except PlaywrightError:
            if not self.closing:
                raise


async def arrived(hold):
    await asyncio.wait_for(hold["arrived"].wait(), timeout=10)


async def release(page, hold):
    async with page.expect_response(lambda response: response.request == hold["request"]) as response:
        hold["release"].set()
    await (await response.value).finished()
    # Let fetch/JSON continuations and the next painted DOM settle after the
    # known response boundary. This is not a retry of a negative assertion.
    await page.evaluate("() => new Promise(done => requestAnimationFrame(() => requestAnimationFrame(done)))")


async def submit_login(page, username):
    if await page.locator("#logout").is_visible():
        await page.locator("#logout").click()
    await expect(page.locator("#login-form")).to_be_visible()
    await page.get_by_role("textbox", name="用户名", exact=True).fill(username)
    await page.get_by_role("textbox", name="密码", exact=True).fill("Simulated frontend password")
    await page.get_by_role("button", name="登录", exact=True).click()


async def login(page, username):
    await submit_login(page, username)
    await expect(page.locator("#workspace")).to_be_visible()
    await expect(page.locator("#display-name")).to_have_text(USERS[username]["display_name"])
    await expect(page.locator("#login-form button[type=submit]")).to_be_enabled()


def shared_row(page):
    return page.locator("#file-list").get_by_role("article").filter(has_text="simulated-shared.txt")


async def owner_controls_absent(page):
    await expect(shared_row(page)).to_be_visible()
    assert await shared_row(page).get_by_role("button", name="分享给同事", exact=True).count() == 0


async def account_loading(page, fixture):
    await login(page, "alice")
    members = fixture.hold("/api/members", "bob")
    listing = fixture.hold("/api/files", "bob")
    await submit_login(page, "bob")
    await arrived(members)
    assert not await page.locator("#workspace").is_visible()
    assert await page.locator("#file-list article").count() == 0
    await release(page, members)
    await arrived(listing)
    assert not await page.locator("#workspace").is_visible()
    assert await page.locator("#file-list article").count() == 0
    await release(page, listing)
    await expect(page.locator("#workspace")).to_be_visible()
    # Preserve the original helper's navigation and immediate negative check.
    await page.locator('[data-view="files"]').click()
    await expect(page.get_by_role("heading", name="团队文件", exact=True)).to_be_visible()
    await owner_controls_absent(page)


async def late_old_success(page, fixture):
    await login(page, "alice")
    old = fixture.hold("/api/files", "alice")
    await page.locator("#refresh-files").click()
    await arrived(old)
    await login(page, "bob")
    await owner_controls_absent(page)
    await release(page, old)
    assert await page.locator("#display-name").inner_text() == USERS["bob"]["display_name"]
    await owner_controls_absent(page)
    assert await page.locator("#notice").is_hidden()


async def late_old_401(page, fixture):
    await login(page, "alice")
    old = fixture.hold("/api/files", "alice", status=401)
    await page.locator("#refresh-files").click()
    await arrived(old)
    await login(page, "bob")
    await release(page, old)
    assert await page.locator("#workspace").is_visible()
    assert await page.locator("#display-name").inner_text() == USERS["bob"]["display_name"]
    await owner_controls_absent(page)


async def reverse_list_order(page, fixture, status=200):
    await login(page, "bob")
    old = fixture.hold("/api/files", "bob", status=status)
    await page.locator("#refresh-files").click()
    await arrived(old)
    fixture.visible = False
    await page.locator("#refresh-files").click()
    await expect(page.locator("#file-count")).to_have_text("0 个文件")
    await release(page, old)
    assert await page.locator("#workspace").is_visible()
    assert await page.locator("#file-count").inner_text() == "0 个文件"
    assert await page.locator("#file-list article").count() == 0


async def same_user_relogin(page, fixture):
    await login(page, "alice")
    old = fixture.hold("/api/files", "alice", status=401)
    await page.locator("#refresh-files").click()
    await arrived(old)
    await login(page, "alice")
    await release(page, old)
    assert await page.locator("#workspace").is_visible()
    assert await page.locator("#display-name").inner_text() == USERS["alice"]["display_name"]
    assert await shared_row(page).get_by_role("button", name="分享给同事", exact=True).count() == 1


async def old_download_poll(page, fixture):
    await login(page, "alice")
    await page.locator('[data-view="tasks"]').click()
    await expect(page.locator("#task-list")).to_contain_text("simulated-alice-download.txt")
    old = fixture.hold("/api/tasks", "alice")
    # No manual refresh: wait for the unchanged real1800ms interval to start it.
    await arrived(old)
    await login(page, "bob")
    await expect(page.locator("#task-list")).to_contain_text("simulated-bob-download.txt")
    await release(page, old)
    assert "simulated-alice-download.txt" not in await page.locator("#task-list").inner_text()
    assert "simulated-bob-download.txt" in await page.locator("#task-list").inner_text()


async def initialization_failure(page, fixture, path):
    await login(page, "alice")
    failed = fixture.hold(path, "bob", status=500)
    await submit_login(page, "bob")
    await arrived(failed)
    assert not await page.locator("#workspace").is_visible()
    assert await page.locator("#file-list article").count() == 0
    await release(page, failed)
    await expect(page.locator("#login-error")).not_to_be_empty()
    assert not await page.locator("#workspace").is_visible()
    assert await page.locator("#file-list article").count() == 0
    await login(page, "bob")
    await owner_controls_absent(page)


async def current_401(page, fixture):
    await login(page, "bob")
    expired = fixture.hold("/api/files", "bob", status=401)
    await page.locator("#refresh-files").click()
    await arrived(expired)
    await release(page, expired)
    assert not await page.locator("#workspace").is_visible()
    assert await page.locator("#login-screen").is_visible()
    assert await page.locator("#file-list article").count() == 0
    assert await page.locator("#login-error").inner_text() == "登录已失效，请重新登录。"


async def late_boot_session(page, fixture):
    await arrived(fixture.boot_hold)
    await login(page, "bob")
    await release(page, fixture.boot_hold)
    assert await page.locator("#display-name").inner_text() == USERS["bob"]["display_name"]
    await owner_controls_absent(page)


async def current_401_closes_old_dialog(page, fixture):
    await login(page, "alice")
    expired = fixture.hold("/api/files", "alice", status=401)
    await page.locator("#refresh-files").click()
    await arrived(expired)
    await shared_row(page).get_by_role("button", name="分享给同事", exact=True).click()
    await expect(page.locator("#share-dialog")).to_be_visible()
    await release(page, expired)
    assert not await page.locator("#share-dialog").is_visible()
    assert await page.locator("#share-filename").inner_text() == ""
    assert await page.locator("#share-recipient option").count() == 0
    assert await page.locator("#login-screen").is_visible()


async def editor_form_cleared(page, fixture):
    await login(page, "editor")
    await page.locator('[data-view="board"]').click()
    entry = page.locator("#announcement-list article")
    await expect(entry).to_be_visible()
    await entry.get_by_role("button", name="修改", exact=True).click()
    await expect(page.locator("#announcement-title")).to_have_value("Simulated independent board")
    await login(page, "bob")
    assert await page.locator("#announcement-form").is_hidden()
    assert await page.locator("#announcement-title").input_value() == ""
    assert await page.locator("#announcement-body").input_value() == ""
    assert await entry.get_by_role("button", name="修改", exact=True).count() == 0
    assert "Simulated independent board" in await entry.inner_text()


async def late_mutation_feedback(page, fixture):
    await login(page, "alice")
    old = fixture.hold("/api/tasks", "alice", method="POST")
    await shared_row(page).get_by_role("button", name="准备下载", exact=True).click()
    await arrived(old)
    await login(page, "bob")
    await release(page, old)
    assert await page.locator("#notice").is_hidden()
    await owner_controls_absent(page)


async def ready_account_controls(page, fixture):
    await login(page, "alice")
    assert await shared_row(page).get_by_role("button", name="分享给同事", exact=True).count() == 1
    await login(page, "bob")
    await owner_controls_absent(page)
    assert "同事共享" in await shared_row(page).inner_text()


async def independent_board_controls(page, fixture):
    await login(page, "editor")
    assert await page.locator("#file-list article").count() == 0
    await page.locator('[data-view="board"]').click()
    entry = page.locator("#announcement-list article")
    await expect(entry).to_be_visible()
    assert await entry.get_by_role("button", name="修改", exact=True).count() == 1
    await login(page, "bob")
    assert await entry.get_by_role("button", name="修改", exact=True).count() == 0
    assert "Simulated independent board" in await entry.inner_text()


async def run_case(browser, source, output, name, action):
    fixture = Fixture(source)
    if name == "late_boot_session":
        fixture.session_user = "alice"
        fixture.boot_hold = fixture.hold("/api/auth/session", None)
    context = await browser.new_context(viewport={"width": 1440, "height": 1000})
    await context.route("**/*", fixture.handle)
    page = await context.new_page()
    errors = []
    page.on("pageerror", lambda error: errors.append(str(error)))
    result = {"case": name, "simulated_api_only": True}
    try:
        await page.goto(ORIGIN, wait_until="domcontentloaded")
        await expect(page.locator("#login-form")).to_be_visible()
        await action(page, fixture)
        assert not errors, errors
        assert not fixture.unexpected, fixture.unexpected
        result["passed"] = True
    except Exception as error:
        result.update(passed=False, error_type=type(error).__name__, error=str(error))
    finally:
        result["page_errors"] = errors
        result["unexpected_requests"] = fixture.unexpected
        result["request_trace"] = fixture.trace
        result["screenshot"] = str(output / (name + ".png"))
        await page.screenshot(path=result["screenshot"], full_page=True)
        fixture.closing = True
        for hold in fixture.holds:
            hold["release"].set()
        await context.close()
    print(json.dumps({"case": name, "passed": result["passed"]}), flush=True)
    return result


async def main(args):
    source_root = args.source_root.resolve()
    source_names = {"index.html", "app.css"} | {path.name for path in (source_root / "public").glob("*.js")}
    source = {name: (source_root / "public" / name).read_bytes() for name in sorted(source_names)}
    output = args.out.resolve() if args.out else APP / "review/runtime" / ("frontend-session-checks-" + str(time.time_ns()))
    output.mkdir(parents=True, exist_ok=False)
    cases = [("account_loading", account_loading), ("late_old_success", late_old_success), ("late_old_401", late_old_401),
             ("reverse_list_order", reverse_list_order), ("same_user_relogin", same_user_relogin), ("old_download_poll", old_download_poll),
             ("initialization_members_failure", lambda p, f: initialization_failure(p, f, "/api/members")),
             ("initialization_files_failure", lambda p, f: initialization_failure(p, f, "/api/files")),
             ("current_401", current_401), ("older_same_user_401", lambda p, f: reverse_list_order(p, f, status=401)),
             ("late_boot_session", late_boot_session), ("current_401_closes_dialog", current_401_closes_old_dialog),
             ("editor_form_cleared", editor_form_cleared), ("late_mutation_feedback", late_mutation_feedback),
             ("ready_account_controls", ready_account_controls), ("independent_board_controls", independent_board_controls)]
    async with async_playwright() as playwright:
        browser = await playwright.chromium.launch(channel="chrome", headless=True)
        try:
            results = [await run_case(browser, source, output, name, action) for name, action in cases]
        finally:
            await browser.close()
    result = {"valid": all(case["passed"] for case in results), "checked_at": datetime.now(timezone.utc).isoformat(),
        "scope": "Isolated frontend regression with exact source bytes and explicitly simulated API barriers. No native authorization, business persistence, provider or recording acceptance is claimed.",
        "source_root": str(source_root), "source_sha256": {name: hashlib.sha256(raw).hexdigest() for name, raw in source.items()},
        "original_browser_assertion_not_replaced": True, "browser_closed": True, "cases": results}
    (output / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"valid": result["valid"], "passed": sum(case["passed"] for case in results), "total": len(results), "output": str(output)}))
    return 0 if result["valid"] else 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, default=APP)
    parser.add_argument("--out", type=Path)
    raise SystemExit(asyncio.run(main(parser.parse_args())))
