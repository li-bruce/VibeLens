/** Create the independent board from the existing session, API and safe DOM helpers.
 * @param {object} ui Shared frontend helpers with their current session guards.
 */
export function createAnnouncementBoard(ui) {
  const { state, $, api, checkCurrent, beginRefresh, element, action, notice, time, perform } = ui;
  /** Reset only the announcement composition form. */
  function resetEditor() { state.editId = null; $('announcement-form').reset(); $('editor-mode').textContent = '发布新公告'; $('publish-button').textContent = '发布公告'; $('cancel-edit').hidden = true; }
  /** Render the latest independent board with unchanged editor/authorship controls.
   * @param {number} epoch Local session that owns this list request.
   */
  async function refreshBoard(epoch = state.sessionEpoch) {
    const request = beginRefresh('board', epoch);
    const data = await api('/api/announcements', {}, epoch, request); checkCurrent(epoch, request); $('announcement-list').replaceChildren();
    if (!data.announcements.length) { const empty = element('div', '', 'paper empty'); empty.append(element('strong', '公告板暂时没有消息'), element('p', state.user.editor ? '在右侧发布第一条团队公告。' : '公告编辑员发布后，登录同事即可在这里阅读。')); $('announcement-list').append(empty); }
    for (const entry of data.announcements) {
      const article = element('article', '', 'paper announcement'); article.append(element('span', '团队公告', 'badge'), element('h2', entry.title), element('div', entry.body, 'body-copy'));
      const footer = element('footer', time(entry.updated_at) + ' · ' + entry.author_name);
      if (state.user.editor && entry.author_id === state.user.id) {
        const buttons = element('div');
        buttons.append(action('修改', /** Load this editor-authored announcement into the edit form. */ async () => { checkCurrent(epoch); state.editId = entry.id; $('announcement-title').value = entry.title; $('announcement-body').value = entry.body; $('editor-mode').textContent = '修改自己的公告'; $('publish-button').textContent = '保存修改'; $('cancel-edit').hidden = false; $('announcement-title').focus(); }, 'quiet'));
        buttons.append(action('删除', /** Delete this announcement through the API and refresh the board. */ async () => { await api('/api/announcements/' + entry.id, { method: 'DELETE' }, epoch); checkCurrent(epoch); if (state.editId === entry.id) resetEditor(); notice('公告已删除。'); await refreshBoard(epoch); }, 'quiet')); footer.append(buttons);
      }
      article.append(footer); $('announcement-list').append(article);
    }
  }
  /** Submit the board form using its existing guarded session and API helpers.
   * @param {Event} event Original native submit event and its submitter button.
   */
  function submitAnnouncement(event) {
    event.preventDefault(); return perform(/** Publish or save the editor own announcement through the native API. */ async () => {
      const epoch = state.sessionEpoch, editing = Boolean(state.editId); await api('/api/announcements' + (editing ? '/' + state.editId : ''), jsonRequest(editing ? 'PUT' : 'POST', { title: $('announcement-title').value, body: $('announcement-body').value }), epoch);
      checkCurrent(epoch); resetEditor(); notice(editing ? '公告已修改。' : '公告已发布。'); await refreshBoard(epoch);
    }, event.submitter);
  }
  return { resetEditor, refreshBoard, submitAnnouncement };
}
