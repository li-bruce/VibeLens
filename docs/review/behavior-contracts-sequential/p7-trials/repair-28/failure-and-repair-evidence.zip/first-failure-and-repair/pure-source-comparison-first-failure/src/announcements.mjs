import { randomUUID } from 'node:crypto';

/** Independent announcement operations using the host's shared native boundaries. */
export class AnnouncementService {
  /** Retain shared storage, operation/authorization/state hooks and the public error type.
   * @param {object} service Existing native host whose common hooks retain their original receiver.
   * @param {Function} ErrorType Existing public application error constructor.
   */
  constructor(service, ErrorType) {
    this.store = service.store;
    this.operation = service.operation.bind(service);
    this.authorize = service.authorize.bind(service);
    this.state = service.state.bind(service);
    this.ErrorType = ErrorType;
  }
  /** Read the independent board for authenticated colleagues.
   * @param {object} actor Current authenticated native member; its id determines file/task ownership.
   */
  async announcements(actor) {
    return this.operation('read_announcements', { actor_id: actor.id }, /** Read published announcements after the native membership decision. */ async context => {
      this.authorize('read_announcements', { member: true }, context);
      return { announcements: this.store.all("SELECT a.*,u.display_name AS author_name FROM announcements a JOIN users u ON u.id=a.author_id WHERE a.status='published' ORDER BY a.updated_at DESC") };
    });
  }
  /** Publish one announcement as its designated editor author.
   * @param {object} actor Current authenticated native member; its id determines file/task ownership.
   * @param {string} title Announcement title, bounded to 120 characters.
   * @param {string} body Announcement content, bounded to 8000 characters; observation selects its length.
   */
  async publish(actor, title, body) {
    return this.operation('publish_announcement', { actor_id: actor.id, title, body_length: body.length }, /** Authorize the editor role and persist this new announcement. */ async context => {
      this.authorize('publish_announcement', { member: true, editor: Boolean(actor.editor) }, context);
      this.validateAnnouncement(title, body); const id = randomUUID(), now = new Date().toISOString();
      this.state('announcement', id, { status: 'absent', revision: 0, author_id: actor.id }, null, context);
      this.store.run("INSERT INTO announcements VALUES(?,?,?,?,'published',?,?,1)", id, actor.id, title.trim(), body, now, now);
      const row = this.store.get('SELECT * FROM announcements WHERE id=?', id); this.state('announcement', id, row, 'publish', context, 'absent');
      return { id, author_id: actor.id, title: row.title, status: row.status, revision: row.revision, allowed: true };
    });
  }
  /** Edit/delete only the authenticated editor's own published announcement.
   * @param {object} actor Current authenticated native member; its id determines file/task ownership.
   * @param {string} id Identity of the author's selected announcement.
   * @param {string} action Selected announcement mutation: edit or delete.
   * @param {string} title Announcement title, bounded to 120 characters.
   * @param {string} body Announcement content, bounded to 8000 characters; observation selects its length.
   */
  async mutateAnnouncement(actor, id, action, title = '', body = '') {
    return this.operation(action === 'delete' ? 'delete_announcement' : 'edit_announcement', { actor_id: actor.id, announcement_id: id, action, title, body_length: body.length }, /** Authorize authorship and persist the selected edit or deletion. */ async context => {
      const row = this.store.get('SELECT * FROM announcements WHERE id=?', id); if (!row) throw new this.ErrorType(404, 'ANNOUNCEMENT_NOT_FOUND');
      this.authorize('manage_announcement', { member: true, editor: Boolean(actor.editor), actor: actor.id, author: row.author_id, announcement_state: row.status }, context);
      if (action === 'edit') { this.validateAnnouncement(title, body); this.store.run('UPDATE announcements SET title=?,body=?,updated_at=?,revision=revision+1 WHERE id=?', title.trim(), body, new Date().toISOString(), id); }
      else this.store.run("UPDATE announcements SET status='deleted',updated_at=?,revision=revision+1 WHERE id=?", new Date().toISOString(), id);
      const changed = this.store.get('SELECT * FROM announcements WHERE id=?', id); this.state('announcement', id, changed, action, context, row.status);
      return { id, status: changed.status, revision: changed.revision, allowed: true };
    });
  }
  /** Validate bounded announcement input without rendering it as HTML.
   * @param {string} title Announcement title, bounded to 120 characters.
   * @param {string} body Announcement content, bounded to 8000 characters; observation selects its length.
   */
  validateAnnouncement(title, body) {
    if (!title.trim() || title.length > 120 || !body.trim() || body.length > 8000) throw new this.ErrorType(400, 'INVALID_ANNOUNCEMENT');
  }
}
