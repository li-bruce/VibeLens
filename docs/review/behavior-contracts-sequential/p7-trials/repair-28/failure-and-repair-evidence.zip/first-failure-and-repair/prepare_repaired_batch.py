"""Preserve the complete failed batch and establish one authorized repaired batch."""
from datetime import datetime, timezone
import shutil
import sys
from pathlib import Path
from change_tools import APP, PACK, RUN, CHANGE, load, save, sha

targeted = load(RUN / "recovery-targeted-summary.json")
assert targeted["valid"] and targeted["after_passed"] == 24
failed = load(RUN / "failed-ordinary-original-seal.json")
assert all(sha(APP / name) == value for name, value in failed["new_run_files"].items())
assert all(sha(APP / name) == value for name, value in failed["record_file_sha256"].items())
assert load(RUN / "runtime-ports-after-failed-batch.json")["all_trial_ports_free"]

failure_text = """# Complete first-batch failure and targeted repair

The first ordinary command exited 1. Its subsequent complete canonical post-verify exited 0 with all configured report categories passed. These are separate scopes; that canonical success does not supersede the observed GUI failure. No acceptance was executed.

| Issue | Original evidence | Repair or current boundary |
|---|---|---|
| Announcement publish did not render; edit submission had the same missing dependency | `unified-1795290160/browser-failure.jpg` visibly reports `jsonRequest is not defined`; `browser_acceptance.py:261`; `failed-ordinary-original-seal.json` | The extraction omitted the existing helper at both the factory call and destructuring boundary. Reconnected that same helper in two source lines. Endpoints, permissions, payloads and actions are unchanged. |
| Second recording did not settle on exception cleanup | `90530611914d45309aa5569b407b3923`, status interrupted, 5980 received events, flushed=false, pending=982; original raw failed recording and stop receipt remain | Preserve it as incomplete evidence. No repair, event insertion, retry-selected schedule or successful-recording claim is applied. A later repaired batch must pass both normal stop receipts independently. |
| Configured post-verify missed the announcement form failure | `failed-batch-complete-post-verify/verification.json` versus the original ordinary command exit 1 | The first five commands exercise native business/HTTP/concurrency/queue and project structure; the former sixth checks account isolation, board read/edit-form controls and bootstrap, without submitting publish or save. Added persistent real-DOM POST/PUT/read/DELETE tests to that same sixth command. |
| Pure source comparison did not establish closure dependencies | `pure-core-source-comparison.json` and sealed pure source comparison remain unchanged | The comparison checked moved backend method bodies, public signatures, receiver binding, bootstrap separation and source identity. It did not prove that all free frontend helper names were injected. The original source-only comparison is therefore insufficient for complete announcement GUI equivalence. This repair and persistent tests close that specific missed path. |

The four new cases run through actual page controls and the extracted module with explicitly simulated API responses. On the frozen failed frontend, 22/24 cases pass; publish and edit fail without sending a mutation request. After the two-line helper connection, 24/24 pass, including method, JSON body/content type and final DOM assertions. The original twenty cases and original assertion lines remain. These targeted results are not native persistence or complete ordinary acceptance evidence.

Additional preserved diagnostics: the first full preflight stopped before native commands after canonical database maintenance changed only generated database source identity and project CRLF/LF bytes. The old candidate is exactly reconstructible; schema catalog, tools, framework and execution build did not change. See `candidate-drift-exact-diagnosis.json`. A later static database sync encountered the known sandbox snapshot PermissionError; its failed receipt remains and the unchanged host command passed. Name-check orchestration also stopped before overwriting an already successful receipt; it resumed from that valid receipt.

All original native tests, SDK adapters, command arrays, 180-second limit, 666 capture definitions, native rules/concepts, 35 historical records, old 242 complete SQL rows and revision 405 personal preferences passed independent preservation audits. No installed provider file changed. The first ordinary run demonstrated active-grant preparation and ready-before-revoke with repeat collection; controlled cancellation/new-request/start-before-revoke evidence is separately indexed under `controlled-permission-evidence/index.json` with exact same-run raw events, submitted state frames, SQL fixtures and original assertion lines.

The main session subsequently authorized one complete repaired-source batch in this same chat. It will have a separate sibling evidence directory. Final adoption requires that batch's original ordinary browser command exit 0, complete browser-acceptance success, two consecutive normal settled recordings, full post-verify and independent audits together. If it fails, preserve and summarize before any further ordinary run. Do not accept.
"""
(RUN / "FAILURE_AND_TARGETED_REPAIR.md").write_text(failure_text, encoding="utf-8")

next_run = RUN.parent / "announcement-module-bootstrap-repaired-20261122"
next_run.mkdir(exist_ok=False)
scripts = ["change_tools.py", "runtime_tools.py", "ordinary_browser_once.py", "seal_browser.py", "post_verify.py",
           "audit_recordings.py", "audit_context.py", "audit_preservation.py", "audit_final_preservation.py",
           "audit_controlled_permissions.py", "start_live_services.py", "fresh_live_ui.py"]
for name in scripts:
    shutil.copy2(RUN / name, next_run / name)
helpers = next_run / "change_tools.py"
helper_text = helpers.read_text(encoding="utf-8")
load_context = "The main session finished its product browser batches and explicitly released this repaired-source native slot. The first ordinary batch failed on the missing jsonRequest factory helper, was fully archived, and its canonical post-verify success remains a separately limited result. That source dependency is repaired, persistent original-entrypoint frontend tests now pass 24/24 (22/24 on frozen failed source), and the exact current candidate/build is sealed. Execute one unchanged original ordinary on/off/fault two-recording workload in this repaired batch after six original native commands, with all capacities/180s/666 fields and provider 66efb5e2 unchanged. On another failure summarize the whole batch before any further ordinary run. Leave real services/fresh live history only after successful ordinary and post-verify plus independent audits. Do not accept."
helpers.write_text(helper_text.replace('ENV.pop("VIBELENS_ENDPOINT", None)',
    'ENV.pop("VIBELENS_ENDPOINT", None)\nENV["BO_LOAD_CONTEXT"] = ' + repr(load_context)), encoding="utf-8")
for source, name in (("recovery-static-snapshot.json", "current-static-snapshot.json"),
                     ("recovery-derived-build.json", "derived-build.json"),
                     ("recovery-inspect-ready.json", "inspect-ready-native.json"),
                     ("recovery-targeted-summary.json", "ui-static-preservation.json"),
                     ("provider-files-runtime-baseline.json", "provider-files-runtime-baseline.json")):
    shutil.copy2(RUN / source, next_run / name)
sys.path.insert(0, str(PACK / "scripts"))
from sync_config import config, snapshot
from behavior_model import capture
from bo_observer.model_io import read_model
current = snapshot(APP, config(APP, "sync.json"), load(APP / CHANGE / "baseline.json"))
assert current["id"] == targeted["candidate_id"]
generated = capture(APP, read_model(APP / "bo_stategraph/project.json", project_root=APP))
assert generated == load(next_run / "derived-build.json")
# The exact standard projector used by the original observations command generates
# the current manifest. The manifest is excluded from candidate identity.
save(APP / "manifest.json", generated)
after_generation = snapshot(APP, config(APP, "sync.json"), current)
assert after_generation["id"] == current["id"]
save(next_run / "standard-current-generation.json", {"valid": True,
    "projector": "behavior_model.capture with canonical model_io.read_model, identical to tooling/observe.py",
    "manifest_sha256": sha(APP / "manifest.json"), "candidate_id": current["id"],
    "candidate_unchanged_by_generation": True, "build_id": generated["build_id"],
    "model_snapshot": str(next_run / "current-static-snapshot.json")})
save(next_run / "candidate-build.json", {"candidate_id": targeted["candidate_id"], "build_id": targeted["build_id"],
    "failed_batch_candidate": failed["candidate_build"]["candidate_id"],
    "failed_batch_build": failed["candidate_build"]["build_id"],
    "pure_refactor_candidate": load(RUN / "pure-refactor-comparison.json")["candidate_id"],
    "full_runtime_verified": False, "accept_executed": False})
records = {path.relative_to(APP).as_posix(): sha(path) for path in (APP / "bo_stategraph/data/recordings").glob("*.json")}
assert len(records) == 37
baseline = {"source_hashes": current["files"], "record_hashes": records,
    "database_sha256": sha(APP / "var/db/application.sqlite"),
    "test_commands": load(APP / "sync.json")["test_commands"], "timeout_seconds": 180,
    "personal_view_revision": load(APP / "bo_stategraph/config/views/local.json")["revision"],
    "first_failed_batch": str(RUN), "first_failed_batch_seal_sha256": sha(RUN / "failed-ordinary-original-seal.json"),
    "original_242_row_audit": str(RUN / "final-old-sql-row-preservation.json")}
save(next_run / "runtime-before-seal.json", baseline)
save(next_run / "before-seal.json", baseline)
shutil.copy2(APP / "var/db/application.sqlite", next_run / "database-before.sqlite")
old_model = next_run / "before/bo_stategraph/project.json"
old_model.parent.mkdir(parents=True)
shutil.copy2(RUN / "before/bo_stategraph/project.json", old_model)
authorization = {"authorized": True, "available_to_trial": True,
    "at": datetime.now(timezone.utc).isoformat(), "same_chat": True,
    "authority": "Main session explicitly authorized one repaired-source complete batch after the failure list and targeted seal, without another question.",
    "ordinary_attempts_allowed_in_this_repaired_batch": 1,
    "six_original_commands": True, "timeout_seconds": 180, "provider_change_allowed": False,
    "keep_first_failed_batch_and_post_verify_scope_difference": True, "accept_allowed": False}
save(next_run / "runtime-release.json", authorization)
save(next_run / "runtime-slot-status.json", authorization)
save(RUN / "repaired-batch-handoff.json", {"valid": True, "repaired_run": str(next_run),
    "candidate_id": targeted["candidate_id"], "build_id": targeted["build_id"],
    "failure_list": str(RUN / "FAILURE_AND_TARGETED_REPAIR.md"), "authorized": True})
print({"failed_batch_fully_preserved": True, "targeted_passed": 24,
       "repaired_run": str(next_run), "candidate_id": targeted["candidate_id"], "build_id": targeted["build_id"]}, flush=True)
