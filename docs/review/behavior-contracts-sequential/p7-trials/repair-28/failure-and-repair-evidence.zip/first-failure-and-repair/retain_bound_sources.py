"""Retain shared operation-source identities backed by explicit constructor wiring."""
from copy import deepcopy
from change_tools import APP, RUN, load, save

first = load(RUN / "pure-mapping-refresh.json")
old_nodes = {node["id"]: node for node in load(RUN / "before/bo_stategraph/project.json")["model"]["nodes"]}
envelope = load(APP / "bo_stategraph/project.json")
model = envelope["model"]
current_ids = {node["id"] for node in model["nodes"]}
assert "this.announcementBoard = new AnnouncementService(this, AppError);" in (APP / "src/service.mjs").read_text(encoding="utf-8")
assert "this.operation = service.operation.bind(service);" in (APP / "src/announcements.mjs").read_text(encoding="utf-8")
retained = []
for record in first["dormant_generated_slice_nodes"]:
    node = deepcopy(old_nodes[record["id"]])
    assert node["source"] == {"path": "src/service.mjs", "symbol": "FileService.operation"}
    assert node["parent"] in current_ids and not any(node.get("capture", {}).values())
    assert node["id"] not in current_ids
    node["origin"] = "project-source-binding"
    node["summary"] = "Shared native operation source explicitly bound by AnnouncementService.constructor from the host receiver. The binding is source evidence; actual execution requires runtime observations."
    model["nodes"].append(node)
    retained.append(node["id"])
save(APP / "bo_stategraph/project.json", envelope)
save(RUN / "pure-bound-source-identities.json", {"valid": True, "retained_ids": retained,
    "source": {"path": "src/service.mjs", "symbol": "FileService.operation"},
    "witness": ["FileService.constructor passes this to AnnouncementService", "AnnouncementService.constructor explicitly binds service.operation to that same receiver"],
    "reason": "Keep the existing source-view identities for the actual shared operation function after a statically unresolved dependency-injection boundary. No direct call edge or runtime event is invented.",
    "new_capture_fields": 0, "personal_view_file_written": False})
print({"source_bound_operation_ids_retained": retained, "fabricated_execution_edges": 0}, flush=True)
