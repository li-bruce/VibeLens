"""Seal a concrete targeted repair, then await the separately coordinated final batch."""
from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
import shutil
import sys
from change_tools import APP, PACK, RUN, CHANGE, PY, load, save, sha, run, cli

negative = load(RUN / "announcement-before-controls/result.json")
positive = load(RUN / "announcement-after-controls/result.json")
assert len(negative["cases"]) == len(positive["cases"]) == 24
assert sum(item["passed"] for item in negative["cases"]) == 22
assert {item["case"] for item in negative["cases"] if not item["passed"]} == {"announcement_publish", "announcement_edit"}
assert positive["valid"] and all(item["passed"] for item in positive["cases"])
assert load(RUN / "verify-after-browser.json")["valid"]
save(RUN / "runtime-slot-status.json", {"available_to_trial": False,
    "at": datetime.now(timezone.utc).isoformat(),
    "reason": "Main session requested complete failure list and targeted results first, followed by one coordinated repaired-source final batch. No native workload or services are active here."})
before = load(RUN / "before-seal.json")
old_test = (RUN / "before/tooling/frontend_session_checks.py").read_text(encoding="utf-8")
new_test = (APP / "tooling/frontend_session_checks.py").read_text(encoding="utf-8")
assert Counter(line.strip() for line in old_test.splitlines() if line.strip().startswith("assert ")) <= Counter(line.strip() for line in new_test.splitlines() if line.strip().startswith("assert "))
assert load(APP / "sync.json")["test_commands"] == before["test_commands"]
assert load(APP / "sync.json")["timeout_seconds"] == 180
for name in before["source_hashes"]:
    if name.startswith(("tests/", "integrations/")) or name in ("tooling/browser_acceptance.py", "tooling/unified_browser_run.py"):
        assert sha(APP / name) == before["source_hashes"][name], name
assert sha(APP / "var/db/application.sqlite") == load(RUN / "failed-ordinary-original-seal.json")["actual_database"]["sha256"]
assert sha(APP / "bo_stategraph/config/views/local.json") == load(RUN / "failed-ordinary-original-seal.json")["preferences"]["sha256"]
if not (RUN / "recovery-code-scan.json").exists():
    cli("recovery-code-scan", "bo_code.py", "scan")
assert load(RUN / "recovery-code-scan.json")["valid"]
if not (RUN / "recovery-db-sync-host.json").exists():
    cli("recovery-db-sync-host", "bo_db.py", "sync")
for label, script, args in (("recovery-docs", "bo_code.py", ["docs", "--strict"]),
                            ("recovery-api", "bo_code.py", ["api-check", "--strict"]),
                            ("recovery-name-inventory", "bo_names.py", ["inventory"])):
    if not (RUN / (label + ".json")).exists():
        cli(label, script, *args)
if not (RUN / "recovery-update-names-command.json").exists():
    run("recovery-update-names", [PY, "-B", "-X", "utf8", RUN / "update_names.py", "recovery"])
assert load(RUN / "recovery-names-check.json")["valid"]
inspection = cli("recovery-inspect-before-review", "change_sync.py", "inspect", allow_failure=True)
assert not inspection["errors"] and inspection["review_errors"] == ["review belongs to an older candidate"]
review = load(APP / CHANGE / "review.json")
review["candidate_id"] = inspection["candidate_id"]
review["announcement_dependency_repair"] = {
    "source_fix": "Pass and destructure the existing jsonRequest helper at the extracted frontend factory boundary.",
    "original_failure": "review/runtime/announcement-module-bootstrap-20261122/failed-ordinary-original-seal.json",
    "negative": "review/runtime/announcement-module-bootstrap-20261122/announcement-before-controls/result.json",
    "positive": "review/runtime/announcement-module-bootstrap-20261122/announcement-after-controls/result.json",
    "persistent_regression": "Four real-DOM announcement form/read/delete cases added to existing tooling/frontend_session_checks.py; original command and assertions remain.",
    "scope": "Concrete source repair plus simulated-API real-DOM targeted checks. New-build native/ordinary acceptance has not run; the failed batch is not promoted.",
}
save(APP / CHANGE / "review.json", review)
ready = cli("recovery-inspect-ready", "change_sync.py", "inspect")
assert ready["candidate_id"] == inspection["candidate_id"]
sys.path.insert(0, str(PACK / "scripts"))
from sync_config import snapshot, config
from behavior_model import capture
from bo_observer.model_io import read_model
snapshot_now = snapshot(APP, config(APP, "sync.json"), load(APP / CHANGE / "baseline.json"))
assert snapshot_now["id"] == ready["candidate_id"]
save(RUN / "recovery-static-snapshot.json", snapshot_now)
model = snapshot_now["model"]
old_model = load(RUN / "before/bo_stategraph/project.json")["model"]
fields = lambda value: {(node["id"], direction, key): item for node in value["nodes"] for direction in ("in", "out")
                       for key, item in node.get("capture", {}).get(direction, {}).items()}
assert fields(model) == fields(old_model) and len(fields(model)) == 666
assert all(model[key] == old_model[key] for key in ("machines", "policy", "concepts"))
assert all(sha(APP / name) == value for name, value in before["record_hashes"].items())
assert all(sha(PACK / name) == value for name, value in load(RUN / "provider-files-runtime-baseline.json").items())
build = capture(APP, read_model(APP / "bo_stategraph/project.json", project_root=APP))
save(RUN / "recovery-derived-build.json", build)
out = RUN / "recovery-source"
out.mkdir(exist_ok=False)
for name in snapshot_now["files"]:
    if (APP / name).is_file():
        target = out / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(APP / name, target)
save(RUN / "recovery-targeted-summary.json", {"valid": True, "candidate_id": ready["candidate_id"],
    "build_id": build["build_id"], "canonical_static_inspect_valid": True, "candidate_stable": True,
    "before_passed": 22, "before_failed": 2, "after_passed": 24,
    "new_persistent_cases": [item["case"] for item in positive["cases"] if item["case"].startswith("announcement_")],
    "original_six_command_arrays_unchanged": True, "original_assertions_preserved": True,
    "all_666_capture_definitions_identical": True, "native_state_rules_and_concepts_unchanged": True,
    "provider_unchanged": True, "old_35_recordings_preserved": True,
    "actual_sql_and_preference_bytes_unchanged_during_repair": True,
    "personal_view_revision": load(APP / "bo_stategraph/config/views/local.json")["revision"],
    "ordinary_attempts_total": 1, "repaired_source_full_native_verified": False,
    "repaired_source_ordinary_verified": False, "services_left_running": False, "accept_executed": False,
    "next": "Main session to coordinate one repaired-source batch; require original complete ordinary browser-acceptance successful receipt plus exit code and complete post-verify together."})
print({"targeted_repair_sealed": True, "candidate_id": ready["candidate_id"], "build_id": build["build_id"],
       "targeted_passed": 24, "native_and_ordinary_pending": True, "accept_executed": False}, flush=True)
