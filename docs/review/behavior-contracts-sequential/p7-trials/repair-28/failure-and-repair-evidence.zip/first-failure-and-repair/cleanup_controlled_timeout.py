"""Stop only the timed-out isolated frontend driver's verified process subtree."""
from datetime import datetime, timezone
import json
import subprocess
from change_tools import RUN, save

target = str(RUN / "bootstrap-before-controls").replace("'", "''")
command = "[Console]::OutputEncoding=[System.Text.UTF8Encoding]::new($false); $ErrorActionPreference='Stop'; $taskAll=@(Get-CimInstance Win32_Process); $taskRoots=@($taskAll | Where-Object {$_.Name -eq 'python.exe' -and $_.CommandLine -and $_.CommandLine.Contains('frontend_session_checks.py') -and $_.CommandLine.Contains('" + target + "')}); $taskIds=@($taskRoots.ProcessId); do {$taskNew=@($taskAll | Where-Object {$_.ParentProcessId -in $taskIds -and $_.ProcessId -notin $taskIds}); $taskIds+=@($taskNew.ProcessId)} while ($taskNew.Count -gt 0); $taskOwned=@($taskAll | Where-Object {$_.ProcessId -in $taskIds}); $taskBefore=@($taskOwned | Select-Object ProcessId,ParentProcessId,Name,CreationDate); $taskRootProof=@($taskRoots | Select-Object ProcessId,CommandLine); foreach ($taskItem in $taskOwned | Sort-Object CreationDate -Descending) {Stop-Process -Id $taskItem.ProcessId -Force -ErrorAction SilentlyContinue}; [pscustomobject]@{root_identity=$taskRootProof;only_owned_targets=$taskBefore}|ConvertTo-Json -Depth 5"
result = subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", command], capture_output=True, encoding="utf-8", timeout=30, creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
assert result.returncode == 0, result.stderr
value = json.loads(result.stdout)
save(RUN / "bootstrap-first-timeout-cleanup.json", {"at": datetime.now(timezone.utc).isoformat(),
    "timeout_seconds": 180, "command": "Unchanged frontend_session_checks.py on frozen ui-before source, first four-case extension",
    "logs": ["bootstrap-before-controlled.stdout.log", "bootstrap-before-controlled.stderr.log"],
    "complete_old_cases_passed": 16, "new_cases_completed_failed": 3,
    "fourth_case_result": "Not completed before deadline; module-response fixture synchronization is corrected separately.",
    "verified_owned_process_cleanup": value, "native_services_or_database_used": False,
    "original_timeout_changed": False})
print({"controlled_timeout_preserved": True, "owned_processes_stopped": len(value["only_owned_targets"]), "native_services_used": False}, flush=True)
