"""Review affected inventory names while preserving every existing bilingual label."""
from collections import defaultdict
from copy import deepcopy
import re
import sys
from change_tools import APP, RUN, load, save, cli

stage = sys.argv[1]
inventory = load(RUN / (stage + "-name-inventory.json"))["items"]
original = load(APP / "bo_stategraph/config/semantic-names.json")
document = deepcopy(original)
aliases = load(APP / "bo_stategraph/project.json")["model"].get("presentation", {}).get("node_aliases", {})
reverse = {target: source for source, target in aliases.items()}
known = defaultdict(set)
for item in inventory:
    value = original["names"].get(item["category"], {}).get(item["id"])
    if value:
        known[(item["category"], item.get("code_role"), item.get("label"))].add((value["en"], value["zh-CN"]))
parameters = {
    "actor": ("Current authenticated member", "当前登录成员"), "id": ("Announcement identity", "公告标识"),
    "title": ("Announcement title", "公告标题"), "body": ("Announcement content", "公告内容"),
    "action": ("Edit or delete action", "修改或删除动作"), "context": ("Native operation context", "原生调用上下文"),
    "epoch": ("Interface session generation", "界面会话代次"), "event": ("Form submit event", "表单提交事件"),
    "ui": ("Shared interface helpers", "界面公共方法"), "service": ("Existing native host", "现有原生服务"),
    "ErrorType": ("Public application error type", "公开应用错误类型"),
    "preserveLoginInput": ("Keep initial login input", "保留初始登录输入"),
}
functions = {
    "announcements": ("Read independent announcements", "读取独立公告板"),
    "publish": ("Publish an announcement", "发布公告"),
    "mutateAnnouncement": ("Edit or delete own announcement", "修改或删除自己的公告"),
    "validateAnnouncement": ("Validate announcement input", "检查公告输入"),
    "constructor": ("Connect native announcement hooks", "连接公告原生方法"),
    "createAnnouncementBoard": ("Create announcement interface", "创建公告界面"),
    "resetEditor": ("Reset announcement form", "重置公告编辑表单"),
    "refreshBoard": ("Refresh independent board", "刷新独立公告板"),
    "submitAnnouncement": ("Submit announcement form", "提交公告表单"),
    "notify": ("Publish an existing native fact", "发送已有原生事实"),
    "preserveInput": ("Preserve typed login input", "保留已输入登录内容"),
    "unbind": ("Detach interface listener", "解除界面事件绑定"),
}
def labels(item):
    category, identity, label = item["category"], item["id"], item.get("label", "")
    if category == "nodes" and identity in reverse and reverse[identity] in original["names"].get(category, {}):
        prior = original["names"][category][reverse[identity]]
        return prior["en"], prior["zh-CN"]
    same = known[(category, item.get("code_role"), label)]
    if len(same) == 1:
        return next(iter(same))
    role = item.get("code_role")
    if role == "file":
        return (("Native announcement module", "公告原生模块") if item.get("source", {}).get("path", "").startswith("src/")
                else ("Announcement interface module", "公告界面模块"))
    if role == "class":
        return "Announcement service", "公告服务"
    if role == "parameter":
        assert label in parameters, ("unreviewed_parameter", item["id"], label)
        return parameters[label]
    symbol = item.get("source", {}).get("symbol", label)
    if role in {"function", "reference"}:
        prefix = symbol.split(".<callback:", 1)[0]
        name = prefix.rsplit(".", 1)[-1]
        assert name in functions, ("unreviewed_function", item["id"], symbol)
        en, zh = functions[name]
        return (en + " callback", zh + "回调") if "<callback:" in symbol else (en, zh)
    if role == "unresolved":
        tokens = re.findall(r"[A-Za-z_$][A-Za-z0-9_$]*", label)
        terminal = tokens[-1] if tokens else "reference"
        assert len(terminal) <= 40, ("unreviewed_long_reference", label)
        return "Unresolved · " + terminal, "待解析 · " + terminal
    raise AssertionError(("unreviewed_inventory_item", {key: item.get(key) for key in ("category", "id", "label", "kind", "code_role")}))

added, rebased = [], []
for item in inventory:
    category, identity = item["category"], item["id"]
    entries = document["names"].setdefault(category, {})
    basis = document["basis"].setdefault(category, {})
    if identity not in entries:
        en, zh = labels(item)
        entries[identity] = {"en": en, "zh-CN": zh}
        added.append({"category": category, "id": identity, "source": item.get("source"),
                      "code_role": item.get("code_role"), "labels": entries[identity], "basis": item["basis"]})
    elif basis.get(identity) != item["basis"]:
        rebased.append({"category": category, "id": identity, "source": item.get("source"),
                        "labels_preserved": entries[identity], "old_basis": basis.get(identity), "new_basis": item["basis"]})
    basis[identity] = item["basis"]
for category, values in original["names"].items():
    assert all(document["names"][category][key] == value for key, value in values.items())
assert all(1 <= len(label) <= 60 and "\n" not in label and "\r" not in label
           for values in document["names"].values() for labels in values.values() for label in labels.values())
filename = RUN / (stage + "-names-reviewed.json")
save(filename, document)
save(RUN / (stage + "-name-review.json"), {"valid": True, "all_existing_labels_preserved": True,
    "new_aliases": added, "reviewed_affected_basis_changes": rebased,
    "meaning": "Scoped source/implementation review. Unresolved reference names retain their unresolved status; labels do not create execution facts. Personal preferences are not edited."})
cli(stage + "-names-apply", "bo_names.py", "apply", "--input", filename)
cli(stage + "-names-check", "bo_names.py", "check")
print({"stage": stage, "new_aliases": len(added), "rebased_existing_labels": len(rebased), "existing_labels_changed": 0}, flush=True)
