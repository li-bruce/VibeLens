import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const run = path.dirname(fileURLToPath(import.meta.url));
const app = path.resolve(run, '../../..');
const before = await import(pathToFileURL(path.join(run, 'before/src/service.mjs')).href);
const current = await import(pathToFileURL(path.join(app, 'src/service.mjs')).href);
const { AnnouncementService } = await import(pathToFileURL(path.join(app, 'src/announcements.mjs')).href);
const normalize = value => value.replaceAll('\r\n', '\n').replaceAll('new this.ErrorType(', 'new AppError(');
const methods = ['announcements', 'publish', 'mutateAnnouncement', 'validateAnnouncement'];
for (const name of methods) {
  assert.equal(normalize(AnnouncementService.prototype[name].toString()), normalize(before.FileService.prototype[name].toString()));
  assert.equal(current.FileService.prototype[name].length, before.FileService.prototype[name].length);
}
const host = { store: {}, operation() { return this === host; }, authorize() { return this === host; }, state() { return this === host; } };
const board = new AnnouncementService(host, current.AppError);
assert.equal(board.store, host.store);
assert.equal(board.ErrorType, current.AppError);
assert.ok(board.operation() && board.authorize() && board.state());
const oldUI = await readFile(path.join(run, 'before/public/app.js'), 'utf8');
const newUI = await readFile(path.join(app, 'public/app.js'), 'utf8');
const boot = source => source.split('async function boot()')[1].split("bind('login-form'")[0];
assert.equal(boot(newUI), boot(oldUI));
const result = { valid: true, backend_methods_compared: methods, public_signatures_preserved: true,
  shared_native_hook_receivers_and_error_type_preserved: true, bootstrap_behavior_unchanged: true,
  allowed_text_normalizations: ['CRLF/LF', 'Explicitly retained native error constructor access'],
  scope: 'Read-only implementation/source ownership comparison. No native store, HTTP server, SDK, recording or business-success evidence is produced.' };
await writeFile(path.join(run, 'pure-core-source-comparison.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result));
