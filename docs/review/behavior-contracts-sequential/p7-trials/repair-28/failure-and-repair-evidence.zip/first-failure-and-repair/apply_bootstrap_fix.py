"""Apply the separately authorized input-precedence behavior correction."""
from copy import deepcopy
from change_tools import APP, RUN, CHANGE, load, save, sha

assert load(RUN / "pure-refactor-comparison.json")["valid"]
baseline = load(RUN / "bootstrap-before-v2-controls/result.json")
new_cases = {"bootstrap_input_null", "bootstrap_input_401", "bootstrap_input_existing_session", "bootstrap_input_before_module"}
assert len(baseline["cases"]) == 20
assert all(row["passed"] for row in baseline["cases"] if row["case"] not in new_cases)
assert all(not row["passed"] for row in baseline["cases"] if row["case"] in new_cases)
path = APP / "public/app.js"
text = path.read_text(encoding="utf-8")
old_hash = sha(path)
assert 'function clearAccountUI() {' in text and 'function beginSession() {' in text
text = text.replace('/** Remove account-owned data and feedback before another session may be displayed. */\nfunction clearAccountUI() {',
    '/** Remove account-owned data and feedback before another session may be displayed.\n * @param {boolean} preserveLoginInput Keep initial login input while bootstrap is still deciding the session.\n */\nfunction clearAccountUI(preserveLoginInput = false) {', 1)
text = text.replace("$('chosen-file').textContent = '单个文件最多 50 MB'; $('password').value = ''; $('announcement-form').hidden = true;",
    "$('chosen-file').textContent = '单个文件最多 50 MB'; if (!preserveLoginInput) $('password').value = ''; $('announcement-form').hidden = true;", 1)
text = text.replace('/** Invalidate every prior UI continuation, including a previous login as the same user. */\nfunction beginSession() { state.sessionEpoch++; clearAccountUI(); return state.sessionEpoch; }',
    '/** Invalidate every prior UI continuation, including a previous login as the same user.\n * @param {boolean} preserveLoginInput Keep initial form input only for bootstrap; explicit session changes still clear it.\n */\nfunction beginSession(preserveLoginInput = false) { state.sessionEpoch++; clearAccountUI(preserveLoginInput); return state.sessionEpoch; }', 1)
old = '''async function boot() {
  const epoch = beginSession();
  try { const data = await api('/api/auth/session', {}, epoch); if (data.user) await enter(data.user, epoch); else showLogin(); }
  catch (error) { if (error !== obsoleteResponse && epoch === state.sessionEpoch) showLogin(error.message); }
}'''
new = '''async function boot() {
  const inputs = [$('username'), $('password')];
  const alreadyTyping = $('password').value.length > 0 || $('username').value !== $('username').defaultValue;
  const epoch = beginSession(true);
  if (alreadyTyping) return;
  /** Give actual credential input precedence over the initial automatic session result. */
  const preserveInput = () => { if (epoch === state.sessionEpoch) state.sessionEpoch++; };
  for (const input of inputs) { input.addEventListener('input', preserveInput); input.addEventListener('change', preserveInput); }
  try { const data = await api('/api/auth/session', {}, epoch); if (data.user) await enter(data.user, epoch); else showLogin(); }
  catch (error) { if (error !== obsoleteResponse && epoch === state.sessionEpoch) showLogin(error.message); }
  finally { for (const input of inputs) { input.removeEventListener('input', preserveInput); input.removeEventListener('change', preserveInput); } }
}'''
assert old in text
text = text.replace(old, new, 1)
assert 'function clearAccountUI(preserveLoginInput = false)' in text and 'function beginSession(preserveLoginInput = false)' in text
path.write_text(text, encoding="utf-8", newline="\n")

source_id = "U8_MODULE_BOOTSTRAP"
source_text = "文件共享这部分保持现在确认的行为。公告以后想单独维护，请把发布、修改、删除和读取公告相关实现整理到合适的独立模块，入口、权限和用户操作不变，让图自动跟上文件和函数位置的变化，保留我保存的视图和批注。另把已经复现的登录初始化问题修好：用户开始输入后，不应被迟到的初始会话响应清空密码。"
discovery = load(APP / "discovery.json")
assert not any(item["id"] == source_id for item in discovery["sources"])
discovery["sources"].append({"id": source_id, "kind": "user", "text": source_text,
    "locator": "Actual user requirement forwarded in the current chat, 2026-11-22, source chat 01a1439a-dceb-7ba2-bada-546619caf220. No simulated requirement answer."})
intent = load(APP / "intent.json")
requirement = next(item for item in intent["requirements"] if item["id"] == "R_AUTH")
previous = deepcopy(requirement)
requirement["text"] += " Once a user starts entering login input, a late initial session result must not clear the typed password or replace that login attempt. Initial input entered before optional client initialization is retained."
requirement["source_refs"].append(source_id)
requirement["source"] = "Actual user statements U4 and U8_MODULE_BOOTSTRAP. Native authentication and authorization remain unchanged; U8 adds local login-input precedence."
intent["revision"] = "requirements-4-bootstrap-input"
save(APP / "discovery.json", discovery)
save(APP / "intent.json", intent)
envelope = load(APP / "bo_stategraph/project.json")
envelope["contracts"]["discovery"]["sha256"] = sha(APP / "discovery.json")
save(APP / "bo_stategraph/project.json", envelope)
review = load(APP / CHANGE / "review.json")
review["decisions"]["business"] = {"action": "updated",
    "reason": "Actual user U8 adds local login-input precedence under R_AUTH. Invalidate late initial replies when typing begins and retain pre-bootstrap input. This is a behavior correction, separately evidenced after pure announcement relocation; native file, announcement, authentication and authorization rules remain unchanged."}
review["requirement_changes"] = {"R_AUTH": "Actual user source U8_MODULE_BOOTSTRAP explicitly requires typed password retention against late initialization; four independent controlled DOM counterexamples are added without changing any old assertion."}
review["validation_scope"] = "Pure announcement refactor is separately sealed. Bootstrap input correction is now subject to four negative/positive controlled cases plus all sixteen prior cases, followed by canonical static inspection and one released complete native/browser/recording cycle. No accept."
save(APP / CHANGE / "review.json", review)
save(RUN / "bootstrap-behavior-change.json", {"kind": "authorized UI behavior correction, not pure source refactor", "source_id": source_id,
    "source_text": source_text, "previous_requirement": previous, "current_requirement": requirement,
    "before_app_js_sha256": old_hash, "after_app_js_sha256": sha(path),
    "first_negative_evidence": str(RUN / "bootstrap-before-v2-controls/result.json"),
    "mechanism": "Preserve pre-bootstrap input; actual input invalidates only the pending initial request epoch. Explicit login/logout/current-session 401 retain their existing clearing behavior.",
    "native_business_or_state_rules_changed": False, "capture_fields_added_or_removed": 0,
    "pure_refactor_reference": str(RUN / "pure-refactor-comparison.json")})
print({"bootstrap_fix_applied": True, "requirement": "R_AUTH", "four_failed_counterexamples_preserved": True,
       "native_rules_changed": False, "pure_stage_separate": True}, flush=True)
