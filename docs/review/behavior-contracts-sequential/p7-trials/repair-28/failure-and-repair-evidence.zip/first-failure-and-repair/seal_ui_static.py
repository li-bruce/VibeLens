"""Freeze the final distinct UI correction before released complete native testing."""
from collections import Counter
import shutil
import sys
from change_tools import APP, PACK, RUN, CHANGE, load, save, sha, cli

positive = load(RUN / "bootstrap-final-controls/result.json")
negative = load(RUN / "bootstrap-before-v2-controls/result.json")
assert positive["valid"] and len(positive["cases"]) == 20
assert sum(item["passed"] for item in negative["cases"]) == 16 and len(negative["cases"]) == 20
inspection = load(RUN / "ui-final-inspect-before-review.json")
assert not inspection["errors"] and inspection["review_errors"] == ["review belongs to an older candidate"]
review = load(APP / CHANGE / "review.json")
review["candidate_id"] = inspection["candidate_id"]
review["validation_scope"] = "Pure announcement relocation is independently sealed at candidate 122ad445. The separate actual-user R_AUTH bootstrap input correction passed the original sixteen plus four new controlled DOM cases. All original native tests/fields/bounds remain. Native slot explicitly released; next run six-command verify, one unchanged ordinary dual-recording workflow, complete post-verify and independent audits. No accept."
save(APP / CHANGE / "review.json", review)
ready = cli("inspect-ready-native", "change_sync.py", "inspect")
before = load(RUN / "before-seal.json")
old = load(RUN / "before/bo_stategraph/project.json")["model"]
current = load(APP / "bo_stategraph/project.json")["model"]
def fields(model):
    return {(node["id"], direction, key): value for node in model["nodes"] for direction in ("in", "out")
            for key, value in node.get("capture", {}).get(direction, {}).items()}
assert fields(old) == fields(current) and len(fields(current)) == 666
for key in ("machines", "policy", "concepts"):
    assert old[key] == current[key], key
pure = load(RUN / "pure-refactor-comparison.json")
for name in ("src/service.mjs", "src/announcements.mjs", "public/announcements.js"):
    assert sha(APP / name) == pure["after_hashes"][name], name
unchanged = [name for name in before["source_hashes"] if name.startswith(("tests/", "integrations/"))]
unchanged += ["src/store.mjs", "src/policy.mjs", "src/http.mjs", "src/server.mjs", "behavior.json", "acceptance.json", "mapping.json",
              "tooling/browser_acceptance.py", "tooling/unified_browser_run.py", "bo_stategraph/bo_runtime.mjs",
              "bo_stategraph/bo_capture.mjs", "bo_stategraph/bo_http.mjs", "bo_stategraph/integration.json", "bo_stategraph/config/views/local.json"]
assert all(sha(APP / name) == before["source_hashes"][name] for name in unchanged)
assert sha(APP / "var/db/application.sqlite") == before["database_sha256"]
assert all(sha(APP / name) == digest for name, digest in before["record_hashes"].items())
assert load(APP / "sync.json")["test_commands"] == before["test_commands"]
assert load(APP / "sync.json")["timeout_seconds"] == before["timeout_seconds"] == 180
assert Counter(line.strip() for line in (RUN / "before/tooling/frontend_session_checks.py").read_text(encoding="utf-8").splitlines() if line.strip().startswith("assert ")) <= Counter(line.strip() for line in (APP / "tooling/frontend_session_checks.py").read_text(encoding="utf-8").splitlines() if line.strip().startswith("assert "))
for name in ("ui-final-docs.json", "ui-final-api.json", "ui-final-names-check.json"):
    assert load(RUN / name)["valid"], name
source_names = sorted(set(before["source_hashes"]) | {"src/announcements.mjs", "public/announcements.js"})
out = RUN / "static-after"
out.mkdir(exist_ok=False)
for name in source_names:
    target = out / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(APP / name, target)
provider_baseline = load(before["provider_runtime_file_baseline_reference"])
assert all(sha(PACK / name) == digest for name, digest in provider_baseline.items())
save(RUN / "provider-files-runtime-baseline.json", provider_baseline)
save(RUN / "runtime-before-seal.json", {"source_hashes": {name: sha(APP / name) for name in source_names},
    "record_hashes": before["record_hashes"], "database_sha256": before["database_sha256"],
    "test_commands": before["test_commands"], "timeout_seconds": 180, "personal_view_revision": before["personal_view_revision"]})
sys.path.insert(0, str(PACK / "scripts"))
from bo_observer.model_io import read_model
from behavior_model import capture
build = capture(APP, read_model(APP / "bo_stategraph/project.json", project_root=APP))
save(RUN / "derived-build.json", build)
save(RUN / "candidate-build.json", {"candidate_id": ready["candidate_id"], "build_id": build["build_id"],
    "before_candidate": "23029c5f522edebcaad3c23ee0cbab4397219dae31ced0eb2013813492388c1b",
    "before_build": "150b7a8c49d72b8debd3022d464f516601b471bebd02bd7cc93590cd715c258b",
    "pure_refactor_candidate": pure["candidate_id"], "full_runtime_verified": False, "accept_executed": False})
save(RUN / "ui-static-preservation.json", {"valid": True, "candidate_id": ready["candidate_id"], "build_id": build["build_id"],
    "pure_refactor_separately_sealed": True, "bootstrap_behavior_fix_separately_recorded": True,
    "controlled_before_passed": 16, "controlled_before_failed": 4, "controlled_after_passed": 20,
    "all_original_assertions_preserved": True, "all_666_definitions_identical": True,
    "all_native_state_rule_and_concept_definitions_unchanged": True, "six_commands_unchanged": True,
    "sdk_and_integration_bytes_unchanged": True, "case_timeout_seconds": 180, "provider_files_unchanged": len(provider_baseline),
    "old_records_unchanged": len(before["record_hashes"]), "database_and_current_preferences_byte_equal": True,
    "runtime_gates_pending": True, "runtime_release_explicitly_authorized": True, "accept_executed": False})
print({"static_stage_sealed": True, "candidate_id": ready["candidate_id"], "build_id": build["build_id"],
       "capture_fields": 666, "controlled_cases_passed": 20, "old_records": len(before["record_hashes"])}, flush=True)
