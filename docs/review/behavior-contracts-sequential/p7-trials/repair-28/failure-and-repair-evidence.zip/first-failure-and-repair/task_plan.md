# Announcement modularization and bootstrap UI correction

- [x] Verify prior acceptance, stop owned Node services, release slot for main-session Python.
- [x] Begin from accepted source/model and current preferences (revision 405).
- [x] Seal pure announcement relocation: source/model comparison, 16 original controlled cases, strict docs/API/names/inspect; no login behavior mixed in.
- [x] Preserve first controlled-test fixture timeout and four completed application counterexamples; fix login input precedence.
- [x] Original 16 plus 4 new controlled cases passed after the fix.
- [x] Finish current canonical UI source/mapping/name/inspect refresh and seal static phase.
- [x] Main-session Python completed and stopped; runtime slot explicitly released. No further authorization or new chat is required.
- [x] Run the original six-command full native verify after static gate (all six pass; pre-browser gate retains only 19 expected fresh-browser gaps).
- [x] Execute first original ordinary batch and archive failure; repair missing announcement helper with persistent 24-case regression (22/24 before, 24/24 after).
- [x] Execute the one separately authorized repaired batch; business GUI steps pass, but second normal recording is interrupted with confirmed queue drops 421. Preserve it and stop further ordinary attempts.
- [x] Complete both post-verify batches and independent source/field/SQL/preferences/provider/partial-record audits; preserve exact controlled-case event/frame/SQL index and read-only traffic diagnosis.
- [x] Start only existing actual services at main-session follow-up request, hand off exact C/B/ports/PIDs; no new business action/recording or accept after restart.
- [ ] Main session independent Graph/Timeline/layout/source inspection and isolated collection-channel profiling; any later ordinary batch requires its coordination.

Preserve 666 field definitions, original six command arrays, original capacities and 180-second timeout, all prior raw records and personal views. Do not modify the installed 66efb5e2 provider.

Current handoff: sibling announcement-module-bootstrap-repaired-20261122/HANDOFF.md and FINAL_HANDOFF.json. C 4697073ae0da8a50bec7c4541e5ea35c327c0224e1694b681d0aa99c7f96fab3, B df85427462bd8faf293b740102d40e8be57960a40214efe22894a6d504ec6f55. App listener 13280 / 8925, viewer listener 47540 / 8926, viewer launcher 54968. Canonical post-verify passed; overall ordinary acceptance did not pass. No P7 completion or accept is claimed.
