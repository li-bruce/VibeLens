"""Read existing traffic/health artifacts and unchanged producer/collector source only."""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import json
import shutil
import statistics
from runtime_tools import APP, PACK, RUN, load, save, sha

seal = load(RUN / "failed-ordinary-original-seal.json")
unified = Path(seal["unified_run"])
assert all(sha(APP / name) == value for name, value in seal["new_run_files"].items())
acceptance = load(unified / "browser-acceptance.json")
samples = [json.loads(line) for line in (unified / "native-idle.jsonl").read_text(encoding="utf-8").splitlines()]
timeline = []
for row in samples:
    health = row["health"]
    timeline.append({"wall_ms": row["wall_ms"], "utc": datetime.fromtimestamp(row["wall_ms"] / 1000, timezone.utc).isoformat(),
        "stage": row["stage"], **{key: health.get(key) for key in
            ("enqueued", "pending", "queue_submitted", "queue_completed", "dropped", "errors", "transport_retries", "last_error")}})
save(RUN / "flow-health-timeline.json", timeline)
second_before = next(row for row in acceptance["idle_waits"] if row["stage"] == "after-start-1a56737f20d34900bbecd418eb18836b")
second_stop = next(row for row in acceptance["idle_waits"] if row["stage"] == "before-stop-1a56737f20d34900bbecd418eb18836b")
last_zero = next(row for row in reversed(timeline) if row["dropped"] == 0)
first_drop = next(row for row in timeline if row["dropped"] > 0)
start = second_before["last_health"]
peak = second_stop["first_health"]
end = second_stop["last_health"]
assert start["pending"] == start["dropped"] == 0
assert peak["pending"] == 8256 and peak["dropped"] == 421
assert end["pending"] == 0 and end["dropped"] == 421
interval_s = (second_stop["started_ms"] - second_before["ended_ms"]) / 1000
drain_s = (second_stop["ended_ms"] - second_stop["started_ms"]) / 1000
record = load(unified / "independent-recording-1a56737f20d34900bbecd418eb18836b.json")
native = [event for event in record["events"] if event["producer_id"] == seal["native_health"]["producer_id"]]
system = [json.loads(line) for line in (unified / "system-load.jsonl").read_text(encoding="utf-8").splitlines()]
relevant_load = [row["system_cpu_percent"] for row in system if last_zero["wall_ms"] <= row["wall_ms"] <= second_stop["ended_ms"]]
out = RUN / "flow-source-snapshot"
out.mkdir(exist_ok=False)
paths = ["scripts/bo_observer/adapters/javascript/bo_runtime.mjs", "scripts/bo_observer/service.py",
         "scripts/bo_observer/observation/event_batch.py"]
source_refs = []
for name in paths:
    target = out / Path(name).name
    shutil.copy2(PACK / name, target)
    source_refs.append({"installed_path": str(PACK / name), "sha256": sha(PACK / name), "frozen_copy": str(target)})
summary = {
    "valid_readonly_extraction": True, "ordinary_replay_or_new_instrumentation": False,
    "candidate_id": seal["candidate_build"]["candidate_id"], "build_id": seal["candidate_build"]["build_id"],
    "run": str(unified), "confirmed_failure": "Native producer finite waiting queue overflow: dropped 421, stage queue / type Full. Later flush completed; lost envelopes remain lost and the second recording is interrupted.",
    "configured_limits": {"native_waiting_queue": 8192, "browser_waiting_queue": 4096,
        "native_request_max_events": 64, "native_request_max_bytes": 262144,
        "per_envelope_max_bytes": 24576, "request_deadline_ms": 1000, "request_attempts": 2,
        "native_drain_parallel_groups": 1, "snapshot_barrier": "Separate single-envelope ordered request",
        "failed_group_recovery": "Ordered recursive halves down to single envelopes; no fanout",
        "pending_8256_explanation": "Observed queue is capped at 8192 waiting items plus up to 64 currently in flight. This is not an increased configured queue."},
    "source_references": source_refs,
    "sampled_drop_window": {"last_observed_no_drop": last_zero, "first_observed_drop": first_drop,
        "scope": "Existing health samples bound the observed transition. They do not timestamp each lost envelope."},
    "second_recording_flow": {"after_start_health": start, "before_stop_first_health": peak,
        "after_wait_health": end, "observed_burst_interval_seconds": interval_s,
        "enqueued_counter_delta": peak["enqueued"] - start["enqueued"],
        "completed_envelope_delta": peak["queue_completed"] - start["queue_completed"],
        "completed_per_second_during_observed_burst": (peak["queue_completed"] - start["queue_completed"]) / interval_s,
        "pending_drain_seconds": drain_s,
        "completed_per_second_during_drain": (end["queue_completed"] - peak["queue_completed"]) / drain_s,
        "scope": "Rates are differences of captured envelope counters over wall-clock sample windows; they are not per-request server latencies or exact packet sizes."},
    "second_recording": {"id": record["id"], "status": record["status"], "events_retained": len(record["events"]),
        "native_events_retained": len(native), "top_observed_native_nodes": Counter(event["node"] for event in native).most_common(15),
        "producer_settlement": record["producer_settlement"], "gaps": record["gaps"]},
    "existing_server_request_timing": {"available": False,
        "reason": "The unprofiled original run has producer health polls, stop-request elapsed times, aggregate system CPU and original event observed_at values. Viewer stdout/stderr contain no ingress request timing/access records. No packet-level batch-size or collector-request duration trace was collected. Do not substitute stop elapsed time or backlog-drain time for event-batch server latency.",
        "normal_stop_request_elapsed_ms": [row["elapsed_ms"] for row in load(unified / "browser-stop-receipts.json")],
        "transport_retries_observed": end["transport_retries"],
        "retry_type_or_individual_duration": "Not retained; one retry alone does not establish a timeout cause."},
    "system_load_existing_window": {"samples": len(relevant_load),
        "cpu_percent_min": min(relevant_load) if relevant_load else None,
        "cpu_percent_max": max(relevant_load) if relevant_load else None,
        "cpu_percent_mean": statistics.mean(relevant_load) if relevant_load else None,
        "scope": "Whole-machine aggregate; no per-process or per-function attribution."},
    "source_based_candidates_for_main_session": [
        "bo_runtime.mjs:709-835: serial bounded drain, JSON encoding, 64/256KiB grouping, one-second acknowledgement deadline and ordered group recovery.",
        "service.py:243-247: HTTP events/batch routes to the existing atomic session sink.",
        "event_batch.py:26-66: per-event validation, two source binding checks, cursor copies, acceptance reducers and publication under the session lock. These are candidate measurement locations, not individually proven hotspots."],
    "boundary": "Evidence confirms production exceeded delivery during this burst and the finite source queue overflowed. Existing artifacts cannot divide the latency among client serialization, wire, server validation/source checks, publication and viewer rendering. Provider/capacity/fields/timeout remain unchanged; main session will evaluate its batching channel before any next ordinary run."
}
save(RUN / "flow-bottleneck-diagnosis.json", summary)
lines = [f"| {row['stage']} | {row['utc']} | {row['enqueued']} | {row['pending']} | {row['queue_completed']} | {row['dropped']} | {row['transport_retries']} |" for row in [last_zero, first_drop, timeline[-1]]]
(RUN / "FLOW_DIAGNOSIS.md").write_text("# Read-only observation flow diagnosis\n\n" + summary["confirmed_failure"] + "\n\n"
    + "| Existing sample | UTC | Enqueued | Pending | Completed | Dropped | Retries |\n|---|---|---:|---:|---:|---:|---:|\n" + "\n".join(lines)
    + f"\n\nThe native waiting limit remains 8192, with at most 64 in flight (observed pending 8256). Original batches remain at most 64 events / 256 KiB, per-envelope 24 KiB, one serial group, 1000 ms request deadline and two attempts. Snapshots retain their separate ordered barriers. No limit, field, timeout or retry policy changed.\n\nOver the captured {interval_s:.3f}s burst interval, the enqueued counter rose {peak['enqueued'] - start['enqueued']} and completed envelopes rose {peak['queue_completed'] - start['queue_completed']}. The remaining 8256 pending envelopes drained over {drain_s:.3f}s, approximately {summary['second_recording_flow']['completed_per_second_during_drain']:.1f} completed envelopes/s. Those are sample-window counters, not measured HTTP request latency.\n\n"
    + summary["existing_server_request_timing"]["reason"] + "\n\n"
    + "Candidate measurement locations are the unchanged SDK serial batching/request path, the collector HTTP batch route, and the atomic event_batch reducer (per-event validation, both source binding checks, detached cursor copies and locked publication). Their individual costs are not established by this run. `flow-bottleneck-diagnosis.json` preserves source hashes/copies, exact counters, node distribution, limitations and source references; `flow-health-timeline.json` preserves all 214 original sample points. Original raw run files are unchanged. No business rerun or new profiler was used.\n", encoding="utf-8")
print({"flow_diagnosis_saved": True, "native_waiting_limit": 8192, "dropped": 421,
       "native_batch_limit": 64, "server_request_latencies_available": False,
       "pending_drain_seconds": drain_s, "new_ordinary_run": False}, flush=True)
