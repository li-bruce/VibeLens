"""Report the whole failed repaired batch and the explicitly requested live review services."""
from datetime import datetime, timezone
from pathlib import Path
import shutil
from runtime_tools import APP, RUN, CHANGE, load, save, sha

previous = RUN.parent / "announcement-module-bootstrap-20261122"
identity = load(RUN / "candidate-build.json")
seal = load(RUN / "failed-ordinary-original-seal.json")
post = load(RUN / "verify-after-browser.json")
assert load(RUN / "ordinary-browser-recording-command.json")["exit_code"] == 1
assert load(RUN / "verify-after-browser-command.json")["exit_code"] == 0 and post["valid"]
assert len(post["tests"]) == 6 and all(row["exit_code"] == 0 for row in post["tests"])
audits = {name: load(RUN / filename) for name, filename in {
    "source": "final-source-provider-record-preservation.json", "sql": "final-old-sql-row-preservation.json",
    "preferences": "final-personal-view-preservation.json", "controlled": "controlled-permission-evidence/index.json",
    "partial": "independent-partial-recording-audit.json", "flow": "flow-bottleneck-diagnosis.json"}.items()}
assert all(audits[name]["valid"] for name in ("source", "sql", "preferences", "controlled"))
assert audits["partial"]["audit_completed"] and audits["partial"]["ordinary_workflow_valid"] is False
assert audits["flow"]["valid_readonly_extraction"]
services = load(RUN / "live/services.json")
listeners = load(RUN / "live/listener-identity.json")
ready = load(RUN / "live/service-readiness.json")
assert ready["valid"] and services["diagnostic_review_only"]
assert ready["build_id"] == identity["build_id"] and ready["candidate_id"] == identity["candidate_id"]
records_api = load(RUN / "live/recordings-at-handoff.json")
assert records_api["active"] is None
assert next(row for row in records_api["recordings"] if row["id"] == "1a56737f20d34900bbecd418eb18836b")["status"] == "interrupted"
assert not (APP / CHANGE / "accepted.json").exists()
assert all(sha(APP / name) == value for name, value in seal["record_file_sha256"].items())
assert all(sha(APP / name) == value for name, value in seal["source_files"].items())
out = RUN / "complete-post-verify-originals"
out.mkdir(exist_ok=False)
shutil.copy2(APP / CHANGE / "verification.json", out / "verification.json")
shutil.copy2(APP / CHANGE / "review.json", out / "review.json")
shutil.copytree(APP / CHANGE / "checks", out / "checks")
rows = [{key: row[key] for key in ("id", "status", "events", "closure_valid", "closed_calls", "full_value_context", "metadata_context")}
        for row in audits["partial"]["records"]]
summary = {"handoff_completed": True, "acceptance_valid": False, **identity,
    "full_runtime_verified": False, "canonical_post_verify_valid": True,
    "ordinary_command_exit_code": 1, "post_verify_command_exit_code": 0,
    "six_commands_passed": True, "persistent_frontend_cases_passed": 24,
    "announcement_original_gui_publish_edit_read_delete_passed": True,
    "repaired_ordinary_attempts": 1, "further_ordinary_attempts": 0,
    "native_capture_dropped": 421, "queue_last_error": {"stage": "queue", "type": "Full"},
    "records": rows, "source_provider_sql_preferences_controlled_audits_passed": True,
    "record_files_preserved": len(seal["record_file_sha256"]),
    "capture_fields": audits["source"]["capture_fields"], "provider_files": audits["source"]["full_installed_files_checked"],
    "personal_revision": audits["preferences"]["after_revision"],
    "services_left_running": True, "services_purpose": "Main-session independent Graph/Timeline/layout/source review after failed batch, explicitly requested; not a passed acceptance environment.",
    "listeners": listeners, "new_live_process": ready,
    "actual_sql_snapshot": seal["actual_database"],
    "source_snapshot": str(RUN / "current-static-snapshot.json"),
    "source_snapshot_sha256": sha(RUN / "current-static-snapshot.json"),
    "preferences_snapshot": str(RUN / "live/personal-views-at-handoff.json"),
    "preferences_snapshot_sha256": sha(RUN / "live/personal-views-at-handoff.json"),
    "first_failed_batch": str(previous), "provider_changed": False, "accept_executed": False,
    "at": datetime.now(timezone.utc).isoformat(),
    "next": "Main session inspects independent viewer functions and its isolated collector batch-channel profiling before arranging any further whole ordinary run."}
save(RUN / "FINAL_HANDOFF.json", summary)
save(RUN / "runtime-slot-status.json", {"available_to_trial": False, "released_to_main_session": True,
    "existing_diagnostic_services_retained": True, "further_ordinary_allowed": False,
    "reason": "Both authorized batches completed; second repaired recording has confirmed loss 421. Main session requested only existing services and will assess batching channel before another ordinary run.",
    "listeners": listeners["listeners"]})
app_listener = next(row for row in listeners["listeners"] if row["port"] == 8925)
viewer_listener = next(row for row in listeners["listeners"] if row["port"] == 8926)
table = "\n".join(f"| `{row['id']}` | {row['status']} | {row['events']} | {row['closed_calls']} | {row['closure_valid']} |" for row in rows)
controlled_on = next(row for row in audits["controlled"]["runs"] if row["mode"] == "on")
branches = "\n".join(f"- `{row['branch']}`: task `{row['task_id']}`, SQL `{row['status']}`; exact event IDs, original state frames and SQL fixture: `{row['raw_evidence']}`." for row in controlled_on["branches"])
text = f"""# Repaired batch: failed acceptance, live diagnostic handoff

The ordinary command exited 1. Announcement publishing/editing/reading/deleting now passed its original GUI sequence, but the second normal stop returned an interrupted recording because the native source queue dropped 421 envelopes. Its later flush completed (pending 0); it is not a flush-timeout failure. Complete post-verify subsequently exited 0 with all six configured commands passed. That narrower gate does not supersede the recording failure. No accept was executed and P7 completion is not claimed.

- C: `{identity['candidate_id']}`
- B: `{identity['build_id']}`
- Active change: `{CHANGE}`
- Installed provider: context-closure-skills/vibelens, commit `66efb5e24ae4b702bfa8f0515c90a3f2c2e637c4`, unchanged.
- Original run: `{seal['unified_run']}`. Ordinary receipt: `ordinary-browser-recording-command.json` (exit 1); raw GUI checks/stop receipts/lifecycle remain in that run. Complete gate: `verify-after-browser.json` and its command receipt (exit 0). Immutable full check copy: `complete-post-verify-originals/`.

| Recording | Status | Received events | Closed calls | Complete invocation closure |
|---|---|---:|---:|---|
{table}

The second record `1a56737f20d34900bbecd418eb18836b` remains interrupted in its unchanged raw file and in `/api/recordings`. It has 2000 full-value context events plus two metadata-only boundaries matching the first original. All parent references and retained typed frame/event identities are valid, but `api_files` and `list_files` have two invocation-without-exit errors; physical invocation closure is incomplete. No lost event, exit, frame or business outcome was filled in.

Failure details and traffic evidence:

- Before its stop wait: enqueued 11799, submitted 11418, completed 3162, pending 8256, dropped 421, queue/Full. The source limit remains 8192 waiting plus up to 64 in flight. End of wait: completed 11418, pending 0, dropped still 421, one transport retry. Record stop settlement later flushed its frozen prefix successfully; queue loss remains a gap.
- Captured second-burst sample window: 3.701s, enqueued-counter +9376, completed +731. Remaining pending 8256 drained over 29.468s, about 280.2 completed envelopes/s. These are counter-window rates, not measured HTTP request latencies.
- SDK batches remain at most 64 events / 256 KiB; one serial group, each envelope at most 24 KiB; 1000 ms request deadline, two attempts; snapshots are separate ordered barriers. No capacity, selected field, timeout, assertion or provider file changed.
- `FLOW_DIAGNOSIS.md`, `flow-bottleneck-diagnosis.json` and `flow-health-timeline.json` preserve existing source limits/hashes, all 214 health samples, stop elapsed times, system CPU observations, node distribution and candidate code locations. The unprofiled run did not retain ingress HTTP batch sizes or per-request server duration. This missing timing is explicit; no new profiler or business replay was run. Serial SDK delivery and the collector's atomic validator/source-binding/cursor-publication path are measurement candidates, not individually proven hotspots.

The earlier missing jsonRequest helper was corrected in the app factory call and module destructuring without changing endpoints, permissions, payloads or actions. Persistent tests use actual page form controls against labeled simulated API responses. Frozen failed frontend: 22/24; fixed frontend: 24/24. The original sixth command now runs all 24 cases; original six arrays, previous twenty cases and old assertions remain. This batch additionally passed `independent_board_publish_edit_read_delete` in the unchanged real GUI workflow.

Independent completed items: all 666 field definitions, 647 model nodes, native state rules/concepts, 2781 provider files, SDK/native test/source bytes, original six arrays and 180-second limit; all 37 records preceding this repaired batch (including first-batch failure), all 39 raw files after it; all 254 prior full SQL rows and revision 405 preferences, with no preference value changes. The first batch separately proves all original 242 rows unchanged, and this batch preserves that later superset. On/off/fault stored file/prepared bytes and Bob's two repeat collections independently match. The interrupted record is explicitly excluded from any complete recording pass. Audit originals: `final-source-provider-record-preservation.json`, `final-old-sql-row-preservation.json`, `final-personal-view-preservation.json`, `independent-partial-recording-audit.json`.

The ordinary recipient schedule was active-grant preparation and ready before revoke, with repeated byte-identical collection after revoke; it does not demonstrate cancellation. Existing controlled cases remain separately evidenced on/off/fault with exact same-run native facts:

{branches}

`controlled-permission-evidence/index.json` includes raw start-check/commit/guard/state-value IDs, submitted state frames, independent SQL fixture rows/hashes, original source assertion lines, cancelled-task no-revival and ordered start-before-revoke finish. No additional demonstration recording was created.

At the main session's explicit follow-up request, only the existing actual-data app and viewer were restarted for independent Graph/Timeline/layout/source review:

- App `http://127.0.0.1:8925/`, actual listener PID `{app_listener['pid']}`.
- Viewer `http://127.0.0.1:8926/graph`, actual listener PID `{viewer_listener['pid']}`, launcher PID `{listeners['viewer_launcher_pid']}`. Exact commands/parents are in `live/listener-identity.json`; startup receipt in `live/services.json`.
- Current binding is current; C/B match above; no recording active. New process run `{ready['run_id']}`, producer `{ready['producer_id']}`, initial actual live events {ready['live_events']}. New process health has dropped 0; this does not change prior dropped 421 or make the old record complete.
- No additional login/file-list business action, ordinary workload, recording or accept was executed after restart. Main session owns the independent desktop checks. Source snapshot: `current-static-snapshot.json`; exact frozen source: `failed-ordinary-originals/source/`; actual SQL snapshot: `failed-ordinary-originals/application.sqlite`; views snapshot: `live/personal-views-at-handoff.json`. Hashes are bound in `FINAL_HANDOFF.json` and the original failure seal.

The complete first failure, original interrupted record and limited-scope post-verify success remain in `{previous}` and `FAILURE_AND_TARGETED_REPAIR.md`. No old failure was overwritten. The main session is profiling the collection entry on an isolated copy. Wait for that review and explicit coordination before any further ordinary run; do not accept or stop these requested live services autonomously.
"""
# Compute the exact previous-row count rather than relying on a rounded narrative.
prior_rows = sum(row["original_rows"] for row in audits["sql"]["tables"])
text = text.replace("all 254 prior full SQL rows", f"all {prior_rows} prior full SQL rows")
(RUN / "HANDOFF.md").write_text(text, encoding="utf-8")
with (previous / "progress.md").open("a", encoding="utf-8") as stream:
    stream.write("\n\nRepaired batch completed at C 4697073a / B df854274. Six native and post commands passed; original GUI announcement flow passed. Its one ordinary attempt exited 1 at the second normal stop: source queue Full dropped 421, later flush complete; raw record remains interrupted. Independent source/666/provider/SQL/preferences/controlled and partial recording audits completed. Exact traffic limits/timeline and missing request-duration evidence are frozen. Existing actual services were restarted only at main-session request for independent viewer checks; no further ordinary run or accept. See sibling announcement-module-bootstrap-repaired-20261122/HANDOFF.md.\n")
print({"failed_batch_handoff_complete": True, "acceptance_valid": False,
    "candidate_id": identity["candidate_id"], "build_id": identity["build_id"],
    "app_pid": app_listener["pid"], "viewer_listener_pid": viewer_listener["pid"],
    "viewer_launcher_pid": listeners["viewer_launcher_pid"], "services_left_running": True,
    "further_ordinary_runs": 0, "accept_executed": False}, flush=True)
