"""Audit retained identities and SQL bytes without promoting an interrupted recording."""
from collections import Counter
from contextlib import closing
from pathlib import Path
import hashlib
import sqlite3
import sys
from runtime_tools import APP, PACK, RUN, load, save, sha

seal = load(RUN / "failed-ordinary-original-seal.json")
unified = Path(seal["unified_run"])
assert all(sha(APP / name) == value for name, value in seal["new_run_files"].items())
assert all(sha(APP / name) == value for name, value in seal["record_file_sha256"].items())
sys.path.insert(0, str(PACK / "scripts"))
from bo_observer.workflow.observation_requirements import invocation_closure
from bo_observer.model_io import read_model
model = read_model(APP / "bo_stategraph/project.json", project_root=APP)
prior = {}
results = []
for number, ident in enumerate(("b437c31c7a984b44af4bf4739a602fe3", "1a56737f20d34900bbecd418eb18836b")):
    original = unified / ("independent-recording-" + ident + ".json")
    record = load(original)
    closure = invocation_closure({"runs": [{"case": ident, "mode": "on", "events": record["events"]}]}, required=True, model=model)
    context = record["context"]["events"]
    combined = {event["id"]: event for event in [*context, *record["events"]]}
    missing = [{"event_id": event["id"], "parent_event_id": event["parent_event_id"]} for event in combined.values()
               if event.get("parent_event_id") and event["parent_event_id"] not in combined]
    headers = [event for event in context if event.get("context_only")]
    compared = []
    omitted = {"context_only", "context_boundary", "inputs", "outputs", "depends", "basis", "revision", "provenance", "exception"}
    for event in headers:
        assert event["inputs"] == event["outputs"] == event["basis"] == {} and event["depends"] == []
        if number:
            original_event = prior[event["id"]]
            assert {k: v for k, v in event.items() if k not in omitted} == {k: v for k, v in original_event.items() if k not in omitted}
            compared.append(event["id"])
    assert record["context_selection"]["recent_value_limit"] == 2000
    assert len(context) - len(headers) <= 2000
    by_id = {event["id"]: event for event in record["events"]}
    frames = record["runtime_frames"]["frames"]
    for frame in frames:
        event = by_id[frame["event_id"]]
        assert frame["build_id"] == event["build_id"] == seal["candidate_build"]["build_id"]
        assert frame["run_id"] == event["run_id"]
    if number == 0:
        assert record["status"] == "stopped" and record["gaps"] == [] and closure["valid"]
    else:
        assert record["status"] == "interrupted" and record["gaps"]
        assert record["producer_settlement"]["flushed"] and record["producer_settlement"]["pending"] == 0
    results.append({"id": ident, "original": str(original), "status": record["status"], "events": len(record["events"]),
        "gaps": record["gaps"], "producer_settlement": record["producer_settlement"],
        "closure_valid": closure["valid"], "closed_calls": closure["closed_calls"], "closure_errors": closure["errors"],
        "typed_runtime_frames": len(frames), "retained_frame_event_identities_valid": True,
        "full_value_context": len(context) - len(headers), "metadata_context": len(headers),
        "context_selection": record["context_selection"], "metadata_matches_previous_original": compared,
        "missing_parent_references": missing})
    prior.update(combined)

image = Path(seal["actual_database"]["path"]).read_bytes()
def connect(raw):
    db = sqlite3.connect(":memory:")
    db.deserialize(raw)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA query_only=ON")
    return db
trials = load(unified / "artifacts/browser-trials.json")
modes = []
for mode, trial in trials["modes"].items():
    root = Path(trial["data_root"])
    raw = image if mode == "on" else (root / "db/application.sqlite").read_bytes()
    with closing(connect(raw)) as db:
        file = dict(db.execute("SELECT * FROM files WHERE id=?", (trial["fixture_file_id"],)).fetchone())
        task = dict(db.execute("SELECT * FROM tasks WHERE file_id=? AND requester_id='alice' ORDER BY created_at DESC LIMIT 1", (file["id"],)).fetchone())
    assert task["status"] == "ready" and task["authorized_at_submission"] == 1
    assert sha(Path(file["storage_path"])) == sha(Path(task["prepared_path"])) == file["sha256"] == task["sha256"] == trials["sha256"]
    modes.append({"mode": mode, "database_sha256": hashlib.sha256(raw).hexdigest(),
                  "file_id": file["id"], "task_id": task["id"], "status": task["status"], "sha256": task["sha256"]})
acceptance = load(unified / "browser-acceptance.json")
order = next(row for row in acceptance["ordinary_worker_order"] if row.get("case") == "ordinary_recipient_ready_before_revoke")
with closing(connect(image)) as db:
    task = dict(db.execute("SELECT * FROM tasks WHERE id=?", (order["task_id"],)).fetchone())
    grant = dict(db.execute("SELECT * FROM grants WHERE file_id=? AND recipient_id='bob'", (task["file_id"],)).fetchone())
assert task["status"] == "ready" and grant["active"] == 0 and order["grant"]["active"] == 1
hashes = [sha(Path(filename)) for filename in acceptance["repeat_downloads"]]
assert hashes == [task["sha256"]] * 2
save(RUN / "independent-partial-recording-audit.json", {"audit_completed": True,
    "ordinary_workflow_valid": False, "source_build": seal["candidate_build"], "records": results,
    "independent_persisted_mode_bytes": modes, "on_off_fault_business_and_bytes_equal": True,
    "ordinary_recipient_scope": "Actual active-grant preparation and ready before revoke, followed by byte-identical repeated collection. This is separate from controlled cancellation.",
    "ordinary_recipient_task_id": task["id"], "repeat_download_sha256": hashes,
    "announcement_gui_flow_passed": acceptance["checks"]["independent_board_publish_edit_read_delete"],
    "complete_gui_acceptance_valid": False, "native_dropped": seal["native_health"]["dropped"],
    "all_original_bytes_preserved": True, "no_event_or_frame_reconstruction": True, "accept_executed": False})
print({"partial_recording_audit_completed": True, "ordinary_valid": False,
    "records": [{key: row[key] for key in ("id", "status", "events", "closure_valid", "closed_calls", "full_value_context", "metadata_context")} for row in results],
    "three_modes_independent_sql_bytes_valid": True, "repeat_bytes_valid": True}, flush=True)
