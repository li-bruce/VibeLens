"""Preserve the one repaired ordinary attempt before independent post-failure work."""
from datetime import datetime, timezone
from pathlib import Path
import shutil
from runtime_tools import APP, RUN, CHANGE, load, save, sha

assert load(RUN / "ordinary-browser-recording-command.json")["exit_code"] == 1
unified = Path(load(APP / "review/runtime/latest-unified-run.json")["path"])
assert unified.name == "unified-1795291546"
out = RUN / "failed-ordinary-originals"
out.mkdir(exist_ok=False)
for name in ("lifecycle.json", "browser-acceptance.json", "browser-stop-receipts.json"):
    shutil.copy2(unified / name, out / name)
for path in unified.glob("browser-failure-*.json"):
    shutil.copy2(path, out / path.name)
for name in ("verification.json", "review.json"):
    shutil.copy2(APP / CHANGE / name, out / name)
shutil.copy2(APP / "var/db/application.sqlite", out / "application.sqlite")
shutil.copy2(APP / "bo_stategraph/config/views/local.json", out / "personal-views.json")
snapshot = load(RUN / "current-static-snapshot.json")
for name in snapshot["files"]:
    if (APP / name).is_file():
        target = out / "source" / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(APP / name, target)
acceptance = load(unified / "browser-acceptance.json")
lifecycle = load(unified / "lifecycle.json")
health = lifecycle["pre_cleanup_native_health"]
assert acceptance["checks"]["independent_board_publish_edit_read_delete"]
assert health["dropped"] == 421 and health["last_error"] == {"stage": "queue", "type": "Full"}
record_summaries = []
for path in sorted(unified.glob("independent-recording-*.json")):
    record = load(path)
    record_summaries.append({"id": record["id"], "path": str(path), "sha256": sha(path),
        "status": record["status"], "events": len(record["events"]), "gaps": record["gaps"],
        "producer_settlement": record["producer_settlement"]})
assert len(record_summaries) == 2
save(RUN / "failed-ordinary-original-seal.json", {"sealed_at": datetime.now(timezone.utc).isoformat(),
    "candidate_build": load(RUN / "candidate-build.json"), "unified_run": str(unified),
    "repaired_ordinary_attempts": 1, "rerun_after_this_failure": False, "exit_code": 1,
    "failure": "browser_acceptance.py:276 -> stop_record:140; normal stop returned an interrupted second recording with producer capture/transport gap",
    "business_ui_checks": acceptance["checks"], "announcement_fix_native_gui_path_passed": True,
    "native_health": health, "recordings": record_summaries,
    "source_snapshot": str(out / "source"), "source_files": snapshot["files"],
    "new_run_files": {path.relative_to(APP).as_posix(): sha(path) for path in unified.rglob("*") if path.is_file()},
    "record_file_sha256": {path.relative_to(APP).as_posix(): sha(path) for path in (APP / "bo_stategraph/data/recordings").glob("*.json")},
    "actual_database": {"path": str(out / "application.sqlite"), "sha256": sha(out / "application.sqlite")},
    "preferences": {"path": str(out / "personal-views.json"), "sha256": sha(out / "personal-views.json"),
                    "revision": load(out / "personal-views.json")["revision"]},
    "preserve_capacities_timeout_assertions_provider": True, "accept_executed": False,
    "next": "Complete this batch's original post-verify and independent valid-prerequisite audits. No new ordinary run, provider patch or claimed final adoption."})
print({"repaired_failure_sealed": True, "announcement_gui_passed": True, "dropped": health["dropped"],
       "records": [{k: row[k] for k in ("id", "status", "events")} for row in record_summaries],
       "another_ordinary_attempt": False}, flush=True)
