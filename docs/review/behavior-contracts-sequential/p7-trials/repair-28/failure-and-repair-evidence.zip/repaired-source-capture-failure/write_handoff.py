"""Write a result-bound handoff only after ordinary, post-verify and live checks pass."""
from datetime import datetime, timezone
from pathlib import Path
from runtime_tools import APP, RUN, CHANGE, load, save, sha

previous = RUN.parent / "announcement-module-bootstrap-20261122"
identity = load(RUN / "candidate-build.json")
ordinary = load(RUN / "ordinary-browser-recording-command.json")
post = load(RUN / "verify-after-browser.json")
post_command = load(RUN / "verify-after-browser-command.json")
seal = load(RUN / "normal-stop-original-seal.json")
audits = {name: load(RUN / filename) for name, filename in {
    "recordings": "independent-recording-audit.json", "context": "independent-context-closure-audit.json",
    "sources": "final-source-provider-record-preservation.json", "sql": "final-old-sql-row-preservation.json",
    "preferences": "final-personal-view-preservation.json", "controlled": "controlled-permission-evidence/index.json"}.items()}
assert ordinary["exit_code"] == post_command["exit_code"] == 0 and post["valid"]
assert all(item["exit_code"] == 0 for item in post["tests"]) and len(post["tests"]) == 6
assert audits["recordings"]["targeted_audit_valid"]
assert all(audits[name]["valid"] for name in ("context", "sources", "sql", "preferences", "controlled"))
assert all(seal["checks"].values()) and len(seal["recordings"]) == 2
assert all(row["status"] == "stopped" and row["gaps"] == [] and row["settlement"]["flushed"] and row["settlement"]["pending"] == 0 for row in seal["recordings"])
live = load(RUN / "live/fresh-live-ui-summary.json")
listeners = load(RUN / "live/listener-identity.json")
assert live["valid"] and live["services_left_running"] and live["recording_active"] is None
assert identity["candidate_id"] == post["candidate_id"] == live["candidate_id"]
assert identity["build_id"] == seal["build_id"] == live["build_id"]
assert not (APP / CHANGE / "accepted.json").exists()
assert all(sha(APP / name) == value for name, value in seal["record_file_sha256"].items())
assert all(sha(APP / name) == value for name, value in load(previous / "failed-ordinary-original-seal.json")["record_file_sha256"].items())
view = load(APP / "bo_stategraph/config/views/local.json")
save(RUN / "live/personal-views-at-handoff.json", view)
record_summary = [{"id": row["id"], "status": row["status"], "events": row["events"],
                   "closed_calls": next(item["closed_calls"] for item in audits["recordings"]["records"] if item["id"] == row["id"]),
                   "settlement": row["settlement"]} for row in seal["recordings"]]
result = {"valid": True, "at": datetime.now(timezone.utc).isoformat(), **identity,
    "full_runtime_verified": True, "ordinary_command_exit_code": ordinary["exit_code"],
    "full_post_verify_exit_code": post_command["exit_code"], "six_post_commands_passed": True,
    "complete_original_browser_acceptance_passed": True, "recordings": record_summary,
    "listeners": listeners, "live_history": {key: live[key] for key in
        ("new_live_events", "new_native_events", "run_id", "producer_id", "dom", "recording_active")},
    "personal_view_revision": view["revision"], "personal_view_sha256": sha(APP / "bo_stategraph/config/views/local.json"),
    "source_snapshot": str(RUN / "current-static-snapshot.json"),
    "source_snapshot_sha256": sha(RUN / "current-static-snapshot.json"),
    "capture_fields": audits["sources"]["capture_fields"], "model_nodes": audits["sources"]["model_nodes"],
    "provider_files_preserved": audits["sources"]["full_installed_files_checked"],
    "old_records_preserved_in_repaired_batch": audits["sources"]["old_recordings_checked"],
    "first_failed_batch": str(previous), "first_failed_ordinary_exit_code": 1,
    "first_failed_batch_post_verify_passed_with_limited_scope": True,
    "all_first_failed_batch_raw_records_preserved": True,
    "ordinary_repaired_attempts": 1, "accept_executed": False,
    "next": "Main session independent desktop/source/preference inspection, then its own canonical accept/check if satisfied."}
save(RUN / "FINAL_HANDOFF.json", result)
controlled_on = next(item for item in audits["controlled"]["runs"] if item["mode"] == "on")
ordinary_acceptance = load(Path(seal["unified_run"]) / "artifacts/browser-acceptance.json")
order = next(item for item in ordinary_acceptance["ordinary_worker_order"] if item.get("case") == "ordinary_recipient_ready_before_revoke")
rows = [f"| `{item['id']}` | {item['events']} | {item['closed_calls']} | stopped / flushed / pending 0 |" for item in record_summary]
branches = []
for item in controlled_on["branches"]:
    terminal = item["state_frames"][-1]
    branches.append(f"- `{item['branch']}`: task `{item['task_id']}`, terminal `{item['status']}`; frame `{terminal['evidence_id']}`. Exact check/commit/guard/state-value event IDs, raw submitted frames and independent SQL fixture: `{item['raw_evidence']}`.")
text = f"""# Repaired batch handoff

The repaired source passed the unchanged original ordinary browser command (exit 0), every original browser-acceptance step, two consecutive normal settled recordings and complete post-verify (exit 0; six commands all exit 0). Independent source/capture/provider/SQL/preferences/record/context audits passed. Services and distinct fresh actual live history remain available for main-session desktop review. No accept was executed.

- Candidate C: `{identity['candidate_id']}`
- Build B: `{identity['build_id']}`
- Active change: `{CHANGE}`
- Provider: installed context-closure-skills/vibelens, commit `66efb5e24ae4b702bfa8f0515c90a3f2c2e637c4`, unchanged.
- App: `http://127.0.0.1:8925/`; graph: `http://127.0.0.1:8926/graph`. Actual listener/parent PIDs and process commands are in `live/listener-identity.json`; launcher receipt remains separately in `live/services.json`.
- Manifest/current source identity: `standard-current-generation.json`, `candidate-build.json`, `current-static-snapshot.json`. Affected actual source copy: `after-source/`. Personal views snapshot and SHA: `live/personal-views-at-handoff.json`, `FINAL_HANDOFF.json`; revision {view['revision']}.

| Recording | Events | Closed calls | Settlement |
|---|---:|---:|---|
{chr(10).join(rows)}

Raw ordinary run: `{seal['unified_run']}`. Original successful command receipt is `ordinary-browser-recording-command.json`; full GUI result is that run's `artifacts/browser-acceptance.json`; both normal stop receipts and untouched exports remain there. `verify-after-browser.json` plus its command receipt is the separate complete canonical gate. `normal-stop-original-seal.json` binds raw hashes and the actual database image. No profile, timeout/capacity change or schedule-selected retry was used.

The ordinary recipient task `{order['task_id']}` was checked while queued with its actual grant active, started successfully and was ready before revoke. Repeated collection after revoke returned the exact persisted prepared bytes. This is reported separately from controlled cancellation; it does not prove the revoked-at-start branch.

Existing controlled native evidence, using the current build and same-run fixture/SQL identities:

{chr(10).join(branches)}

`controlled-permission-evidence/index.json` also includes on/off/fault SQL checks, cancelled-task no-revival, exact source assertion lines and explicit start/revoke/finish order. These are controlled cases, not additional ordinary recordings.

Preservation: {audits['sources']['capture_fields']} identical capture definitions, {audits['sources']['model_nodes']} model nodes, {audits['sources']['full_installed_files_checked']} installed provider files, all {audits['sources']['old_recordings_checked']} records preceding this repaired batch (including the prior interrupted recording), native source/SDK tests, six command arrays and 180-second limit. Original 242-row proof is in the first batch; this batch compares every full row in its later baseline and final live audit. Context limit remains 2000 full-value events; metadata boundaries match witnessed originals and all parents remain referentially closed. Independent audit files provide actual counts and any permitted camera roundoff.

Fresh live evidence: `live/fresh-live-ui-summary.json`, `live/new-live-events.json`, native health, HTTP/DOM snapshots and screenshot. It comes from a new real Chrome login and file-list refresh against actual var data, with a new native run/producer. It is not recording replay and does not add a demonstration recording. New live events: {live['new_live_events']}, native: {live['new_native_events']}; run `{live['run_id']}`, producer `{live['producer_id']}`. No recording is active.

The first batch remains in `{previous}`. Its ordinary exit 1, visible jsonRequest failure, interrupted second recording (pending 982), and subsequent limited-scope post-verify exit 0 are preserved and described in `FAILURE_AND_TARGETED_REPAIR.md`. The two-line helper fix has persistent real-page publish/edit/read/delete regression coverage in the unchanged sixth command: frozen failed frontend 22/24, fixed frontend 24/24. Original twenty cases and assertions remain. This successful repaired batch does not rewrite that failure as a pass.

Main session next: independently inspect actual page, graph/source locations, historical/interrupted/current recordings, field values, saved views and annotations; then perform its own canonical accept/check if satisfied. Leave current services running until the main session coordinates their stop. P7 completion is not claimed by this handoff.
"""
(RUN / "HANDOFF.md").write_text(text, encoding="utf-8")
print({"handoff_ready": True, "candidate_id": identity["candidate_id"], "build_id": identity["build_id"],
       "recordings": record_summary, "services_left_running": True, "accept_executed": False}, flush=True)
