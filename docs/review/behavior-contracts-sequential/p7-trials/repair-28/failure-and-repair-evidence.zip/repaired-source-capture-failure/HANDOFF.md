# Repaired batch: failed acceptance, live diagnostic handoff

The ordinary command exited 1. Announcement publishing/editing/reading/deleting now passed its original GUI sequence, but the second normal stop returned an interrupted recording because the native source queue dropped 421 envelopes. Its later flush completed (pending 0); it is not a flush-timeout failure. Complete post-verify subsequently exited 0 with all six configured commands passed. That narrower gate does not supersede the recording failure. No accept was executed and P7 completion is not claimed.

- C: `4697073ae0da8a50bec7c4541e5ea35c327c0224e1694b681d0aa99c7f96fab3`
- B: `df85427462bd8faf293b740102d40e8be57960a40214efe22894a6d504ec6f55`
- Active change: `.stategraph/announcement-module-bootstrap-20261122`
- Installed provider: context-closure-skills/vibelens, commit `66efb5e24ae4b702bfa8f0515c90a3f2c2e637c4`, unchanged.
- Original run: `C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.validation\p7-trials\node-retest-app\review\runtime\unified-1795291546`. Ordinary receipt: `ordinary-browser-recording-command.json` (exit 1); raw GUI checks/stop receipts/lifecycle remain in that run. Complete gate: `verify-after-browser.json` and its command receipt (exit 0). Immutable full check copy: `complete-post-verify-originals/`.

| Recording | Status | Received events | Closed calls | Complete invocation closure |
|---|---|---:|---:|---|
| `b437c31c7a984b44af4bf4739a602fe3` | stopped | 2402 | 539 | True |
| `1a56737f20d34900bbecd418eb18836b` | interrupted | 9029 | 1620 | False |

The second record `1a56737f20d34900bbecd418eb18836b` remains interrupted in its unchanged raw file and in `/api/recordings`. It has 2000 full-value context events plus two metadata-only boundaries matching the first original. All parent references and retained typed frame/event identities are valid, but `api_files` and `list_files` have two invocation-without-exit errors; physical invocation closure is incomplete. No lost event, exit, frame or business outcome was filled in.

Failure details and traffic evidence:

- Before its stop wait: enqueued 11799, submitted 11418, completed 3162, pending 8256, dropped 421, queue/Full. The source limit remains 8192 waiting plus up to 64 in flight. End of wait: completed 11418, pending 0, dropped still 421, one transport retry. Record stop settlement later flushed its frozen prefix successfully; queue loss remains a gap.
- Captured second-burst sample window: 3.701s, enqueued-counter +9376, completed +731. Remaining pending 8256 drained over 29.468s, about 280.2 completed envelopes/s. These are counter-window rates, not measured HTTP request latencies.
- SDK batches remain at most 64 events / 256 KiB; one serial group, each envelope at most 24 KiB; 1000 ms request deadline, two attempts; snapshots are separate ordered barriers. No capacity, selected field, timeout, assertion or provider file changed.
- `FLOW_DIAGNOSIS.md`, `flow-bottleneck-diagnosis.json` and `flow-health-timeline.json` preserve existing source limits/hashes, all 214 health samples, stop elapsed times, system CPU observations, node distribution and candidate code locations. The unprofiled run did not retain ingress HTTP batch sizes or per-request server duration. This missing timing is explicit; no new profiler or business replay was run. Serial SDK delivery and the collector's atomic validator/source-binding/cursor-publication path are measurement candidates, not individually proven hotspots.

The earlier missing jsonRequest helper was corrected in the app factory call and module destructuring without changing endpoints, permissions, payloads or actions. Persistent tests use actual page form controls against labeled simulated API responses. Frozen failed frontend: 22/24; fixed frontend: 24/24. The original sixth command now runs all 24 cases; original six arrays, previous twenty cases and old assertions remain. This batch additionally passed `independent_board_publish_edit_read_delete` in the unchanged real GUI workflow.

Independent completed items: all 666 field definitions, 647 model nodes, native state rules/concepts, 2781 provider files, SDK/native test/source bytes, original six arrays and 180-second limit; all 37 records preceding this repaired batch (including first-batch failure), all 39 raw files after it; all 254 prior full SQL rows and revision 405 preferences, with no preference value changes. The first batch separately proves all original 242 rows unchanged, and this batch preserves that later superset. On/off/fault stored file/prepared bytes and Bob's two repeat collections independently match. The interrupted record is explicitly excluded from any complete recording pass. Audit originals: `final-source-provider-record-preservation.json`, `final-old-sql-row-preservation.json`, `final-personal-view-preservation.json`, `independent-partial-recording-audit.json`.

The ordinary recipient schedule was active-grant preparation and ready before revoke, with repeated byte-identical collection after revoke; it does not demonstrate cancellation. Existing controlled cases remain separately evidenced on/off/fault with exact same-run native facts:

- `revoked_at_preparation_start`: task `05f1b445-2f8a-4eb3-bdc3-5b876d16f55d`, SQL `cancelled`; exact event IDs, original state frames and SQL fixture: `C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.validation\p7-trials\node-retest-app\review\runtime\announcement-module-bootstrap-repaired-20261122\controlled-permission-evidence\on\revoked_at_preparation_start-raw-evidence.json`.
- `reshared_new_request`: task `c3871003-ee01-4bfc-b164-30bfdf3a72bd`, SQL `ready`; exact event IDs, original state frames and SQL fixture: `C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.validation\p7-trials\node-retest-app\review\runtime\announcement-module-bootstrap-repaired-20261122\controlled-permission-evidence\on\reshared_new_request-raw-evidence.json`.
- `started_before_revoke`: task `ec08bfcd-65ba-4fdc-b55c-17de6b6937d5`, SQL `ready`; exact event IDs, original state frames and SQL fixture: `C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.validation\p7-trials\node-retest-app\review\runtime\announcement-module-bootstrap-repaired-20261122\controlled-permission-evidence\on\started_before_revoke-raw-evidence.json`.

`controlled-permission-evidence/index.json` includes raw start-check/commit/guard/state-value IDs, submitted state frames, independent SQL fixture rows/hashes, original source assertion lines, cancelled-task no-revival and ordered start-before-revoke finish. No additional demonstration recording was created.

At the main session's explicit follow-up request, only the existing actual-data app and viewer were restarted for independent Graph/Timeline/layout/source review:

- App `http://127.0.0.1:8925/`, actual listener PID `13280`.
- Viewer `http://127.0.0.1:8926/graph`, actual listener PID `47540`, launcher PID `54968`. Exact commands/parents are in `live/listener-identity.json`; startup receipt in `live/services.json`.
- Current binding is current; C/B match above; no recording active. New process run `39c30db2-0d4f-47ac-8681-c1aa9bcdef35`, producer `c6220c70-6b30-4231-9db4-e16a0234f0a4`, initial actual live events 4. New process health has dropped 0; this does not change prior dropped 421 or make the old record complete.
- No additional login/file-list business action, ordinary workload, recording or accept was executed after restart. Main session owns the independent desktop checks. Source snapshot: `current-static-snapshot.json`; exact frozen source: `failed-ordinary-originals/source/`; actual SQL snapshot: `failed-ordinary-originals/application.sqlite`; views snapshot: `live/personal-views-at-handoff.json`. Hashes are bound in `FINAL_HANDOFF.json` and the original failure seal.

The complete first failure, original interrupted record and limited-scope post-verify success remain in `C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.validation\p7-trials\node-retest-app\review\runtime\announcement-module-bootstrap-20261122` and `FAILURE_AND_TARGETED_REPAIR.md`. No old failure was overwritten. The main session is profiling the collection entry on an isolated copy. Wait for that review and explicit coordination before any further ordinary run; do not accept or stop these requested live services autonomously.
