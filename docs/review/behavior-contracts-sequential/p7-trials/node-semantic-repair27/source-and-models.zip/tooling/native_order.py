"""Derive an ordinary worker outcome from independent native SQL/order witnesses."""
import json
from pathlib import Path

def preparation_expectation(data_root, task_id, build_id):
    """Read the actual queued pre-state and grant at start, never the observed task result."""
    filename = Path(data_root) / "native-order.jsonl"
    rows = [json.loads(line) for line in filename.read_text(encoding="utf-8").splitlines() if line.strip()]
    matching = [row for row in rows if row.get("task_id") == task_id and row.get("build_id") == build_id]
    checks = [row for row in matching if row["phase"] == "preparation_check"]
    if len(checks) != 1:
        raise ValueError(f"Expected one actual start pre-state for {task_id}, found {len(checks)}")
    check = checks[0]
    task, file, grant = check["task"], check["file"], check.get("grant")
    if task["id"] != task_id or task["file_id"] != file["id"] or task["status"] != "queued" or task["authorized_at_submission"] != 1:
        raise ValueError("Invalid native queued-task pre-state or identity")
    if grant and (grant["file_id"] != task["file_id"] or grant["recipient_id"] != task["requester_id"]):
        raise ValueError("Grant belongs to another file or requester")
    allowed = task["requester_id"] == file["owner_id"] or bool(grant and grant["active"])
    commits = [row for row in matching if row["phase"] == "preparation_commit" and row["transaction_id"] == check["transaction_id"]]
    if len(commits) != 1:
        raise ValueError("Missing or duplicated native start/cancel commit")
    commit = commits[0]
    if commit["native_run_id"] != check["native_run_id"] or commit["native_sequence"] <= check["native_sequence"]:
        raise ValueError("Native start transaction has inconsistent process ordering")
    expected_commit_state = "preparing" if allowed else "cancelled"
    if commit["task"]["status"] != expected_commit_state or commit["task"]["revision"] != task["revision"] + 1:
        raise ValueError("Native start commit disagrees with its independently computed permission")
    return {"source": str(filename), "scope": "ordinary_worker_native_order", "task_id": task_id,
        "build_id": build_id, "native_run_id": check["native_run_id"], "transaction_id": check["transaction_id"],
        "check_sequence": check["native_sequence"], "commit_sequence": commit["native_sequence"],
        "pre_state": task, "file": file, "grant": grant,
        "expected_permission": allowed, "expected_terminal_task_status": "ready" if allowed else "cancelled",
        "expected_from": "Independent native queued row, file owner and current grant at the actual check; no observer arrival order or later result is used."}
