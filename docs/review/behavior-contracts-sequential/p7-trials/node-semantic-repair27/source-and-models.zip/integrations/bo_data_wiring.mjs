import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { readFile } from 'node:fs/promises';

/** Connect real synchronous SQLite calls to the installed data adapter without owning execution. */
export async function bo_attach_data(probe, service, root) {
  const skill=process.env.VIBELENS_SKILL || path.resolve(root,'../node-migration-final-skills/vibelens');
  const {BODataRuntime}=await import(pathToFileURL(path.join(skill,'scripts/bo_observer/adapters/javascript/bo_data.mjs')).href);
  const config=JSON.parse(await readFile(path.join(root,'bo_stategraph/databases.json'),'utf8'));
  const operations=new Map(config.operations.map(/** Index the exact configured data-operation identity. */ item=>[item.id,item]));
  // The native adapter reports supplied targets. This project facade supplies
  // their explicit access role and the truthful unknown row count on failures.
  // It never parses user SQL, invents results or changes the installed adapter.
  const facade=new Proxy(probe,{
    get(/** Read the original probe member or the project data-formatting facade. */ target,key) {
      if(key==='record')return /** Complete explicit data target metadata before the canonical probe validates it. */ (node,phase,builder,options)=>target.record(node,phase,/** Add roles for this actual selected call and preserve all native values. */ ()=>{
        const payload=builder(),operation=operations.get(node);
        payload.outputs.target_access=payload.outputs.targets.map(/** Bind each supplied native target to this read or write role. */ name=>({target:name,action:operation.action}));
        if(phase==='error' && ['read','write'].includes(operation.action))payload.outputs.rows_known=false;
        return payload;
      },options);
      const value=target[key];return typeof value==='function'?value.bind(target):value;
    }
  });
  const runtime=new BODataRuntime(facade,config);
  service.store.instrumentation={around(/** Observe the real native SQLite call with its fixed project-owned targets. */ action,sql,execute){
    // All application statements use literal table names in this registered DDL.
    // Only these fixed SELECT/INSERT/UPDATE forms are bound. This is explicit
    // application wiring, with no claim to analyze arbitrary SQL or column lineage.
    const names=[...sql.matchAll(/\b(?:FROM|JOIN|INTO|UPDATE)\s+(users|sessions|files|grants|tasks|announcements)\b/gi)].map(/** Read a fixed registered table occurrence from a native statement. */ match=>'table:'+match[1].toLowerCase());
    const targets=[...new Set(names)];
    if(!targets.length)return execute();
    const native=service.context.getStore();
    return runtime.execute('data_'+action,execute,{targets,statement:action.toUpperCase(),parentCallId:native?.active?native.invocationId:null,entity:'application',attempt:'application',scope:'application',summarize:/** Count only rows already consumed by the actual native call. */ value=>({rows:action==='read'?value.length:value.changes})});
  }};
  return {runtime,close(){delete service.store.instrumentation;}};
}
