/** Independently retain actual native SQLite/order witnesses, without evaluating or controlling policy. */
import { mkdirSync, appendFileSync } from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

/** Attach a read-only witness to completed native facts and the synchronous pre-start boundary.
 * @param {FileService} service Native service whose ordering and rows are independently read.
 * @param {string} root Project root used only to resolve the selected immutable provider.
 * @param {string} buildId Actual configured build identity, not a fabricated run label.
 */
export async function bo_attach_order(service, root, buildId) {
  const skill = process.env.VIBELENS_SKILL || path.resolve(root, '../node-migration-final-skills/vibelens');
  const { bo_internal } = await import(pathToFileURL(path.join(skill, 'scripts/bo_observer/adapters/javascript/bo_data.mjs')).href);
  const filename = path.join(service.root, 'native-order.jsonl');
  const records = [], failures = [];
  mkdirSync(path.dirname(filename), { recursive: true });
  /** Independently query the selected task and current file/grant; never copy the observer event's result. */
  const taskRows = taskId => {
    const task = service.store.get('SELECT id,file_id,requester_id,authorized_at_submission,status,revision,started_at,ready_at,last_error FROM tasks WHERE id=?', taskId);
    if (!task) return { task: null, file: null, grant: null };
    const file = service.store.get('SELECT id,owner_id,revision FROM files WHERE id=?', task.file_id);
    const grant = service.store.get('SELECT file_id,recipient_id,active,revision FROM grants WHERE file_id=? AND recipient_id=?', task.file_id, task.requester_id) || null;
    return { task, file, grant };
  };
  /** Retain one native checkpoint with exact invocation/transaction identity and current persisted values. */
  const observe = event => {
    if (!['preparation_check', 'preparation_commit', 'state', 'commit', 'rollback'].includes(event.phase)) return;
    if (event.phase === 'state' && !['grant', 'download_task'].includes(event.model)) return;
    const row = { schema: 'native-order-witness/v1', build_id: buildId, native_run_id: event.native_run_id,
      native_sequence: event.native_sequence, invocation_id: event.invocationId, native_operation: event.name,
      phase: event.phase, transaction_id: event.transaction_id || null,
      task_id: event.task_id || (event.model === 'download_task' ? event.id : null), model: event.model || null, event: event.event || null };
    if (row.task_id) Object.assign(row, taskRows(row.task_id));
    if (event.model === 'grant') {
      const separator = event.id.lastIndexOf('/'), fileId = event.id.slice(0, separator), recipientId = event.id.slice(separator + 1);
      row.grant = service.store.get('SELECT file_id,recipient_id,active,revision FROM grants WHERE file_id=? AND recipient_id=?', fileId, recipientId) || null;
      row.tasks_at_grant = service.store.all('SELECT id,file_id,requester_id,status,revision FROM tasks WHERE file_id=? AND requester_id=?', fileId, recipientId);
    }
    appendFileSync(filename, JSON.stringify(row) + '\n', 'utf8');
    records.push(row);
  };
  const unsubscribe = service.subscribe(/** Keep witness failures visible while leaving native execution authoritative. */ event => {
    try { bo_internal(/** Suppress these independent read-only verification queries from all business observation. */ () => observe(event)); }
    catch (error) { failures.push({ native_sequence: event.native_sequence, message: error.message }); }
  });
  return { filename, records, failures, close: unsubscribe };
}
