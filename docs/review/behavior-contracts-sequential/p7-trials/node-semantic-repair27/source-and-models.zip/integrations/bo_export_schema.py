"""Export only the application's registered DDL as offline in-memory metadata."""
import json
import os
from pathlib import Path
import sys
import sqlalchemy as sa
from sqlalchemy.dialects import sqlite

root=Path(__file__).resolve().parents[1]
skill=Path(os.environ.get("VIBELENS_SKILL",root.parent/"node-migration-final-skills/vibelens"))
sys.path.insert(0,str(skill/"scripts"))
from bo_observer.data.catalog import export_sqlalchemy_metadata

engine=sa.create_engine("sqlite:///:memory:")
with engine.connect() as connection:
    connection.connection.driver_connection.executescript((root/"src/schema.sql").read_text(encoding="utf-8"))
    metadata=sa.MetaData()
    metadata.reflect(bind=connection)
catalog=export_sqlalchemy_metadata(metadata,"application",dialect=sqlite.dialect())
catalog["limitations"].append("The shared native SQLite DDL is instantiated only in memory for declaration export; no application connection, migration or row is accessed.")
engine.dispose()
print(json.dumps(catalog,ensure_ascii=False))
