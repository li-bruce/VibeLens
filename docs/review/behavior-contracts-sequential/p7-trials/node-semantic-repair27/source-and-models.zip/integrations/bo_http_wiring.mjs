import { randomUUID } from 'node:crypto';

/** Bind the installed HTTP adapter to the actual Express 5 registered route layers. */
export function bo_wrap_http(app, probe, service, bindings, observeHttp) {
  const declarations=app.router.stack.filter(/** Select actual native route declarations, excluding middleware-only layers. */ layer=>Boolean(layer.route));
  const requests=new WeakMap();
  /** Resolve only an exact selected native registration without reading a request body or query string. */
  function bo_resolve(request) {
    const pathname=new URL(request.url,'http://127.0.0.1').pathname;
    if(pathname.startsWith('/api/bo/'))return null;
    for(const layer of declarations){
      const route=layer.route;
      if(!route.methods[request.method.toLowerCase()])continue;
      // Reuse Express's compiled, pure matching functions. Calling Layer.match
      // would mutate layer.params; this observer never calls that method.
      if(!Array.isArray(layer.matchers) || !layer.matchers.some(/** Match the concrete pathname with a native compiled route matcher. */ match=>Boolean(match(pathname))))continue;
      const handler=route.stack.at(-1)?.handle?.name;
      const binding=Object.entries(bindings).find(/** Associate the actual final handler with its exact method/path/source registration. */ ([,entry])=>entry[0]===request.method && entry[1]===route.path && entry[2]===handler);
      if(!binding)return null;
      const node=binding[0],invocationId=randomUUID();
      requests.set(request,{node,invocationId,pathname});
      return {node,inputs:{method:request.method,path:pathname},context:{callId:invocationId,entity:'application',attempt:'application',scope:'application'}};
    }
    return null;
  }
  /** Invoke the native application once inside its actual HTTP observation interval. */
  function bo_native_listener(request,response,...args) {
    const binding=requests.get(request);
    if(binding){
      service.notify({name:binding.node,phase:'http_started',invocationId:binding.invocationId,method:request.method,path:binding.pathname});
      let ended=false;
      const end=/** Retain one native response boundary for independent SDK-context comparison. */ ()=>{
        if(ended)return;ended=true;
        service.notify({name:binding.node,phase:'http_return',invocationId:binding.invocationId,status:response.headersSent?response.statusCode:null,completed:response.writableFinished});
      };
      response.once('finish',end);response.once('close',end);
    }
    return app.call(this,request,response,...args);
  }
  return observeHttp(bo_native_listener,{probe,resolve:bo_resolve});
}
