import path from 'node:path';
import { fileURLToPath } from 'node:url';

/** Mount observer-only native assets/configuration without invoking business operations. */
export function bo_mount(app, observer) {
  const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
  /** Serve a no-op module when capture is off, preserving the application's startup. */
  function bo_client(req, res) {
    res.set('Cache-Control','no-store');
    if (!observer) return res.type('application/javascript').send('export {};');
    res.sendFile('client.mjs',{root:path.join(root,'bo_stategraph/config/assets')});
  }
  /** Supply local development capture settings; no business credentials are included. */
  function bo_config(req, res) {
    if (!observer || !['127.0.0.1','localhost'].includes(req.hostname)) return res.status(404).end();
    res.json(observer.clientConfig());
  }
  /** Read actual local producer counters without invoking any application command. */
  function bo_health(req,res) { if(!observer || !['127.0.0.1','localhost'].includes(req.hostname))return res.status(404).end();res.json(observer.health()); }
  /** Export native decision reports already produced by the actual observer callback. */
  function bo_evidence(req,res) { if(!observer || !['127.0.0.1','localhost'].includes(req.hostname))return res.status(404).end();res.json({policy_evaluations:observer.evaluations,state_frames:observer.stateFrames}); }
  /** Serve the exact managed native probe dependency. */
  function bo_runtime(req, res) { if (!observer) return res.status(404).end(); res.set('Cache-Control','no-store').sendFile('bo_runtime.mjs',{root:path.join(root,'bo_stategraph')}); }
  /** Serve the exact managed acknowledged capture-control dependency. */
  function bo_capture(req, res) { if (!observer) return res.status(404).end(); res.set('Cache-Control','no-store').sendFile('bo_capture.mjs',{root:path.join(root,'bo_stategraph')}); }
  app.get('/api/bo/client.mjs', bo_client);
  app.get('/api/bo/config', bo_config);
  app.get('/api/bo/health',bo_health);
  app.get('/api/bo/evidence',bo_evidence);
  app.get('/api/bo/native-runtime.mjs', bo_runtime);
  app.get('/api/bo/native-capture.mjs', bo_capture);
}
