CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY, username TEXT NOT NULL UNIQUE, display_name TEXT NOT NULL,
        password_salt TEXT NOT NULL, password_hash TEXT NOT NULL, editor INTEGER NOT NULL CHECK(editor IN (0,1))
      );
      CREATE TABLE IF NOT EXISTS sessions (
        token_hash TEXT PRIMARY KEY, trace_id TEXT NOT NULL UNIQUE, user_id TEXT NOT NULL REFERENCES users(id),
        status TEXT NOT NULL CHECK(status IN ('active','ended')), revision INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL
      );
      CREATE TABLE IF NOT EXISTS files (
        id TEXT PRIMARY KEY, owner_id TEXT NOT NULL REFERENCES users(id), name TEXT NOT NULL,
        size INTEGER NOT NULL CHECK(size >= 0), sha256 TEXT NOT NULL, storage_path TEXT NOT NULL,
        created_at TEXT NOT NULL, revision INTEGER NOT NULL DEFAULT 1
      );
      CREATE TABLE IF NOT EXISTS grants (
        file_id TEXT NOT NULL REFERENCES files(id), recipient_id TEXT NOT NULL REFERENCES users(id),
        active INTEGER NOT NULL CHECK(active IN (0,1)), revision INTEGER NOT NULL DEFAULT 1,
        PRIMARY KEY(file_id, recipient_id)
      );
      CREATE TABLE IF NOT EXISTS tasks (
        id TEXT PRIMARY KEY, file_id TEXT NOT NULL REFERENCES files(id), requester_id TEXT NOT NULL REFERENCES users(id),
        authorized_at_submission INTEGER NOT NULL CHECK(authorized_at_submission=1),
        status TEXT NOT NULL CHECK(status IN ('queued','preparing','ready','cancelled')),
        prepared_path TEXT, sha256 TEXT, last_error TEXT, created_at TEXT NOT NULL,
        started_at TEXT, ready_at TEXT, revision INTEGER NOT NULL DEFAULT 1
      );
      CREATE TABLE IF NOT EXISTS announcements (
        id TEXT PRIMARY KEY, author_id TEXT NOT NULL REFERENCES users(id), title TEXT NOT NULL,
        body TEXT NOT NULL, status TEXT NOT NULL CHECK(status IN ('published','deleted')),
        created_at TEXT NOT NULL, updated_at TEXT NOT NULL, revision INTEGER NOT NULL DEFAULT 1
      );
