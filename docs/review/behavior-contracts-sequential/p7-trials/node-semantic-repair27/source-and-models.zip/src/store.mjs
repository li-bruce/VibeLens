import initSqlJs from 'sql.js';
import { mkdirSync, existsSync, readFileSync, writeFileSync, renameSync } from 'node:fs';
import { createRequire } from 'node:module';
import path from 'node:path';
import { randomBytes, scryptSync } from 'node:crypto';
const require = createRequire(import.meta.url);
const SQL = await initSqlJs({ locateFile: /** Resolve the installed SQLite WebAssembly asset from this project dependency. */ file => require.resolve('sql.js/dist/' + file) });

/** Three synthetic accounts for the explicitly requested local trial. */
export const TEST_ACCOUNTS = [
  { id: 'alice', username: 'alice', display_name: '林澈', editor: false },
  { id: 'bob', username: 'bob', display_name: '陈可', editor: false },
  { id: 'editor', username: 'editor', display_name: '叶青', editor: true }
];
export const TEST_PASSWORD = 'DemoPass!2026';

/** Create the application's SQLite store and retain normal native transaction semantics. */
export class Store {
  /** Open the native SQLite database, create its schema and seed the requested synthetic accounts. @param {string} filename Project-local SQLite filename. */
  constructor(filename) {
    mkdirSync(path.dirname(filename), { recursive: true });
    this.filename = filename; this.txDepth = 0;
    this.db = new SQL.Database(existsSync(filename) ? readFileSync(filename) : undefined);
    this.db.run('PRAGMA foreign_keys = ON');
    const schema = readFileSync(new URL('./schema.sql', import.meta.url), 'utf8');
    this.db.exec(schema);
    this.migrateTaskCancellation(schema);
    this.transaction(/** Seed missing synthetic accounts with salted password hashes in one native transaction. */ () => {
      for (const account of TEST_ACCOUNTS) {
        const salt = randomBytes(16).toString('hex');
        this.run('INSERT OR IGNORE INTO users VALUES (?,?,?,?,?,?)', account.id, account.username, account.display_name, salt, scryptSync(TEST_PASSWORD, salt, 32).toString('hex'), Number(account.editor));
      }
    });
  }
  /** Extend the existing task constraint without changing any persisted task or account row.
   * @param {string} schema Current application-owned DDL used to create the replacement task table.
   */
  migrateTaskCancellation(schema) {
    const current = this.get("SELECT sql FROM sqlite_master WHERE type='table' AND name='tasks'");
    if (current.sql.includes("'cancelled'")) return;
    this.transaction(/** Rebuild only the task CHECK constraint in one atomic native migration. */ () => {
      this.db.run('ALTER TABLE tasks RENAME TO tasks_before_start_permission');
      this.db.exec(schema);
      this.db.run('INSERT INTO tasks SELECT * FROM tasks_before_start_permission');
      this.db.run('DROP TABLE tasks_before_start_permission');
    });
  }
  /** Read one native SQLite row; callers select fields before observation. */
  get(sql, ...parameters) { return this.all(sql, ...parameters)[0]; }
  /** Read native SQLite rows without an observer-owned second business query.
   * @param {string} sql Actual native bound SELECT statement; observation withholds the raw text.
   * @param {...any} parameters Actual SQLite bound values; observation withholds their contents.
   */
  all(sql, ...parameters) {
    return this.nativeData('read',sql,/** Consume the actual bound SQLite result once. */ () => {
    const statement = this.db.prepare(sql), rows = [];
    try { statement.bind(parameters); while (statement.step()) rows.push(statement.getAsObject()); }
    finally { statement.free(); }
    return rows;
    });
  }
  /** Execute a bound native SQLite mutation.
   * @param {string} sql Actual native bound INSERT or UPDATE statement; observation withholds the raw text.
   * @param {...any} parameters Actual SQLite bound values; observation withholds their contents.
   */
  run(sql, ...parameters) {
    if (!this.txDepth) return this.transaction(/** Execute this bound mutation inside a native transaction when no transaction is active. */ () => this.run(sql, ...parameters));
    return this.nativeData('write',sql,/** Execute the actual bound SQLite write once. */ () => { this.db.run(sql, parameters); return { changes: this.db.getRowsModified() }; });
  }
  /** Preserve the native result and single execution across optional data instrumentation.
   * @param {string} action Native read or write category.
   * @param {string} sql Native bound statement; raw text and parameters are withheld from observation.
   * @param {Function} execute Actual synchronous SQLite call.
   */
  nativeData(action,sql,execute) {
    let called=false,value,failure;
    const once=/** Cache the real native database result or exception for this one call. */ () => {
      if (!called) { called=true;try {value=execute();} catch(error) {failure=error;} }
      if (failure) throw failure; return value;
    };
    try { this.instrumentation?.around(action,sql,once); } catch { /* Native outcome is retained below. */ }
    return once();
  }
  /** Commit or roll back the actual synchronous database transaction. */
  transaction(operation) {
    if (this.txDepth) return operation();
    const backup = this.db.export(); this.db.run('PRAGMA foreign_keys = ON');
    this.db.run('BEGIN IMMEDIATE'); this.txDepth = 1;
    try {
      const result = operation(); this.db.run('COMMIT'); this.persist(); return result;
    } catch (error) {
      this.db.close(); this.db = new SQL.Database(backup); this.db.run('PRAGMA foreign_keys = ON'); throw error;
    } finally { this.txDepth = 0; }
  }
  /** Persist a committed real SQLite database through atomic project-local replacement. */
  persist() {
    writeFileSync(this.filename + '.tmp', this.db.export());
    renameSync(this.filename + '.tmp', this.filename);
    this.db.run('PRAGMA foreign_keys = ON');
  }
  /** Close this application's database connection. */
  close() { this.db.close(); }
}
