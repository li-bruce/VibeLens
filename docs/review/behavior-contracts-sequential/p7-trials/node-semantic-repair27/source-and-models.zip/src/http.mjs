import express from 'express';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { createServer } from 'node:http';
import { AppError, publicUser } from './service.mjs';
import { bo_mount } from '../integrations/bo_web_routes.mjs';

/** Read the application's own session cookie without exposing it to observation.
 * @param {object} req Native Express request with the matched route, current cookie and operation inputs.
 */
export function sessionCookie(req) {
  const value = req.headers.cookie?.split(';').map(/** Trim whitespace around one native cookie segment. */ value => value.trim()).find(/** Select only the application session-cookie segment. */ value => value.startsWith('team_session='));
  return value ? value.slice('team_session='.length) : '';
}
/** Build HTTP routes around native business methods; optional observation cannot change decisions. */
export function createApp(service, publicRoot, observer = null) {
  const app = express();
  let collectorOrigin='';
  try {
    const endpoint=new URL(observer?.clientConfig?.().endpoint);
    if(endpoint.protocol==='http:' && ['127.0.0.1','localhost'].includes(endpoint.hostname)) collectorOrigin=' '+endpoint.origin;
  } catch { /* Optional observer configuration cannot block application startup. */ }
  app.disable('x-powered-by');
  bo_mount(app, observer);
  app.use(/** Set local application response headers and reject mismatched mutation origins. */ function originBoundary(req, res, next) {
    res.set('Cache-Control', 'no-store');
    res.set('X-Content-Type-Options', 'nosniff');
    res.set('Referrer-Policy', 'same-origin');
    res.set('Content-Security-Policy', "default-src 'self'; connect-src 'self'"+collectorOrigin+"; style-src 'self'; script-src 'self'; base-uri 'none'; frame-ancestors 'none'");
    const origin = req.headers.origin;
    if (!['GET','HEAD','OPTIONS'].includes(req.method) && origin && origin !== req.protocol + '://' + req.get('host')) return res.status(403).json({ error: 'ORIGIN_REJECTED' });
    next();
  });
  /** Bind the real matched API boundary before parsers so framework errors remain observable.
   * @param {string} id Stable identity of this matched API entry in the observer declaration.
   */
  function observed(id) {
    return /** Wrap this matched native API invocation before body parsing. */ function apiBoundary(req, res, next) {
      const invocationId = randomUUID();
      let complete;
      try { complete = observer?.httpStart?.(id, req.method, req.path, invocationId); } catch { /* Observation only. */ }
      let ended=false;
      const end=/** Retain the actual end of this entered upload-authentication request scope. */ () => { if(ended)return;ended=true;const status=res.headersSent?res.statusCode:undefined;try { complete?.(status,res.writableFinished); } catch { /* Observation only. */ } service.notify({ name:id,phase:'http_return',invocationId,status,completed:res.writableFinished }); };
      res.once('finish',end);res.once('close',end);
      const proceed = /** Enter the native Express continuation in its actual invocation context. */ () => { service.notify({ name:id,phase:'http_started',invocationId,method:req.method,path:req.path }); next(); };
      if (complete?.run) complete.run(proceed); else proceed();
    };
  }
  /** Read the current authenticated member or null for the login screen.
   * @param {object} req Native Express request with the matched route, current cookie and operation inputs.
   * @param {object} res Native Express response used to return the actual status and resource.
   */
  async function sessionHandler(req, res) { res.json({ user: publicUser(service.session(sessionCookie(req))) }); }
  /** Authenticate real credentials and issue an HTTP-only session cookie.
   * @param {object} req Native Express request with the matched route, current cookie and operation inputs.
   * @param {object} res Native Express response used to return the actual status and resource.
   */
  async function loginHandler(req, res) {
    const result = await service.login(String(req.body?.username || ''), String(req.body?.password || ''));
    res.set('Set-Cookie', 'team_session=' + result.token + '; Path=/; HttpOnly; SameSite=Strict');
    res.json({ user: result.user });
  }
  /** Invalidate the current session and remove its browser cookie.
   * @param {object} req Native Express request with the matched route, current cookie and operation inputs.
   * @param {object} res Native Express response used to return the actual status and resource.
   */
  async function logoutHandler(req, res) {
    await service.logout(sessionCookie(req));
    res.set('Set-Cookie', 'team_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0'); res.status(204).end();
  }
  /** List public colleagues for a named sharing action.
   * @param {object} req Native Express request with the matched route, current cookie and operation inputs.
   * @param {object} res Native Express response used to return the actual status and resource.
   */
  async function membersHandler(req, res) { res.json({ members: service.members(service.requireActor(sessionCookie(req))) }); }
  /** List the current member's visible file metadata.
   * @param {object} req Native Express request with the matched route, current cookie and operation inputs.
   * @param {object} res Native Express response used to return the actual status and resource.
   */
  async function filesHandler(req, res) { res.json(await service.listFiles(service.requireActor(sessionCookie(req)))); }
  /** Return one file only after the native permission check.
   * @param {object} req Native Express request with the matched route, current cookie and operation inputs.
   * @param {object} res Native Express response used to return the actual status and resource.
   */
  async function fileHandler(req, res) { res.json(await service.viewFile(service.requireActor(sessionCookie(req)), req.params.id)); }
  /** Accept bounded raw file bytes after authentication.
   * @param {object} req Native Express request with the matched route, current cookie and operation inputs.
   * @param {object} res Native Express response used to return the actual status and resource.
   */
  async function uploadHandler(req, res) {
    if (!Buffer.isBuffer(req.body)) throw new AppError(400, 'FILE_BYTES_REQUIRED');
    res.status(201).json(await service.upload(req.actor, String(req.query.name || ''), req.body));
  }
  /** Create an uploader-owned named recipient grant.
   * @param {object} req Native Express request with the matched route, current cookie and operation inputs.
   * @param {object} res Native Express response used to return the actual status and resource.
   */
  async function shareHandler(req, res) { res.json(await service.setGrant(service.requireActor(sessionCookie(req)), req.params.id, String(req.body?.recipient_id || ''), true)); }
  /** Revoke one grant without touching already admitted tasks.
   * @param {object} req Native Express request with the matched route, current cookie and operation inputs.
   * @param {object} res Native Express response used to return the actual status and resource.
   */
  async function revokeHandler(req, res) { res.json(await service.setGrant(service.requireActor(sessionCookie(req)), req.params.id, req.params.recipient, false)); }
  /** Admit a new preparation task using current file access.
   * @param {object} req Native Express request with the matched route, current cookie and operation inputs.
   * @param {object} res Native Express response used to return the actual status and resource.
   */
  async function requestHandler(req, res) { res.status(202).json(await service.requestDownload(service.requireActor(sessionCookie(req)), String(req.body?.file_id || ''))); }
  /** Return only the current requester's task records.
   * @param {object} req Native Express request with the matched route, current cookie and operation inputs.
   * @param {object} res Native Express response used to return the actual status and resource.
   */
  async function tasksHandler(req, res) { res.json(await service.listTasks(service.requireActor(sessionCookie(req)))); }
  /** Deliver an actual prepared artifact without consuming the task.
   * @param {object} req Native Express request with the matched route, current cookie and operation inputs.
   * @param {object} res Native Express response used to return the actual status and resource.
   */
  async function collectHandler(req, res) {
    const result = await service.collect(service.requireActor(sessionCookie(req)), req.params.id);
    res.set('Content-Type', 'application/octet-stream');
    res.set('Content-Disposition', "attachment; filename*=UTF-8''" + encodeURIComponent(result.name));
    res.send(result.bytes);
  }
  /** Return published announcements to logged-in colleagues.
   * @param {object} req Native Express request with the matched route, current cookie and operation inputs.
   * @param {object} res Native Express response used to return the actual status and resource.
   */
  async function boardHandler(req, res) { res.json(await service.announcements(service.requireActor(sessionCookie(req)))); }
  /** Publish under the native editor role check.
   * @param {object} req Native Express request with the matched route, current cookie and operation inputs.
   * @param {object} res Native Express response used to return the actual status and resource.
   */
  async function publishHandler(req, res) { res.status(201).json(await service.publish(service.requireActor(sessionCookie(req)), String(req.body?.title || ''), String(req.body?.body || ''))); }
  /** Update only an editor's own announcement.
   * @param {object} req Native Express request with the matched route, current cookie and operation inputs.
   * @param {object} res Native Express response used to return the actual status and resource.
   */
  async function editHandler(req, res) { res.json(await service.mutateAnnouncement(service.requireActor(sessionCookie(req)), req.params.id, 'edit', String(req.body?.title || ''), String(req.body?.body || ''))); }
  /** Delete only an editor's own announcement.
   * @param {object} req Native Express request with the matched route, current cookie and operation inputs.
   * @param {object} res Native Express response used to return the actual status and resource.
   */
  async function deleteHandler(req, res) { res.json(await service.mutateAnnouncement(service.requireActor(sessionCookie(req)), req.params.id, 'delete')); }
  /** Authenticate before reading uploaded bytes into memory.
   * @param {object} req Native Express request with the matched route, current cookie and operation inputs.
   * @param {object} res Native Express response used to return the actual status and resource.
   * @param {Function} next Express continuation invoked after successful upload authentication.
   */
  function uploadActor(req, res, next) { req.actor = service.requireActor(sessionCookie(req)); next(); }

  app.get('/api/auth/session', sessionHandler);
  app.post('/api/auth/login', express.json({limit:'16kb'}), loginHandler);
  app.post('/api/auth/logout', logoutHandler);
  app.get('/api/members', membersHandler);
  app.get('/api/files', filesHandler);
  app.get('/api/files/:id', fileHandler);
  app.post('/api/files', observed('api_upload_actor'), uploadActor, express.raw({type:'application/octet-stream',limit:'50mb'}), uploadHandler);
  app.post('/api/files/:id/shares', express.json({limit:'4kb'}), shareHandler);
  app.delete('/api/files/:id/shares/:recipient', revokeHandler);
  app.post('/api/tasks', express.json({limit:'4kb'}), requestHandler);
  app.get('/api/tasks', tasksHandler);
  app.get('/api/tasks/:id/download', collectHandler);
  app.get('/api/announcements', boardHandler);
  app.post('/api/announcements', express.json({limit:'32kb'}), publishHandler);
  app.put('/api/announcements/:id', express.json({limit:'32kb'}), editHandler);
  app.delete('/api/announcements/:id', deleteHandler);
  app.use('/api', /** Return a public 404 for an unmatched API path. */ function unknownApi(req, res) { res.status(404).json({ error: 'API_NOT_FOUND' }); });
  app.use(express.static(path.resolve(publicRoot), { index: 'index.html' }));
  /** Preserve framework/parser failures as their real HTTP errors. */
  app.use(/** Return the actual application or parser error as its public HTTP status and code. */ function errorHandler(error, req, res, next) {
    if (res.headersSent) return next(error);
    const status = error.status || 500;
    const code = error.code || (status === 413 ? 'UPLOAD_TOO_LARGE' : status === 400 ? 'INVALID_REQUEST' : 'INTERNAL_ERROR');
    res.status(status).json({ error: code });
  });
  let listener=app;
  try { if(observer?.wrapHttp)listener=observer.wrapHttp(app); } catch { /* Optional observation cannot block the native HTTP server. */ }
  return createServer(listener);
}
