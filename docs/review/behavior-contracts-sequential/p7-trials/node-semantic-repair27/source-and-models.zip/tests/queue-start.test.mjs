import test from 'node:test';
import assert from 'node:assert/strict';
import { queueStartScenario } from './queue_start_scenario.mjs';
import { mkdtemp, readFile, copyFile } from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { Store } from '../src/store.mjs';

/** Run the separately retained controlled branches, not a preferred ordinary worker schedule. */
test('confirmed preparation-start permission branches', { timeout: 45000 }, async t => {
  const results = [];
  for (const mode of ['on', 'off', 'fault']) await t.test(mode, async () => {
    results.push(await queueStartScenario(mode, 'all'));
  });
  assert.deepEqual(results[0].observations, results[1].observations);
  assert.deepEqual(results[0].observations, results[2].observations);
});

/** Validate the native schema upgrade against an isolated copy of the frozen old database, never its stored file paths. */
test('task cancellation schema migration preserves every original row', async () => {
  const fixture = JSON.parse(await readFile('review/native-migration-fixture.json', 'utf8'));
  const original = await readFile(fixture.path);
  assert.equal(createHash('sha256').update(original).digest('hex'), fixture.sha256);
  const root = await mkdtemp(path.resolve('review/runtime/migration-'));
  const filename = path.join(root, 'application.sqlite');
  await copyFile(fixture.path, filename);
  const store = new Store(filename);
  try {
    for (const [table, expected] of Object.entries(fixture.table_sha256)) {
      const rows = store.all('SELECT * FROM "' + table + '"').map(row => JSON.stringify(row)).sort();
      assert.equal(createHash('sha256').update(rows.join('\n')).digest('hex'), expected);
    }
    const ddl = store.get("SELECT sql FROM sqlite_master WHERE type='table' AND name='tasks'").sql;
    assert.ok(ddl.includes("'cancelled'"));
    assert.equal(store.get("SELECT COUNT(*) AS count FROM sqlite_master WHERE name='tasks_before_start_permission'").count, 0);
    const task = store.get('SELECT id FROM tasks ORDER BY id LIMIT 1');
    assert.doesNotThrow(() => store.run("UPDATE tasks SET status='cancelled' WHERE id=?", task.id));
    assert.throws(() => store.run("UPDATE tasks SET status='unknown' WHERE id=?", task.id));
  } finally { store.close(); }
});
