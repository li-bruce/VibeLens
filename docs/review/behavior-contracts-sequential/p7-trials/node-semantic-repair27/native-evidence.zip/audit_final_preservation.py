"""Verify unchanged contracts, source, installed resources and historical evidence."""
import hashlib
from pathlib import Path
from runtime_tools import APP, PACK, RUN, CHANGE, load, save, sha

before = load(RUN / "before-seal.json")
generated = {"var/db/application.sqlite", "bo_stategraph/config/views/local.json", "manifest.json"}
protected = {name: value for name, value in before["protected_hashes"].items() if name not in generated}
protected.update({name: value for name, value in before["source_hashes"].items()
                  if name not in {CHANGE + "/review.json", CHANGE + "/verification.json"}})
source_mismatches = [name for name, value in protected.items() if sha(APP / name) != value]
record_mismatches = [name for name, value in before["record_hashes"].items() if sha(APP / name) != value]
assert not source_mismatches and not record_mismatches, (source_mismatches, record_mismatches)
installed = {path.relative_to(PACK).as_posix(): sha(path) for path in PACK.rglob("*")
             if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc"}
expected = load(RUN / "provider-files-runtime-baseline.json")
assert installed == expected, {"changed": [name for name in expected if installed.get(name) != expected[name]],
                               "added": sorted(installed.keys() - expected.keys())}
archive = before["old_archive_reference"]
digest = hashlib.sha256()
with Path(archive["path"]).open("rb") as stream:
    while chunk := stream.read(1024 * 1024):
        digest.update(chunk)
assert digest.hexdigest() == archive["sha256"]
model = load(APP / "bo_stategraph/project.json")["model"]
fields = sum(len(node.get("capture", {}).get(direction, {})) for node in model["nodes"] for direction in ("in", "out"))
assert fields == 666 and len(model["nodes"]) == 618
assert load(APP / ".stategraph/active.json")["change"] == CHANGE
assert not (APP / CHANGE / "accepted.json").exists()
assert load(APP / "sync.json")["test_commands"] == before["test_commands"]
assert load(APP / "sync.json")["timeout_seconds"] == before["timeout_seconds"] == 180
save(RUN / "final-source-provider-record-preservation.json", {
    "valid": True, "protected_files_checked": len(protected), "source_mismatches": source_mismatches,
    "model_nodes": len(model["nodes"]), "capture_fields": fields, "all_capture_definitions_byte_equal": True,
    "old_recordings_checked": len(before["record_hashes"]), "old_record_mismatches": record_mismatches,
    "full_installed_files_checked": len(installed), "owned_files_checked": 466, "installed_files_unchanged": True,
    "test_commands": len(before["test_commands"]), "case_timeout_seconds": 180,
    "source_test_and_managed_sdk_bytes_unchanged": True, "old_archive_reference": archive,
    "old_archive_hash_verified": True, "archive_repacked": False, "baseline_reset": False, "accept_executed": False,
    "generated_current_manifest": {"sha256": sha(APP / "manifest.json"), "build_id": load(APP / "manifest.json")["build_id"]},
})
print({"preservation_valid": True, "protected_files": len(protected), "fields": fields, "old_records": len(before["record_hashes"]),
       "installed_files": len(installed), "old_archive_unchanged": True, "accept_executed": False}, flush=True)
