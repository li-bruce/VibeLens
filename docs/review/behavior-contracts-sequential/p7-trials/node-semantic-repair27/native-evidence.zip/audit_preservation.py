"""Compare old native rows and real personal preferences without restoring either."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from runtime_tools import APP, RUN, load, save, sha

before = sqlite3.connect((RUN / "database-before.sqlite").as_uri() + "?mode=ro", uri=True)
after = sqlite3.connect((APP / "var/db/application.sqlite").as_uri() + "?mode=ro", uri=True)
tables = []
for table in ("users", "sessions", "files", "grants", "tasks", "announcements"):
    metadata = before.execute("PRAGMA table_info(" + table + ")").fetchall()
    columns = [row[1] for row in metadata]
    keys = [row[1] for row in sorted(metadata, key=lambda row: row[5]) if row[5]]
    assert keys
    original = before.execute("SELECT * FROM " + table).fetchall()
    missing, changed = [], []
    for row in original:
        values = [row[columns.index(key)] for key in keys]
        actual = after.execute("SELECT * FROM " + table + " WHERE " + " AND ".join(key + "=?" for key in keys), values).fetchone()
        identity = hashlib.sha256(json.dumps(values, ensure_ascii=False).encode()).hexdigest()
        if actual is None:
            missing.append(identity)
        elif actual != row:
            changed.append({"primary_key_sha256": identity,
                            "changed_columns": [key for key, a, b in zip(columns, row, actual) if a != b]})
    tables.append({"table": table, "original_rows": len(original),
                   "current_rows": after.execute("SELECT COUNT(*) FROM " + table).fetchone()[0],
                   "missing": missing, "changed": changed})
before.close()
after.close()
sql_valid = all(not row["missing"] and not row["changed"] for row in tables)
save(RUN / "final-old-sql-row-preservation.json", {"valid": sql_valid, "tables": tables,
     "scope": "All original native rows compared by primary key and full values using query-only SQLite handles. No credentials are exported and no business data is written."})
assert sql_valid, tables

original_log = {"path": "var/native-order.jsonl", **load(RUN / "ordinary-browser-start.json")["original_native_order_prefix"]}
with (APP / original_log["path"]).open("rb") as stream:
    prefix = stream.read(original_log["bytes"])
log_valid = hashlib.sha256(prefix).hexdigest() == original_log["sha256"]
save(RUN / "final-native-order-prefix-preservation.json", {"valid": log_valid,
    "original_path": original_log["path"], "original_prefix_bytes": original_log["bytes"],
    "original_prefix_sha256": original_log["sha256"], "current_bytes": (APP / original_log["path"]).stat().st_size,
    "scope": "The exact original native-order bytes remain as an unchanged prefix. Later actual runs append evidence; log classification did not delete, rewrite or disable the independent reader."})
assert log_valid

path = APP / "bo_stategraph/config/views/local.json"
baseline = load(RUN / "personal-views-before-ordinary.json")
actual = load(path)
raw_hash = sha(path)
save(RUN / "personal-views-after-final-browser.json", actual)
a = {key: json.loads(value) for key, value in baseline["entries"].items()}
b = {key: json.loads(value) for key, value in actual["entries"].items()}
def differences(left, right, prefix=()):
    if type(left) != type(right):
        return [{"path": list(prefix), "before": left, "after": right}]
    if isinstance(left, dict):
        result = []
        for key in sorted(left.keys() | right.keys()):
            if key not in left or key not in right:
                result.append({"path": list(prefix + (key,)), "before": left.get(key), "after": right.get(key)})
            else:
                result.extend(differences(left[key], right[key], prefix + (key,)))
        return result
    if isinstance(left, list):
        if len(left) != len(right):
            return [{"path": list(prefix), "before": left, "after": right}]
        return [item for i, (x, y) in enumerate(zip(left, right)) for item in differences(x, y, prefix + (i,))]
    return [] if left == right else [{"path": list(prefix), "before": left, "after": right}]
changes = differences(a, b)
entry = "business-observer.layout.v2:node-retest-team-files:view:business"
def camera_roundoff(row):
    parts = row["path"]
    return (len(parts) == 5 and parts[:3] == [entry, "spatial", "camera"]
            and parts[3] in ("position", "target") and parts[4] in (0, 1, 2)
            and isinstance(row["before"], (int, float)) and isinstance(row["after"], (int, float))
            and abs(row["after"] - row["before"]) < 0.0001)
valid = a.keys() == b.keys() and all(camera_roundoff(row) for row in changes)
save(RUN / "final-personal-view-preservation.json", {"valid": valid,
    "before_revision": baseline["revision"], "after_revision": actual["revision"],
    "entry_identities_preserved": a.keys() == b.keys(), "all_existing_positions_pins_annotations_names_and_views_preserved": valid,
    "changes": changes, "sha256": raw_hash, "file_restore_or_revision_backfill": False,
    "scope": "Actual pre-ordinary baseline compared with this ordinary browser autosave. Only recorded tiny business-camera position/target roundoff is allowed; every other value must remain identical."})
assert sha(path) == raw_hash
assert valid, changes
print({"sql_preserved": True, "tables": tables, "preference_revision": actual["revision"],
       "camera_roundoff_changes": len(changes), "all_other_preferences_preserved": True, "restored": False})
