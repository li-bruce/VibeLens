"""Compare every original capture schema using stable node, direction and field IDs."""
from collections import Counter
from runtime_tools import APP, RUN, CHANGE, load, save, sha

baseline_path = APP / CHANGE / "baseline.json"
baseline = load(baseline_path)
current = load(APP / "bo_stategraph/project.json")["model"]
def fields(model):
    return {(node["id"], direction, name): definition for node in model["nodes"]
            for direction in ("in", "out") for name, definition in node.get("capture", {}).get(direction, {}).items()}
original, actual = fields(baseline["model"]), fields(current)
missing = sorted(original.keys() - actual.keys())
changed = sorted(key for key in original.keys() & actual.keys() if original[key] != actual[key])
added = sorted(actual.keys() - original.keys())
assert len(original) == 568 and len(actual) == 666 and len(added) == 98
assert not missing and not changed
assert fields(load(RUN / "before/bo_stategraph/project.json")["model"]) == actual
groups = Counter(key[0] for key in added)
result = {"valid": True, "counting_key": ["node_id", "direction_in_or_out", "field_name"],
    "meaning": "Each declared capture schema entry is counted once per node and direction. The 568 required_fields are the immutable baseline entries that must be retained; 666 capture_fields is the complete current inventory, including the retained 568 and 98 reviewed additions from earlier work in the same active change.",
    "baseline_id": baseline["id"], "baseline_sha256": sha(baseline_path), "baseline_nodes": len(baseline["model"]["nodes"]),
    "current_nodes": len(current["nodes"]), "baseline_required_fields": len(original), "current_capture_fields": len(actual),
    "required_fields_retained_with_identical_definitions": len(original), "missing_original_fields": missing,
    "changed_original_definitions": changed, "added_fields": len(added), "added_counts_by_node": dict(sorted(groups.items())),
    "added_definitions": [{"node": node, "direction": direction, "field": name, "definition": actual[(node, direction, name)]} for node, direction, name in added],
    "repair27_added_or_modified_fields": 0, "current_model_equal_to_before_upgrade": True}
save(RUN / "capture-field-statistics-and-preservation.json", result)
print({key: result[key] for key in ("valid", "baseline_required_fields", "current_capture_fields", "required_fields_retained_with_identical_definitions", "added_fields", "added_counts_by_node", "repair27_added_or_modified_fields")}, flush=True)
