"""Read the listener owners and their Python launcher relationships."""
import json
import subprocess
from runtime_tools import RUN, load, save
services = load(RUN / "live/services.json")
command = "[Console]::OutputEncoding=[System.Text.UTF8Encoding]::new($false); $ErrorActionPreference='Stop'; $taskListeners=@(Get-NetTCPConnection -State Listen | Where-Object {$_.LocalPort -in 8925,8926,8935,8936} | Select-Object LocalAddress,LocalPort,OwningProcess); $taskPids=@($taskListeners.OwningProcess)+@(" + str(services["app"]) + "," + str(services["viewer"]) + "); $taskProcesses=@(Get-CimInstance Win32_Process | Where-Object {$_.ProcessId -in $taskPids -or $_.ParentProcessId -in $taskPids} | Select-Object ProcessId,ParentProcessId,Name,CommandLine); [pscustomobject]@{listeners=$taskListeners;processes=$taskProcesses}|ConvertTo-Json -Depth 5"
result = subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", command], capture_output=True, encoding="utf-8", timeout=30, creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
assert result.returncode == 0, result.stderr
value = json.loads(result.stdout)
save(RUN / "live/host-processes-and-ports-observed.json", value)
print(value, flush=True)
