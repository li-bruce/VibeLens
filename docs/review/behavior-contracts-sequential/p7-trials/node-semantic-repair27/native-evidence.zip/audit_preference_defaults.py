"""Explain two added default keys without changing the failed strict comparison."""
import json
from runtime_tools import APP, PACK, RUN, load, save, sha

first = load(RUN / "first-final-personal-view-preservation.json")
entry = "business-observer.layout.v2:node-retest-team-files:view:business"
expected = [
    {"path": [entry, "bundling"], "before": None, "after": False},
    {"path": [entry, "routing"], "before": None, "after": "curve"},
]
assert not first["valid"] and first["changes"] == expected
before = load(RUN / "personal-views-before-ordinary.json")
after = load(RUN / "first-personal-views-after-final-browser.json")
left, right = json.loads(before["entries"][entry]), json.loads(after["entries"][entry])
assert "routing" not in left and "bundling" not in left
assert right["routing"] == "curve" and right["bundling"] is False
viewer = PACK / "assets/stategraph-viewer/viewer.js"
route = PACK / "assets/stategraph-viewer/edge-routing.js"
source, routing = viewer.read_text(encoding="utf-8"), route.read_text(encoding="utf-8")
quotes = ['routing: cleanRoute(saved?.routing)', 'bundling: saved?.bundling === true',
          'preferences.routing = cleanRoute(analysisSettings.routing)', 'preferences.bundling = analysisSettings.bundling']
assert all(quote in source for quote in quotes)
assert 'edgeRoutes.includes(value) ? value : "curve"' in routing
save(RUN / "preference-default-materialization.json", {
    "analysis_complete": True, "strict_comparison_passed": False,
    "first_failed_comparison_preserved": {"path": str(RUN / "first-final-personal-view-preservation.json"),
                                          "sha256": sha(RUN / "first-final-personal-view-preservation.json")},
    "before_revision": before["revision"], "after_revision": after["revision"],
    "added_keys": expected, "all_preexisting_values_and_entry_identities_preserved": True,
    "effective_routing_and_bundling_unchanged": True,
    "ordinary_browser_control_actions": "The original unchanged driver does not select routing or toggle edge bundling; the actual viewer autosave wrote curve and false.",
    "historical_dom_selector_readback": "Not captured by the original workload; effective selection is established from original source defaults, unchanged control actions and actual persisted output. Independent desktop selector inspection remains separate.",
    "source_evidence": [{"path": str(viewer), "sha256": sha(viewer), "quotes": quotes},
                        {"path": str(route), "sha256": sha(route), "meaning": "Missing or unsupported routing resolves to curve."}],
    "classification": "Ordinary viewer autosave materialized two already-effective defaults. Raw/structural preference equality fails; the user's existing positions, pins, annotations, names and values are unchanged. This is disclosed rather than rolling preferences back or changing the original audit assertion.",
    "preferences_restored_or_modified_by_audit": False, "original_assertion_relaxed": False,
})
print({"strict_comparison_passed": False, "added_default_keys": 2,
       "preexisting_values_preserved": True, "effective_settings_unchanged": True, "restored": False}, flush=True)
