"""Select the immutable repair27 provider without changing application contracts."""
import sys
from runtime_tools import APP, RUN, PACK, CHANGE, load, save, sha, cli

before = load(RUN / "before-seal.json")
inspection = load(RUN / "inspect-provider27-before-review.json")
assert not inspection["errors"]
assert inspection["review_errors"] == ["review belongs to an older candidate"]
assert all(not row["changed"] for row in load(RUN / "managed-upgrade-hashes.json")["paths"])
assert all(sha(APP / name) == value for name, value in before["protected_hashes"].items())
assert all(sha(APP / name) == value for name, value in before["record_hashes"].items())
for name in before["source_hashes"]:
    if name not in {CHANGE + "/review.json", CHANGE + "/verification.json"}:
        assert sha(APP / name) == before["source_hashes"][name], name
assert load(APP / "sync.json")["test_commands"] == before["test_commands"]
assert load(APP / "sync.json")["timeout_seconds"] == before["timeout_seconds"] == 180
review = load(APP / CHANGE / "review.json")
review["candidate_id"] = inspection["candidate_id"]
review["provider_upgrade"] = {
    "kind": "Coordinator-authorized immutable repair27 context-closure provider selection",
    "commit": "66efb5e24ae4b702bfa8f0515c90a3f2c2e637c4",
    "manifest_sha256": "9163f3fe421bb5f1e63aef58acdc7dc6c6246abb8324d5ccf28b27e97f60e58f",
    "owned_files_verified": 466,
    "managed_adapter_plan": "All three JavaScript adapters and receipt already match canonical bytes",
    "manual_adapter_edits": False,
    "locked_parser_dependencies_present": True,
    "native_fields_preserved": 568,
    "original_assertions_preserved": 230,
    "test_commands": 6,
}
review["decisions"]["probes"]["reason"] += (
    " The coordinator released repair27 and the exclusive actual runtime slot. Select immutable context-closure provider "
    "66efb5e24ae4b702bfa8f0515c90a3f2c2e637c4 through canonical plan/apply/check. All three managed JavaScript adapter bytes "
    "and the receipt remain unchanged. The provider retains recent selected values with true parent enter/return metadata; "
    "old failed recordings remain unchanged. Run all six registered commands, fifteen native cases and the original ordinary "
    "real-server on/off/fault browser workload with two consecutive recordings once, followed by complete post-verification. "
    "Preserve all fields, assertions, queue capacities and the 180-second case timeout."
)
review["validation_scope"] = (
    "Repair27 immutable installation and normal managed upgrade passed. Current personal preferences at revision 291 form "
    "the preservation baseline, including authorized coordinator desktop changes. Native, recording and post-verification "
    "must all complete before leaving actual-var services and fresh real live producer history for independent desktop, "
    "Timeline and source inspection. Preserve failures and continue only independent checks with valid prerequisites. "
    "No pass-selection retry, old-record rewriting, baseline reset, accept, capacity/deadline change or announcement refactor."
)
save(APP / CHANGE / "review.json", review)
sys.path.insert(0, str(PACK / "scripts"))
from bo_observer.model_io import read_model
from behavior_model import capture
model = read_model(APP / "bo_stategraph/project.json", project_root=APP)
build = capture(APP, model)
save(RUN / "derived-build.json", build)
save(RUN / "candidate-build.json", {
    "candidate_id": inspection["candidate_id"], "build_id": build["build_id"],
    "before_candidate": before["before_candidate"], "before_build": before["before_build"],
    "build_changed_by_provider_selection": build["build_id"] != before["before_build"],
    "managed_js_bytes_changed": False, "full_runtime_verified": False, "accept_executed": False,
})
save(RUN / "provider-files-runtime-baseline.json", load(RUN / "provider-files-before.json"))
save(RUN / "static-upgrade-preservation.json", {
    "valid": True, "all_protected_source_data_and_preferences_unchanged": True,
    "old_records_unchanged": len(before["record_hashes"]), "six_commands_unchanged": True,
    "case_timeout_unchanged": True, "managed_plan_apply_check_saved": True,
    "managed_adapter_hashes_unchanged": True, "owned466_exact": True,
    "parser_dependencies_already_present": True, "manual_installation_edit": False,
})
print({"candidate_id": inspection["candidate_id"], "build_id": build["build_id"],
       "build_changed": build["build_id"] != before["before_build"], "old_records": len(before["record_hashes"])}, flush=True)
cli("inspect-ready-native", "change_sync.py", "inspect")
