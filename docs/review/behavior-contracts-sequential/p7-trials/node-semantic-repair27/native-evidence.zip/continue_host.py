"""Continue the original gate on the explicitly authorized Windows host."""
import os
import tempfile
from runtime_tools import APP, RUN, cli, save

save(RUN / "host-environment.json", {
    "authorization": "Coordinator explicitly authorized original commands on the Windows host after preserving the sandbox snapshot PermissionError.",
    "cwd": os.getcwd(), "temp_directory": tempfile.gettempdir(),
    "app_root": str(APP), "business_source_or_database_location_changed": False,
    "sandbox_failure_reference": str(RUN / "verify-before-browser.json"),
    "diagnostic_reference": str(RUN / "collector-permission-diagnostic.json"),
})
value = cli("verify-before-browser-host", "change_sync.py", "verify", allow_failure=True)
print({"valid": value.get("valid"), "errors": value.get("errors"),
       "tests": value.get("tests"), "candidate_id": value.get("candidate_id")}, flush=True)
