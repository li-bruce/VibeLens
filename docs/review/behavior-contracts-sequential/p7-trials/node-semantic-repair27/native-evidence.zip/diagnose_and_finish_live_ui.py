"""Diagnose bootstrap readiness, then create new live history with real UI actions."""
import asyncio
from datetime import datetime, timezone
import json
import time
import traceback
from urllib.parse import urlsplit
import urllib.request
from playwright.async_api import async_playwright, expect
from runtime_tools import APP, RUN, load, save, sha

OUT = RUN / "live"
BASE, GRAPH = "http://127.0.0.1:8925", "http://127.0.0.1:8926"
services = load(OUT / "services.json")
save(OUT / "fresh-live-browser-first-failure.json", {
    "script": str(RUN / "fresh_live_ui.py"), "script_sha256": sha(RUN / "fresh_live_ui.py"),
    "observed_exit_code": 1, "exception": "playwright TimeoutError",
    "message": "Timeout 30000ms exceeded while waiting for login response",
    "first_native_history_reference": str(OUT / "after-fresh-failure-view.json"),
    "first_native_history_events": 6, "login_post_observed": False,
    "historical_dom_at_failure": "The original helper did not save it; exact original interleaving cannot be reconstructed.",
    "original_ordinary_workload_unchanged": True,
})

def get(url):
    with urllib.request.urlopen(url, timeout=35) as response:
        return json.load(response)

before = get(GRAPH + "/api/view")
before_ids = {event["id"] for event in before["events"]}
save(OUT / "view-before-corrected-ui.json", before)
started = datetime.now(timezone.utc).isoformat()
requests, responses, page_errors = [], [], []
diagnostic = {}

async def dom(page):
    return await page.evaluate("""() => ({username_id: document.querySelector('#username').id,
      username_name: document.querySelector('#username').name,
      username_value: document.querySelector('#username').value,
      password_id: document.querySelector('#password').id,
      password_name: document.querySelector('#password').name,
      password_length: document.querySelector('#password').value.length,
      login_form_valid: document.querySelector('#login-form').checkValidity(),
      login_visible: !document.querySelector('#login-screen').hidden})""")

async def main():
    async with async_playwright() as playwright:
        browser = await playwright.chromium.launch(channel="chrome", headless=True)
        context = await browser.new_context(viewport={"width": 1440, "height": 1000})
        page = await context.new_page()
        ready, release = asyncio.Event(), asyncio.Event()
        async def hold_actual_boot(route):
            response = await route.fetch()
            body = await response.json()
            assert response.status == 200 and body.get("user") is None
            diagnostic["actual_origin_response"] = {"status": response.status, "body": body}
            ready.set()
            await release.wait()
            await route.fulfill(response=response)
        await page.route(BASE + "/api/auth/session", hold_actual_boot)
        page.on("request", lambda request: requests.append({"method": request.method, "path": urlsplit(request.url).path}))
        page.on("response", lambda response: responses.append({"status": response.status, "path": urlsplit(response.url).path}))
        page.on("pageerror", lambda error: page_errors.append(str(error)))
        try:
            await page.goto(BASE + "/", wait_until="domcontentloaded")
            await asyncio.wait_for(ready.wait(), timeout=30)
            await page.get_by_role("textbox", name="用户名", exact=True).fill("alice")
            await page.get_by_role("textbox", name="密码", exact=True).fill("readiness-probe")
            diagnostic["before_boot_response_applied"] = await dom(page)
            release.set()
            await page.wait_for_function("document.getElementById('password').value === ''")
            diagnostic["after_boot_response_applied"] = await dom(page)
            assert diagnostic["before_boot_response_applied"]["password_length"] > 0
            assert diagnostic["after_boot_response_applied"]["password_length"] == 0
            assert not diagnostic["after_boot_response_applied"]["login_form_valid"]
            assert not any(item == {"method": "POST", "path": "/api/auth/login"} for item in requests)
            diagnostic.update({"reproduced": True, "simulated_timing": True,
                "meaning": "A response barrier delays the actual unchanged 200/user-null session reply. Bootstrap clears a password entered before initialization finishes. No dummy password is submitted; no response or native success is fabricated.",
                "first_failure_exact_schedule_proven": False,
                "helper_correction": "Complete initial session handling before filling and submitting actual credentials.",
                "business_source_changed": False, "app_js_sha256": sha(APP / "public/app.js")})
            save(OUT / "bootstrap-readiness-diagnostic.json", diagnostic)
            await page.unroute(BASE + "/api/auth/session", hold_actual_boot)
            await page.get_by_role("textbox", name="用户名", exact=True).fill("alice")
            await page.get_by_role("textbox", name="密码", exact=True).fill("DemoPass!2026")
            credentials = await dom(page)
            assert credentials["username_value"] == "alice" and credentials["password_length"] == 13
            assert credentials["login_form_valid"]
            save(OUT / "real-login-form-preconditions.json", {**credentials, "password_value_saved": False})
            async with page.expect_response(lambda response: response.url == BASE + "/api/auth/login" and response.request.method == "POST") as response_info:
                await page.get_by_role("button", name="登录", exact=True).click()
            response = await response_info.value
            assert response.status == 200
            await expect(page.locator("#workspace")).to_be_visible()
            await expect(page.get_by_role("heading", name="团队文件", exact=True)).to_be_visible()
            await expect(page.locator("#file-list article").first).to_be_visible()
            async with page.expect_response(lambda response: response.url == BASE + "/api/files" and response.request.method == "GET") as response_info:
                await page.get_by_role("button", name="刷新列表", exact=True).click()
            response = await response_info.value
            assert response.status == 200
            body = await response.json()
            await expect(page.locator("#file-count")).to_have_text(str(body["count"]) + " 个文件")
            diagnostic["real_authenticated_dom"] = {"display_name": await page.locator("#display-name").inner_text(),
                "file_count": await page.locator("#file-count").inner_text(),
                "rendered_rows": await page.locator("#file-list article").count()}
            assert diagnostic["real_authenticated_dom"]["rendered_rows"] == body["count"] > 0
            await page.screenshot(path=str(OUT / "fresh-live-files.png"), full_page=True)
            (OUT / "fresh-live-files.html").write_text(await page.content(), encoding="utf-8")
        except BaseException:
            save(OUT / "corrected-live-ui-failure.json", {"traceback": traceback.format_exc(), "requests": requests, "responses": responses,
                "dom": await dom(page), "diagnostic": diagnostic})
            await page.screenshot(path=str(OUT / "corrected-live-ui-failure.png"), full_page=True)
            raise
        finally:
            release.set()
            await context.close()
            await browser.close()

asyncio.run(main())
deadline = time.monotonic() + 35
while True:
    health, after = get(BASE + "/api/bo/health"), get(GRAPH + "/api/view")
    new = [event for event in after["events"] if event["id"] not in before_ids]
    native = [event for event in new if event.get("run_id") == health["run_id"] and event.get("producer_id") == health["producer_id"]]
    if health["pending"] == 0 and all(any(event["node"] == name and event["phase"] == "return" for event in native) for name in ("login", "list_files")):
        break
    assert time.monotonic() < deadline, "New real UI login/list events did not settle"
    time.sleep(.2)
recordings = get(GRAPH + "/api/recordings")
assert recordings["active"] is None and after["binding_status"]["status"] == "current"
assert after["manifest"]["build_id"] == services["build_id"]
assert not health["errors"] and not health["dropped"] and not health["capture_control_errors"]
assert health["tracing"]["open_spans"] == 0 and not page_errors
save(OUT / "view-after-ui.json", after)
save(OUT / "new-live-events.json", new)
save(OUT / "native-health-after-ui.json", health)
save(OUT / "recordings-after-ui.json", recordings)
save(OUT / "real-ui-network.json", {"requests": requests, "responses": responses, "page_errors": page_errors,
     "request_queries_bodies_and_credentials_saved": False})
result = {"valid": True, "started_at": started, "finished_at": datetime.now(timezone.utc).isoformat(),
    "build_id": services["build_id"], "candidate_id": services["candidate_id"], "provider": services["provider"],
    "database": services["database"], "before_live_events": len(before["events"]), "after_live_events": len(after["events"]),
    "new_live_events": len(new), "new_native_events": len(native), "run_id": health["run_id"], "producer_id": health["producer_id"],
    "new_event_ids": [event["id"] for event in new], "dom": diagnostic["real_authenticated_dom"], "health": health,
    "first_browser_failure_preserved": True, "bootstrap_timing_diagnostic_is_simulated": True,
    "real_login_list_provenance": "Actual Chrome form login and refresh, followed by new native producer/run event-ID delta; initial response barrier is separate diagnostic evidence.",
    "original_ordinary_workload_rerun": False, "recording_active": None, "services_left_running": True,
    "business_source_changed": False, "page_errors": page_errors}
save(OUT / "fresh-live-ui-summary.json", result)
print({key: result[key] for key in ("valid", "new_live_events", "new_native_events", "run_id", "producer_id", "dom", "services_left_running")}, flush=True)
