"""Freeze only this successful ordinary run, affected sources and necessary SQL."""
from datetime import datetime, timezone
from pathlib import Path
import shutil
from runtime_tools import APP, RUN, load, save, sha

identity = load(RUN / "candidate-build.json")
unified = Path(load(APP / "review/runtime/latest-unified-run.json")["path"])
lifecycle = load(unified / "lifecycle.json")
acceptance = load(unified / "artifacts/browser-acceptance.json")
assert lifecycle["completed"] and all(acceptance["checks"].values())
assert lifecycle["build_id"] == acceptance["build_id"] == identity["build_id"]
assert len(acceptance["recordings"]) == 2
assert all(child["pre_cleanup_exit_code"] is None for child in lifecycle["children"])
records = set()
for item in acceptance["recordings"]:
    assert item["status"] == "stopped" and item["events"] > 0 and not item["gaps"]
    assert item["settlement"]["flushed"] and item["settlement"]["pending"] == 0
    identity_id = item["id"]
    records.update(unified.glob("*" + identity_id + "*"))
    records.update((unified / "artifacts").glob("*" + identity_id + "*"))
    records.update((APP / "bo_stategraph/data/recordings").glob("*" + identity_id + "*"))
backup = RUN / "final-browser-database.sqlite"
assert not backup.exists()
shutil.copy2(APP / "var/db/application.sqlite", backup)
build = load(RUN / "derived-build.json")
affected = set(load(RUN / "inspect-ready-native.json")["changed_files"])
sources = affected.intersection(build["files"]) | {"sync.json", "bo_stategraph/project.json", "acceptance.json", "mapping.json",
    "bo_stategraph/config/semantic-names.json", "bo_stategraph/config/views/local.json"}
out = RUN / "after-source"
out.mkdir(exist_ok=False)
for name in sources:
    destination = out / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(APP / name, destination)
result = {"sealed_at": datetime.now(timezone.utc).isoformat(), "candidate_id": identity["candidate_id"], "build_id": identity["build_id"],
    "provider_commit": "66efb5e24ae4b702bfa8f0515c90a3f2c2e637c4", "unified_run": str(unified),
    "recordings": acceptance["recordings"], "checks": acceptance["checks"], "native_health_at_stop": lifecycle["pre_cleanup_native_health"],
    "record_file_sha256": {path.relative_to(APP).as_posix(): sha(path) for path in sorted(records) if path.is_file()},
    "source_sha256": {name: sha(APP / name) for name in sorted(sources)}, "complete_build_input_hashes_reference_only": build["files"],
    "database_backup": {"path": str(backup), "sha256": sha(backup)},
    "new_run_files": {path.relative_to(APP).as_posix(): sha(path) for path in unified.rglob("*") if path.is_file()},
    "old_archive_reference": load(RUN / "before-seal.json")["old_archive_reference"],
    "scope": "Only affected source/definitions, necessary current SQL copy and this ordinary run's new evidence. No recursive old-review/archive or dependency ZIP; no rewritten events/preferences."}
save(RUN / "normal-stop-original-seal.json", result)
save(RUN / "ordinary-unified-pointer.json", {"path": str(unified), "build_id": identity["build_id"]})
print({"sealed": True, "build_id": identity["build_id"], "recordings": acceptance["recordings"], "source_files": len(sources)}, flush=True)
