# Repair27 validation

- [ ] Verify immutable installation and preserve current data/preferences/evidence.
- [ ] Run canonical managed upgrade and static/native gates.
- [ ] Run the original ordinary business workload with two consecutive recordings once.
- [ ] Complete post-verification and independent preservation/SQL/closure audits.
- [ ] If complete, leave real services and fresh live history for independent UI review; do not accept.

Preserve original fields, six commands, assertions, capacities, deadlines and failed records. No pass-selection retries.
