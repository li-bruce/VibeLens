"""Capture a quiescent native data point and the actual retained host processes."""
from datetime import datetime, timezone
import hashlib
import json
import sqlite3
import time
import urllib.request
from runtime_tools import APP, RUN, load, save, sha

OUT = RUN / "live"
services = load(OUT / "services.json")
fresh = load(OUT / "fresh-live-ui-summary.json")
assert fresh["valid"] and not fresh["original_ordinary_workload_rerun"]
def get(url):
    with urllib.request.urlopen(url, timeout=35) as response:
        return json.load(response)

database = APP / "var/db/application.sqlite"
samples = []
for index in range(3):
    image = database.read_bytes()
    samples.append({"at": datetime.now(timezone.utc).isoformat(), "bytes": len(image),
                    "sha256": hashlib.sha256(image).hexdigest()})
    if index < 2:
        time.sleep(1)
assert len({item["sha256"] for item in samples}) == 1
backup = RUN / "database-after-fresh-ui.sqlite"
if backup.exists():
    assert backup.read_bytes() == image
else:
    backup.write_bytes(image)
def connect(blob):
    connection = sqlite3.connect(":memory:")
    connection.deserialize(blob)
    connection.execute("PRAGMA query_only=ON")
    return connection

old, current = connect((RUN / "database-before.sqlite").read_bytes()), connect(image)
tables = []
for table in ("users", "sessions", "files", "grants", "tasks", "announcements"):
    metadata = old.execute("PRAGMA table_info(" + table + ")").fetchall()
    columns = [row[1] for row in metadata]
    keys = [row[1] for row in sorted(metadata, key=lambda row: row[5]) if row[5]]
    original = old.execute("SELECT * FROM " + table).fetchall()
    missing, changed = 0, 0
    for row in original:
        actual = current.execute("SELECT * FROM " + table + " WHERE " + " AND ".join(key + "=?" for key in keys),
            [row[columns.index(key)] for key in keys]).fetchone()
        missing += actual is None
        changed += actual is not None and actual != row
    tables.append({"table": table, "original_rows": len(original),
                   "current_rows": current.execute("SELECT COUNT(*) FROM " + table).fetchone()[0],
                   "missing_original": missing, "changed_original": changed})
assert all(not item["missing_original"] and not item["changed_original"] for item in tables)
task_states = dict(current.execute("SELECT status, COUNT(*) FROM tasks GROUP BY status"))
assert not task_states.get("queued", 0) and not task_states.get("preparing", 0)
old.close()
current.close()
health, view, recordings = get("http://127.0.0.1:8925/api/bo/health"), get("http://127.0.0.1:8926/api/view"), get("http://127.0.0.1:8926/api/recordings")
assert health["pending"] == 0 and health["errors"] == health["dropped"] == 0
assert health["tracing"]["open_spans"] == 0 and recordings["active"] is None
assert view["binding_status"]["status"] == "current" and view["manifest"]["build_id"] == services["build_id"]
preferences = load(APP / "bo_stategraph/config/views/local.json")
preference_point = {"revision": preferences["revision"], "sha256": sha(APP / "bo_stategraph/config/views/local.json"),
    "meaning": "Point-in-time observation during authorized main-session desktop checks. Main-session view changes are not compared with or restored to the earlier ordinary-run baseline."}
save(OUT / "native-health-at-handoff.json", health)
save(OUT / "view-at-handoff.json", view)
processes = load(OUT / "host-processes-and-ports-observed.json")
listeners = {item["LocalPort"]: item["OwningProcess"] for item in processes["listeners"]}
assert set(listeners) == {8925, 8926} and listeners[8925] == services["app"]
by_pid = {item["ProcessId"]: item for item in processes["processes"]}
viewer_pid = listeners[8926]
assert viewer_pid == services["viewer"] or by_pid[viewer_pid]["ParentProcessId"] == services["viewer"]
assert "context-closure-skills" in by_pid[viewer_pid]["CommandLine"]
save(OUT / "host-processes-and-ports.json", processes)
save(RUN / "final-live-quiescence.json", {
    "valid": True, "samples": samples, "native_sql_stable_during_samples": True,
    "agent_business_operations_paused": True, "auxiliary_chrome_closed": True,
    "native_services_disabled_or_worker_changed": False, "tables": tables, "task_states": task_states,
    "database_backup": {"path": str(backup), "sha256": sha(backup)},
    "native_health": health, "services": services, "host_processes_and_ports": processes,
    "listener_pids": listeners, "viewer_launcher_pid": services["viewer"],
    "recording_active": None, "binding_status": view["binding_status"],
    "personal_preferences_point_during_main_session_checks": preference_point,
    "independent_desktop_inspection_pending": True, "accept_executed": False,
})
print({"quiescent": True, "app_pid": listeners[8925], "viewer_pid": listeners[8926], "viewer_launcher_pid": services["viewer"],
       "tables": tables, "task_states": task_states, "native_events": len(view["events"]),
       "ports": processes["listeners"], "agent_business_operations_paused": True}, flush=True)
