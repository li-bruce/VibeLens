"""Seal the original successful run, then perform the complete canonical gate."""
import runpy
import shutil
from runtime_tools import APP, RUN, cli, load

assert load(RUN / "ordinary-browser-recording-command.json")["exit_code"] == 0
shutil.copy2(APP / "bo_stategraph/config/views/local.json", RUN / "personal-views-after-ordinary.json")
runpy.run_path(str(RUN / "seal_browser.py"), run_name="__main__")
value = cli("verify-after-browser", "change_sync.py", "verify", allow_failure=True)
print({"valid": value.get("valid"), "errors": value.get("errors"),
       "tests": value.get("tests"), "candidate_id": value.get("candidate_id")}, flush=True)
