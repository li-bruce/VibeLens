"""Validate the independent repair27 installation and seal the small affected scope."""
from datetime import datetime, timezone
from pathlib import Path
import re
import shutil
from runtime_tools import APP, RUN, PACK, OLD_PACK, REPOSITORY, CHANGE, load, save, sha

front = APP / "review/runtime/frontend-session-fix-20261121"
assert load(front / "final-static-preservation.json")["valid"]
proof_path = APP.parent / "context-closure-provider-commit.json"
proof = load(proof_path)
assert proof["valid"] and proof["commit"] == "66efb5e24ae4b702bfa8f0515c90a3f2c2e637c4"
manifest_path = REPOSITORY / "docs/review/behavior-contracts-sequential/p7-trials/repair-27/installation-final.json"
manifest = load(manifest_path)
assert sha(manifest_path) == proof["manifest_sha256"] == "9163f3fe421bb5f1e63aef58acdc7dc6c6246abb8324d5ccf28b27e97f60e58f"
assert manifest["owned_files"] == len(manifest["files"]) == 466
owned = {row["path"]: row["sha256"] for row in manifest["files"]}
errors = [name for name, value in owned.items() if not (PACK / name).is_file() or sha(PACK / name) != value]
assert not errors, errors
provider_files = {path.relative_to(PACK).as_posix(): sha(path) for path in PACK.rglob("*")
                  if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc"}
save(RUN / "provider-files-before.json", provider_files)
save(RUN / "provider-owned-verification.json", {"valid": True, "commit": proof["commit"], "owned_files_checked": len(owned),
     "owned_mismatches": errors, "full_installed_files": len(provider_files), "manifest": str(manifest_path),
     "manifest_sha256": sha(manifest_path), "proof": str(proof_path), "proof_sha256": sha(proof_path)})

before = RUN / "before"
before.mkdir(exist_ok=False)
paths = ["public/app.js", "tooling/frontend_session_checks.py", "sync.json", "implementation.json", "bo_stategraph/project.json",
         "bo_stategraph/config/semantic-names.json", "bo_stategraph/bo_runtime.mjs", "bo_stategraph/bo_capture.mjs",
         "bo_stategraph/bo_http.mjs", "bo_stategraph/integration.json", CHANGE + "/review.json", CHANGE + "/verification.json"]
for name in paths:
    target = before / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(APP / name, target)
shutil.copy2(APP / "var/db/application.sqlite", RUN / "database-before.sqlite")
protected = ["var/db/application.sqlite", "bo_stategraph/config/views/local.json", CHANGE + "/baseline.json",
             "initial-node-app/baseline.json", "initial-node-app/accepted.json", "initial-node-app/review.json", "initial-node-app/verification.json",
             "behavior.json", "discovery.json", "acceptance.json", "mapping.json", "tooling/browser_acceptance.py",
             "tooling/unified_browser_run.py", "tooling/project_checks.py", "tooling/observe.py", "manifest.json"]
protected += [path.relative_to(APP).as_posix() for folder in (APP / "src", APP / "tests", APP / "integrations") for path in folder.rglob("*") if path.is_file() and "__pycache__" not in path.parts]
records = {path.relative_to(APP).as_posix(): sha(path) for path in (APP / "bo_stategraph/data/recordings").glob("*.json") if re.fullmatch(r"[0-9a-f]{32}", path.stem)}
save(RUN / "before-seal.json", {"prepared_at": datetime.now(timezone.utc).isoformat(), "source_hashes": {name: sha(APP / name) for name in paths},
     "protected_hashes": {name: sha(APP / name) for name in protected}, "record_hashes": records,
     "frontend_handoff": {"path": str(front / "handoff-index.json"), "sha256": sha(front / "handoff-index.json")},
     "before_candidate": load(APP / "review/runtime/recording-copy-runtime-20261121/candidate-build.json")["candidate_id"], "before_build": load(APP / "review/runtime/recording-copy-runtime-20261121/candidate-build.json")["build_id"],
     "test_commands": load(APP / "sync.json")["test_commands"], "timeout_seconds": load(APP / "sync.json")["timeout_seconds"],
     "old_archive_reference": load(APP / "review/runtime/settlement-runtime-20261121/post-browser-before-scope-and-copy/seal.json")["archive_reference_only"],
     "data_backup": {"path": str(RUN / "database-before.sqlite"), "sha256": sha(RUN / "database-before.sqlite")},
     "personal_views_revision": load(APP / "bo_stategraph/config/views/local.json")["revision"],
     "no_recursive_archive_or_dependency_copy": True})
print({"provider_owned_checked": 466, "full_provider_files": len(provider_files), "old_records": len(records),
       "frontend_preservation_complete": True, "before_candidate": load(APP / "review/runtime/recording-copy-runtime-20261121/candidate-build.json")["candidate_id"]}, flush=True)

shutil.copy2(APP / "bo_stategraph/config/views/local.json", RUN / "personal-views-before-upgrade.json")
shutil.copy2(APP / "var/native-order.jsonl", RUN / "native-order-before.jsonl")
assert (PACK / "scripts/bo_observer/adapters/javascript/node_modules/typescript/package.json").is_file()
