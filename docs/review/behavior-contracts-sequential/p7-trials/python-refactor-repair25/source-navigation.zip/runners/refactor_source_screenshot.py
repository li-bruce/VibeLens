"""Capture the real source panel after scrolling the matched declaration into view."""
import json
from pathlib import Path
from playwright.sync_api import sync_playwright

out = Path('.validation/p7-trials/python-refactor-settlement-source-visible')
out.mkdir(parents=True, exist_ok=False)
ready = '() => window.graphDebug?.graph && !graphDebug.sourceBusy && !graphDebug.layoutBusy && !graphDebug.geometryBusy'
result = {'valid': False, 'purpose': 'Readable evidence framing; original source assertions retained separately'}
try:
    with sync_playwright() as driver:
        browser = driver.chromium.launch(executable_path='C:/Program Files/Google/Chrome/Application/chrome.exe',
                                        headless=True, args=['--enable-unsafe-swiftshader'])
        page = browser.new_page(viewport={'width': 1600, 'height': 1100})
        page.goto('http://127.0.0.1:8876/graph?lang=zh-CN', wait_until='domcontentloaded')
        page.wait_for_function(ready, timeout=60000)
        page.select_option('#analysis-view', 'business')
        page.wait_for_function(ready, timeout=60000)
        if page.locator('#layered-toggle').inner_text() != '2D':
            page.click('#layered-toggle')
        page.click('#collapse')
        page.click('#fit')
        page.wait_for_function(ready, timeout=60000)
        point = page.evaluate('''() => {
            const e=[...document.querySelectorAll('#semantic [data-node-id]')]
                .find(e=>e.dataset.nodeId==='cancel_download');
            return e ? {x:+e.dataset.screenX,y:+e.dataset.screenY} : null;
        }''')
        assert point
        page.mouse.click(point['x'], point['y'], button='right')
        page.click('#source')
        matched = page.locator('#source-code mark').filter(has_text='def cancel_download(').first
        matched.wait_for(state='attached')
        title = page.locator('#detail-title').inner_text()
        assert 'app/downloads.py' in title, title
        matched.scroll_into_view_if_needed()
        assert matched.is_visible()
        box = matched.bounding_box()
        panel = page.locator('#node-details').bounding_box()
        assert box and panel and box['y'] >= panel['y'] and box['y'] + box['height'] <= panel['y'] + panel['height']
        page.screenshot(path=str(out / 'source-visible.png'))
        page.locator('#node-details').screenshot(path=str(out / 'source-panel.png'))
        result.update(valid=True, title=title, matched=matched.inner_text(), bounds=box, panel=panel)
        browser.close()
except Exception as error:
    result['failure'] = str(error)
finally:
    (out / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, ensure_ascii=False))
raise SystemExit(not result['valid'])
