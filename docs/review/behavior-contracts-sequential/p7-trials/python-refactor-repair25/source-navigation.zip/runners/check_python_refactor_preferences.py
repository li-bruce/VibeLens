"""Compare persisted preferences before and after real desktop interactions."""
import hashlib
import json
from pathlib import Path

root = Path.cwd()
before = json.loads((root / '.validation/p7-trials/python-refactor-settlement-ui-scope/scope.json').read_text())['preferences']
project = root / '.validation/p7-trials/python-retest-app'
after = json.loads((project / 'bo_stategraph/config/views/local.json').read_text())
missing_entries = sorted(set(before['entries']) - set(after['entries']))
assert not missing_entries, missing_entries
rows = []
for key, raw in before['entries'].items():
    old = json.loads(raw) if isinstance(raw, str) else raw
    current_raw = after['entries'][key]
    current = json.loads(current_raw) if isinstance(current_raw, str) else current_raw
    for label, a, b in (
        ('positions', old.get('positions', {}), current.get('positions', {})),
        ('spatial_positions', old.get('spatial', {}).get('positions', {}), current.get('spatial', {}).get('positions', {})),
        ('annotations', old.get('annotations', {}), current.get('annotations', {})),
    ):
        if not isinstance(a, dict) or not isinstance(b, dict):
            raise TypeError((key, label))
        removed = sorted(set(a) - set(b))
        assert not removed, (key, label, removed)
        rows.append({'entry': key, 'kind': label, 'prior_count': len(a),
                     'retained_count': len(a), 'changed_ids': [n for n in a if a[n] != b[n]]})
    old_custom = {item['id']: item for item in old.get('custom', [])}
    new_custom = {item['id']: item for item in current.get('custom', [])}
    assert set(old_custom) <= set(new_custom), key
    if old_custom:
        rows.append({'entry': key, 'kind': 'custom_views', 'prior_count': len(old_custom),
                     'retained_count': len(old_custom),
                     'changed_ids': [n for n in old_custom if old_custom[n] != new_custom[n]]})
report = {'valid': True, 'scope': 'No prior preference identities removed by upgrade or UI. Actual drag, fit, filters and re-save operations may change values; no old document was restored.',
          'before_revision': before['revision'], 'after_revision': after['revision'],
          'before_entries': len(before['entries']), 'after_entries': len(after['entries']),
          'checks': rows, 'after_sha256': hashlib.sha256((project / 'bo_stategraph/config/views/local.json').read_bytes()).hexdigest()}
output = root / '.validation/p7-trials/python-refactor-settlement-ui/preference-continuity.json'
with output.open('x', encoding='utf-8') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: value for key, value in report.items() if key != 'checks'}))
