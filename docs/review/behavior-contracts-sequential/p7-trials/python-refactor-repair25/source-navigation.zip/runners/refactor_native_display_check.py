"""Verify the repaired real viewer's captions and moved-function source panel.

No response fixtures or preference restoration are used. Source bytes come from
the actual application's current file and the viewer's on-demand response.
"""
import argparse
import hashlib
import json
from pathlib import Path
import traceback
from urllib.parse import parse_qs, urlsplit
from playwright.sync_api import sync_playwright

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--url', required=True)
parser.add_argument('--project', type=Path, required=True)
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
args.out.mkdir(parents=True, exist_ok=False)
ready = '() => window.graphDebug?.graph && !graphDebug.sourceBusy && !graphDebug.layoutBusy && !graphDebug.geometryBusy'
result = {'valid':False,'checks':[],'errors':[],'source_responses':[]}
targets = {'policy-operation:cancel_download':{'en':'Cancellation permission','zh-CN':'取消任务权限'},
           'policy:network':{'en':'Permission rules','zh-CN':'权限规则网'}}


def settle(page):
    page.wait_for_function(ready, timeout=60000)


def menu(page, identity, action):
    point = page.evaluate('''id => {
        const e = [...document.querySelectorAll('#semantic [data-node-id]')].find(e=>e.dataset.nodeId===id);
        return e ? {x:+e.dataset.screenX,y:+e.dataset.screenY,caption:e.textContent} : null;
    }''',identity)
    assert point, identity
    page.mouse.click(point['x'],point['y'],button='right')
    assert identity in page.evaluate('graphDebug.selectedNodes'), (identity,page.evaluate('graphDebug.selectedNodes'))
    page.click(action)
    page.locator('#node-details').wait_for(state='visible')
    return point


def source_response(response):
    if urlsplit(response.url).path in {'/api/source', '/api/code/source'} and response.ok:
        data = response.json()
        result['source_responses'].append({'url':response.url,'data':data})


try:
    with sync_playwright() as driver:
        browser = driver.chromium.launch(executable_path='C:/Program Files/Google/Chrome/Application/chrome.exe',
                                        headless=True,args=['--enable-unsafe-swiftshader'])
        page = browser.new_page(viewport={'width':1600,'height':1100})
        page.on('pageerror',lambda error:result['errors'].append(str(error)))
        page.on('response',source_response)
        for language in ('zh-CN','en'):
            page.goto(args.url.split('?')[0]+'?lang='+language,wait_until='domcontentloaded')
            settle(page)
            if page.locator('#name-mode').get_attribute('aria-checked')!='true':
                page.click('#name-mode')
                settle(page)
            page.select_option('#analysis-view','rules')
            settle(page)
            page.click('#collapse')
            for mode in ('2D','3D'):
                if page.locator('#layered-toggle').inner_text()!=mode:
                    page.click('#layered-toggle')
                page.click('#fit')
                settle(page)
                for index,(identity,captions) in enumerate(targets.items()):
                    point = menu(page,identity,'#details')
                    actual = page.locator('#detail-title').inner_text()
                    assert point['caption']==actual==captions[language],(language,mode,identity,actual)
                    filename=f'{language}-{mode}-{index}.png'
                    page.screenshot(path=str(args.out/filename))
                    result['checks'].append({'locale':language,'mode':mode,'id':identity,
                                             'caption':actual,'screenshot':filename})
                    page.click('#close-detail')
        page.select_option('#analysis-view','business')
        settle(page)
        if page.locator('#layered-toggle').inner_text()!='2D':
            page.click('#layered-toggle')
        page.click('#collapse')
        page.click('#fit')
        settle(page)
        menu(page,'cancel_download','#source')
        page.wait_for_function("[...document.querySelectorAll('#source-code mark')].some(mark=>mark.textContent.includes('def cancel_download('))")
        expected = (args.project/'app/downloads.py').read_text(encoding='utf-8')
        source = next(item for item in result['source_responses']
                      if parse_qs(urlsplit(item['url']).query).get('path') == ['app/downloads.py'])
        assert source['data']['source']==expected
        marks = page.locator('#source-code mark').all_text_contents()
        assert any('def cancel_download(' in mark for mark in marks),marks
        page.screenshot(path=str(args.out/'moved-source.png'))
        result['source']={'path':'app/downloads.py','sha256':hashlib.sha256(expected.encode()).hexdigest(),
                          'full_file_loaded':True,'highlighted':marks,'screenshot':'moved-source.png'}
        assert not result['errors']
        result['valid']=True
        browser.close()
except Exception as error:
    result['failure']=str(error)
    result['traceback']=traceback.format_exc()
finally:
    # Keep paths and fingerprints in the report; source is already archived with
    # the native project and need not be duplicated for every language screenshot.
    for item in result['source_responses']:
        text=item['data'].pop('source','')
        item['source_sha256']=hashlib.sha256(text.encode()).hexdigest()
    (args.out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'valid':result['valid'],'captions':len(result['checks']),'failure':result.get('failure')}))
raise SystemExit(not result['valid'])
