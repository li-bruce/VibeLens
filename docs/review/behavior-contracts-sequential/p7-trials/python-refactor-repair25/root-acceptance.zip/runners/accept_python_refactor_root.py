"""Run the normal local acceptance gate after independently checking trial evidence.

This runner records the root chat's operation separately from the blocked trial
attempt. It never manufactures a receipt or changes the project's expectations.
"""

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT / '.validation/p7-trials/python-retest-app'
CASE = PROJECT / 'review/download-refactor-v1/repair25-acceptance'
PROVIDER = ROOT / '.validation/p7-trials/capture-settlement-skills/vibelens'
OUT = ROOT / '.validation/p7-trials/python-refactor-root-acceptance'
CANDIDATE = '28eba23b64ed788639ce52fc2de57aa41397a9a8e870731cb44c3fd73f51c6af'
BUILD = '356fec482af180f1aa54fa874708f028d3bddc63247d5f6febd32ff8d8e8a251'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def main():
    """Check exact inputs, run canonical accept/check, and retain their real exits."""
    OUT.mkdir(exist_ok=False)
    post = read(CASE / 'post-verify.json')
    assert post['valid'] and post['candidate_id'] == CANDIDATE
    assert all(r['status'] == 'passed' for r in post['reports'].values())
    assert read(PROJECT / '.stategraph/active.json')['change'] == 'download-preparation-refactor-v1'
    assert read(PROJECT / 'manifest.json')['build_id'] == BUILD
    assert not (PROJECT / 'download-preparation-refactor-v1/accepted.json').exists()
    state = read(CASE / 'RUN_STATE.json')
    for relative, expected in state['frozen_source_inputs'].items():
        if relative != 'bo_stategraph/config/views/local.json':
            assert digest(PROJECT / relative) == expected, relative
    ui = ROOT / '.validation/p7-trials/python-refactor-settlement-ui'
    assert read(ui / 'sequence.json')['valid']
    assert read(ROOT / '.validation/p7-trials/python-refactor-settlement-display/result.json')['valid']
    assert read(ROOT / '.validation/p7-trials/python-refactor-settlement-source-visible/result.json')['valid']
    prefs = read(ui / 'preference-continuity-after-source.json')
    local = PROJECT / 'bo_stategraph/config/views/local.json'
    assert prefs['valid'] and prefs['after_revision'] == read(local)['revision'] == 647
    assert digest(local) == prefs['after_sha256']
    before = {}
    with zipfile.ZipFile(OUT / 'before-accept-local.zip', 'x', zipfile.ZIP_DEFLATED) as archive:
        for relative in ('manifest.json', '.stategraph/source-baseline.json',
                         '.stategraph/maintenance.json', 'bo_stategraph/config/views/local.json'):
            path = PROJECT / relative
            if path.exists():
                before[relative] = digest(path)
                archive.write(path, relative)
    write('preflight.json', {'valid': True, 'candidate_id': CANDIDATE, 'build_id': BUILD,
                           'reports': {k: v['status'] for k, v in post['reports'].items()},
                           'before': before, 'preferences_revision': 647,
                           'trial_approval_rejection_retained': True})
    env = dict(os.environ)
    env['TEAM_FILES_DATABASE_URL'] = 'sqlite:///' + (PROJECT / 'var/team.sqlite3').as_posix()
    for command in ('accept', 'check'):
        argv = [sys.executable, '-B', '-X', 'utf8', str(PROVIDER / 'scripts/change_sync.py'),
                command, '--root', str(PROJECT)]
        result = subprocess.run(argv, cwd=PROJECT, env=env, capture_output=True,
                                encoding='utf-8', errors='replace', timeout=420, shell=False)
        (OUT / (command + '.stdout.log')).write_text(result.stdout, encoding='utf-8')
        (OUT / (command + '.stderr.log')).write_text(result.stderr, encoding='utf-8')
        write(command + '-command.json', {'argv': argv, 'exit_code': result.returncode})
        parsed = json.loads(result.stdout)
        write(command + '.json', parsed)
        print(json.dumps({'command': command, 'exit_code': result.returncode, **parsed}), flush=True)
        assert result.returncode == 0 and parsed['valid'] and parsed['candidate_id'] == CANDIDATE
    accepted = read(PROJECT / 'download-preparation-refactor-v1/accepted.json')
    assert accepted['candidate_id'] == CANDIDATE and accepted['build_id'] == BUILD
    assert digest(local) == prefs['after_sha256']
    write('result.json', {'valid': True, 'accepted': accepted, 'preferences_revision': 647,
                         'preferences_sha256': digest(local), 'services_left_running': True,
                         'formal_receipts_created_by': 'canonical change_sync.py accept/check'})


if __name__ == '__main__':
    main()
