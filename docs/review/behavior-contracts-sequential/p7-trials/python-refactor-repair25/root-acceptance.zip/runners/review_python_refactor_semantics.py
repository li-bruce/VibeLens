"""Compare accepted model meaning with the source-only refactor's real artifacts."""

from collections import Counter
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT / '.validation/p7-trials/python-retest-app'
OUT = ROOT / 'docs/review/behavior-contracts-sequential/p7-trials/python-refactor-repair25'
PREVIOUS = OUT.parent / 'python-cancellation-ordered/source-and-models.zip'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


with zipfile.ZipFile(PREVIOUS) as archive:
    before = json.loads(archive.read('project/discovery.json'))
    old_model = json.loads(archive.read('project/behavior.json'))
    old_machines = json.loads(archive.read('project/bo_stategraph/machines.json'))
after = read(PROJECT / 'discovery.json')
model = read(PROJECT / 'behavior.json')
keys = ('networks', 'objects', 'facts', 'state_models', 'policy', 'crosslinks',
        'expectations', 'confirmations', 'changes', 'construction', 'participation')
equal = {key: before[key] == after[key] for key in keys}
assert all(equal.values()), equal
assert old_machines == read(PROJECT / 'bo_stategraph/machines.json')
old_actions = {n['id']: n for n in old_model['nodes'] if n['kind'] == 'action'}
new_actions = {n['id']: n for n in model['nodes'] if n['kind'] == 'action'}
assert old_actions.keys() == new_actions.keys()
for key, old in old_actions.items():
    assert old.get('capture') == new_actions[key].get('capture'), key
    assert old.get('requirements') == new_actions[key].get('requirements'), key
scope = read(ROOT / '.validation/p7-trials/python-refactor-settlement-ui-scope/scope.json')
for relative, expected in scope['source_hashes'].items():
    assert hashlib.sha256((PROJECT / relative).read_bytes()).hexdigest() == expected, relative
review = read(PROJECT / 'download-preparation-refactor-v1/review.json')
layers = read(ROOT / '.validation/p7-trials/python-refactor-settlement-ui/layers/result.json')
assert layers['valid'] and not layers['errors']
result = {
    'valid': True,
    'meaning_comparison': equal,
    'native_state_definitions_equal': True,
    'business_action_ids_and_capture_fields_preserved': sorted(new_actions),
    'source_moves': review['source_moves'],
    'source_files_checked': len(scope['source_hashes']),
    'base_inventory': {'nodes': len(scope['nodes']), 'edges': len(scope['edges'])},
    'actual_desktop_presets': [{
        'preset': row['preset'],
        'modes': [{'mode': mode['mode'], 'shown': len(mode['shown'])} for mode in row['modes']],
    } for row in layers['checks']],
    'note': 'Base stored-data nodes receive their display layer through the shared projection. '
            'This report uses actual browser presets rather than treating a missing raw layer '
            'field as missing data. File/folder nodes have static provenance, not invented lifetimes.',
}
(OUT / 'source-refactor-review.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'valid': True, 'source_files': result['source_files_checked'],
                  'business_actions': len(new_actions), 'source_moves': len(review['source_moves'])}))
