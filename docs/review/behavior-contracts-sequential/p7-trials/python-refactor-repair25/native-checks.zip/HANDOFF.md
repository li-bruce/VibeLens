# Repair-25 Python refactor: independent UI handoff

Browser testing has stopped. Normal run.py with the default worker and the new installed observer remain running. No accept or business iteration was started.

- App: http://127.0.0.1:8875
- Viewer: http://127.0.0.1:8876/graph?lang=zh-CN
- SQLite: `C:\Users\Lvi_P\Documents\Work\CF\平台软著\SoftwareStatusObserverSkill\.validation\p7-trials\python-retest-app\var\team.sqlite3`
- Candidate: `28eba23b64ed788639ce52fc2de57aa41397a9a8e870731cb44c3fd73f51c6af`
- Build: `356fec482af180f1aa54fa874708f028d3bddc63247d5f6febd32ff8d8e8a251`
- Provider commit: `b8bdff26f5750a6e102356a755c35e22ebb1ea09`
- Installation manifest SHA256: `a5785bc257f4b51849b6ea75a193c883e8c270b110c8abfdab611aaacddce8a8`

Managed native plan/apply/check updated only bo_stategraph/bo_probe.py and its integration receipt; the other six native adapters, state definitions and execution engines remain unchanged. Canonical recall/scan/inspect identified the new candidate and retained the stale-review receipt. The original baseline, confirmed meaning, source moves, required fields, 2048 capacity and all deadlines were preserved. Full pre native gate passes 162/162; post-verify awaits root independent UI and explicit instruction; original 21 business/6 HTTP tests, on/off/fault, rollback, races, two negatives, original browser and cancellation 38 checks passed.

| Record | True ID | Events / frames | Actual checks | Raw SHA256 |
|---|---|---|---|---|
| controlled | 153f03ffc0764859b6a8b57365968389 | 866 / 24 | 20 passed | 3db49a49d3d1542ee3e5b6983c10ca26ca4e70c4be75b84cb8d22ae2d3adbcd1 |
| normal | 428e96904a404187a2f81003ef0e0abe | 3926 / 24 | 20 passed | 18989d5b7b1d3d1211916bb10a20d95a480c26a7974bc6f5537a563831bfe344 |

create_app(start_worker=False), explicit native Service methods; automatic worker disabled. The unchanged raw scope/docstring and some inherited check names mention automatic worker/ordinary entry. Controlled native predicates do not establish automatic driver execution.

Unchanged run.py default worker; expected outcome from independent committed SQL order before terminal-result inspection.
Normal terminal premise: rejected. Original normal premises not executed: [4]. Current-build automatic-worker rejection exercised: True. These are separate from the actual passing-check count.

The controlled and normal original recordings remain independent. Exact cardinality is 12/12/24 for controlled and 12/12/24 for normal. Check 14 retains exact controlled model/object/revision/transaction/build/run/event/frame identity.

Normal fixed-prefix stop receipt: `{"flushed": true, "target": 4010, "completed": 4010, "submitted": 4014, "pending": 4}`. Pending submissions beyond the fixed target do not mean a gap in that stopped prefix; the ordinary service continues.

Original raw recordings retained unchanged: 18. Frozen project inputs unchanged (including retained recording files): 86. New owned provider files unchanged: 464.

Actual saved preferences were compared with the root-owned pre-upgrade document: 4229 positions, 725 spatial positions, 12 annotations and the complete custom definitions. No old document was restored. Actual UI continuity remains assigned to root.

The prior 3D right-click failure and original provider recordings are preserved. The new renderer bytes match the supplied repair commit; menu/overlap behavior is not claimed as independently validated here. Root will execute the five UI groups, bilingual details and complete source read.

The first preservation helper read the commit-proof receipt instead of its referenced per-file manifest. The preparation failure and script were preserved, then the actual manifest was verified against the supplied SHA256. No application, provider or runtime test was changed or retried for that fixture correction.

Pre gate ZIP SHA256: `8185d281f395c3710cb2925d5037b9f96e96a116a1396f8c6cdeb67940c9cb1a`. Post-verify status: `pending root independent UI and explicit instruction`.

Services and actual listening PID ownership are in `live-processes.json` and `live-ownership-at-handoff.json`. The final live snapshot retained 4298 real events.

Pending: Root five UI groups including caption overlap and region menu; Root bilingual detail and complete moved-file source checks; Root actual preference continuity checks; Accept only on explicit root instruction.
