# Original twenty: fresh records and exact semantic scope

The unchanged raw scope/docstring and some inherited check names mention automatic worker/ordinary entry. Controlled native predicates do not establish automatic driver execution.

| ID | Original check | Controlled | Normal actual / original premise |
|---|---|---|---|
| original-01 | real preferences response succeeds | Native predicate passed | passed / passed |
| original-02 | native early authentication and CSRF returns | Native predicate passed | passed / passed |
| original-03 | recipient reshare actually denied | Native predicate passed | passed / passed |
| original-04 | first attempt is genuinely queued before revocation | Native predicate passed | passed / unexercised |
| original-05 | automatic worker rejects revoked queued attempt | Native predicate passed | passed / passed |
| original-06 | fresh admitted result bytes 1 | Native predicate passed | passed / passed |
| original-07 | fresh admitted result bytes 2 | Native predicate passed | passed / passed |
| original-08 | re-sharing did not revive the old request | Native predicate passed | passed / passed |
| original-09 | recording actually stopped without gaps | Native predicate passed | passed / passed |
| original-10 | fixed producer prefix drained | Native predicate passed | passed / passed |
| original-11 | each recorded producer prefix is continuous | Native predicate passed | passed / passed |
| original-12 | every real transition in all four models has an exact frame | Native predicate passed | passed / passed |
| original-13 | every initial and same-version read retains exact native context | Native predicate passed | passed / passed |
| original-14 | changed denied input does not rewrite queued context | Native predicate passed | passed / passed |
| original-15 | all recorded invocation lifecycles close | Native predicate passed | passed / passed |
| original-16 | real HTTP rejections retain API return events | Native predicate passed | passed / passed |
| original-17 | safe per-producer diagnostics and retry counts retained | Native predicate passed | passed / passed |
| original-18 | capture has no errors drops or frame evictions | Native predicate passed | passed / passed |
| original-19 | read-only inspection preserves native rows | Native predicate passed | passed / passed |
| original-20 | original recording is not supplemented after stop | Native predicate passed | passed / passed |
