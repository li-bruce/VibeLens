"""Exercise an actual trial recording through the live viewer's desktop controls."""
import argparse
import json
from pathlib import Path
import traceback
from playwright.sync_api import sync_playwright

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--url', required=True)
parser.add_argument('--recording', required=True)
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
args.out.mkdir(parents=True, exist_ok=False)
report = {'valid': False, 'recording': args.recording, 'checks': [], 'page_errors': []}


def snapshot(page):
    """Sample graph and timeline in one browser turn, including the causal cursor."""
    value = page.evaluate('''() => ({trace: graphDebug.timeline,
      position: document.querySelector('#replay-position').dataset.eventId,
      timeline: document.querySelector('#recording-timeline').dataset.eventId,
      graphRaw: graphDebug.view.replay.index,
      transfers: JSON.parse(document.querySelector('#recording-timeline').dataset.graphTransfers)
    })''')
    trace = value['trace']
    assert value['position'] == value['timeline'] == trace['eventId']
    assert value['graphRaw'] == trace['raw']
    assert value['transfers'] == trace['transfers']
    return trace


try:
    with sync_playwright() as driver:
        browser = driver.chromium.launch(
            executable_path='C:/Program Files/Google/Chrome/Application/chrome.exe',
            headless=True, args=['--enable-unsafe-swiftshader'])
        page = browser.new_page(viewport={'width': 1600, 'height': 1050})
        page.on('pageerror', lambda error: report['page_errors'].append(str(error)))
        page.goto(args.url, wait_until='domcontentloaded')
        page.wait_for_function('''id => [...document.querySelector('#record-list').options]
            .some(option => option.value === id)''', arg=args.recording, timeout=60000)
        page.select_option('#record-list', args.recording)
        page.wait_for_function('id => graphDebug.view?.replay?.id === id',
                               arg=args.recording, timeout=60000)
        if not page.locator('#recording-timeline').is_visible():
            page.click('#replay-timeline')
        page.select_option('#replay-grain', 'events')
        page.select_option('.trace-scope', 'all')
        page.select_option('.trace-depth', 'all')
        if page.locator('.trace-single').get_attribute('aria-pressed') == 'true':
            page.click('.trace-single')
        page.wait_for_function('graphDebug.timeline?.geometry', timeout=60000)
        # Clear prior per-group folds through the same global controls users use.
        page.click('.trace-tracks')
        if all(row['folded'] for row in snapshot(page)['rows']):
            page.click('.trace-tracks')
        if page.locator('.trace-clear').is_enabled():
            page.click('.trace-clear')
        initial = snapshot(page)
        report['initial'] = initial
        assert initial['lifecycles'], 'Actual recording has no node lifecycles'
        assert initial['clock'] == 'time', 'Native source clocks lost their time axis'
        def positive_duration(row):
            return isinstance(row.get('duration'), (int, float)) and row['duration'] > 0
        assert any(positive_duration(row) for row in initial['lifecycles']), \
            'Actual recording has no measured lifecycle durations'
        business_nodes = {node for row in initial['rows'] if row['layer'] == 'business'
                          for node in row['members']}
        business_lifetimes = [row for row in initial['lifecycles']
                              if row['node'] in business_nodes and positive_duration(row)]
        assert business_lifetimes, 'Business activations have no actual duration'
        report['business_lifetimes'] = business_lifetimes
        pairs = [(row['group'], row['layer']) for row in initial['rows']]
        assert len(pairs) == len(set(pairs)), 'Rows split nodes instead of execution/layer'
        report['checks'].append('Actual lifetimes and one row per execution/layer')

        page.click('.trace-tracks')
        folded = snapshot(page)
        assert folded['rows'] and all(row['folded'] for row in folded['rows'])
        assert all(row['layer'] == 'business' for row in folded['rows'])
        assert len(folded['rows']) == len({row['group'] for row in initial['rows']})
        page.screenshot(path=str(args.out / 'timeline-folded.png'))
        page.click('.trace-tracks')
        unfolded = snapshot(page)
        assert [(row['group'], row['layer']) for row in unfolded['rows']] == pairs
        report['checks'].append('Execution bands collapse to their business row and restore all layers')

        canvas = page.locator('#recording-timeline canvas')
        bounds = canvas.bounding_box()
        page.mouse.move(bounds['x']+100, bounds['y']+100)
        page.mouse.wheel(0, -100000)
        page.wait_for_function('graphDebug.timeline.scroll === 0')
        expanded = snapshot(page)
        first_group = expanded['rows'][0]['group']
        header_y = bounds['y']+expanded['geometry']['top']+14
        page.mouse.click(bounds['x']+12, header_y)
        one_folded = snapshot(page)
        band = [row for row in one_folded['rows'] if row['group']==first_group]
        assert len(band)==1 and band[0]['folded'] and band[0]['layer']=='business'
        assert all(not row['folded'] for row in one_folded['rows'] if row['group']!=first_group)
        page.mouse.click(bounds['x']+12, header_y)
        assert [(row['group'],row['layer']) for row in snapshot(page)['rows']] == pairs
        report['checks'].append('A single execution band folds without folding other executions')

        routes = snapshot(page)['routes']
        assert routes, 'No actual causal connectors rendered in the visible timeline'
        assert all(len(route['route']) >= 2 for route in routes)
        report['visible_routes'] = routes
        report['checks'].append('Actual causal connector geometry is present; route types retained in the report')
        page.screenshot(path=str(args.out/'timeline-causal-links.png'))

        options = page.locator('#replay-events option').evaluate_all(
            'nodes => nodes.map(node => Number(node.value)).filter(Number.isFinite)')
        assert len(options) > 1
        raw = options[len(options)//2]
        for mode in ('2D', '3D'):
            if page.locator('#layered-toggle').inner_text() != mode:
                page.click('#layered-toggle')
            page.select_option('#replay-events', str(raw))
            page.wait_for_function('''() => !graphDebug.layoutBusy && !graphDebug.geometryBusy''')
            current = snapshot(page)
            assert current['raw'] == raw
            page.screenshot(path=str(args.out / f'timeline-{mode}.png'))
        report['checks'].append('2D and 3D share replay cursor and transfer identities')

        page.click('.trace-fit')
        width = snapshot(page)['window']
        for _ in range(4):
            page.click('.trace-zoom-in')
        page.wait_for_function('!graphDebug.timeline.zooming')
        zoomed = snapshot(page)
        assert zoomed['window']['end']-zoomed['window']['start'] < width['end']-width['start']
        canvas = page.locator('#recording-timeline canvas')
        bounds = canvas.bounding_box()
        x = bounds['x'] + zoomed['geometry']['left'] + zoomed['geometry']['plot']*.5
        page.mouse.move(x, bounds['y']+12)
        page.mouse.down()
        page.mouse.move(x+80, bounds['y']+12, steps=12)
        page.mouse.up()
        page.wait_for_function('(start) => graphDebug.timeline.window.start !== start',
                               arg=zoomed['window']['start'])
        snapshot(page)
        report['checks'].append('Timeline zoom and pointer pan update the visible time window')

        page.click('.trace-fit')
        trace = snapshot(page)
        bounds = canvas.bounding_box()
        start = bounds['x'] + trace['geometry']['left']
        plot = trace['geometry']['plot']
        page.keyboard.down('Shift')
        page.mouse.move(start+plot*.2, bounds['y']+38)
        page.mouse.down()
        page.mouse.move(start+plot*.65, bounds['y']+38, steps=14)
        page.mouse.up()
        page.keyboard.up('Shift')
        selected_before = snapshot(page)
        assert selected_before['range']
        lower, upper = sorted(selected_before['range'])
        expected_selection = sorted(point['raw'] for point in selected_before['points']
                                    if lower <= point['time'] <= upper)
        page.click('.trace-loop')
        assert page.locator('#replay-loop').is_checked()
        selected_after = snapshot(page)
        actual_selection = sorted(point['raw'] for point in selected_after['points'])
        if expected_selection:
            assert actual_selection == expected_selection, \
                'Time selection included unrelated deliveries or omitted selected events'
        else:
            assert len(actual_selection) == 1, 'Empty time range must choose one nearest event'
        report['time_selection'] = {'expected_event_count': len(expected_selection),
                                    'actual_event_count': len(actual_selection),
                                    'exact_membership_checked': bool(expected_selection)}
        page.click('.trace-clear')
        assert not page.locator('#replay-loop').is_checked()
        report['checks'].append('Pointer-selected interval loops its exact events despite interleaved delivery')

        page.select_option('.trace-depth', 'state')
        through = snapshot(page)
        assert all(row['layer'] in ('business', 'state') for row in through['rows'])
        page.click('.trace-single')
        single = snapshot(page)
        assert single['rows'] and all(row['layer']=='state' for row in single['rows'])
        page.click('.trace-single')
        page.select_option('.trace-depth', 'all')
        report['checks'].append('Depth hides lower rows; single-layer mode keeps the selected layer')

        page.select_option('#replay-events', str(options[0]))
        page.select_option('#replay-speed', '300')
        page.click('#replay-play')
        page.wait_for_function('(raw) => graphDebug.timeline.raw !== raw', arg=options[0])
        snapshot(page)
        page.click('#replay-play')
        held = snapshot(page)['raw']
        page.wait_for_timeout(700)
        assert snapshot(page)['raw']==held
        report['checks'].append('Playback advances; pause retains the same graph/timeline step')
        report['final'] = snapshot(page)
        page.screenshot(path=str(args.out / 'timeline-final.png'))
        assert not report['page_errors']
        browser.close()
    report['valid'] = True
except Exception as error:
    report['failure'] = str(error)
    report['traceback'] = traceback.format_exc()
(args.out/'result.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
print(json.dumps({key:value for key,value in report.items() if key not in ('initial','final')}))
raise SystemExit(not report['valid'])
