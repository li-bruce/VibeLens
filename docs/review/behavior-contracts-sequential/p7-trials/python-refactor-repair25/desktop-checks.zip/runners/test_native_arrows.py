"""Inspect moving transfer arrows from an actual stopped native recording."""

import argparse
import json
from pathlib import Path
import traceback

from playwright.sync_api import sync_playwright

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--url', required=True)
parser.add_argument('--recording', required=True)
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
args.out.mkdir(parents=True, exist_ok=False)
report = {'valid': False, 'recording': args.recording, 'modes': [], 'errors': []}
browser = None

try:
    with sync_playwright() as driver:
        browser = driver.chromium.launch(
            executable_path='C:/Program Files/Google/Chrome/Application/chrome.exe',
            headless=True, args=['--enable-unsafe-swiftshader'])
        page = browser.new_page(viewport={'width':1600, 'height':1050})
        page.on('pageerror', lambda error: report['errors'].append(str(error)))
        page.goto(args.url, wait_until='domcontentloaded')
        page.wait_for_function('''id => [...document.querySelector('#record-list').options]
            .some(option => option.value === id)''', arg=args.recording, timeout=60000)
        page.select_option('#record-list', args.recording)
        page.wait_for_function('id => graphDebug.view?.replay?.id === id',
                               arg=args.recording, timeout=60000)
        page.select_option('#replay-grain', 'events')
        page.select_option('#analysis-view', 'states')
        page.wait_for_function('''() => graphDebug.graph && !graphDebug.sourceBusy &&
            !graphDebug.layoutBusy && !graphDebug.geometryBusy''', timeout=60000)
        # State declarations now share their actual model's display group.
        # Open that first level through the toolbar so an internal transition
        # has visible endpoints; a folded model must not invent an external edge.
        page.click('#collapse')
        page.click('#expand')
        page.click('#fit')
        page.wait_for_function('''() => !graphDebug.layoutBusy &&
            !graphDebug.geometryBusy''', timeout=60000)
        # Select a committed transition from its original recorded frame. This
        # reads the real endpoint and uses the viewer's own sequence ordering.
        selected = page.evaluate('''async id => {
            const recording = await (await fetch('/api/recordings/'+id)).json();
            const {timeline} = await import('/recording.js');
            const items = timeline(recording);
            const framed = new Set(recording.runtime_frames.frames.map(f=>f.event_id));
            const index = items.findIndex(e => framed.has(e.id) && e.outputs?.revision > 0);
            return {index, event: items[index]};
        }''', args.recording)
        assert selected['index'] > 0, 'No native committed transition with a recorded frame'
        report['selected'] = selected
        for mode in ('2D', '3D'):
            if page.locator('#layered-toggle').inner_text() != mode:
                page.click('#layered-toggle')
            page.wait_for_function('!graphDebug.layoutBusy && !graphDebug.geometryBusy')
            page.select_option('#replay-events', str(selected['index']))
            page.wait_for_function('graphDebug.transferPoints.length > 0', timeout=20000)
            first = page.evaluate('({points:graphDebug.transferPoints, raw:graphDebug.view.replay.index})')
            page.wait_for_function('''first => graphDebug.transferPoints.some(p => {
                const old = first.find(q=>q.id===p.id);
                return old && Math.hypot(old.x-p.x,old.y-p.y) > 1;
            })''', arg=first['points'], timeout=10000)
            second = page.evaluate('({points:graphDebug.transferPoints, raw:graphDebug.view.replay.index})')
            assert first['raw'] == second['raw'] == selected['index']
            report['modes'].append({'mode':mode, 'first':first, 'second':second})
            page.screenshot(path=str(args.out/f'arrows-{mode}.png'))
        assert sorted(p['id'] for p in report['modes'][0]['first']['points']) == sorted(
            p['id'] for p in report['modes'][1]['first']['points'])
        assert not report['errors']
        browser.close()
        report['valid'] = True
except Exception as error:
    report.update(failure=str(error), traceback=traceback.format_exc())
(args.out/'result.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'valid':report['valid'], 'failure':report.get('failure')}))
raise SystemExit(not report['valid'])
