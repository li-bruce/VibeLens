"""Run desktop controls sequentially against one completed native recording.

Each child uses the actual service and retains its own result. This runner neither
starts a producer nor supplies a response fixture. Failures stop the sequence.
"""

import argparse
import json
from pathlib import Path
import subprocess
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--url', required=True)
parser.add_argument('--recording', required=True)
parser.add_argument('--database', type=Path, required=True)
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
root = Path.cwd()
output = args.out.resolve()
output.mkdir(parents=True, exist_ok=False)
commands = [
    ('readiness', '.validation/test_native_readiness.py', []),
    ('layers', 'tools/test_trial_views_browser.py',
     ['--browser', 'C:/Program Files/Google/Chrome/Application/chrome.exe']),
    ('timeline', '.validation/test_native_timeline.py', ['--recording', args.recording]),
    ('arrows', '.validation/test_native_arrows.py', ['--recording', args.recording]),
    ('controls', '.validation/test_native_controls.py', ['--database', str(args.database.resolve())]),
]
results = []
for name, script, options in commands:
    command = [sys.executable, '-B', '-X', 'utf8', str(root / script),
               '--url', args.url, '--out', str(output / name), *options]
    with (output / (name + '.stdout.log')).open('x', encoding='utf-8') as stdout, \
         (output / (name + '.stderr.log')).open('x', encoding='utf-8') as stderr:
        process = subprocess.run(command, cwd=root, stdout=stdout, stderr=stderr)
    results.append({'name': name, 'command': command, 'exit_code': process.returncode})
    (output / 'sequence.json').write_text(json.dumps({
        'valid': len(results) == len(commands) and all(item['exit_code'] == 0 for item in results),
        'recording': args.recording, 'checks': results,
        'scope': 'Real desktop viewer controls; native business and capture acceptance are separate',
    }, indent=2) + '\n', encoding='utf-8')
    print(name, process.returncode, flush=True)
    if process.returncode:
        raise SystemExit(process.returncode)
