"""Freeze a trial's declared identities and personal view before an iteration.

This is a reviewer snapshot, not an acceptance receipt. It reads configured
project-owned sources only; dependencies and generated archives are not scanned.
"""

import argparse
import hashlib
import json
from pathlib import Path


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def checksum(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--project", type=Path, required=True)
parser.add_argument("--out", type=Path, required=True)
args = parser.parse_args()
root = args.project.resolve()
out = args.out.resolve()
out.mkdir(parents=True, exist_ok=False)
project = read(root / "bo_stategraph/project.json")
model = project["model"]
sources = {}
for relative in model["source_files"]:
    path = (root / relative).resolve()
    if not path.is_relative_to(root):
        raise ValueError("Configured source escapes the project: " + relative)
    sources[relative] = checksum(path) if path.is_file() else None

declarations = {
    name: read(root / name)
    for name in ("discovery.json", "behavior.json", "intent.json", "acceptance.json")
    if (root / name).is_file()
}
preferences = root / "bo_stategraph/config/views/local.json"
snapshot = {
    "schema": "vibelens-trial-review-snapshot/v1",
    "purpose": "Independent comparison; no acceptance claim",
    "project": str(root),
    "project_sha256": checksum(root / "bo_stategraph/project.json"),
    "selection": project["selection"],
    "source_hashes": sources,
    "nodes": [
        {key: node[key] for key in (
            "id", "kind", "layer", "source", "declaration_id", "semantic_roles"
        ) if key in node}
        for node in model["nodes"]
    ],
    "edges": model["edges"],
    "concepts": model.get("concepts", {}),
    "machines": model.get("machines", {}),
    "policy": model.get("policy", {}),
    "declarations": declarations,
    "preferences": read(preferences) if preferences.is_file() else None,
}
destination = out / "scope.json"
destination.write_text(json.dumps(snapshot, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
receipt = {
    "file": "scope.json", "sha256": checksum(destination),
    "source_files": len(sources), "missing_source_files": [key for key, value in sources.items() if value is None],
    "nodes": len(snapshot["nodes"]), "edges": len(snapshot["edges"]),
    "preferences_present": snapshot["preferences"] is not None,
}
(out / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(json.dumps(receipt))
