/* Refresh only the download queue when its authoritative states change. */
const jobList = document.getElementById("job-list");
if (jobList && /:(queued|preparing);/.test(jobList.dataset.states)) {
  const refreshJobs = async () => {
    try {
      const response = await fetch("/api/jobs", { headers: { Accept: "application/json" } });
      if (!response.ok || response.redirected) return;
      const jobs = await response.json();
      const states = jobs.map(job => `${job.id}:${job.state};`).join("");
      if (states !== jobList.dataset.states) window.location.reload();
    } catch (_) {
      // The existing page remains available during a connection interruption.
    }
  };
  window.setInterval(refreshJobs, 2000);
}
