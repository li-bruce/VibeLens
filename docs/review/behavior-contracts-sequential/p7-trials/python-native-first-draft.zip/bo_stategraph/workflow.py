"""Project-native transactional adapter for declaration-driven state changes."""

import json
from pathlib import Path

from .bo_executor import BOExecutors


def allowed_guard(context: dict, payload: dict) -> bool:
    """Read the native permission result acquired by the enclosing transaction.

    Args:
        context: Typed context containing the actual allowed decision.
        payload: Typed event payload, empty for the current object transitions.
    """
    return context["allowed"]


class Workflow:
    """Execute the registered definitions and their declared local effects."""

    def __init__(self, root: Path):
        """Load all four machines and their project-owned transition effects.

        Args:
            root: Application source root containing the canonical declarations.
        """
        self.definition = json.loads((Path(root) / "bo_stategraph/machines.json").read_text(encoding="utf-8"))
        charts = self.definition["machines"]
        self.executors = BOExecutors(charts, {mid: {g: allowed_guard for g in m["guards"]} for mid, m in charts.items()})

    def step(self, model_id: str, instance, event: str, allowed: bool) -> dict:
        """Apply one declaration transition and its registered effect inside the caller's transaction.

        Args:
            model_id: Independent state model identity.
            instance: Actual ORM object; its state and revision are changed in place.
            event: Declared native event name.
            allowed: Permission decision read within the same transaction.
        """
        before = instance.state
        result = self.executors.step(model_id, before, event, {"allowed": allowed})
        key = model_id + ":" + before + ":" + event
        for effect in self.definition["transition_effects"].get(key, []):
            if effect != "record_admission":
                raise ValueError("Unsupported project transition effect: " + effect)
            instance.admitted = True
        instance.state = result["state"]
        instance.revision += 1
        return {"before": before, "after": instance.state, "event": event, "guards": result["guards"], "revision": instance.revision}

