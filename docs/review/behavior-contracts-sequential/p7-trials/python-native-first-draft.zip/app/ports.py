"""Failure-isolated observation port; domain behavior has no external observer imports."""

from contextlib import contextmanager


class NullObservation:
    """Keep native operations available when monitoring is disabled or absent."""

    @contextmanager
    def bo_call(self, node: str, values: dict):
        """Yield an isolated completion dictionary for selected observations.

        Args:
            node: Stable mapped operation identity.
            values: Explicitly selected non-secret input values.
        """
        yield {}

    def bo_transition(self, value: dict):
        """Accept an actual committed transition without changing application state.

        Args:
            value: Native journal values supplied after commit.
        """

