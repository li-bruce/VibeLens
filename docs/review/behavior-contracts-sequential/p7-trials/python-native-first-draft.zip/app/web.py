"""Flask routes for authenticated file sharing, queued downloads, and an independent board."""

from functools import wraps
from pathlib import Path
import secrets

from flask import Flask, abort, flash, g, jsonify, redirect, render_template, request, send_file, session, url_for

from .service import PermissionDenied, Service


MESSAGES = {
    "login_required": "请先登录。", "invalid_credentials": "用户名或密码不正确。",
    "file_unavailable": "文件不存在或共享已撤销。", "uploader_only": "只有上传者能分享和撤销共享。",
    "recipient_is_uploader": "请选一位其他同事。", "filename_required": "请选择要上传的文件。",
    "result_unavailable": "这次结果尚不可领取，或不属于当前账号。",
    "announcement_editor_only": "只有公告编辑员可以发布公告。",
    "own_announcement_only": "只能修改或删除自己的公告。", "announcement_text_required": "请填写公告标题和正文。",
    "job_not_admitted": "任务尚未开始准备。",
}


def create_app(root: Path, directory: Path | None = None, start_worker: bool = True, observation=None) -> Flask:
    """Create the native application without requiring an observer service.

    Args:
        root: Application source root containing templates and declarations.
        directory: Optional private runtime directory; defaults to root/var.
        start_worker: Whether to run the actual preparation worker.
        observation: Optional neutral observation port injected by the launcher.
    """
    root = Path(root)
    data = Path(directory) if directory else root / "var"
    data.mkdir(parents=True, exist_ok=True)
    secret_path = data / ".session-key"
    if not secret_path.exists():
        try:
            with secret_path.open("x", encoding="ascii") as target:
                target.write(secrets.token_hex(32))
        except FileExistsError:
            pass
    app = Flask(__name__, template_folder=str(root / "templates"), static_folder=str(root / "static"))
    app.secret_key = secret_path.read_text(encoding="ascii")
    app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax", SESSION_COOKIE_NAME="team_files_session")
    service = Service(root, data, observation)
    app.extensions["service"] = service

    @app.before_request
    def request_identity():
        """Read native session identity and require a CSRF token on every mutation."""
        g.actor_id = session.get("actor_id", "")
        session.setdefault("csrf", secrets.token_urlsafe(24))
        if request.method == "POST" and not secrets.compare_digest(request.form.get("csrf", ""), session["csrf"]):
            abort(400, description="invalid_csrf")

    @app.after_request
    def response_headers(response):
        """Keep colleague pages private and prohibit active content from uploaded files.

        Args:
            response: Actual Flask response being returned to this request.
        """
        response.headers["Cache-Control"] = "no-store"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Content-Security-Policy"] = "default-src 'self'; style-src 'self'; script-src 'self'; base-uri 'self'; frame-ancestors 'none'"
        return response

    def authenticated(handler):
        """Require an authenticated request before invoking a concrete handler.

        Args:
            handler: Registered business HTTP handler.
        """
        @wraps(handler)
        def checked(*args, **kwargs):
            """Forward this request only when its native login identity exists."""
            if not g.actor_id:
                return redirect(url_for("login"))
            return handler(*args, **kwargs)
        return checked

    @app.errorhandler(PermissionDenied)
    def denied(error):
        """Return an actual permission rejection without disclosing inaccessible file data.

        Args:
            error: Native PermissionDenied instance with a stable code.
        """
        return render_template("error.html", message=MESSAGES.get(str(error), "没有执行此操作的权限。"), actor_id=g.actor_id), 403

    @app.errorhandler(ValueError)
    def invalid(error):
        """Present a user input error while preserving its rejection status.

        Args:
            error: Native input validation exception.
        """
        return render_template("error.html", message=MESSAGES.get(str(error), "输入有误，请检查后重试。"), actor_id=g.actor_id), 400

    @app.route("/login", methods=["GET", "POST"])
    def login():
        """Show login or authenticate a username and password into the native session."""
        error = ""
        if request.method == "POST":
            try:
                user = service.sign_in(request.form.get("username", ""), request.form.get("password", ""))
                session.clear()
                session.update(actor_id=user["id"], csrf=secrets.token_urlsafe(24))
                return redirect(url_for("home"), code=303)
            except PermissionDenied as failure:
                error = MESSAGES[str(failure)]
        return render_template("login.html", error=error), 401 if error else 200

    @app.post("/logout")
    def logout():
        """End the actual authenticated session."""
        session.clear()
        return redirect(url_for("login"), code=303)

    @app.get("/")
    @authenticated
    def home():
        """Render the selected files, download jobs, or announcement board for this colleague."""
        tab = request.args.get("tab", "files")
        if tab not in ("files", "downloads", "board"):
            abort(404)
        data = service.list_files(g.actor_id)
        jobs = service.list_jobs(g.actor_id) if tab == "downloads" else []
        notices = service.list_announcements(g.actor_id) if tab == "board" else []
        edit = next((item for item in notices if item["id"] == request.args.get("edit")), None)
        if edit and edit["author_id"] != g.actor_id:
            raise PermissionDenied("own_announcement_only")
        return render_template("home.html", tab=tab, jobs=jobs, notices=notices, edit=edit, **data)

    @app.post("/files")
    @authenticated
    def upload():
        """Store the uploaded file for the authenticated uploader."""
        uploaded = request.files.get("file")
        if uploaded is None:
            raise ValueError("filename_required")
        service.upload_file(g.actor_id, uploaded.filename or "", uploaded.stream)
        flash("文件已上传，当前仅你可见。")
        return redirect(url_for("home"), code=303)

    @app.post("/files/<file_id>/share")
    @authenticated
    def share(file_id: str):
        """Create or revoke one recipient's grant after checking the original uploader.

        Args:
            file_id: Original file identity from the concrete route.
        """
        revoke = request.form.get("action") == "revoke"
        service.manage_share(g.actor_id, file_id, request.form.get("recipient_id", ""), revoke)
        flash("共享已撤销。已开始准备的任务仍可完成并领取。" if revoke else "已分享给选定同事。")
        return redirect(url_for("home"), code=303)

    @app.post("/files/<file_id>/downloads")
    @authenticated
    def enqueue(file_id: str):
        """Create one independent queued download attempt.

        Args:
            file_id: Original file requested by the authenticated colleague.
        """
        service.request_download(g.actor_id, file_id)
        flash("已加入准备队列，完成后可在这里领取。")
        return redirect(url_for("home", tab="downloads"), code=303)

    @app.get("/downloads/<job_id>/result")
    @authenticated
    def collect(job_id: str):
        """Send a prepared ZIP only to this admitted job's authenticated requester.

        Args:
            job_id: Download attempt identity from the concrete route.
        """
        path, name = service.collect_result(g.actor_id, job_id)
        return send_file(path, as_attachment=True, download_name=name, mimetype="application/zip")

    @app.post("/announcements")
    @authenticated
    def announcement():
        """Publish, edit, or delete the current editor's own announcement."""
        delete = request.form.get("action") == "delete"
        service.save_announcement(g.actor_id, request.form.get("title", ""), request.form.get("body", ""), request.form.get("announcement_id", ""), delete)
        flash("公告已删除。" if delete else "公告已保存。")
        return redirect(url_for("home", tab="board"), code=303)

    @app.get("/api/jobs")
    @authenticated
    def job_status():
        """Return the authenticated requester's current job states for page refresh."""
        return jsonify(service.list_jobs(g.actor_id))

    @app.get("/health")
    def health():
        """Expose native service readiness without listing business data."""
        return jsonify(status="ok", worker=bool(service.worker and service.worker.is_alive()))

    if start_worker:
        service.start_worker()
    return app
