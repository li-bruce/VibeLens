
import { Store } from 'file:///C:/Users/Lvi_P/Documents/Work/CF/%E5%B9%B3%E5%8F%B0%E8%BD%AF%E8%91%97/SoftwareStatusObserverSkill/.validation/p7-trials/node-retest-app/src/store.mjs';
import readline from 'node:readline';
const store=new Store(process.argv[2]);
console.log(JSON.stringify({stage:'writer_ready',pid:process.pid}));
const input=readline.createInterface({input:process.stdin});
input.on('line',line=>{
  const command=JSON.parse(line);
  if(command.op==='close'){store.close();input.close();return;}
  try{
    if(command.op==='publish_schema'){
      if(!/^[a-z0-9_]+$/.test(command.table))throw new Error('Invalid fixture table');
      store.transaction(()=>store.run('CREATE TABLE "'+command.table+'" (id INTEGER PRIMARY KEY, payload TEXT NOT NULL)'));
    }else store.persist();
    console.log(JSON.stringify({stage:'publication',ok:true,pid:process.pid,method:'Unmodified Store.persist',operation:command.op}));
  }catch(error){console.log(JSON.stringify({stage:'publication',ok:false,pid:process.pid,code:error.code,syscall:error.syscall,stack:error.stack}));}
});
