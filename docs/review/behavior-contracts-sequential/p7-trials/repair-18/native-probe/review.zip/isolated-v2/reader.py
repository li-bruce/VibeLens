
import ctypes,hashlib,json,os,sys
from ctypes import wintypes as w
from pathlib import Path
pack,app,filename,phase=sys.argv[1:]
sys.path.insert(0,str(Path(pack)/'scripts'))
from bo_observer.data import catalog,sqlite_snapshot as snapshot
store=json.loads((Path(app)/'bo_stategraph/databases.json').read_text(encoding='utf-8-sig'))['stores'][0]
store['sqlite_file_mode']='atomic_replace'
os.environ[store['url_env']]='sqlite:///'+Path(filename).as_posix()
held=False
streams=[]
aliases=[]
images=[]
def actual_handle_path(stream):
    import msvcrt
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    method=kernel.GetFinalPathNameByHandleW
    method.argtypes=[w.HANDLE,w.LPWSTR,w.DWORD,w.DWORD];method.restype=w.DWORD
    buffer=ctypes.create_unicode_buffer(32768)
    count=method(msvcrt.get_osfhandle(stream.fileno()),buffer,len(buffer),0)
    assert 0<count<len(buffer)
    return buffer.value
def pause(value):
    print(json.dumps(value),flush=True)
    assert sys.stdin.readline().strip()=='release'
original_open=snapshot._open_windows_link
def open_with_barrier(path):
    global held
    stream=original_open(path)
    streams.append(stream);aliases.append(str(path))
    if phase=='snapshot_handle' and not held:
        held=True
        pause({'stage':'barrier','phase':phase,'pid':os.getpid(),'stream_closed':stream.closed,
               'actual_windows_handle_path':actual_handle_path(stream),'alias_path':str(path),
               'alias_differs_from_published_path':Path(path)!=Path(filename),
               'same_file_before_replacement':(os.fstat(stream.fileno()).st_dev,os.fstat(stream.fileno()).st_ino)==(os.stat(filename).st_dev,os.stat(filename).st_ino),
               'file_inode_before_replacement':os.fstat(stream.fileno()).st_ino})
    return stream
snapshot._open_windows_link=open_with_barrier
original_image=snapshot.read_image
def read_image(path):
    image=original_image(path)
    images.append(hashlib.sha256(image).hexdigest())
    return image
snapshot.read_image=read_image
original_inspect=catalog._inspect
def inspect_with_barrier(inspector,method,*args,**kwargs):
    global held
    value=original_inspect(inspector,method,*args,**kwargs)
    if phase=='reflection' and method=='get_table_names' and not held:
        held=True
        pause({'stage':'barrier','phase':phase,'pid':os.getpid(),'tables':value,
               'database_list':[list(row) for row in inspector.bind.exec_driver_sql('PRAGMA database_list').fetchall()],
               'query_only':inspector.bind.exec_driver_sql('PRAGMA query_only').scalar(),
               'all_file_streams_closed':all(stream.closed for stream in streams),
               'snapshot_sha256':images[-1]})
    return value
catalog._inspect=inspect_with_barrier
def collect(stage):
    value=catalog.collect(store,root=Path(app))
    print(json.dumps({'stage':stage,'pid':os.getpid(),'sqlite_file_mode':store['sqlite_file_mode'],
        'canonical_catalog':catalog.__file__,'canonical_snapshot':snapshot.__file__,
        'image_sha256':images[-1],'catalog':value,'all_file_streams_closed':all(stream.closed for stream in streams),
        'remaining_aliases':[name for name in aliases if Path(name).exists()]}),flush=True)
collect('first_catalog')
assert sys.stdin.readline().strip()=='next'
collect('next_catalog')
assert sys.stdin.readline().strip()=='exit'
