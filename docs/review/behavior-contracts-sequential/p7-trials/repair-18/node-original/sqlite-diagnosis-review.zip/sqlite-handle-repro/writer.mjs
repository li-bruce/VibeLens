
import { Store } from 'file:///C:/Users/Lvi_P/Documents/Work/CF/%E5%B9%B3%E5%8F%B0%E8%BD%AF%E8%91%97/SoftwareStatusObserverSkill/.validation/p7-trials/node-retest-app/src/store.mjs';
import readline from 'node:readline';
const store = new Store(process.argv[2]);
console.log(JSON.stringify({stage:'writer_ready',pid:process.pid}));
const input=readline.createInterface({input:process.stdin});
input.on('line',line=>{
  const op=JSON.parse(line).op;
  if(op==='close'){store.close();console.log(JSON.stringify({stage:'writer_closed'}));input.close();return;}
  try{store.persist();console.log(JSON.stringify({ok:true,pid:process.pid,method:'Store.persist'}));}
  catch(error){console.log(JSON.stringify({ok:false,pid:process.pid,method:'Store.persist',code:error.code,errno:error.errno,syscall:error.syscall,path:error.path,dest:error.dest,stack:error.stack}));}
});
