
import json,os,sys
from pathlib import Path
pack,app,filename=sys.argv[1:]
sys.path.insert(0,str(Path(pack)/'scripts'))
from bo_observer.data import catalog
store=json.loads((Path(app)/'bo_stategraph/databases.json').read_text(encoding='utf-8-sig'))['stores'][0]
os.environ[store['url_env']]='sqlite:///'+Path(filename).as_posix()
original=catalog._inspect
held=False
def barrier(inspector,method,*args,**kwargs):
    global held
    value=original(inspector,method,*args,**kwargs)
    if method=='get_table_names' and not held:
        held=True
        database_list=[list(row) for row in inspector.bind.exec_driver_sql('PRAGMA database_list').fetchall()]
        print(json.dumps({'stage':'actual_reflection_connection_held','pid':os.getpid(),'tables':value,'database_list':database_list,'canonical_module':catalog.__file__}),flush=True)
        assert sys.stdin.readline().strip()=='release'
    return value
catalog._inspect=barrier
result=catalog.collect(store,root=Path(app))
print(json.dumps({'stage':'canonical_collect_returned','pid':os.getpid(),'resources':len(result['resources']),'coverage':result['coverage']}),flush=True)
# Remain alive after collect/dispose so writer success cannot be attributed to process exit.
assert sys.stdin.readline().strip()=='exit'
