# Node preparation-start iteration: static handoff

Status: static implementation and declaration review complete; runtime behavior is unverified in this iteration. Stop here under the latest coordination instruction. Python owns heavy testing. The shared 3D label/right-click picking defect is being repaired centrally; await the uniformly managed installation and explicit release before native regression, actual-var migration, services, browsers or recordings. No accept was performed. No ARIS or subagents were used.

Project: `SoftwareStatusObserverSkill/.validation/p7-trials/node-retest-app`.

## Exact identities

- Current canonical static candidate: `1ebc6e635cf03e4a78cbe297d6b15cb19bd7531e7d8a22c348f04ec8b6db35c5`.
- Active change: `download-start-permission-20261121`.
- Immutable baseline identity: `a8f0eec865999f12ec6885078de42cab1a548a0d2a6d7976fc442fda0ead7e86`; baseline file SHA256 `3644ba1e96a30b16230dedd4431041b2b104ad6edc3798663ae101ba9d52c793`.
- Current ordered provider: `../ordered-evidence-skills/vibelens`; reported commit `b403866bdb6909d5d47fb23aef0ab092b2bcc15f`; installation manifest SHA256 `c799a95b5a719dfdef305a0e588723bfac86d2e500d670e231af9fa7717296fa`.
- Behavior definition: `00cfb6e6e7a726afc8a687a6b6c4610985ece9080fbecf1dca02bea9bfcd447f`.

The static candidate is tool-aware and will change after the next managed installation. Do not relabel this receipt as evidence for that future candidate. The existing manifest and native-test settings remain historical until the canonical observation/verification stage refreshes them. No new runtime build ID was invented.

## Implemented scope

The final confirmed semantic design2 is implemented in native source. Inside one synchronous native SQLite transaction, the worker reads the queued task's persisted requester, the file uploader and that requester's current sharing, then starts preparation or cancels that task. Sharing restored before this check permits the same uncancelled queued task to start. A cancelled task remains cancelled after re-sharing; a fresh authorized request creates a new task. Already preparing/ready tasks retain authenticated requester-only repeat collection. Native authorization stays in `FileService` and SQLite; VibeLens remains observe mode.

`src/store.mjs` includes the native task CHECK-constraint migration. An isolated frozen-old-database copy and a row-hash comparison test are registered, but neither that test nor migration of actual `var` has run. Actual database SHA256 is still `56c921003dbc1ecf85e3e0fd6c3cf24d50df1b75f3534b3b1ca85ee155962605`, with 3 users, 102 sessions, 29 files, 9 grants, 30 tasks and 8 announcements. Its current constraint still lacks cancelled, as expected before migration.

Five preparation-qualified read facts keep every original shared file/collection/announcement fact definition intact. Canonical confirmation is valid and ready; all initial confirmation/presentation records remain retained. The business cancellation effect maps to the actual `prepare_download` branch. The behavior contract retains four variables and every old action, adding cancellation as action11. Both changed behavior records have explicit R_DOWNLOAD requirement basis in the normal change review.

Names describe conditions: **Preparation cancelled / 准备已取消** and **Waiting for preparation / 等待准备**. The task's actual reason separately renders **已取消：共享已撤销** only for SHARING_REVOKED. Exact raw identifiers, original source names and personal/manual names remain intact. The actual before/after table is `NAMING_REVIEW.md` and `naming-before-after.json`; canonical names inventory/apply/check passed. Rendered collapsed/expanded business/state/rule names in both languages still need independent UI checks. Technical unresolved source targets retain literal names rather than invented business meanings.

## Evidence and test registration

All four original commands, original timeout180, required probes, 570 old physical node identities, every old capture field and all 230 original assertion lines are retained. One additional command registers the new controlled tests:

```text
node --test tests/queue-start.test.mjs
```

It is separate from the original business suite, so the existing native-without-observer fixture remains independent of observer files. The new controlled scenarios execute actual application operations with existing explicit worker ownership, completed native transactions and independent task/file/grant reads. They retain exact task/requester/file/run/invocation/transaction identities, revisions and native sequence. They cover denied-start cancellation, no revival, fresh request, restored-before-check, revocation after actual preparing, repeat collection and owner/other-recipient isolation in on/off/fault modes. Every controlled run retains its own directory/result/failure and raw order journal.

Canonical native observations now register start_denied and controlled_start_permissions in all three modes, in addition to every original case. Their business expectations and cancellation completion witness bind to the actual case. Native default8192, browser4096 and explicit2/4096 capacities are unchanged.

The ordinary browser flow remains scheduled as before and already waits for ready before revoking sharing. It therefore checks ready-task survival and repeat collection. Native checkpoint/order evidence supplies its expectation independently of observer arrival order or the later result. A recording without a cancellation/restoration branch is unexercised for that branch and maps to the separate controlled evidence; do not retry for a preferred schedule. The observer-disabled browser bootstrap has no native order journal and is explicitly labeled unrecorded for order, while its original business/byte assertions remain mandatory.

## Static receipts

All paths below are relative to this directory.

| Receipt | Result and limit |
|---|---|
| `static-change-inspect-reviewed-2.json` | valid, errors0, review_errors0; current canonical candidate above |
| `static-concepts-final.json` | valid and ready; no invented announcement re-confirmation |
| `static-policy-check.json`, `static-policy-fingerprint-2.json` | valid native rule binding and canonical policy identity |
| `static-source-scan.json`, `static-source-check.json` | source scan/check valid |
| `static-source-docs.json`, `static-source-api.json` | strict documentation/API checks valid |
| `static-names-check-final.json` | coverage and basis current; human-readable naming table separate; rendered UI pending |
| `static-integration-final.json` | canonical managed integration check valid; installed SDK source untouched |
| `static-syntax.json`, `static-python-syntax-final.json` | 19 JavaScript syntax checks and six final Python AST parses; no application imports/execution |
| `static-preservation.json` | old assertions/fields/nodes, actual preferences/DB, 2779 provider files, 5109 prior evidence files and 27 raw recordings preserved |
| `static-process-status-host.json` | target ports8925/8926/8935/8936 have no listeners; no command-line-matched project runtime/test process |

Read `static-corrections.json` for retained failed static attempts and their actual corrections. The initial failed provider begin, unsupported business-effect node kind, incomplete confirmation scope, behavior witness case mismatch and rejected long technical alias remain available as original receipts. Successful static checks do not certify runtime business behavior.

## Protected history and the derived diagnostic update

Initial accepted, baseline, review and verification receipts remain exact. The new baseline is unchanged. Actual personal settings remain revision168, SHA256 `d795ac126b70607604eebcdae48ba30b7149297414b4fe60176c42f5e4d87c15`; no restoration or write occurred. Original sources/declarations/design/history are sealed in `before-iteration.zip`, SHA256 `7f8ce72756e866c4df77a11c57edde59d45cf23d28e484e9ddad88f62e404043`.

One old derived file changed: the pre-begin canonical `change_sync check` on the then-active initial change called inspect and recomputed `initial-node-app/impact.json`. Its current candidate0ce12b... exactly matches `check-accepted-initial.json`; its frozen original candidatea8f0eec8... remains in the before archive. No restore was performed and this is not claimed as unchanged. The first preservation audit exposing this difference is retained in `static-preservation.first.json`; the final audit separately classifies the derived update while checking every authoritative receipt and raw file.

The current change used the explicitly authorized strict begin through the retained accepted provider only after an exact accepted-snapshot recheck. All subsequent implementation/static work uses the ordered provider. No baseline, active change or accepted identity was manually fabricated.

## Resume only after coordination release

1. Receive the centrally repaired managed installation. Use canonical managed plan/apply/check and process-local provider selection; preserve this entire handoff and do not patch installed UI/SDK code locally.
2. Refresh canonical source/declaration review against that provider, preserving the current source, all old receipts and actual settings. Use `tooling/sync_preparation_start.py` for affected incremental mappings when necessary; do not rerun the legacy initial scaffold over preserved captures. Do not begin another change or reset this baseline.
3. When heavy testing is explicitly released, run the registered complete native pipeline and all controlled branches, preserving every failure. Validate the isolated old-schema migration before actual-var migration; perform the real native migration and required canonical database metadata refresh before claiming current database acceptance.
4. Run the full original ordinary browser/recording path once with unchanged deadlines/schedule and both provider variables identical. Keep controlled/ordinary evidence and missing branches separate. Complete exact-candidate post-verify and SQL/bytes/identity/closure/order audits.
5. Start actual-var services on the same final build/provider and create nonempty real login/list history for independent root UI. Check both languages, expanded/collapsed states/events and the centrally repaired left/right picking in 2D/3D. Preserve revision168 settings as the actual baseline; do not restore older preferences. Keep accept deferred until the coordinating instruction after independent UI.

None of these five runtime/resumption steps has run in this iteration.
