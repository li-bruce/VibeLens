"""Capture actual failed resource URLs and replay/canvas geometry before editing."""
import json
from pathlib import Path
from playwright.sync_api import sync_playwright

OUTPUT = Path(__file__).parent / "before-retry"
OUTPUT.mkdir(parents=True, exist_ok=True)
results = {}
with sync_playwright() as driver:
    browser = driver.chromium.launch(channel="chrome", headless=True, args=["--enable-unsafe-swiftshader"])
    for name, url in [("app", "http://127.0.0.1:8925/"), ("viewer", "http://127.0.0.1:8926/graph?lang=zh-CN")]:
        context = browser.new_context(viewport={"width": 1600, "height": 1000})
        page = context.new_page()
        record = {"url": url, "responses": [], "console": [], "page_errors": []}
        results[name] = record
        print('Inspecting ' + url, flush=True)
        page.set_default_timeout(15000)
        session = context.new_cdp_session(page)
        session.send("Network.enable")
        session.on("Network.responseReceived", lambda event, item=record: item["responses"].append({"url": event["response"]["url"], "status": event["response"]["status"], "type": event["type"]}))
        page.on("console", lambda message, item=record: item["console"].append({"type": message.type, "text": message.text, "location": message.location}) if message.type == "error" else None)
        page.on("pageerror", lambda error, item=record: item["page_errors"].append(str(error)))
        try:
            page.goto(url, wait_until="domcontentloaded", timeout=30000)
            print(name + ': DOM loaded', flush=True)
            if name == "app":
                page.locator('#login-form').wait_for(state='visible')
            if name == "viewer":
                recording = "49e70b20dc444f2c9ecdbfafb0571169"
                page.wait_for_function("id => [...document.querySelector('#record-list').options].some(o => o.value === id)", arg=recording)
                page.select_option("#record-list", recording)
                page.wait_for_function("id => graphDebug.view?.replay?.id === id", arg=recording, timeout=60000)
                record["recording"] = recording
                record["geometry"] = page.evaluate("""() => {
                  const rect = selector => {const r = document.querySelector(selector).getBoundingClientRect(); return {x:r.x,y:r.y,width:r.width,height:r.height,bottom:r.bottom,right:r.right};};
                  const replay = rect('#replay'), viewport = rect('#viewport');
                  const overlap = Math.max(0, Math.min(replay.right,viewport.right)-Math.max(replay.x,viewport.x))*Math.max(0,Math.min(replay.bottom,viewport.bottom)-Math.max(replay.y,viewport.y));
                  return {replay,viewport,overlap,position:getComputedStyle(document.querySelector('#replay')).position};
                }""")
            page.screenshot(path=str(OUTPUT / f"{name}.png"), timeout=10000)
        except Exception as error:
            record["error"] = str(error)
        record["failed_responses"] = [r for r in record["responses"] if r["status"] >= 400]
        (OUTPUT / "diagnosis.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps({key: value for key, value in record.items() if key != 'responses'}, ensure_ascii=False), flush=True)
        context.close()
    browser.close()
(OUTPUT / "diagnosis.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps({name: {key: value for key, value in item.items() if key != "responses"} for name, item in results.items()}, ensure_ascii=False))
