"""Archive original UI receipts without copying native accounts, databases or recordings."""
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[2]
LOCAL = Path(__file__).parent
OUT = ROOT / 'docs/review/behavior-contracts-sequential/p7-trials/ui-followup-30'
hash_bytes = lambda value: hashlib.sha256(value).hexdigest()
folders = ['before-retry', 'layout-before', 'resource-before', 'fixture-first',
           'layout-after', 'trial-recording-after', 'resource-after',
           'timeline-existing', 'changes-existing']
entries = []
with zipfile.ZipFile(OUT/'evidence.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for folder in folders:
        for source in sorted((LOCAL/folder).iterdir()):
            if source.suffix not in {'.json', '.png'}:
                continue
            name = ('before' if folder == 'before-retry' else folder) + '/' + source.name
            body = source.read_bytes()
            archive.writestr(name, body)
            entries.append({'path': name, 'sha256': hash_bytes(body), 'bytes': len(body)})
    for name in ['source-check.json', 'integrity.json', 'diagnose.py', 'archive_evidence.py']:
        body = (LOCAL/name).read_bytes()
        archive.writestr(name, body)
        entries.append({'path': name, 'sha256': hash_bytes(body), 'bytes': len(body)})

(OUT/'screenshots').mkdir(exist_ok=True)
for name, source in {
    'before-viewer.png': 'before-retry/viewer.png',
    'before-application.png': 'resource-before/failure.png',
    'after-trial-3d.png': 'trial-recording-after/1600-zh-CN-3D.png',
    'after-trial-2d.png': 'trial-recording-after/1600-en-2D.png',
    'after-desktop-1280.png': 'trial-recording-after/1280-zh-CN-3D.png',
    'after-application.png': 'resource-after/application.png',
}.items():
    shutil.copyfile(LOCAL/source, OUT/'screenshots'/name)

checks = []
for folder in folders[1:]:
    result = json.loads((LOCAL/folder/'result.json').read_text(encoding='utf8'))
    checks.append({'name': folder, 'passed': result['passed'], 'groups': len(result.get('checks', [])),
                   'receipt': folder+'/result.json', 'error': result.get('error')})
integrity=json.loads((LOCAL/'integrity.json').read_text(encoding='utf8'))
result = {
    'schema': 'vibelens-development-evidence/v1', 'status': 'verified',
    'branch': 'feat/behavior-contracts-sequential', 'base_commit': 'b2503909',
    'date': '2026-11-22', 'new_chats': 0,
    'scope': 'Shared desktop replay layout, browser resource diagnostics and an application-owned missing static icon; existing native acceptance is retained.',
    'issues': [
        {'id': 'R30-01', 'status': 'verified', 'cause': 'Absolute replay positioning over the shared graph viewport', 'before_overlap_px2': 75680, 'after_overlap_px2': 0},
        {'id': 'R30-02', 'status': 'verified', 'url': 'http://127.0.0.1:8925/favicon.ico', 'before_status': 404, 'after_status': 200},
    ],
    'checks': checks, 'source_check_passed': json.loads((LOCAL/'source-check.json').read_text(encoding='utf8'))['valid'],
    'integrity': integrity,
    'archive': {'path': 'evidence.zip', 'sha256': hash_bytes((OUT/'evidence.zip').read_bytes()), 'entries': entries},
    'source_files': [{'path': str(p).replace('\\', '/'), 'sha256': hash_bytes((ROOT/p).read_bytes())} for p in map(Path, [
        'skills/vibelens/assets/stategraph-viewer/viewer.css', 'skills/vibelens/assets/stategraph-viewer/viewer.js',
        'skills/vibelens/assets/stategraph-viewer/timeline.css', 'tools/browser_resource_diagnostics.mjs',
        'tools/test_replay_workspace_browser.mjs', 'tools/test_trial_resources_browser.mjs', 'tools/recording_browser_fixture.mjs'])],
}
(OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
batch_path=ROOT/'docs/review/behavior-contracts-sequential/p7-trials/batch-status.json'
batch=json.loads(batch_path.read_text(encoding='utf8'))
batch['resolved_follow_up_findings'] = [{'original_finding': finding, 'status': 'verified', 'evidence': 'ui-followup-30/results.json'} for finding in batch['follow_up_findings']]
batch['follow_up_findings']=[]
for issue in result['issues']:
    batch['issues'].append({'id':issue['id'], 'status':'verified', 'scope':issue.get('cause', 'Native application favicon and URL-aware browser diagnostics'), 'evidence':'ui-followup-30/results.json'})
batch_path.write_text(json.dumps(batch,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
print(json.dumps({'archive_entries':len(entries),'archive_bytes':(OUT/'evidence.zip').stat().st_size,'archive_sha256':result['archive']['sha256'],'issues':[r['id'] for r in result['issues']]},indent=2))
