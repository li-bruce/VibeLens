"""Pin the reviewed per-instance lifecycles and their native value correspondence."""

from pathlib import Path
import hashlib
import json


def build_behavior(root: Path, doc: dict, graph: dict):
    """Bind native transition invocations while retaining separate permission and commit checks.

    Args:
        root: Application project root.
        doc: Confirmed discovery with four independent state models.
        graph: Source-backed native model before final AST enrichment.
    """
    from bo_observer.behavior import assess

    def literal(domain, value):
        """Create a typed constant without executable text."""
        return {"op": "literal", "domain": domain, "value": value}

    def variable(identity, phase="before"):
        """Reference the selected state at its declared boundary."""
        return {"op": "var", "id": identity, "phase": phase}

    def equal(left, right):
        """Build an exact typed comparison."""
        return {"op": "eq", "args": [left, right]}

    source_refs = ["U_RULES", "U_FINAL_STATES"]
    machines = doc["state_models"]
    states = [item["id"] + ".state" for item in machines]
    domains = [{"id": "Boolean", "type": "boolean", "source_refs": source_refs}]
    variables, initial, actions = [], [], []
    for machine in machines:
        identity, domain = machine["id"] + ".state", machine["id"] + ".states"
        domains.append({"id": domain, "type": "enum", "values": machine["states"], "source_refs": source_refs})
        variables.append({"id": identity, "domain": domain, "owner": "state-model:" + machine["id"], "concept_ref": "state-model:" + machine["id"], "persistence": "persistent", "source_refs": source_refs})
        initial.append(equal(variable(identity), literal(domain, machine["initial"])))
        for transition in machine["transitions"]:
            conditions = [equal(variable(identity), literal(domain, transition["source"]))]
            if transition.get("conditions"):
                conditions.append({"op": "param", "id": "allowed"})
            if transition.get("unless"):
                conditions.append({"op": "not", "args": [{"op": "param", "id": "allowed"}]})
            actions.append({"id": machine["id"] + ":" + transition["id"], "model_refs": ["state-model:" + machine["id"]], "transition_ref": "transition:" + machine["id"] + ":" + transition["id"], "parameters": {"allowed": "Boolean"}, "enabled": {"op": "all", "args": conditions}, "reads": [identity], "writes": [identity], "updates": {}, "unchanged": [name for name in states if name != identity], "completion": {"kind": "return", "meaning": "The native executor returned after applying the row state and its declared local effects inside the caller transaction. Business commit acknowledgement is checked separately."}, "source_refs": transition["source_refs"]})
    contract = {"schema": "bo-behavior/v1", "project_id": doc["project_id"], "revision": "initial-lifecycles-1", "scope": {"model_refs": ["state-model:" + item["id"] for item in machines], "object_refs": ["object:" + item["subject"]["object"] for item in machines], "unresolved": [], "exclusions": ["This contract describes each object instance's lifecycle. Object multiplicity, shared rule expressions, authentication, ZIP bytes, HTTP results and transaction commit retain their separate protected native checks. No finite or formal analysis is claimed."]}, "domains": domains, "variables": variables, "initial": {"op": "all", "args": initial}, "actions": actions, "properties": [{"id": "rejected-attempt-does-not-revive", "kind": "transition_constraint", "action_refs": [item["id"] for item in actions if item["id"].startswith("download-job:")], "expression": {"op": "implies", "args": [equal(variable("download-job.state"), literal("download-job.states", "rejected")), equal(variable("download-job.state", "after"), literal("download-job.states", "rejected"))]}, "source_refs": ["U_FINAL_STATES"]}]}
    definition = assess(contract, doc)
    (root / "review/behavior-definition.json").write_text(json.dumps(definition, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    if not definition["valid"]:
        raise ValueError(definition["errors"])
    contract_path = root / "bo_stategraph/behavior.json"
    contract_path.write_text(json.dumps(contract, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    inputs = {"model_id": "string", "model_ref": "string", "instance_id": "string", "event": "string", "allowed": "boolean", "context_allowed": "boolean", "transaction_id": "string", "build_id": "string"}
    graph["nodes"].append({"id": "native_transition", "kind": "function", "layer": "program", "label": "Apply native state transition", "summary": "Apply the registered native state declaration inside its existing transaction.", "source": {"path": "bo_stategraph/workflow.py", "symbol": "Workflow.step"}, "capture": {"in": inputs, "out": {**inputs, "state": "string", "revision": "number"}}})
    binding = {"schema": "bo-behavior-bindings/v1", "definition_sha256": definition["definition_sha256"], "variables": {}, "actions": {}, "interactions": {}}
    reader = {"path": "tooling/observe.py", "symbol": "read_native_transitions"}
    writer = {"path": "bo_stategraph/workflow.py", "symbol": "Workflow.step"}

    def site(phase, model_id, event=None):
        """Select exact physical native boundaries, retaining repeated invocation identities."""
        direction = "inputs" if phase == "enter" else "outputs"
        when = [{"path": [direction, "model_ref"], "equals": "state-model:" + model_id}]
        if event:
            when.append({"path": [direction, "event"], "equals": event})
        return {"node": "native_transition", "phase": phase, "when": when}

    def witness(model_id, field, phase, cases, event=None):
        """Bind SQL journal values to the same model, instance, transaction and build."""
        direction = "inputs" if phase == "enter" else "outputs"
        keys = [{"name": name, "actual": [actual], "observed": [direction, observed]} for name, actual, observed in (("model", "model", "model_ref"), ("instance", "instance_id", "instance_id"), ("invocation", "transaction_id", "transaction_id"), ("attempt", "transaction_id", "transaction_id"), ("build", "build_id", "build_id"))]
        return {"reader": reader, "writers": [writer], "observation": {**site(phase, model_id, event), "path": [direction, field]}, "native": {"collection": ["native_transitions", model_id, event or "all"], "value": [field], "keys": keys}, "cases": cases}

    all_cases = ["normal", "queued_revoked", "started_revoked"]
    for machine in machines:
        model_id = machine["id"]
        binding["variables"][model_id + ".state"] = witness(model_id, "state", "return", all_cases)
        for transition in machine["transitions"]:
            cases = ["queued_revoked"] if transition["trigger"] == "reject" else all_cases
            parameter = witness(model_id, "allowed", "enter", cases, transition["trigger"])
            parameter["writers"] = []
            parameter["source_parameter"] = "allowed"
            binding["actions"][model_id + ":" + transition["id"]] = {"entry": site("enter", model_id, transition["trigger"]), "completion": site("return", model_id, transition["trigger"]), "completion_witness": witness(model_id, "state", "return", cases, transition["trigger"]), "parameters": {"allowed": parameter}, "exits": [], "cases": [{"id": case, "boundaries": ["complete"]} for case in cases]}
    graph["behavior_bindings"] = binding
    graph["source_files"] = sorted(set(graph["source_files"]) | {"bo_stategraph/behavior.json"})
    return graph, {"path": "bo_stategraph/behavior.json", "sha256": hashlib.sha256(contract_path.read_bytes()).hexdigest(), "schema": "bo-behavior/v1"}
