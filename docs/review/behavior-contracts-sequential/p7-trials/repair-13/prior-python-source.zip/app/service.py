"""Team file operations and transactional preparation admission."""

from datetime import datetime, timezone
from pathlib import Path
import json
import shutil
import threading
import uuid
import zipfile

from sqlalchemy import select
from werkzeug.security import check_password_hash

from bo_stategraph.workflow import Workflow
from .models import Announcement, DownloadJob, File, Grant, Journal, User
from .ports import NullObservation
from .storage import Store
from .rules import Rules


class PermissionDenied(Exception):
    """A native permission rejection with a stable presentation code."""


FACT_READ_BASIS = {"actor_id": "current_request_or_job_start", "logged_in": "current_interactive_request", "is_editor": "current_announcement_operation", "owner_id": "current_file_operation_or_job_start", "recipient_id": "current_file_operation_or_job_start", "grant_active": "immediately_before_preparation_start_or_current_file_read", "job_requester": "current_job_request", "job_admitted": "read_at_collection_written_at_preparation_start", "announcement_author": "current_announcement_operation"}


def now() -> str:
    """Return a sortable UTC creation timestamp."""
    return datetime.now(timezone.utc).isoformat()


class Service:
    """Own business effects; the optional observer only receives completed facts."""

    def __init__(self, root: Path, directory: Path, observation=None):
        """Initialize native storage and the declaration-driven executor.

        Args:
            root: Application source root.
            directory: Private runtime directory for database and file contents.
            observation: Optional failure-isolated neutral observation port.
        """
        self.store = Store(directory)
        self.build_id = json.loads((Path(root) / "manifest.json").read_text(encoding="utf-8"))["build_id"]
        self.bo_probe = observation or NullObservation()
        self.store.bo_probe = self.bo_probe
        self.bo_probe.bo_attach_storage(self.store.engine)
        self.workflow = Workflow(root, self.bo_probe)
        self.rules = Rules(root)
        self.fact_basis = {}
        self.originals = Path(directory) / "originals"
        self.results = Path(directory) / "results"
        self.originals.mkdir(exist_ok=True)
        self.results.mkdir(exist_ok=True)
        self.stop_event = threading.Event()
        self.worker = None

    def _user(self, session, actor_id: str) -> User:
        """Require a real authenticated account identity.

        Args:
            session: Current native database session.
            actor_id: Identity supplied by the application's authenticated session.
        """
        user = session.get(User, actor_id)
        if user is None:
            raise PermissionDenied("login_required")
        return user

    def _file(self, session, file_id: str) -> File:
        """Find an existing original file without leaking its name on rejection.

        Args:
            session: Current native database session.
            file_id: File identity to resolve.
        """
        file = session.get(File, file_id)
        if file is None:
            raise PermissionDenied("file_unavailable")
        return file

    def _access(self, session, file: File, actor_id: str) -> tuple:
        """Read current file and grant facts from the enclosing native session.

        Args:
            session: Current native database session or transaction.
            file: Actual original file row.
            actor_id: Colleague whose current access is checked.
        """
        grant = session.get(Grant, (file.id, actor_id))
        allowed = self._policy(session, "view_file", actor_id, file=file, grant=grant)
        return allowed, grant

    def _policy(self, session, operation: str, actor_id: str, file=None, grant=None, job=None, announcement=None, fact_revision: str = "") -> bool:
        """Acquire explicit native facts and use the shared declaration's actual decision.

        Args:
            session: Native read session or serialized write transaction.
            operation: Registered permission operation.
            actor_id: Authenticated principal or persisted job requester.
            file: Selected original file, when applicable.
            grant: Selected recipient grant, when applicable.
            job: Selected download attempt, when applicable.
            announcement: Selected publication, when applicable.
            fact_revision: Enclosing transaction identity or a distinct read identity.
        """
        user = session.get(User, actor_id)
        facts = {"actor_id": actor_id, "logged_in": user is not None, "is_editor": bool(user and user.editor), "owner_id": file.owner_id if file else "", "recipient_id": grant.recipient_id if grant else "", "grant_active": bool(grant and grant.state == "active"), "job_requester": job.requester_id if job else "", "job_admitted": bool(job and job.admitted), "announcement_author": announcement.author_id if announcement else "", "grant_fresh": bool(not job or (file and job.requester_id == file.owner_id) or (grant and grant.revision == job.grant_revision))}
        result = self.rules.evaluate(operation, facts, fact_revision or uuid.uuid4().hex)
        for step in result["trace"]:
            name = step["node"]
            if name in FACT_READ_BASIS:
                self.fact_basis[name] = {"node": "policy:" + name, "direction": "out", "field": "value", "read_basis": {"timing": FACT_READ_BASIS[name], "scope": "selected_object_and_operation"}}
        self.bo_probe.bo_policy(result)
        return result["value"] is True

    def _change(self, session, model_id: str, instance, event: str, allowed: bool, transaction_id: str) -> dict:
        """Execute and journal a state change in the caller's atomic transaction.

        Args:
            session: Actual write transaction.
            model_id: Independent model identity.
            instance: Native ORM instance governed by that model.
            event: Declared transition event.
            allowed: Native permission result from this same transaction.
            transaction_id: Identity shared by the state and its business effects.
        """
        instance_id = instance.file_id + ":" + instance.recipient_id if model_id == "grant" else instance.id
        previous_allowed = session.scalar(select(Journal.permission_allowed).where(Journal.model_id == model_id, Journal.instance_id == instance_id, Journal.revision == instance.revision).order_by(Journal.sequence.desc()).limit(1))
        # Context describes this native version's last committed decision. An
        # initial version has no committed decision; the current input is separate.
        context = {"allowed": bool(previous_allowed)} if previous_allowed is not None else ({"allowed": False} if instance.revision == 0 else {})
        self.bo_probe.bo_before_transition({"model_id": model_id, "instance_id": instance_id, "state": instance.state, "revision": instance.revision, "allowed": allowed, "context_allowed": context.get("allowed"), "context": context, "transaction_id": transaction_id})
        value = self.workflow.step(model_id, instance, event, allowed, transaction_id, context)
        value.update(model_id=model_id, instance_id=instance_id, transaction_id=transaction_id)
        value.update(allowed=allowed, admitted=bool(getattr(instance, "admitted", False)))
        session.add(Journal(model_id=model_id, instance_id=instance_id, event=event, before=value["before"], after=value["after"], revision=value["revision"], guards=json.dumps(value["guards"]), permission_allowed=allowed, transaction_id=transaction_id, build_id=self.build_id))
        return value

    def sign_in(self, username: str, password: str) -> dict:
        """Verify credentials without observing passwords or password hashes.

        Args:
            username: Claimed account identity.
            password: Secret submitted by the colleague; never captured.
        """
        with self.bo_probe.span("sign_in", {"username": username, "password_provided": bool(password)}) as output:
            with self.store.read() as session:
                user = session.get(User, username)
                if user is None or not check_password_hash(user.password_hash, password):
                    output.update(allowed=False)
                    raise PermissionDenied("invalid_credentials")
                result = {"id": user.id, "name": user.name, "editor": user.editor}
            output.update(allowed=True, actor_id=result["id"])
            return result

    def upload_file(self, actor_id: str, filename: str, stream) -> str:
        """Save an original file owned by the authenticated uploader.

        Args:
            actor_id: Authenticated uploader.
            filename: Display name; paths are removed before storage.
            stream: Actual uploaded binary stream; only its byte count is observed.
        """
        name = filename.replace("\\", "/").split("/")[-1].strip()
        if not name or name in (".", ".."):
            raise ValueError("filename_required")
        file_id, transaction_id = uuid.uuid4().hex, uuid.uuid4().hex
        path = self.originals / file_id
        with self.bo_probe.span("upload_file", {"actor_id": actor_id, "filename": name[:256]}) as output:
            try:
                with path.open("xb") as target:
                    shutil.copyfileobj(stream, target)
                size = path.stat().st_size
                with self.store.transaction() as session:
                    self._user(session, actor_id)
                    if not self._policy(session, "upload", actor_id, fact_revision=transaction_id):
                        raise PermissionDenied("login_required")
                    file = File(id=file_id, owner_id=actor_id, name=name, size=size, state="absent", revision=0, created_at=now())
                    session.add(file)
                    change = self._change(session, "file", file, "upload", True, transaction_id)
                self.bo_probe.bo_transition(change)
            except BaseException:
                path.unlink(missing_ok=True)
                raise
            output.update(file_id=file_id, size=size, state="available", committed=True, transaction_id=transaction_id)
        return file_id

    def list_files(self, actor_id: str) -> dict:
        """List only originals visible to this colleague, with management controls for uploaders.

        Args:
            actor_id: Authenticated colleague whose visible files are returned.
        """
        with self.bo_probe.span("view_file", {"actor_id": actor_id}) as output:
            with self.store.read() as session:
                user = self._user(session, actor_id)
                users = [{"id": u.id, "name": u.name} for u in session.scalars(select(User).order_by(User.id))]
                files = []
                for file in session.scalars(select(File).order_by(File.created_at.desc())):
                    allowed, grant = self._access(session, file, actor_id)
                    if not allowed:
                        continue
                    shares = [{"recipient_id": g.recipient_id, "state": g.state} for g in session.scalars(select(Grant).where(Grant.file_id == file.id))] if file.owner_id == actor_id else []
                    files.append({"id": file.id, "name": file.name, "size": file.size, "owner_id": file.owner_id, "is_owner": file.owner_id == actor_id, "grants": shares})
                result = {"files": files, "users": users, "user": {"id": user.id, "name": user.name, "editor": user.editor}}
            output.update(count=len(files))
            return result

    def manage_share(self, actor_id: str, file_id: str, recipient_id: str, revoke: bool = False) -> None:
        """Grant or revoke one recipient; recipients and editors gain no management override.

        Args:
            actor_id: Authenticated original uploader.
            file_id: Original file to share.
            recipient_id: Selected colleague affected by this grant only.
            revoke: Select revocation instead of sharing.
        """
        node = "revoke_share" if revoke else "share_file"
        transaction_id = uuid.uuid4().hex
        with self.bo_probe.span(node, {"actor_id": actor_id, "file_id": file_id, "recipient_id": recipient_id, "revoke": revoke}) as output:
            with self.store.transaction() as session:
                self._user(session, actor_id)
                self._user(session, recipient_id)
                file = self._file(session, file_id)
                if not self._policy(session, "manage_share", actor_id, file=file, fact_revision=transaction_id):
                    raise PermissionDenied("uploader_only")
                if recipient_id == actor_id:
                    raise ValueError("recipient_is_uploader")
                grant = session.get(Grant, (file_id, recipient_id))
                if grant is None:
                    grant = Grant(file_id=file_id, recipient_id=recipient_id, state="inactive", revision=0)
                    session.add(grant)
                expected = "inactive" if revoke else "active"
                change = None
                if grant.state != expected:
                    change = self._change(session, "grant", grant, "revoke" if revoke else "share", True, transaction_id)
            if change:
                self.bo_probe.bo_transition(change)
            output.update(state=expected, committed=True, transaction_id=transaction_id)

    def request_download(self, actor_id: str, file_id: str) -> str:
        """Queue a distinct attempt while retaining its original grant generation.

        Args:
            actor_id: Authenticated uploader or currently shared recipient.
            file_id: Original file requested for preparation.
        """
        job_id, transaction_id = uuid.uuid4().hex, uuid.uuid4().hex
        with self.bo_probe.span("request_download", {"actor_id": actor_id, "file_id": file_id}) as output:
            with self.store.transaction() as session:
                self._user(session, actor_id)
                file = self._file(session, file_id)
                grant = session.get(Grant, (file.id, actor_id))
                allowed = self._policy(session, "request_download", actor_id, file=file, grant=grant, fact_revision=transaction_id)
                if not allowed:
                    raise PermissionDenied("file_unavailable")
                job = DownloadJob(id=job_id, file_id=file_id, requester_id=actor_id, grant_revision=grant.revision if grant and actor_id != file.owner_id else None, state="not_requested", revision=0, admitted=False, result_name="", error_code="", created_at=now())
                session.add(job)
                change = self._change(session, "download-job", job, "request", True, transaction_id)
            self.bo_probe.bo_transition(change)
            output.update(job_id=job_id, state="queued", committed=True, transaction_id=transaction_id)
        return job_id

    def start_preparation(self) -> dict | None:
        """Claim the oldest job and atomically persist admission or permanent rejection."""
        transaction_id = uuid.uuid4().hex
        with self.bo_probe.span("start_preparation", {}) as output:
            with self.store.transaction() as session:
                job = session.scalar(select(DownloadJob).where(DownloadJob.state == "queued").order_by(DownloadJob.sequence).limit(1))
                if job is None:
                    output.update(found=False)
                    return None
                file = self._file(session, job.file_id)
                grant = session.get(Grant, (file.id, job.requester_id))
                allowed = self._policy(session, "start_preparation", job.requester_id, file=file, grant=grant, job=job, fact_revision=transaction_id)
                event = "start" if allowed else "reject"
                if allowed:
                    self.bo_probe.bo_admission_started(transaction_id, job.id)
                change = self._change(session, "download-job", job, event, allowed, transaction_id)
                if not allowed:
                    job.error_code = "share_revoked"
                result = {"id": job.id, "file_id": file.id, "name": file.name, "state": job.state, "admitted": job.admitted, "requester_id": job.requester_id}
            self.bo_probe.bo_transition(change)
            output.update(found=True, job_id=result["id"], allowed=allowed, admitted=result["admitted"], state=result["state"], committed=True, transaction_id=transaction_id)
            return result

    def complete_preparation(self, job_id: str) -> None:
        """Build a real ZIP for an admitted attempt; later revocation is not rechecked.

        Args:
            job_id: Identity of an attempt already in the preparing state.
        """
        transaction_id = uuid.uuid4().hex
        with self.bo_probe.span("complete_preparation", {"job_id": job_id}) as output:
            with self.store.read() as session:
                job = session.scalar(select(DownloadJob).where(DownloadJob.id == job_id))
                if job is None or job.state != "preparing" or not job.admitted:
                    raise PermissionDenied("job_not_admitted")
                file = self._file(session, job.file_id)
                original_id, filename = file.id, file.name
            temporary = self.results / (job_id + ".part")
            final = self.results / (job_id + ".zip")
            try:
                with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED) as archive:
                    archive.write(self.originals / original_id, arcname=filename)
                temporary.replace(final)
                with self.store.transaction() as session:
                    job = session.scalar(select(DownloadJob).where(DownloadJob.id == job_id))
                    if job.state != "preparing" or not job.admitted:
                        raise PermissionDenied("job_not_admitted")
                    job.result_name = final.name
                    job.error_code = ""
                    change = self._change(session, "download-job", job, "complete", True, transaction_id)
                self.bo_probe.bo_transition(change)
            finally:
                temporary.unlink(missing_ok=True)
            output.update(state="ready", committed=True, transaction_id=transaction_id)

    def collect_result(self, actor_id: str, job_id: str) -> tuple:
        """Return a ready result to its requester; keep it available for repeated downloads.

        Args:
            actor_id: Authenticated requester; other colleagues cannot collect this result.
            job_id: Identity of this admitted and completed download attempt.
        """
        with self.bo_probe.span("collect_result", {"actor_id": actor_id, "job_id": job_id}) as output:
            with self.store.read() as session:
                self._user(session, actor_id)
                job = session.scalar(select(DownloadJob).where(DownloadJob.id == job_id))
                if job is None or job.state != "ready" or not self._policy(session, "collect_result", actor_id, job=job):
                    raise PermissionDenied("result_unavailable")
                file = self._file(session, job.file_id)
                path, name = self.results / job.result_name, file.name + ".zip"
            if not path.is_file():
                raise FileNotFoundError("prepared_result_missing")
            output.update(allowed=True, state="ready")
            return path, name

    def list_jobs(self, actor_id: str) -> list:
        """List this requester's attempts, including rejected jobs and preserved results.

        Args:
            actor_id: Authenticated requester whose jobs are visible.
        """
        with self.bo_probe.span("list_jobs", {"actor_id": actor_id}) as output:
            with self.store.read() as session:
                self._user(session, actor_id)
                rows = session.execute(select(DownloadJob, File).join(File).where(DownloadJob.requester_id == actor_id).order_by(DownloadJob.sequence.desc()))
                result = [{"id": j.id, "name": f.name, "state": j.state, "admitted": j.admitted, "error_code": j.error_code} for j, f in rows]
            output.update(count=len(result))
            return result

    def list_announcements(self, actor_id: str) -> list:
        """Read published announcements after login, independent from file grants.

        Args:
            actor_id: Authenticated colleague reading the board.
        """
        with self.bo_probe.span("read_announcements", {"actor_id": actor_id}) as output:
            with self.store.read() as session:
                self._user(session, actor_id)
                if not self._policy(session, "read_announcements", actor_id):
                    raise PermissionDenied("login_required")
                rows = session.scalars(select(Announcement).where(Announcement.state == "published").order_by(Announcement.created_at.desc()))
                result = [{"id": a.id, "author_id": a.author_id, "title": a.title, "body": a.body} for a in rows]
            output.update(count=len(result))
            return result

    def save_announcement(self, actor_id: str, title: str, body: str, announcement_id: str = "", delete: bool = False) -> str:
        """Publish, edit, or delete an editor's own announcement.

        Args:
            actor_id: Authenticated announcement editor.
            title: Publication title, required when publishing or editing.
            body: Publication text, required when publishing or editing.
            announcement_id: Existing publication identity; empty creates a publication.
            delete: Select deletion instead of saving text.
        """
        node = "delete_announcement" if delete else "edit_announcement" if announcement_id else "publish_announcement"
        transaction_id = uuid.uuid4().hex
        with self.bo_probe.span(node, {"actor_id": actor_id, "announcement_id": announcement_id, "title_length": len(title), "body_length": len(body), "delete": delete}) as output:
            with self.store.transaction() as session:
                user = self._user(session, actor_id)
                if announcement_id:
                    item = session.get(Announcement, announcement_id)
                    if item is None or not self._policy(session, "manage_announcement", actor_id, announcement=item, fact_revision=transaction_id):
                        raise PermissionDenied("own_announcement_only")
                else:
                    if not self._policy(session, "publish_announcement", actor_id, fact_revision=transaction_id):
                        raise PermissionDenied("announcement_editor_only")
                    item = Announcement(id=uuid.uuid4().hex, author_id=actor_id, state="unpublished", revision=0, created_at=now())
                    session.add(item)
                if not delete:
                    if not title.strip() or not body.strip():
                        raise ValueError("announcement_text_required")
                    item.title, item.body = title.strip(), body.strip()
                change = self._change(session, "announcement", item, "delete" if delete else "edit" if announcement_id else "publish", True, transaction_id)
                result_id, state = item.id, item.state
            self.bo_probe.bo_transition(change)
            output.update(announcement_id=result_id, state=state, committed=True, transaction_id=transaction_id)
            return result_id

    def run_worker(self, interval: float = 1.0):
        """Process the application-owned FIFO queue, including admitted jobs after restart.

        Args:
            interval: Queue polling interval in seconds; it does not grant permission.
        """
        while not self.stop_event.wait(interval):
            try:
                with self.store.read() as session:
                    pending = session.scalar(select(DownloadJob.id).where(DownloadJob.state == "preparing").order_by(DownloadJob.sequence).limit(1))
                    queued = session.scalar(select(DownloadJob.id).where(DownloadJob.state == "queued").limit(1))
                if pending:
                    self.complete_preparation(pending)
                    continue
                if queued is None:
                    continue
                job = self.start_preparation()
                if job and job["state"] == "preparing":
                    self.complete_preparation(job["id"])
            except Exception as error:
                # Native failure stays visible; no result or ready state is invented.
                self.worker_error = type(error).__name__

    def start_worker(self):
        """Start one process-local background preparation worker."""
        if self.worker is None:
            self.worker = threading.Thread(target=self.run_worker, daemon=True, name="download-preparation")
            self.worker.start()

    def close(self):
        """Stop the native worker before disposing application storage."""
        self.stop_event.set()
        if self.worker:
            self.worker.join(timeout=5)
        self.store.engine.dispose()
