"""Compare current reader and handle-verified prototype using unchanged source bytes."""
import ctypes
from ctypes import wintypes
import json
import msvcrt
import os
from pathlib import Path
import stat
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "skills/vibelens/scripts"))
from bo_observer.graph.source_files import SourceFiles
from bo_observer.graph.behavior_model import capture

kernel = ctypes.WinDLL("kernel32", use_last_error=True)
final_name = kernel.GetFinalPathNameByHandleW
final_name.argtypes = (wintypes.HANDLE, wintypes.LPWSTR, wintypes.DWORD, wintypes.DWORD)
final_name.restype = wintypes.DWORD

class HandleReader(SourceFiles):
    def read(self, name):
        relative = Path(name)
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError("expected contained relative path")
        try:
            with (self.root / relative).open("rb") as source:
                if not stat.S_ISREG(os.fstat(source.fileno()).st_mode):
                    return None
                buffer = ctypes.create_unicode_buffer(32768)
                length = final_name(msvcrt.get_osfhandle(source.fileno()), buffer, len(buffer), 0)
                if not length or length >= len(buffer):
                    raise ctypes.WinError(ctypes.get_last_error())
                value = buffer.value
                if value.startswith("\\\\?\\UNC\\"):
                    value = "\\\\" + value[8:]
                elif value.startswith("\\\\?\\"):
                    value = value[4:]
                if not Path(value).is_relative_to(self.root):
                    raise ValueError("path escapes project")
                return source.read()
        except OSError as error:
            print(type(error).__name__, str(error), flush=True)
            return None

project = ROOT / ".validation/p7-ingress-control-only"
model = json.loads((project / "bo_stategraph/project.json").read_text(encoding="utf-8"))["model"]
names = list(capture(project, model)["files"])
expected = SourceFiles(project).read_all(names)
result = {}
for cls in (SourceFiles, HandleReader):
    reader = cls(project)
    for parallel in (False, True):
        started = time.perf_counter()
        for _ in range(50):
            actual = reader.read_all(names) if parallel else {name:reader.read(name) for name in names}
            assert actual == expected, (cls.__name__, [name for name in names if actual[name] != expected[name]])
        result[cls.__name__ + ("-parallel" if parallel else "-serial")] = time.perf_counter() - started
output = ROOT / "docs/review/behavior-contracts-sequential/p7-trials/repair-13/source-reader-baseline.json"
output.write_text(json.dumps({"files":len(names), "iterations":50, "seconds":result},indent=2)+"\n",encoding="utf-8")
print(result)
