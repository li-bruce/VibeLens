/** Semantic layers are shared by renderers, filters and the spatial layout worker. */
import { nodeType } from "./graph-core.js";
export const layers = [
  { id: "business", label: "Business", color: 0x208b73 },
  { id: "state", label: "States", color: 0x8c57ad },
  { id: "rules", label: "Rules", color: 0xaf731c },
  { id: "api", label: "API", color: 0x986345 },
  { id: "execution", label: "Functions and values", color: 0x477b9c },
  { id: "operations", label: "Data operations", color: 0x3b839c },
  { id: "project", label: "Project structure", color: 0x997c4f },
  { id: "code", label: "Code symbols", color: 0x8172a3 },
  { id: "data", label: "Data structure", color: 0x638b98 },
];

// Earlier releases stored the default order as an ordinary preference. Recognize
// those exact defaults so an upgrade can improve them without sorting custom views.
const legacyOrder = [
  "api",
  "business",
  "state",
  "rules",
  "operations",
  "execution",
  "data",
  "project",
  "code",
];
const sameOrder = (a, b) => a.length === b.length && a.every((id, index) => id === b[index]);

/** Classify facts by their declared role, never by an AI-generated display name. */
export function layerOf(node) {
  const type = nodeType(node);
  if (["query", "transform"].includes(node.data_role || node.capture_owner_role))
    return "operations";
  if (node.code_role === "endpoint") return "api";
  if (["directory", "file"].includes(node.code_role) || node.reference_scope === "project")
    return "project";
  if (node.code_role || ["python-ast", "source-ast"].includes(node.origin)) return "code";
  if (type === "business") return "business";
  if (["state", "wait"].includes(type)) return "state";
  if (["decision", "resource"].includes(type)) return "rules";
  if (["store", "dataset", "column"].includes(type)) return "data";
  return "execution";
}

export function cleanLayers(value) {
  const only = layers.some((layer) => layer.id === value?.only) ? value.only : "all";
  const ids = layers.map((layer) => layer.id);
  const priorOrder = Array.isArray(value?.order) ? [...value.order] : [];
  const defaultOrder =
    value?.orderMode === "default" ||
    (value?.orderMode !== "custom" &&
      (!priorOrder.length ||
        [ids, legacyOrder, legacyOrder.filter((id) => id !== "project")].some((order) =>
          sameOrder(priorOrder, order),
        )));
  if (value?.schema !== 2 && !priorOrder.includes("project") && priorOrder.includes("code"))
    priorOrder.splice(priorOrder.indexOf("code"), 0, "project");
  const order = defaultOrder
    ? ids
    : [...new Set([...priorOrder, ...ids])].filter((id) => ids.includes(id));
  return {
    schema: 2,
    enabled: value?.enabled === true,
    drawer: value?.drawer === true,
    compact: value?.compact === true,
    camera: ["angled", "front", "side", "top"].includes(value?.camera) ? value.camera : "top",
    gap: Number.isFinite(value?.gap) ? Math.max(80, Math.min(600, value.gap)) : 260,
    order,
    orderMode: defaultOrder ? "default" : "custom",
    only,
    visible: Array.isArray(value?.visible)
      ? layers
          .filter(
            (layer) =>
              value.visible.includes(layer.id) ||
              (layer.id === "project" &&
                value.schema !== 2 &&
                layers
                  .filter((item) => item.id !== "project")
                  .every((item) => value.visible.includes(item.id))),
          )
          .map((layer) => layer.id)
      : layers.filter((layer) => only === "all" || only === layer.id).map((layer) => layer.id),
    projections: value?.projections !== false,
  };
}

/** Visible, populated planes occupy consecutive slots in the chosen order. */
export function layerHeights(settings, scope = layers) {
  const config = cleanLayers(settings),
    result = new Map();
  config.order = config.order.filter(
    (id) => config.visible.includes(id) && scope.some((layer) => layer.id === id),
  );
  let height = 0;
  for (let i = config.order.length - 1; i >= 0; i--) {
    const id = config.order[i];
    if (i < config.order.length - 1) height += config.gap;
    result.set(id, height);
  }
  return result;
}

/** A layer filter keeps endpoints together; it never manufactures a direct relation. */
export function layerSlice(graph, settings) {
  const visible = cleanLayers(settings).visible;
  if (visible.length === layers.length) return graph;
  const boxes = graph.boxes.filter((box) => visible.includes(layerOf(box.node)));
  const ids = new Set(boxes.map((box) => box.id));
  return {
    ...graph,
    boxes,
    byId: new Map(boxes.map((box) => [box.id, box])),
    regions: (graph.regions || []).filter((region) => ids.has(region.id)),
    edges: graph.edges.filter((edge) => ids.has(edge.from) && ids.has(edge.to)),
  };
}
