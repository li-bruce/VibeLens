"""Independent application, storage, state, and observer-isolation checks."""

from concurrent.futures import ThreadPoolExecutor
import io
import json
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from contextlib import closing
from copy import deepcopy
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "observer_runtime"), str(ROOT / "tooling")]
from app.web import create_app
from app.service import DomainError
from integrations.bo_adapter import BOTrace
from integrations.bo_view import BOGraphSession, GraphSession, bo_view_configuration
from bo_stategraph.workflow import machine_snapshot
from scenarios import CONTENT, login_client, csrf, run_workflow, run_revocation


class SharingTests(unittest.TestCase):
    def setUp(self):
        (ROOT / "review/tmp").mkdir(parents=True, exist_ok=True)
        self.directory = tempfile.TemporaryDirectory(prefix="sharing-test-", dir=ROOT / "review/tmp")
        self.path = Path(self.directory.name) / "trial.sqlite3"
        self.app = create_app(ROOT, self.path)
        self.service = self.app.extensions["sharing"]

    def tearDown(self):
        self.service.store.engine.dispose()
        self.directory.cleanup()

    def test_confirmed_workflow_without_observer(self):
        observations, _ = run_workflow(self.app)
        expected = json.loads((ROOT / "acceptance.json").read_text(encoding="utf-8"))["checks"]
        for check in expected:
            if check["case"] == "workflow":
                self.assertEqual(observations[check["path"][0]], check["equals"], check["id"])

    def test_private_file_and_exact_owner_download(self):
        row = self.service.upload("linzhou", "private.txt", CONTENT)
        self.assertEqual(row["state"], "private")
        self.assertEqual(self.service.download("linzhou", row["id"])[1], CONTENT)
        self.assertEqual(self.service.list_files("xuning"), [])
        with self.assertRaises(DomainError):
            self.service.download("xuning", row["id"])

    def test_unknown_recipient_rolls_back(self):
        row = self.service.upload("linzhou", "private.txt", CONTENT)
        before = self.service.store.snapshots()
        with self.assertRaises(DomainError) as caught:
            self.service.share("linzhou", row["id"], "missing")
        self.assertEqual(caught.exception.code, "recipient_not_found")
        self.assertEqual(self.service.store.snapshots(), before)
        with closing(sqlite3.connect(self.path)) as connection:
            self.assertEqual(connection.execute("SELECT COUNT(*) FROM shares").fetchone()[0], 0)

    def test_duplicate_and_concurrent_share_preserve_one_grant(self):
        row = self.service.upload("linzhou", "note.txt", CONTENT)
        with ThreadPoolExecutor(max_workers=3) as pool:
            list(pool.map(lambda _: self.service.share("linzhou", row["id"], "xuning"), range(3)))
        with closing(sqlite3.connect(self.path)) as connection:
            self.assertEqual(connection.execute("SELECT COUNT(*) FROM shares").fetchone()[0], 1)
            state, revision = connection.execute("SELECT state, revision FROM files").fetchone()
        self.assertEqual((state, revision), ("shared", 4))
        self.assertEqual(self.service.download("xuning", row["id"])[1], CONTENT)

    def test_all_demo_users_may_own_their_own_uploads(self):
        row = self.service.upload("zhoulan", "own.txt", b"")
        self.assertEqual(row["owner_id"], "zhoulan")
        self.assertEqual(self.service.download("zhoulan", row["id"])[1], b"")
        with self.assertRaises(DomainError):
            self.service.share("linzhou", row["id"], "xuning")

    def test_invalid_actor_cannot_upload(self):
        for actor in ["", "unknown"]:
            with self.assertRaises(DomainError):
                self.service.upload(actor, "note.txt", CONTENT)
        self.assertEqual(self.service.store.snapshots(), [])

    def test_csrf_and_cookie_are_required_for_writes(self):
        client, _ = login_client(self.app, "linzhou")
        result = client.post("/upload", data={"file": (io.BytesIO(CONTENT), "note.txt")})
        self.assertEqual(result.status_code, 400)
        self.assertEqual(self.service.store.snapshots(), [])

    def test_file_name_and_download_headers(self):
        row = self.service.upload("linzhou", "../../报告.txt", CONTENT)
        self.assertEqual(row["filename"], "报告.txt")
        client, _ = login_client(self.app, "linzhou")
        response = client.get(f"/files/{row['id']}/download")
        self.assertEqual(response.data, CONTENT)
        self.assertTrue(response.headers["Content-Disposition"].startswith("attachment;"))
        self.assertEqual(response.headers["Cache-Control"], "no-store")
        self.assertEqual(response.headers["X-Content-Type-Options"], "nosniff")
        with self.assertRaises(DomainError):
            self.service.upload("linzhou", "bad\x00name", CONTENT)

    def test_no_file_edit_or_delete_endpoints(self):
        row = self.service.upload("linzhou", "note.txt", CONTENT)
        client, _ = login_client(self.app, "xuning")
        self.assertIn(client.put(f"/files/{row['id']}").status_code, [404, 405])
        self.assertIn(client.delete(f"/files/{row['id']}").status_code, [404, 405])
        self.assertEqual(client.post(f"/files/{row['id']}/revoke", data={"csrf": csrf(client), "recipient_id": "xuning"}).status_code, 403)

    def test_confirmed_revocation_workflow(self):
        observations, _ = run_revocation(self.app)
        expected = json.loads((ROOT / "acceptance.json").read_text(encoding="utf-8"))["checks"]
        for check in expected:
            if check["case"] == "revocation":
                self.assertEqual(observations[check["path"][0]], check["equals"], check["id"])

    def test_flat_view_keeps_native_journal_and_state_meaning(self):
        row = self.service.upload("linzhou", "note.txt", CONTENT)
        self.service.share("linzhou", row["id"], "xuning")
        self.service.revoke("linzhou", row["id"], "xuning")
        native = machine_snapshot(self.service.store.snapshots(), "test-build")["configurations"][0]
        original = json.loads(json.dumps(native))
        shown = bo_view_configuration(native, "file")
        self.assertEqual(native, original)
        self.assertEqual(shown["native_journal"], native["journal"])
        self.assertEqual([entry["after"]["phase"] for entry in shown["journal"]], ["private", "shared", "private"])
        for raw, frame in zip(native["journal"], shown["journal"], strict=True):
            self.assertEqual((frame["seq"], frame["event"], frame["guards"]), (raw["seq"], raw["event"], raw["guards"]))
            self.assertEqual((frame["source"], frame["target"]), (raw["before"], raw["after"]))
            self.assertEqual(frame["activity"], "file")
            self.assertEqual(frame["after"]["activities"], {})
        session = BOGraphSession.__new__(BOGraphSession)
        session.model = json.loads((ROOT / "bo_stategraph/project.json").read_text(encoding="utf-8"))["model"]
        raw_view = {"machine": {"configurations": [native]}, "runtime_frames": {"frames": [{"machine": {"configurations": [native]}}]}}
        with patch.object(GraphSession, "view", return_value=deepcopy(raw_view)):
            view = session.view()
        self.assertEqual(view["machine"]["configurations"][0], shown)
        self.assertEqual(view["runtime_frames"]["frames"][0]["machine"]["configurations"][0], shown)

    def test_revoke_csrf_failure_preserves_access(self):
        row = self.service.upload("linzhou", "note.txt", CONTENT)
        self.service.share("linzhou", row["id"], "xuning")
        owner, _ = login_client(self.app, "linzhou")
        self.assertEqual(owner.post(f"/files/{row['id']}/revoke", data={"recipient_id": "xuning"}).status_code, 400)
        self.assertEqual(self.service.download("xuning", row["id"])[1], CONTENT)

    def test_concurrent_revoke_preserves_other_recipient(self):
        row = self.service.upload("linzhou", "note.txt", CONTENT)
        self.service.share("linzhou", row["id"], "xuning")
        self.service.share("linzhou", row["id"], "zhoulan")
        with ThreadPoolExecutor(max_workers=3) as pool:
            list(pool.map(lambda _: self.service.revoke("linzhou", row["id"], "xuning"), range(3)))
        self.assertEqual(self.service.download("zhoulan", row["id"])[1], CONTENT)
        self.assertEqual(self.service.download("linzhou", row["id"])[1], CONTENT)
        with self.assertRaises(DomainError):
            self.service.download("xuning", row["id"])
        with closing(sqlite3.connect(self.path)) as connection:
            self.assertEqual(connection.execute("SELECT state FROM files WHERE id=?", (row["id"],)).fetchone()[0], "shared")
            self.assertEqual(connection.execute("SELECT recipient_id FROM shares WHERE file_id=?", (row["id"],)).fetchall(), [("zhoulan",)])

    def test_observer_transport_fault_preserves_effects(self):
        trace = BOTrace(ROOT, mode="fault", capacity=16)
        self.service.bo_trace, self.service.store.bo_data = trace, trace.data
        row = self.service.upload("linzhou", "note.txt", CONTENT)
        self.service.share("linzhou", row["id"], "xuning")
        self.assertEqual(self.service.download("xuning", row["id"])[1], CONTENT)
        self.service.revoke("linzhou", row["id"], "xuning")
        self.assertEqual(self.service.download("linzhou", row["id"])[1], CONTENT)
        with self.assertRaises(DomainError):
            self.service.download("xuning", row["id"])
        trace.close()
        self.assertGreater(trace.probe.bo_errors + trace.probe.bo_dropped, 0)

    def test_queue_saturation_preserves_effects(self):
        trace = BOTrace(ROOT, mode="on", capacity=1)
        self.service.bo_trace, self.service.store.bo_data = trace, trace.data
        row = self.service.upload("linzhou", "note.txt", CONTENT)
        self.service.share("linzhou", row["id"], "xuning")
        self.assertEqual(self.service.download("xuning", row["id"])[1], CONTENT)
        self.service.revoke("linzhou", row["id"], "xuning")
        self.assertEqual(self.service.download("linzhou", row["id"])[1], CONTENT)
        with self.assertRaises(DomainError):
            self.service.download("xuning", row["id"])
        trace.close()
        self.assertGreater(trace.probe.bo_dropped, 0)

    def test_core_runs_with_observer_files_absent(self):
        destination = Path(self.directory.name) / "core"
        destination.mkdir()
        for name in ["app", "bo_stategraph"]:
            shutil.copytree(ROOT / name, destination / name, ignore=shutil.ignore_patterns("__pycache__", "data", "config", "database-catalog.json"))
        command = [sys.executable, "-B", "-c", f"from pathlib import Path; from app.storage import Store; from app.service import SharingService; p=Path({str(destination)!r}); s=Store(p/'core.sqlite3'); s.initialize(); x=SharingService(p,s); f=x.upload('linzhou','core.txt',b'core'); x.share('linzhou',f['id'],'xuning'); assert x.download('xuning',f['id'])[1]==b'core'; x.revoke('linzhou',f['id'],'xuning'); assert x.download('linzhou',f['id'])[1]==b'core'; s.engine.dispose(); print('core_ok')"]
        result = subprocess.run(command, cwd=destination, capture_output=True, text=True, encoding="utf-8")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("core_ok", result.stdout)


if __name__ == "__main__":
    unittest.main()
