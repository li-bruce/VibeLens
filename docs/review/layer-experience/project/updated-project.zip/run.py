"""Start both local services; restart only the owned worker after model regeneration."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time
from werkzeug.serving import make_server as app_server
from app.web import create_app

ROOT = Path(__file__).resolve().parent


def build_signature(root=ROOT):
    raw = (root / "bo_stategraph/project.json").read_bytes()
    project = json.loads(raw)
    digest = hashlib.sha256(raw)
    for name in sorted(project["model"]["source_files"]):
        digest.update(name.encode("utf-8"))
        path = root / name
        digest.update(path.read_bytes() if path.is_file() else b"missing")
    return digest.hexdigest()


def terminate_worker(child):
    """Terminate only this launcher's worker and its Windows venv descendants."""
    if child.poll() is not None:
        return
    if os.name == "nt":
        subprocess.run(["taskkill", "/PID", str(child.pid), "/T", "/F"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
    else:
        child.terminate()
    child.wait(timeout=10)


def worker(args):
    collector = trace = None
    graph_url = None
    if not args.core:
        try:
            sys.path.insert(0, str(ROOT / "observer_runtime"))
            from integrations.bo_view import BOGraphSession
            from bo_observer.service import make_server
            from bo_observer.web.view_preferences import Preferences
            from integrations.bo_adapter import BOTrace
            session = BOGraphSession(ROOT)
            session.preferences = Preferences(ROOT, session.project["project_id"],
                legacy_project_ids=session.model.get("presentation", {}).get("layout_aliases", []))
            collector = make_server(session, args.graph_port, origins=(f"http://127.0.0.1:{args.port}",), assets=ROOT / "static/graph")
            trace = BOTrace(ROOT, capacity=4096, sink=lambda value, kind: session.event(value) if kind == "events" else session.snapshot(value))
            threading.Thread(target=collector.serve_forever, daemon=True).start()
            graph_url = f"http://127.0.0.1:{collector.server_port}/graph"
        except Exception as error:
            print(f"Observer unavailable ({type(error).__name__}); application continues independently.", flush=True)
            if collector:
                collector.server_close()
            collector = trace = None
    app = create_app(ROOT, bo_trace=trace, bo_data=trace.data if trace else None, graph_url=graph_url)
    server = app_server("127.0.0.1", args.port, app, threaded=True)
    print(f"Application: http://127.0.0.1:{server.server_port}/", flush=True)
    print(f"Graph: {graph_url or 'disabled'}", flush=True)
    print("Demo accounts: linzhou / xuning / zhoulan; password: file-demo-2026", flush=True)
    try:
        server.serve_forever()
    finally:
        server.server_close()
        if trace:
            trace.close()
        if collector:
            collector.shutdown()
            collector.server_close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8850)
    parser.add_argument("--graph-port", type=int, default=8847)
    parser.add_argument("--core", action="store_true")
    parser.add_argument("--worker", action="store_true")
    args = parser.parse_args()
    os.environ.setdefault("FILE_SHARING_DB_URL", "sqlite:///data/sharing.sqlite3")
    if args.worker:
        return worker(args)
    child = None
    try:
        while True:
            signature = build_signature()
            command = [sys.executable, "-B", "-u", str(ROOT / "run.py"), "--worker", "--port", str(args.port), "--graph-port", str(args.graph_port)]
            if args.core:
                command.append("--core")
            child = subprocess.Popen(command, cwd=ROOT)
            while child.poll() is None:
                time.sleep(0.8)
                current = build_signature()
                if current != signature:
                    print("Bound build changed; restarting the owned producer and collector.", flush=True)
                    terminate_worker(child)
                    break
            else:
                return child.returncode
    except KeyboardInterrupt:
        pass
    finally:
        if child and child.poll() is None:
            terminate_worker(child)


if __name__ == "__main__":
    raise SystemExit(main())
