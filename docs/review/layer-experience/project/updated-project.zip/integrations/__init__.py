"""Optional observation integrations."""
