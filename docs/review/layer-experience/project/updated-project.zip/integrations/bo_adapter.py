"""Fault-isolated adapter for the exact managed VibeLens runtime."""

from copy import deepcopy
import json
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "observer_runtime"))
from bo_observer.adapters.python.bo_probe import BOProbe
from bo_observer.policy.recording import record_evaluation
from bo_observer.data.runtime import BODataRuntime
from bo_observer.graph.behavior_model import capture
from bo_stategraph.workflow import file_context, machine_snapshot


class BOTrace:
    def __init__(self, root, *, mode="on", sink=None, capacity=256):
        self.root = Path(root)
        self.project = json.loads((self.root / "bo_stategraph/project.json").read_text(encoding="utf-8"))
        self.manifest = capture(self.root, self.project["model"])
        self.events, self.snapshots, self.evaluations, self.rejections = [], [], [], []
        self.errors = 0
        self.mode, self.sink = mode, sink
        self.probe = BOProbe(self.project, self.manifest["build_id"], enabled=mode != "off", capacity=capacity, sink=self.bo_sink)
        self.data = BODataRuntime(self.probe, json.loads((self.root / "bo_stategraph/databases.json").read_text(encoding="utf-8")))

    def bo_sink(self, value, kind):
        if self.mode == "fault":
            raise OSError("injected_observer_transport_failure")
        if self.sink:
            try:
                self.sink(value, kind)
            except Exception as error:
                self.rejections.append({"kind": kind, "node": value.get("node"), "error": str(error)})
                raise
        (self.events if kind == "events" else self.snapshots).append(deepcopy(value))

    def record(self, node, phase, builder, **kwargs):
        try:
            return self.probe.record(node, phase, builder, **kwargs)
        except Exception:
            self.errors += 1
            return None

    def policy(self, policy, evaluation, entity):
        try:
            if self.mode == "on":
                self.evaluations.append(deepcopy(evaluation))
            record_evaluation(policy, evaluation, self.probe, entity=entity, attempt=entity)
        except Exception:
            self.errors += 1

    def state(self, row, evidence_id, transition):
        try:
            if evidence_id:
                configuration = machine_snapshot([row], self.manifest["build_id"])["configurations"][0]
                self.probe.snapshot(row["id"], row["state"], file_context(row), row["revision"], evidence_id,
                    event=transition["event"], guards=transition["guards"], payload=transition["payload"], configuration=configuration)
        except Exception:
            self.errors += 1

    def close(self):
        self.probe.flush(10)
        self.probe.close()
