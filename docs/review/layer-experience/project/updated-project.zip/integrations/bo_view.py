"""Project flat-state journals into the viewer's historical-frame interface."""

from copy import deepcopy
from bo_observer.observation.session import GraphSession


def bo_view_configuration(configuration, owner):
    result = deepcopy(configuration)
    journal = result.get("journal", [])
    if not journal or not all(isinstance(entry.get("before"), str) and isinstance(entry.get("after"), str) for entry in journal):
        return result
    result["native_journal"] = deepcopy(journal)
    result["journal"] = [{**deepcopy(entry), "activity": owner,
        "source": entry["before"], "target": entry["after"],
        "before": {"phase": entry["before"], "activities": {}},
        "after": {"phase": entry["after"], "activities": {}}} for entry in journal]
    return result


class BOGraphSession(GraphSession):
    """Keep authoritative native snapshots intact and adapt only the public view."""

    def view(self):
        result = super().view()
        owner = "file"
        if owner not in {node["id"] for node in self.model["nodes"]}:
            raise ValueError("flat_state_owner_missing")
        machines = [result["machine"]] + [frame["machine"] for frame in result.get("runtime_frames", {}).get("frames", [])]
        for machine in machines:
            machine["configurations"] = [bo_view_configuration(configuration, owner)
                for configuration in machine.get("configurations", [])]
        return result
