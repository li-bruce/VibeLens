"""Record the coding review for the current candidate without altering its baseline."""
import json
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
SKILL = Path((ROOT / "tooling/skill-path.txt").read_text(encoding="utf-8").strip())
sys.path[:0] = [str(ROOT), str(SKILL / "scripts")]
from bo_observer.workflow.sync_config import config, snapshot
current = snapshot(ROOT, config(ROOT, "sync.json"))
active = json.loads((ROOT / ".stategraph/active.json").read_text(encoding="utf-8"))["change"]
review = {"candidate_id": current["id"], "decisions": {
    "business": {"action": "updated", "reason": "User instruction U3 adds owner-only, recipient-specific revocation and denial of a new download from a stale page. Original upload/share/download cases remain protected."},
    "state_machine": {"action": "updated", "reason": "The same bo.fsm declaration adds revoke branches selected by the real remaining grant count. The actual SQLite journal and state snapshots witness both branches."},
    "abstraction": {"action": "updated", "reason": "Mapped every inventoried application function, HTTP entry, state, shared policy and configured data operation."},
    "probes": {"action": "updated", "reason": "Bound safe actual values and independently exercised on/off/fault modes; passwords, tokens and file bodies are excluded."}},
    "requirement_changes": {"R_SCOPE": "U3 explicitly authorizes revocation; the old no-revocation scope assertion is now limited to the remaining excluded actions. File edit/delete exclusions remain.",
        "R_REVOKE": "New confirmed requirement U3: only the owner may remove a selected recipient relation; later downloads are denied while ownership/content and other grants remain."},
    "excluded_symbols": {},
    "environment_change": "No framework upgrade is part of this iteration. Initial source and verification are preserved in review/baselines/initial-v1. The new change baseline is immutable."}
if Path(active).name == "diagnosis-03":
    review["decisions"] = {
        "business": {"action": "updated", "reason": "Controlled-fault diagnosis of the existing owner revocation requirement. Original independent business assertions remain byte-identical; no new behavior is requested."},
        "state_machine": {"action": "unchanged", "reason": "The native state declaration and guards are unchanged. Real snapshots and database journal distinguish shared-to-shared failure from successful revocation."},
        "abstraction": {"action": "updated", "reason": "Refresh actual source mappings and retain the existing function/feature inventory and stable business/policy identities."},
        "probes": {"action": "unchanged", "reason": "Original observers, fields, modes, mapping assertions, and whitebox checks remain unchanged. The diagnostic SQL listener only observes driver bindings."}}
    review["requirement_changes"] = {}
    review["environment_change"] = "Isolated copy and copy-local synthetic databases, app port 8852 and graph port 8853. Canonical native framework is used without schema or projection compatibility patches. All evidence belongs to review/diagnosis."
elif Path(active).name == "framework-compat-01":
    review["decisions"] = {
        "business": {"action": "unchanged", "reason": "All confirmed V2 requirements, business code, and independent expectations are byte-preserved."},
        "state_machine": {"action": "unchanged", "reason": "The same native bo.fsm declaration and state-transition witnesses remain required."},
        "abstraction": {"action": "updated", "reason": "Regenerated source mappings after normal candidate-framework upgrade and complete removal of the schema/projection shim."},
        "probes": {"action": "unchanged", "reason": "All probe fields, registered cases, modes, and independent mapping requirements are retained."}}
    review["requirement_changes"] = {}
    review["environment_change"] = "Separate framework compatibility regression against an unreleased working-tree candidate. Native protocol and projection interfaces replace the removed shim. The project-native journal view adapter is unchanged. Adapted V2 source, evidence, and costs remain frozen."
(ROOT / active / "review.json").write_text(json.dumps(review, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"candidate_id": current["id"], "reviewed": True}))
