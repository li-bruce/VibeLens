"""Reproducible headless browser acceptance against the actual served build."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "observer_runtime")]
from bo_observer.graph.behavior_model import capture


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--url", default="http://127.0.0.1:8850")
    parser.add_argument("--graph", default="http://127.0.0.1:8847")
    parser.add_argument("--out", default="review/browser")
    args = parser.parse_args()
    output = ROOT / args.out
    output.mkdir(parents=True, exist_ok=True)
    project = json.loads((ROOT / "bo_stategraph/project.json").read_text(encoding="utf-8"))
    expected_build = capture(ROOT, project["model"])["build_id"]
    steps, images, errors = [], [], []

    def step(name, details=None):
        steps.append({"order": len(steps) + 1, "name": name, "time_unix": time.time(), "details": details})
        (output / "steps-latest.json").write_text(json.dumps(steps, ensure_ascii=False, indent=2), encoding="utf-8")

    def screenshot(page, name):
        path = output / (name + ".png")
        page.screenshot(path=str(path), full_page=True)
        images.append({"file": path.relative_to(ROOT).as_posix(), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})

    with sync_playwright() as playwright:
        executable = os.environ.get("FILE_SHARING_BROWSER", r"C:\Program Files\Google\Chrome\Application\chrome.exe")
        browser = playwright.chromium.launch(headless=True, executable_path=executable)
        contexts = [browser.new_context(viewport={"width": 1440, "height": 1080}, accept_downloads=True) for _ in range(4)]
        owner, recipient, outsider, graph = [context.new_page() for context in contexts]
        for page in [owner, recipient, outsider, graph]:
            page.on("pageerror", lambda error: errors.append(str(error)))
        graph.on("console", lambda message: errors.append(message.text) if message.type == "error" else None)
        health = graph.request.get(args.graph + "/api/bo/health").json()
        assert health["build_id"] == expected_build, "served_build_mismatch"
        assert health["binding"]["status"] == "current", health
        graph.goto(args.graph + "/graph")
        graph.locator("#viewport").wait_for(state="visible")
        previous = graph.request.get(args.graph + "/api/recordings").json().get("active")
        if previous:
            assert previous["label"] == "Initial headless browser workflow", "unrelated_active_recording"
            graph.request.post(args.graph + "/api/recordings/stop", data={})
        started = graph.request.post(args.graph + "/api/recordings/start", data={"label": "Initial headless browser workflow"})
        assert started.ok, started.text()
        step("recording_started", {"build_id": expected_build})

        def login(page, user):
            page.goto(args.url + "/login")
            page.locator("#username").select_option(user)
            page.locator("#password").fill("file-demo-2026")
            page.get_by_role("button", name="登录，进入文件列表").click()
            page.get_by_role("heading", name="文件，在这里交接。").wait_for()
            step("signed_in", {"user": user})

        owner.goto(args.url + "/login")
        screenshot(owner, "01-login")
        login(owner, "linzhou")
        filename = f"browser-sharing-note-{time.time_ns()}.txt"
        content = b"Headless browser acceptance: Lin Zhou shares with Xu Ning.\n"
        owner.locator("#file").set_input_files({"name": filename, "mimeType": "text/plain", "buffer": content})
        owner.get_by_role("button", name="上传文件 ↑").click()
        row = owner.get_by_role("row").filter(has=owner.get_by_text(filename, exact=True)).last
        row.wait_for()
        download_url = row.get_by_role("link", name="下载 ↓").get_attribute("href")
        file_id = download_url.split("/")[2]
        step("uploaded", {"filename": filename, "file_id": file_id, "size": len(content)})
        row.get_by_role("combobox").select_option("xuning")
        row.get_by_role("button", name="共享", exact=True).click()
        owner.get_by_role("status").wait_for()
        screenshot(owner, "02-owner-shared")
        step("shared_with_designated_user", {"recipient": "xuning"})
        login(recipient, "xuning")
        received_row = recipient.get_by_role("row").filter(has=recipient.get_by_text(filename, exact=True)).last
        screenshot(recipient, "03-recipient")
        assert "林舟" in received_row.get_by_role("cell").nth(1).inner_text()
        assert received_row.get_by_text(f"{len(content)} 字节", exact=True).is_visible()
        assert received_row.get_by_role("button", name="共享", exact=True).count() == 0
        with recipient.expect_download() as download_info:
            received_row.get_by_role("link", name="下载文件 ↓").click()
        download = download_info.value
        saved = output / "downloaded-note.txt"
        download.save_as(str(saved))
        assert saved.read_bytes() == content
        step("recipient_downloaded_exact_bytes", {"sha256": hashlib.sha256(content).hexdigest()})
        token = recipient.locator('form[action="/logout"] input[name="csrf"]').input_value()
        rejection = recipient.request.post(args.url + f"/files/{file_id}/share", form={"csrf": token, "recipient_id": "zhoulan"})
        assert rejection.status == 403
        step("recipient_reshare_rejected", {"status": 403})
        login(outsider, "zhoulan")
        assert outsider.get_by_text(filename, exact=True).count() == 0
        screenshot(outsider, "04-unrelated-user")
        denied = outsider.request.get(args.url + download_url)
        assert denied.status == 403
        step("unrelated_download_rejected", {"status": denied.status})
        deadline = time.monotonic() + 75
        while True:
            live = graph.request.get(args.graph + "/api/view").json()
            settled = any(event.get("node") == "authorize" and event.get("inputs", {}).get("actor") == "zhoulan"
                and event.get("inputs", {}).get("operation") == "download" and event.get("outputs", {}).get("allowed") is False
                for event in live["events"])
            if settled:
                break
            assert time.monotonic() < deadline, "runtime_capture_did_not_reach_last_operation"
            time.sleep(0.15)
        assert any(event.get("node") == "share" and event.get("entity") == file_id for event in live["events"])
        assert any(event.get("node") == "download" and event.get("inputs", {}).get("actor") == "xuning"
            and event.get("entity") == file_id for event in live["events"])
        assert any(frame.get("authority", {}).get("entity") == file_id and frame["authority"].get("state") == "shared"
            for frame in live["runtime_frames"]["frames"])
        event_count = len(live["events"])
        step("actual_upload_share_download_and_state_witnesses_arrived", {"events": event_count})
        stopped = graph.request.post(args.graph + "/api/recordings/stop", data={})
        assert stopped.ok, stopped.text()
        recording = stopped.json()
        (output / "recording-stop.json").write_text(json.dumps(recording, ensure_ascii=False, indent=2), encoding="utf-8")
        graph = contexts[3].new_page()
        graph.on("pageerror", lambda error: errors.append(str(error)))
        graph.on("console", lambda message: errors.append(message.text) if message.type == "error" else None)
        graph.goto(args.graph + "/graph")
        graph.locator("#viewport").wait_for(state="visible")
        graph.wait_for_function("build => !document.querySelector('#connection').textContent.includes('暂时无法连接') && document.querySelector('#binding').textContent.includes(build)", arg=expected_build[:8], timeout=75000)
        graph.locator(f'#record-list option[value="{recording["id"]}"]').wait_for(state="attached", timeout=75000)
        graph.locator("#record-list").select_option(recording["id"])
        graph.locator("#replay").wait_for(state="visible")
        graph.locator("#replay-next").click()
        assert graph.locator("#replay-position").inner_text()
        screenshot(graph, "05-runtime-graph")
        step("recording_stopped_reloaded_and_replayed")
        after_controls = graph.request.get(args.graph + "/api/view").json()
        assert len(after_controls["events"]) == event_count, "viewer_control_created_business_events"
        after = graph.request.get(args.graph + "/api/bo/health").json()
        assert after["build_id"] == expected_build and after["binding"]["status"] == "current"
        assert not errors, errors
        report = {"valid": True, "browser": browser.version, "headless": True, "application": args.url,
            "graph": args.graph, "build_id_before": expected_build, "build_id_after": after["build_id"],
            "steps": steps, "screenshots": images, "page_errors": errors, "file_id": file_id}
        (output / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(json.dumps({"valid": True, "steps": len(steps), "screenshots": len(images), "build_id": expected_build}))
        browser.close()


if __name__ == "__main__":
    main()
