"""Offline native metadata export; does not connect to or initialize a database."""
import json
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "observer_runtime")]
from sqlalchemy.dialects.sqlite import dialect
from app.models import metadata
from bo_observer.data.catalog import export_sqlalchemy_metadata
print(json.dumps(export_sqlalchemy_metadata(metadata, "sharing", dialect=dialect()), ensure_ascii=False))
