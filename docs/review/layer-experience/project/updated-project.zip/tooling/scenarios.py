"""Independent trial scenarios; expected outcomes do not call policy predicates."""

import hashlib
import io
import re
import sqlite3
from contextlib import closing
from app.storage import DEMO_PASSWORD

CONTENT = b"A private note from Lin Zhou to Xu Ning.\n"


def login_client(app, username, password=DEMO_PASSWORD):
    client = app.test_client()
    page = client.get("/login")
    token = re.search(rb'name="csrf" value="([^"]+)"', page.data).group(1).decode()
    result = client.post("/login", data={"username": username, "password": password, "csrf": token})
    return client, result


def csrf(client):
    with client.session_transaction() as state:
        return state["csrf"]


def run_workflow(app):
    owner, signed_in = login_client(app, "linzhou")
    recipient, _ = login_client(app, "xuning")
    outsider, _ = login_client(app, "zhoulan")
    bad, rejected = login_client(app, "linzhou", "incorrect-demo-password")
    observations = {"login_ok": signed_in.status_code == 302,
        "bad_login_denied": rejected.status_code == 401 and "user_id" not in bad.get("/api/files").json}
    owner.post("/upload", data={"csrf": csrf(owner), "file": (io.BytesIO(CONTENT), "shared-note.txt")}, content_type="multipart/form-data")
    api = owner.get("/api/files").json
    assert len(api) == 1, api
    file_id = api[0]["id"]
    store = app.extensions["sharing"].store
    with closing(sqlite3.connect(store.path)) as connection:
        observations["owner_id"] = connection.execute("SELECT owner_id FROM files WHERE id=?", (file_id,)).fetchone()[0]
    assert recipient.get("/api/files").json == []
    shared = owner.post(f"/files/{file_id}/share", data={"csrf": csrf(owner), "recipient_id": "xuning"})
    assert shared.status_code == 302
    with closing(sqlite3.connect(store.path)) as connection:
        observations["recipient_id"] = connection.execute("SELECT recipient_id FROM shares WHERE file_id=?", (file_id,)).fetchone()[0]
        before = connection.execute("SELECT COUNT(*) FROM shares").fetchone()[0]
    observations["recipient_share_denied"] = recipient.post(f"/files/{file_id}/share", data={"csrf": csrf(recipient), "recipient_id": "zhoulan"}).status_code == 403
    observations["outsider_share_denied"] = outsider.post(f"/files/{file_id}/share", data={"csrf": csrf(outsider), "recipient_id": "zhoulan"}).status_code == 403
    observations["received_filename"] = recipient.get("/api/files").json[0]["filename"]
    dashboard = recipient.get("/")
    observations["download_matches"] = recipient.get(f"/files/{file_id}/download").data == CONTENT
    observations["outsider_download_denied"] = outsider.get(f"/files/{file_id}/download").status_code == 403
    anonymous = app.test_client()
    observations["anonymous_download_denied"] = anonymous.get(f"/files/{file_id}/download").status_code == 401
    with closing(sqlite3.connect(store.path)) as connection:
        observations["denial_preserves_grants"] = before == connection.execute("SELECT COUNT(*) FROM shares").fetchone()[0]
        observations["file_state"] = connection.execute("SELECT state FROM files WHERE id=?", (file_id,)).fetchone()[0]
    routes = {rule.rule for rule in app.url_map.iter_rules()}
    observations["no_extra_actions"] = not any(any(word in route for word in ["delete", "register", "preview", "approve"]) for route in routes)
    assert b"shared-note.txt" in dashboard.data
    assert not re.search(rb'action="/files/[^"]+/share"', dashboard.data)
    owner.post("/logout", data={"csrf": csrf(owner)})
    assert owner.get(f"/files/{file_id}/download").status_code == 401
    return observations, file_id


def run_revocation(app):
    owner, _ = login_client(app, "linzhou")
    recipient, _ = login_client(app, "xuning")
    outsider, _ = login_client(app, "zhoulan")
    service = app.extensions["sharing"]
    row = service.upload("linzhou", "revoked-note.txt", CONTENT)
    file_id = row["id"]
    service.share("linzhou", file_id, "xuning")
    stale_page = recipient.get("/")
    download_url = f"/files/{file_id}/download"
    assert download_url.encode() in stale_page.data
    observations = {}
    with closing(sqlite3.connect(service.store.path)) as connection:
        before = connection.execute("SELECT filename, owner_id, size, sha256, content FROM files WHERE id=?", (file_id,)).fetchone()
        original_grants = connection.execute("SELECT file_id,recipient_id FROM shares ORDER BY id").fetchall()
    observations["recipient_revoke_denied"] = recipient.post(f"/files/{file_id}/revoke", data={"csrf": csrf(recipient), "recipient_id": "xuning"}).status_code == 403
    observations["outsider_revoke_denied"] = outsider.post(f"/files/{file_id}/revoke", data={"csrf": csrf(outsider), "recipient_id": "xuning"}).status_code == 403
    anonymous = app.test_client()
    anonymous.get("/login")
    observations["anonymous_revoke_denied"] = anonymous.post(f"/files/{file_id}/revoke", data={"csrf": csrf(anonymous), "recipient_id": "xuning"}).status_code == 401
    with closing(sqlite3.connect(service.store.path)) as connection:
        observations["denials_preserve_grants"] = original_grants == connection.execute("SELECT file_id,recipient_id FROM shares ORDER BY id").fetchall()
    other = service.upload("linzhou", "other-recipient-note.txt", CONTENT)
    service.share("linzhou", other["id"], "xuning")
    observations["owner_revoke_ok"] = owner.post(f"/files/{file_id}/revoke", data={"csrf": csrf(owner), "recipient_id": "xuning"}).status_code == 302
    observations["stale_download_status"] = recipient.get(download_url).status_code
    observations["owner_download_matches"] = owner.get(download_url).data == CONTENT
    observations["other_file_grant_retained"] = recipient.get(f"/files/{other['id']}/download").data == CONTENT
    visible = recipient.get("/api/files").json
    assert file_id not in [item["id"] for item in visible]
    with closing(sqlite3.connect(service.store.path)) as connection:
        after = connection.execute("SELECT filename, owner_id, size, sha256, content FROM files WHERE id=?", (file_id,)).fetchone()
        observations["file_retained"] = before == after
    observations["repeated_revoke_ok"] = owner.post(f"/files/{file_id}/revoke", data={"csrf": csrf(owner), "recipient_id": "xuning"}).status_code == 302
    assert owner.post(f"/files/{file_id}/share", data={"csrf": csrf(owner), "recipient_id": "xuning"}).status_code == 302
    observations["reshare_download_matches"] = recipient.get(download_url).data == CONTENT
    service.revoke("linzhou", file_id, "xuning")
    service.share("linzhou", other["id"], "zhoulan")
    service.revoke("linzhou", other["id"], "xuning")
    observations["other_recipient_download_matches"] = outsider.get(f"/files/{other['id']}/download").data == CONTENT
    with closing(sqlite3.connect(service.store.path)) as connection:
        observations["owner_id"], observations["revoked_file_state"] = connection.execute("SELECT owner_id,state FROM files WHERE id=?", (file_id,)).fetchone()
        observations["revoked_grants"] = connection.execute("SELECT COUNT(*) FROM shares WHERE file_id=?", (file_id,)).fetchone()[0]
    return observations, file_id
