"""Headless acceptance: revoke an existing recipient grant while its page stays open."""

import argparse
from contextlib import closing
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import sys
import time
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "observer_runtime")]
from bo_observer.graph.behavior_model import capture


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--url", default="http://127.0.0.1:8850")
    parser.add_argument("--graph", default="http://127.0.0.1:8847")
    parser.add_argument("--out", default="review/iteration-02-revoke/browser")
    parser.add_argument("--obsolete-recording-id", help="An actual recording from this isolated copy's previous build.")
    args = parser.parse_args()
    output = ROOT / args.out
    output.mkdir(parents=True, exist_ok=True)
    project = json.loads((ROOT / "bo_stategraph/project.json").read_text(encoding="utf-8"))
    build_id = capture(ROOT, project["model"])["build_id"]
    steps, screenshots, errors = [], [], []
    checks = {}

    def step(name, details=None):
        steps.append({"order": len(steps) + 1, "name": name, "time_unix": time.time(), "details": details})
        (output / "steps-latest.json").write_text(json.dumps(steps, ensure_ascii=False, indent=2), encoding="utf-8")

    def screenshot(page, name):
        path = output / (name + ".png")
        page.screenshot(path=str(path), full_page=True)
        screenshots.append({"file": path.relative_to(ROOT).as_posix(), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})

    def database_facts(file_id):
        with closing(sqlite3.connect(ROOT / "data/sharing.sqlite3")) as connection:
            row = connection.execute("SELECT owner_id,filename,size,sha256,state,revision FROM files WHERE id=?", (file_id,)).fetchone()
            grants = connection.execute("SELECT recipient_id FROM shares WHERE file_id=? ORDER BY recipient_id", (file_id,)).fetchall()
            return {"owner_id": row[0], "filename": row[1], "size": row[2], "sha256": row[3], "state": row[4], "revision": row[5], "recipients": [item[0] for item in grants]}

    with sync_playwright() as playwright:
        executable = os.environ.get("FILE_SHARING_BROWSER", r"C:\Program Files\Google\Chrome\Application\chrome.exe")
        browser = playwright.chromium.launch(headless=True, executable_path=executable)
        contexts = [browser.new_context(viewport={"width": 1440, "height": 1080}, accept_downloads=True) for _ in range(4)]
        owner, recipient, outsider, graph = [context.new_page() for context in contexts]
        for page in [owner, recipient, outsider, graph]:
            page.on("pageerror", lambda error: errors.append(str(error)))
        graph.on("console", lambda message: errors.append(message.text) if message.type == "error" else None)
        health = graph.request.get(args.graph + "/api/bo/health").json()
        assert health["build_id"] == build_id and health["binding"]["status"] == "current"
        old_record = args.obsolete_recording_id or json.loads((ROOT / "review/baselines/initial-v1/browser/recording-stop.json").read_text(encoding="utf-8"))["id"]
        listing = graph.request.get(args.graph + "/api/recordings").json()
        assert old_record not in {record["id"] for record in listing["recordings"]}
        assert all(record["build_id"] == build_id for record in listing["recordings"])
        checks["obsolete_version_recordings_hidden"] = True
        if listing.get("active"):
            assert listing["active"]["label"] == "Owner revocation stale-page acceptance"
            graph.request.post(args.graph + "/api/recordings/stop", data={})
        started = graph.request.post(args.graph + "/api/recordings/start", data={"label": "Owner revocation stale-page acceptance"})
        assert started.ok, started.text()
        step("recording_started", {"build_id": build_id})

        def login(page, user):
            page.goto(args.url + "/login")
            page.locator("#username").select_option(user)
            page.locator("#password").fill("file-demo-2026")
            page.get_by_role("button", name="登录，进入文件列表").click()
            page.get_by_role("heading", name="文件，在这里交接。").wait_for()
            step("signed_in", {"user": user})

        login(owner, "linzhou")
        filename = f"revocation-note-{time.time_ns()}.txt"
        content = b"Revocation preserves this file and its owner.\n"
        owner.locator("#file").set_input_files({"name": filename, "mimeType": "text/plain", "buffer": content})
        owner.get_by_role("button", name="上传文件 ↑").click()
        owned_row = owner.get_by_role("row").filter(has=owner.get_by_text(filename, exact=True))
        owned_row.wait_for()
        download_url = owned_row.get_by_role("link", name="下载 ↓").get_attribute("href")
        file_id = download_url.split("/")[2]
        owned_row.get_by_role("combobox").select_option("xuning")
        owned_row.get_by_role("button", name="共享", exact=True).click()
        owner.get_by_role("status").wait_for()
        before = database_facts(file_id)
        assert before["recipients"] == ["xuning"] and before["owner_id"] == "linzhou"
        screenshot(owner, "01-owner-before-revoke")
        step("uploaded_and_shared", {"file_id": file_id, "recipient": "xuning"})
        login(recipient, "xuning")
        stale_row = recipient.get_by_role("row").filter(has=recipient.get_by_text(filename, exact=True))
        assert stale_row.get_by_role("button").count() == 0
        with recipient.expect_download() as downloaded:
            stale_row.get_by_role("link", name="下载文件 ↓").click()
        first_file = output / "recipient-before-revoke.txt"
        downloaded.value.save_as(str(first_file))
        assert first_file.read_bytes() == content
        screenshot(recipient, "02-recipient-before-revoke")
        stale_url = recipient.url
        stale_hash = hashlib.sha256(recipient.content().encode()).hexdigest()
        step("recipient_downloaded_before_revoke")
        token = recipient.locator('form[action="/logout"] input[name="csrf"]').input_value()
        denied = recipient.request.post(args.url + f"/files/{file_id}/revoke", form={"csrf": token, "recipient_id": "xuning"})
        assert denied.status == 403
        login(outsider, "zhoulan")
        token = outsider.locator('form[action="/logout"] input[name="csrf"]').input_value()
        denied_outsider = outsider.request.post(args.url + f"/files/{file_id}/revoke", form={"csrf": token, "recipient_id": "xuning"})
        assert denied_outsider.status == 403 and database_facts(file_id) == before
        checks["nonowner_revoke_denied_without_effects"] = True
        step("recipient_and_outsider_revoke_rejected", {"statuses": [403, 403]})
        owned_row.get_by_role("button", name="取消共享给许宁", exact=True).click()
        owner.get_by_role("status").wait_for()
        assert owned_row.get_by_role("button", name="取消共享给许宁", exact=True).count() == 0
        after = database_facts(file_id)
        assert after["recipients"] == [] and after["state"] == "private"
        assert {key: after[key] for key in ["owner_id", "filename", "size", "sha256"]} == {key: before[key] for key in ["owner_id", "filename", "size", "sha256"]}
        screenshot(owner, "03-owner-after-revoke")
        step("owner_revoked_selected_recipient", {"before": before, "after": after})
        assert recipient.url == stale_url and hashlib.sha256(recipient.content().encode()).hexdigest() == stale_hash
        assert stale_row.get_by_role("link", name="下载文件 ↓").is_visible()
        screenshot(recipient, "04-unchanged-stale-page")
        checks["recipient_page_remained_unchanged"] = True
        with recipient.expect_response(lambda response: response.url == args.url + download_url) as refused:
            stale_row.get_by_role("link", name="下载文件 ↓").click()
        assert refused.value.status == 403
        assert refused.value.headers.get("cache-control") == "no-store"
        recipient.get_by_role("heading", name="你没有操作这个文件的权限。", exact=True).wait_for()
        screenshot(recipient, "05-stale-download-denied")
        checks["stale_page_download_denied_after_commit"] = True
        step("clicked_same_stale_link_and_received_403", {"status": 403, "old_dom_sha256": stale_hash})
        with owner.expect_download() as downloaded:
            owned_row.get_by_role("link", name="下载 ↓").click()
        owner_file = output / "owner-after-revoke.txt"
        downloaded.value.save_as(str(owner_file))
        assert owner_file.read_bytes() == content
        checks["owner_download_and_file_content_preserved"] = True
        step("owner_downloaded_identical_bytes_after_revoke", {"sha256": hashlib.sha256(content).hexdigest()})
        recipient.goto(args.url + "/")
        assert recipient.get_by_text(filename, exact=True).count() == 0
        screenshot(recipient, "06-recipient-after-refresh")
        checks["revoked_file_absent_after_refresh"] = True
        deadline = time.monotonic() + 120
        while True:
            view = graph.request.get(args.graph + "/api/view").json()
            own_download = any(event.get("node") == "download" and event.get("entity") == file_id and event.get("inputs", {}).get("actor") == "linzhou" for event in view["events"])
            revoke_event = any(event.get("node") == "revoke" and event.get("entity") == file_id for event in view["events"])
            revoked_fact = any(event.get("node") == "policy:read_allowed" and event.get("outputs", {}).get("value") is False and event.get("inputs", {}).get("bo_basis", "").startswith(file_id + ":") for event in view["events"])
            if own_download and revoke_event and revoked_fact:
                break
            assert time.monotonic() < deadline, "revocation_runtime_evidence_timeout"
            time.sleep(0.15)
        frames = [frame for frame in view["runtime_frames"]["frames"] if frame.get("authority", {}).get("entity") == file_id]
        assert [frame["authority"]["state"] for frame in frames] == ["private", "shared", "private"]
        assert view["health"]["errors"] == 0 and view["health"]["dropped"] == 0
        step("actual_revocation_and_private_state_captured", {"states": ["private", "shared", "private"]})
        stopped = graph.request.post(args.graph + "/api/recordings/stop", data={})
        assert stopped.ok, stopped.text()
        record = stopped.json()
        assert record["events"] > 0 and not record["gaps"]
        (output / "recording-stop.json").write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
        replay = contexts[3].new_page()
        replay.set_viewport_size({"width": 1920, "height": 1440})
        replay.on("pageerror", lambda error: errors.append(str(error)))
        replay.on("console", lambda message: errors.append(message.text) if message.type == "error" else None)
        replay.goto(args.graph + "/graph")
        replay.wait_for_function("build => !document.querySelector('#connection').textContent.includes('暂时无法连接') && document.querySelector('#binding').textContent.includes(build)", arg=build_id[:8], timeout=75000)
        replay.locator(f'#record-list option[value="{record["id"]}"]').wait_for(state="attached", timeout=75000)
        replay.locator("#record-list").select_option(record["id"])
        replay.locator("#replay").wait_for(state="visible")
        replay.locator("#replay-next").click()
        assert replay.locator("#replay-position").inner_text()
        options = replay.locator("#replay-events option").evaluate_all("items => items.map(item => ({value: item.value, label: item.textContent}))")
        revoke_option = next(item for item in options if "Revoke recipient access" in item["label"])
        replay.locator("#replay-events").select_option(revoke_option["value"])
        checks["revocation_step_selected_in_replay"] = True
        screenshot(replay, "07-revocation-replay")
        checks["recording_replayed"] = True
        step("recording_stopped_and_replayed", {"recording_id": record["id"], "events": record["events"]})
        final_health = graph.request.get(args.graph + "/api/bo/health").json()
        assert final_health["build_id"] == build_id and final_health["binding"]["status"] == "current"
        preferences = graph.request.get(args.graph + "/api/preferences")
        assert preferences.ok and preferences.json()["project_id"] == project["project_id"]
        assert not errors, errors
        report = {"valid": True, "headless": True, "browser": browser.version, "build_id_before": build_id,
            "build_id_after": final_health["build_id"], "steps": steps, "checks": checks,
            "screenshots": screenshots, "file_id": file_id, "before": before, "after": after,
            "recording": record, "page_errors": errors, "application": args.url, "graph": args.graph}
        (output / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(json.dumps({"valid": True, "build_id": build_id, "steps": len(steps), "screenshots": len(screenshots), "recording_events": record["events"]}))
        browser.close()


if __name__ == "__main__":
    main()
