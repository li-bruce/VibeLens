"""Execute real requests and compare SQLite facts with the public graph export."""

from copy import deepcopy
import json
from pathlib import Path
import sys
import tempfile
from itertools import product
ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "observer_runtime"), str(ROOT / "tooling")]
from app.web import create_app
from bo_stategraph import BOStateGraph
from bo_stategraph.workflow import machine_snapshot
from bo_observer.graph.behavior_model import capture
from bo_observer.protocol import validate_event, validate_snapshot
from integrations.bo_adapter import BOTrace
from scenarios import run_workflow, run_revocation


def main():
    project = json.loads((ROOT / "bo_stategraph/project.json").read_text(encoding="utf-8"))
    model = project["model"]
    build_id = capture(ROOT, model)["build_id"]
    runs, witnesses = [], []
    selected_export = None
    (ROOT / "review/tmp").mkdir(parents=True, exist_ok=True)
    scenarios = {"workflow": run_workflow, "revocation": run_revocation}
    for case, mode in product(scenarios, ["on", "off", "fault"]):
        scenario = scenarios[case]
        with tempfile.TemporaryDirectory(prefix="sharing-acceptance-", dir=ROOT / "review/tmp") as directory:
            trace = BOTrace(ROOT, mode=mode, capacity=4096,
                sink=lambda value, kind: validate_event(value, project, build_id) if kind == "events" else validate_snapshot(value, project, build_id))
            app = create_app(ROOT, Path(directory) / "trial.sqlite3", bo_trace=trace, bo_data=trace.data)
            observations, file_id = scenario(app)
            trace.close()
            rows = app.extensions["sharing"].store.snapshots()
            actual = [{**row, "build_id": build_id} for row in rows]
            machine = machine_snapshot(rows, build_id)
            graph = BOStateGraph(model, build_id=build_id, mode="drive", instance_provider=lambda: machine_snapshot(app.extensions["sharing"].store.snapshots(), build_id))
            graph.bo_require_definition(app.extensions["sharing"].workflow.executor.bo_definition)
            instances = graph.bo_instances()
            public = graph.bo_export(runtime={"machine": machine})
            for row in actual:
                observed = next(item["observed"] for item in instances if item["observed"]["instance_id"] == row["id"])
                witnesses.extend([{"id": f"{case}:{mode}:{row['id']}:{field}", "source": "SQLite independent materialized read", "projection": "BOStateGraph.bo_instances." + field, "actual": row[field], "mapped": observed[field]} for field in ["state", "revision", "build_id"]])
            runs.append({"case": case, "mode": mode, "events": trace.events,
                "state_snapshots": trace.snapshots,
                "policy_evaluations": trace.evaluations, "observations": observations,
                "authority_snapshot": {"files": actual}, "projection": {"build_id": build_id, "machine": machine, "instances": instances},
                "observer": {"errors": trace.errors, "transport_errors": trace.probe.bo_errors, "dropped": trace.probe.bo_dropped, "data_errors": trace.data.bo_errors, "rejections": trace.rejections}})
            if mode == "on" and case == "workflow":
                selected_export = public
            app.extensions["sharing"].store.engine.dispose()
    payload = {"build_id": build_id, "machine": model["machine"], "runs": runs, "mapping_checks": witnesses, "stategraph_export": selected_export}
    (ROOT / "review/runtime-observations.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload, ensure_ascii=False))


if __name__ == "__main__":
    main()
