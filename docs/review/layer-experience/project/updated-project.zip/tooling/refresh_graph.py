"""Refresh managed data projection and the static source slice without accepting a change."""
import json
import os
from pathlib import Path
import subprocess
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "observer_runtime")]
from bo_observer.graph.code_structure import scan, enrich
from bo_observer.data.sync import synchronize
os.environ.setdefault("FILE_SHARING_DB_URL", "sqlite:///data/sharing.sqlite3")
report = synchronize(ROOT)
if not report["valid"]:
    raise ValueError(report)
path = ROOT / "bo_stategraph/project.json"
project = json.loads(path.read_text(encoding="utf-8"))
cfg = json.loads((ROOT / "sync.json").read_text(encoding="utf-8"))
project["model"] = enrich(project["model"], scan(ROOT, cfg["code_files"]), 1)
path.write_text(json.dumps(project, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
(ROOT / "behavior.json").write_text(json.dumps(project["model"], ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"valid": True, "nodes": len(project["model"]["nodes"]), "database": report}))
