"""Reproducible connected verification entrypoint; preserves the active change baseline."""

import json
import os
from pathlib import Path
import subprocess
import sys
import time
import shutil
ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault("PYTHONUTF8", "1")
os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")
os.environ.setdefault("FILE_SHARING_DB_URL", "sqlite:///data/sharing.sqlite3")
SKILL = Path((ROOT / "tooling/skill-path.txt").read_text(encoding="utf-8").strip())


def run(name, args):
    started = time.perf_counter()
    result = subprocess.run([sys.executable, "-B", "-X", "utf8", *args], cwd=ROOT, capture_output=True, text=True, encoding="utf-8")
    path = ROOT / "review" / name
    if path.exists():
        active = json.loads((ROOT / ".stategraph/active.json").read_text(encoding="utf-8"))["change"]
        scope_name = "iteration-02-revoke" if Path(active).name == "revoke-v2" else Path(active).name
        if scope_name == "diagnosis-03":
            scope_name = "diagnosis"
        history = ROOT / "review" / scope_name / "history"
        history.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, history / (str(time.time_ns()) + "-" + name))
    path.write_text(json.dumps({"argv": args, "returncode": result.returncode, "duration_seconds": time.perf_counter() - started, "stdout": result.stdout, "stderr": result.stderr}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(name, result.returncode)
    if result.returncode:
        print(result.stdout[-14000:])
        print(result.stderr[-4000:])
        raise SystemExit(result.returncode)
    return result


def main():
    run("source-sync.json", [str(SKILL / "scripts/bo_sync.py"), "scan", "--root", str(ROOT)])
    run("change-inspect.json", [str(SKILL / "scripts/change_sync.py"), "inspect", "--root", str(ROOT)])
    run("change-verify.json", [str(SKILL / "scripts/change_sync.py"), "verify", "--root", str(ROOT)])
    run("change-accept.json", [str(SKILL / "scripts/change_sync.py"), "accept", "--root", str(ROOT)])
    run("change-check.json", [str(SKILL / "scripts/change_sync.py"), "check", "--root", str(ROOT)])


if __name__ == "__main__":
    main()
