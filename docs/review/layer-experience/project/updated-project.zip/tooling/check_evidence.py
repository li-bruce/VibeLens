"""Check real state witnesses and rejection of incomplete evidence in isolated copies."""
from contextlib import closing
from copy import deepcopy
import json
import os
from pathlib import Path
import sqlite3
import sys
import tempfile
ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "observer_runtime")]
from bo_observer.protocol import validate_project
from bo_observer.workflow.mapping_contract import assess
from bo_observer.data.catalog import collect
from bo_observer.data.schema_compare import structure_differences
from app.storage import Store


def assert_transition_witnesses(run):
    expected = {(row["id"], entry["seq"]): entry
        for row in run["authority_snapshot"]["files"] for entry in row["journal"]}
    snapshots = {(item["instance_id"], item["revision"]): item for item in run["state_snapshots"]}
    assert len(snapshots) == len(run["state_snapshots"]), "duplicate_state_snapshot"
    assert set(snapshots) == set(expected), "missing_or_extra_transition_witness"
    events = {event["id"]: event for event in run["events"]}
    for key, snapshot in snapshots.items():
        entry = expected[key]
        event = events[snapshot["evidence_id"]]
        assert event["revision"] == snapshot["revision"] == entry["seq"]
        assert snapshot["event"] == entry["event"] and snapshot["state"] == entry["after"]
        assert snapshot["guards"] == entry["guards"] and snapshot["guards"]["operation_allowed"] is True
        if snapshot["event"] == "revoke":
            assert snapshot["guards"]["has_recipients"] == (snapshot["context"]["grant_count"] > 0)


def main():
    payload = json.loads((ROOT / "review/runtime-observations.json").read_text(encoding="utf-8"))
    project = json.loads((ROOT / "bo_stategraph/project.json").read_text(encoding="utf-8"))
    model = project["model"]
    plan = json.loads((ROOT / "mapping.json").read_text(encoding="utf-8"))
    kwargs = {"required": True, "plan": plan, "model": model, "build_id": payload["build_id"]}
    assert assess(payload, **kwargs)["valid"]
    results = []
    for name in ["missing_instance", "missing_owner", "stale_revision", "fewer_modes", "disconnected_export"]:
        candidate = deepcopy(payload)
        if name == "missing_instance":
            candidate["stategraph_export"]["instances"] = []
        elif name == "missing_owner":
            del candidate["runs"][0]["projection"]["instances"][0]["observed"]["context"]["owner_id"]
        elif name == "stale_revision":
            candidate["runs"][0]["projection"]["instances"][0]["observed"]["revision"] -= 1
        elif name == "fewer_modes":
            candidate["runs"].pop()
        else:
            candidate["stategraph_export"]["runtime"]["machine"]["configurations"] = []
        assert not assess(candidate, **kwargs)["valid"], name
        results.append({"check": name, "rejected": True})
    observed = payload["runs"][0]
    assert observed["observer"]["transport_errors"] == 0
    events = {event["id"]: event for event in observed["events"]}
    snapshots = observed["state_snapshots"]
    assert len(snapshots) == 2
    assert [(item["event"], item["state"]) for item in snapshots] == [("upload", "private"), ("share", "shared")]
    for snapshot in snapshots:
        event = events[snapshot["evidence_id"]]
        assert event["revision"] == snapshot["revision"]
        assert snapshot["guards"] == {"operation_allowed": True}
        journal = snapshot["configuration"]["journal"]
        assert journal[-1]["event"] == snapshot["event"] and journal[-1]["after"] == snapshot["state"]
    results.append({"check": "native_transition_event_snapshot_journal_agree", "passed": True})
    revoked = next(run for run in payload["runs"] if run["case"] == "revocation" and run["mode"] == "on")
    assert revoked["observer"]["transport_errors"] == 0
    assert_transition_witnesses(revoked)
    branches = {item["state"] for item in revoked["state_snapshots"] if item["event"] == "revoke"}
    assert branches == {"private", "shared"}
    results.append({"check": "revocation_transition_journal_and_both_branches_agree", "passed": True})
    omitted = deepcopy(revoked)
    removed = next(item for item in omitted["state_snapshots"] if item["event"] == "revoke")
    omitted["state_snapshots"].remove(removed)
    try:
        assert_transition_witnesses(omitted)
    except AssertionError as error:
        results.append({"check": "missing_revocation_transition_witness_rejected", "passed": True, "diagnostic": str(error)})
    else:
        raise AssertionError("missing_revocation_witness_was_accepted")
    broken = deepcopy(project)
    broken["model"]["edges"].append({"id": "unsupported_map", "from": "owner", "to": "recipient", "type": "maps", "label": "Invalid", "evidence": "Negative protocol input only"})
    try:
        validate_project(broken)
    except ValueError:
        results.append({"check": "arbitrary_maps_relation_rejected", "passed": True})
    else:
        raise AssertionError("arbitrary_maps_relation_was_accepted")
    with tempfile.TemporaryDirectory(prefix="schema-check-", dir=ROOT / "review/tmp") as directory:
        path = Path(directory) / "schema.sqlite3"
        store = Store(path)
        store.initialize()
        store.engine.dispose()
        os.environ["FILE_SHARING_SCHEMA_CHECK_URL"] = "sqlite:///" + str(path)
        spec = {"id": "sharing", "engine": "sqlalchemy", "url_env": "FILE_SHARING_SCHEMA_CHECK_URL"}
        before = collect(spec, root=ROOT)
        with closing(sqlite3.connect(path)) as connection:
            connection.execute("ALTER TABLE files ADD COLUMN schema_check_marker TEXT")
            connection.commit()
        after = collect(spec, root=ROOT)
        assert before != after
        old_fields = {field["name"] for resource in before["resources"] if resource["key"] == "table:files" for field in resource["fields"]}
        new_fields = {field["name"] for resource in after["resources"] if resource["key"] == "table:files" for field in resource["fields"]}
        assert "schema_check_marker" not in old_fields and "schema_check_marker" in new_fields
        results.append({"check": "real_isolated_schema_change_detected", "passed": True})
    report = {"valid": True, "build_id": payload["build_id"], "checks": results,
        "scope": "Negative evidence copies and protocol inputs only; application source and accepted business expectations are not mutated."}
    (ROOT / "review/evidence-checks.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report))


if __name__ == "__main__":
    main()
