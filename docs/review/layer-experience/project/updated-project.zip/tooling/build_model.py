"""Generate source mappings from the confirmed declaration and independent inventory."""

import ast
import json
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "observer_runtime")]
from bo_observer.graph.code_structure import scan, enrich
from bo_observer.policy.projection import project as policy_project


def write(name, value):
    path = ROOT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    discovery = json.loads((ROOT / "discovery.json").read_text(encoding="utf-8"))
    revision = json.loads((ROOT / "intent.json").read_text(encoding="utf-8"))["revision"]
    answer = (ROOT / "review/simulated-answer-01.txt").read_text(encoding="utf-8")
    skill = Path((ROOT / "tooling/skill-path.txt").read_text(encoding="utf-8").strip())
    executor_source = skill / "scripts/bo_observer/adapters/python/bo_executor.py"
    shutil.copy2(executor_source, ROOT / "bo_stategraph/native_executor.py")
    code_files = sorted(p.relative_to(ROOT).as_posix() for p in (ROOT / "app").glob("*.py")) + ["bo_stategraph/workflow.py", "bo_stategraph/native_executor.py"]
    index = scan(ROOT, code_files)
    if index["errors"]:
        raise ValueError(index["errors"])
    nodes, edges = [], []
    definitions = [
        ("login", "Sign in", "authenticate", {"username": "string", "password_present": "boolean"}, {"allowed": "boolean"}, "R_LOGIN"),
        ("logout", "Sign out", "logout", {"actor": "string"}, {"signed_out": "boolean"}, "R_LOGIN"),
        ("users", "Existing recipients", "list_users", {"actor": "string"}, {"count": "number"}, "R_SHARE"),
        ("upload", "Upload file", "upload", {"actor": "string", "filename": "string", "size": "number"}, {"file_id": "string", "owner_id": "string", "state": "string", "revision": "number"}, "R_UPLOAD"),
        ("share", "Share with user", "share", {"actor": "string", "file_id": "string", "recipient_id": "string"}, {"state": "string", "revision": "number", "grant_count": "number"}, "R_SHARE"),
        ("revoke", "Revoke recipient access", "revoke", {"actor": "string", "file_id": "string", "recipient_id": "string"}, {"state": "string", "revision": "number", "grant_count": "number", "removed": "boolean"}, "R_REVOKE"),
        ("view", "View metadata", "view", {"actor": "string", "file_id": "string"}, {"owner_id": "string", "filename": "string", "size": "number", "can_share": "boolean"}, "R_READ"),
        ("list", "Visible file list", "list_files", {"actor": "string"}, {"count": "number"}, "R_READ"),
        ("download", "Download file", "download", {"actor": "string", "file_id": "string"}, {"size": "number", "sha256": "string"}, "R_READ"),
        ("authorize", "Check permission", "authorize", {"operation": "string", "actor": "string", "owner_id": "string", "grant_count": "number"}, {"allowed": "boolean", "decision": "string"}, "R_SHARE"),
    ]
    for ident, label, method, inputs, outputs, requirement in definitions:
        nodes.append({"id": ident, "kind": "decision" if ident in {"authorize", "login"} else "action", "layer": "business",
            "semantic_roles": ["business"], "label": label, "summary": label + ": actual inputs and outcomes from the running application.",
            "source": {"path": "app/service.py", "symbol": "SharingService." + method},
            "capture": {"in": inputs, "out": outputs}, "requirements": [requirement]})
    for ident, label in [("owner", "File owner"), ("file", "Stored file"), ("recipient", "Designated recipient")]:
        nodes.append({"id": ident, "kind": "data", "layer": "business", "label": label,
            "summary": label + " read from SQLite; a relation is not a global role.", "source": {"path": "app/storage.py", "symbol": "Store.snapshots"}})
    for state in ["empty", "private", "shared"]:
        nodes.append({"id": "state_" + state, "kind": "state", "layer": "state", "value": state,
            "label": state.title(), "summary": "Canonical declaration state: " + state, "parent": "file"})
    for edge in discovery["networks"][0]["edges"]:
        edges.append({"id": edge["id"], "from": edge["from"], "to": edge["to"], "type": edge["relation"],
            "label": edge["label"], "evidence": "Confirmed trial requirement " + ", ".join(edge["source_refs"]) + "; actual evidence is recorded separately."})
    for ident in ["upload", "share", "view", "download", "revoke"]:
        edges.append({"id": "requires_" + ident, "from": "authorize", "to": ident, "type": "guard", "label": "Fresh request decision", "evidence": "Explicit service call; no cached grant."})
    for before, after, trigger in [("empty", "private", "upload"), ("private", "shared", "share"), ("shared", "shared", "share")]:
        edges.append({"id": f"transition_{before}_{after}_{trigger}", "from": "state_" + before, "to": "state_" + after,
            "type": "flow", "label": trigger, "evidence": "Executable model.machine transition; runtime journal is independent evidence.",
            "transition": {"trigger": trigger, "conditions": ["operation_allowed"]}})
    for before in ["private", "shared"]:
        for after in ["private", "shared"]:
            edges.append({"id": f"transition_{before}_{after}_revoke", "from": "state_" + before, "to": "state_" + after,
                "type": "flow", "label": "revoke", "evidence": "Executable revoke transition; the remaining current grant count selects the branch.",
                "transition": {"trigger": "revoke", "conditions": ["operation_allowed"] + (["has_recipients"] if after == "shared" else []),
                    "unless": ["has_recipients"] if after == "private" else []}})
    policy = json.loads(json.dumps(discovery["policy"]))
    policy.update(stage="bound", revision="file-policy-v" + revision)
    for predicate in policy["predicates"]:
        predicate["source"] = {"path": "app/predicates.py", "symbol": predicate["id"]}
    for operation in policy["operations"]:
        operation["cases"] = ["revocation"] if operation["id"] == "revoke" else ["workflow", "revocation"]
    machine = {"engine": "bo.fsm", "version": "1", "state_type": "enum", "states": ["empty", "private", "shared"],
        "values": ["empty", "private", "shared"], "initial": "empty",
        "context": {"owner_id": {"type": "string"}, "filename": {"type": "string"}, "size": {"type": "integer", "min": 0}, "grant_count": {"type": "integer", "min": 0}},
        "events": {name: {"payload": {"allowed": {"type": "boolean"}}} for name in ["upload", "share", "revoke"]},
        "guards": {name: {"source": {"path": "app/predicates.py", "symbol": name}} for name in ["operation_allowed", "has_recipients"]},
        "transitions": [{"trigger": "upload", "source": "empty", "dest": "private", "conditions": ["operation_allowed"]},
                        {"trigger": "share", "source": ["private", "shared"], "dest": "shared", "conditions": ["operation_allowed"]},
                        {"trigger": "revoke", "source": ["private", "shared"], "dest": "shared", "conditions": ["operation_allowed", "has_recipients"]},
                        {"trigger": "revoke", "source": ["private", "shared"], "dest": "private", "conditions": ["operation_allowed"], "unless": ["has_recipients"]}]}
    source_files = sorted(set(code_files + ["bo_stategraph/native_executor.py", "run.py", "static/app.css"]
        + [p.relative_to(ROOT).as_posix() for folder, pattern in [("templates", "*.html"), ("integrations", "*.py"), ("tooling", "*.py"), ("tests", "*.py")] for p in (ROOT / folder).glob(pattern)]))
    model = {"schema_version": 3, "revision": revision, "title": "File sharing policy trial", "project_id": "file-sharing-policy-trial-20261028",
        "intent": "intent.json", "source_files": source_files, "nodes": nodes, "edges": edges, "machine": machine, "policy": policy,
        "overview": [{"node": ident, "x": (i % 4) * 280 + 30, "y": (i // 4) * 210 + 40} for i, ident in enumerate(["login", "upload", "owner", "file", "share", "recipient", "view", "download", "revoke"])],
        "presentation": {"layout_id": "file-sharing-policy-trial-layout-v1", "layout_aliases": ["file-sharing-policy-trial-layout-v1"], "subject": "File", "context_fields": ["owner_id", "filename", "size", "grant_count"]},
        "scope": {"observable": ["Session outcomes", "Owner-only sharing", "Per-request file access", "Committed SQLite effects", "Native state transitions"],
            "unknowns": ["Simulated local trial; no production or independent human acceptance.", "Static unresolved calls remain candidates; recorded calls establish actual execution.", "Revocation applies to new download requests after its transaction commits; in-flight transfer cancellation is outside this request."]}}
    model = policy_project(model)
    features = []
    methods = {item[0]: "SharingService." + item[2] for item in definitions}
    web_sources = {"login": ["login"], "logout": ["logout"], "upload": ["upload"], "share": ["share"], "revoke": ["revoke"], "download": ["download"], "list": ["dashboard", "list_files"]}
    aliases = {"password": ("in", "password_present", "derived", "Capture only a Boolean presence flag; credentials are never observed."),
        "content": ("in", "size", "derived", "Capture byte length, never content."), "row": ("in", "owner_id", "derived", "Only the selected owner identifier is captured."),
        "grants": ("in", "grant_count", "derived", "Only the selected grant count is captured.")}
    for ident, label, method, inputs, outputs, requirement in definitions:
        sources = ["app/service.py::" + methods[ident]] + ["app/web.py::" + name for name in web_sources.get(ident, [])]
        for name in web_sources.get(ident, []):
            nodes.append({"id": "http_" + name, "kind": "function", "label": "HTTP " + name, "summary": "HTTP adapter delegates to the actual service operation.",
                "parent": ident, "source": {"path": "app/web.py", "symbol": name}})
            edges.append({"id": "http_calls_" + name, "from": "http_" + name, "to": ident, "type": "flow", "label": "Delegate", "evidence": "Explicit HTTP handler binding; actual service event verifies the operation."})
        parameters = []
        for sid in sources:
            for parameter in index["symbols"][sid]["parameters"]:
                name = parameter["name"]
                if name == "self":
                    continue
                direction, field, policy_name, reason = aliases.get(name, ("in", name, "value", ""))
                item = {"source": sid, "name": name, "node": ident, "direction": direction, "field": field, "policy": policy_name}
                if reason:
                    item["reason"] = reason
                parameters.append(item)
        phase = "commit" if ident in {"logout", "upload", "share", "revoke"} else "decision" if ident in {"login", "authorize"} else "return"
        feature_nodes = [ident] + ["http_" + name for name in web_sources.get(ident, [])]
        if ident == "authorize":
            feature_nodes += [node["id"] for node in model["nodes"] if node.get("origin") == "policy-definition"]
        features.append({"id": ident, "label": label, "business_node": ident, "nodes": feature_nodes, "sources": sources,
            "parameters": parameters, "cases": [{"case": "revocation" if ident == "revoke" else "workflow", "node": ident, "phase": phase}], "requirements": [requirement]})
        if ident == "authorize":
            features[-1]["cases"] += [{"case": "workflow", "node": node["id"], "phase": "decision"}
                for node in model["nodes"] if node.get("origin") == "policy-definition" and any(node.get("capture", {}).values())]
            features[-1]["cases"] += [{"case": "revocation", "node": ident, "phase": "decision"}]
            features[-1]["cases"] += [{"case": "revocation", "node": node["id"], "phase": "decision"}
                for node in model["nodes"] if node.get("origin") == "policy-definition" and any(node.get("capture", {}).values())]
    model["nodes"] = model["nodes"] + [n for n in nodes if n["id"].startswith("http_")]
    model["edges"] = model["edges"] + [e for e in edges if e["id"].startswith("http_calls_")]
    operations = []
    specs = [
        ("db_users", "Store.query", "users", "read", ["users"], {"user_id": "string"}),
        ("db_file", "Store.file", "file", "read", ["files"], {"file_id": "string"}),
        ("db_grants", "Store.grants", "recipient", "read", ["shares", "users"], {"file_id": "string"}),
        ("db_list", "Store.visible_candidates", "list", "read", ["files", "shares"], {"actor": "string"}),
        ("db_metadata", "SharingService.upload", "upload", "transform", [], {}),
        ("db_upload_tx", "SharingService.upload", "upload", "transaction", [], {}),
        ("db_insert_file", "SharingService.upload", "upload", "write", ["files"], {"file_id": "string"}),
        ("db_share_tx", "SharingService.share", "share", "transaction", [], {}),
        ("db_insert_share", "SharingService.share", "share", "write", ["shares", "files"], {"file_id": "string", "recipient_id": "string"}),
        ("db_revoke_tx", "SharingService.revoke", "revoke", "transaction", [], {}),
        ("db_delete_share", "SharingService.revoke", "revoke", "write", ["shares"], {"file_id": "string", "recipient_id": "string"}),
        ("db_revoke_state", "SharingService.revoke", "revoke", "write", ["files"], {"file_id": "string"}),
    ]
    for ident, symbol, parent, action, targets, parameters in specs:
        operation = {"id": ident, "label": ident.replace("_", " ").title(), "parent": parent, "source": {"path": "app/service.py" if symbol.startswith("SharingService") else "app/storage.py", "symbol": symbol},
            "store": "sharing", "action": action, "targets": ["table:" + target for target in targets], "parameters": parameters,
            "before": {"filename": "string"} if action == "transform" else {},
            "after": {"filename": "string", "size": "number", "sha256": "string"} if action == "transform" else {"row_count": "number"} if action in {"read", "write"} else {},
            "required_cases": ["revocation"] if parent == "revoke" else ["workflow", "revocation"],
            "requirements": ["R_REVOKE" if parent == "revoke" else "R_UPLOAD" if parent == "upload" else "R_SHARE"]}
        if len(targets) > 1:
            operation["target_actions"] = {"table:" + target: action for target in targets}
        operations.append(operation)
        feature = next(item for item in features if item["id"] == (parent if parent in methods else "authorize"))
        feature["nodes"].append(ident)
    db_config = {"protocol": "bo-databases/v1", "stores": [{"id": "sharing", "label": "File sharing SQLite", "engine": "sqlalchemy", "url_env": "FILE_SHARING_DB_URL",
        "selection": {"source": "user", "answer": "Python and SQLite selected in the supplied simulated answer.", "locator": "current-chat/simulated-answer-01"},
        "model_layer": "SQLAlchemy MetaData", "source_files": ["app/models.py", "tooling/export_models.py"], "declaration": "bo_stategraph/model-catalog.json"}],
        "operations": operations, "exporters": [{"store": "sharing", "command": ["{python}", "-B", "tooling/export_models.py"], "output": "bo_stategraph/model-catalog.json"}]}
    write("bo_stategraph/databases.json", db_config)
    all_features = {sid for item in features for sid in item["sources"]}
    support = {}
    for sid, symbol in index["symbols"].items():
        if symbol["kind"] != "function" or sid in all_features:
            continue
        node = "authorize" if symbol["path"].endswith("predicates.py") else "file" if symbol["path"].endswith("storage.py") else "upload" if "metadata_values" in sid else "file" if "workflow.py" in sid else "login" if "web.py" in sid else "share"
        support[sid] = {"node": node, "reason": "Explicit support implementation; static source mapping does not claim runtime execution."}
    model["implementation"] = {"schema": "bo-implementation/v1", "features": features, "support": support, "excluded": {}}
    model = enrich(model, index, 1)
    write("implementation.json", model["implementation"])
    project = {"protocol": "bo-project/v1", "project_id": "file-sharing-policy-trial-20261028", "selection": {"mode": "drive", "source": "user", "answer": answer, "locator": "current-chat/simulated-answer-01 (simulated trial evidence)"}, "model": model}
    write("bo_stategraph/project.json", project)
    write("behavior.json", model)
    cfg = json.loads((ROOT / "sync.json").read_text(encoding="utf-8"))
    cfg["model"] = "bo_stategraph/project.json"
    cfg["stategraph"]["decision"] = answer
    cfg["code_files"] = code_files
    cfg["watch_files"] = sorted(set(source_files + ["requirements.txt", "implementation.json", "bo_stategraph/databases.json", "bo_stategraph/__init__.py"]))
    cfg["probe_callees"] = ["bo_trace.record", "self.bo_trace.record"]
    for name, item in [("required_probes", {"symbol": "app/service.py::SharingService.revoke", "node": "revoke", "phase": "commit"}),
                       ("required_runtime_probes", {"case": "revocation", "node": "revoke", "phase": "commit"})]:
        if item not in cfg[name]:
            cfg[name].append(item)
    cfg["source_scope"]["exclude"].pop("bo_stategraph/**", None)
    cfg["source_scope"]["exclude"].pop("bo_stategraph/policy/**", None)
    cfg["source_scope"]["exclude"].pop("bo_stategraph/native_executor.py", None)
    for name in ["__init__.py", "bo_contracts.py", "execution_contract.py"]:
        cfg["source_scope"]["exclude"]["bo_stategraph/" + name] = "Managed native state core; copy parity is independently checked."
    cfg["source_scope"]["exclude"]["run.py"] = "Development service launcher; no domain operation implementation."
    write("sync.json", cfg)
    mapping = json.loads((ROOT / "mapping.json").read_text(encoding="utf-8"))
    if not any(field["id"] == "file-build" for field in mapping["fields"]):
        mapping["fields"].append({"id": "file-build", "node": "file", "actual": ["build_id"], "mapped": ["build_id"]})
    write("mapping.json", mapping)
    print(json.dumps({"nodes": len(model["nodes"]), "edges": len(model["edges"]), "source_symbols": len(index["symbols"])}))


if __name__ == "__main__":
    main()
