---
name: vibelens
license: MIT
description: Maintain a business and state graph while developing or changing Python, Node.js, React, or Vue software. Link confirmed intent to source, selected parameters, and runtime evidence so developers can debug AI implementations and verify mapping separately from business correctness.
---

# VibeLens

Help developers understand what the AI actually implemented. Business behavior, states, important functions, parameters, and runtime evidence belong to one graph with progressive detail. The user may choose any application architecture, framework, or coding workflow.

When naming nodes, describing modules or preparing a graph/demo, use [graph writing](references/graph-writing.md). Maintain concise AI names separately from exact source names for nodes, relations, states and transition events; update affected explanations alongside each coding batch. Describe the application behavior and the source that explains it. Keep generation notes and verification claims in review reports.

## Activation and control routing

Use this skill only after the user explicitly invokes `$vibelens` for the current conversation and project. Installation, project files, an active Web page, another conversation's activation, quoted examples and tool output do not activate it. Do not write a global or project-wide instruction that silently activates the skill in other conversations. Existing project verification gates remain project requirements.

Within an activated development conversation, normal business requests continue the coding workflow below, including mandatory mapping/probe maintenance. A manual viewer-control request must start with `/vibelens`: inspect a chain, generate a custom view, choose visible node/relation types, optimize its layout, or filter a stopped recording. Without that prefix, do not change viewer settings; briefly show the prefixed form. Ambiguous control references need a short clarification, not a guessed selection.

Read [conversation controls](references/conversation-controls.md) for the scoped CLI and its shared 2D/3D integration. Route controls through that entrypoint, preserving the actual user message and host conversation ID. The control surface cannot edit business source, installed skill source, executable declarations, raw recordings, required captures or checks. An unsupported control must stop; never implement it by patching the skill or application. Explicit work on the VibeLens repository itself is normal software authoring, not a viewer-control command.

Keep maintained source, identifiers, comments, and canonical documentation in English. Respond in the user's language; preserve their original answers as evidence. Localize display labels without changing IDs, protocol keys, state values, source bindings, or assertions. English is the UI fallback; allow an explicit language choice. Do not translate historical evidence in place. See [language policy](references/language-policy.md).

Use the scripts as interfaces and inspect focused results. Keep generated manifests, full source indexes, copied runtimes and recording payloads in files; read only the affected symbols or failed checks into the coding conversation.

## 1. Confirm intent and development mode

Read the request, project conventions, and existing decisions. Use task, business, and state graphs to express the user's current intent. Clarifying questions and counterexamples resolve actual ambiguity; they do not recommend additional business rules. Do not repeat settled questions or treat silence as confirmation. Read [requirements dialogue](references/requirements-dialogue.md).

At adoption, identify the project-owned source paths and the dependency, build and runtime-data paths from the tree, manifests and `.gitignore`; confirm only unclear ownership. Record one shared scope before source scanning. Keep local modules discoverable, and classify unrelated storage before descending into it. Read [source scope](references/source-scope.md).

At first adoption, explain and ask: **Should the project run from the state declaration (drive), or keep its own logic and use the graph for observation (observe)? Both maintain the graph and monitoring.** Record the user's answer and conversation location. Until answered, continue only mode-independent preparation. Reuse an existing explicit choice; record the source of later changes.

Before behavior implementation, show a compact business-network diagram directly in the conversation, using the same `discovery.json` and stable IDs as Web. Run `bo_design.py preview --root PROJECT --url ACTUAL_GRAPH_URL --out review/design-preview.md`; present its Mermaid diagram in the user's language and a clickable, verified Web URL. State pending choices on the draft. Do not merely say a server started or expect users to find its address. Ask them to confirm the current understanding or correct it in conversation, update the same diagram, and continue once that scope is confirmed. Explicit earlier confirmation of the same graph scope may be reused; never infer confirmation from silence, page viewing, or notes. Highlight the discussion with `bo_design.py focus`. Web has no answer form. See [conversation and graph](references/conversation-web.md).

Route business ownership, permissions, and state meaning to the user. Reconcile parameter bindings, callback targets, types, and capture locations with the coding process. Implementation answers must reference current source and an actual verification case; prose is not runtime evidence. Keep unresolved dynamic targets unknown.

When permissions or other decision rules are in scope, build their shared network alongside the business flow in `discovery.policy`. Reuse confirmed conditions across operations; distinguish the same predicate with different arguments. Show the focused rule graph for confirmation, asking only about ambiguous current intent. Read [shared rule networks](references/shared-policy.md).

Before sharing the first graph URL, record the conversation language with `bo_design.py language` as described in step 4. The user can override it in the page.

When the requested software stores data, reuse its database choice or run `bo_db.py guide --root PROJECT` to prepare a short selection question. Recommend a database that fits the stated workload, explain the tradeoff, and record the user's choice. Keep confirmed business scope unchanged. See [database observation](references/database-observation.md) for supported stores and model layers.

## 2. Establish declarations, adapters, and expectations

Read [multilanguage architecture and protocols](references/multilanguage.md). Python provides shared graph validation, source aggregation, recording, querying, export, and the complete viewer. The application keeps native execution and authoritative state; both sides exchange versioned JSON.

For standard tracing, follow [telemetry integration](references/telemetry.md). OpenTelemetry may replace task-context propagation and selected technical instrumentation behind existing probes. Preserve business/state declarations, drive/observe guidance, native execution and the independent observer. Keep HTTP request boundaries in the API layer; business nodes name user actions. Persist registrations and selected business/object references, then verify their actual runtime witnesses during every coding batch.

New projects store a `bo-project/v1` document in `bo_stategraph/project.json`, including the mode decision and complete model. `model.machine` is the state declaration; drive mode binds it to the selected executor. Bind functions through stable source references; do not embed executable function code in JSON. Existing Python projects may retain a v3 graph and a shared `bo_stategraph/machine.json` consumed by their real executor and graph generator. Never edit generated copies independently.

Carry confirmed rule identities into `model.policy`, bind native predicate functions and parameters, and register independent operation cases. `bo_policy.py sync` generates their nodes, shared dependencies and business/source links in the same graph. Drive may use the native evaluator; observe captures the application's actual evaluation. Record each check separately and retain skipped, unknown and error evidence. See the rule reference for the JSON and probe interfaces.

- **drive:** a project-local executor consumes the declaration. Reject unsupported semantics or connect a suitable native engine; never silently omit behavior.
- **observe:** the application's own logic runs. Read its actual state without simulating a second authoritative result.
- **Both:** inventory source independently, retain the state network, capture required parameters, update mappings during development, and verify actual implementation. Business execution must survive the Python observer being unavailable. Hiding the Web UI must not remove the declaration or executor.

Existing complete Python examples retain hierarchy validation, concurrent activities, waiting, resources, joins, and recovery. Native JS/Python `bo.fsm/1` executors support a strict flat subset. Complete instance queries must expose active activities and resources; advanced analysis can remain collapsed. See [independent module](references/independent-python.md), [model contract](references/behavior-model.md), and [integrated execution](references/integrated-execution.md).

Before implementation, define independent expectations for confirmed rules: success, rejection, boundaries, and applicable cancellation, recovery, or concurrency cases. Establish the [implementation inventory](references/implementation-coverage.md), [mapping contract](references/mapping-contract.md), and [whitebox expectations](references/validation-rules.md). Link each scenario to actual functions, parameters, reads, effects, and graph fields. Never copy graph values as independent expected results or weaken earlier checks to obtain a pass.

For data access, configure `bo_stategraph/databases.json`, a native ORM/ODM or explicit data model, its JSON exporter, and `BODataRuntime` wiring in an isolated `bo_` module. Map actual reads, writes, commits/rollbacks, and selected data transformations to source and required cases. Distinguish application model rules, database-enforced structure, and observed samples. The observer reads metadata; the application's migration workflow changes the database.

Write concise source docstrings/JSDoc for authored mapped API handlers, functions and important parameters as implementation begins. Extract explanations from verified source bindings and distinguish concrete routes from collection wrappers. Read [source documentation](references/source-documentation.md) for the format and strict check; the coding agent maintains these with the code.

## 3. Maintain the graph during each coding batch

For a later business request, first follow [iteration dialogue](references/iteration-dialogue.md): restore confirmed decisions, locate the affected graph region and its boundaries, show the proposed local change in conversation and Web, and resolve only new or changed business meaning before implementation. Reuse explicit confirmations of the same scope. Source-only refactors keep their business meaning and update mappings without repeating business questions.

Connect these commands to the project's verification entrypoint. Conversation guidance applies only after explicit adoption in that conversation; project instruction files must not silently activate the skill elsewhere. The AI runs the commands; the user does not maintain intermediate files:

```text
change_sync begin -> coding and local generation -> bo_sync scan -> change_sync inspect
-> resolve confirmations and implementation review -> change_sync verify -> accept -> check
```

Before every coding turn, run `change_sync.py recall --root PROJECT` and read its concise output. It restores mode, current request, protected contracts, observation-module paths, affected layer nodes and verification commands from project files. `begin` also produces this recall automatically. Detailed per-layer sources, fields, lifecycles and cases are in `.stategraph/observation-plan.json`; inspect only affected entries. Recall does not accept source changes. See [observation continuity](references/observation-continuity.md).

Commands require the project `--root`; `begin` also needs `--change` and the actual request. Continue an active change instead of replacing its baseline to hide drift. See [continuous development](references/continuous-development.md).

Record confirmed requirement statuses and the actual allowed requirement IDs before `begin`. Keep the resulting baseline bytes immutable, including scope metadata; missing metadata is a failed initialization.

`bo_sync scan/watch` discovers new, changed, and deleted files independently of nodes already in the graph. Python, JS/TS, React, and Vue adapters produce common source facts. Missing parsers, syntax errors, and unsupported languages are explicit gaps. Watch produces maintenance tasks; the host or active coding AI must consume them. It cannot wake arbitrary editors or agents by itself.

Review source ownership when new directories, dependency/output paths or `.gitignore` change. Apply the same scope to graph, API, documentation and completeness checks; reject physical bindings into pruned storage while retaining hashed configuration and review inputs.

The optional [code structure](references/code-structure.md) is derived from that independent scope. Once enabled, refresh it during maintenance and verify its saved nodes, relations and file hashes against current source. Keep its source revision distinct from the running application's build. Preserve unresolved calls; never infer runtime execution from static edges. Include recognized API entries and handler links, and verify explicit business/state links rather than joining similar labels. See [graph evidence](references/types-rules-capture.md#readable-graph-evidence) for capture fields, source parameters and relation meaning.

Configured data projects also refresh their native model exports and database metadata during `bo_sync scan/watch`. `bo.py serve` watches configured data and reloads validated graph builds automatically. The native development launcher must reload its producer with the new build identity; old-build events remain rejected. `bo_db.py check` and `change_sync verify` independently recompute data mappings and require executed cases. A failed collector leaves the previous graph marked stale; never accept it as current.

Read `confirmations.user` and `confirmations.coding`. Ask users only about unresolved business meaning; reconcile unresolved calls and implementation changes within coding. Configure `reconciliation` records when dynamic bindings need protection. Stale source answers, absent targets, and missing verification cases must fail; records do not replace actual value and call checks.

Map all implemented features, including later login, messages, queries, configuration, and frontend actions. Give entrypoints, parameters, helpers, and runtime cases a traceable place in the graph. Collapsing a feature is not excluding it. Static edges are candidates; capture actual calls, decisions, state changes, and effects at their execution boundaries. Do not invent results for conditions skipped by short-circuit evaluation. See [source isolation](references/source-isolation.md) and [semantic probes](references/semantic-pins.md).

Use `bo_` for observation wiring and `BO` for adapter classes; keep domain names for business methods. Select fields explicitly. Never collect credentials, tokens, or arbitrary bodies. Isolate builder, transport, and storage failures; bound queues. Events identify project, model, build, run, producer, entity, call, and parameter version. Internal rule, state and value facts retain their actual enclosing invocation, including when file identities differ. Enable protected `require_observation_closure`; missing ownership fails mapping. Source-bound external point notifications may declare `observation_root`, as detailed in [observation continuity](references/observation-continuity.md). Arrival order across processes is not causality. Use application/entity scope for features such as login outside a selected task.

At node construction, register existing lifecycle meanings with `lifecycle.states` and explicit event/value `bindings`. Clarify uncertain business meanings with the user and implementation bindings with coding. Otherwise use neutral entry, wait/resume, return and exception observations; a return or exception does not establish business success or failure. A broad exception class cannot establish a specific outcome such as permission denial; capture the actual cause or retain the generic exception. Preserve real call ownership, including detached work with its own interval. Graph and timeline share these facts. Keep independent semantic and source parameter IDs connected by explicit `represents` mappings. Follow [lifecycles and representations](references/lifecycles-and-representations.md); test registered meanings against actual captured values, timed bars, same-track and cross-layer links, live inspection and recording without business writes.

Collection, reporting, polling, source viewing, layout, and recording controls must not produce business events. Exclusions need exact source and identity. Split mixed business/observer handlers rather than exempting them wholesale. Preserve real login, message, and state-change capture. See [observer exclusions](references/observer-exclusion.md).

Track source moves explicitly, preserving node identities, parameters, and assertions. Generate from canonical sources and check installed copies. Do not reset capture baselines, fabricate events, or relax expectations to remove failures. Keep personal layouts in `bo_stategraph/config/views/local.json`; upgrades must preserve them. See [source migration](references/cochange.md).

Keep project, node, and relation IDs stable across iterations. Use explicit `presentation.node_aliases` / `edge_aliases` for one-to-one renames; retain dormant personal settings and migration conflicts. Do not derive identity from labels, source line numbers, or build versions. A changed title is not a new project.

Route authored relation construction and updates through the [relation insertion](references/relation-insertion.md) interface. Register exact context, duplicate identity and permitted conceptual compositions from confirmed declarations. Keep physical execution facts direct. Missing meaning or evidence retains the edge; invalid or conflicting registrations stop the batch. Preserve raw IDs and witness paths, and check restoration after a witness changes or disappears.

Focused capture selects value builders and retains minimal witnessed caller boundaries. Unselected inputs and results remain uncollected; boundary metadata adds no ordinary replay steps. Disclose any remaining partial ownership without inferring parents or claiming full capture. See [observation continuity](references/observation-continuity.md#focused-values-and-execution-context).

Update affected source explanations with each coding batch. Run `bo_code.py docs --root PROJECT --strict` for new projects' mapped scope and keep it in their verification entrypoint; adopted code reports missing explanations while retaining complete mapping and all existing checks. A missing comment cannot be replaced by an AI label or a fabricated source reference.

For HTTP applications, also run `bo_code.py api-check --root PROJECT --strict`. Bind observed requests by actual handler source, method and route; verify their intervals in Graph and Timeline, including routes sharing a handler. Keep this gate in new projects so adding an unregistered API cannot silently lose observation.

## 4. Present and inspect

Use English for the default interface. Set its language from the user's current conversation with `bo_design.py language --root PROJECT --locale en|zh-CN --source CONVERSATION_REFERENCE`; repeat when the conversation language changes. A user's manual Web language choice takes precedence. Keep graph IDs, source code, and user-authored labels and notes unchanged. See [interface language](references/interface-language.md).

Reuse the complete `assets/stategraph-viewer/` interaction. After each batch, provide the updated graph and a brief explanation of changes. Start at high-level nodes, then expand important functions, states, and values; reveal advanced details on demand. Any expanded node uses a region with its type's color. Preserve group dragging, saved layouts, typed edges, notes, core markers, search, source navigation, and replay.

Keep the canvas central. Use node/edge context menus (also Shift+F10 and selection actions), a compact visible-type legend, and labeled recording icons. Clear removes only the selected stopped recording; it leaves application data and other recordings intact. Show conversation focus directly on the graph, with no separate discussion bar. Clicking empty canvas or pressing Escape dismisses it; expired focus clears silently.

Keep source detail optional. Offer **Project structure** for directories, files and dependencies, **Local code** for a selected region, and **Code structure** for declarations and calls. Scan the engineering tree automatically from the declared project scope after coding; do not ask the user or coding agent to author a separate directory model. Files link to their declarations in the same graph. Honor display budgets and show boundary/omission information. The existing state and business graph must work when source detail is closed.

Both 2D and true 3D use one typed graph inventory, layer visibility controls and runtime facts. Start 3D from above; keep same-layer elements on their plane and match the legend to the actual geometry. State nodes and transitions project the executable declaration, including conditions and actual hierarchy; unknown branch evidence stays unknown. Keep data operations and recorded event fields distinct from function signatures and lexical parameters; use source-context navigation without token highlighting when a field has no explicit source binding. Keep API handlers, authored function anchors, state transitions and data operations connected by explicit relations. Never join nodes by their names. In 3D, preserve semantic layers, nested containment and the owner's identity across layer projections. Source-only declarations remain static; use their explicit mapping to locate a recording owner rather than inventing execution. Retain spatial positions, pins and camera separately from 2D preferences. Preserve layer order, uniform spacing, visibility and edge shape across iterations. Compact currently visible, populated planes without empty height slots. Use recognizable solid objects in 3D with matching type colors and planar icons. Straight edges remain straight across layers; curves retain their curvature. Keep semantic type clustering within actual containment and preserve manual coordinates until Arrange. Keep 2D/3D type icons, counts, state badges and Delete-to-hide behavior equivalent. Recompute routes from current visible geometry; preserve original edge identities and report blocked paths. Playback skip/range settings and paused-step animation must never mutate recorded events or execute business commands. See [spatial graph](references/spatial-graph.md) for ownership, interaction and performance checks.

Provide one project development command that launches the application and its observer service together and prints both actual URLs. Keep application execution independent if observation is unavailable. The launcher must track and clean up only processes it started. Connect recording/replay to real runtime events; a design-only server has no business recording and must be labeled accordingly. Register the producer's actual scope control, bounded queue flush and health through `GraphSession.bo_bind_capture` or an equivalent integration. Test stop with queued events and focused capture before evaluating field builders; a display filter is not a capture connection. A drain failure must retain an interrupted recording and its gaps. See the [producer integration](references/multilanguage.md#recording-boundaries-and-capture-control). Set `require_probe_health: true` and report actual probe/data-adapter counters in normal runtime checks. Verify denied and error paths through real application entrypoints as well as normal paths; business results and mapping health are separate acceptance results. Verify both URLs, build identity, recording start/stop, and replay against a real user operation before delivery.

Every view must preserve meaningful relations. If the other endpoint is hidden, expose an explicit boundary; never invent a direct call or permission. Capture scope and replay granularity are separate. Show actual state/value changes at each step. Distinguish declarations, static derivation, and observed facts; missing or stale evidence is not current truth. See [hierarchical interaction](references/hierarchical-graph.md), [recording](references/recorded-analysis.md), and [local graphs and sharing](references/focus-and-sharing.md).

Respect explicit individual exclusions, including hidden groups and their descendants. “All elements” clears every exclusion while retaining layout and expansion. Folded elements remain represented by their group and counts; cross-group static relations retain their original endpoints. After a code/graph update, show only current-version recordings and leave an obsolete replay. A same-version process restart may retain recordings. Verify this across an actual reload; never reset personal views to make a new graph fit.

Separate a rule definition, relation data, and one evaluation. Do not generalize one example into all ReBAC. Read [authorization patterns](references/authorization-patterns.md), [rule graphs](references/rebac-graph.md), or [types and instances](references/types-rules-capture.md) when relevant.

When requested, hide the debug Web UI with `bo_web.py mode` or use the verified core export. Preserve declarations, native execution, and unified queries. Run the exported core; filenames alone do not prove removal. Personal layouts, credentials, and runtime records are private by default. Upgrades may remove unchanged superseded managed files; report conflicts for user-modified files.

## 5. Verify and deliver

For each batch, use the changed graph region and its incoming/outgoing dependencies to select regression cases. Follow the [iteration graph checks](references/iteration-graph-checks.md): retain independent expectations, run affected and neighboring feature cases, and test one relevant omission or incorrect value in an isolated copy. A static relation selects a case; actual execution establishes its evidence. Preserve the existing project-wide checks.

Report **implementation mapping**, **state constraints**, **business rules**, and **project checks** separately. A graph may accurately expose a business bug: mapping can pass while business checks fail. Missing evidence and unrun tests are not passes. Reject invalid declarations, types, projections, engines, or guard wiring before loading. Preserve actual invalid runtime values with diagnostics; never correct observations to fit the model.

Compare identities and effects at the selected native boundary. A final session or database snapshot cannot establish what was true before authentication, commit, logout or response completion. Keep the independent reader and its timing explicit; test an actual framework error response when API capture is configured.

For a configured policy network, scan/inspect/verify must check its exact projection, independent source signatures, actual per-check evaluations and their matching graph events. Include every configured operation case. Recheck shared dependents after composition, function, parameter or fact-basis changes; keep business expectations independent from recorded predicate truth.

Run the canonical protocol and CLI without replacing their validators or projectors. Project-native data and engine adapters translate actual application structures. A compatibility hook that changes canonical validation or projection is a framework gap: preserve its reproduction and report native-framework checks as blocked until the canonical implementation is repaired. Adapted success is separate evidence.

For exercised drive-mode transitions, compare the native executor's actual event, before/after states and evaluated guards with public queries and recording frames. A complete declaration or final state alone is not path evidence. Report an empty or incomplete journal/trace as a mapping gap; verify a deliberately removed transition witness is detected.

Verify that unsynchronized source changes fail; every feature and required field has actual evidence; key values match independent reads; business effects agree with observation on, off, failing, and queue-limited; viewer/recording controls create no business events; filtered views retain relations; export and Web removal preserve business execution. Run architecture checks, existing gates, and new language cases without weakening prior checks.

For `/vibelens` controls, resolve containment from the canonical model and verify that every requested node is visible before reporting application success. Test switching from a simplified boundary view into nested rules or business steps; a display projection must not replace declaration ancestry.

For configured databases, check a real schema change, actual query targets and selected values, a transformation, commit and applicable rollback/error cases, and observer-query exclusion. Verify source links, data relations, replay, saved layout, and obsolete-recording removal after a build change. Missing drivers or services are unrun checks. Keep mapping results separate from business outcomes and unverified schema details.

Keep failures, fixes, retests, and limitations. Deliver an accessible graph, reproducible commands, and usage guidance. Distinguish scripted dialogue, independent AI trials, and human testing. Open or message another conversation only with user authorization.
