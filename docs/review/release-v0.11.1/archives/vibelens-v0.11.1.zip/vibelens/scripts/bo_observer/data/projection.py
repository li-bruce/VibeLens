"""Project database metadata into the same graph as business functions and states."""

from copy import deepcopy
from urllib.parse import quote

from .contract import MANAGED, CONFIG_PATH, CATALOG_PATH, capture_spec
from .protocol import operation_target_actions
from .schema_compare import structure_differences
from ..observation.lifecycle import data_lifecycle


def resource_id(store, key):
    """Names identify native resources; reviewed aliases handle actual renames."""
    return "db:" + quote(store, safe="") + ":" + quote(key, safe="")


def field_id(store, key, field):
    """Keep field identities tied to the native resource rather than its display label."""
    return resource_id(store, key) + ":field:" + quote(field, safe="")


def project_model(model, config, bundle):
    """Replace only managed data nodes; preserve authored graph, IDs, notes, and layout settings."""
    result = deepcopy(model)
    previous_nodes = {node["id"]: node for node in result["nodes"]}
    node_order = {node["id"]: position for position, node in enumerate(result["nodes"])}
    edge_order = {edge["id"]: position for position, edge in enumerate(result["edges"])}
    previous_sources = set(result.get("database", {}).get("managed_source_files", []))
    authored_sources = set(result["source_files"]) - previous_sources
    result["nodes"] = [n for n in result["nodes"] if n.get("managed_by") != MANAGED]
    result["edges"] = [e for e in result["edges"] if e.get("managed_by") != MANAGED]
    nodes = {n["id"]: n for n in result["nodes"]}
    edge_ids = {e["id"] for e in result["edges"]}
    required_sources = {CONFIG_PATH, CATALOG_PATH}
    actuals = {c["store_id"]: c for c in bundle["catalogs"]}
    declarations = {c["store_id"]: c for c in bundle["declarations"]}

    def add_node(value):
        """Add one managed node without overwriting authored IDs or source enrichment."""
        if value["id"] in nodes:
            raise ValueError("database node conflicts with an authored node: " + value["id"])
        if value.get("parent") and value["parent"] not in nodes:
            raise ValueError("database parent does not exist: " + value["parent"])
        value["managed_by"] = MANAGED
        previous = previous_nodes.get(value["id"], {})
        if value.get("source") and value["source"] == previous.get("source"):
            # Source enrichment owns this field. It independently verifies the
            # AST hash; refreshing database metadata must not erase its output.
            if "code_evidence" in previous:
                value["code_evidence"] = deepcopy(previous["code_evidence"])
        result["nodes"].append(value)
        nodes[value["id"]] = value

    def edge(start, end, relation, label=None, *, origin=None, constraint=None):
        """Retain endpoint identity and merge repeated native constraint evidence."""
        ident = "db-edge:" + quote(start, safe="") + ":" + relation + ":" + quote(end, safe="")
        if start not in nodes or end not in nodes:
            raise ValueError("database relation endpoint absent")
        if ident in edge_ids:
            existing = next(e for e in result["edges"] if e["id"] == ident)
            if existing.get("managed_by") != MANAGED:
                raise ValueError("database edge conflicts with an authored edge: " + ident)
            if constraint:
                existing.setdefault("data_constraints", []).append({"origin": origin, **constraint})
                labels = list(
                    dict.fromkeys(c.get("name") or c["kind"] for c in existing["data_constraints"])
                )
                existing["label"] = ", ".join(labels)
            return
        edge_ids.add(ident)
        value = {
            "id": ident,
            "from": start,
            "to": end,
            "type": "contains" if relation == "contains" else "data",
            "label": label or relation,
            "evidence": "database catalog and configured source binding",
            "managed_by": MANAGED,
        }
        if relation != "contains":
            value["data_relation"] = relation
        if origin:
            value["data_origin"] = origin
        if constraint:
            value["data_constraints"] = [{"origin": origin, **constraint}]
        result["edges"].append(value)

    for store in config["stores"]:
        ident = resource_id(store["id"], "store")
        actual = actuals[store["id"]]
        declared = declarations.get(store["id"])
        application_declaration = (declared or {}).get("validation_scope") == "application"
        differences = structure_differences(actual, declared)
        required_sources.update(store["source_files"])
        if store.get("declaration"):
            required_sources.add(store["declaration"])
        add_node(
            {
                "id": ident,
                "kind": "data",
                "label": store["label"],
                "summary": store["engine"] + " · " + actual["coverage"],
                "data_role": "store",
                "data_store": store["id"],
                "data_key": "store",
                "data_origin": "database",
                "data_coverage": actual["coverage"],
                "data_metadata": {
                    "engine": store["engine"],
                    "limitations": actual["limitations"],
                    "model_layer": store["model_layer"],
                },
                **({"parent": store["parent"]} if store.get("parent") else {}),
            }
        )
        if store.get("parent"):
            edge(store["parent"], ident, "contains")
        current = {r["key"]: r for r in actual["resources"]}
        expected = {r["key"]: r for r in (declared or {}).get("resources", [])}
        for key in sorted(current.keys() | expected.keys()):
            resource = current.get(key) or expected[key]
            status = (
                "matched"
                if key in current and key in expected
                else "database_only" if key in current else "declared_only"
            )
            if key in expected and application_declaration:
                status = "application_declared"
            elif (
                key in current
                and key in expected
                and any(d["resource"] == key for d in differences)
            ):
                status = "different"
            rid = resource_id(store["id"], key)
            add_node(
                {
                    "id": rid,
                    "kind": "data",
                    "label": resource["name"],
                    "summary": resource["kind"],
                    "parent": ident,
                    "data_role": "dataset",
                    "data_store": store["id"],
                    "data_key": key,
                    "data_origin": "database" if key in current else "declaration",
                    "data_coverage": actual["coverage"],
                    "data_metadata": {
                        "kind": resource["kind"],
                        "status": status,
                        "constraints": resource["constraints"],
                        "declared_constraints": expected.get(key, {}).get("constraints", []),
                    },
                }
            )
            edge(ident, rid, "contains")
            observed_fields = {f["name"]: f for f in current.get(key, {}).get("fields", [])}
            declared_fields = {f["name"]: f for f in expected.get(key, {}).get("fields", [])}
            if status == "matched" and any(
                observed_fields.get(name, {}).get(prop) in (None, "unknown")
                for name, expected_field in declared_fields.items()
                for prop in ("native_type", "nullable", "primary_key", "required", "generated")
                if expected_field.get(prop) not in (None, "unknown")
            ):
                nodes[rid]["data_metadata"]["status"] = "unverified"
            for name in sorted(observed_fields.keys() | declared_fields.keys()):
                field = observed_fields.get(name) or declared_fields[name]
                fid = field_id(store["id"], key, name)
                field_status = (
                    "matched"
                    if name in observed_fields and name in declared_fields
                    else "database_only" if name in observed_fields else "declared_only"
                )
                if name in declared_fields and application_declaration:
                    field_status = "application_declared"
                elif (
                    name in observed_fields
                    and name in declared_fields
                    and any(d["resource"] == key and d.get("field") == name for d in differences)
                ):
                    field_status = "different"
                elif (
                    name in observed_fields
                    and name in declared_fields
                    and any(
                        observed_fields[name].get(prop) in (None, "unknown")
                        for prop in (
                            "native_type",
                            "nullable",
                            "primary_key",
                            "required",
                            "generated",
                        )
                        if declared_fields[name].get(prop) not in (None, "unknown")
                    )
                ):
                    field_status = "unverified"
                add_node(
                    {
                        "id": fid,
                        "kind": "data",
                        "label": name,
                        "summary": field["native_type"],
                        "parent": rid,
                        "data_role": "column",
                        "data_store": store["id"],
                        "data_key": key + "." + name,
                        "data_origin": "database" if name in observed_fields else "declaration",
                        "data_coverage": actual["coverage"],
                        "data_metadata": {
                            **field,
                            "status": field_status,
                            "declared": declared_fields.get(name),
                        },
                    }
                )
                edge(rid, fid, "contains")
        for key, resource, origin in [
            *((k, r, "database") for k, r in current.items()),
            *((k, r, "declaration") for k, r in expected.items()),
        ]:
            for constraint in resource["constraints"]:
                target = constraint.get("target")
                if not target:
                    continue
                tid = resource_id(store["id"], target)
                if tid not in nodes:
                    add_node(
                        {
                            "id": tid,
                            "kind": "data",
                            "label": target,
                            "summary": "Referenced resource outside the inspected scope",
                            "parent": ident,
                            "data_role": "dataset",
                            "data_store": store["id"],
                            "data_key": target,
                            "data_origin": origin,
                            "data_coverage": "partial",
                            "data_metadata": {"status": "outside_scope"},
                        }
                    )
                    edge(ident, tid, "contains")
                edge(
                    resource_id(store["id"], key),
                    tid,
                    "references",
                    constraint["name"] or constraint["kind"],
                    origin=origin,
                    constraint=constraint,
                )
                for local, remote in zip(constraint["fields"], constraint.get("target_fields", [])):
                    start = field_id(store["id"], key, local)
                    end = field_id(store["id"], target, remote)
                    if start in nodes and end in nodes:
                        edge(
                            start,
                            end,
                            "maps",
                            constraint["name"] or constraint["kind"],
                            origin=origin,
                            constraint=constraint,
                        )

    for operation in config["operations"]:
        required_sources.add(operation["source"]["path"])
        target_actions = operation_target_actions(operation)
        add_node(
            {
                "id": operation["id"],
                "kind": "function",
                "label": operation["label"],
                "summary": operation["action"] + " · " + operation["store"],
                "source": operation["source"],
                "parent": operation["parent"],
                "data_role": "transform" if operation["action"] == "transform" else "query",
                "data_store": operation["store"],
                "data_origin": "declaration",
                "data_coverage": "partial",
                "data_metadata": {
                    "action": operation["action"],
                    "targets": operation["targets"],
                    **(
                        {"target_actions": operation["target_actions"]}
                        if "target_actions" in operation
                        else {}
                    ),
                },
                "capture": capture_spec(operation),
                "lifecycle": data_lifecycle(operation["action"]),
            }
        )
        edge(operation["parent"], operation["id"], "contains")
        for target in operation["targets"]:
            tid = resource_id(operation["store"], target)
            if tid not in nodes:
                raise ValueError(
                    "configured database target absent: " + operation["store"] + "/" + target
                )
            if target_actions.get(target) in {"read", "read_write"}:
                edge(tid, operation["id"], "reads")
            if target_actions.get(target) in {"write", "read_write"}:
                edge(operation["id"], tid, "writes")
    for operation in config["operations"]:
        for previous in operation.get("inputs", []):
            edge(previous, operation["id"], "transforms")
    result["source_files"] = sorted(authored_sources | required_sources)
    result["database"] = {
        "protocol": MANAGED,
        "source_id": bundle["source_id"],
        "catalog_id": bundle["catalog_id"],
        "stores": [s["id"] for s in config["stores"]],
        "managed_source_files": sorted(required_sources - authored_sources),
    }
    # Composable projections preserve existing order and append only new IDs.
    # Otherwise source and database generators continually reorder each other.
    result["nodes"].sort(key=lambda node: node_order.get(node["id"], len(node_order)))
    result["edges"].sort(key=lambda edge: edge_order.get(edge["id"], len(edge_order)))
    return result
