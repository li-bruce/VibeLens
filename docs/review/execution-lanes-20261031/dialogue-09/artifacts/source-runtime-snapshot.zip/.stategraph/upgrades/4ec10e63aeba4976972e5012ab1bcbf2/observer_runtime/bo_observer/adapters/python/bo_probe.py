"""Bounded, fault-isolated JSON transport. Standard library only."""

from contextvars import ContextVar
from contextlib import contextmanager, nullcontext
from datetime import datetime, timezone
import json
import math
import queue
import threading
import time
from urllib.request import Request, urlopen
import uuid

try:
    from ...observation.observation_scope import bo_internal, bo_is_internal
except ImportError:
    # This probe is also distributed as a standalone standard-library module.
    bo_internal = nullcontext

    def bo_is_internal():
        return False


_bo_internal = ContextVar("bo_transport_internal", default=False)
_bo_span = ContextVar("bo_activation_scope", default=None)


class BOActivation:
    """One witnessed operation; the enclosing context owns its real completion."""

    def __init__(self, probe, node, options):
        self.bo_probe, self.bo_node, self.bo_options = probe, node, options
        self.call_id = options["call_id"]
        self.entry_id = None
        self.bo_result = lambda: {}
        self.bo_active = True

    def result(self, builder):
        """Select completion values lazily; transport failures do not alter the result."""
        self.bo_result = builder

    def record(self, phase, builder):
        return self.bo_probe.record(self.bo_node, phase, builder, **self.bo_options)


def bo_selected(value, spec, depth=0):
    """Copy only declared fields, with bounded nesting, string length, arrays, and numbers."""
    if depth > 6:
        raise ValueError("capture depth exceeded")
    if isinstance(spec, dict):
        if not isinstance(value, dict):
            raise ValueError("expected selected object")
        return {k: bo_selected(value[k], s, depth + 1) for k, s in spec.items() if k in value}
    if isinstance(spec, list):
        if not isinstance(value, list) or len(spec) != 1 or len(value) > 64:
            raise ValueError("bounded array required")
        return [bo_selected(v, spec[0], depth + 1) for v in value]
    if value is None:
        return None
    if (
        spec in ("number", "scalar")
        and type(value) in (int, float)
        and math.isfinite(value)
        and (type(value) is not int or abs(value) <= 9007199254740991)
    ):
        return value
    if spec in ("boolean", "scalar") and type(value) is bool:
        return value
    if spec in ("string", "scalar") and isinstance(value, str) and len(value) <= 256:
        return value
    raise ValueError("unapproved capture type")


class BOProbe:
    def bo_current_context(self):
        """Copy the active same-probe invocation identity for native adapters."""
        parent = _bo_span.get()
        if parent is None or parent.bo_probe is not self or not parent.bo_active:
            return {}
        return {
            **{
                key: value
                for key, value in parent.bo_options.items()
                if key in {"entity", "attempt", "scope", "basis"}
            },
            "parent_call_id": parent.call_id,
        }

    @contextmanager
    def bo_call_context(self, node, call_id, **identity):
        """Scope a native adapter's already-recorded call without emitting extra events."""
        activation = BOActivation(self, node, {**identity, "call_id": call_id})
        token = _bo_span.set(activation)
        try:
            yield
        finally:
            activation.bo_active = False
            _bo_span.reset(token)

    @contextmanager
    def span(self, node, builder=lambda: {}, **options):
        """Witness entry through completion, including awaited children and exceptions.

        Use ``with`` in synchronous or asynchronous code. Nested spans inherit only
        this probe's invocation context. Detached tasks must own a separate span.
        """
        options = {**self.bo_current_context(), **options}
        options.setdefault("call_id", uuid.uuid4().hex)
        options["lifecycle"] = "span"
        activation = BOActivation(self, node, options)
        activation.entry_id = activation.record("enter", builder)
        token = _bo_span.set(activation)
        try:
            yield activation
        except BaseException as error:
            error_name = type(error).__name__
            activation.record("error", lambda: {"outputs": {"error": error_name}})
            raise
        else:
            activation.record("return", activation.bo_result)
        finally:
            activation.bo_active = False
            _bo_span.reset(token)

    def __init__(
        self,
        project,
        build_id,
        *,
        endpoint="",
        token="",
        run_id=None,
        producer_id=None,
        enabled=True,
        capacity=256,
        timeout=0.5,
        sink=None,
    ):
        self.bo_project, self.bo_build = project, build_id
        self.bo_endpoint, self.bo_token, self.bo_timeout, self.bo_sink = (
            endpoint,
            token,
            timeout,
            sink,
        )
        self.bo_run, self.bo_producer = run_id or uuid.uuid4().hex, producer_id or uuid.uuid4().hex
        self.bo_enabled = enabled
        self.bo_seq = self.bo_errors = self.bo_dropped = self.bo_suppressed = 0
        self.bo_filtered = 0
        self.bo_capture_nodes = None
        self.bo_last_error = None
        self.bo_queue = queue.Queue(maxsize=max(1, capacity))
        self.bo_lock = threading.Lock()
        self.bo_closed = threading.Event()
        self.bo_nodes = {n["id"]: n for n in project["model"]["nodes"]}
        excluded = project["model"].get("implementation", {}).get("excluded", {})
        self.bo_excluded = {
            n["id"]
            for n in project["model"]["nodes"]
            if n.get("source")
            and excluded.get(n["source"]["path"] + "::" + n["source"]["symbol"], {}).get("category")
            == "observer"
        }
        self.bo_worker = threading.Thread(
            target=self.bo_drain, daemon=True, name="bo-json-transport"
        )
        if enabled:
            self.bo_worker.start()

    def bo_base(self, protocol):
        return {
            "protocol": protocol,
            "project_id": self.bo_project["project_id"],
            "model_revision": self.bo_project["model"]["revision"],
            "build_id": self.bo_build,
            "run_id": self.bo_run,
            "producer_id": self.bo_producer,
        }

    def bo_set_scope(self, nodes):
        """Select temporary capture owners before evaluating their field builders.

        None restores full capture. Filtering does not consume a producer sequence
        number, so deliberately excluded events do not resemble transport loss.
        """
        if nodes is not None and (
            not isinstance(nodes, list)
            or any(not isinstance(node, str) or node not in self.bo_nodes for node in nodes)
        ):
            raise ValueError("capture scope requires known node IDs or None")
        with self.bo_lock:
            self.bo_capture_nodes = None if nodes is None else frozenset(nodes)

    def bo_health(self):
        """Expose transport/capture counters without reading application state."""
        with self.bo_lock:
            return {
                "enabled": self.bo_enabled and not self.bo_closed.is_set(),
                "run_id": self.bo_run,
                "producer_id": self.bo_producer,
                "enqueued": self.bo_seq,
                "pending": self.bo_queue.unfinished_tasks,
                "errors": self.bo_errors,
                "dropped": self.bo_dropped,
                "filtered": self.bo_filtered,
                "last_error": dict(self.bo_last_error) if self.bo_last_error else None,
            }

    def bo_put(self, kind, body):
        raw = json.dumps(body, ensure_ascii=False, allow_nan=False).encode()
        if len(raw) > 24576:
            raise ValueError("observation too large")
        self.bo_queue.put_nowait((kind, raw))
        return True

    def record(
        self,
        node,
        phase,
        builder,
        *,
        entity="application",
        attempt="application",
        scope="application",
        basis=None,
        call_id=None,
        parent_call_id=None,
        depends=(),
        revision=None,
        lifecycle=None,
    ):
        """Build and enqueue a selected observation without changing the business result.

        Suppress observer activity and recursive capture. Count failures locally and
        return None when an observation cannot be queued.
        """
        if not self.bo_enabled or self.bo_closed.is_set():
            return None
        if _bo_internal.get() or bo_is_internal() or node in self.bo_excluded:
            self.bo_suppressed += 1
            return None
        with self.bo_lock:
            if self.bo_capture_nodes is not None and node not in self.bo_capture_nodes:
                self.bo_filtered += 1
                return None
        token = _bo_internal.set(True)
        try:
            if phase not in {
                "enter",
                "return",
                "read",
                "decision",
                "wait",
                "commit",
                "change",
                "error",
            }:
                raise ValueError("invalid phase")
            spec = self.bo_nodes[node].get("capture", {})
            values = builder()
            if lifecycle not in (None, "span"):
                raise ValueError("invalid lifecycle boundary mode")
            with self.bo_lock:
                self.bo_seq += 1
                eid = f"{self.bo_run}:{self.bo_producer}:{self.bo_seq}"
                body = {
                    **self.bo_base("bo-event/v1"),
                    "schema_version": 3,
                    "seq": self.bo_seq,
                    "id": eid,
                    "node": node,
                    "phase": phase,
                    "entity": entity,
                    "attempt": attempt,
                    "scope": scope,
                    "basis": bo_selected(
                        basis or {},
                        {"param_version": "number", "epoch": "number", "clock": "number"},
                    ),
                    "call_id": call_id or eid,
                    "parent_call_id": parent_call_id,
                    "inputs": bo_selected(values.get("inputs", {}), spec.get("in", {})),
                    "outputs": bo_selected(values.get("outputs", {}), spec.get("out", {})),
                    "depends": list(depends),
                    "observed_at": datetime.now(timezone.utc).isoformat(),
                }
                if revision is not None:
                    if type(revision) is not int or not 0 <= revision <= 9007199254740991:
                        raise ValueError("invalid state revision")
                    body["revision"] = revision
                if lifecycle is not None:
                    body["lifecycle"] = lifecycle
                self.bo_put("events", body)
            return eid
        except queue.Full:
            self.bo_dropped += 1
            self.bo_last_error = {"stage": "queue", "type": "Full"}
        except Exception as error:
            self.bo_errors += 1
            self.bo_last_error = {
                "stage": "capture",
                "type": type(error).__name__,
                "node": node[:160] if isinstance(node, str) and node in self.bo_nodes else None,
                "phase": (
                    phase
                    if isinstance(phase, str)
                    and phase
                    in {"enter", "return", "read", "decision", "wait", "commit", "change", "error"}
                    else None
                ),
            }
        finally:
            _bo_internal.reset(token)
        return None

    def snapshot(
        self,
        instance_id,
        state,
        context,
        revision,
        evidence_id,
        *,
        event=None,
        guards=None,
        payload=None,
        configuration=None,
    ):
        """Queue a state snapshot associated with an already identified business event."""
        if not self.bo_enabled or self.bo_closed.is_set():
            return False
        if _bo_internal.get() or bo_is_internal():
            self.bo_suppressed += 1
            return False
        try:
            return self.bo_put(
                "snapshots",
                {
                    **self.bo_base("bo-snapshot/v1"),
                    "instance_id": instance_id,
                    "state": state,
                    "context": context,
                    "revision": revision,
                    "evidence_id": evidence_id,
                    "event": event,
                    "guards": guards,
                    "payload": payload,
                    "configuration": configuration,
                },
            )
        except queue.Full:
            self.bo_dropped += 1
        except Exception as error:
            self.bo_errors += 1
            self.bo_last_error = {"stage": "snapshot", "type": type(error).__name__}
        return False

    def bo_send_one(self, kind, raw):
        """Deliver an original envelope through the existing local or HTTP contract."""
        if self.bo_sink:
            return self.bo_sink(json.loads(raw), kind)
        req = Request(
            self.bo_endpoint + "/api/bo/" + kind,
            data=raw,
            headers={"Content-Type": "application/json", "X-BO-Token": self.bo_token},
            method="POST",
        )
        with urlopen(req, timeout=self.bo_timeout) as response:
            response.read(32768)

    def bo_transport_error(self, error):
        self.bo_errors += 1
        self.bo_last_error = {"stage": "transport", "type": type(error).__name__}

    def bo_drain(self):
        """Drain bounded event groups; snapshots remain ordered completion barriers.

        Only explicitly batch-capable local sinks opt in. HTTP and plain callable
        sinks retain their single-envelope contract. Failed batch preflight falls
        back to the original envelopes, preserving per-message error isolation.
        """
        deferred = None
        while deferred is not None or not self.bo_closed.is_set() or not self.bo_queue.empty():
            if deferred is not None:
                kind, raw = deferred
                deferred = None
            else:
                try:
                    kind, raw = self.bo_queue.get(timeout=0.05)
                except queue.Empty:
                    continue
            batch = [raw]
            token = _bo_internal.set(True)
            try:
                with bo_internal():
                    try:
                        accept_many = getattr(self.bo_sink, "bo_accept_many", None)
                    except Exception:
                        accept_many = None  # An optional capability cannot break a plain sink.
                    if kind == "events" and callable(accept_many):
                        while len(batch) < 16:
                            try:
                                following = self.bo_queue.get_nowait()
                            except queue.Empty:
                                break
                            if following[0] != "events":
                                deferred = following
                                break
                            batch.append(following[1])
                    if len(batch) > 1:
                        try:
                            receipts = accept_many([json.loads(value) for value in batch])
                            if (
                                not isinstance(receipts, list)
                                or len(receipts) != len(batch)
                                or any(
                                    not isinstance(receipt, dict)
                                    or receipt.get("accepted") is not True
                                    for receipt in receipts
                                )
                            ):
                                raise ValueError("event batch lacks acceptance receipts")
                        except Exception:
                            for value in batch:
                                try:
                                    self.bo_send_one(kind, value)
                                except Exception as error:
                                    self.bo_transport_error(error)
                    else:
                        self.bo_send_one(kind, raw)
            except Exception as error:
                self.bo_transport_error(error)
            finally:
                _bo_internal.reset(token)
                for _ in batch:
                    self.bo_queue.task_done()

    def flush(self, timeout=2):
        """Wait up to the supplied timeout for queued observations to finish sending."""
        deadline = time.monotonic() + timeout
        while self.bo_queue.unfinished_tasks and time.monotonic() < deadline:
            time.sleep(0.005)
        return not self.bo_queue.unfinished_tasks

    def close(self):
        """Request worker shutdown and bound the time spent joining it."""
        self.bo_closed.set()
        if self.bo_enabled:
            self.bo_worker.join(1)
