"""Reproduce the canonical data-adapter/closure-validator mismatch.

This is a framework API reproduction with a real SQLite transaction and transform.
It is separate from application acceptance and is never ingested into its viewer.
"""
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
ROOT=Path(__file__).resolve().parents[2]
SCRIPTS=ROOT.parents[1]/"SoftwareStatusObserverSkill/skills/vibelens/scripts"
sys.path.insert(0,str(SCRIPTS))
from bo_observer.adapters.python.bo_probe import BOProbe
from bo_observer.data.runtime import BODataRuntime
from bo_observer.workflow.observation_requirements import invocation_closure

def main():
    project=json.loads((ROOT/"bo_stategraph/project.json").read_text(encoding="utf-8-sig"))
    config=json.loads((ROOT/"bo_stategraph/databases.json").read_text(encoding="utf-8-sig"))
    events=[]
    def sink(envelope,kind):
        if kind=="events":
            events.append(envelope)
    probe=BOProbe(project,"framework-api-reproduction",sink=sink,capacity=32)
    adapter=BODataRuntime(probe,config)
    connection=sqlite3.connect(":memory:")
    connection.execute("CREATE TABLE proof (id INTEGER PRIMARY KEY)")
    with adapter.transaction("db_transaction",connection):
        connection.execute("INSERT INTO proof VALUES (1)")
    committed=connection.execute("SELECT COUNT(*) FROM proof").fetchone()[0]
    transformed=adapter.transform("db_metadata",lambda value:{"size":value["size"]},{"size":7},
        before=lambda value:{"size":value["size"]},after=lambda value:{"size":value["size"]})
    probe.flush(10)
    health=probe.bo_health()
    probe.close()
    connection.close()
    result=invocation_closure({"runs":[{"case":"canonical-api-repro","mode":"on","events":events}]},required=True)
    paths=["bo_observer/data/runtime.py","bo_observer/workflow/observation_requirements.py","bo_observer/adapters/python/bo_probe.py"]
    parity={name:{"canonical_sha256":hashlib.sha256((SCRIPTS/name).read_bytes()).hexdigest(),
        "copied_sha256":hashlib.sha256((ROOT/"observer_runtime"/name).read_bytes()).hexdigest()} for name in paths}
    report={"reproduced":not result["valid"] and committed==1 and transformed=={"size":7},
        "classification":"Shared canonical producer and validator disagree about transaction/transform terminal phases.",
        "application_acceptance":False,"sqlite_committed_rows":committed,"transform_result":transformed,
        "probe_health":health,"data_errors":adapter.bo_errors,"events":events,"closure":result,"source_parity":parity}
    output=Path(__file__).with_name("reproduction-result.json")
    output.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps({"reproduced":report["reproduced"],"sqlite_committed_rows":committed,
        "phases":[[event["node"],event["phase"]] for event in events],"closure":result},ensure_ascii=False))
    return 0 if report["reproduced"] else 1
if __name__=="__main__":
    raise SystemExit(main())
