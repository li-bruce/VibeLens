# Review Evidence

Preserve original Chinese dialogue as historical evidence. Maintained source, identifiers, comments, and canonical documentation use English.

Current stage: stopped at the shared runtime-mapping failure, without acceptance. The business-user role was simulated by the coordinating AI. Actually received forwarded messages are not independent human usability evidence. `PROVENANCE-CORRECTION.md` supersedes earlier conflicting provenance labels without rewriting raw historical text.

- `user-request-001.txt`: exact initial delegated user request.
- `dialogue-001.json`: actual request and assistant questions; no simulated answers.
- `decisions.json`: explicit execution mode, database, and isolation choices.
- `policy-draft.json`: shared login and approval gates, with unresolved actor authority represented as unknown inputs.
- `design-preview.md`: generated conversation diagram from the same design graph as the viewer.

Failures, project repairs before stop, retests, runtime checks and design-stage screenshots are retained. `ARCHIVE-BOUNDARY.md` separates the complete failed gate, later current source, interrupted verification, and unrun browser/recording checks. `archive-index.json` identifies the final archive and its SHA-256. A design graph and successful business assertions do not establish runtime mapping acceptance.
