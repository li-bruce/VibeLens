# Shared Framework Issue: Data Operation Completion vs Strict Invocation Closure

Status: reproduced against the requested canonical Skill. No framework or installed-copy source was modified. No synthetic completion events were added and no protected check was disabled.

## Actual application result

The canonical verification report in `../verify-001.json` reports:

- Business: passed, all 12 required case/mode assertions executed.
- State constraints: passed.
- Configured project tests: passed.
- Mapping: failed with 11 `invocation_without_exit` reports.
- Enabled producer health: passed for all four normal cases.
- Policy evidence and implementation/data coverage: passed.
- Public export: checked; 12 mapping witnesses and 75 projection comparisons passed.

This is an unaccepted local prototype. The project has not run `accept`; the normal check remains blocking.

## Cause reproduced without application execution

`BODataRuntime.transaction` emits `enter → commit` after a real successful commit.
`BODataRuntime.transform` emits `enter → change` after the actual transformation.
The canonical `invocation_closure(required=True)` filters its event input to only `enter`, `return`, and `error`. It therefore ignores both normal terminal phases and reports those entries as unclosed.

Relevant maintained source:

- `scripts/bo_observer/data/runtime.py`: `transform`, `transaction`.
- `scripts/bo_observer/workflow/observation_requirements.py`: `invocation_closure`.

Run from this project's root with its virtual environment:

```powershell
.\.venv\Scripts\python.exe -B .\review\framework-issue\reproduce.py
```

The reproduction imports the canonical Skill directly, runs a real SQLite transaction and a real scalar transformation, collects four original probe events, then invokes the unchanged canonical checker. `reproduction-result.json` retains the actual commit count, output, event identities, counters, errors, and canonical/copied source hashes.

The reproduction is framework API evidence, separate from application-source mapping. Its events are not ingested into the application's viewer or presented as application acceptance.

## Boundary

No example-local workaround is applied. Repair of the shared producer/checker contract requires separate authorization to work on the maintained repository. Recording, browser, and other trial checks are reported separately; they cannot turn this failed gate into a pass.
