"""Freeze this stopped trial without editing source or rerunning acceptance."""
import hashlib
import json
from pathlib import Path
import shutil
import socket
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[1]
ARCHIVE=ROOT/"review/archive-20261031-stopped-03"
SCRIPTS=ROOT.parents[1]/"SoftwareStatusObserverSkill/skills/vibelens/scripts"
sys.path.insert(0,str(SCRIPTS))
from behavior_model import digest

def read(path):
    raw=path.read_bytes()
    try:
        return json.loads(raw.decode("utf-8-sig"))
    except UnicodeDecodeError:
        return json.loads(raw.decode("gb18030"))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def copy_file(source,target):
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(source,target)

def main():
    if ARCHIVE.exists():
        raise RuntimeError("Archive already exists; do not overwrite historical evidence.")
    ARCHIVE.mkdir()
    names=["app","bo_stategraph","integrations","observer_runtime","static","templates","tooling"]
    ignored=shutil.ignore_patterns("__pycache__","*.pyc")
    for name in names:
        source=ROOT/name
        if name=="bo_stategraph":
            shutil.copytree(source,ARCHIVE/"source"/name,ignore=shutil.ignore_patterns("__pycache__","*.pyc","data"))
        else:
            shutil.copytree(source,ARCHIVE/"source"/name,ignore=ignored)
    for name in ["README.md","AGENTS.md","requirements.txt","intent.json","discovery.json","acceptance.json",
        "mapping.json","whitebox.json","implementation.json","sync.json","ownership.json","run.py",".gitignore"]:
        if (ROOT/name).is_file():
            copy_file(ROOT/name,ARCHIVE/"source"/name)
    shutil.copytree(ROOT/".stategraph",ARCHIVE/"evidence/stategraph",ignore=ignored)
    if (ROOT/"bo_stategraph/data").is_dir():
        shutil.copytree(ROOT/"bo_stategraph/data",ARCHIVE/"evidence/observer-data",ignore=ignored)
    for source in (ROOT/"review").iterdir():
        if source.name.startswith("archive-") or source.name=="archive-index.json" or source==ARCHIVE:
            continue
        target=ARCHIVE/"evidence/review"/source.name
        if source.is_dir():
            shutil.copytree(source,target,ignore=ignored)
        else:
            copy_file(source,target)
    if (ROOT/"var").is_dir():
        for source in (ROOT/"var").glob("*.sqlite3"):
            copy_file(source,ARCHIVE/"evidence/application-data"/source.name)
    completed=read(ROOT/"review/verify-001.json")
    wrapper=read(ROOT/".stategraph/initial/checks/observations.json")
    raw=read(ROOT/"review/runtime-observations.json")
    received=read(ROOT/".stategraph/initial/verification.json")
    installed=read(ROOT/"bo_stategraph/runtime-version.json")
    conflicts=[]
    for name,expected in installed.get("files",{}).items():
        path=ROOT/name
        if not path.is_file() or sha(path)!=expected:
            conflicts.append(name)
    native_source=SCRIPTS/"bo_observer/adapters/python/bo_executor.py"
    native_copy=ROOT/"bo_stategraph/native_executor.py"
    listeners={}
    for port in (8972,8973):
        with socket.socket() as stream:
            stream.settimeout(0.5)
            listeners[str(port)]={"connect_code":stream.connect_ex(("127.0.0.1",port))}
    identity={
        "schema":"stopped-trial-archive/v1",
        "status":"stopped_without_acceptance",
        "runtime_mapping_acceptance":"failed",
        "accepted_json_exists":(ROOT/".stategraph/initial/accepted.json").exists(),
        "completed_gate":{"path":"evidence/review/verify-001.json","candidate_id":completed["candidate_id"],
            "valid":completed["valid"],"observations_hash":completed["observations_hash"],
            "wrapper_hash_matches":digest(wrapper)==completed["observations_hash"],
            "raw_stdout_matches_saved_payload":json.loads(wrapper["stdout"])==raw,
            "build_id":raw["build_id"],
            "reports":{name:report["status"] for name,report in completed["reports"].items()}},
        "interrupted_gate":{"path":"evidence/review/verify-002.json","status":"interrupted_before_final_result",
            "stdout_bytes":(ROOT/"review/verify-002.json").stat().st_size,
            "candidate_id":read(ROOT/"review/inspect-005.json")["candidate_id"]},
        "current_source":{"path":"source","boundary":"Later than completed gate 001; do not attribute the completed result to this later source. Gate 002 was interrupted."},
        "provenance":{"business_user_role":"simulated_by_coordinator_ai","forwarded_messages_actually_received":True,
            "independent_human_usability_test":False,"correction":"evidence/review/PROVENANCE-CORRECTION.md"},
        "framework":{"installed_manifest_conflicts":conflicts,"native_executor_matches_canonical":sha(native_copy)==sha(native_source),
            "source_repair":"none","synthetic_return_events":"none","alternate_capture":"none",
            "removed_data_operations":"none","weakened_closure_check":False},
        "runtime":{"ports":listeners,"sandbox_connect_probe":"Raw codes retained; nonzero codes alone are not a host-side availability verdict.",
            "verified_host_stop":read(ROOT/"review/stop-process-check.json"),"application_browser_test":"not_run",
            "recording_and_replay":"not_run","screenshots":"Design stage only"},
        "exclusions":["Project .venv dependency binaries are not duplicated; requirements and install logs are retained.",
            "The session-secret file is not archived.","No publication or Git push was performed.",
            "Earlier canceled diagnostic attempts remain incomplete and are not passes.",
            "Source and complete gate 001 have separate identities; the archive does not invent an exact source match."]
    }
    (ARCHIVE/"ARCHIVE.json").write_text(json.dumps(identity,ensure_ascii=False,indent=2),encoding="utf-8")
    (ARCHIVE/"README.md").write_text(
        "# Stopped VibeLens Trial Archive\n\n"
        "Runtime mapping acceptance failed. No accept command was run.\n\n"
        "The scenario user was simulated by the coordinator AI. Forwarded text was actually received; this is not independent human usability evidence.\n\n"
        "- source/: current source at stop, including unchanged installed observer and viewer copies.\n"
        "- evidence/review/verify-001.json: complete failed gate for its earlier candidate.\n"
        "- evidence/stategraph/checks/observations.json and evidence/review/runtime-observations.json: original observations; ARCHIVE.json checks their correspondence to the completed gate.\n"
        "- evidence/review/framework-issue/: canonical reproduction, raw events, source hashes, and cause.\n"
        "- evidence/review/verify-002.json: interrupted attempt with no final result.\n"
        "- evidence/review/PROVENANCE-CORRECTION.md: authoritative simulated-user provenance correction.\n\n"
        "Do not combine the earlier complete gate with the later current source as if they were one accepted build. Check ARCHIVE.json and SHA256SUMS.json.\n",
        encoding="utf-8")
    hashes={path.relative_to(ARCHIVE).as_posix():sha(path) for path in sorted(ARCHIVE.rglob("*")) if path.is_file()}
    (ARCHIVE/"SHA256SUMS.json").write_text(json.dumps(hashes,ensure_ascii=False,indent=2),encoding="utf-8")
    archive_zip=ARCHIVE.with_suffix(".zip")
    with zipfile.ZipFile(archive_zip,"x",compression=zipfile.ZIP_DEFLATED,compresslevel=6) as package:
        for path in sorted(ARCHIVE.rglob("*")):
            if path.is_file():
                package.write(path,path.relative_to(ARCHIVE).as_posix())
    index={"directory":str(ARCHIVE),"zip":str(archive_zip),"zip_sha256":sha(archive_zip),
        "file_count":len(hashes)+1,"identity":identity}
    (ROOT/"review/archive-index.json").write_text(json.dumps(index,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps({"archive":str(ARCHIVE),"files":len(hashes)+1,"zip_sha256":index["zip_sha256"],
        "raw_gate_hash_matches":identity["completed_gate"]["wrapper_hash_matches"],
        "payload_matches":identity["completed_gate"]["raw_stdout_matches_saved_payload"],
        "installed_conflicts":conflicts,"ports":listeners,"accepted":identity["accepted_json_exists"]},ensure_ascii=False))
if __name__=="__main__":
    main()
