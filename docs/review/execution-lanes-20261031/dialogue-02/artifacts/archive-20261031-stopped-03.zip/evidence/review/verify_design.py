"""Retain actual design CLI and HTTP verification evidence."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT.parents[1] / "SoftwareStatusObserverSkill" / "skills" / "vibelens" / "scripts"
BASE_URL = "http://127.0.0.1:8973"
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONIOENCODING="utf-8")
REPORT = {"stage": "design_only", "checks": [], "business_implementation": "not_started"}

def run(name, script, *args):
    command = [sys.executable, "-B", str(SCRIPTS / script), *args]
    result = subprocess.run(command, cwd=str(ROOT), env=ENV, capture_output=True, encoding="utf-8", errors="replace")
    record = {"name": name, "command": command, "returncode": result.returncode, "stdout": result.stdout, "stderr": result.stderr}
    REPORT["checks"].append(record)
    (ROOT / "review" / (name + ".json")).write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    if result.returncode:
        raise RuntimeError(name + " failed; see its evidence file.")
    return json.loads(result.stdout)

run("discovery-validation-003", "requirements_dialogue.py", "validate", "--file", str(ROOT / "discovery.json"))
run("policy-validation-002", "bo_policy.py", "validate", "--root", str(ROOT), "--policy", "review/policy-draft.json", "--draft")
run("design-language", "bo_design.py", "language", "--root", str(ROOT), "--locale", "zh-CN", "--source", "codex://threads/01a191cb-bebd-71e0-a15e-939778e8fbca U001")
run("design-focus", "bo_design.py", "focus", "--root", str(ROOT), "--decision", "D_GRAPH_CONFIRM", "--label", "Confirm updated file review and access rules")
for endpoint in ["/graph", "/api/view", "/api/design"]:
    with urllib.request.urlopen(BASE_URL + endpoint, timeout=8) as response:
        raw = response.read()
        record = {"endpoint": endpoint, "status": response.status, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
        REPORT["checks"].append(record)
        if endpoint.startswith("/api/"):
            (ROOT / "review" / (endpoint.rsplit("/", 1)[-1] + "-snapshot.json")).write_bytes(raw)
preview = subprocess.run([sys.executable, "-B", str(SCRIPTS / "bo_design.py"), "preview", "--root", str(ROOT), "--url", BASE_URL + "/graph", "--out", "review/design-preview.md"], cwd=str(ROOT), env=ENV, capture_output=True, encoding="utf-8", errors="replace")
REPORT["checks"].append({"name": "design-preview", "returncode": preview.returncode, "stdout": preview.stdout, "stderr": preview.stderr})
if preview.returncode:
    raise RuntimeError("Preview failed")
request = (ROOT / "review/user-request-001.txt").read_text(encoding="utf-8").rstrip()
activation = run("control-activation", "bo_control.py", "activate", "--root", str(ROOT), "--url", BASE_URL, "--message", request)
REPORT["graph_url"] = activation.get("result", {}).get("graph_url")
REPORT["valid"] = True
(ROOT / "review/design-web-checks.json").write_text(json.dumps(REPORT, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps({"valid": True, "graph_url": REPORT["graph_url"], "stage": REPORT["stage"]}, ensure_ascii=False))
