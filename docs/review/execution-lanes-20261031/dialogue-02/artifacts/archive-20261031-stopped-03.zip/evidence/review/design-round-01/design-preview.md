# Business network draft

```mermaid
flowchart LR
  n0["登录后访问文件"]
  n1["审核通过"]
  n2["指定的接收人"]
  n3["待同事审核"]
  n4["同事审核"]
  n5["未通过后的处理待确认"]
  n6["分享给指定账号"]
  n7["登录"]
  n8["上传文件"]
  n6 -->|"指定接收账号"| n2
  n1 -->|"通过后才可分享；谁操作待确认"| n6
  n7 -->|"访问必须已登录"| n0
  n2 -->|"接收权限；其他角色权限待确认"| n0
  n7 -->|"上传入口"| n8
  n4 -->|"通过"| n1
  n4 -->|"未通过时的去向待确认"| n5
  n8 -->|"上传后交审"| n3
  n3 -->|"审核人安排待确认"| n4
  b0["AND · 登录且具备文件访问权限 (outside scope)"]
  b0 -.->|"Requires"| n0
  b1["AND · 登录且通过审核并具有分享资格 (outside scope)"]
  b1 -.->|"Requires"| n6
```

[Open the live graph](http://127.0.0.1:8973/graph)

This is a focused view. Dashed boundaries retain original relations; open Web for the complete graph.

Still to confirm:

- 审核人怎么确定：上传者每次指定一位同事，还是固定审核人？
- 权限怎么分：谁能发起分享？上传者、审核人和接收人分别可以查看文件信息、下载或再次分享到什么程度？
- 审核未通过后，直接结束这份文件的流程，还是允许重新提交审核？

Confirm this understanding in the conversation, or describe a correction. Viewing the graph is not confirmation.
