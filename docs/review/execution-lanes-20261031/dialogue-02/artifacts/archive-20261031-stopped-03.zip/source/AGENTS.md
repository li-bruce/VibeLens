# Project Integrity

This independent trial retains a developer graph, source bindings, and runtime evidence.

- Before editing, run `python observer_runtime/change_sync.py recall --root ABSOLUTE_PROJECT_PATH`.
- Run `python tooling/verify.py` before delivery; it includes the canonical change check.
- Preserve accepted baselines and independent expectations. Repair failures without weakening checks.
- VibeLens conversation guidance activates only after an explicit `$vibelens` request for that conversation. Never silently activate it elsewhere.
- Source, identifiers, comments, and canonical documentation use English. Preserve original Chinese dialogue in review evidence.
- Shared Skill/framework source and other projects are read-only. Do not publish.
