"""Read-only observation wiring separated from business authority."""
import json
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT / "observer_runtime"))
from bo_observer.observation.session import GraphSession
from bo_observer.adapters.python.bo_probe import BOProbe
from bo_observer.data.runtime import BODataRuntime
from bo_observer.policy.recording import record_evaluation
from bo_observer.observation.observation_scope import bo_internal
from bo_stategraph.workflow import file_context

class BOIntegration:
    def __init__(self, root, mode="on"):
        self.root, self.mode = root, mode
        self.session = GraphSession(root)
        self.evaluations = []
        sink = self.session.bo_sink
        if mode == "fault":
            sink = self.bo_broken_sink
        self.probe = BOProbe(self.session.project, self.session.manifest["build_id"],
            sink=sink, enabled=mode != "off", capacity=4096)
        config = json.loads((root / "bo_stategraph/databases.json").read_text(encoding="utf-8-sig"))
        self.data = BODataRuntime(self.probe, config)
        self.session.bo_bind_capture(scope_setter=self.probe.bo_set_scope,
            flush_capture=lambda: self.probe.flush(30), health=self.health)

    def bo_broken_sink(self, kind, payload):
        raise OSError("deliberate_observer_transport_fault")

    def health(self):
        return {**self.probe.bo_health(), "data_errors": self.data.bo_errors}

    def policy(self, report, entity):
        self.evaluations.append(report)
        record_evaluation(self.session.model["policy"], report, self.probe, entity=entity, attempt=entity)

    def state(self, row, node, transition):
        evidence = self.probe.record(node, "change", lambda: {"outputs": {
            "state": row["state"], "revision": row["revision"]}},
            entity=row["id"], attempt=row["id"], scope="entity", revision=row["revision"])
        if evidence:
            self.probe.snapshot(row["id"], row["state"], file_context(row), row["revision"], evidence,
                event=transition["event"], guards=transition["guards"], payload=transition["payload"])

    def close(self):
        self.probe.flush(30)
        self.probe.close()
        self.session.close()

def bo_snapshot_store(store):
    with bo_internal():
        return store.snapshots()
