"""Optional developer-observation integration."""
