# Team File Review Trial

This independent trial is stopped after a shared invocation-closure failure. Runtime mapping acceptance has not passed, and this version was not accepted.

- Runtime choice: Python and SQLite, explicitly requested by the user.
- Execution mode: declaration-driven (`drive`), explicitly requested by the user.
- Canonical discovery: `discovery.json`.
- Actual dialogue and verification evidence: `review/`.
- Scenario business rules were confirmed by a simulated user played by the coordinating AI. This is not independent human usability evidence.
- The VibeLens repository, installed copies, and other projects are read-only.
- No deployment or publication is authorized.

Implementation and scripted HTTP/SQLite observations are retained. The complete failed gate and the later interrupted verification have different source identities. See `review/ARCHIVE-BOUNDARY.md`, `review/STOPPED.md`, and `review/PROVENANCE-CORRECTION.md` before interpreting evidence. The local services are stopped. Future retesting belongs in a new independent conversation after the maintained framework is repaired.
