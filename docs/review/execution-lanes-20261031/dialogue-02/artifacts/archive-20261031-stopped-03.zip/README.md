# Stopped VibeLens Trial Archive

Runtime mapping acceptance failed. No accept command was run.

The scenario user was simulated by the coordinator AI. Forwarded text was actually received; this is not independent human usability evidence.

- source/: current source at stop, including unchanged installed observer and viewer copies.
- evidence/review/verify-001.json: complete failed gate for its earlier candidate.
- evidence/stategraph/checks/observations.json and evidence/review/runtime-observations.json: original observations; ARCHIVE.json checks their correspondence to the completed gate.
- evidence/review/framework-issue/: canonical reproduction, raw events, source hashes, and cause.
- evidence/review/verify-002.json: interrupted attempt with no final result.
- evidence/review/PROVENANCE-CORRECTION.md: authoritative simulated-user provenance correction.

Do not combine the earlier complete gate with the later current source as if they were one accepted build. Check ARCHIVE.json and SHA256SUMS.json.
