import { stepHierarchy } from "./step-hierarchy.js";
/** Viewer coordinator: connect API snapshots, graph presentation and user actions.
 * Feature modules own drawing, source/edge/change panels, layout, evidence and
 * persistence. This module owns view selection and lifecycle; it never executes
 * application commands or rewrites recorded facts.
 */
import { renderStepChanges } from "./change-panel.js";
import { LiveTrace } from "./trace-session.js";
import { parentEvent } from "./trace-evidence.js";
import { RecordingTimeline, cleanTimeline } from "./recording-timeline.js";
import { renderEdgeDetail } from "./edge-panel.js";
import { createDetailPanel } from "./detail-panel.js";
import { LayerRuler } from "./layer-ruler.js";
import { cleanRoute } from "./edge-routing.js";
import { cleanReplaySelection, selectedReplayPlan, nextReplayIndex } from "./replay-selection.js";
import { SemanticView } from "./semantic-view.js";
import { prepareSpatialHierarchy, planarSeeds } from "./spatial-model.js";
import { fitVisibleHierarchy } from "./containment-view.js";
import {
  layers,
  cleanLayers,
  layerSlice,
  cleanLayerVisibility,
  visibilityForView,
  savedLayerVisibility,
  implementationFacets,
  layerOf,
  implementationFacet,
} from "./graph-layers.js";
import { spatialLegend } from "./spatial-geometry.js";
import { SpatialRenderer } from "./spatial-renderer.js";
import { captureRoots } from "./capture-scope.js";
import { conceptActivityIds } from "./concept-observation.js";
import { declarationNodes } from "./graph-inventory.js";
import { t as boTranslate } from "./i18n.js";
import {
  locale,
  translateShell,
  restoreLocale,
  saveLocale,
  localeURL,
  chooseLocale,
  storedLocale,
} from "./i18n.js";
import { iconButton, installIcons, createContextMenu } from "./controls.js";
import { createGraphRenderer, nodePoint, bezierAt } from "./renderer.js";
import { pickRoutes } from "./route-picking.js";
import { createConversationFocus, discussionContext } from "./conversation.js";
import {
  createControlBridge,
  controlProjection,
  requireVisibleControlNodes,
} from "./conversation-controls.js";
import { projectStorage } from "./preferences.js";
import { createPoller } from "./polling.js";
import { migrateNodeIds } from "./layout.js";
import {
  projectLayoutKey,
  graphVersion,
  recordingMatches,
  connectionStatus,
} from "./view-lifecycle.js";
import { databaseWarning } from "./data-layer.js";
import { CodeLayer, withCodeGraph, codeTypes, codeRelations, codeSummary } from "./code-layer.js";
import {
  executionIds,
  layoutGraph,
  selectedConfiguration,
  configurations,
  stateLabels,
  phaseLabel,
  nodeTypes,
  sourceBinding,
  parameterSummary,
} from "./graph-core.js";
import {
  readLayout,
  writeLayout,
  placeIncremental,
  setPosition,
  togglePin,
  calculateLayout,
  applyLayout,
  topologyKey,
  GraphGesture,
  annotationFor,
  displayName,
  setAnnotation,
  pickHit,
  searchNodes,
  ancestorsToReveal,
  selectionContext,
  refreshHierarchy,
  relationStyles,
  settleExpansion,
  presentationGraph,
  filterNode,
  cleanFilters,
  emptyFilters,
  renderRevision,
  elementCoverage,
} from "./layout.js";
import { presets, profileFor, cleanProfile, matchingNodes, sharedMemberships } from "./analysis.js";
import { legendGlyph, legendRelation, meanings } from "./glyphs.js";
import { timeline, frame, eventLabel, transferEdges, recordingRequest } from "./recording.js";
import { namedView } from "./graph-names.js";
import { boDisplayValue, boStepPlan, boStepDetail, boTransferLabel } from "./replay-steps.js";
const codeLayer = new CodeLayer();
let codeLimit = 400;
const $ = (id) => document.getElementById(id),
  app = new PIXI.Application(),
  scene = new PIXI.Container();
// The bundled ELK entry defaults to its Node fallback unless a factory is supplied.
const layoutWorker = new Worker(new URL("./elk-worker.min.js", import.meta.url));
const elk = new ELK({ workerFactory: () => layoutWorker }),
  gesture = new GraphGesture();
let version = "live",
  caseChoice = "live",
  choice = "latest",
  step = "latest",
  view = null,
  graph = null,
  displayGraph = null,
  selected = null;
let scale = 1,
  pan = { x: 0, y: 0 },
  expanded = new Set(),
  preferences = null,
  storageKey = null,
  first = true,
  lastKey = "",
  dirty = false;
let layoutEpoch = 0,
  layoutBusy = false,
  layoutError = null,
  undo = null,
  detailMode = null,
  saveTimer = null;
let focusContext = {
    active: false,
    nodes: new Set(),
    edges: new Set(),
    regions: new Set(),
  },
  renderedEdges = [],
  presentation = null;
let analysisId = "overview",
  analysisWasSaved = false,
  analysisSettings = null,
  analysisKey = null,
  analysisOverride = null;
let recording = null,
  replayReturnAnalysis = null,
  replayItems = [],
  replayIndex = 0,
  playTimer = null,
  recordBusy = false,
  recordLoading = false,
  recordLoadId = 0,
  recordActive = false,
  lastRecordPoll = 0,
  latestLive = null;
const liveTrace = new LiveTrace();
let liveTraceSource = null;
let animationFrame = null,
  animationUntil = 0,
  animatedIds = [],
  lastLiveEvent = null;
let heldTimer = null,
  selectedLayer = null;
let boPlan = [],
  boFullPlan = [],
  boPlanKey = "",
  boDetail = null,
  boTransfers = new Map();
const edgePaths = new Map(),
  animationLayer = new PIXI.Container(),
  animationDot = new PIXI.Graphics();
let drawFrame = null,
  disposed = false,
  contextLost = false;
const hits = [],
  metrics = { nodes: 0, edges: 0, texts: 0 };
const detailPanel = createDetailPanel({
  read: () => ({
    view,
    graph,
    preferences,
    selected,
    mode: detailMode,
    choice,
    step,
    version,
    recording: recording?.transient && recording.id.startsWith("live:") ? null : recording,
    scale,
    pan,
    screen: app.screen,
  }),
  point,
});
let legacyStorage;
try {
  legacyStorage = window.localStorage;
} catch {}
const conversationControls = createControlBridge({
  apply: applyConversationControl,
});
const storage = await projectStorage(
  conversationControls.legacy(legacyStorage),
  (message) => {
    if ($("layout-status")) $("layout-status").textContent = message;
  },
  conversationControls.request,
);
const restoredLocaleURL = restoreLocale(storage, window.location.href);
if (restoredLocaleURL) window.location.replace(restoredLocaleURL);
translateShell(document);
installIcons(document);
const recordingTimeline = new RecordingTimeline($("recording-timeline"), {
  onPause: () => stopPlayback(true),
  onSeek: (raw, locate) => {
    stopPlayback();
    if (!recording && liveTraceSource) {
      recording = { ...liveTraceSource, transient: true };
      replayItems = timeline(recording);
      boPlanKey = "";
      $("replay").hidden = false;
      document.body.classList.add("is-replay");
      for (const id of ["version", "case", "attempt", "step"]) $(id).disabled = true;
      updateAnalysisOptions();
      $("code-local").disabled = true;
      $("code-more").hidden = true;
    }
    seek(raw, locate);
  },
  onLive: () => leaveRecording(),
  onRange: (patch) => {
    if (!recording && patch.loop && liveTraceSource)
      recordingTimeline.callbacks.onSeek(recordingTimeline.raw, false);
    changeReplaySelection(patch);
  },
  onSettings: (settings) => {
    if (!analysisSettings) return;
    analysisSettings.timeline = settings;
    if (recording) boUpdateReplay();
    else boUpdateLiveTimeline();
    saveSoon();
  },
});
$("replay-timeline").onclick = () =>
  recordingTimeline.configure({ visible: !analysisSettings.timeline.visible });
// Tool rows wrap with language and viewport width. Reserve their actual height
// for legends and replay changes instead of overlapping them with fixed offsets.
const toolObserver = new ResizeObserver((entries) => {
  for (const entry of entries) {
    const property =
      entry.target.id === "layer-controls" ? "--layer-ruler-width" : "--view-tools-height";
    $("viewport").style.setProperty(
      property,
      (entry.target.id === "layer-controls" ? entry.contentRect.width : entry.contentRect.height) +
        "px",
    );
  }
});
toolObserver.observe(document.querySelector(".view-tools"));
toolObserver.observe($("layer-controls"));
const contextMenu = createContextMenu($("graph-menu"));
$("language").value = locale();
$("language").addEventListener("change", async (event) => {
  event.target.disabled = true;
  try {
    save();
    await saveLocale(storage, event.target.value);
    window.location.assign(localeURL(window.location.href, event.target.value));
  } catch (error) {
    $("layout-status").textContent = String(error.message);
    event.target.value = locale();
    event.target.disabled = false;
  }
});
await app.init({
  resizeTo: $("viewport"),
  preference: "webgl",
  antialias: true,
  background: 0xf6f8fa,
  resolution: Math.min(devicePixelRatio, 1.5),
  autoDensity: true,
  autoStart: false,
});
$("canvas-host").appendChild(app.canvas);
app.stage.addChild(scene, animationLayer);
animationLayer.addChild(animationDot);
app.canvas.setAttribute("aria-hidden", "true");
$("renderer").textContent = "PixiJS / WebGL · ELK";
const renderer = createGraphRenderer({
  PIXI,
  app,
  scene,
  metrics,
  hits,
  edgePaths,
  onMetrics: (data) => Object.assign($("renderer").dataset, data),
  onRoutes: (stats) => {
    updateRouteStatus(stats);
    if (!stats.busy || stats.total <= 2000) {
      schedule();
      updateSemanticGeometry();
    }
  },
});
let spatial = null,
  semanticFrame = 0,
  semanticTimer = null;
/** Throttle movement updates, but always publish the final camera geometry. */
function spatialGeometry() {
  clearTimeout(semanticTimer);
  if (disposed || !graph || !spatialActive()) return;
  const remaining = 90 - (performance.now() - semanticFrame);
  if (remaining > 0) {
    semanticTimer = setTimeout(spatialGeometry, remaining);
    return;
  }
  semanticFrame = performance.now();
  updateRouteStatus(spatial?.diagnostics.routeSolver);
  updateSemanticGeometry();
  positionDetail();
}
const semanticView = new SemanticView($("semantic"), $("semantic-edges"), {
  onSelect: select,
  onEdge: showEdge,
});
const spatialActive = () => analysisSettings?.layers?.enabled === true;
function updateSpatial() {
  if (!spatialActive() || !graph) return;
  if (!spatial)
    spatial = new SpatialRenderer($("canvas-host"), {
      onSelect: (id) => {
        $("viewport").focus({ preventScroll: true });
        select(id);
      },
      onToggle: toggle,
      onEdge: (edge) => {
        $("viewport").focus({ preventScroll: true });
        showEdge(edge);
      },
      onSave: saveSoon,
      onRender: spatialGeometry,
      onError: (message) => {
        $("layout-status").textContent = message;
      },
      onLayer: (id) => changeLayers([id]),
      onMenu: (hit, x, y) => {
        select(hit?.id || hit?.region || null);
        if (hit?.edge) selectedEdge = hit.edge.id;
        openSelectionMenu(x, y);
      },
    });
  spatial.update({
    graph: displayGraph,
    presentation,
    preferences,
    selected,
    focusContext,
    settings: cleanLayers(analysisSettings.layers),
    scope: storageKey,
    boDetail,
    boTransfers,
    routing: cleanRoute(analysisSettings.routing),
  });
}
function point(box) {
  if (spatialActive()) {
    const p = spatial?.screenNode(box.id);
    if (p) return { x: (p.x - pan.x) / scale, y: (p.y - pan.y) / scale };
  }
  return nodePoint(displayGraph || graph, presentation, displayGraph?.byId.get(box.id) || box);
}
/** Layer names remain readable; selection, visibility and height are independent. */
const layerRuler = new LayerRuler($("layer-controls"), {
  change: (config) => {
    if (!analysisSettings || !graph) return;
    analysisSettings.layers = cleanLayers(config);
    updateLayerControls();
    updatePresentation();
    updateSemantic();
    schedule();
    saveSoon();
  },
  select: (id) => {
    select(null);
    selectedLayer = id;
    updateLayerControls();
  },
});
function updateLayerControls() {
  const config = cleanLayers(analysisSettings?.layers),
    mode = config.enabled ? "3D" : "2D";
  $("layered-toggle").textContent = mode;
  $("layer-gap").value = config.gap;
  $("layer-gap").disabled = !config.enabled;
  $("layer-drawer").classList.toggle("is-compact", config.compact);
  $("layers-toggle").setAttribute("aria-expanded", String(!config.compact));
  $("layered-toggle").setAttribute("aria-pressed", String(config.enabled));
  const action = boTranslate(config.enabled ? "Switch to 2D" : "Switch to 3D");
  $("layered-toggle").title = action;
  $("layered-toggle").setAttribute("aria-label", action);
  layerRuler.render(config, selectedLayer);
  $("layers-all").setAttribute("aria-pressed", String(config.visible.length === layers.length));
  $("undo-layout").disabled = !undo || undo.mode !== mode;
  $("edge-routing").value = cleanRoute(analysisSettings?.routing);
  updateLegendMode();
}
function changeLayers(visible) {
  if (!analysisSettings || !graph) return;
  stopAnimation();
  analysisSettings.layers = cleanLayers({
    ...analysisSettings.layers,
    only: "all",
    visible,
  });
  updateLayerControls();
  updatePresentation();
  updateSemantic();
  schedule();
  save();
}
$("layers-toggle").onclick = () => {
  if (!analysisSettings) return;
  const config = cleanLayers(analysisSettings.layers);
  analysisSettings.layers = { ...config, compact: !config.compact };
  updateLayerControls();
  save();
};
$("layer-gap").oninput = () => {
  if (!analysisSettings || !graph) return;
  analysisSettings.layers = cleanLayers({
    ...analysisSettings.layers,
    gap: Number($("layer-gap").value),
  });
  updateLayerControls();
  updateSpatial();
  updateSemantic();
  schedule();
  saveSoon();
};
$("layers-all").onclick = () => {
  analysisSettings.layers.facets = [...implementationFacets];
  changeLayers(layers.map((layer) => layer.id));
};
$("edge-routing").onchange = (event) => {
  analysisSettings.routing = cleanRoute(event.target.value);
  updateSpatial();
  schedule();
  save();
};
$("layered-toggle").onclick = () => {
  if (!analysisSettings || !graph) return;
  stopAnimation();
  contextMenu.close();
  save();
  const config = cleanLayers(analysisSettings.layers);
  analysisSettings.layers = {
    ...config,
    enabled: !config.enabled,
    camera: "top",
  };
  if (!analysisSettings.layers.enabled) project();
  updateLayerControls();
  updatePresentation();
  updateSemantic();
  if (!analysisSettings.layers.enabled && preferences.camera) {
    pan = { x: preferences.camera.x, y: preferences.camera.y };
    scale = preferences.camera.scale;
    schedule();
  } else fit();
  save();
};
$("top-view").onclick = () => {
  if (analysisSettings)
    analysisSettings.layers = {
      ...cleanLayers(analysisSettings.layers),
      camera: "top",
    };
  fit();
};
let legendMode = null;
function updateLegendMode() {
  const mode = spatialActive() ? "3D" : "2D";
  if (legendMode === mode) return;
  legendMode = mode;
  $("legend-mode").textContent = mode;
  $("legend-panel").dataset.mode = mode;
  for (const row of document.querySelectorAll("[data-legend-node]")) {
    const type = row.dataset.legendNode;
    let glyph;
    if (mode === "3D") {
      glyph = document.createElement("img");
      glyph.src = spatialLegend(nodeTypes).get(type);
      glyph.alt = "";
      glyph.dataset.glyph = type;
      glyph.dataset.mode = "3D";
      glyph.dataset.geometry = "webgl";
    } else glyph = legendGlyph(type, nodeTypes[type]);
    row.firstElementChild?.replaceWith(glyph);
  }
}
function updatePresentation() {
  const filters = cleanFilters(preferences.filters);
  displayGraph = layerSlice(graph, cleanLayers(analysisSettings?.layers), {
    hiddenNodes: filters.hiddenNodes,
    hiddenEdges: filters.hiddenEdges,
    edgeTypes: filters.edges,
    nodeAllowed: (node) =>
      filterNode(node, graph.all, filters) || filterNode(node, graph.all, filters, true),
    cacheKey: JSON.stringify(filters),
  });
  presentation = presentationGraph(displayGraph, preferences.filters);
  // Refit from this view's visible bodies. The complete layout and its saved
  // anchors remain available when the user restores a hidden node or layer.
  ({ graph: displayGraph, presentation } = fitVisibleHierarchy(displayGraph, presentation));
  renderedEdges = presentation.edges;
  const visibleTypes = new Set(
    graph.boxes
      .filter((box) => presentation.glyphs.has(box.id) || presentation.regions.has(box.id))
      .map((box) => box.type),
  );
  const visibleRelations = new Set(renderedEdges.map((edge) => edge.type));
  $("key-legend").hidden = !displayGraph.boxes.some(
    (box) => box.node.data_metadata?.primary_key === true && presentation.glyphs.has(box.id),
  );
  for (const item of document.querySelectorAll("[data-legend-node]"))
    item.hidden = !visibleTypes.has(item.dataset.legendNode);
  for (const item of document.querySelectorAll("[data-legend-edge]"))
    item.hidden = !visibleRelations.has(item.dataset.legendEdge);
  $("empty").hidden = !!(presentation.glyphs.size + presentation.regions.size);
  if (!$("empty").hidden)
    $("empty").textContent = boTranslate("No matching nodes. Change the view or filters.");
}
function draw() {
  dirty = false;
  drawFrame = null;
  if (!graph || disposed || contextLost || document.hidden) return;
  focusContext = selected
    ? selectionContext(graph, selected)
    : discussionContext(graph, conversation.ids);
  updatePresentation();
  app.canvas.hidden = spatialActive();
  if (spatialActive()) {
    updateSpatial();
    spatial.setVisible(true);
    $("renderer").textContent = "Three.js / WebGL · 3D force layout";
    $("zoom").value = "3D";
    positionDetail();
    return;
  }
  spatial?.setVisible(false);
  $("renderer").textContent = "PixiJS / WebGL · ELK";
  preferences.routing = cleanRoute(analysisSettings.routing);
  renderer.draw({
    graph: displayGraph,
    presentation,
    focusContext,
    preferences,
    selected,
    scale,
    pan,
    boDetail,
    boTransfers,
    formatChange: boChangeText,
    formatValue: boText,
    contextLost,
  });
  updateRouteStatus(renderer.routing);
  app.renderer.render(app.stage);
  $("zoom").value = Math.round(scale * 100) + "%";
  updateSemanticGeometry();
  positionDetail();
}
function schedule() {
  if (!dirty && !disposed && !contextLost && !document.hidden) {
    dirty = true;
    drawFrame = requestAnimationFrame(draw);
  }
}
function updateRouteStatus(stats = {}) {
  const element = $("route-status");
  element.hidden = !stats.busy && !stats.unresolved && !stats.error;
  element.textContent = stats.error
    ? boTranslate("Routing unavailable")
    : stats.busy
      ? boTranslate("Routing {0}/{1}", stats.routed || 0, stats.total || 0)
      : boTranslate("{0} routes blocked", stats.unresolved);
  element.title = stats.error || (stats.failures || []).join("\n");
}
function save() {
  if (!preferences) return;
  saveAnalysis();
  preferences.expanded = [...expanded];
  if (spatialActive() && spatial?.scope === storageKey) preferences.spatial = spatial.snapshot();
  if (!analysisSettings?.layers?.enabled) preferences.camera = { x: pan.x, y: pan.y, scale };
  preferences.focus = selected;
  const saved = writeLayout(storage, storageKey, preferences);
  if (!layoutBusy)
    $("layout-status").textContent =
      layoutError || (saved ? storage.status() : boTranslate("This view could not be saved"));
}
function saveSoon() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(save, 180);
}
window.addEventListener("pagehide", (event) => {
  clearTimeout(semanticTimer);
  save();
  storage.flush();
  clearTimeout(saveTimer);
  poller.pause();
  cancelAnimationFrame(drawFrame);
  dirty = false;
  if (!event.persisted) {
    toolObserver.disconnect();
    disposed = true;
    poller.close();
    stopPlayback();
    stopAnimation();
    layoutWorker.terminate();
    resizeObserver.disconnect();
    spatial?.dispose();
    renderer.dispose();
    recordingTimeline.dispose();
    renderer.clear();
    app.destroy(true, { children: true });
  }
});
document.addEventListener("visibilitychange", () => {
  // Browsers can emit this after pagehide has already destroyed the GPU objects.
  if (disposed) return;
  if (document.hidden) {
    stopPlayback();
    stopAnimation();
    poller.pause();
    cancelAnimationFrame(drawFrame);
    dirty = false;
  } else {
    schedule();
    poller.run();
  }
});
window.addEventListener("pageshow", (event) => {
  if (event.persisted) {
    schedule();
    poller.run();
  }
});
app.canvas.addEventListener("webglcontextlost", (event) => {
  event.preventDefault();
  contextLost = true;
  cancelAnimationFrame(drawFrame);
  dirty = false;
  $("connection").textContent = boTranslate("Graphics connection lost; recovering");
});
app.canvas.addEventListener("webglcontextrestored", () => {
  contextLost = false;
  schedule();
});
function cancelLayout() {
  layoutEpoch++;
  layoutBusy = false;
  layoutError = null;
  $("arrange").disabled = false;
}
function project() {
  if (!view) return;
  if (!recording && latestLive) view = withCodeGraph(latestLive, codeLayer.slice);
  else if (recording) {
    // Saved replay may use its captured file tree, never today's lazy AST slice.
    view = withCodeGraph(view, recording.transient ? codeLayer.slice : null);
  }
  view = namedView(view, analysisSettings?.explainedNames !== false);
  preferences.nameMode = view.model.presentation.name_mode;
  $("name-mode").disabled = false;
  $("name-mode").setAttribute("aria-checked", String(preferences.nameMode !== "source"));
  const renamed = migrateNodeIds(
    preferences,
    view.model.presentation?.node_aliases,
    view.model.presentation?.edge_aliases,
  );
  expanded = new Set([...expanded].map((id) => renamed[id] || id));
  selected = renamed[selected] || selected;
  const profile = currentProfile();
  graph = layoutGraph(view, expanded, new Set(), new Map(), choice, step, {
    hiddenNodes: preferences.filters.hiddenNodes,
    hiddenEdges: preferences.filters.hiddenEdges,
    include: (n) =>
      n.filter_context ||
      analysisSettings?.advanced ||
      (["implementation", "code", "project", "api", "functions"].includes(analysisId) &&
        !!n.code_role) ||
      (!["python-ast", "source-ast"].includes(n.origin) && n.analysis_level !== "advanced") ||
      annotationFor(preferences, n.id).core,
    memberships: sharedMemberships(view.model),
    ...(!profile.hierarchical ||
    profile.scope !== "all" ||
    profile.query ||
    profile.nodes.length < 8 ||
    profile.depth !== "all"
      ? {
          match: (all, events, status, relations) =>
            matchingNodes(all, view, events, profile, status, relations),
        }
      : {}),
  });
  for (const b of graph.boxes) {
    b.baseHeight = b.h;
    b.h += annotationFor(preferences, b.node.referenceOf || b.id).note ? 22 : 0;
  }
  if (spatialActive()) prepareSpatialHierarchy(graph, preferences);
  else placeIncremental(graph, preferences);
  updatePresentation();
  if (selected && !graph.byId.has(selected))
    selected = ancestorsToReveal(graph.all, selected).find((id) => graph.byId.has(id)) || null;
  updateFilters();
  updateSemantic();
  updateActions();
  updateDetail();
  updateEdgeDetail();
  if (recording) boUpdateReplay();
  else boUpdateLiveTimeline();
  schedule();
}
async function arrange(initial = false) {
  if (!graph) return;
  if (spatialActive()) {
    updateSpatial();
    if (!initial) {
      undo = { mode: "3D", snapshot: spatial.snapshot() };
      $("undo-layout").disabled = false;
    }
    const epoch = ++layoutEpoch,
      scope = storageKey,
      key = topologyKey(graph);
    layoutBusy = true;
    try {
      const positions = await calculateLayout(
        elk,
        graph,
        preferences,
        preferences.algorithm || "cluster",
      );
      if (epoch !== layoutEpoch || scope !== storageKey || key !== topologyKey(graph)) return;
      // Arrange uses the same subtree/type solver in both dimensions. The 3D
      // camera and manually saved 2D positions remain independent preferences.
      spatial.layout(true, planarSeeds(graph, positions));
    } catch (error) {
      console.error(error);
      layoutError = boTranslate("Layout failed; keeping previous positions");
    } finally {
      if (epoch === layoutEpoch) layoutBusy = false;
    }
    return;
  }
  const epoch = ++layoutEpoch,
    key = topologyKey(graph),
    scope = storageKey,
    algorithm = preferences.algorithm || "cluster";
  const previous = JSON.stringify(preferences.positions),
    camera = { scale, pan: { ...pan } };
  layoutBusy = true;
  layoutError = null;
  $("arrange").disabled = true;
  $("layout-status").textContent = boTranslate("Arranging\u2026");
  try {
    const positions = await calculateLayout(elk, graph, preferences, algorithm);
    if (epoch !== layoutEpoch || scope !== storageKey || !graph || key !== topologyKey(graph))
      return;
    undo = { mode: "2D", positions: previous, camera };
    $("undo-layout").disabled = false;
    applyLayout(graph, preferences, positions);
    preferences.algorithm = algorithm;
    fit();
    if (conversation.ids.length) frameDiscussion();
  } catch (error) {
    if (epoch === layoutEpoch) {
      console.error(error);
      layoutError = boTranslate("Layout failed; keeping previous positions");
    }
  } finally {
    if (epoch === layoutEpoch) {
      layoutBusy = false;
      $("arrange").disabled = false;
      save();
      updateActions();
      schedule();
    }
  }
}
function plotArea() {
  const top = 42,
    tools = document.querySelector(".view-tools").offsetHeight + 24,
    bottom = $("step-changes").hidden
      ? tools
      : Math.min(app.screen.height * 0.6, $("step-changes").offsetHeight + tools + 12);
  return {
    top,
    height: Math.max(60, app.screen.height - top - bottom),
    width: Math.max(60, app.screen.width - 45),
  };
}
function fit() {
  if (!graph) return;
  if (spatialActive()) {
    updatePresentation();
    updateSpatial();
    spatial.fit();
    schedule();
    saveSoon();
    return;
  }
  refreshHierarchy(graph);
  updatePresentation();
  const area = plotArea();
  scale = Math.max(
    0.12,
    Math.min(1.05, area.width / displayGraph.width, area.height / displayGraph.height),
  );
  pan = {
    x: (app.screen.width - displayGraph.width * scale) / 2 - displayGraph.minX * scale,
    y: area.top + (area.height - displayGraph.height * scale) / 2 - displayGraph.minY * scale,
  };
  schedule();
  saveSoon();
}
function zoom(factor, point = { x: app.screen.width / 2, y: app.screen.height / 2 }) {
  if (spatialActive()) {
    spatial?.zoom(factor);
    return;
  }
  const next = Math.max(0.12, Math.min(3, scale * factor));
  pan.x = point.x - ((point.x - pan.x) * next) / scale;
  pan.y = point.y - ((point.y - pan.y) * next) / scale;
  scale = next;
  schedule();
  saveSoon();
}
function select(id) {
  selectedLayer = null;
  if (analysisSettings) layerRuler.render(analysisSettings.layers, null);
  selected = id;
  semanticView.select(id);
  selectedEdge = null;
  detailMode = null;
  $("node-details").hidden = true;
  $("edge-details").hidden = true;
  updateActions();
  schedule();
  saveSoon();
}
function clearCanvasFocus() {
  conversation.clear();
  select(null);
}
function frameDiscussion() {
  if (spatialActive()) {
    updateSpatial();
    spatial?.fit(conversation.ids[0]);
    return;
  }
  const boxes = [...discussionContext(graph, conversation.ids).nodes]
    .map((id) => graph?.byId.get(id))
    .filter(Boolean);
  if (!boxes.length) return;
  const bounds = boxes.map((b) => graph.regions.find((r) => r.id === b.id) || b);
  const left = Math.min(...bounds.map((b) => b.x)) - 55,
    top = Math.min(...bounds.map((b) => b.y)) - 55;
  const width = Math.max(...bounds.map((b) => b.x + b.w)) - left + 55,
    height = Math.max(...bounds.map((b) => b.y + b.h)) - top + 55;
  const area = plotArea();
  scale = Math.max(0.12, Math.min(1.1, area.width / width, area.height / height));
  pan = {
    x: (app.screen.width - width * scale) / 2 - left * scale,
    y: area.top + (area.height - height * scale) / 2 - top * scale,
  };
  schedule();
}
function showDiscussion(ids) {
  if (!graph) return;
  if (analysisId !== "overview") changeAnalysis("overview");
  for (const id of ids) for (const parent of ancestorsToReveal(graph.all, id)) expanded.add(parent);
  if (
    ids.some(
      (id) =>
        graph.all.get(id)?.analysis_level === "advanced" ||
        ["python-ast", "source-ast"].includes(graph.all.get(id)?.origin),
    )
  )
    analysisSettings.advanced = true;
  selected = null;
  project();
  frameDiscussion();
}
function toggle(id) {
  if (!graph?.children.has(id)) return;
  cancelLayout();
  selected = id;
  const opening = !expanded.has(id);
  if (opening) expanded.add(id);
  else expanded.delete(id);
  project();
  if (opening) {
    if (!spatialActive()) settleExpansion(graph, preferences, id);
    updatePresentation();
    focusSelection();
  }
  save();
  schedule();
}
function pin() {
  if (!selected) return;
  cancelLayout();
  togglePin(graph, preferences, selected);
  if (spatialActive()) spatial?.setPinned(selected, !!graph.byId.get(selected)?.pinned);
  updateActions();
  save();
  schedule();
}
function updateHierarchyPath() {
  const host = $("hierarchy-path");
  host.replaceChildren();
  const home = document.createElement("button");
  home.textContent = boTranslate("Overview");
  home.onclick = () => $("collapse").click();
  host.append(home);
  if (!graph?.byId.has(selected)) return;
  const path = [...ancestorsToReveal(graph.all, selected).reverse(), selected];
  for (const id of path) {
    const node = graph.all.get(id);
    if (!node) continue;
    const separator = document.createElement("span");
    separator.textContent = "›";
    const button = document.createElement("button");
    button.textContent = displayName(node, preferences);
    if (id === selected) button.setAttribute("aria-current", "location");
    button.onclick = () => {
      select(id);
      focusSelection();
    };
    host.append(separator, button);
  }
}
function focusSelection() {
  if (!graph?.byId.has(selected)) return;
  if (spatialActive()) {
    updateSpatial();
    spatial?.fit(selected);
    return;
  }
  const context = selectionContext(graph, selected),
    boxes = [
      ...graph.boxes.filter((b) => context.branch.has(b.id)),
      ...graph.regions.filter((r) => context.branch.has(r.id)),
    ];
  const minX = Math.min(...boxes.map((b) => b.x)) - 55,
    minY = Math.min(...boxes.map((b) => b.y)) - 55;
  const width = Math.max(...boxes.map((b) => b.x + b.w)) - minX + 55,
    height = Math.max(...boxes.map((b) => b.y + b.h)) - minY + 55;
  const area = plotArea();
  scale = Math.max(0.12, Math.min(1.15, area.width / width, area.height / height));
  pan = {
    x: (app.screen.width - width * scale) / 2 - minX * scale,
    y: area.top + (area.height - height * scale) / 2 - minY * scale,
  };
  schedule();
  saveSoon();
}
function updateActions() {
  const b = graph?.byId.get(selected),
    binding = sourceBinding(view, graph?.all, selected);
  $("code-local").disabled =
    view?.stage === "design" ||
    !!recording ||
    ["project", "code", "api"].includes(analysisId) ||
    (!b && !analysisSettings?.codeFocus);
  $("reference-origin").hidden = !b?.node.referenceOf;
  $("core-toggle").disabled = !b;
  const core = b && annotationFor(preferences, b.node.referenceOf || b.id).core;
  $("core-toggle").textContent = core ? boTranslate("\u2605 Core") : boTranslate("\u2606 Core");
  $("core-toggle").setAttribute("aria-pressed", String(!!core));
  updateHierarchyPath();
  $("focus-selection").disabled = !b;
  $("node-expand").disabled = !b?.kids.length;
  $("node-expand").textContent = b?.open ? boTranslate("Collapse") : boTranslate("Expand");
  $("pin").disabled = !b;
  $("pin").textContent = b?.pinned ? boTranslate("Unpin") : boTranslate("Pin node");
  $("annotate").disabled = !b;
  $("hide-node").disabled = !b;
  $("details").disabled = !b;
  $("details").textContent = boTranslate(
    b?.node.concept_definition ? "Definition" : "Parameter values",
  );
  $("source").disabled = !binding;
  $("selection-menu").hidden = !b && !selectedEdge;
  $("selection").textContent = b
    ? `${nodeTypes[b.type].label} · ${displayName(b.node, preferences)}` +
      (b.open ? boTranslate(" \u00B7 Drag empty space inside a region to move its group") : "") +
      (binding ? ` · ${binding.path}:${binding.line}` : "")
    : boTranslate("Right-click a node or edge for actions.");
}
/** Both rendering modes expose the same keyboard and screen-reader graph. */
function updateSemantic() {
  semanticView.render({
    graph,
    presentation,
    preferences,
    selected,
    spatial: spatialActive(),
  });
}
function updateSemanticGeometry() {
  semanticView.geometry({
    graph,
    presentation,
    displayGraph,
    preferences,
    selected,
    focusContext,
    discussion: conversation.ids,
    spatial: spatialActive() ? spatial : null,
    canvas: spatialActive() && spatial ? spatial.canvas : app.canvas,
    point,
    scale,
    pan,
  });
}
let selectedEdge = null,
  edgeChoices = [];
function showEdge(edge) {
  select(null);
  selectedEdge = edge.id;
  edgeChoices = edge.alternatives || [];
  updateActions();
  updateEdgeDetail();
}
function updateEdgeDetail() {
  const shown = renderEdgeDetail({
    graph,
    displayGraph,
    preferences,
    edges: renderedEdges,
    selected: selectedEdge,
    choices: edgeChoices,
    screen: app.screen,
    scale,
    pan,
    onChoose: showEdge,
    onReveal: (witness) => {
      const config = cleanLayers(analysisSettings.layers);
      const nodes = witness.nodes.map((id) => graph.all.get(id)).filter(Boolean);
      analysisSettings.layers = cleanLayers({
        ...config,
        visible: [...new Set([...config.visible, ...nodes.map(layerOf)])],
        facets: [...new Set([...config.facets, ...nodes.map(implementationFacet)])],
      });
      for (const node of nodes)
        for (const id of ancestorsToReveal(graph.all, node.id)) expanded.add(id);
      analysisSettings.advanced = true;
      updateLayerControls();
      project();
      save();
    },
    onHide: (id) => {
      preferences.filters.hiddenEdges.push(id);
      applyFilters();
    },
  });
  if (!shown) selectedEdge = null;
}
$("close-edge").onclick = () => {
  selectedEdge = null;
  $("edge-details").hidden = true;
  $("viewport").focus({ preventScroll: true });
};
function updateDetail() {
  detailPanel.update();
}
function positionDetail() {
  detailPanel.position();
}
function showDetail(mode) {
  detailMode = mode;
  updateDetail();
  if (mode === "source") loadSource();
}
function editAnnotation() {
  if (!graph?.byId.has(selected)) return;
  const b = graph.byId.get(selected),
    annotation = annotationFor(preferences, b.node.referenceOf || selected);
  $("node-name").value = annotation.label;
  $("node-name").placeholder = b.node.label;
  $("node-note").value = annotation.note;
  $("node-core").checked = !!annotation.core;
  showDetail("annotation");
  $("node-name").focus({ preventScroll: true });
}
function saveAnnotation() {
  const b = graph?.byId.get(selected);
  if (!b || detailMode !== "annotation") return;
  cancelLayout();
  const annotation = setAnnotation(preferences, b.node.referenceOf || selected, {
    label: $("node-name").value,
    note: $("node-note").value,
    core: $("node-core").checked,
  });
  b.h = b.baseHeight + (annotation.note ? 22 : 0);
  placeIncremental(graph, preferences);
  for (const el of $("semantic").children) {
    const node = graph.byId.get(el.dataset.nodeId)?.node;
    if (node) {
      const name = displayName(node, preferences);
      el.textContent = name;
      el.setAttribute("aria-label", name);
    }
  }
  updateActions();
  updateDetail();
  save();
  schedule();
}
$("core-toggle").onclick = () => {
  const b = graph?.byId.get(selected);
  if (!b) return;
  const id = b.node.referenceOf || b.id,
    previous = annotationFor(preferences, id);
  setAnnotation(preferences, id, { ...previous, core: !previous.core });
  updateActions();
  updateSemantic();
  save();
  schedule();
};
$("node-core").onchange = saveAnnotation;
$("node-name").oninput = saveAnnotation;
$("node-note").oninput = saveAnnotation;
$("restore-name").onclick = () => {
  $("node-name").value = "";
  saveAnnotation();
};
$("annotation-form").onsubmit = (e) => {
  e.preventDefault();
  saveAnnotation();
  detailMode = null;
  updateDetail();
  $("viewport").focus({ preventScroll: true });
};
$("full-source").onclick = () => loadSource();
async function loadSource() {
  await detailPanel.load();
}
function hitAt(e) {
  const r = app.canvas.getBoundingClientRect();
  const x = (e.clientX - r.left - pan.x) / scale,
    y = (e.clientY - r.top - pan.y) / scale;
  const hit = pickHit(hits, x, y);
  if (hit?.id || hit?.expand) return hit;
  const choices = pickRoutes(
    renderedEdges,
    (edge) => edgePaths.get(edge.id)?.points,
    { x, y },
    5 / scale,
  );
  return choices.length ? { edge: { ...choices[0], alternatives: choices } } : hit;
}
// Pointer and keyboard users share the same selection and action handlers.
function openSelectionMenu(x, y, target = $("viewport")) {
  const box = graph?.byId.get(selected);
  const edge = renderedEdges.find((item) => item.id === selectedEdge);
  if (!box && !edge) return;
  updateActions();
  const title = box
    ? displayName(box.node, preferences)
    : (relationStyles[edge.type] || relationStyles.other).label;
  contextMenu.open(box ? "node" : "edge", title, x, y, target);
}
$("viewport").addEventListener("contextmenu", (event) => {
  const node = event.target.closest("[data-node-id]");
  const semanticEdge = event.target.closest("[data-edge-id]");
  if (event.target !== app.canvas && !node && !semanticEdge) return;
  const hit = event.target === app.canvas ? hitAt(event) : null;
  const id = node?.dataset.nodeId || hit?.id || hit?.region || hit?.expand;
  const edge = hit?.edge || renderedEdges.find((item) => item.id === semanticEdge?.dataset.edgeId);
  if (!id && !edge) return;
  event.preventDefault();
  contextMenu.close();
  select(id || null);
  if (edge && !id) selectedEdge = edge.id;
  openSelectionMenu(
    event.clientX,
    event.clientY,
    event.target === app.canvas ? $("viewport") : event.target,
  );
});
$("selection-menu").onclick = (event) => {
  const bounds = event.currentTarget.getBoundingClientRect();
  openSelectionMenu(bounds.left, bounds.bottom + 6, event.currentTarget);
};
$("edge-inspect").onclick = updateEdgeDetail;
for (const [id, endpoint] of [
  ["edge-from", "from"],
  ["edge-to", "to"],
])
  $(id).onclick = () => {
    const edge = renderedEdges.find((item) => item.id === selectedEdge);
    if (edge) {
      revealResult(edge[endpoint]);
      focusSelection();
    }
  };
$("edge-hide").onclick = () => {
  const edge = renderedEdges.find((item) => item.id === selectedEdge);
  if (!edge) return;
  for (const member of edge.members)
    if (!preferences.filters.hiddenEdges.includes(member.id))
      preferences.filters.hiddenEdges.push(member.id);
  select(null);
  applyFilters();
};
app.canvas.addEventListener("pointerdown", (e) => {
  if (e.button !== 0 || gesture.active) return;
  $("viewport").focus({ preventScroll: true });
  contextMenu.close();
  const hit = hitAt(e);
  cancelLayout();
  app.canvas.setPointerCapture(e.pointerId);
  if (hit?.id) select(hit.id);
  else if (hit?.region) select(hit.region);
  const owner = hit?.id || hit?.region;
  gesture.start(
    { pointerId: e.pointerId, x: e.clientX, y: e.clientY },
    { node: owner ? displayGraph.byId.get(owner) : null, pan, scale },
  );
  gesture.active.hit = hit;
  app.canvas.style.cursor = owner ? "grabbing" : "move";
});
app.canvas.addEventListener("pointermove", (e) => {
  const move = gesture.move({
    pointerId: e.pointerId,
    x: e.clientX,
    y: e.clientY,
  });
  if (!move) return;
  if (move.kind === "node") {
    setPosition(graph, preferences, move.id, move.x, move.y);
  } else pan = { x: move.x, y: move.y };
  schedule();
});
function endDrag(e, cancelled = false) {
  const gestureEnd = gesture.end(e.pointerId);
  if (!gestureEnd) return;
  app.canvas.style.cursor = "default";
  if (!gestureEnd.moved && !cancelled) {
    const h = gestureEnd.hit;
    if (h?.expand) toggle(h.expand);
    else if (h?.region) select(h.region);
    else if (h?.edge) showEdge(h.edge);
    else if (!h) clearCanvasFocus();
  }
  save();
  schedule();
}
app.canvas.addEventListener("pointerup", (e) => endDrag(e));
app.canvas.addEventListener("pointercancel", (e) => endDrag(e, true));
app.canvas.addEventListener("lostpointercapture", (e) => endDrag(e, true));
app.canvas.addEventListener("dblclick", (e) => {
  const h = hitAt(e);
  if (h?.id) toggle(h.id);
  else if (h?.region) toggle(h.region);
});
app.canvas.addEventListener(
  "wheel",
  (e) => {
    e.preventDefault();
    const r = app.canvas.getBoundingClientRect();
    zoom(Math.exp(-e.deltaY * 0.0015), {
      x: e.clientX - r.left,
      y: e.clientY - r.top,
    });
  },
  { passive: false },
);
$("viewport").addEventListener("keydown", (e) => {
  if (e.target.closest("#graph-menu")) return;
  if (e.key === "ContextMenu" || (e.shiftKey && e.key === "F10")) {
    e.preventDefault();
    const node = e.target.closest("[data-node-id]");
    const edge = e.target.closest("[data-edge-id]");
    if (node) select(node.dataset.nodeId);
    if (edge) {
      select(null);
      selectedEdge = edge.dataset.edgeId;
    }
    const rect = $("viewport").getBoundingClientRect();
    openSelectionMenu(rect.left + rect.width / 2, rect.top + rect.height / 2, e.target);
    return;
  }
  if (
    e.target.closest(
      "input,textarea,select,#node-details,#edge-details,#filter-panel,#legend-panel",
    )
  )
    return;
  if (e.key === "Delete" && !e.target.closest('[contenteditable="true"]')) {
    e.preventDefault();
    if (selectedLayer) {
      const config = cleanLayers(analysisSettings.layers);
      changeLayers(config.visible.filter((id) => id !== selectedLayer));
    } else if (selectedEdge) $("edge-hide").click();
    else if (selected) $("hide-node").click();
    return;
  }
  if (e.key.toLowerCase() === "f") focusSelection();
  if (e.key === "0") fit();
  if (e.key === "+" || e.key === "=") zoom(1.15);
  if (e.key === "-") zoom(1 / 1.15);
  if (e.key.toLowerCase() === "p") pin();
  if (e.key === "Enter" && selected) {
    e.preventDefault();
    toggle(selected);
  }
  if (e.key === "Escape") {
    detailMode = null;
    clearCanvasFocus();
  }
  const delta = {
    ArrowLeft: [-1, 0],
    ArrowRight: [1, 0],
    ArrowUp: [0, -1],
    ArrowDown: [0, 1],
  }[e.key];
  if (delta) {
    e.preventDefault();
    const b = graph?.byId.get(selected),
      distance = e.shiftKey ? 80 : 20;
    cancelLayout();
    if (b && spatialActive()) spatial?.moveGroup(b.id, delta[0] * distance, delta[1] * distance);
    else if (b)
      setPosition(graph, preferences, b.id, b.x + delta[0] * distance, b.y + delta[1] * distance);
    else {
      pan.x -= delta[0] * 50;
      pan.y -= delta[1] * 50;
    }
    save();
    schedule();
  }
});
$("fit").onclick = fit;
$("zoom-in").onclick = () => zoom(1.2);
$("zoom-out").onclick = () => zoom(1 / 1.2);
$("arrange").onclick = () => arrange();
$("undo-layout").onclick = () => {
  if (!undo || undo.mode !== (spatialActive() ? "3D" : "2D")) return;
  cancelLayout();
  if (undo.mode === "3D") {
    preferences.spatial = structuredClone(undo.snapshot);
    spatial.restore(undo.snapshot);
  } else {
    preferences.positions = Object.assign(Object.create(null), JSON.parse(undo.positions));
    scale = undo.camera.scale;
    pan = undo.camera.pan;
    project();
  }
  undo = null;
  $("undo-layout").disabled = true;
  save();
};
$("collapse").onclick = () => {
  cancelLayout();
  expanded.clear();
  selected = null;
  detailMode = null;
  project();
  fit();
  save();
};
$("focus-selection").onclick = focusSelection;
$("expand").onclick = () => {
  if (!graph) return;
  cancelLayout();
  const roots = graph.boxes.filter((b) => !b.node.parent).map((b) => b.id);
  for (const id of roots) expanded.add(id);
  project();
  if (!spatialActive()) for (const id of roots) settleExpansion(graph, preferences, id);
  fit();
  save();
};
$("node-expand").onclick = () => toggle(selected);
$("pin").onclick = pin;
$("details").onclick = () => showDetail("values");
$("source").onclick = () => showDetail("source");
$("close-detail").onclick = () => {
  detailMode = null;
  updateDetail();
  $("viewport").focus({ preventScroll: true });
};
$("annotate").onclick = editAnnotation;
function filteredSearch(query) {
  return searchNodes(graph.all, preferences, query, 1000)
    .filter(
      (result) =>
        filterNode(result.node, graph.all, preferences.filters) ||
        (graph.children.has(result.node.id) &&
          filterNode(result.node, graph.all, preferences.filters, true)),
    )
    .slice(0, 30);
}
function updateFilters() {
  $("fields-toggle").setAttribute("aria-pressed", String(preferences?.filters.fields === "all"));
  $("filter-toggle").disabled = false;
  const filters = (preferences.filters = cleanFilters(preferences.filters));
  for (const input of $("filter-panel").querySelectorAll("input[data-filter]"))
    input.checked = filters[input.dataset.filter].includes(input.value);
  const depth = $("filter-depth"),
    max = Math.max(
      0,
      ...[...graph.all.keys()].map((id) => ancestorsToReveal(graph.all, id).length),
    );
  if (depth.dataset.max !== String(max)) {
    depth.replaceChildren(
      new Option(boTranslate("All levels"), "all"),
      ...Array.from(
        { length: max + 1 },
        (_, i) =>
          new Option(
            i ? boTranslate("Level ") + i + boTranslate(" ") : boTranslate("Top level"),
            String(i),
          ),
      ),
    );
    depth.dataset.max = String(max);
  }
  depth.value = String(filters.depth);
  const profile = currentProfile();
  $("filter-scope").value = profile.scope;
  $("filter-query").value = profile.query;
  const active =
    JSON.stringify(filters) !== JSON.stringify(emptyFilters()) ||
    profile.scope !== "all" ||
    !!profile.query ||
    !analysisSettings.advanced;
  $("filter-toggle").textContent = active
    ? boTranslate("Filters \u00B7 active")
    : boTranslate("Filters");
  const coverage = elementCoverage(graph, presentation);
  $("filter-count").textContent = boTranslate(
    "Nodes: {0} visible, {1} folded, {2} filtered. Relations: {3} visible, {4} folded, {5} filtered.",
    coverage.visibleNodes,
    coverage.foldedNodes,
    coverage.excludedNodes,
    coverage.visibleEdges,
    coverage.foldedEdges,
    coverage.excludedEdges,
  );
  Object.assign($("filter-count").dataset, coverage);
  updateHiddenElements();
}
/** Restore individual exclusions without losing the rest of a custom view. */
function updateHiddenElements() {
  const entries = [];
  for (const kind of ["hiddenNodes", "hiddenEdges"])
    for (const id of preferences.filters[kind]) {
      const row = document.createElement("div"),
        button = document.createElement("button");
      const node = graph.all.get(id),
        edge = graph.rawEdges.find((item) => item.id === id);
      const label =
        kind === "hiddenNodes"
          ? node
            ? displayName(node, preferences)
            : id
          : edge
            ? `${graph.all.get(edge.from)?.label || edge.from} → ${graph.all.get(edge.to)?.label || edge.to}`
            : id;
      row.append(document.createTextNode(label + " "));
      button.textContent = boTranslate("Show again");
      button.onclick = () => {
        preferences.filters[kind] = preferences.filters[kind].filter((item) => item !== id);
        applyFilters();
      };
      row.append(button);
      entries.push(row);
    }
  $("hidden-elements").replaceChildren(...entries);
  $("hidden-elements-heading").hidden = !entries.length;
}
$("hide-node").onclick = () => {
  if (!selected) return;
  preferences.filters.hiddenNodes.push(selected);
  selected = null;
  applyFilters();
};
$("show-all").onclick = () => {
  analysisOverride = { ...cleanProfile(), hierarchical: true };
  analysisSettings.advanced = true;
  preferences.filters = emptyFilters();
  analysisSettings.layers = cleanLayers({
    ...analysisSettings.layers,
    only: "all",
    visible: layers.map((layer) => layer.id),
    facets: [...implementationFacets],
  });
  updateLayerControls();
  updateAnalysisOptions();
  applyFilters();
};
$("fields-toggle").onclick = () => {
  preferences.filters.fields = preferences.filters.fields === "all" ? "selected" : "all";
  applyFilters();
};
function applyFilters() {
  cancelLayout();
  preferences.filters = cleanFilters(preferences.filters);
  project();
  showSearch();
  save();
  schedule();
}
for (const kind of ["nodes", "edges", "regions"]) {
  const values =
    kind === "edges"
      ? Object.fromEntries(Object.entries(relationStyles).filter(([key]) => key !== "contains"))
      : nodeTypes;
  const host = $("filter-" + kind);
  for (const [value, style] of Object.entries(values)) {
    const label = document.createElement("label"),
      input = document.createElement("input"),
      name = document.createElement("span");
    input.type = "checkbox";
    input.dataset.filter = kind;
    input.value = value;
    input.checked = true;
    name.textContent = style.label;
    name.style.color = "#" + style.color.toString(16).padStart(6, "0");
    label.append(input, name);
    host.append(label);
    input.onchange = () => {
      preferences.filters[kind] = [...host.querySelectorAll("input:checked")].map((el) => el.value);
      applyFilters();
    };
  }
}
for (const button of $("filter-panel").querySelectorAll("button[data-filter-group]")) {
  button.onclick = () => {
    const key = button.dataset.filterGroup;
    preferences.filters[key] = button.dataset.all === "true" ? emptyFilters()[key] : [];
    applyFilters();
  };
}
$("filter-depth").onchange = (event) => {
  preferences.filters.depth = event.target.value === "all" ? "all" : Number(event.target.value);
  applyFilters();
};
$("filter-reset").onclick = () => {
  analysisOverride = null;
  const profile = profileFor(analysisId, analysisSettings.custom);
  preferences.filters = cleanFilters(profile);
  applyFilters();
};
$("filter-toggle").onclick = () => {
  const panel = $("filter-panel");
  panel.hidden = !panel.hidden;
  $("filter-toggle").setAttribute("aria-expanded", String(!panel.hidden));
};
$("close-filters").onclick = () => {
  $("filter-panel").hidden = true;
  $("filter-toggle").setAttribute("aria-expanded", "false");
  $("filter-toggle").focus();
};
$("filter-panel").onkeydown = (event) => {
  if (event.key === "Escape") $("close-filters").click();
};
function showSearch() {
  const list = $("search-results");
  list.replaceChildren();
  if (!graph || !$("node-search").value.trim()) {
    list.hidden = true;
    return;
  }
  const results = filteredSearch($("node-search").value);
  for (const result of results) {
    const button = document.createElement("button");
    button.type = "button";
    const title = document.createElement("strong"),
      description = document.createElement("span");
    const parent = graph.all.get(result.node.parent),
      context = parent ? displayName(parent, preferences) : "";
    title.textContent = result.name;
    description.textContent = result.node.field
      ? [
          context,
          result.node.direction === "in" ? boTranslate("Input") : boTranslate("Output"),
          result.node.fieldType,
        ]
          .filter(Boolean)
          .join(" · ")
      : [context, result.node.source?.symbol || result.node.id].filter(Boolean).join(" · ");
    button.append(title, description);
    button.onclick = () => revealResult(result.node.id);
    list.append(button);
  }
  if (!results.length) {
    const empty = document.createElement("p");
    empty.textContent = boTranslate("No nodes found");
    list.append(empty);
  }
  list.hidden = false;
}
function revealResult(id) {
  if (!graph?.all.has(id)) return;
  if (graph.all.get(id).field) {
    preferences.filters.promotedFields ||= [];
    preferences.filters.promotedFields.push(id);
  }
  if (
    ["python-ast", "source-ast"].includes(graph.all.get(id).origin) ||
    graph.all.get(id).analysis_level === "advanced"
  ) {
    analysisSettings.advanced = true;
    updateAnalysisOptions();
  }
  cancelLayout();
  for (const parent of ancestorsToReveal(graph.all, id)) expanded.add(parent);
  project();
  select(id);
  const box = graph.byId.get(id);
  if (box?.open && box.kids.length) focusSelection();
  else if (box) {
    scale = Math.max(0.8, scale);
    const p = point(box);
    pan = {
      x: app.screen.width / 2 - p.x * scale,
      y: app.screen.height / 2 - p.y * scale,
    };
  }
  $("search-results").hidden = true;
  save();
  schedule();
  $("viewport").focus({ preventScroll: true });
}
$("node-search").oninput = showSearch;
$("node-search").onfocus = showSearch;
$("node-search").onkeydown = (e) => {
  if (e.key === "Escape") $("search-results").hidden = true;
  if (e.key === "Enter") {
    e.preventDefault();
    const first = graph && filteredSearch(e.target.value)[0];
    if (first) revealResult(first.node.id);
  }
};
document.addEventListener("pointerdown", (e) => {
  if (!e.target.closest(".graph-search")) $("search-results").hidden = true;
});
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && !e.target.closest("#viewport,.graph-search,input,textarea,select")) {
    clearCanvasFocus();
    $("viewport").focus({ preventScroll: true });
  }
});
$("attempt").onchange = (e) => {
  choice = e.target.value;
  step = "latest";
  lastKey = "";
  project();
};
$("step").onchange = (e) => {
  step = e.target.value;
  project();
  updateFacts();
};
const resizeObserver = new ResizeObserver(() => {
  if (!disposed) {
    app.renderer.resize($("viewport").clientWidth, $("viewport").clientHeight);
    spatial?.resize();
    if (analysisSettings?.layers?.enabled) fit();
    // Resizing clears the WebGL drawing buffer. Paint in this observer turn,
    // before the browser composites it, rather than exposing a black frame
    // while waiting for the next animation callback.
    cancelAnimationFrame(drawFrame);
    if (graph) draw();
    else app.renderer.render(app.stage);
  }
});
resizeObserver.observe($("viewport"));
function updateFacts() {
  if (!view) return;
  const state = selectedConfiguration(view, choice, step),
    p = view.authority.parameters;
  const phase =
    step !== "latest" ? state?.phase : choice === "latest" ? view.machine.current : state?.phase;
  $("phase").textContent = phase
    ? boTranslate("Flow state: ") + phaseLabel(view.model, phase)
    : step !== "latest"
      ? boTranslate("Inspecting internal activity; no flow state recorded at this step")
      : boTranslate("No runtime records");
  $("context").textContent =
    parameterSummary(view, state, step) ||
    boTranslate("Parameter version {0}", state?.param_version ?? p.param_version ?? "—") +
      (step !== "latest" ? boTranslate(" \u00B7 step {0}", step) : "");
}
function frameLabel(entry) {
  const name = view.model.nodes.find((n) => n.id === entry.activity)?.label || entry.activity;
  const raw = entry.after.activities?.[entry.activity],
    state = preferences.nameMode === "source" ? raw : stateLabels[raw] || raw;
  const label =
    entry.event === "join"
      ? preferences.nameMode === "source"
        ? entry.after.join.state
        : boTranslate(
            entry.after.join.state === "passed" ? "All checks passed" : "Some checks did not pass",
          )
      : entry.event === "abort"
        ? preferences.nameMode === "source"
          ? "abort"
          : boTranslate("Checks stopped")
        : `${name}：${state || entry.event}`;
  return `${entry.seq} · ${label}`;
}
function showDatabaseWarning(next) {
  const warning = databaseWarning(next.database_status),
    connection = $("connection");
  connection.dataset.databaseStale = String(!!warning);
  connection.title = warning?.details || "";
  if (warning) connection.textContent += " · " + warning.label;
}
async function poll() {
  const requestedVersion = version,
    requestedCase = caseChoice;
  try {
    const r = await fetch(
      "/api/view?version=" +
        encodeURIComponent(version) +
        "&case=" +
        encodeURIComponent(caseChoice),
      { cache: "no-store" },
    );
    if (r.status === 404) {
      const error = await r.json();
      if (error.code === "bo_web_disabled") {
        stopPlayback();
        stopAnimation();
        changeView();
        $("connection").textContent = boTranslate("Debug Web is disabled");
        $("empty").hidden = false;
        $("empty").textContent = boTranslate("Re-enable Web in the development tool to continue.");
        return;
      }
    }
    if (!r.ok) throw Error("HTTP " + r.status);
    const next = await r.json();
    if (disposed || version !== requestedVersion || caseChoice !== requestedCase) return;
    loadAnalysis(projectLayoutKey(next, storage));
    const codeEnabled =
      !recording &&
      next.stage !== "design" &&
      (["project", "code", "api", "implementation"].includes(analysisId) ||
        !!analysisSettings.codeFocus);
    let codeSlice = null;
    let sourceNeedsLayout = false;
    try {
      const previousCodeFocus = codeLayer.slice?.focus;
      codeSlice = recording?.transient
        ? codeLayer.slice
        : await codeLayer.load({
            enabled: codeEnabled,
            focus: ["project", "code", "api", "implementation"].includes(analysisId)
              ? null
              : analysisSettings.codeFocus,
            limit: codeLimit,
            projection: ["project", "api"].includes(analysisId) ? analysisId : "all",
          });
      if (codeSlice?.focus && codeSlice.focus !== previousCodeFocus)
        for (const node of codeSlice.nodes)
          if (["directory", "file", "class"].includes(node.code_role)) expanded.add(node.id);
      $("code-status").textContent = codeSummary(codeSlice, boTranslate);
      $("code-status").title = codeSlice ? JSON.stringify(codeSlice.errors) : "";
    } catch (error) {
      $("code-status").textContent = boTranslate("Code structure unavailable");
      $("code-status").title = error.message;
    }
    $("code-more").hidden = !!recording || !codeSlice?.omitted_nodes || codeLimit >= 5000;
    $("code-local").setAttribute("aria-pressed", String(!!analysisSettings.codeFocus));
    $("code-local").disabled =
      next.stage === "design" ||
      !!recording ||
      ["project", "code", "api"].includes(analysisId) ||
      (!selected && !analysisSettings.codeFocus);
    const key = renderRevision(next, [
      version,
      caseChoice,
      choice,
      step,
      codeSlice?.revision,
      codeSlice?.focus,
      codeSlice?.loaded_nodes,
      analysisId,
    ]);
    const previousLive = latestLive;
    latestLive = next;
    const graphChanged = previousLive && graphVersion(previousLive) !== graphVersion(next);
    if (graphChanged) {
      cancelLayout();
      detailPanel.clear();
      lastRecordPoll = 0;
      lastLiveEvent = null;
    }
    if (recording && !recordingMatches(recording, next)) leaveRecording();
    document.querySelector(".record-bar").hidden = next.stage === "design";
    $("program-link").hidden = next.stage === "design";
    if (Object.hasOwn(next, "program_url")) {
      const url = next.program_url ? new URL(next.program_url, location.href) : null;
      const safe =
        url &&
        ["http:", "https:"].includes(url.protocol) &&
        ["localhost", "127.0.0.1"].includes(url.hostname);
      $("program-link").hidden = next.stage === "design" || !safe;
      if (safe) $("program-link").href = url.href;
    }
    if (next.stage !== "design") {
      const source = liveTrace.observe(next, graphVersion(next));
      if (!recordActive) liveTraceSource = source;
      await refreshRecordings(next);
    } else {
      liveTrace.reset();
      liveTraceSource = null;
      recordingTimeline.clear();
    }
    if (recording?.transient && liveTraceSource) {
      const id = replayItems[replayIndex]?.id;
      recording = { ...liveTraceSource, transient: true };
      replayItems = timeline(recording);
      replayIndex = Math.max(
        0,
        replayItems.findIndex((event) => event.id === id),
      );
      boPlanKey = "";
      // Receiving new facts never advances the inspected graph cursor.
      view = frame(recording, replayIndex, replayItems);
      project();
    }
    if (recording) {
      await conversationControls.refresh(next);
      $("connection").textContent = boTranslate("Connected \u00B7 recorded replay");
      showDatabaseWarning(next);
      return;
    }
    view = withCodeGraph(next, codeSlice);
    $("project-title").textContent = view.model.presentation.subject || boTranslate("Application");
    document.title = "VibeLens · " + $("project-title").textContent;
    const baseKey = projectLayoutKey(next, storage);
    loadAnalysis(baseKey);
    const nextStorageKey = baseKey + (analysisId === "overview" ? "" : ":view:" + analysisId);
    if (nextStorageKey !== storageKey) {
      cancelLayout();
      const restored = readLayout(storage, nextStorageKey);
      preferences = restored.state;
      storageKey = nextStorageKey;
      if (!restored.restored)
        preferences.filters = cleanFilters(profileFor(analysisId, analysisSettings.custom));
      if (analysisSettings.annotations) preferences.annotations = analysisSettings.annotations;
      selected = preferences.focus;
      expanded = new Set(restored.restored ? preferences.expanded : []);
      if (preferences.camera) {
        scale = preferences.camera.scale;
        pan = { x: preferences.camera.x, y: preferences.camera.y };
      }
      first = true;
    }
    if (codeSlice && !analysisSettings.sourceTreeInitialized?.includes(analysisId)) {
      sourceNeedsLayout =
        ["project", "code", "api"].includes(analysisId) &&
        !codeSlice.nodes.some((node) => preferences.positions[node.id]);
      analysisSettings.sourceTreeInitialized ||= [];
      for (const node of codeSlice.nodes)
        if (node.code_role === "directory" && (analysisId === "code" || node.project_path === "."))
          expanded.add(node.id);
      analysisSettings.sourceTreeInitialized.push(analysisId);
      saveAnalysis();
    }

    const cases = next.available_cases || [];
    if (JSON.stringify([cases, version]) !== $("case").dataset.options) {
      $("case").replaceChildren(
        ...cases.map(
          (v) =>
            new Option(
              v === "live" ? boTranslate("Current operation") : next.case_names?.[v] || v,
              v,
            ),
        ),
      );
      $("case").dataset.options = JSON.stringify([cases, version]);
      if (cases.includes(caseChoice)) $("case").value = caseChoice;
    }
    $("connection").textContent = contextLost
      ? boTranslate("Graphics connection lost; recovering")
      : connectionStatus(next, boTranslate);
    const stale = next.binding_status.status !== "current";
    $("binding").textContent = stale
      ? boTranslate("Application has not loaded the new code")
      : boTranslate("Build ") + next.manifest.build_id.slice(0, 8);
    $("binding").classList.toggle("stale", stale);
    if (stale && !contextLost)
      $("connection").textContent =
        next.stage === "design"
          ? boTranslate("Design declaration \u00B7 not implemented")
          : boTranslate("Application has not loaded the new code");
    showDatabaseWarning(next);
    if (key !== lastKey) {
      lastKey = key;
      const run = selectedConfiguration(view, choice);
      $("step").replaceChildren(
        new Option(boTranslate("Latest state"), "latest"),
        ...(run?.journal || []).map((e) => new Option(frameLabel(e), String(e.seq))),
      );
      if (run?.journal.some((e) => String(e.seq) === step)) $("step").value = step;
      else step = "latest";
      const select = $("attempt");
      select.replaceChildren(new Option(boTranslate("Current run"), "latest"));
      const runs = configurations(view);
      if (runs.length)
        runs.forEach((run, i) =>
          select.add(
            new Option(
              boTranslate("Run {0} \u00B7 version {1}", i + 1, run.param_version) +
                (run.disposition === "superseded"
                  ? boTranslate(" (older version)")
                  : run.disposition === "interrupted"
                    ? boTranslate(" (interrupted)")
                    : ""),
              run.attempt,
            ),
          ),
        );
      else
        for (const id of executionIds(view)) select.add(new Option(boTranslate("Run ") + id, id));
      select.value = choice;
      const hasPositions = Object.keys(preferences.positions).length > 0;
      project();
      if (first || sourceNeedsLayout) {
        first = false;
        if (!hasPositions || sourceNeedsLayout) arrange(true);
        else if (!preferences.camera || analysisSettings?.layers?.enabled) fit();
      }
      saveSoon();
    }
    await conversation.refresh();
    await conversationControls.refresh(next);
    updateFacts();
    const newest = next.events.at(-1);
    if (newest && newest.id !== lastLiveEvent) {
      if (previousLive && lastLiveEvent) boUpdateLive(previousLive, next);
      lastLiveEvent = newest.id;
    }
    if (!recording) boUpdateLiveTimeline();
  } catch (error) {
    if (disposed) return;
    console.error(error);
    $("connection").textContent = boTranslate("Cannot connect to the application");
    if (!view) {
      $("empty").hidden = false;
      $("empty").textContent = boTranslate("Waiting for the application to connect.");
    }
  }
}
function changeView() {
  stopAnimation();
  contextMenu.close();
  cancelLayout();
  choice = "latest";
  step = "latest";
  lastKey = "";
  detailMode = null;
  selectedEdge = null;
  view = null;
  graph = null;
  renderer.clear();
  presentation = null;
  app.renderer.render(app.stage);
  $("node-details").hidden = true;
  $("edge-details").hidden = true;
}
$("version").onchange = (e) => {
  version = e.target.value;
  caseChoice = "live";
  changeView();
};
$("case").onchange = (e) => {
  caseChoice = e.target.value;
  changeView();
};
function loadAnalysis(baseKey) {
  const key = baseKey + ":analysis";
  if (analysisKey === key) return;
  analysisKey = key;
  let saved;
  try {
    saved = JSON.parse(storage.getItem(key));
  } catch {}
  analysisWasSaved = !!saved && typeof saved === "object";
  analysisSettings = {
    advanced: false,
    explainedNames: saved?.explainedNames !== false,
    custom: [],
    overrides: Object.create(null),
    selected: "overview",
    annotations: null,
    layers: cleanLayers(saved?.layers),
    layerVisibility: cleanLayerVisibility(saved?.layerVisibility, saved?.layers),
    routing: cleanRoute(saved?.routing),
    timeline: cleanTimeline(saved?.timeline),
    sourceTreeInitialized: Array.isArray(saved?.sourceTreeInitialized)
      ? saved.sourceTreeInitialized.filter((id) => typeof id === "string").slice(0, 40)
      : [],
    replays: saved?.replays && typeof saved.replays === "object" ? saved.replays : {},
  };
  updateLayerControls();
  if (saved) {
    if (typeof saved.discussion?.revision === "string")
      analysisSettings.discussion = {
        revision: saved.discussion.revision.slice(0, 256),
        active: saved.discussion.active === true,
      };
    if (typeof saved.codeFocus === "string") analysisSettings.codeFocus = saved.codeFocus;
    analysisSettings.codeViews = Array.isArray(saved.codeViews)
      ? saved.codeViews.filter((id) => typeof id === "string").slice(0, 40)
      : [];
    analysisSettings.advanced = saved.advanced === true;
    analysisSettings.custom = (Array.isArray(saved.custom) ? saved.custom : [])
      .slice(0, 20)
      .filter(
        (p) =>
          typeof p.id === "string" &&
          /^custom-[a-z0-9-]+$/.test(p.id) &&
          typeof p.label === "string",
      )
      .map((p) => ({
        ...cleanProfile(p),
        id: p.id,
        label: p.label.slice(0, 40),
      }));
    for (const [id, p] of Object.entries(saved.overrides || {}))
      if (presets.some((x) => x.id === id) || analysisSettings.custom.some((x) => x.id === id))
        analysisSettings.overrides[id] = cleanProfile(p);
    if (saved.annotations && typeof saved.annotations === "object")
      analysisSettings.annotations = saved.annotations;
    if ([...presets, ...analysisSettings.custom].some((p) => p.id === saved.selected))
      analysisSettings.selected = saved.selected;
  }
  analysisId = analysisSettings.selected;
  analysisSettings.layers = cleanLayers({
    ...analysisSettings.layers,
    visible: visibilityForView(analysisSettings, analysisId),
    facets: [...implementationFacets],
  });
  updateLayerControls();
  analysisOverride = analysisSettings.overrides[analysisId] || null;
  updateAnalysisOptions();
}
function currentProfile() {
  const p = analysisOverride || profileFor(analysisId, analysisSettings?.custom);
  return cleanProfile({ ...p, ...preferences?.filters });
}
/** Rename the presentation in place; keep the camera, event cursor and selection. */
$("name-mode").onclick = () => {
  if (!analysisSettings || !view) return;
  analysisSettings.explainedNames = !analysisSettings.explainedNames;
  boPlanKey = "";
  replayEditorKey = "";
  project();
  updateFacts();
  saveAnalysis();
  saveSoon();
};
/** Apply a scoped presentation plan through the same state used by native UI actions. */
async function applyConversationControl(plan, session) {
  if (!graph || !analysisSettings)
    throw Error("Wait for the graph to load before applying controls");
  if (recording) leaveRecording();
  const id = "custom-vl-" + session.slice(0, 8) + "-" + plan.view_id;
  if (
    !analysisSettings.custom.some((item) => item.id === id) &&
    analysisSettings.custom.length >= 20
  )
    throw Error("Delete an unused custom view before creating another");
  const projection = controlProjection(graph.all, plan, declarationNodes(view)),
    { nodes: available, keep } = projection;
  const original = structuredClone(preferences);
  original.filters = cleanFilters({
    ...original.filters,
    ...plan.filters,
    depth: "all",
    hiddenNodes: [...available.keys()].filter((key) => !keep.has(key)),
    hiddenEdges: [],
  });
  original.algorithm = plan.layout;
  original.expanded = projection.expanded;
  analysisSettings.advanced ||= projection.advanced;
  const profile = {
    ...cleanProfile(original.filters),
    hierarchical: false,
    id,
    label: plan.label,
  };
  analysisSettings.custom = analysisSettings.custom
    .filter((item) => item.id !== id)
    .concat(profile);
  const base = analysisKey.slice(0, -":analysis".length);
  writeLayout(storage, base + ":view:" + id, original);
  saveAnalysis();
  if (analysisId === id) {
    preferences = original;
    expanded = new Set(original.expanded);
    analysisOverride = null;
    updateAnalysisOptions();
    project();
  } else changeAnalysis(id);
  await arrange();
  if (plan.action === "replay") {
    await openRecording(plan.recording.id);
    if (recording.build_id !== plan.recording.build_id) throw Error("Recording build changed");
    const included = new Set(plan.recording.event_ids);
    if ([...included].some((key) => !recording.events.some((event) => event.id === key)))
      throw Error("The recording no longer contains the selected events");
    const ordered = replayItems.filter((item) => included.has(item.id));
    changeReplaySelection({
      skipped: replayItems.filter((item) => !included.has(item.id)).map((item) => item.id),
      loop: plan.recording.loop,
      from: ordered[0]?.id,
      to: ordered.at(-1)?.id,
    });
    if (boPlan.length) seek(boPlan[0]);
  }
  requireVisibleControlNodes(graph, plan);
  save();
  if (!(await storage.flush()))
    throw Error("The conversation view could not be saved; refresh before retrying");
  fit();
  document.body.dataset.controlPlan = plan.id;
  return {
    view_id: id,
    nodes: graph.boxes.map((box) => box.id),
    events: plan.recording?.event_ids || [],
  };
}
function saveAnalysis() {
  if (!analysisKey || !analysisSettings) return;
  analysisSettings.selected = analysisId;
  analysisSettings.layerVisibility[analysisId] = savedLayerVisibility(analysisSettings.layers);
  analysisSettings.annotations = preferences?.annotations || analysisSettings.annotations;
  if (analysisOverride) analysisSettings.overrides[analysisId] = analysisOverride;
  else delete analysisSettings.overrides[analysisId];
  try {
    storage.setItem(analysisKey, JSON.stringify(analysisSettings));
  } catch {}
}
function updateAnalysisOptions() {
  const groups = new Map();
  for (const p of [...presets, ...analysisSettings.custom]) {
    const group = p.group || "Custom";
    if (!groups.has(group)) {
      const element = document.createElement("optgroup");
      element.label = boTranslate(group);
      groups.set(group, element);
    }
    const option = new Option(p.label, p.id);
    // The lazy source index is current-source evidence, not a recorded frame.
    option.disabled = recordedSourceUnavailable(p.id);
    if (option.disabled) option.title = boTranslate("Return to live view to browse code structure");
    groups.get(group).append(option);
  }
  $("analysis-view").replaceChildren(...groups.values());
  $("fields-toggle").setAttribute("aria-pressed", String(preferences?.filters.fields === "all"));
  $("analysis-details").setAttribute("aria-pressed", String(analysisSettings.advanced));
  $("analysis-view").value = analysisId;
  $("delete-view").hidden = !analysisId.startsWith("custom-");
}
function recordedSourceUnavailable(id) {
  return (
    !!recording &&
    (id === "code" ||
      (id === "api" && !recording.context?.api_structure) ||
      (id === "project" && !recording.context?.project_structure))
  );
}
function changeAnalysis(id) {
  if (!analysisSettings || id === analysisId || recordedSourceUnavailable(id)) return;
  stopPlayback();
  cancelLayout();
  save();
  clearTimeout(saveTimer);
  analysisId = id;
  analysisSettings.layers = cleanLayers({
    ...analysisSettings.layers,
    visible: visibilityForView(analysisSettings, id),
    facets: [...implementationFacets],
  });
  codeLayer.clear();
  if (["resources", "permission"].includes(id)) analysisSettings.advanced = true;
  analysisOverride = analysisSettings.overrides[id] || null;
  saveAnalysis();
  updateAnalysisOptions();
  const base = analysisKey.slice(0, -":analysis".length),
    key = base + (id === "overview" ? "" : ":view:" + id),
    restored = readLayout(storage, key);
  preferences = restored.state;
  storageKey = key;
  if (!restored.restored)
    preferences.filters = cleanFilters(profileFor(id, analysisSettings.custom));
  if (analysisSettings.annotations) preferences.annotations = analysisSettings.annotations;
  expanded = new Set(restored.state.expanded);
  if (!restored.restored && id === "shared")
    expanded = new Set(sharedMemberships(view.model).map((m) => m.group));
  selected = preferences.focus;
  detailMode = null;
  undo = null;
  $("undo-layout").disabled = true;

  project();
  if (preferences.camera) {
    scale = preferences.camera.scale;
    pan = { x: preferences.camera.x, y: preferences.camera.y };
    schedule();
  } else arrange();
  saveSoon();
  lastKey = "";
  poller.run();
}
$("code-local").onclick = () => {
  if (!analysisSettings) return;
  analysisSettings.codeFocus = analysisSettings.codeFocus ? null : selected;
  analysisSettings.codeViews ||= [];
  if (analysisSettings.codeFocus && !analysisSettings.codeViews.includes(analysisId)) {
    for (const key of ["nodes", "regions", "edges"])
      preferences.filters[key] = [
        ...new Set([...preferences.filters[key], ...(key === "edges" ? codeRelations : codeTypes)]),
      ];
    analysisSettings.codeViews.push(analysisId);
    save();
  }
  codeLayer.clear();
  codeLimit = 400;
  saveAnalysis();
  project();
  lastKey = "";
  poller.run();
};
$("code-more").onclick = () => {
  codeLimit = Math.min(5000, codeLimit + 400);
  lastKey = "";
  poller.run();
};
$("analysis-details").onclick = () => {
  if (!analysisSettings) return;
  analysisSettings.advanced = !analysisSettings.advanced;
  updateAnalysisOptions();
  project();
  saveSoon();
};
$("analysis-view").onchange = (e) => changeAnalysis(e.target.value);
$("filter-scope").onchange = (e) => {
  analysisOverride = {
    ...currentProfile(),
    scope: e.target.value,
    hierarchical: false,
  };
  applyFilters();
  arrange();
};
$("filter-query").onchange = (e) => {
  analysisOverride = {
    ...currentProfile(),
    query: e.target.value,
    hierarchical: false,
  };
  applyFilters();
  arrange();
};
$("save-view").onsubmit = (e) => {
  e.preventDefault();
  if (!analysisSettings) return;
  const label = $("custom-view-name").value.trim();
  if (!label) return;
  const existing = analysisSettings.custom.find((p) => p.label === label);
  if (!existing && analysisSettings.custom.length >= 20) {
    $("filter-count").textContent = boTranslate(
      "Up to 20 custom views can be saved. Delete one first.",
    );
    return;
  }
  const id = existing?.id || "custom-" + Date.now().toString(36),
    profile = { ...currentProfile(), hierarchical: false, id, label };
  analysisSettings.custom = analysisSettings.custom.filter((p) => p.id !== id).concat(profile);
  // A saved view starts from the arrangement the developer is looking at.
  save();
  writeLayout(storage, analysisKey.slice(0, -":analysis".length) + ":view:" + id, preferences);
  saveAnalysis();
  updateAnalysisOptions();
  changeAnalysis(id);
  $("filter-count").textContent = boTranslate("Saved \u201C") + label + "」";
};
$("delete-view").onclick = () => {
  const old = analysisId;
  changeAnalysis("overview");
  analysisSettings.custom = analysisSettings.custom.filter((p) => p.id !== old);
  delete analysisSettings.overrides[old];
  saveAnalysis();
  updateAnalysisOptions();
};
$("reference-origin").onclick = () => {
  const id = graph?.byId.get(selected)?.node.referenceOf;
  if (!id) return;
  if (analysisId !== "overview") changeAnalysis("overview");
  revealResult(id);
  focusSelection();
};
const legendHost = $("node-legend");
legendHost.replaceChildren();
for (const [type, style] of Object.entries(nodeTypes)) {
  const compact = document.createElement("span");
  compact.append(legendGlyph(type, style), document.createTextNode(style.label));
  legendHost.append(compact);
  const row = document.createElement("div"),
    label = document.createElement("span");
  row.dataset.legendNode = type;
  row.title = meanings[type] || style.label;
  label.textContent = style.label;
  row.append(legendGlyph(type, style), label);
  $("legend-types").append(row);
}
const edgeLegend = document.querySelector(".relation-legend");
edgeLegend.replaceChildren();
for (const [type, style] of Object.entries(relationStyles))
  if (!["contains", "other"].includes(type)) {
    const label = document.createElement("span");
    label.dataset.legendEdge = type;
    label.title = style.label;
    label.append(legendRelation(style), document.createTextNode(style.label));
    edgeLegend.append(label);
  }
function boVisible() {
  return graph.boxes.filter((b) => presentation.glyphs.has(b.id) || presentation.regions.has(b.id));
}
function boText(value, row) {
  return boDisplayValue(value, view.model, row);
}
function boChangeText(row) {
  return `${row.field}: ${boText(row.before, row)} → ${boText(row.after, row)}`;
}
function boShowChanges() {
  renderStepChanges({
    detail: boDetail,
    model: view.model,
    onLocate: (id) => {
      select(id);
      focusSelection();
    },
  });
}
function boSetTransfers(events) {
  boTransfers.clear();
  for (const event of events) {
    const configuration = (
      recording?.final.machine.configurations ||
      view.machine.configurations ||
      []
    ).find((c) => c.attempt === event.attempt);
    for (const id of transferEdges(event, view.events, renderedEdges, graph.all, configuration)) {
      const edge = renderedEdges.find((e) => e.id === id),
        entry = configuration?.journal?.find((j) => j.seq === event.outputs?.revision);
      const reverse =
        edge.type === "resource"
          ? entry?.event !== "start"
          : ["call", "flow"].includes(edge.type) &&
            ["return", "error"].includes(event.phase) &&
            !!parentEvent(event, view.events);
      boTransfers.set(id, {
        event,
        label: boTransferLabel(edge, event, configuration),
        type: edge.type,
        reverse,
      });
    }
  }
  for (const el of $("semantic-edges").children)
    el.dataset.payload = boTransfers.get(el.dataset.edgeId)?.label || "";
}
function boUpdateReplay() {
  if (!recording || !graph) return;
  const visible = boVisible(),
    key = JSON.stringify([
      recording.id,
      replayItems.length,
      analysisSettings.explainedNames,
      $("replay-grain").value,
      visible.map((b) => [b.id, b.type]),
      replaySelection(),
    ]);
  if (key !== boPlanKey) {
    boPlanKey = key;
    boFullPlan = boStepPlan(recording, replayItems, graph.all, visible, {
      mode: $("replay-grain").value,
    });
    boPlan = selectedReplayPlan(replayItems, boFullPlan, replaySelection());
    $("replay-range").max = Math.max(0, boPlan.length - 1);
    const hierarchy = stepHierarchy(replayItems, graph.all, recording.context.events);
    $("replay-events").replaceChildren(
      ...boPlan.map((raw, i) => {
        const meta = hierarchy.get(raw),
          indent = "\u00a0".repeat(Math.min(12, meta.depth) * 3);
        const option = new Option(
          `${indent}${i + 1} · ${eventLabel(replayItems[raw], view.model)}`,
          String(raw),
        );
        option.style.color = meta.color || "#18866b";
        option.dataset.layer = meta.layer;
        option.dataset.depth = String(meta.depth);
        option.title = replayItems[raw].id;
        return option;
      }),
    );
  }
  const previous = boFullPlan.filter((i) => i < replayIndex).at(-1) ?? -1,
    position = Math.max(0, boPlan.filter((i) => i <= replayIndex).length - 1),
    item = replayItems[replayIndex];
  boDetail = boStepDetail(recording, replayItems, replayIndex, previous, graph.all, visible, {
    mode: $("replay-grain").value,
  });
  boShowChanges();
  boSetTransfers(replayItems.slice(Math.max(1, previous + 1), replayIndex + 1));
  $("replay-range").value = position;
  $("replay-events").value = String(boPlan[position]);
  $("replay-events").style.color = $("replay-events").selectedOptions[0]?.style.color || "";
  $("replay-position").value =
    `${boPlan.includes(replayIndex) ? position + 1 : "—"} / ${boPlan.length}`;
  Object.assign($("replay-position").dataset, {
    eventId: item.id,
    rawIndex: String(replayIndex),
    rawCount: String(replayItems.length),
    stepCount: String(boPlan.length),
  });
  $("replay-note").textContent = recording.gaps.length
    ? boTranslate("Recording gap: ") + recording.gaps.join("；")
    : recording.capture?.mode === "focused"
      ? boTranslate("Focused recording \u00B7 outside scope not captured")
      : boTranslate("{0} raw events", recording.events.length);
  $("replay-prev").disabled = !boPlan.some((raw) => raw < replayIndex);
  $("replay-next").disabled = !boPlan.some((raw) => raw > replayIndex);
  $("replay-play").disabled = !boPlan.length;
  $("replay-range").disabled = !boPlan.length;
  updateReplaySelection();
  $("replay-locate").disabled = !item.node;
  recordingTimeline.update({
    recording,
    model: view.model,
    preferences,
    items: replayItems,
    all: graph.all,
    edges: graph.rawEdges,
    visible: new Set(visible.map((box) => box.id)),
    order: cleanLayers(analysisSettings.layers).order,
    plan: boPlan,
    raw: replayIndex,
    transfers: boTransfers.keys(),
    settings: analysisSettings.timeline,
    playing: !!playTimer,
    selection: replaySelection(),
  });
  $("replay-timeline").setAttribute("aria-pressed", String(analysisSettings.timeline.visible));
}
function boUpdateLive(before, after) {
  const known = new Set(before.events.map((e) => e.id)),
    events = after.events.filter((e) => !known.has(e.id));
  if (!events.length) {
    boUpdateLiveTimeline();
    return;
  }
  const sample = {
      context: before,
      final: after,
      events,
      commands: [],
      status: "recording",
    },
    items = timeline(sample);
  boDetail = boStepDetail(sample, items, items.length - 1, 0, graph.all, boVisible());
  boShowChanges();
  boSetTransfers(events);
  animateEvent(events.at(-1));
  boUpdateLiveTimeline();
  schedule();
}
/** Live and active capture use the same read-only index and graph seek as saved replay. */
function boUpdateLiveTimeline() {
  if (recording || !graph || !analysisSettings || !liveTraceSource) return;
  const source = liveTraceSource,
    items = timeline(source),
    visible = boVisible();
  const plan = boStepPlan(source, items, graph.all, visible, {
    mode: $("replay-grain").value,
  });
  recordingTimeline.update({
    recording: source,
    model: view.model,
    preferences,
    items,
    all: graph.all,
    edges: graph.rawEdges,
    visible: new Set(visible.map((box) => box.id)),
    order: cleanLayers(analysisSettings.layers).order,
    plan,
    raw: items.length - 1,
    transfers: boTransfers.keys(),
    settings: analysisSettings.timeline,
    playing: true,
    selection: null,
    inspection: false,
  });
  $("replay-timeline").setAttribute("aria-pressed", String(analysisSettings.timeline.visible));
}
function boCaptureScope() {
  if ($("capture-mode").value === "all") return { mode: "all" };
  const box = graph?.byId.get(selected);
  if (!box) throw Error(boTranslate("Select a node or region to record"));
  const roots = captureRoots(view, box.node);
  if (!roots.length) throw Error(boTranslate("This node has no capture binding"));
  return { mode: "focused", roots };
}
function stopAnimation() {
  cancelAnimationFrame(animationFrame);
  animationFrame = null;
  if (disposed) return;
  animationDot.clear();
  spatial?.stopAnimation();
  animationUntil = 0;
  $("renderer").dataset.animationActive = "false";
  if (!disposed && !contextLost) app.renderer.render(app.stage);
}
function animateEvent(event) {
  if (!graph || disposed || document.hidden || contextLost) return;
  stopAnimation();
  $("renderer").dataset.animationEpoch = String(
    Number($("renderer").dataset.animationEpoch || 0) + 1,
  );
  animatedIds = [...boTransfers.keys()];
  if (!animatedIds.length)
    animatedIds = transferEdges(event, view.events, renderedEdges, graph.all, graph.configuration);
  $("renderer").dataset.animatedEdges = JSON.stringify(animatedIds);
  if (spatialActive()) {
    updateSpatial();
    $("renderer").dataset.animationActive = "true";
    spatial?.animate(animatedIds, boTransfers);
    return;
  }
  if (matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const started = performance.now();
  animationUntil = started + 650;
  const tick = (now) => {
    if (
      now >= animationUntil ||
      disposed ||
      document.hidden ||
      contextLost ||
      !graph ||
      !presentation
    ) {
      stopAnimation();
      return;
    }
    animationLayer.position.set(pan.x, pan.y);
    animationLayer.scale.set(scale);
    animationDot.clear();
    const t = (now - started) / 650;
    for (const id of animatedIds) {
      const path = edgePaths.get(id);
      if (path) {
        const p = bezierAt(path, boTransfers.get(id)?.reverse ? 1 - t : t);
        const edge = renderedEdges.find((e) => e.id === id),
          style = relationStyles[edge?.type] || relationStyles.other,
          r = 5 / scale;
        if (["guard", "transition"].includes(edge?.type))
          animationDot
            .poly([p.x, p.y - r, p.x + r, p.y, p.x, p.y + r, p.x - r, p.y])
            .fill(style.color);
        else if (["data", "resource", "reads", "writes", "transforms"].includes(edge?.type))
          animationDot.rect(p.x - r, p.y - r, 2 * r, 2 * r).fill(style.color);
        else animationDot.circle(p.x, p.y, r).fill(style.color);
      }
    }
    const node = graph.boxes.find(
      (b) =>
        (boDetail?.rows.some((r) => r.owner === b.id) ||
          (b.node.referenceOf || b.node.event_node || b.id) === event.node ||
          conceptActivityIds(b.node).includes(event.node)) &&
        (presentation.glyphs.has(b.id) || presentation.regions.has(b.id)),
    );
    if (node) {
      const p = point(node),
        region = presentation.regions.has(node.id) && graph.regions.find((r) => r.id === node.id);
      animationDot
        .circle(p.x, p.y, (region?.radius || 32) + 10 * t)
        .stroke({ color: 0x238065, width: 2 / scale, alpha: 1 - t });
    }
    $("renderer").dataset.animationActive = "true";
    app.renderer.render(app.stage);
    animationFrame = requestAnimationFrame(tick);
  };
  animationFrame = requestAnimationFrame(tick);
}
async function refreshRecordings(next, force = false) {
  $("record-clear").disabled =
    recordBusy || recordLoading || recordActive || !recording || !!recording.transient;
  $("record-start").disabled =
    recordBusy ||
    recordLoading ||
    recordActive ||
    !!recording ||
    next.historical ||
    next.binding_status.status !== "current";
  if (!force && Date.now() - lastRecordPoll < 2000) return;
  lastRecordPoll = Date.now();
  try {
    const listing = await recordingRequest("");
    recordActive = !!listing.active;
    if (listing.active) {
      const active = await recordingRequest("/" + encodeURIComponent(listing.active.id));
      liveTraceSource = { ...active, observed_until: new Date().toISOString() };
    } else liveTraceSource = liveTrace.current;
    document.querySelector(".record-bar").dataset.recording = String(recordActive);
    $("record-start").setAttribute("aria-pressed", String(recordActive));
    $("record-clear").disabled =
      recordBusy || recordLoading || recordActive || !recording || !!recording.transient;
    $("capture-mode").disabled = recordActive || !!recording;
    $("record-start").disabled ||= !!listing.active;
    $("record-stop").disabled = recordBusy || !listing.active;
    const selected = recording?.id || "",
      options = listing.recordings.filter((r) => r.status !== "recording");
    const optionKey = JSON.stringify(options.map((r) => [r.id, r.events, r.status, r.gaps]));
    if ($("record-list").dataset.options !== optionKey) {
      $("record-list").replaceChildren(
        new Option(boTranslate("Live observation"), ""),
        ...options.map(
          (r) =>
            new Option(
              boTranslate(
                "{0} \u00B7 {1} events{2}{3}",
                new Date(r.started_at).toLocaleTimeString(),
                r.events,
                r.capture?.mode === "focused" ? boTranslate(" \u00B7 focused") : "",
                r.gaps.length ? boTranslate(" \u00B7 gaps") : "",
              ),
              r.id,
            ),
        ),
      );
      $("record-list").dataset.options = optionKey;
    }
    if (!recordLoading) $("record-list").value = selected;
    const scopeName =
      listing.active?.capture?.mode === "focused"
        ? listing.active.capture.roots
            .map((id) => next.model.nodes.find((n) => n.id === id)?.label || id)
            .join("、")
        : "";
    $("record-status").textContent = listing.active
      ? boTranslate(
          "{0} \u00B7 {1} events",
          scopeName ? boTranslate("Only ") + scopeName : boTranslate("Recording"),
          listing.active.events,
        )
      : listing.error
        ? listing.error
        : recording
          ? ""
          : "";
  } catch (error) {
    $("record-status").textContent = error.message;
    $("record-start").disabled = true;
  }
}
$("record-start").onclick = async () => {
  recordBusy = true;
  try {
    const scope = boCaptureScope();
    await recordingRequest("/start", { scope });
    await refreshRecordings(latestLive, true);
  } catch (error) {
    $("record-status").textContent = error.message;
  } finally {
    recordBusy = false;
    lastRecordPoll = 0;
  }
};
$("record-stop").onclick = async () => {
  recordBusy = true;
  $("record-stop").disabled = true;
  try {
    const saved = await recordingRequest("/stop", {});
    await openRecording(saved.id);
    await refreshRecordings(latestLive, true);
  } catch (error) {
    $("record-status").textContent = error.message;
  } finally {
    recordBusy = false;
    lastRecordPoll = 0;
  }
};
$("record-clear").onclick = async () => {
  if (!recording || recording.transient || recordActive || recordBusy || recordLoading) return;
  recordBusy = true;
  $("record-clear").disabled = true;
  try {
    await recordingRequest("/clear", { id: recording.id });
    leaveRecording();
    await refreshRecordings(latestLive, true);
  } catch (error) {
    $("record-status").textContent = error.message;
  } finally {
    recordBusy = false;
    lastRecordPoll = 0;
  }
};
function replaySelection() {
  return cleanReplaySelection(analysisSettings?.replays?.[recording?.id], replayItems);
}
function changeReplaySelection(patch) {
  if (!recording) return;
  stopPlayback();
  const selection = cleanReplaySelection({ ...replaySelection(), ...patch }, replayItems);
  analysisSettings.replays[recording.id] = selection;
  // Bound private playback preferences without retaining obsolete raw recordings.
  const ids = Object.keys(analysisSettings.replays);
  for (const id of ids.slice(0, Math.max(0, ids.length - 10))) delete analysisSettings.replays[id];
  boPlanKey = "";
  boUpdateReplay();
  save();
  holdCurrentStep();
}
let replayEditorKey = "";
function updateReplaySelection() {
  const selection = replaySelection();
  const key = JSON.stringify([
    recording.id,
    boFullPlan,
    selection,
    analysisSettings.explainedNames,
  ]);
  if (key === replayEditorKey) return;
  replayEditorKey = key;
  $("replay-loop").checked = selection.loop;
  const option = (raw) =>
    new Option(
      `${boFullPlan.indexOf(raw) + 1} · ${eventLabel(replayItems[raw], view.model)}`,
      replayItems[raw].id,
    );
  for (const id of ["replay-loop-from", "replay-loop-to"])
    $(id).replaceChildren(...boFullPlan.map(option));
  $("replay-loop-from").value = selection.from;
  $("replay-loop-to").value = selection.to;
  $("replay-step-list").replaceChildren(
    ...boFullPlan.map((raw, index) => {
      const label = document.createElement("label"),
        check = document.createElement("input");
      check.type = "checkbox";
      check.dataset.eventId = replayItems[raw].id;
      check.checked = !selection.skipped.includes(replayItems[raw].id);
      check.onchange = () =>
        changeReplaySelection({
          skipped: check.checked
            ? replaySelection().skipped.filter((id) => id !== replayItems[raw].id)
            : [...replaySelection().skipped, replayItems[raw].id],
        });
      label.append(check, `${index + 1} · ${eventLabel(replayItems[raw], view.model)}`);
      return label;
    }),
  );
}
$("replay-steps-toggle").onclick = () => {
  $("replay-selection").hidden = !$("replay-selection").hidden;
  $("replay-steps-toggle").setAttribute("aria-expanded", String(!$("replay-selection").hidden));
};
$("replay-loop").onchange = (e) => changeReplaySelection({ loop: e.target.checked });
$("replay-loop-from").onchange = (e) => changeReplaySelection({ from: e.target.value });
$("replay-loop-to").onchange = (e) => changeReplaySelection({ to: e.target.value });
$("replay-include-all").onclick = () => changeReplaySelection({ skipped: [] });

/** Pausing repeats presentation of the same fact; no seek, capture or model mutation. */
function holdCurrentStep() {
  clearTimeout(heldTimer);
  if (!recording || playTimer || disposed) return;
  $("renderer").dataset.replayHeld = "true";
  const replay = () => {
    if (!recording || playTimer || disposed) return;
    if (!document.hidden) animateEvent(replayItems[replayIndex]);
    heldTimer = setTimeout(replay, 850);
  };
  replay();
}
function stopPlayback(hold = false) {
  clearTimeout(playTimer);
  clearTimeout(heldTimer);
  playTimer = heldTimer = null;
  $("renderer").dataset.replayHeld = "false";
  iconButton($("replay-play"), "play", boTranslate("Play"));
  if (hold) holdCurrentStep();
}
function seek(index, locate = false) {
  if (!recording) return;
  replayIndex = Math.max(0, Math.min(replayItems.length - 1, Number(index) || 0));
  choice = "latest";
  step = "latest";
  view = frame(recording, replayIndex, replayItems);
  project();
  updateFacts();
  const item = replayItems[replayIndex];
  if (locate && item.node) {
    if (!graph.byId.has(item.node) && analysisId !== "overview") changeAnalysis("overview");
    revealResult(item.node);
  }
  animateEvent(item);
  if (!playTimer) holdCurrentStep();
}
async function openRecording(id) {
  stopPlayback();
  stopAnimation();
  const requestId = ++recordLoadId;
  recordLoading = true;
  $("record-clear").disabled = true;
  try {
    const saved = await recordingRequest("/" + encodeURIComponent(id));
    if (requestId !== recordLoadId) return;
    if (saved.schema !== "stategraph-recording/v1")
      throw Error(boTranslate("Unsupported recording format"));
    if (latestLive && !recordingMatches(saved, latestLive))
      throw Error(boTranslate("This recording belongs to an earlier graph version."));
    if (!recording)
      replayReturnAnalysis = ["project", "code", "api"].includes(analysisId) ? analysisId : null;
    recording = saved;
    $("record-list").value = saved.id;
    replayItems = timeline(saved);
    boPlanKey = "";
    $("replay").hidden = false;
    document.body.classList.add("is-replay");
    for (const id of ["version", "case", "attempt", "step"]) $(id).disabled = true;
    if (["project", "code", "api"].includes(analysisId)) changeAnalysis("overview");
    updateAnalysisOptions();
    $("code-local").disabled = true;
    $("code-more").hidden = true;
    seek(0);
  } catch (error) {
    if (requestId === recordLoadId) $("record-list").value = recording?.id || "";
    throw error;
  } finally {
    if (requestId === recordLoadId) {
      recordLoading = false;
      $("record-clear").disabled =
        recordBusy || recordActive || !recording || !!recording.transient;
    }
  }
}
function leaveRecording() {
  recordLoadId++;
  recordLoading = false;
  $("record-clear").disabled = true;
  stopPlayback();
  stopAnimation();
  recording = null;
  recordingTimeline.clear();
  if (latestLive) {
    view = withCodeGraph(latestLive, codeLayer.slice);
    project();
  }
  updateAnalysisOptions();
  if (replayReturnAnalysis) changeAnalysis(replayReturnAnalysis);
  replayReturnAnalysis = null;
  boDetail = null;
  boTransfers.clear();
  $("step-changes").hidden = true;
  $("replay").hidden = true;
  document.body.classList.remove("is-replay");
  $("record-list").value = "";
  for (const id of ["version", "case", "attempt", "step"]) $(id).disabled = false;
  lastKey = "";
  lastRecordPoll = 0;
  poller.run();
}
$("record-list").onchange = async (e) => {
  if (!e.target.value) return leaveRecording();
  try {
    await openRecording(e.target.value);
  } catch (error) {
    $("record-status").textContent = error.message;
  }
};
$("replay-live").onclick = leaveRecording;
$("replay-range").oninput = (e) => {
  stopPlayback();
  seek(boPlan[Number(e.target.value)]);
};
$("replay-events").onchange = (e) => {
  stopPlayback();
  seek(Number(e.target.value));
};
$("replay-prev").onclick = () => {
  stopPlayback();
  seek(boPlan.filter((i) => i < replayIndex).at(-1) ?? 0);
};
$("replay-next").onclick = () => {
  stopPlayback();
  seek(boPlan.find((i) => i > replayIndex) ?? replayIndex);
};
$("replay-locate").onclick = () => seek(replayIndex, true);
$("replay-grain").onchange = () => {
  stopPlayback();
  boPlanKey = "";
  boUpdateReplay();
  schedule();
};
$("replay-play").onclick = () => {
  if (playTimer) return stopPlayback(true);
  clearTimeout(heldTimer);
  heldTimer = null;
  $("renderer").dataset.replayHeld = "false";
  if (!boPlan.length) return;
  // Start at the first included step when the selected snapshot is outside the range.
  if (!boPlan.includes(replayIndex) || replayIndex >= boPlan.at(-1)) {
    playTimer = -1;
    seek(boPlan[0]);
  }
  const advance = () => {
    const next = nextReplayIndex(boPlan, replayIndex, replaySelection().loop);
    if (next === undefined) return stopPlayback(true);
    seek(next);
    playTimer = setTimeout(advance, Number($("replay-speed").value));
  };
  iconButton($("replay-play"), "pause", boTranslate("Pause"));
  playTimer = setTimeout(advance, Number($("replay-speed").value));
};
$("replay-export").onclick = () => {
  if (!recording) return;
  const url = URL.createObjectURL(
    new Blob([JSON.stringify(recording, null, 2)], {
      type: "application/json",
    }),
  );
  const link = document.createElement("a");
  link.href = url;
  link.download = "stategraph-" + recording.id + ".json";
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
};
// Read-only debugging data; UI actions use the same pointer/keyboard handlers as users.
window.graphDebug = {
  get timeline() {
    return recordingTimeline.diagnostics;
  },
  get graph() {
    return graph;
  },
  get view() {
    return view;
  },
  get presentation() {
    return presentation;
  },
  get displayGraph() {
    return displayGraph;
  },
  get layers() {
    return { ...analysisSettings?.layers };
  },
  get layoutAlgorithm() {
    return preferences.algorithm || "cluster";
  },
  get camera() {
    return { scale, pan: { ...pan } };
  },
  get spatial() {
    return spatial?.diagnostics || null;
  },
  get spatialPositions() {
    return spatial ? structuredClone(spatial.positions) : {};
  },
  get planarPorts() {
    return [...edgePaths].slice(0, 500).map(([id, path]) => ({
      id,
      start: { ...path.start },
      end: { ...path.end },
      vertices: path.points?.length,
    }));
  },
  get planarCaptions() {
    return renderer.captions;
  },
  get metrics() {
    if (spatialActive()) return spatial?.diagnostics || {};
    return {
      ...metrics,
      drawCount: renderer.frames,
      routeSolver: renderer.routing,
      webgl: !!app.renderer.gl,
    };
  },
  get layoutBusy() {
    return (
      layoutBusy ||
      (spatialActive() ? spatial?.busy || spatial?.router.stats.busy : renderer.routing.busy)
    );
  },
};
const conversation = createConversationFocus({
  onFocus: showDiscussion,
  onClear: () => schedule(),
  onLocale: async (conversation) => {
    const desired = chooseLocale({
      explicit: new URL(window.location.href).searchParams.get("lang"),
      saved: storedLocale(storage),
      conversation,
    });
    if (desired !== locale()) {
      save();
      await storage.flush();
      window.location.reload();
    }
  },
  readState: () => analysisSettings?.discussion,
  hasSavedView: () => analysisWasSaved,
  writeState: (state) => {
    if (!analysisSettings) return;
    analysisSettings.discussion = state;
    saveAnalysis();
  },
});
const poller = createPoller(poll, {
  enabled: () => !disposed && !document.hidden,
});
poller.run();
