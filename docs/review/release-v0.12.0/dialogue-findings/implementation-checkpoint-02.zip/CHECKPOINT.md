# Implementation checkpoint 02

This is retained evidence from an in-progress trial before browser acceptance. It is not an accepted complete application or a release package.

`project/` contains the original corrected observations, API/documentation/database checks, earlier failed verification, maintained application source, graph declarations and tests. `inventory.json` lists the exact archive paths, byte counts and SHA-256 values. Source hashes agree with the corrected manifest and the independent follow-up review.

The earlier `verify-initial.json` failed before the corrections. It is not the verification result for this corrected source snapshot. No corrected full accept/browser result is asserted.

Managed runtime, viewer and dependency code are deliberately excluded. They are available in the immutable public VibeLens v0.12.0 archive:
https://github.com/li-bruce/VibeLens/releases/download/v0.12.0/vibelens-v0.12.0.zip
SHA-256: 9955b650113c41e79c2039dc78ae52d2690f318de87b341bb9af9009869035da

For read-only event review, use the maintained repository's implementation-followup-readonly.py with this extracted project directory and --runtime pointing to the released vibelens/scripts directory. This imports only the pure evidence validators; it does not start the application or browser.

The application accounts and runtime identities are synthetic. Business database files, uploaded contents, vendor trees, virtual environments and real credentials are excluded. No pending approval action was executed while producing this snapshot.
