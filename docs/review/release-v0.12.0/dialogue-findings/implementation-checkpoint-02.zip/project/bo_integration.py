"""Isolated observation of native calls, responses, rules and database access."""

from contextlib import nullcontext
from functools import wraps
import inspect
import json
import threading
import uuid
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent / "observer_runtime"))

from flask import g

from bo_observer.adapters.python.bo_probe import BOProbe
from bo_observer.observation.session import GraphSession
from bo_observer.observation.observation_scope import bo_internal
from bo_observer.policy.recording import record_evaluation
from bo_observer.service import make_server
from bo_observer.data.runtime import BODataRuntime
from bo_stategraph.query import read_authority, machine_snapshot
from opentelemetry.sdk.trace import TracerProvider
from bo_observer.adapters.python.bo_otel import BOOpenTelemetry


class BOIntegration:
    """Keep transport errors separate from actual application authorization."""

    def __init__(self, root, mode="on", port=None, capacity=2048):
        """Load the unchanged canonical collector and a bounded native probe."""
        self.root, self.mode = root, mode
        self.session = GraphSession(root)
        self.errors = 0
        self.raw = []
        self.rejections = []
        self.policies = []
        self.lock = threading.Lock()
        self.service = None
        self.probe = BOProbe(self.session.project, self.session.manifest["build_id"], enabled=mode != "off", capacity=capacity, sink=self.sink)
        self.provider = TracerProvider()
        self.probe.bo_bind_tracing(BOOpenTelemetry(self.provider.get_tracer("file-sharing-trial")))
        self.session.bo_bind_capture(scope_setter=self.probe.bo_set_scope, flush_capture=lambda: self.probe.flush(30), health=self.health)
        config_path = root / "bo_stategraph/databases.json"
        self.data = BODataRuntime(self.probe, json.loads(config_path.read_text(encoding="utf-8"))) if config_path.exists() else None
        self.server = make_server(self.session, port=port, assets=root / "static/graph") if port else None
        if self.server:
            self.session.program_url = "http://127.0.0.1:8897/"
            threading.Thread(target=self.server.serve_forever, daemon=True, name="bo-viewer").start()

    def sink(self, message, kind):
        """Forward actual envelopes to the canonical collector without rewriting them."""
        if self.mode == "fault":
            raise OSError("deliberate_observer_transport_failure")
        try:
            result = self.session.bo_sink(message, kind)
        except Exception as error:
            with self.lock:
                self.rejections.append({"kind": kind, "message": message, "error": str(error)})
            raise
        with self.lock:
            self.raw.append({"kind": kind, "message": message})
        return result

    def failure(self):
        """Count an observation integration failure separately from native results."""
        self.errors += 1

    def health(self):
        """Combine real producer and database adapter health counters."""
        return {**self.probe.bo_health(), "integration_errors": self.errors, "database_errors": self.data.bo_errors if self.data else 0}

    def emit(self, node, phase, values, **identity):
        """Capture native selected facts and genuine before/after state witnesses."""
        if node in {"login", "upload", "approve", "reject", "share", "revoke", "download"} and phase == "return":
            return None  # The enclosing actual method span owns completion.
        if node == "retain_review_record" and phase == "commit":
            values = {**values, "outputs": {**values["outputs"], "error": ""}}
        eid = self.probe.record(node, phase, lambda: values, **identity)
        if node == "transition" and eid:
            value = values["outputs"]
            if phase == "read":
                self.probe.snapshot(value["file_id"], value["before"], {}, value["revision"], eid)
            elif phase == "change":
                for name, result in value["guards"].items():
                    self.probe.record("guard:" + name, "decision", lambda result=result: {"outputs": {"value": result}}, entity=value["file_id"])
                self.probe.snapshot(value["file_id"], value["after"], {}, value["revision"], eid, event=value["event"], guards=value["guards"], payload=value["payload"])
        return eid

    def policy(self, report, object_id):
        """Record the native evaluation's visited expressions without running it again."""
        record_evaluation(self.session.model["policy"], report, self.probe, entity=object_id, attempt=self.probe.bo_current_context().get("attempt", "application"))
        for step in report["trace"]:
            if step["arguments"]:
                self.probe.record("same_identity", "decision", lambda step=step: {"inputs": step["arguments"], "outputs": {"value": step["value"]}}, entity=object_id)
        with self.lock:
            self.policies.append(report)

    def attach(self, service):
        """Attach source-qualified wrappers and read-only native instance queries."""
        self.service = service
        if self.data:
            self.data.attach_sqlalchemy(service.engine)
            native_transaction = service.transaction
            native_projection = service.approved_value

            def observed_transaction(operation, object_id):
                """Observe the unchanged manager's real commit/rollback exit."""
                return self.data.transaction("db:transaction", native_transaction(operation, object_id), parameters={"operation": operation}, entity=object_id)

            def observed_projection(review_status):
                """Observe the single native status-to-Boolean transformation."""
                return self.data.transform("db:approved_value", native_projection, review_status, before=lambda value: {"review_status": value}, after=lambda value: {"file_approved": value})

            service.transaction = observed_transaction
            service.approved_value = observed_projection
        for name in ["login", "logout", "upload", "approve", "reject", "share", "revoke", "download", "dashboard"]:
            original = getattr(service, name)
            setattr(service, name, self.wrap(name, original))
        # GraphSession owns observed snapshot identities. Independent native
        # storage comparisons pass their configurations explicitly to the public query.

    def native_snapshot(self):
        """Read authoritative current fields inside explicit observer exclusion."""
        with bo_internal():
            return machine_snapshot(read_authority(self.service.engine))

    def wrap(self, name, original):
        """Wrap one native function at its true invocation boundary."""
        signature = inspect.signature(original)

        @wraps(original)
        def observed(*args, **kwargs):
            """Run the native function once, retaining its actual return or error."""
            bound = signature.bind(*args, **kwargs)
            selected = {k: v for k, v in bound.arguments.items() if k not in {"password", "content"}}
            if "content" in bound.arguments:
                selected["byte_count"] = len(bound.arguments["content"])
            entity = selected.get("file_id") or selected.get("share_id") or selected.get("session_id") or "application"
            try:
                context = self.probe.span(name, lambda: {"inputs": selected}, entity=entity, scope="entity")
                activation = context.__enter__()
            except Exception:
                self.failure()
                return original(*args, **kwargs)
            try:
                scope = self.data.operation("db:" + name, {}, entity=entity) if self.data and "db:" + name in self.data.bo_operations else nullcontext()
                with scope:
                    result = original(*args, **kwargs)
            except BaseException as error:
                context.__exit__(type(error), error, error.__traceback__)
                raise
            else:
                values = result if isinstance(result, dict) else {}
                if name == "dashboard":
                    values = {"actor_id": result["actor"]["id"], "file_count": len(result["files"]), "message_count": len(result["messages"])}
                activation.result(lambda: {"outputs": {**{k: v for k, v in values.items() if k != "handle"}, "error": ""}})
                context.__exit__(None, None, None)
                return result

        return observed

    def http_start(self, request):
        """Register the exact concrete Flask endpoint and its original request identity."""
        try:
            if request.endpoint == "static":
                return
            node = "api:" + (request.endpoint or "unknown")
            if node not in self.probe.bo_nodes:
                node = "api:framework_error"
            request_id = uuid.uuid4().hex
            context = self.probe.span(node, lambda: {"inputs": {"method": request.method, "path": request.path, "request_id": request_id}}, entity=request_id, attempt=request_id, scope="entity")
            g.bo_http_context = context
            g.bo_http_span = context.__enter__()
        except Exception:
            self.failure()

    def http_end(self, response):
        """Use Flask's actual response status at framework finalization."""
        try:
            if hasattr(g, "bo_http_span"):
                g.bo_http_span.result(lambda: {"outputs": {"status_code": response.status_code, "streamed": response.is_streamed, "error": response.status if response.status_code >= 400 else ""}})
                g.bo_http_context.__exit__(None, None, None)
                del g.bo_http_span
        except Exception:
            self.failure()

    def close(self):
        """Drain captured observations and stop owned observer resources."""
        self.probe.flush(30)
        if self.data:
            self.data.close()
        if self.server:
            self.server.shutdown()
            self.server.server_close()
        self.probe.close()
        self.provider.shutdown()
