"""Bind the frozen user design to actual application symbols and independent cases."""

import ast
from copy import deepcopy
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "observer_runtime"))
from bo_observer.concepts import snapshot
from bo_observer.policy.projection import project as project_policy
from bo_observer.graph.behavior_model import capture
OPERATIONS = ["login", "logout", "upload", "approve", "reject", "share", "revoke", "download", "dashboard"]
SOURCES = ["app.py", "models.py", "service.py", "policy_functions.py", "bo_integration.py", "bo_stategraph/workflow.py", "bo_stategraph/query.py", "build_model.py"]
ROUTES = {"health": ("GET", "/health"), "login_page": ("GET", "/login"), "login": ("POST", "/api/login"), "logout": ("POST", "/api/logout"), "dashboard": ("GET", "/"), "dashboard_data": ("GET", "/api/dashboard"), "upload": ("POST", "/api/files"), "approve": ("POST", "/api/files/<file_id>/approve"), "reject": ("POST", "/api/files/<file_id>/reject"), "share": ("POST", "/api/files/<file_id>/share"), "revoke": ("POST", "/api/shares/<share_id>/revoke"), "download": ("GET", "/download/<share_id>")}


def write(name, data):
    """Write a project-owned generated artifact as UTF-8 JSON."""
    path = ROOT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def declarations(path):
    """Inventory each authored function independently of graph inclusion."""
    result = {}

    def visit(items, prefix=""):
        """Retain nested lexical names even when declarations occur in control flow."""
        for item in items:
            if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                name = prefix + item.name
                if not isinstance(item, ast.ClassDef):
                    result[name] = [arg.arg for arg in item.args.posonlyargs + item.args.args + item.args.kwonlyargs if arg.arg not in {"self", "cls"}]
                visit(item.body, name + ".")
            else:
                visit(list(ast.iter_child_nodes(item)), prefix)

    visit(ast.parse((ROOT / path).read_text(encoding="utf-8")).body)
    return result


def main():
    """Generate exact native semantics and mappings without changing confirmations."""
    discovery = json.loads((ROOT / "discovery.json").read_text(encoding="utf-8"))
    confirmed = snapshot(discovery)
    designed = discovery["state_models"][0]
    policy = deepcopy(discovery["policy"])
    policy["stage"] = "bound"
    for predicate in policy["predicates"]:
        predicate["source"] = {"path": "policy_functions.py", "symbol": "same_identity"}
        predicate["implementation_node"] = "same_identity"
    for operation in policy["operations"]:
        operation["business_nodes"] = [operation["id"]]
        operation["cases"] = ["full-workflow"]
    machine = {"engine": "bo.fsm", "version": "1", "states": deepcopy(designed["states"]), "values": deepcopy(designed["states"]), "initial": designed["initial"], "events": {k: {"payload": v["payload"]} for k, v in designed["events"].items()}, "context": {}, "guards": {}, "transitions": []}
    for name in designed["guards"]:
        machine["guards"][name] = {"source": {"path": "bo_stategraph/workflow.py", "symbol": "ReviewDriver." + name}}
    machine["state_type"] = "enum"
    for transition in designed["transitions"]:
        machine["transitions"].append({k: deepcopy(transition[k]) for k in ["source", "dest", "trigger", "conditions", "unless"] if k in transition})
    nodes, edges = [], []

    def node(ident, symbol, inputs=None, outputs=None, path="service.py", layer="business", kind="action", **extra):
        """Bind one authored graph node to its exact native source and capture shape."""
        value = {"id": ident, "kind": kind, "label": ident.replace("_", " "), "summary": symbol + " implements this source-bound operation; inspect its native docstring for exact behavior.", "layer": layer, "source": {"path": path, "symbol": symbol}, "capture": {"in": inputs or {}, "out": outputs or {}}, **extra}
        nodes.append(value)
        return value

    def edge(ident, left, right, kind="flow"):
        """Record an explicit relation without asserting that it executed."""
        edges.append({"id": ident, "from": left, "to": right, "type": kind, "evidence": "Explicit native operation or confirmed semantic binding"})

    node("login", "FileService.login", {"account": "string"}, {"session_id": "string", "actor_id": "string", "is_reviewer": "boolean", "authenticated": "boolean", "error": "string"})
    node("logout", "FileService.logout", {"session_id": "string"}, {"error": "string"})
    node("upload", "FileService.upload", {"session_id": "string", "filename": "string", "byte_count": "number"}, {"file_id": "string", "state": "string", "byte_count": "number", "transaction_id": "string", "committed": "boolean", "error": "string"})
    review_output = {"file_id": "string", "state": "string", "review_id": "string", "reviewer_id": "string", "transaction_id": "string", "committed": "boolean", "error": "string"}
    for name in ["approve", "reject"]:
        node(name, "FileService." + name, {"session_id": "string", "file_id": "string"}, review_output)
    grant_output = {"file_id": "string", "share_id": "string", "recipient_id": "string", "active": "boolean", "review_status": "string", "transaction_id": "string", "committed": "boolean", "error": "string"}
    node("share", "FileService.share", {"session_id": "string", "file_id": "string", "recipient_id": "string"}, grant_output)
    node("revoke", "FileService.revoke", {"session_id": "string", "share_id": "string"}, grant_output)
    node("download", "FileService.download", {"session_id": "string", "share_id": "string"}, {"file_id": "string", "share_id": "string", "name": "string", "byte_count": "number", "error": "string"})
    node("dashboard", "FileService.dashboard", {"session_id": "string"}, {"actor_id": "string", "file_count": "number", "message_count": "number", "error": "string"})
    node("notify", "FileService.received_messages", outputs={"message_id": "string", "file_id": "string", "share_id": "string", "recipient_id": "string", "actor_id": "string", "active": "boolean"})
    node("deny_old_link", "FileService.download", outputs={"file_id": "string", "share_id": "string", "actor_id": "string", "recipient_id": "string", "active": "boolean", "reason": "string"})
    node("read_facts", "FileService.read_facts", {"session_id": "string"}, policy["inputs"], layer="program", kind="function")
    node("same_identity", "same_identity", {"left": "string", "right": "string"}, {"value": "boolean"}, path="policy_functions.py", layer="program", kind="function")
    node("permission", "FileService.permission", outputs={"allowed": "boolean"}, layer="predicate", kind="decision")
    node("retain_review_record", "FileService.review", outputs=review_output, layer="program", kind="effect")
    node("transaction", "FileService.transaction", outputs={"transaction_id": "string", "committed": "boolean", "operation": "string"}, layer="program", kind="effect")
    for item in nodes:
        if item["id"] in {"transaction", "retain_review_record"}:
            item["lifecycle"] = {"states": [{"id": "running", "label": "Running", "kind": "active"}, {"id": "committed", "label": "Committed", "kind": "ended"}, {"id": "failed", "label": "Failed", "kind": "ended"}], "bindings": [{"phase": "enter", "state": "running", "boundary": "start"}, {"phase": "commit", "state": "committed", "boundary": "end"}, {"phase": "error", "state": "failed", "boundary": "end"}]}
    node("transition", "FileService.transition", outputs={"file_id": "string", "before": "string", "after": "string", "before_revision": "number", "revision": "number", "event": "string", "transaction_id": "string", "payload": {}, "guards": {k: "boolean" for k in machine["guards"]}}, layer="program", kind="function")
    for name in machine["guards"]:
        operation = name.removeprefix("may_")
        node("guard:" + name, "ReviewDriver." + name, outputs={"value": "boolean"}, path="bo_stategraph/workflow.py", layer="predicate", kind="decision", policy_operation=operation)
    for state in designed["states"]:
        nodes.append({"id": "state:" + state, "kind": "state", "label": state, "summary": "Declared native file review status: " + state, "value": state, "layer": "state"})
    for endpoint in [*ROUTES, "framework_error"]:
        node("api:" + endpoint, "create_app." + endpoint, {"method": "string", "path": "string", "request_id": "string"}, {"status_code": "number", "streamed": "boolean", "error": "string"}, path="app.py", layer="api", kind="function")
    node("build_model", "main", path="build_model.py", layer="program", kind="function")
    for left, right in [("login", "upload"), ("upload", "approve"), ("upload", "reject"), ("approve", "share"), ("share", "dashboard"), ("dashboard", "download"), ("share", "revoke")]:
        edge(left + "-" + right, left, right)
    source_files = [*SOURCES, "implementation.json", "bo_stategraph/telemetry.json", *[p.relative_to(ROOT).as_posix() for p in (ROOT / "templates").glob("*.html")], "static/app/style.css"]
    model = {"schema_version": 3, "revision": "implementation-01", "title": "Colleague file sharing", "intent": "intent.json", "source_files": sorted(source_files), "nodes": nodes, "edges": edges, "overview": [{"node": name, "x": (i % 4) * 260, "y": (i // 4) * 170} for i, name in enumerate(["login", "upload", "approve", "share", "reject", "dashboard", "download", "revoke"])], "scope": {"observable": ["File review declaration", "Native session and grant mutations", "Real framework HTTP responses", "Native rule evaluation"], "unknowns": ["Single local SQLite application; no production deployment claim", "No bound session or sharing state machine", "Finite runtime cases do not establish all possible paths"]}, "machine": machine, "policy": policy, "presentation": {"subject": "file", "default_node": "upload", "names": {"nodes": {}, "edges": {}, "states": {}, "events": {}}}}
    model = project_policy(model)
    business = {item["id"]: [item["id"]] for network in discovery["networks"] for item in network["nodes"]}
    binding = {"schema": "bo-concept-bindings/v1", "semantic_revision": confirmed["semantic_revision"], "primary_state_model": "file_review", "objects": {"file_review": deepcopy(designed["subject"])}, "business": business, "facts": {}, "expectations": {}, "crosslinks": {}, "events": {}, "guards": {}, "effects": {"effect:file_review:retain_review_record": ["retain_review_record"]}, "transition_effects": {}}
    checks = []
    for expectation in discovery["expectations"]:
        case = expectation["id"]
        binding["expectations"][case] = [case]
        for i, assertion in enumerate(expectation["then"]):
            checks.append({"id": case + ":" + str(i), "requirement": "R1", "case": case, **deepcopy(assertion)})
    for fact in discovery["facts"]:
        value = {"node": "read_facts", "direction": "out", "field": fact["id"], "read_basis": fact["read_basis"]}
        checks.append({"id": "basis:" + fact["id"], "requirement": "R1", "case": "full-workflow", "path": ["read_basis", fact["id"]], "equals": value})
        binding["facts"][fact["id"]] = [{k: v for k, v in value.items() if k != "read_basis"} | {"basis_checks": [{"case": "full-workflow", "path": ["read_basis", fact["id"]]}]}]
    for event in designed["events"]:
        binding["events"]["event:file_review:" + event] = {"node": event, "event": event}
    for guard, value in designed["guards"].items():
        decision = value["decision"].replace("policy:operation:", "policy-operation:")
        binding["guards"]["guard:file_review:" + guard] = {"node": "guard:" + guard, "decision": decision, "field": "value"}

    def anchor(reference):
        """Resolve each confirmed conceptual identity to its actual native anchor."""
        if reference.startswith(("policy:operation:", "policy-operation:")):
            operation_id = reference.split(":")[-1]
            return "policy:" + next(o["root"] for o in policy["operations"] if o["id"] == operation_id)
        if reference in business:
            return business[reference][0]
        if reference.startswith("fact:"):
            return "read_facts"
        if reference.startswith("event:file_review:"):
            return reference.split(":")[-1]
        if reference.startswith("transition:file_review:"):
            tid = reference.split(":")[-1]
            return next(t["trigger"] for t in designed["transitions"] if t["id"] == tid)
        if reference.startswith("guard:file_review:"):
            return "guard:" + reference.split(":")[-1]
        if reference.startswith("effect:"):
            return "retain_review_record"
        return reference

    for link in discovery["crosslinks"]:
        left, right = anchor(link["from"]), anchor(link["to"])
        relation = link["relation"]
        if relation == "action_requests_event" and left == right:
            binding["crosslinks"][link["id"]] = {"relation": relation, "from": [left], "to": [right], "native_event": right, "edges": []}
            continue
        if relation in {"transition_guarded_by", "decision_reads_fact"}:
            left, right = right, left
        eid = "binding:" + link["id"]
        edge(eid, left, right, "guard" if relation == "transition_guarded_by" else "data")
        binding["crosslinks"][link["id"]] = [eid]
    # Policy projection made a copy; append subsequent explicit native relations.
    model["edges"].extend(e for e in edges if e["id"].startswith("binding:"))
    for transition in designed["transitions"]:
        if not transition.get("effects"):
            continue
        event = transition["trigger"]
        eid = "effect:" + event + "-record"
        model["edges"].append({"id": eid, "from": event, "to": "retain_review_record", "type": "data", "evidence": "FileService.review commits the state and ReviewRecord in the same native transaction"})
        binding["transition_effects"]["transition:file_review:" + transition["id"]] = [{"effect": "effect:file_review:retain_review_record", "edges": [eid], "completion": {"node": "retain_review_record", "phase": "commit", "field": "committed", "equals": True, "identity_field": "transaction_id", "boundary": designed["effects"]["retain_review_record"]["completion"], "expectation": "review-decision-record-committed", "path": ["review_record_committed"]}}]
    model["concepts"] = binding
    for network in discovery["networks"]:
        for item in network["nodes"]:
            for target in business[item["id"]]:
                model["presentation"]["names"]["nodes"][target] = {"en": target.replace("_", " "), "zh-CN": item["label"]}
    telemetry = {"protocol": "bo-telemetry/v1", "backend": "opentelemetry", "registrations": [{"node": "api:" + name, "source": {"path": "app.py", "symbol": "create_app." + name}, "match": {"name": method + " " + route}, "capture": {"out": {"status_code": "http.response.status_code"}}} for name, (method, route) in ROUTES.items()]}
    write("bo_stategraph/telemetry.json", telemetry)
    write("intent.json", {"intent_id": "colleague-file-sharing", "revision": "confirmed-04", "goal": "Implement the confirmed local file sharing workflow", "requirements": [{"id": "R1", "text": "Preserve the confirmed business network, file-review state machine and shared rules", "status": "confirmed", "source": "discovery.json U_SIM_04 and C04_confirmed_scope"}], "exclusions": ["Public sharing links", "Additional bound state machines", "Production deployment"]})
    if not (ROOT / "acceptance.json").exists():
        write("acceptance.json", {"description": "Independent expected outcomes fixed from the approved discovery, before execution", "checks": checks, "model_checks": []})
    plan = {"schema": "bo-implementation/v1", "features": [], "support": {}, "excluded": {}}
    index = {path: declarations(path) for path in SOURCES}
    for name in OPERATIONS:
        sid = "service.py::FileService." + name
        params = []
        for argument in index["service.py"]["FileService." + name]:
            field, policy_name, direction = argument, "value", "in"
            if argument == "password":
                field, policy_name, direction = "authenticated", "derived", "out"
            if argument == "content":
                field, policy_name = "byte_count", "derived"
            params.append({"source": sid, "name": argument, "node": name, "direction": direction, "field": field, "policy": policy_name, **({"reason": "Capture only the actual authentication outcome" if argument == "password" else "Capture the actual submitted byte count"} if policy_name != "value" else {})})
        plan["features"].append({"id": name, "label": name, "business_node": name, "nodes": [name], "sources": [sid], "parameters": params, "cases": [{"case": "full-workflow", "node": name, "phase": "return", "values": []}]})
    for name in ROUTES:
        target = name if name in OPERATIONS else "dashboard"
        sid = "app.py::create_app." + name
        node_id = "api:" + name
        plan["features"].append({"id": node_id, "label": name, "business_node": target, "nodes": [node_id], "sources": [sid], "parameters": [{"source": sid, "name": p, "node": node_id, "direction": "in", "field": "path", "policy": "derived", "reason": "The original HTTP path contains this concrete route identifier"} for p in index["app.py"]["create_app." + name]], "cases": [{"case": "full-workflow", "node": node_id, "phase": "return", "values": []}]})
    entry_sources = {s for f in plan["features"] for s in f["sources"]}
    for path, symbols in index.items():
        for symbol in symbols:
            sid = path + "::" + symbol
            if sid in entry_sources:
                continue
            if path == "bo_integration.py" or symbol.split(".")[-1].startswith("bo_"):
                plan["excluded"][sid] = {"category": "observer", "reason": "Isolated observation transport or wiring; never business authority"}
            elif symbol.endswith(".__init__"):
                plan["excluded"][sid] = {"category": "construction", "reason": "Instance construction; exercised by native startup and scenarios"}
            else:
                target = next((n["id"] for n in model["nodes"] if n.get("source") == {"path": path, "symbol": symbol}), "build_model" if path == "build_model.py" else "transition" if "workflow" in path or "query" in path else "dashboard")
                plan["support"][sid] = {"node": target, "reason": "Native supporting implementation; source remains discoverable and is not claimed executed from this mapping alone"}
    model["implementation"] = plan
    write("implementation.json", plan)
    project = {"protocol": "bo-project/v1", "project_id": discovery["project_id"], "selection": {"mode": "drive", "source": "user", "answer": "Drive file_review only; session and sharing remain native objects", "locator": "discovery.json U_SIM_02 and U_SIM_04"}, "model": model}
    write("bo_stategraph/project.json", project)
    config = json.loads((ROOT / "sync.json").read_text(encoding="utf-8"))
    config.update({"model": "bo_stategraph/project.json", "manifest": "manifest.json", "code_files": SOURCES, "watch_files": ["build_model.py", "tests/observe.py", "tests/test_business.py"], "acceptance": "acceptance.json", "mapping_contract": "mapping.json", "stategraph": {"module": "bo_stategraph/__init__.py", "development_mode": "drive", "execution_mode": "drive", "decision_source": "user", "decision": "discovery.json U_SIM_02 and U_SIM_04: drive only file_review"}, "require_mapping_witnesses": True, "require_probe_health": True, "require_observation_closure": True, "probe_modes": ["on", "off", "fault"], "probe_callees": ["self.bo_emit"], "required_probes": [{"symbol": "service.py::FileService.transition", "node": "transition", "phase": "read"}], "required_runtime_probes": [{"case": "full-workflow", "node": "transition", "phase": "change"}], "observations_command": ["{python}", "-B", "tests/observe.py"], "test_commands": [["{python}", "-B", "tests/test_business.py"]], "timeout_seconds": 180})
    config["stategraph"]["decision"] = project["selection"]["answer"]
    config["watch_files"].extend(["tests/scenarios.py", "bo_stategraph/__init__.py", "bo_stategraph/bo_contracts.py", "bo_stategraph/execution_contract.py"])
    prune = config["source_scope"]["prune"]
    for path, category, reason in [("observer_runtime", "dependency", "Managed unchanged v0.12.0 observer copy"), ("static/graph", "dependency", "Managed unchanged v0.12.0 viewer"), ("bo_stategraph/policy", "dependency", "Managed native policy core"), ("bo_stategraph/data", "artifact", "Observer runtime recordings"), ("review/implementation-01", "artifact", "Frozen implementation evidence")]:
        if not any(p["path"] == path for p in prune):
            prune.append({"path": path, "category": category, "reason": reason})
    config["source_scope"]["exclude"] = {"tooling/**": "Review and process utilities, versioned separately", "tests/**": "Independent scenario runners executed by verification", "bo_stategraph/__init__.py": "Managed unchanged public stategraph core", "bo_stategraph/bo_contracts.py": "Managed unchanged native validation", "bo_stategraph/execution_contract.py": "Managed unchanged execution validation"}
    write("sync.json", config)
    if not (ROOT / "mapping.json").exists():
        write("mapping.json", {"schema": "bo-mapping/v1", "cases": ["full-workflow"], "modes": ["on", "off", "fault"], "source": {"path": "bo_stategraph/query.py", "symbol": "read_authority"}, "actual_collection": ["authority_snapshot", "files"], "actual_id": ["id"], "fields": [{"id": "state", "node": "transition", "actual": ["state"], "mapped": ["state"]}, {"id": "revision", "node": "transition", "actual": ["revision"], "mapped": ["revision"]}, {"id": "build", "node": "transition", "actual": ["build_id"], "mapped": ["build_id"]}], "export": {"case": "full-workflow", "mode": "on"}})
    if (ROOT / "bo_stategraph/databases.json").exists():
        from bo_observer.data.sync import synchronize
        report = synchronize(ROOT)
        if not report["valid"]:
            raise ValueError("Database projection failed: " + json.dumps(report))
        model = json.loads((ROOT / "bo_stategraph/project.json").read_text(encoding="utf-8"))["model"]
    owned = {n for f in plan["features"] for n in f["nodes"]}
    shared = next(f for f in plan["features"] if f["id"] == "upload")
    for item in model["nodes"]:
        if item["id"] in owned or not any(item.get("capture", {}).values()):
            continue
        ident = item["id"]
        phase = "decision" if ident.startswith(("policy:", "guard:")) or ident in {"same_identity", "permission", "deny_old_link"} else "commit" if ident in {"transaction", "retain_review_record", "db:transaction"} else "change" if ident in {"transition", "db:approved_value"} else "read" if ident in {"read_facts", "notify"} else "return"
        shared["nodes"].append(ident)
        shared["cases"].append({"case": "full-workflow", "node": ident, "phase": phase, "values": []})
    model["implementation"] = plan
    for feature in plan["features"]:
        for ident in list(feature["nodes"]):
            item = next(n for n in model["nodes"] if n["id"] == ident)
            if ident.startswith("api:") or ident in OPERATIONS:
                feature["cases"].append({"case": "full-workflow", "node": ident, "phase": "enter", "values": []})
            if ident in {"upload", "approve", "reject", "share", "revoke", "download", "dashboard", "login"}:
                feature["cases"].append({"case": "full-workflow", "node": ident, "phase": "error", "values": []})
    write("implementation.json", plan)
    from bo_observer.graph.code_structure import scan, enrich
    model = enrich(model, scan(ROOT, SOURCES))
    project["model"] = model
    write("bo_stategraph/project.json", project)
    write("manifest.json", capture(ROOT, model))
    print(json.dumps({"nodes": len(model["nodes"]), "edges": len(model["edges"]), "source_files": len(source_files), "status": "generated; verification remains required"}))


if __name__ == "__main__":
    main()
