"""Pure native predicates called by the application's permission evaluator."""


def same_identity(left: str, right: str) -> bool:
    """Compare two actual account identities from one request read basis.

    Args:
        left: First account identity read by the application.
        right: Second account identity read by the application.

    Returns:
        Whether the two identities are equal.
    """
    return left == right
