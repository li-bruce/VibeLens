# Observation clarification

Actual received authorized simulation message, not a new business workflow:

验收时请再替我核对三个容易误读的地方：普通样式文件加载成功，不能在图里算成“框架错误”；上传者打开首页且没有收到消息，不能算“接收人看到消息”；某次权限检查被拒绝，也不能一概算成“撤销后旧链接被拒绝”，要看这次请求真实的对象和原因。审核记录的开始、完成和事务提交也要能够对应起来。这些都还是原来功能的如实观察要求，请用实际操作的正反结果核对，不需要增加新的业务流程。
