"""Local Flask UI and concrete HTTP boundaries for the file-sharing trial."""

import argparse
import json
from pathlib import Path
import secrets

from flask import Flask, Response, g, jsonify, redirect, render_template, request, session, url_for
from werkzeug.exceptions import HTTPException

from models import create_store
from service import BusinessError, FileService

ROOT = Path(__file__).resolve().parent


def create_app(data_dir: Path | None = None, observer=None) -> Flask:
    """Construct the native app with a dedicated data directory and optional observer.

    Args:
        data_dir: Instance-owned database and uploads; defaults to project var/app.
        observer: Optional isolated receiver of already obtained native facts.
    """
    data_dir = (data_dir or ROOT / "var" / "app").resolve()
    data_dir.mkdir(parents=True, exist_ok=True)
    secret_path = data_dir / "session-secret.txt"
    if not secret_path.exists():
        secret_path.write_text(secrets.token_hex(32), encoding="ascii")
    application = Flask(__name__, static_folder="static/app", static_url_path="/assets")
    application.config.update(SECRET_KEY=secret_path.read_text(encoding="ascii"), MAX_CONTENT_LENGTH=17 * 1024 * 1024, SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")
    project = json.loads((ROOT / "bo_stategraph/project.json").read_text(encoding="utf-8"))
    engine = create_store(data_dir / "app.sqlite3")
    service = FileService(engine, data_dir / "uploads", project, ROOT, observer)
    application.extensions["service"] = service
    application.extensions["observer"] = observer

    @application.before_request
    def before_request():
        """Start actual HTTP observation and validate CSRF on every mutation."""
        session.setdefault("csrf", secrets.token_urlsafe(24))
        if observer is not None:
            observer.http_start(request)
        if request.method == "POST":
            token = request.headers.get("X-CSRF-Token") or request.form.get("csrf", "")
            if not secrets.compare_digest(token, session["csrf"]):
                raise BusinessError("页面验证已过期，请刷新后重试。", 400)

    @application.after_request
    def after_request(response):
        """Capture the real framework response status, including denied requests."""
        response.headers["Cache-Control"] = "no-store"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        if observer is not None:
            observer.http_end(response)
        return response

    def respond(result, notice):
        """Return JSON to API clients or a native redirect for submitted HTML forms."""
        if request.accept_mimetypes.best == "application/json" or request.is_json:
            return jsonify(result)
        session["notice"] = notice
        return redirect(url_for("dashboard"), code=303)

    def payload():
        """Read the submitted JSON object or regular form without altering values."""
        return request.get_json(silent=True) or request.form

    @application.errorhandler(BusinessError)
    def business_error(error):
        """Render the actual native rejection with its real HTTP status."""
        if request.accept_mimetypes.best == "application/json" or request.is_json:
            return jsonify(error=str(error)), error.status
        return render_template("error.html", message=str(error), status=error.status), error.status

    @application.errorhandler(HTTPException)
    def framework_error(error):
        """Render actual framework errors without inventing a successful operation."""
        if request.accept_mimetypes.best == "application/json":
            return jsonify(error=error.name), error.code
        return render_template("error.html", message=error.name, status=error.code), error.code

    @application.get("/health")
    def health():
        """Report process availability without reading or mutating business objects."""
        return jsonify(status="ok", application="file-sharing-trial", observer_enabled=observer is not None)

    @application.get("/login")
    def login_page():
        """Show the four seeded local trial identities and a password form."""
        return render_template("login.html")

    @application.post("/api/login")
    def login():
        """Authenticate the submitted account and replace the signed login identity."""
        values = payload()
        result = service.login(str(values.get("account", "")), str(values.get("password", "")))
        if session.get("session_id"):
            service.logout(session["session_id"])
        session["session_id"] = result["session_id"]
        return respond(result, "登录成功。")

    @application.post("/api/logout")
    def logout():
        """Invalidate the current native login and return to account selection."""
        if session.get("session_id"):
            service.logout(session.pop("session_id"))
        if request.accept_mimetypes.best == "application/json":
            return jsonify(authenticated=False)
        return redirect(url_for("login_page"), code=303)

    @application.get("/")
    def dashboard():
        """Show the actor's files, review controls and recipient messages."""
        if not session.get("session_id"):
            return redirect(url_for("login_page"))
        data = service.dashboard(session["session_id"])
        return render_template("dashboard.html", **data, notice=session.pop("notice", None))

    @application.get("/api/dashboard")
    def dashboard_data():
        """Return the same authorized dashboard values for independent HTTP checks."""
        return jsonify(service.dashboard(session.get("session_id", "")))

    @application.post("/api/files")
    def upload():
        """Accept bytes for one fresh file and commit its pending review state."""
        incoming = request.files.get("file")
        if incoming is None:
            raise BusinessError("请选择一个文件。", 400)
        result = service.upload(session.get("session_id", ""), incoming.filename or "", incoming.read())
        return respond(result, "已上传，等待审核。每次上传都会生成新的文件编号。")

    @application.post("/api/files/<file_id>/approve")
    def approve(file_id: str):
        """Approve a pending file after actual reviewer and non-uploader checks.

        Args:
            file_id: Identity from the concrete file approval route.
        """
        return respond(service.approve(session.get("session_id", ""), file_id), "审核已通过；上传者现在可以选择接收人。")

    @application.post("/api/files/<file_id>/reject")
    def reject(file_id: str):
        """Reject a pending file while retaining the exact file and review record.

        Args:
            file_id: Identity from the concrete file rejection route.
        """
        return respond(service.reject(session.get("session_id", ""), file_id), "已驳回，原文件与审核记录保留。")

    @application.post("/api/files/<file_id>/share")
    def share(file_id: str):
        """Create one recipient grant only for the uploader's approved file.

        Args:
            file_id: File whose approved state is read without being changed.
        """
        result = service.share(session.get("session_id", ""), file_id, str(payload().get("recipient_id", "")))
        return respond(result, "共享已生效，接收人已收到站内消息。")

    @application.post("/api/shares/<share_id>/revoke")
    def revoke(share_id: str):
        """Disable the selected grant after verifying the current uploader identity.

        Args:
            share_id: Persistent grant identity selected for revocation.
        """
        return respond(service.revoke(session.get("session_id", ""), share_id), "共享已撤销。旧链接的新下载请求也会被拒绝。")

    @application.get("/download/<share_id>")
    def download(share_id: str):
        """Authorize a new transfer and stream the already opened file to completion.

        Args:
            share_id: Grant identity; possession of this URL does not authorize access.
        """
        result = service.download(session.get("session_id", ""), share_id)

        def chunks():
            """Close the native handle after completion or client disconnection."""
            with result["handle"] as handle:
                while data := handle.read(65536):
                    yield data

        from urllib.parse import quote
        response = Response(chunks(), mimetype="application/octet-stream")
        response.headers["Content-Length"] = str(result["byte_count"])
        response.headers["Content-Disposition"] = "attachment; filename*=UTF-8''" + quote(result["name"], safe="")
        response.call_on_close(result["handle"].close)
        return response

    return application


def main():
    """Run the loopback-only application with optional isolated VibeLens integration."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8897)
    parser.add_argument("--graph-port", type=int, default=8898)
    parser.add_argument("--observer", choices=["on", "off", "fault"], default="on")
    options = parser.parse_args()
    observer = None
    if options.observer != "off":
        try:
            from bo_integration import BOIntegration
            observer = BOIntegration(ROOT, mode=options.observer, port=options.graph_port)
        except Exception as error:
            print("Observer unavailable; native application continues:", repr(error), flush=True)
    application = create_app(observer=observer)
    if observer:
        observer.attach(application.extensions["service"])
    application.run(host="127.0.0.1", port=options.port, threaded=True, use_reloader=False)


if __name__ == "__main__":
    main()
