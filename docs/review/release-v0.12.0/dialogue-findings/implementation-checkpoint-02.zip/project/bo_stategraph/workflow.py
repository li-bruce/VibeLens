"""Project-owned native driver of the confirmed file-review declaration."""

from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "observer_runtime"))
from bo_observer.adapters.python.bo_executor import BOExecutor


class ReviewDriver:
    """Use the declared transitions and the already evaluated native permission."""

    def __init__(self, machine: dict, allowed: bool):
        """Bind a request-local decision to each declared review guard."""
        self.allowed = allowed
        self.executor = BOExecutor(machine, {"may_upload": self.may_upload, "may_approve": self.may_approve, "may_reject": self.may_reject})

    def may_upload(self, context: dict, payload: dict) -> bool:
        """Return the current upload permission, without rereading volatile facts."""
        return self.allowed

    def may_approve(self, context: dict, payload: dict) -> bool:
        """Return the current reviewer and non-uploader permission for approval."""
        return self.allowed

    def may_reject(self, context: dict, payload: dict) -> bool:
        """Return the same current reviewer and non-uploader permission for rejection."""
        return self.allowed

    def step(self, state: str, event: str) -> dict:
        """Execute one declared file transition; the caller commits its effects.

        Args:
            state: Actual file status before this request's mutation.
            event: Requested upload, approve or reject event.
        """
        return self.executor.step(state, event, {}, {})
