"""Project-owned independent read adapter for the unchanged public stategraph."""

import json
from sqlalchemy import select
from sqlalchemy.orm import Session
from models import FileRecord, NativeJournal


def read_authority(engine) -> dict:
    """Read actual file states and native journals using a new database session.

    Args:
        engine: Native SQLAlchemy engine; this function performs no writes.
    """
    with Session(engine) as db:
        files = [{"id": f.id, "state": f.review_status, "revision": f.revision,
                  "build_id": f.run_build_id, "uploader_id": f.uploader_id}
                 for f in db.scalars(select(FileRecord).order_by(FileRecord.id))]
        journal = [{"sequence": j.sequence, "operation": j.operation, "object_id": j.object_id,
                    "transaction_id": j.transaction_id, "values": json.loads(j.payload)}
                   for j in db.scalars(select(NativeJournal).order_by(NativeJournal.sequence))]
        return {"files": files, "journal": journal}


def machine_snapshot(authority: dict) -> dict:
    """Translate actual stored fields without inventing transitions or revisions.

    Args:
        authority: Result of the independent native storage reader.
    """
    return {"configurations": [{"attempt": f["id"], "phase": f["state"], "state_revision": f["revision"],
                                "run_build_id": f["build_id"], "context": {}, "source_status": "current"}
                               for f in authority["files"]]}
