"""Native SQLite models; application transactions own all business state."""

from datetime import datetime, timezone
from pathlib import Path
from sqlalchemy import Boolean, CheckConstraint, ForeignKey, Integer, String, Text, create_engine, event
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column
from werkzeug.security import generate_password_hash


def utc_now() -> str:
    """Return an ISO timestamp for a committed native record."""
    return datetime.now(timezone.utc).isoformat()


class Base(DeclarativeBase):
    """Declare native tables without creating them at import time."""


class User(Base):
    """An existing local account; role is read on each protected request."""
    __tablename__ = "users"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    display_name: Mapped[str] = mapped_column(String)
    password_hash: Mapped[str] = mapped_column(String)
    is_reviewer: Mapped[bool] = mapped_column(Boolean, default=False)


class LoginSession(Base):
    """A native login identity, deliberately without a bound session FSM."""
    __tablename__ = "login_sessions"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    actor_id: Mapped[str] = mapped_column(ForeignKey("users.id"))
    authenticated: Mapped[bool] = mapped_column(Boolean)
    created_at: Mapped[str] = mapped_column(String, default=utc_now)


class FileRecord(Base):
    """A fresh identity per upload with one authoritative review status."""
    __tablename__ = "files"
    __table_args__ = (CheckConstraint("review_status IN ('awaiting_upload','pending_review','approved','rejected')"),)
    id: Mapped[str] = mapped_column(String, primary_key=True)
    uploader_id: Mapped[str] = mapped_column(ForeignKey("users.id"))
    name: Mapped[str] = mapped_column(String)
    storage_name: Mapped[str] = mapped_column(String, unique=True)
    byte_count: Mapped[int] = mapped_column(Integer)
    review_status: Mapped[str] = mapped_column(String)
    revision: Mapped[int] = mapped_column(Integer, default=0)
    run_build_id: Mapped[str] = mapped_column(String)
    created_at: Mapped[str] = mapped_column(String, default=utc_now)

    @property
    def approved(self) -> bool:
        """Derive the rule input from the stored review status; never write it."""
        return self.review_status == "approved"


class ReviewRecord(Base):
    """An immutable review decision retained when another file is uploaded."""
    __tablename__ = "reviews"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    file_id: Mapped[str] = mapped_column(ForeignKey("files.id"), unique=True)
    reviewer_id: Mapped[str] = mapped_column(ForeignKey("users.id"))
    decision: Mapped[str] = mapped_column(String)
    transaction_id: Mapped[str] = mapped_column(String)
    created_at: Mapped[str] = mapped_column(String, default=utc_now)


class ShareGrant(Base):
    """One designated recipient per file with native revocation status."""
    __tablename__ = "shares"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    file_id: Mapped[str] = mapped_column(ForeignKey("files.id"), unique=True)
    recipient_id: Mapped[str] = mapped_column(ForeignKey("users.id"))
    active: Mapped[bool] = mapped_column(Boolean)
    created_at: Mapped[str] = mapped_column(String, default=utc_now)


class Message(Base):
    """A site message created in the same transaction as its grant."""
    __tablename__ = "messages"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    share_id: Mapped[str] = mapped_column(ForeignKey("shares.id"))
    recipient_id: Mapped[str] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[str] = mapped_column(String, default=utc_now)


class NativeJournal(Base):
    """Committed native transitions and object changes with transaction identity."""
    __tablename__ = "native_journal"
    sequence: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    transaction_id: Mapped[str] = mapped_column(String)
    object_id: Mapped[str] = mapped_column(String)
    operation: Mapped[str] = mapped_column(String)
    payload: Mapped[str] = mapped_column(Text)
    created_at: Mapped[str] = mapped_column(String, default=utc_now)


def create_store(database: Path):
    """Create the native engine and schema for a local database.

    Args:
        database: Absolute SQLite path owned by this application instance.
    """
    database.parent.mkdir(parents=True, exist_ok=True)
    engine = create_engine("sqlite:///" + database.as_posix(), connect_args={"timeout": 15, "check_same_thread": False})

    @event.listens_for(engine, "connect")
    def set_pragmas(connection, _record):
        """Enable real foreign-key constraints for every native connection."""
        cursor = connection.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.close()

    Base.metadata.create_all(engine)
    with Session(engine) as db, db.begin():
        for account, label, reviewer in [
            ("uploader", "林同事 · 上传者", False),
            ("reviewer", "周同事 · 审核员", True),
            ("recipient", "陈同事 · 接收人", False),
            ("outsider", "其他同事", False),
        ]:
            if db.get(User, account) is None:
                db.add(User(id=account, display_name=label, password_hash=generate_password_hash("Trial2026!"), is_reviewer=reviewer))
    return engine
