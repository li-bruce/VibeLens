"""Independent scenarios through real loopback HTTP and fresh SQLite readers."""

import json
from pathlib import Path
import re
import sqlite3
import sys
import tempfile
import threading

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import requests
from werkzeug.serving import WSGIRequestHandler, make_server
from app import create_app
from bo_stategraph import BOStateGraph
from bo_stategraph.query import machine_snapshot, read_authority


class QuietHandler(WSGIRequestHandler):
    """Keep actual framework logs out of the JSON evidence channel."""
    def log(self, type, message, *args):
        """Suppress only test-server console output."""


class Client:
    """Use independent HTTP cookie jars for each native account."""
    def __init__(self, base, account):
        self.base = base
        self.http = requests.Session()
        page = self.http.get(base + "/login", timeout=10)
        self.csrf = re.search(r'name="csrf" value="([^"]+)"', page.text).group(1)
        self.http.headers.update({"Accept": "application/json", "X-CSRF-Token": self.csrf})
        reply = self.post("/api/login", json={"account": account, "password": "Trial2026!"})
        assert reply.status_code == 200, reply.text
        self.session_id = reply.json()["session_id"]

    def post(self, path, **kwargs):
        """Return the actual HTTP response without normalizing an error to success."""
        return self.http.post(self.base + path, timeout=20, **kwargs)

    def get(self, path, **kwargs):
        """Start a real loopback GET, optionally leaving its stream open."""
        return self.http.get(self.base + path, timeout=20, **kwargs)

    def upload(self, name, content=b"file-sharing trial content\n"):
        """Upload exact fixture bytes through the normal multipart endpoint."""
        reply = self.post("/api/files", files={"file": (name, content)})
        assert reply.status_code == 200, reply.text
        return reply.json()["file_id"]


def run_mode(mode="off"):
    """Exercise independent approved outcomes with observation on, off or failing."""
    from bo_integration import BOIntegration
    project = json.loads((ROOT / "bo_stategraph/project.json").read_text(encoding="utf-8"))
    manifest = json.loads((ROOT / "manifest.json").read_text(encoding="utf-8"))
    observer = BOIntegration(ROOT, mode=mode) if mode != "off" else None
    with tempfile.TemporaryDirectory(prefix="business-", dir=ROOT / ".tmp") as directory:
        data = Path(directory)
        app = create_app(data, observer)
        service = app.extensions["service"]
        native_fact_reads = []
        original_reader = service.read_facts

        def independent_reader(db, session_id, file=None, share=None, recipient_id=""):
            """Compare the native return against separate SQLite reads at the actual boundary."""
            values = original_reader(db, session_id, file, share, recipient_id)
            with sqlite3.connect(data / "app.sqlite3") as connection:
                row = connection.execute("SELECT u.id,u.is_reviewer,s.authenticated FROM login_sessions s JOIN users u ON u.id=s.actor_id WHERE s.id=?", (session_id,)).fetchone()
                file_row = connection.execute("SELECT uploader_id,review_status FROM files WHERE id=?", (file.id,)).fetchone() if file else None
                grant = connection.execute("SELECT recipient_id,active FROM shares WHERE id=?", (share.id,)).fetchone() if share else None
                proposed = connection.execute("SELECT id FROM users WHERE id=?", (recipient_id,)).fetchone() if recipient_id else None
            actual = {"authenticated": bool(row[2]), "is_reviewer": bool(row[1]), "actor_id": row[0], "uploader_id": file_row[0] if file_row else "", "recipient_id": grant[0] if grant else "", "file_approved": bool(file_row and file_row[1] == "approved"), "share_active": bool(grant and grant[1]), "single_recipient_ok": bool(proposed and (grant is None or grant[0] == recipient_id))}
            assert values == actual, (values, actual)
            native_fact_reads.append({"session_id": session_id, "file_id": file.id if file else None, "native": values, "sqlite": actual})
            return values

        service.read_facts = independent_reader
        if observer:
            observer.attach(service)
        server = make_server("127.0.0.1", 0, app, threaded=True, request_handler=QuietHandler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        base = "http://127.0.0.1:" + str(server.server_port)
        outcomes, receipts, semantic_observations = {}, [], []

        def marked_request(callback, absent=(), present=None, label=""):
            """Compare exact request-local semantic observations with its real HTTP result."""
            if observer:
                observer.probe.flush(30)
            start = len(observer.raw) if observer else 0
            response = callback()
            if observer:
                observer.probe.flush(30)
            current = [r["message"] for r in observer.raw[start:] if r["kind"] == "events"] if observer else []
            if mode == "on":
                assert not any(e["node"] in absent for e in current), (label, absent)
                if present:
                    assert any(e["node"] == present["node"] and all(e.get("outputs", {}).get(k) == v for k, v in present["values"].items()) for e in current), (label, present)
            semantic_observations.append({"label": label, "status_code": response.status_code, "absent": list(absent), "required": present, "events": [e["id"] for e in current], "observed_nodes": sorted({e["node"] for e in current})})
            return response

        def sql(statement, parameters=()):
            with sqlite3.connect(data / "app.sqlite3") as connection:
                connection.row_factory = sqlite3.Row
                return [dict(row) for row in connection.execute(statement, parameters)]

        def expect(reply, status, label):
            receipts.append({"action": label, "status_code": reply.status_code, "expected_status": status, "body": reply.json() if reply.headers.get("Content-Type", "").startswith("application/json") else None})
            assert reply.status_code == status, (label, reply.status_code, reply.text[:300])
            return reply

        try:
            uploader, reviewer, recipient, outsider = [Client(base, account) for account in ["uploader", "reviewer", "recipient", "outsider"]]
            expect(uploader.get("/health"), 200, "health")
            expect(marked_request(lambda: uploader.get("/assets/style.css"), absent=["api:framework_error"], label="stylesheet-is-not-framework-error"), 200, "stylesheet")
            expect(marked_request(lambda: uploader.get("/"), absent=["notify"], label="empty-uploader-dashboard-is-not-recipient-notification"), 200, "dashboard-html")
            expect(uploader.post("/api/login", json={"account": "uploader", "password": "wrong"}), 401, "invalid-password")
            expect(uploader.post("/api/files", files={"file": ("empty.txt", b"")}), 400, "empty-upload")
            pending = uploader.upload("pending.txt")
            denied = expect(marked_request(lambda: uploader.post(f"/api/files/{pending}/share", json={"recipient_id": "recipient"}), absent=["deny_old_link"], label="unapproved-share-is-not-revoked-download"), 403, "share-unapproved")
            outcomes["unapproved-cannot-share"] = {"allowed": denied.status_code == 200}
            expect(reviewer.post(f"/api/files/{pending}/reject"), 200, "reject-other-file")
            old_review = sql("SELECT * FROM reviews WHERE file_id=?", (pending,))
            replacement = uploader.upload("pending-reuploaded.txt")
            outcomes["reupload-keeps-rejected-history"] = {"new_file_id_differs": replacement != pending, "old_review_unchanged": sql("SELECT * FROM reviews WHERE file_id=?", (pending,)) == old_review, "old_file_status": sql("SELECT review_status FROM files WHERE id=?", (pending,))[0]["review_status"], "new_file_status": sql("SELECT review_status FROM files WHERE id=?", (replacement,))[0]["review_status"]}
            own = reviewer.upload("reviewer-own-file.txt")
            for operation in ["approve", "reject"]:
                denied = expect(marked_request(lambda: reviewer.post(f"/api/files/{own}/{operation}"), absent=["deny_old_link"], label="self-" + operation + "-is-not-revoked-download"), 403, "self-" + operation)
                outcomes[f"reviewer-cannot-{operation}-own-file"] = {"allowed": denied.status_code == 200, "review_status": sql("SELECT review_status FROM files WHERE id=?", (own,))[0]["review_status"]}
            file_id = uploader.upload("approved.txt")
            approval = expect(reviewer.post(f"/api/files/{file_id}/approve"), 200, "approve-other-file").json()
            reviews = sql("SELECT * FROM reviews WHERE file_id=?", (file_id,))
            journal = sql("SELECT * FROM native_journal WHERE transaction_id=?", (approval["transaction_id"],))
            outcomes["review-decision-record-committed"] = {"review_record_committed": len(reviews) == 1 and len(journal) == 1 and reviews[0]["transaction_id"] == journal[0]["transaction_id"], "review_record_matches_file": reviews[0]["file_id"] == file_id}
            denied = expect(reviewer.post(f"/api/files/{file_id}/share", json={"recipient_id": "recipient"}), 403, "reviewer-cannot-share")
            outcomes["reviewer-role-does-not-grant-sharing"] = {"allowed": denied.status_code == 200}
            shared = expect(uploader.post(f"/api/files/{file_id}/share", json={"recipient_id": "recipient"}), 200, "share-approved").json()
            share_id = shared["share_id"]
            inbox = expect(marked_request(lambda: recipient.get("/api/dashboard"), present={"node": "notify", "values": {"actor_id": "recipient", "recipient_id": "recipient", "share_id": share_id, "file_id": file_id}}, label="actual-recipient-message"), 200, "recipient-inbox").json()
            outcomes["share-notifies-recipient"] = {"recipient_can_see_message": any(m["file_id"] == file_id for m in inbox["messages"])}
            outcomes["share-does-not-change-review-state"] = {"review_status": sql("SELECT review_status FROM files WHERE id=?", (file_id,))[0]["review_status"], "sharing_active": bool(sql("SELECT active FROM shares WHERE id=?", (share_id,))[0]["active"])}
            content = expect(recipient.get(f"/download/{share_id}"), 200, "recipient-download")
            assert content.content == b"file-sharing trial content\n"
            denied = expect(marked_request(lambda: outsider.get(f"/download/{share_id}"), absent=["deny_old_link"], label="wrong-account-is-not-revoked-grant"), 403, "other-account-old-url")
            outcomes["other-account-cannot-use-link"] = {"allowed": denied.status_code == 200}
            denied = expect(recipient.post(f"/api/shares/{share_id}/revoke"), 403, "recipient-cannot-revoke")
            outcomes["non-uploader-cannot-revoke"] = {"allowed": denied.status_code == 200}
            expect(uploader.post(f"/api/files/{file_id}/share", json={"recipient_id": "outsider"}), 403, "second-recipient-denied")
            outcomes["one-recipient-per-file"] = {"recipient_count_for_file": sql("SELECT COUNT(DISTINCT recipient_id) AS n FROM shares WHERE file_id=?", (file_id,))[0]["n"]}
            expect(uploader.post(f"/api/shares/{share_id}/revoke"), 200, "uploader-revokes")
            outcomes["revoke-does-not-change-review-state"] = {"review_status": sql("SELECT review_status FROM files WHERE id=?", (file_id,))[0]["review_status"], "sharing_active": bool(sql("SELECT active FROM shares WHERE id=?", (share_id,))[0]["active"])}
            denied = expect(marked_request(lambda: recipient.get(f"/download/{share_id}"), present={"node": "deny_old_link", "values": {"file_id": file_id, "share_id": share_id, "actor_id": "recipient", "recipient_id": "recipient", "active": False, "reason": "revoked_grant"}}, label="actual-revoked-grant-request"), 403, "new-download-after-revoke")
            outcomes["old-link-denied-after-revocation"] = {"download_started": denied.status_code == 200}
            large_bytes = b"stream-continues-after-revocation\n" * 250000
            large = uploader.upload("stream-boundary.bin", large_bytes)
            expect(reviewer.post(f"/api/files/{large}/approve"), 200, "approve-stream-file")
            large_share = expect(uploader.post(f"/api/files/{large}/share", json={"recipient_id": "recipient"}), 200, "share-stream-file").json()["share_id"]
            started = recipient.get(f"/download/{large_share}", stream=True)
            assert started.status_code == 200
            first = started.raw.read(65536)
            expect(uploader.post(f"/api/shares/{large_share}/revoke"), 200, "revoke-during-transfer")
            remainder = started.raw.read()
            started.close()
            new = expect(recipient.get(f"/download/{large_share}"), 403, "new-request-during-old-transfer")
            outcomes["started-transfer-can-finish"] = {"started_transfer_completed": first + remainder == large_bytes, "new_request_allowed": new.status_code == 200}
            expect(uploader.get("/missing-route"), 404, "real-framework-404")
            bad = uploader.http.post(base + "/api/logout", headers={"X-CSRF-Token": "wrong"}, timeout=10)
            expect(bad, 400, "csrf-denied")
            expect(outsider.post("/api/logout"), 200, "logout")
            expect(outsider.get("/api/dashboard"), 401, "logged-out-denied")
            authority = read_authority(service.engine)
            graph = observer.session.graph if observer else BOStateGraph(project["model"], build_id=manifest["build_id"], mode="drive")
            machine = machine_snapshot(authority)
            projection = {"build_id": manifest["build_id"], "machine": machine, "instances": graph.bo_instances(machine)}
            if observer:
                observer.probe.flush(30)
            events = [r["message"] for r in observer.raw if r["kind"] == "events"] if observer else []
            snapshots = [r["message"] for r in observer.raw if r["kind"] == "snapshots"] if observer else []
            health = observer.health() if observer else {"enabled": False, "errors": 0, "dropped": 0, "pending": 0}
            if mode == "on":
                for record in sql("SELECT * FROM reviews"):
                    entered = [e for e in events if e["node"] == "retain_review_record" and e["phase"] == "enter" and e["outputs"].get("review_id") == record["id"]]
                    completed = [e for e in events if e["node"] == "retain_review_record" and e["phase"] == "commit" and e["outputs"].get("review_id") == record["id"]]
                    committed = [e for e in events if e["node"] == "transaction" and e["phase"] == "commit" and e["outputs"].get("transaction_id") == record["transaction_id"]]
                    assert len(entered) == len(completed) == len(committed) == 1
                    assert entered[0]["call_id"] == completed[0]["call_id"] == record["id"]
                    assert entered[0]["outputs"]["transaction_id"] == completed[0]["outputs"]["transaction_id"] == record["transaction_id"]
                    assert entered[0]["seq"] < committed[0]["seq"] < completed[0]["seq"]
                    semantic_observations.append({"label": "review-entry-commit-completion", "review_id": record["id"], "transaction_id": record["transaction_id"], "event_ids": [entered[0]["id"], committed[0]["id"], completed[0]["id"]]})
            timings = {"authenticated": "before protected operation", "is_reviewer": "before approval or rejection in the current request", "file_approved": "before sharing", "share_active": "read current persisted authorization before starting file content transfer for each new download request", "actor_id": "before the current protected operation", "uploader_id": "before approval, rejection, sharing or revocation", "recipient_id": "before each new download", "single_recipient_ok": "before sharing, using the selected account and current grant records"}
            basis = {name: {"node": "read_facts", "direction": "out", "field": name, "read_basis": {"timing": timing, "scope": "current_request"}} for name, timing in timings.items()}
            full = {"receipts": receipts, "scenario_count": len(outcomes), "download_bytes_equal": content.content == b"file-sharing trial content\n", "read_basis": basis, "native_fact_reads": native_fact_reads, "semantic_observations": semantic_observations, "outcomes": outcomes}
            runs = [{"case": name, "mode": mode, **value, "observations": value, "execution_case": "full-workflow", "events": events if name == "review-decision-record-committed" else [], "probe_health": health, "authority_snapshot": authority, "projection": projection} for name, value in outcomes.items()]
            runs.append({"case": "full-workflow", "mode": mode, **full, "observations": full, "events": events, "snapshots": snapshots, "rejections": observer.rejections if observer else [], "policy_evaluations": observer.policies if observer else [], "probe_health": health, "authority_snapshot": authority, "projection": projection})
            from bo_observer.workflow.mapping_contract import instance_witnesses
            witnesses = instance_witnesses(projection["instances"], {f["id"]: {"state": f["state"], "revision": f["revision"], "build_id": f["build_id"]} for f in authority["files"]}, case="full-workflow:" + mode, source="bo_stategraph/query.py::read_authority")
            return {"runs": runs, "stategraph_export": graph.bo_export(runtime={"machine": machine}), "health": health, "mapping_checks": witnesses, "machine": service.native_definition, "build_id": manifest["build_id"]}
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=5)
            if observer:
                observer.close()
            service.engine.dispose()


def assert_outcomes(run):
    """Assert concrete user outcomes independently of the generated graph."""
    values = run["outcomes"]
    for case in ["unapproved-cannot-share", "other-account-cannot-use-link", "reviewer-role-does-not-grant-sharing", "non-uploader-cannot-revoke", "reviewer-cannot-approve-own-file", "reviewer-cannot-reject-own-file"]:
        assert values[case]["allowed"] is False, case
    assert values["share-notifies-recipient"]["recipient_can_see_message"] is True
    assert values["old-link-denied-after-revocation"]["download_started"] is False
    assert values["one-recipient-per-file"]["recipient_count_for_file"] == 1
    assert values["share-does-not-change-review-state"] == {"review_status": "approved", "sharing_active": True}
    assert values["revoke-does-not-change-review-state"] == {"review_status": "approved", "sharing_active": False}
    assert values["started-transfer-can-finish"] == {"started_transfer_completed": True, "new_request_allowed": False}
    assert values["review-decision-record-committed"] == {"review_record_committed": True, "review_record_matches_file": True}
    assert values["reupload-keeps-rejected-history"] == {"new_file_id_differs": True, "old_review_unchanged": True, "old_file_status": "rejected", "new_file_status": "pending_review"}
    for operation in ["approve", "reject"]:
        assert values[f"reviewer-cannot-{operation}-own-file"]["review_status"] == "pending_review"
