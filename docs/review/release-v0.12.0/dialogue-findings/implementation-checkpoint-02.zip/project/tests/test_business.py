"""Run independent real HTTP business checks with no observer dependency."""
import json
from scenarios import run_mode, assert_outcomes

if __name__ == "__main__":
    result = run_mode("off")
    full = next(r for r in result["runs"] if r["case"] == "full-workflow")
    assert_outcomes(full)
    print(json.dumps({"valid": True, "business_scenarios": full["scenario_count"], "http_receipts": len(full["receipts"]), "mode": "off"}))
