"""Emit real on/off/fault runs for the canonical verification command."""
import json
from scenarios import run_mode, assert_outcomes

if __name__ == "__main__":
    results = [run_mode(mode) for mode in ["on", "off", "fault"]]
    for result in results:
        assert_outcomes(next(r for r in result["runs"] if r["case"] == "full-workflow"))
    print(json.dumps({"build_id": results[0]["build_id"], "machine": results[0]["machine"], "runs": [run for result in results for run in result["runs"]], "stategraph_export": results[0]["stategraph_export"], "mapping_checks": [w for r in results for w in r["mapping_checks"]]}, ensure_ascii=False))
