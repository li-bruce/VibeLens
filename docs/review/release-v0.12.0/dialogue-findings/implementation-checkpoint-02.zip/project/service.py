"""Native file-sharing operations with transactional authorization and history."""

from contextlib import contextmanager, nullcontext
import json
from pathlib import Path
from threading import RLock
import uuid

from sqlalchemy import select, text
from sqlalchemy.orm import Session
from werkzeug.security import check_password_hash

from bo_stategraph.policy.runtime import evaluate
from bo_stategraph.workflow import ReviewDriver
from models import FileRecord, LoginSession, Message, NativeJournal, ReviewRecord, ShareGrant, User
from policy_functions import same_identity


class BusinessError(Exception):
    """A native denial whose HTTP status is selected by the application."""
    def __init__(self, message: str, status: int = 403):
        """Retain the actual user-facing reason and response status."""
        super().__init__(message)
        self.status = status


class FileService:
    """Own native transactions; optional observation cannot authorize an action."""

    def __init__(self, engine, storage: Path, project: dict, root: Path, observer=None):
        """Bind storage, confirmed declarations and an optional isolated observer."""
        self.engine, self.storage, self.project, self.root = engine, storage, project, root
        self.storage.mkdir(parents=True, exist_ok=True)
        self.bo_observer = observer
        self.lock = RLock()

    def bo_emit(self, node: str, phase: str, values: dict, **identity):
        """Offer already obtained native facts; ignore observation failure."""
        if self.bo_observer is not None:
            try:
                return self.bo_observer.emit(node, phase, values, **identity)
            except Exception:
                self.bo_observer.failure()
        return None

    @contextmanager
    def transaction(self, operation: str, object_id: str):
        """Serialize a real SQLite write transaction and witness its outcome.

        Args:
            operation: Native operation being committed.
            object_id: Known file, grant or session identity at entry.
        """
        tx_id = uuid.uuid4().hex
        self.bo_emit("transaction", "enter", {"outputs": {"transaction_id": tx_id, "committed": False, "operation": operation}}, entity=object_id, call_id=tx_id, bo_boundary="start")
        with self.lock, Session(self.engine, expire_on_commit=False) as db:
            try:
                db.begin()
                yield db, tx_id
                db.commit()
            except Exception:
                db.rollback()
                self.bo_emit("transaction", "error", {"outputs": {"transaction_id": tx_id, "committed": False, "operation": operation}}, entity=object_id, call_id=tx_id, bo_boundary="end")
                raise
            else:
                self.bo_emit("transaction", "commit", {"outputs": {"transaction_id": tx_id, "committed": True, "operation": operation}}, entity=object_id, call_id=tx_id, bo_boundary="end")

    def current_actor(self, db: Session, session_id: str) -> User:
        """Read the current authenticated native session and current account role.

        Args:
            db: Session for the same operation's database transaction.
            session_id: Opaque identifier from the signed application cookie.
        """
        login = db.get(LoginSession, session_id) if session_id else None
        actor = db.get(User, login.actor_id) if login and login.authenticated else None
        if actor is None:
            raise BusinessError("请先登录。", 401)
        return actor

    def read_facts(self, db: Session, session_id: str, file=None, share=None, recipient_id="") -> dict:
        """Read selected native rule inputs at the protected operation boundary.

        Args:
            db: The current native database session.
            session_id: Actual authenticated session identity.
            file: Current persisted file, when this operation reads a file.
            share: Current persisted grant, when this operation reads a grant.
            recipient_id: Proposed existing recipient account for sharing.
        """
        actor = self.current_actor(db, session_id)
        proposed = db.get(User, recipient_id) if recipient_id else None
        values = {"authenticated": True, "is_reviewer": actor.is_reviewer,
                  "actor_id": actor.id, "uploader_id": file.uploader_id if file else "",
                  "recipient_id": share.recipient_id if share else "",
                  "file_approved": self.approved_value(file.review_status) if file else False, "share_active": bool(share and share.active),
                  "single_recipient_ok": bool(proposed and (share is None or share.recipient_id == recipient_id))}
        self.bo_emit("read_facts", "read", {"inputs": {"session_id": session_id}, "outputs": values}, entity=file.id if file else session_id)
        return values

    def approved_value(self, review_status: str) -> bool:
        """Derive the read-only approval fact from the actual stored status.

        Args:
            review_status: Authoritative current file review value.
        """
        return review_status == "approved"

    def permission(self, operation: str, facts: dict, basis: str, object_id: str) -> dict:
        """Evaluate the confirmed rule once and use its actual result natively.

        Args:
            operation: Confirmed policy operation ID.
            facts: Native scalar values acquired for this request.
            basis: Request or transaction read-basis identity.
            object_id: Actual native object being authorized.
        """
        report = evaluate(self.project["model"]["policy"], operation, facts, {"same_identity": same_identity}, fact_revision=basis, source_root=self.root)
        self.bo_emit("permission", "decision", {"outputs": {"allowed": report["value"]}}, entity=object_id)
        if self.bo_observer is not None:
            try:
                self.bo_observer.policy(report, object_id)
            except Exception:
                self.bo_observer.failure()
        if report["value"] is not True:
            reasons = {"share": "共享被拒绝：必须由上传者操作、审核已通过，并且只指定一位站内接收人。", "revoke": "撤销被拒绝：只有上传者可以撤销共享。", "download": "下载被拒绝：当前账号不是指定接收人，或共享已被撤销。", "approve": "审核被拒绝：需要审核员身份，且不能审核自己上传的文件。", "reject": "审核被拒绝：需要审核员身份，且不能审核自己上传的文件。"}
            raise BusinessError(reasons.get(operation, "当前操作未获授权。"))
        return report

    def journal(self, db: Session, tx_id: str, object_id: str, operation: str, values: dict):
        """Store actual native mutation facts in the same transaction as the effect."""
        db.add(NativeJournal(transaction_id=tx_id, object_id=object_id, operation=operation, payload=json.dumps(values, ensure_ascii=False)))

    def login(self, account: str, password: str) -> dict:
        """Authenticate an existing account and create a real session identity.

        Args:
            account: Existing local account name.
            password: Submitted password, never copied into observation.
        """
        session_id = uuid.uuid4().hex
        with self.transaction("login", session_id) as (db, tx_id):
            actor = db.get(User, account)
            if not actor or not check_password_hash(actor.password_hash, password):
                raise BusinessError("账号或密码不正确。", 401)
            db.add(LoginSession(id=session_id, actor_id=actor.id, authenticated=True))
            self.journal(db, tx_id, session_id, "login", {"authenticated_before": False, "authenticated_after": True, "actor_id": actor.id})
            result = {"session_id": session_id, "actor_id": actor.id, "is_reviewer": actor.is_reviewer, "authenticated": True}
        self.bo_emit("login", "return", {"outputs": result}, entity=session_id)
        return result

    def logout(self, session_id: str):
        """Invalidate the actual native session without altering file or grant state.

        Args:
            session_id: Actual login identity to invalidate.
        """
        with self.transaction("logout", session_id) as (db, tx_id):
            login = db.get(LoginSession, session_id)
            if login:
                login.authenticated = False
                self.journal(db, tx_id, session_id, "logout", {"authenticated_before": True, "authenticated_after": False})

    def transition(self, db: Session, file: FileRecord, operation: str, report: dict, tx_id: str) -> dict:
        """Apply the declaration to the actual pre-state and retain native path evidence."""
        before = file.review_status
        old_revision = file.revision
        self.bo_emit("transition", "read", {"outputs": {"file_id": file.id, "before": before, "revision": old_revision}}, entity=file.id, revision=old_revision)
        driver = ReviewDriver(self.project["model"]["machine"], report["value"])
        self.native_definition = driver.executor.bo_definition
        result = driver.step(before, operation)
        file.review_status = result["state"]
        file.revision += 1
        witness = {"file_id": file.id, "before": before, "after": file.review_status, "before_revision": old_revision, "revision": file.revision, "event": operation, "payload": result["payload"], "guards": result["guards"], "transaction_id": tx_id}
        self.journal(db, tx_id, file.id, operation, witness)
        return witness

    def upload(self, session_id: str, filename: str, content: bytes) -> dict:
        """Commit a fresh pending file; a reupload never resets a rejected identity.

        Args:
            session_id: Current native login identity.
            filename: Display name, never used as a storage path.
            content: Submitted bytes, counted but never captured by the observer.
        """
        file_id = uuid.uuid4().hex
        if not filename or not content:
            raise BusinessError("请选择一个非空文件。", 400)
        if len(content) > 16 * 1024 * 1024:
            raise BusinessError("试用版单个文件不超过 16 MB。", 413)
        safe_name = filename.replace("\\", "/").rsplit("/", 1)[-1][:180]
        destination = self.storage / file_id
        try:
            with self.transaction("upload", file_id) as (db, tx_id):
                facts = self.read_facts(db, session_id)
                report = self.permission("upload", facts, tx_id, file_id)
                destination.write_bytes(content)
                build_id = json.loads((self.root / "manifest.json").read_text(encoding="utf-8"))["build_id"]
                file = FileRecord(id=file_id, uploader_id=facts["actor_id"], name=safe_name, storage_name=file_id, byte_count=len(content), review_status="awaiting_upload", revision=0, run_build_id=build_id)
                db.add(file)
                witness = self.transition(db, file, "upload", report, tx_id)
        except Exception:
            destination.unlink(missing_ok=True)
            raise
        result = {"file_id": file_id, "state": file.review_status, "byte_count": len(content), "transaction_id": tx_id, "committed": True}
        self.bo_emit("upload", "return", {"outputs": result}, entity=file_id)
        self.bo_emit("transition", "change", {"outputs": witness}, entity=file_id, revision=file.revision)
        return result

    def approve(self, session_id: str, file_id: str) -> dict:
        """Approve another colleague's pending file using the shared review rule.

        Args:
            session_id: Native session of the current reviewer.
            file_id: Exact uploaded file to approve.
        """
        return self.review(session_id, file_id, "approve")

    def reject(self, session_id: str, file_id: str) -> dict:
        """Reject another colleague's pending file using the shared review rule.

        Args:
            session_id: Native session of the current reviewer.
            file_id: Exact uploaded file to reject.
        """
        return self.review(session_id, file_id, "reject")

    def review(self, session_id: str, file_id: str, operation: str) -> dict:
        """Commit a review transition and immutable decision record atomically.

        Args:
            session_id: Native session of the current reviewer.
            file_id: Identity of the exact uploaded file under review.
            operation: Either approve or reject from the fixed API route.
        """
        with self.transaction(operation, file_id) as (db, tx_id):
            file = db.get(FileRecord, file_id)
            if file is None:
                raise BusinessError("文件不存在。", 404)
            facts = self.read_facts(db, session_id, file)
            report = self.permission(operation, facts, tx_id, file_id)
            if file.review_status != "pending_review":
                raise BusinessError("该文件已经审核，原记录会保留。", 409)
            witness = self.transition(db, file, operation, report, tx_id)
            review_id = uuid.uuid4().hex
            self.bo_emit("retain_review_record", "enter", {"outputs": {"file_id": file_id, "review_id": review_id, "reviewer_id": facts["actor_id"], "state": file.review_status, "transaction_id": tx_id, "committed": False}}, entity=file_id, call_id=review_id, bo_boundary="start")
            db.add(ReviewRecord(id=review_id, file_id=file_id, reviewer_id=facts["actor_id"], decision=operation, transaction_id=tx_id))
        result = {"file_id": file_id, "state": file.review_status, "review_id": review_id, "reviewer_id": facts["actor_id"], "transaction_id": tx_id, "committed": True}
        self.bo_emit(operation, "return", {"outputs": result}, entity=file_id)
        self.bo_emit("retain_review_record", "commit", {"outputs": result}, entity=file_id, call_id=review_id, bo_boundary="end")
        self.bo_emit("transition", "change", {"outputs": witness}, entity=file_id, revision=file.revision)
        return result

    def share(self, session_id: str, file_id: str, recipient_id: str) -> dict:
        """Share an approved file with one existing account and create its site message.

        Args:
            session_id: Current uploader session.
            file_id: Approved file whose review status is read, never changed here.
            recipient_id: The single designated existing site account.
        """
        with self.transaction("share", file_id) as (db, tx_id):
            file = db.get(FileRecord, file_id)
            if file is None:
                raise BusinessError("文件不存在。", 404)
            grant = db.scalar(select(ShareGrant).where(ShareGrant.file_id == file_id))
            facts = self.read_facts(db, session_id, file, grant, recipient_id)
            self.permission("share", facts, tx_id, file_id)
            before = bool(grant and grant.active)
            if grant is None:
                grant = ShareGrant(id=uuid.uuid4().hex, file_id=file_id, recipient_id=recipient_id, active=True)
                db.add(grant)
                db.flush()
            else:
                grant.active = True
            if not before:
                db.add(Message(id=uuid.uuid4().hex, share_id=grant.id, recipient_id=recipient_id))
            self.journal(db, tx_id, grant.id, "share", {"file_id": file_id, "recipient_id": recipient_id, "active_before": before, "active_after": True, "review_status": file.review_status})
            result = {"file_id": file_id, "share_id": grant.id, "recipient_id": recipient_id, "active": True, "review_status": file.review_status, "transaction_id": tx_id, "committed": True}
        self.bo_emit("share", "return", {"outputs": result}, entity=file_id)
        return result

    def revoke(self, session_id: str, share_id: str) -> dict:
        """Revoke this file's recipient grant while preserving its review state.

        Args:
            session_id: Native session checked against the current uploader.
            share_id: Exact persistent grant to revoke.
        """
        with self.transaction("revoke", share_id) as (db, tx_id):
            grant = db.get(ShareGrant, share_id)
            if grant is None:
                raise BusinessError("共享不存在。", 404)
            file = db.get(FileRecord, grant.file_id)
            facts = self.read_facts(db, session_id, file, grant)
            self.permission("revoke", facts, tx_id, file.id)
            before = grant.active
            grant.active = False
            self.journal(db, tx_id, share_id, "revoke", {"file_id": file.id, "recipient_id": grant.recipient_id, "active_before": before, "active_after": False, "review_status": file.review_status})
            result = {"file_id": file.id, "share_id": share_id, "recipient_id": grant.recipient_id, "active": False, "review_status": file.review_status, "transaction_id": tx_id, "committed": True}
        self.bo_emit("revoke", "return", {"outputs": result}, entity=file.id)
        return result

    def download(self, session_id: str, share_id: str) -> dict:
        """Authorize each new request and open immutable bytes before transfer.

        Args:
            session_id: Native session of the requesting recipient.
            share_id: Grant identity in the old or current download URL.

        Returns:
            An already opened file handle; revocation cannot cancel an in-flight transfer.
        """
        with self.lock, Session(self.engine) as db:
            grant = db.get(ShareGrant, share_id)
            if grant is None:
                raise BusinessError("共享不存在。", 404)
            file = db.get(FileRecord, grant.file_id)
            facts = self.read_facts(db, session_id, file, grant)
            try:
                self.permission("download", facts, uuid.uuid4().hex, file.id)
            except BusinessError:
                if facts["actor_id"] == grant.recipient_id and not grant.active:
                    self.bo_emit("deny_old_link", "decision", {"outputs": {"file_id": file.id, "share_id": grant.id, "actor_id": facts["actor_id"], "recipient_id": grant.recipient_id, "active": grant.active, "reason": "revoked_grant"}}, entity=file.id)
                    raise BusinessError("下载被拒绝：此文件给你的共享授权已撤销，旧链接不能继续发起下载。") from None
                raise BusinessError("下载被拒绝：当前账号不是此文件的指定接收人。") from None
            handle = (self.storage / file.storage_name).open("rb")
            result = {"file_id": file.id, "share_id": share_id, "name": file.name, "byte_count": file.byte_count, "handle": handle}
        self.bo_emit("download", "return", {"outputs": {k: v for k, v in result.items() if k != "handle"}}, entity=file.id)
        return result

    def dashboard(self, session_id: str) -> dict:
        """Read files owned by the actor, reviewer queue, and recipient site messages.

        Args:
            session_id: Current native identity used to scope every returned item.
        """
        with Session(self.engine) as db:
            actor = self.current_actor(db, session_id)
            users = [{"id": u.id, "name": u.display_name} for u in db.scalars(select(User).order_by(User.id))]
            files = []
            query = select(FileRecord).order_by(FileRecord.created_at.desc())
            if not actor.is_reviewer:
                query = query.where(FileRecord.uploader_id == actor.id)
            for file in db.scalars(query):
                grant = db.scalar(select(ShareGrant).where(ShareGrant.file_id == file.id))
                review = db.scalar(select(ReviewRecord).where(ReviewRecord.file_id == file.id))
                files.append({"id": file.id, "name": file.name, "uploader_id": file.uploader_id, "byte_count": file.byte_count, "state": file.review_status,
                              "share": {"id": grant.id, "recipient_id": grant.recipient_id, "active": grant.active} if grant else None,
                              "review": {"decision": review.decision, "reviewer_id": review.reviewer_id, "id": review.id} if review else None})
            messages = self.received_messages(db, actor.id)
            return {"actor": {"id": actor.id, "name": actor.display_name, "is_reviewer": actor.is_reviewer}, "files": files, "messages": messages, "users": users}

    def received_messages(self, db: Session, actor_id: str) -> list:
        """Return only messages actually addressed to the current authenticated account.

        Args:
            db: Native session used for this dashboard read.
            actor_id: Actual current recipient identity, not a role label.
        """
        messages = []
        for message, grant, file in db.execute(select(Message, ShareGrant, FileRecord).join(ShareGrant, Message.share_id == ShareGrant.id).join(FileRecord, ShareGrant.file_id == FileRecord.id).where(Message.recipient_id == actor_id).order_by(Message.created_at.desc())):
            messages.append({"id": message.id, "share_id": grant.id, "file_id": file.id, "name": file.name, "uploader_id": file.uploader_id, "active": grant.active})
            self.bo_emit("notify", "read", {"outputs": {"message_id": message.id, "file_id": file.id, "share_id": grant.id, "recipient_id": message.recipient_id, "actor_id": actor_id, "active": grant.active}}, entity=file.id)
        return messages
