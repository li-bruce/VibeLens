# Evidence index

All paths are relative to the trial root unless prefixed with `review/`. This is a simulated-user trial. Original failures are retained; a later pass does not rewrite an earlier result.

Latest accepted batch: `.stategraph/repair-runtime-owner`, build `2589ec518852a132c32ab71d4f5f3dc4ed2112ee0b88732fda1c4c26d6f0cd6f`. The final actual 60-event recording is `870c162a1d124eca8a1dab24b3336d90`. Entries named delivery without runtime-owner describe the preserved prior 63-event build and its initial duplicate-row/incorrect-owner findings.

| Evidence | Path | Meaning |
|---|---|---|
| Latest scoped batch and immutable baseline | `.stategraph/repair-runtime-owner/`, `review/repair-runtime-owner-baseline-begin.json`, `review/runtime-owner-baseline-byte-proof.json` | R6 declared before editing; original full baseline bytes unchanged through accept. |
| Before runtime-owner correction | `review/runtime-owner-before/`, `review/runtime-owner-model-diff.json` | Fixed creation-owner override and original model/builder/report preserved; machine unchanged. |
| Normal canonical viewer upgrade | `review/upgrade-replay-plan.json`, `review/upgrade-replay-applied.json`, `.validation/managed-before-replay-upgrade/` | Exactly replay-steps.js and viewer.js applied, no conflicts; previous managed sources retained. |
| Original-record before/after regression | `review/replay-original-installed-before.json`, `review/replay-original-installed-after.json`, `.validation/bo_check_replay_rows.mjs` | Same untouched 63-event recording/model: 1/2/2/2 summary rows becomes 1/1/1/1. |
| Latest actual recording and query | `review/recording-runtime-owner.json`, `review/live-view-runtime-owner.json`, `review/public-query-runtime-owner.json` | Real ticket #5; 60 events, four native frames, three actual transitions, zero reported gaps/errors/drops. |
| Actual source and dual highlight browser proof | `review/runtime-owner-replay-proof.json`, `review/runtime-owner-browser-check.json`, `review/runtime-owner-click-target.json`, `review/screenshots/runtime-owner-replay-*.jpg` | Four actual operation labels; one row each; both endpoint owners/highlights retained; completed state selected on click. |
| Latest full gate and actual package run | `review/verify-replay-upgraded.json`, `review/check-runtime-owner.json`, `review/runtime-owner-gate-summary.json`, `review/runtime-owner-delivery-check.json`, `dist/repair-core-runtime-owner-20261025.zip` | Full gate passed, actual current ZIP ran, stale-source copy rejected and old source revision denied. |
| Upgrade preference scope | `review/preferences-replay-upgrade-proof.json`, `review/preferences-replay-upgrade-semantic-proof.json` | Original strict comparison false retained; only live camera damping delta 6.47e-12, positions/pins/layers/2D entries retained. |
| Raw current-chat session | `review/raw-session.jsonl`, `review/raw-session-metadata.json` | Exact private local snapshot through its recorded cutoff; includes original user/delegated steering, tools and replies. Final later messages are outside that snapshot. |
| Dialogue navigation | `review/conversation.jsonl` | Human-readable index with U0/U1/U2 and design links; not a verbatim replacement for the raw session. |
| Clarification and confirmed graph | `review/design-preview.md`, `review/screenshots/design-2d.jpg`, `discovery.json` | Same-source pre-implementation graph and explicit scope confirmation. |
| Initial failed baseline/provenance repair | `review/initial-baseline-before-provenance-repair.json`, `review/provenance-repair.json`, `.stategraph/repair-initial/` | Process deviation, not a clean immutable-baseline pass. |
| Correctly scoped later baseline | `review/repair-evidence-baseline-begin.json`, `review/baseline-byte-proof.json`, `.stategraph/repair-evidence/` | Full original bytes and begin/accept equality; requirement R6. |
| Gate failure and retest | `review/verify-evidence.json`, `review/verify-delivery.json`, `review/verify-delivery-retest.json`, `review/accept-delivery.json`, `review/check-delivery.json` | Preserved fixture-placement/parser rejection followed by full pass. |
| Independent expectations | `intent.json`, `acceptance.json`, `mapping.json`, `whitebox.json`, `tests/`, `test_workflow.py` | Expected business/field values, real mutations, source/engine/schema checks. |
| Final actual recording | `review/recording-delivery.json`, `review/recordings-delivery.json`, `review/live-view-delivery.json` | Exact accepted build; 63 events, four frames, zero reported gaps/errors/drops. |
| Final public query and edge/guard proof | `review/public-query-delivery.json`, `review/delivery-check-result.json` | Real pre-restart #4 journal matched to native frames, guard values, call identities and source. |
| Earlier good recording | `review/recording-final.json` | 98 events on older e750... build; retained independently. Filename predates later final build. |
| Original bad recording | `review/recording-first.json`, `review/live-view-before.json`, `review/observer.log` | 60 events with capture-response errors; not gap-free evidence. |
| Actual rejected HTTP operations | `review/live-reject-*.json` | 409 responses and independent SQLite before/after equality. |
| Actual path deletion/queue checks | `review/runtime-evidence/`, `tests/test_evidence.py` | Removed middle witness with final state retained; actual queue drops and independent business completion. |
| Engineering mutations | `.validation/engineering/`, `.validation/archived-engineering/`, `review/engineering-relocation.json` | Original fixtures retained intact, semantic and mapping failures plus real ALTER TABLE evidence. |
| Source exact parameter | `review/source-parameter-proof.json`, `review/screenshots/source-exact-actor-id.jpg` | Actual formal actor_id token only. |
| Full/local code layers | `review/screenshots/local-code-open.jpg`, source/code AX files | Optional source layer and explicit boundaries/truncation. |
| Actual runtime geometry | `review/spatial-*.json`, `review/runtime-geometry-retest.json`, `.validation/check_runtime_geometry.mjs` | Real plane/node/edge/label/camera coordinates and exact installed helper calculation. |
| 2D/3D separation | `review/layout-2d-3d.json`, `review/screenshots/delivery-2d.jpg` | 30 nodes in each; unchanged 3D positions after switching. |
| Web hidden/disabled | `review/web-modes-result.json`, `review/check_web_modes.py` | Graph hidden/404 as configured, no events from diagnostic reads, business still completes. |
| Same-build restart | `review/restart-before.json`, `review/restart-after.json`, `review/restart-result.stdout.txt`, `review/check_restart.py` | Four SQLite rows, same recording and preference entries retained; verified owned process tree. |
| Real core package | `dist/repair-core-20261025.zip`, `review/package-delivery.json`, `.validation/delivery/`, `review/delivery-check-result.json` | Native package command and actual extracted execution without observer/viewer. |
| Stale source counterexample | `review/delivery-check-result.json`, `.validation/delivery/` | Same copied gate passes, source edit makes it fail; previous code revision is rejected. |
| Original browser replay failure | `review/delivery-replay-proof.json`, `review/delivery-replay-*.ax.txt`, `review/screenshots/delivery-replay-*.jpg` | Original duplicate rows and incorrect creation-owner labels retained; later fix is separately evidenced above. |
| Exact duplicate owner diagnostics | `review/duplicate-owner-dom.json`, `review/duplicate-actual-boxes.json`, `review/screenshots/duplicate-actual-boxes.jpg` | Same event/kind, distinct before/after state owners; actual graph/display box fields read through a temporary GET-only mirror, then closed. |
| Read-only diagnostic isolation | `.validation/bo_readonly_proxy.py`, `review/readonly-proxy-process.json`, `review/check-after-readonly-diagnostics.json` | No production source/record modification, no accepted build or baseline change; mirror stopped after extraction. |
| Final actual form screenshots | `review/screenshots/delivery-created.jpg`, `delivery-claimed.jpg`, `delivery-result.jpg`, `delivery-completed.jpg` | Real #4 state progression. |
| Final graph screenshots | `review/screenshots/delivery-graph.jpg`, `delivery-3d-restarted.jpg` | Actual installed viewer; geometry, visual density and clipped/overlapping content can be inspected directly. |
| Failure history | `review/failures.jsonl`, `review/supplemental-events.jsonl`, `review/runtime-owner-events.jsonl` | Original failures, causes, fixes and retest evidence; no overwritten first-pass claims. |

Reproducible commands are in `README.md`. Geometry and saved-record checks read bounded archived evidence; browser screenshots alone do not prove event/guard correctness. Core and mutation checks operate only in new `.validation/` copies. Review raw session data and runtime evidence as private local trial material.
