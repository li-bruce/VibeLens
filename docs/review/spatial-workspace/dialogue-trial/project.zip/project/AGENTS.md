# Project development contract

This project uses the explicitly requested candidate VibeLens skill for its developer graph. The user chose drive in simulated-user reply U1 and confirmed the same-source diagram in U2 (review/conversation.jsonl). Do not repeat settled questions or add business scope.

The canonical declaration is bo_stategraph/project.json:model.machine. The real flat executor in bo_stategraph/workflow.py consumes it. The app owns SQLite commits. Optional integrations/bo_adapter.py observes selected values through the public probe/data APIs. Preserve real functions, state/guard declarations, source bindings, independent expectations and all previous evidence.

Read .stategraph/active.json to identify the current change and continue it until accepted; never reset any baseline. Before beginning a later batch, declare its actual allowed requirement IDs and freeze the full baseline bytes, including scope metadata. During code changes run build_model.py, observer_runtime/bo_sync.py scan, change_sync inspect, reconcile current candidate review, then verify/accept/check. The normal gate is .venv/Scripts/python.exe -B validate.py. It must reject stale source or missing mappings. Runtime state changes belong to the actual native commit event.node; do not force every change to repair.submit with presentation.runtime_owner.

Write only inside this project. The candidate repository and global skills are read-only. No subagents, other chats, commits or publication. This is a simulated-user test, never human usability evidence. Capture no full ticket text or credentials in the observer.
