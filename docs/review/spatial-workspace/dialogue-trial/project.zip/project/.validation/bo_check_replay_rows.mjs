import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
const root=path.resolve('.');
const moduleRoot=process.argv[2]||path.join(root,'static/graph');
const {boStepDetail}=await import(pathToFileURL(path.join(moduleRoot,'replay-steps.js')));
const {timeline}=await import(pathToFileURL(path.join(moduleRoot,'recording.js')));
const recording=JSON.parse(fs.readFileSync(process.argv[3]||'review/recording-delivery.json','utf8').replace(/^\uFEFF/,''));
const model=recording.context.model,all=new Map(model.nodes.map(n=>[n.id,n]));
const visible=model.nodes.filter(n=>n.kind==='state'&&n.id.startsWith('repair.')).map(n=>({id:n.id,node:n,type:n.kind}));
if(visible.length!==4)throw new Error('Actual four state nodes were not found');
const items=timeline(recording),result=[];
let previous=0;
for(let i=0;i<items.length;i++){
 const event=items[i];if(event.kind!=='probe'||event.phase!=='commit'||!event.node.startsWith('repair.'))continue;
 const detail=boStepDetail(recording,items,i,previous,all,visible);
 result.push({event_id:event.id,event_node:event.node,rows:detail.rows});previous=i;
}
console.log(JSON.stringify({basis:'Preserved original actual recording with its exact original model, four declared state boxes and event-bound frames; no event/source rewrite',moduleRoot,recording:recording.id,rowsPerCommit:result.map(r=>r.rows.length),result},null,2));
