import assert from 'node:assert/strict';
import fs from 'node:fs';
import * as T from '../static/graph/spatial-three.vendor.js';
import {edgeCurve} from '../static/graph/spatial-paths.js';
import {regionLabelAnchor} from '../static/graph/spatial-labels.js';
const read=name=>JSON.parse(fs.readFileSync(new URL('../review/'+name,import.meta.url),'utf8'));
const results=[];
for(const name of ['before-orbit','after-orbit-settled','group-drag']){
 const {scene,dom}=read(`spatial-${name}.json`),sp=scene.spatial;
 assert.ok(sp.webgl&&sp.perspective);
 const planes=new Map(sp.layerPlanes.map(p=>[p.id,p.y]));
 const nodes=new Map(dom.nodes.map(n=>[n.nodeId,n]));
 for(const n of dom.nodes)assert.equal(+n.worldY,planes.get(n.plane),n.nodeId);
 for(const v of sp.volumes)assert.equal(v.center.y,planes.get(v.layer),`${v.id}:${v.layer}`);
 let edges=0,points=0;
 for(const e of dom.edges){
  const a=nodes.get(e.from),b=nodes.get(e.to);
  if(!a||!b||a.plane!==b.plane)continue;
  const vector=n=>({x:+n.worldX,y:+n.worldY,z:+n.worldZ});
  const curve=edgeCurve(vector(a),vector(b));
  for(let i=0;i<=100;i++){assert.ok(Math.abs(curve.getPoint(i/100).y-planes.get(a.plane))<1e-8);points++;}
  edges++;
 }
 assert.ok(edges>0);
 const camera=new T.PerspectiveCamera(43,dom.viewport.width/dom.viewport.height,1,100000);
 camera.position.fromArray(sp.camera.position);camera.lookAt(...sp.camera.target);camera.updateMatrixWorld();
 const project=p=>{const v=new T.Vector3(p.x,p.y,p.z).project(camera);return{x:(v.x+1)*dom.viewport.width/2,y:(1-v.y)*dom.viewport.height/2,depth:v.z};};
 const labels=[];
 for(const l of dom.labels.filter(l=>!l.hidden)){
  const v=sp.volumes.find(v=>v.id===l.spatialRegion&&v.layer===l.regionLayer);assert.ok(v);
  const anchor=regionLabelAnchor(v,project);
  const actual={x:l.rect.x+l.rect.width/2-dom.viewport.x,y:l.rect.y-dom.viewport.y};
  const delta=Math.hypot(actual.x-anchor.x,actual.y-anchor.y);
  assert.ok(delta<1,`${name}:${l.regionLayer} label delta ${delta}`);
  let bottom=-Infinity;
  for(let i=0;i<4096;i++){const angle=i/4096*Math.PI*2;bottom=Math.max(bottom,project({x:v.center.x+v.radius*Math.cos(angle),y:v.center.y,z:v.center.z+v.radius*Math.sin(angle)}).y);}
  assert.ok(Math.abs(anchor.y-bottom-7)<0.5);
  labels.push({layer:l.regionLayer,deltaPx:delta,offsetPx:anchor.y-bottom});
 }
 results.push({name,nodes:dom.nodes.length,volumes:sp.volumes.length,sameLayerEdges:edges,edgePoints:points,labels,camera:sp.camera,build:scene.build_id});
}
assert.notDeepEqual(results[0].camera.position,results[1].camera.position);
const top=read('spatial-runtime-top.json').scene??read('spatial-runtime-top.json');
const gap=read('spatial-runtime-gap.json');
const hidden=read('spatial-runtime-hidden-state.json');
const spatial=v=>(v.scene??v).spatial;
const base=spatial(top).layerPlanes,wide=spatial(gap).layerPlanes,removed=spatial(hidden).layerPlanes;
assert.ok(!removed.some(p=>p.id==='state'));
for(const p of removed)assert.equal(p.y,wide.find(x=>x.id===p.id).y);
for(const p of base)assert.ok(wide.find(x=>x.id===p.id).y>p.y);
console.log(JSON.stringify({valid:true,basis:'Actual renderer diagnostics and DOM saved through CUA; exact installed Three.js/edge/caption helpers',results,hiddenStatePlaneRemoved:true,remainingPlanePositionsPreserved:true,gapChangedAllPlanes:true},null,2));
