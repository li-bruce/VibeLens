"""Temporary GET-only mirror for extracting actual viewer graph-box diagnostics."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.request import urlopen
from urllib.error import HTTPError
SCRIPT=b'''<script type="module">
const boxTimer=setInterval(()=>{const target=document.querySelector('#viewport'),debug=window.graphDebug;if(!target||!debug)return;
const fields=box=>({id:box.id,referenceOf:box.node?.referenceOf??null,event_node:box.node?.event_node??null,parent:box.node?.parent??null,type:box.type});
target.dataset.boBoxes=JSON.stringify({basis:'Actual graphDebug.graph.boxes and displayGraph.boxes getters; no graph/data modification',graph:(debug.graph?.boxes||[]).map(fields),display:(debug.displayGraph?.boxes||[]).map(fields)});
},100);
window.addEventListener('pagehide',()=>clearInterval(boxTimer),{once:true});
</script>'''
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        try:
            with urlopen('http://127.0.0.1:8899'+self.path,timeout=10) as response:
                status,body,mime=response.status,response.read(),response.headers.get('Content-Type','application/octet-stream')
        except HTTPError as error:status,body,mime=error.code,error.read(),'application/json'
        if 'text/html' in mime:body=body.replace(b'</body>',SCRIPT+b'</body>')
        self.send_response(status);self.send_header('Content-Type',mime);self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
    def do_POST(self):self.send_error(405,'Read-only diagnostic mirror')
    do_PUT=do_POST
    do_DELETE=do_POST
if __name__=='__main__':ThreadingHTTPServer(('127.0.0.1',8900),Handler).serve_forever()
