# Findings

- Candidate skill and companion resources have an initial 194-file SHA-256 inventory in review/candidate-baseline.json. The maintained checkout already had changes before this trial; preserve them.
- Requirements graph and review preview share discovery.json. Eight nodes and seven relations were displayed in the browser; design screenshot and HTTP receipt are retained.
- Default-sandbox service launches did not give reachable HTTP; hidden host Start-Process worked. Stop/restart only a verified command line owned by this trial.
- The candidate provides bo-project/v1, native probes, GraphSession service, public BOStateGraph core, source indexing, data mapping and full viewer. Prefer these existing boundaries over a custom viewer or fabricated event/projection implementation.
- The python-modes example is a small state example with a limited freshness gate, so it cannot by itself satisfy the requested full acceptance workflow.

## Confirmed scope

U1 chooses drive, fixed test identity switching without login, submitter-only confirmation, assigned-technician-only result registration, and SQLite + SQLAlchemy restart persistence.
U2 explicitly confirms the diagram and clarifies no rejection or rework; result registration waits for submitter confirmation, which ends the flow.

Browser evidence: first app and runtime graph load successfully. Native browser recording started at zero interval events. User u1 submitted ticket #1 (pending/revision 1), then technician t1 claimed it (in_progress/revision 2). Screenshots are retained; this is simulated-user operation testing. The public query's empty journal was identified by the test initiator; it currently proves actual current storage state only. Preserve this before adding real publication-based transition evidence in the isolated adapter.

The first full browser flow completed at revision 4. The native recording retained 60 interval events but reported capture failures (collector health errors=9, dropped=0). Server logs show ConnectionAbortedError while replying after accepted events; the trial transport used a 0.2-second timeout. Do not label this recording gap-free. Switching the replay to the State machine preset regrouped the step selector to six entries; a selection using the former 44-step label failed, and the refreshed AX state exposed the correct new labels.

After the repaired source build restarted, the original completed ticket remained at revision 4. The current viewer connected, kept its saved State machine preset, returned to live view, and listed only the current build (old recording absent). Original recording JSON and files remain archived.

Final recording 68036a1fc8d641e69c6d109890032334 retained 98 events with gaps=[], health errors=0 and dropped=0. Replay displayed all four actual state frames. The existing viewer repeats each later flow-change summary row twice; original screenshots/AX evidence preserve this candidate UI duplication. No maintained viewer code was patched. The browser read-only evaluation scope does not expose window.graphDebug; geometry checks currently use DOM/screenshots and the exact installed helper functions.

Source parameter proof: app/domain.py:49 / RepairService.confirm opened with mark text exactly actor_id. The Local code control is an aria-pressed button, so checkbox setChecked was inappropriate; clicking the actual button enabled local code. The same graph's business/state view remained functional when code was closed.

Actual scene plane inspection succeeded through the trial-only read-only DOM diagnostics. Hiding state removed its actual background plane; restoring gap 260 restored plane Y values. Actual camera orbit, rendered semantic node/edge coordinates and region-label rectangles are retained in spatial-before-orbit.json and spatial-after-orbit.json for mathematical checks against the installed helpers.

The exact installed helpers now validate actual before-orbit, settled orbit and group-drag captures: all 30 nodes and four volumes share their planes, 17 same-layer edges per view pass 101 sampled points each, and visible captions track projected circumference bottom +7px. Layer gap and hidden-plane preservation checks pass.

Later R6 change passed full verify/accept/check: 39/39 business assertions, 153 independent witnesses, 213 projections, six features/40 required event checks, full source graph 528 nodes/617 edges. Full baseline SHA-256 is unchanged from begin through accept; the initial manual baseline scope amendment remains an explicit separate process deviation.

Accepted-build browser recording 255111f86fcc4b0eb57da3696404b15b has 63 events, four actual frames, three actual transitions, no reported gaps/errors/drops. Exact event/source/target/guards/revision and parent call identities match actual native frames and the pre-restart public query. Live query paths become explicitly partial after process restart; durable recordings retain original history.

Actual core ZIP ran without observer/viewer. Same-build restart retained four rows, the 63-event recording and every personal preference entry. 2D/3D switching preserved all 30 3D node coordinates. Hidden/disabled graph Web modes add no business events through diagnostic reads; business completed while debug Web returned 404. Isolated source change rejected the formerly passing accepted gate and old source revision.

The replay summary duplicate remains FAILED. Parent/test initiator acknowledged the actual viewer defect and is fixing the maintained candidate independently. Trial will not edit the candidate viewer or hide rows; regression must use normal upgrade and the preserved original recording.

Exact duplicate diagnostics were captured at the initiator's request through a temporary GET-only localhost mirror. Both rows share commit event ...:89 and kind business, with owners repair.pending and repair.in_progress. Actual graphDebug.graph.boxes and displayGraph.boxes identify both as state nodes, with null referenceOf/event_node/parent. The mirror was stopped after extraction; accepted build, gate and full baseline hash remain unchanged. Files: review/duplicate-actual-boxes.json and review/duplicate-owner-dom.json.

Later correction: the trial generator's fixed runtime_owner=repair.submit was itself a mapping error missed by the earlier gate. Preserved original model/builder/report, began repair-runtime-owner with explicit R6 before any source edit, removed the override, and kept the machine unchanged. Added actual native-event fact/step regression to the existing evidence check.

Canonical replay-steps.js/viewer.js were then applied through normal bo_upgrade, with no conflicts. The untouched original recording produces [1,2,2,2] rows on the old viewer and [1,1,1,1] on the upgrade. Actual new browser recording 870c162a1d124eca8a1dab24b3336d90 has 60 events, four frames, three transitions, zero gaps/errors/drops. Source labels now match submit/claim/record_result/confirm; both endpoint states have changes/highlights; clicking the final row selects repair.completed. The prior failed item is now closed by separate regression evidence, not erased.

Latest accepted build 2589ec518852a132c32ab71d4f5f3dc4ed2112ee0b88732fda1c4c26d6f0cd6f passes the full gate and actual ZIP execution/stale-source counterexample. Later baseline SHA256 B26A1729D15C307D060B99C6D2541D53C08D953449DC981B6962816960E84568 is unchanged from begin through accept. Upgrade preferences retain positions/pins/layers/2D; only a live camera damping coordinate differed by about 6.47e-12, so exact preference-byte equality is not claimed.
