"""Normal delivery gate: independent checks plus the accepted-current change receipt."""

import subprocess
import sys
import os
import json
from pathlib import Path

if __name__ == "__main__":
    root = Path(__file__).resolve().parent
    os.environ.setdefault("REPAIR_DATABASE_URL", "sqlite:///" + (root / "data/repair.sqlite").as_posix())
    cfg = json.loads((root / "sync.json").read_text(encoding="utf-8"))
    commands = [[sys.executable if item == "{python}" else item for item in command] for command in cfg["test_commands"]]
    for command in [*commands, [sys.executable, "-B", "observer_runtime/change_sync.py", "check", "--root", str(root)]]:
        result = subprocess.run(command, cwd=root)
        if result.returncode:
            raise SystemExit(result.returncode)
