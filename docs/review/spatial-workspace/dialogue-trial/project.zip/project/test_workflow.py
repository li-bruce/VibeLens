"""Independent business expectations and native declaration counterexamples."""

from copy import deepcopy
import json
from observe import ROOT, run_suite
from bo_stategraph.bo_executor import BOExecutor
from bo_stategraph.workflow import GUARDS


def main():
    preserved = json.loads((ROOT / "review/initial-baseline-before-provenance-repair.json").read_text(encoding="utf-8"))
    current_intent = json.loads((ROOT / "intent.json").read_text(encoding="utf-8"))
    assert [{key: value for key, value in rule.items() if key != "status"} for rule in current_intent["requirements"]] == preserved["intent"]["requirements"], "The audited metadata repair changed requirement meaning"
    assert all(rule["status"] == "confirmed" for rule in current_intent["requirements"])
    payload = run_suite(modes=("off",))
    expected = json.loads((ROOT / "acceptance.json").read_text(encoding="utf-8"))["checks"]
    runs = {run["case"]: run for run in payload["runs"]}
    for check in expected:
        actual = runs[check["case"]]["observations"]
        for part in check["path"]:
            actual = actual[part]
        assert type(actual) is type(check["equals"]) and actual == check["equals"], (check["id"], actual)
    declaration = payload["machine"]
    for name, mutate in [
        ("unknown_engine", lambda machine: machine.update(engine="unknown")),
        ("missing_guard", lambda machine: machine["guards"].update(unbound="missing")),
        ("unsupported_callback", lambda machine: machine["transitions"][0].update(before="unbound")),
        ("missing_state", lambda machine: machine["values"].pop()),
    ]:
        invalid = deepcopy(declaration)
        mutate(invalid)
        try:
            BOExecutor(invalid, GUARDS)
        except ValueError:
            continue
        raise AssertionError(name + " accepted an invalid declaration")
    print(json.dumps({"valid": True, "independent_business_assertions": len(expected), "cases": len(runs), "invalid_declarations_rejected": 4}))


if __name__ == "__main__":
    main()
