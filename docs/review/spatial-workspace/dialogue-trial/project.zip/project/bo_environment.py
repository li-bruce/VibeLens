"""Expose the installed candidate runtime entrypoints without touching global paths."""

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
RUNTIME = ROOT / "observer_runtime"
if str(RUNTIME) not in sys.path:
    sys.path.insert(0, str(RUNTIME))
