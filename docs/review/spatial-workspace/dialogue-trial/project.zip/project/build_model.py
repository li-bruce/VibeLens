"""Portable generator entrypoint; implementation is tracked under tooling/."""

from tooling.bo_build import build

if __name__ == "__main__":
    build()
