"""Execute real HTTP handlers and compare public projections to independent SQLite reads."""

import json
from pathlib import Path
import sqlite3
from threading import Barrier, Thread
import uuid
import bo_environment
from app.domain import RepairService
from app.server import create_app
from app.storage import Store
from integrations.bo_adapter import BOAdapter
from bo_observer.service import GraphSession
from behavior_model import capture
from mapping_contract import instance_witnesses

ROOT = Path(__file__).resolve().parents[1]
CASES = ("normal", "wrong_role", "wrong_technician", "wrong_submitter", "wrong_order", "completed_terminal", "empty_content", "empty_result", "restart", "claim_race", "rollback")


def independent_rows(path: Path) -> list:
    with sqlite3.connect("file:" + path.as_posix() + "?mode=ro", uri=True) as connection:
        connection.row_factory = sqlite3.Row
        return [dict(row) for row in connection.execute("SELECT * FROM tickets ORDER BY id")]


def subject(path, project, build_id, mode, envelopes):
    session = GraphSession(ROOT) if mode == "on" else None
    def sink(body, kind):
        envelopes.append({"kind": kind, "body": body})
        if mode == "fault":
            raise RuntimeError("controlled_capture_sink_failure")
        if session:
            result = session.event(body) if kind == "events" else session.snapshot(body)
            if not result.get("accepted"):
                raise ValueError("collector_rejected_actual_evidence: " + json.dumps(result))
    adapter = BOAdapter(project, build_id, ROOT, mode=mode, sink=sink)
    store = Store(path, adapter)
    service = RepairService(store, project["model"]["machine"], adapter, build_id)
    client = create_app(service, project["model"]).test_client()
    return service, client, adapter, session


def run_case(case, mode, project, build_id, folder):
    path = folder / (case + "-" + mode + ".sqlite")
    envelopes = []
    service, client, adapter, session = subject(path, project, build_id, mode, envelopes)
    sessions, adapters, stores = [session], [adapter], [service.store]
    http = []
    def post(route, actor_id, **data):
        response = client.post(route, json={"actor_id": actor_id, **data})
        http.append({"method": "POST", "path": route, "actor_id": actor_id, "status": response.status_code, "body": response.get_json()})
        return response
    def submit():
        response = post("/api/tickets", "u1", content="  Leaking tap  ")
        assert response.status_code == 200, response.get_json()
        return response.get_json()["id"]
    def claim(ident):
        response = post(f"/api/tickets/{ident}/claim", "t1")
        assert response.status_code == 200, response.get_json()
    def result(ident):
        response = post(f"/api/tickets/{ident}/result", "t1", result="  Fixed the leaking tap  ")
        assert response.status_code == 200, response.get_json()
    def confirm(ident):
        response = post(f"/api/tickets/{ident}/confirm", "u1")
        assert response.status_code == 200, response.get_json()
    observations = {}
    try:
        if case == "empty_content":
            response = post("/api/tickets", "u1", content="   ")
            assert response.status_code == 409
            observations["no_ticket"] = not independent_rows(path)
        else:
            ident = submit()
            route = f"/api/tickets/{ident}"
            if case in {"normal", "completed_terminal"}:
                history = [independent_rows(path)[0]]
                states = [history[0]["state"]]
                for operation in (claim, result, confirm):
                    operation(ident)
                    history.append(independent_rows(path)[0])
                    states.append(history[-1]["state"])
                final = independent_rows(path)[0]
                if case == "normal":
                    observations.update(states=states, final_result=final["result"], final_revision=final["revision"], submitted={"actor_id": "u1", "content_length": len("  Leaking tap  ")}, claimed={"actor_id": "t1", "ticket_id": ident}, recorded={"actor_id": "t1", "ticket_id": ident, "result_length": len("  Fixed the leaking tap  ")}, confirmed={"actor_id": "u1", "ticket_id": ident})
                    for key, snapshot in zip(("submitted", "claimed", "recorded", "confirmed"), history):
                        observations[key].update(ticket_id=snapshot["id"], state=snapshot["state"], revision=snapshot["revision"])
                    assert client.get("/api/identities").status_code == 200
                    assert client.get("/api/tickets").status_code == 200
                else:
                    before = independent_rows(path)
                    assert post(route + "/confirm", "u1").status_code == 409
                    observations["unchanged"] = independent_rows(path) == before
            elif case == "wrong_role":
                before = independent_rows(path)
                assert post(route + "/claim", "u2").status_code == 409
                observations["unchanged"] = independent_rows(path) == before
            elif case == "wrong_order":
                before = independent_rows(path)
                assert post(route + "/result", "t1", result="too early").status_code == 409
                observations["unchanged"] = independent_rows(path) == before
            elif case in {"wrong_technician", "empty_result"}:
                claim(ident)
                before = independent_rows(path)
                response = post(route + "/result", "t2" if case == "wrong_technician" else "t1", result="fixed" if case == "wrong_technician" else "   ")
                assert response.status_code == 409
                observations["unchanged"] = independent_rows(path) == before
            elif case == "wrong_submitter":
                claim(ident)
                result(ident)
                before = independent_rows(path)
                assert post(route + "/confirm", "u2").status_code == 409
                observations["unchanged"] = independent_rows(path) == before
            elif case == "restart":
                claim(ident)
                result(ident)
                before = independent_rows(path)
                adapter.flush()
                adapter.close()
                service.store.close()
                if session:
                    session.close()
                service, client, adapter, session = subject(path, project, build_id, mode, envelopes)
                sessions.append(session)
                adapters.append(adapter)
                stores.append(service.store)
                assert client.get("/api/tickets").status_code == 200
                observations["preserved"] = independent_rows(path) == before
            elif case == "claim_race":
                barrier = Barrier(3)
                outcomes = []
                def contender(actor_id):
                    barrier.wait()
                    try:
                        service.claim(ident, actor_id)
                        outcomes.append("claimed")
                    except ValueError:
                        outcomes.append("rejected")
                threads = [Thread(target=contender, args=(name,)) for name in ("t1", "t2")]
                for thread in threads:
                    thread.start()
                barrier.wait()
                for thread in threads:
                    thread.join(10)
                    assert not thread.is_alive()
                observations["successful_claims"] = outcomes.count("claimed")
                observations["outcomes"] = outcomes
            elif case == "rollback":
                before = independent_rows(path)
                try:
                    with service.bo.call("repair.claim", "ticket:" + str(ident)):
                        with service.store.transaction() as connection:
                            row = service.store.get(connection, ident)
                            service.store.update(connection, row, {**row, "state": "in_progress", "technician_id": "t1", "revision": 2})
                            raise RuntimeError("controlled_after_write_failure")
                except RuntimeError:
                    pass
                observations["unchanged"] = independent_rows(path) == before
        for current in adapters:
            assert current.flush(), "Capture did not drain"
        before_query_events = len(envelopes)
        projection = client.get("/api/stategraph").get_json()
        for current in adapters:
            current.flush()
        assert len(envelopes) == before_query_events, "Observer query emitted business events"
        actual_rows = independent_rows(path)
        actual = [{"id": "ticket:" + str(row["id"]), **row, "id": "ticket:" + str(row["id"]), "build_id": service.build_id, "result_length": len(row["result"])} for row in actual_rows]
        witnesses = instance_witnesses(projection["instances"], {row["id"]: {"state": row["state"], "revision": row["revision"], "build_id": row["build_id"], "context": {"submitter_id": row["submitter_id"], "technician_id": row["technician_id"], "result_length": row["result_length"]}} for row in actual}, case=case + ":" + mode, source="Independent sqlite3 SELECT after real handler execution")
        stats = [{"probe_errors": item.bo_probe.bo_errors, "dropped": item.bo_probe.bo_dropped, "data_errors": item.bo_data.bo_errors, "adapter_errors": item.bo_errors} for item in adapters]
        if mode == "on":
            assert all(not any(values.values()) for values in stats), stats
        events = [item["body"] for item in envelopes if item["kind"] == "events"] if mode == "on" else []
        if case == "wrong_technician" and mode == "on":
            decisions = [event for event in events if event["node"] == "guard.has_result"]
            assert not decisions, "Short-circuited guard was falsely reported"
        native = session.view() if session is not None else {}
        value = {"case": case, "mode": mode, "events": events, "observations": observations, "authority_snapshot": {"runs": actual, "raw_rows": actual_rows}, "projection": {key: projection[key] for key in ("build_id", "machine", "instances")}, "native_runtime_frames": native.get("runtime_frames"), "native_instances": native.get("instances", []), "http": http, "capture_stats": stats, "database": str(path.relative_to(ROOT))}
        return value, witnesses, projection["stategraph_export"]
    finally:
        for current in adapters:
            current.close()
        for current in stores:
            current.close()
        for current in sessions:
            if current:
                current.close()


def run_suite(modes=("on", "off", "fault")):
    project = json.loads((ROOT / "bo_stategraph/project.json").read_text(encoding="utf-8"))
    binding = capture(ROOT, project["model"])
    folder = ROOT / "review/runtime-evidence" / (binding["build_id"][:12] + "-" + uuid.uuid4().hex[:8])
    folder.mkdir(parents=True)
    runs, witnesses, public = [], [], None
    for mode in modes:
        for case in CASES:
            result, checks, exported = run_case(case, mode, project, binding["build_id"], folder)
            runs.append(result)
            witnesses.extend(checks)
            if case == "normal" and (mode == "on" or public is None):
                public = exported
    return {"build_id": binding["build_id"], "machine": project["model"]["machine"], "runs": runs, "mapping_checks": witnesses, "stategraph_export": public}


if __name__ == "__main__":
    print(json.dumps(run_suite(), ensure_ascii=False))
