"""Tracked graph maintenance and independent trial execution utilities."""
