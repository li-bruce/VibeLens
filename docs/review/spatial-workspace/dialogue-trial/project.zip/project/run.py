"""One development command launches the application and its isolated observer."""

import argparse
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
from urllib.request import urlopen
import bo_environment

ROOT = Path(__file__).resolve().parent


def app_worker(port, mode):
    from app.domain import RepairService
    from app.server import create_app
    from app.storage import Store
    from integrations.bo_adapter import BOAdapter
    from behavior_model import capture
    project = json.loads((ROOT / "bo_stategraph/project.json").read_text(encoding="utf-8"))
    binding = capture(ROOT, project["model"])
    adapter = BOAdapter(project, binding["build_id"], ROOT, mode=mode)
    store = Store(ROOT / "data/repair.sqlite", adapter)
    service = RepairService(store, project["model"]["machine"], adapter, binding["build_id"])
    app = create_app(service, project["model"])
    try:
        app.run(host="127.0.0.1", port=port, threaded=True, use_reloader=False)
    finally:
        adapter.flush()
        adapter.close()
        store.close()


def available(port):
    with socket.socket() as sock:
        return sock.connect_ex(("127.0.0.1", port)) != 0


def wait_for(url, process, seconds=15):
    deadline = time.monotonic() + seconds
    while process.poll() is None and time.monotonic() < deadline:
        try:
            with urlopen(url, timeout=0.5) as response:
                if response.status == 200:
                    return True
        except OSError:
            pass
        time.sleep(0.1)
    return False


def stop_owned(process):
    """Stop one child and its Windows redirector descendants, never a port owner by guess."""
    if process.poll() is not None:
        return
    if os.name == "nt":
        subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    else:
        process.terminate()
    try:
        process.wait(5)
    except subprocess.TimeoutExpired:
        process.kill()


def launch(app_port, graph_port, mode, app_only):
    if not available(app_port) or (not app_only and not available(graph_port)):
        raise RuntimeError("Requested port is occupied; no existing process was stopped")
    environment = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1", "PYTHONIOENCODING": "utf-8", "REPAIR_DATABASE_URL": "sqlite:///" + (ROOT / "data/repair.sqlite").as_posix()}
    children, streams = [], []
    def start(name, command):
        command = [str(ROOT / command[0]), *command[1:]]
        output = (ROOT / "review" / (name + ".log")).open("a", encoding="utf-8")
        streams.append(output)
        process = subprocess.Popen([sys.executable, "-B", *command], cwd=ROOT, env=environment, stdout=output, stderr=subprocess.STDOUT, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        children.append(process)
        return process
    def owned_pids():
        return [process.pid for process in children if process.poll() is None]
    try:
        observer = None
        if not app_only:
            observer = start("observer", ["integrations/bo_serve.py", "--root", str(ROOT), "--port", str(graph_port)])
            if not wait_for(f"http://127.0.0.1:{graph_port}/graph", observer):
                print("Observer unavailable; application execution remains independent", flush=True)
        application = start("application", ["run.py", "--worker", "app", "--app-port", str(app_port), "--mode", mode])
        if not wait_for(f"http://127.0.0.1:{app_port}/api/stategraph/health", application):
            raise RuntimeError("Application failed to become ready; inspect review/application.log")
        print(f"Application: http://127.0.0.1:{app_port}/", flush=True)
        if observer and observer.poll() is None:
            print(f"VibeLens: http://127.0.0.1:{graph_port}/graph", flush=True)
        settings_path = ROOT / ".stategraph/collector.json"
        loaded = json.loads(settings_path.read_text(encoding="utf-8")).get("build_id") if settings_path.exists() else None
        while application.poll() is None:
            (ROOT / ".stategraph/processes.json").write_text(json.dumps({"supervisor_pid": os.getpid(), "owned_pids": owned_pids(), "app_pid": application.pid, "observer_pid": observer.pid if observer else None, "app_port": app_port, "graph_port": graph_port, "root": str(ROOT)}, indent=2), encoding="utf-8")
            if observer and observer.poll() is None and settings_path.exists():
                current = json.loads(settings_path.read_text(encoding="utf-8")).get("build_id")
                if current != loaded:
                    stop_owned(application)
                    application = start("application", ["run.py", "--worker", "app", "--app-port", str(app_port), "--mode", mode])
                    if not wait_for(f"http://127.0.0.1:{app_port}/api/stategraph/health", application):
                        raise RuntimeError("Producer reload failed")
                    loaded = current
                    print("Application reloaded for observer build " + str(current), flush=True)
            time.sleep(0.5)
    except KeyboardInterrupt:
        pass
    finally:
        for process in reversed(children):
            stop_owned(process)
        for stream in streams:
            stream.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--worker", choices=["app"])
    parser.add_argument("--app-port", type=int, default=8898)
    parser.add_argument("--graph-port", type=int, default=8899)
    parser.add_argument("--mode", choices=["on", "off", "fault"], default="on")
    parser.add_argument("--app-only", action="store_true")
    args = parser.parse_args()
    if args.worker:
        app_worker(args.app_port, args.mode)
    else:
        launch(args.app_port, args.graph_port, args.mode, args.app_only)
