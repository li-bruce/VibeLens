"""Exercise the installed renderer's actual curve and camera-relative caption helpers."""

import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = r'''
import assert from 'node:assert/strict';
import * as T from './static/graph/spatial-three.vendor.js';
import { edgeCurve } from './static/graph/spatial-paths.js';
import { regionLabelAnchor } from './static/graph/spatial-labels.js';
let curves=0, views=0;
for (const y of [0,260,520]) {
 for (const [a,b] of [[{x:0,y,z:0},{x:280,y,z:120}],[{x:10,y,z:20},{x:10,y,z:20}]]) {
  const curve=edgeCurve(a,b);
  for(let i=0;i<=100;i++) assert.ok(Math.abs(curve.getPoint(i/100).y-y)<1e-9);
  curves++;
 }
}
const volume={center:{x:0,y:260,z:0},radius:160}, anchors=[];
for(const position of [[0,1100,1],[700,650,900],[-650,500,600]]) {
 const camera=new T.PerspectiveCamera(42,16/9,1,10000);
 camera.position.fromArray(position); camera.lookAt(0,260,0); camera.updateMatrixWorld();
 const project=(p)=>{const v=new T.Vector3(p.x,p.y,p.z).project(camera);return{x:(v.x+1)*640,y:(1-v.y)*360,depth:v.z};};
 const anchor=regionLabelAnchor(volume,project);
 let bottom=-Infinity;
 for(let i=0;i<4096;i++){const angle=i/4096*Math.PI*2;bottom=Math.max(bottom,project({x:Math.cos(angle)*160,y:260,z:Math.sin(angle)*160}).y);}
 assert.ok(anchor.y>=bottom+6.5&&anchor.y<=bottom+7.5);
 anchors.push(anchor); views++;
}
assert.notDeepEqual(anchors[0],anchors[1]);
console.log(JSON.stringify({valid:true,curves,sampledPoints:curves*101,cameraViews:views,circumferenceSamples:views*4096,labelOffsetPx:7}));
'''

if __name__ == "__main__":
    result = subprocess.run(["node", "--experimental-default-type=module", "--input-type=module", "-e", SCRIPT], cwd=ROOT, capture_output=True, text=True, encoding="utf-8", timeout=30)
    if result.returncode:
        raise SystemExit(result.stderr)
    print(result.stdout.strip())
