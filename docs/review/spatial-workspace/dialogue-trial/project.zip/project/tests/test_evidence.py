"""Check real commit journals, native state frames and observation isolation."""

from copy import deepcopy
import json
from pathlib import Path
import sys
import subprocess
from threading import Event
import uuid

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import bo_environment
from observe import run_case, independent_rows
from app.domain import RepairService
from app.storage import Store
from integrations.bo_adapter import BOAdapter
from behavior_model import capture
from mapping_contract import assess
from bo_stategraph.bo_pathcheck import bo_path_report


def main():
    project = json.loads((ROOT / "bo_stategraph/project.json").read_text(encoding="utf-8"))
    build_id = capture(ROOT, project["model"])["build_id"]
    folder = ROOT / "review/runtime-evidence" / ("evidence-" + uuid.uuid4().hex[:8])
    folder.mkdir(parents=True)
    run, _, exported = run_case("normal", "on", project, build_id, folder)
    journal = exported["runtime"]["machine"]["journal"]
    assert exported["runtime"]["machine"]["path_evidence"]["status"] == "complete"
    expected = [("claim", "pending", "in_progress", {"is_technician": True}), ("record_result", "in_progress", "awaiting_confirmation", {"is_technician": True, "is_assignee": True, "has_result": True}), ("confirm", "awaiting_confirmation", "completed", {"is_submitter": True})]
    assert [(entry["event"], entry["source"], entry["target"], entry["guards"]) for entry in journal] == expected
    by_event = {event["id"]: event for event in run["events"]}
    call_nodes = {}
    for event in run["events"]:
        call_nodes.setdefault(event["call_id"], set()).add(event["node"])
    assert all(len(nodes) == 1 for nodes in call_nodes.values()), "Several actual functions share one call identity"
    for event in run["events"]:
        if event["node"] == "flow.step":
            assert event["parent_call_id"] in call_nodes and any(node.startswith("repair.") for node in call_nodes[event["parent_call_id"]])
        if event["node"].startswith("guard."):
            assert call_nodes.get(event["parent_call_id"]) == {"flow.step"}
    frames = {frame["event_id"]: frame for frame in run["native_runtime_frames"]["frames"]}
    assert len(frames) == 4
    assert sorted(frame["revision"] for frame in frames.values()) == [1, 2, 3, 4]
    for entry in journal:
        event = by_event[entry["evidence_id"]]
        assert event["phase"] == "commit" and event["revision"] == entry["revision"]
        frame = frames[entry["evidence_id"]]
        assert frame["machine"]["current"] == entry["target"]
        actual = frame["machine"]["journal"]
        assert len(actual) == 1 and (actual[0]["event"], actual[0]["source"], actual[0]["target"]) == (entry["event"], entry["source"], entry["target"])
    assert all(not item["errors"] and not item["missing"] for item in run["native_instances"])
    # Exercise the actual viewer fact builder with this real native run. The
    # container is a unit-test view input; events and event-bound frames are real.
    assert "runtime_owner" not in project["model"]["presentation"]
    replay_input = {"build_id": build_id, "context": {"model": project["model"], "machine": {"configurations": []}, "events": []}, "final": {"machine": run["native_runtime_frames"]["frames"][-1]["machine"]}, "runtime_frames": run["native_runtime_frames"], "events": run["events"], "commands": [], "status": "stopped"}
    replay_script = """
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {boFacts,boStepDetail} from './static/graph/replay-steps.js';
import {timeline} from './static/graph/recording.js';
const recording=JSON.parse(fs.readFileSync(0,'utf8')),items=timeline(recording);
const facts=boFacts(recording,items),business=facts.changes.flat().filter(x=>x.kind==='business');
assert.deepEqual(business.map(x=>x.node),['repair.submit','repair.claim','repair.record_result','repair.confirm']);
const all=new Map(recording.context.model.nodes.map(n=>[n.id,n]));
const visible=[...all.values()].filter(n=>n.kind==='state'&&n.id.startsWith('repair.')).map(n=>({id:n.id,node:n,type:n.kind}));
let previous=0;
const rows=[];
for(const fact of business){
 const event=recording.events.find(e=>e.id===fact.event);
 assert.equal(event.node,fact.node);
 const index=items.findIndex(e=>e.id===event.id),detail=boStepDetail(recording,items,index,previous,all,visible);
 assert.equal(detail.rows.length,1,'One actual state fact must appear in one summary row');
 const row=detail.rows[0];
 assert.equal(row.sourceLabel,all.get(event.node).label);
 assert.equal(row.owner,visible.find(b=>b.node.value===fact.after).id);
 assert.deepEqual(new Set(row.owners),new Set(visible.filter(b=>b.node.value===fact.before||b.node.value===fact.after).map(b=>b.id)));
 rows.push(row);previous=index;
}
console.log(JSON.stringify({valid:true,actualCommitOwners:business.map(x=>x.node),business,rows}));
"""
    replay = subprocess.run(["node", "--experimental-default-type=module", "--input-type=module", "-e", replay_script], input=json.dumps(replay_input), cwd=ROOT, capture_output=True, text=True, encoding="utf-8", timeout=30)
    assert replay.returncode == 0, (replay.stdout, replay.stderr)
    (folder / "actual-runtime-owner-facts.json").write_text(replay.stdout, encoding="utf-8")
    configurations = deepcopy(exported["runtime"]["machine"]["configurations"])
    incomplete = deepcopy(journal)
    removed = incomplete.pop(1)
    gap = bo_path_report(project["model"]["machine"], configurations, incomplete, {"ticket:1": {"state": run["observations"]["states"][0], "revision": 1}})
    assert configurations[0]["phase"] == "completed" and configurations[0]["state_revision"] == 4
    assert gap["status"] == "partial" and any("Missing" in item or "differs" in item for item in gap["instances"][0]["gaps"])
    (folder / "removed-transition-counterexample.json").write_text(json.dumps({"removed_actual_witness": removed, "final_state_preserved": configurations[0]["phase"], "report": gap}, indent=2), encoding="utf-8")
    (folder / "normal-journal-and-frames.json").write_text(json.dumps({"run": run, "public_export": exported}, ensure_ascii=False, indent=2), encoding="utf-8")

    release, entered = Event(), Event()
    def slow_sink(body, kind):
        entered.set()
        release.wait(5)
    adapter = BOAdapter(project, build_id, ROOT, sink=slow_sink, capacity=1)
    store = Store(folder / "queue-limited.sqlite", adapter)
    service = RepairService(store, project["model"]["machine"], adapter, build_id)
    try:
        row = service.submit("u1", "Queue test")
        assert entered.wait(1)
        service.claim(row["id"], "t1")
        service.record_result(row["id"], "t1", "Repaired")
        service.confirm(row["id"], "u1")
        actual = independent_rows(store.path)[0]
        assert actual["state"] == "completed" and actual["revision"] == 4
        assert adapter.bo_probe.bo_dropped > 0, "Queue pressure test did not exercise overflow"
        dropped = adapter.bo_probe.bo_dropped
    finally:
        release.set()
        adapter.flush()
        adapter.close()
        store.close()
    print(json.dumps({"valid": True, "actual_transitions": len(journal), "actual_state_frames": len(frames), "event_and_guard_witnesses": "checked", "removed_transition_with_final_state": "mapping_gap_detected", "queue_dropped": dropped, "queue_limited_business_state": "completed", "evidence": str(folder.relative_to(ROOT))}))


if __name__ == "__main__":
    main()
