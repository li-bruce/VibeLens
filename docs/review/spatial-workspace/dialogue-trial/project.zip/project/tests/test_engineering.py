"""Real schema change, observer-free core and semantic mutation checks in isolated copies."""

import json
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys
import uuid

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import bo_environment
from bo_observer.data.catalog import collect
from bo_observer.delivery.architecture_guard import inspect, collect as collect_paths


def observation_mutant(folder, name, transform, expected_key):
    isolated = folder / name
    isolated.mkdir()
    project = json.loads((ROOT / "bo_stategraph/project.json").read_text(encoding="utf-8"))
    for relative in [*project["model"]["source_files"], "bo_stategraph/project.json"]:
        target = isolated / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / relative, target)
    shutil.copytree(ROOT / "observer_runtime", isolated / "observer_runtime", ignore=shutil.ignore_patterns("__pycache__", "node_modules"))
    domain = isolated / "app/domain.py"
    original = domain.read_text(encoding="utf-8")
    changed = transform(original)
    assert changed != original
    domain.write_text(changed, encoding="utf-8")
    script = '''import json\nfrom pathlib import Path\nfrom observe import run_case\nfrom behavior_model import capture\nfrom implementation_coverage import runtime_errors\nroot=Path.cwd()\nproject=json.loads(Path('bo_stategraph/project.json').read_text(encoding='utf-8'))\nbuild=capture(root,project['model'])['build_id']\nfolder=root/'review/mutant-run'\nfolder.mkdir(parents=True)\nrun,_,public=run_case('normal','on',project,build,folder)\nassert run['observations']['states']==['pending','in_progress','awaiting_confirmation','completed']\nerrors=runtime_errors(project['model']['implementation'],project['model'],{'build_id':build,'runs':[run]},root=root)['errors']\nprint(json.dumps({'business_completed':True,'errors':errors,'actual_events':run['events'],'observations':run['observations']}))\n'''
    (isolated / "mutant_check.py").write_text(script, encoding="utf-8")
    result = subprocess.run([sys.executable, "-B", "mutant_check.py"], cwd=isolated, capture_output=True, text=True, encoding="utf-8", timeout=60)
    assert result.returncode == 0, (result.stdout, result.stderr)
    payload = json.loads(result.stdout)
    assert payload["business_completed"]
    assert any(expected_key in error and error.get("feature_event_missing", error.get("feature_value_mismatch")) == ("confirm" if name == "missing-probe" else "submit") for error in payload["errors"]), payload["errors"]
    (isolated / "result.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"business_completed": True, "targeted_mapping_failure": expected_key}


def main():
    folder = ROOT / ".validation/engineering" / uuid.uuid4().hex[:8]
    folder.mkdir(parents=True)
    active = json.loads((ROOT / ".stategraph/active.json").read_text(encoding="utf-8"))["change"]
    if active != ".stategraph/repair-initial":
        frozen_baseline = ROOT / "review" / (Path(active).name + "-baseline-begin.json")
        assert (ROOT / active / "baseline.json").read_bytes() == frozen_baseline.read_bytes(), "Baseline changed after begin"
    ownership = json.loads((ROOT / "ownership.json").read_text(encoding="utf-8"))
    architecture = inspect(ROOT, ownership)
    assert architecture["valid"], architecture["errors"]
    core = folder / "core"
    core.mkdir()
    for name in collect_paths(ROOT, ownership["core_include"]):
        target = core / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / name, target)
    clean = subprocess.run([sys.executable, "-B", "bo_core_run.py", "--self-test"], cwd=core, capture_output=True, text=True, encoding="utf-8")
    assert clean.returncode == 0, clean.stderr
    clean_result = json.loads(clean.stdout)
    assert not clean_result["observer_runtime_present"] and not clean_result["viewer_present"]
    policy = core / "app/policy.py"
    policy.write_text(policy.read_text(encoding="utf-8").replace('return context["submitter_id"] == payload["actor_id"]', "return True"), encoding="utf-8")
    script = '''import json\nfrom pathlib import Path\nfrom app.storage import Store\nfrom app.domain import RepairService\nfrom app.ports import NullObserver\nproject=json.loads(Path('bo_stategraph/project.json').read_text(encoding='utf-8'))\nstore=Store(Path('data/mutated.sqlite'))\nservice=RepairService(store,project['model']['machine'],NullObserver(),'isolated-mutant')\nrow=service.submit('u1','Guard mutant')\nservice.claim(row['id'],'t1')\nservice.record_result(row['id'],'t1','Repaired')\ntry:\n service.confirm(row['id'],'u2')\nexcept ValueError:\n print('Business guard rejected outsider')\nelse:\n print('BUSINESS VIOLATION: outsider confirmation committed')\n raise SystemExit(2)\n'''
    (core / "mutation_case.py").write_text(script, encoding="utf-8")
    broken = subprocess.run([sys.executable, "-B", "mutation_case.py"], cwd=core, capture_output=True, text=True, encoding="utf-8")
    assert broken.returncode == 2 and "BUSINESS VIOLATION" in broken.stdout, (broken.returncode, broken.stdout, broken.stderr)
    missing = observation_mutant(folder, "missing-probe", lambda source: "\n".join("            event_id = None" if 'event_id = self.bo.record("repair.confirm", "commit"' in line else line for line in source.split("\n")), "feature_event_missing")
    wrong_input = observation_mutant(folder, "wrong-input", lambda source: "\n".join(line.replace('"actor_id": actor_id', '"actor_id": "u2"') if 'event_id = self.bo.record("repair.submit", "commit"' in line else line for line in source.split("\n")), "feature_value_mismatch")

    fixture = folder / "schema.sqlite"
    with sqlite3.connect(fixture) as connection:
        connection.execute("CREATE TABLE tickets(id INTEGER PRIMARY KEY, content TEXT NOT NULL)")
    import os
    variable = "REPAIR_SCHEMA_TEST_URL"
    os.environ[variable] = "sqlite:///" + fixture.as_posix()
    config = {"id": "schema-test", "engine": "sqlalchemy", "url_env": variable}
    before = collect(config, root=ROOT)
    with sqlite3.connect(fixture) as connection:
        connection.execute("ALTER TABLE tickets ADD COLUMN diagnostic_marker INTEGER")
    after = collect(config, root=ROOT)
    old_fields = {field["name"] for resource in before["resources"] for field in resource["fields"]}
    new_fields = {field["name"] for resource in after["resources"] for field in resource["fields"]}
    assert "diagnostic_marker" not in old_fields and "diagnostic_marker" in new_fields
    result = {"valid": True, "architecture": architecture, "core_execution": clean_result, "semantic_mutation": {"exit": broken.returncode, "stdout": broken.stdout, "stderr": broken.stderr, "reason": "Actual outsider confirmation committed in isolated broken guard copy"}, "observation_mutations": {"missing_probe": missing, "wrong_input": wrong_input}, "schema_before": before, "schema_after": after}
    (folder / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"valid": True, "architecture": True, "core_without_observer": True, "business_mutant_detected": True, "real_schema_change": True, "evidence": str(folder.relative_to(ROOT))}))


if __name__ == "__main__":
    main()
