# Repair ticket trial

This is an independent simulated-user VibeLens trial. It is not a human usability study. The confirmed scope is a local Python repair website with fixed identities, no login, SQLite + SQLAlchemy persistence and four states:

`pending -> in_progress -> awaiting_confirmation -> completed`

Only a technician claims a pending ticket. Only its assigned technician records a nonempty result. Only its submitter confirms completion. Completion is terminal. There is no rejection or rework workflow.

## Run

From this directory in PowerShell:

```powershell
$env:PYTHONDONTWRITEBYTECODE='1'
$env:PYTHONIOENCODING='utf-8'
.\.venv\Scripts\python.exe -B run.py
```

The launcher prints and serves both local URLs:

- Application: <http://127.0.0.1:8898/>
- VibeLens graph: <http://127.0.0.1:8899/graph>

Use 用户甲 / 用户乙 and 维修员甲 / 维修员乙 in the fixed identity selector. Create a ticket, switch to a technician to claim and record the result, then return to the submitting user to confirm. SQLite is `data/repair.sqlite`.

The existing virtual environment has the versions pinned in `requirements.txt`. For a fresh local environment, install that file with Python pip. Ports must be free; the launcher never stops an unrelated port owner. Stop the foreground launcher with Ctrl+C. Background trial ownership is recorded in `.stategraph/processes.json`; verify its exact root and process command line before stopping its own process tree.

## Verify

```powershell
.\.venv\Scripts\python.exe -B validate.py
.\.venv\Scripts\python.exe -B review/check_delivery.py --recording review/recording-runtime-owner.json --query review/public-query-runtime-owner.json --view review/live-view-runtime-owner.json --change .stategraph/repair-runtime-owner --core dist/repair-core-runtime-owner-20261025.zip --instance ticket:5 --out review/runtime-owner-delivery-check.json
node --experimental-default-type=module .validation/check_runtime_geometry.mjs
```

`validate.py` runs independent business/state/architecture/evidence checks and the accepted-current receipt gate. The delivery check above reads the latest actual 60-event recording, runs the actual ZIP export and rejects changed source in an isolated copy. Without arguments it checks the preserved earlier 63-event delivery. The geometry check reads actual browser-captured scene/DOM evidence and uses the exact installed Three.js and curve/caption helpers.

For a new implementation batch, read `.stategraph/active.json` and continue its change until accepted. Declare the actual allowed requirement IDs before a new `begin`, then preserve all baseline bytes, including scope metadata. Rebuild with `build_model.py`, scan with `observer_runtime/bo_sync.py scan --root .`, inspect/review/verify/accept/check with `observer_runtime/change_sync.py`. No baseline field may be manually amended. `AGENTS.md` and the active pointer define this workflow.

## Architecture and evidence

`bo_stategraph/project.json:model.machine` is the canonical declaration read by the native flat `BOExecutor`. `app/` owns business guards, authoritative SQL transactions and forms. `integrations/bo_adapter.py` is optional bounded observation. The shared `BOProbe`, data adapter, `GraphSession`, public `BOStateGraph` and viewer are candidate resources installed by the normal upgrade tool. `integrations/bo_serve.py` only exposes existing renderer diagnostics as a read-only DOM attribute for browser geometry inspection.

See [验收报告](review/验收报告.md), [evidence index](review/evidence-index.md) and [failure history](review/failures.jsonl). The latest core export is `dist/repair-core-runtime-owner-20261025.zip`; the previous ZIP is retained. Extract into a new folder and run `python -B bo_core_run.py --self-test` or `python -B bo_core_run.py --port 8898`. It retains business execution and public queries, with a neutral observation port and no observer runtime or viewer.

The final R6 correction removes the fixed `presentation.runtime_owner=repair.submit` override. Each state change now belongs to its actual native commit event.node. The canonical viewer upgrade shows one summary row for one fact while retaining all state display owners for highlights. Original duplicate-row recordings and screenshots remain unchanged.

Two boundaries remain explicit: live journals are retained in the current producer process; after restart, existing current states do not imply a recovered path. Saved recordings retain actual previous frames. Runtime events retain selected actor/state/revision/length values, not full ticket or result bodies. Independent private trial evidence contains the deliberately entered synthetic test text.

All authored work stays under this trial. No commits, publishing, other-chat messages or maintained-repository edits are performed by this trial.
