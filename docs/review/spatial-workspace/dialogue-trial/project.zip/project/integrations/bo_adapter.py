"""Isolated bounded capture and database adapters using the candidate's public APIs."""

from contextlib import contextmanager
from contextvars import ContextVar
from collections import deque
from copy import deepcopy
import json
from pathlib import Path
import uuid
from app.ports import NullObserver
from bo_stategraph.workflow import ticket_context
from bo_observer.adapters.python.bo_probe import BOProbe
from bo_observer.data.runtime import BODataRuntime
from bo_web import BOWeb


class BOAdapter(NullObserver):
    def __init__(self, project: dict, build_id: str, root: Path, *, mode="on", sink=None, capacity=256):
        settings_path = root / ".stategraph/collector.json"
        settings = json.loads(settings_path.read_text(encoding="utf-8")) if settings_path.exists() and sink is None else {}
        self.bo_mode = mode
        self.bo_revisions = {}
        self.bo_states = {}
        self.bo_bases = {}
        self.bo_journal = deque(maxlen=2048)
        self.bo_web = BOWeb(root)
        self.bo_context = ContextVar("repair_observation_context", default={})
        self.bo_probe = BOProbe(project, build_id, enabled=mode != "off", capacity=capacity, sink=sink, endpoint=settings.get("endpoint", "http://127.0.0.1:8899"), token=settings.get("token", ""), timeout=3)
        config = json.loads((root / "bo_stategraph/databases.json").read_text(encoding="utf-8"))
        self.bo_data = BODataRuntime(self.bo_probe, config)
        self.bo_errors = 0

    @contextmanager
    def call(self, node, entity=None):
        previous = self.bo_context.get()
        entity = entity or previous.get("entity", "application")
        scope = "application" if entity == "application" else "attempt"
        values = {"call_id": uuid.uuid4().hex, "parent_call_id": previous.get("call_id"), "owner_node": node, "entity": entity, "attempt": entity, "scope": scope}
        token = self.bo_context.set(values)
        try:
            yield
        except Exception as error:
            self.record(node, "error", lambda: {"inputs": {}, "outputs": {"error_type": type(error).__name__}})
            raise
        finally:
            self.bo_context.reset(token)

    def record(self, node, phase, builder, **kwargs):
        try:
            if self.bo_mode == "fault":
                def broken_builder():
                    raise RuntimeError("controlled_observer_builder_failure")
                builder = broken_builder
            context = dict(self.bo_context.get())
            owner = context.pop("owner_node", None)
            if owner is not None and owner != node:
                context["parent_call_id"] = context["call_id"]
                context["call_id"] = uuid.uuid4().hex
            return self.bo_probe.record(node, phase, builder, **{**context, **kwargs})
        except Exception:
            self.bo_errors += 1
            return None

    def publish(self, row, event=None, guards=None, evidence_id=None, payload=None):
        if evidence_id is None:
            return None
        try:
            previous = self.bo_states.get(row["id"])
            self.bo_bases.setdefault("ticket:" + str(row["id"]), {"state": row["state"], "revision": row["revision"], "evidence_id": evidence_id})
            if event is not None and previous is not None:
                self.bo_journal.append({"attempt": "ticket:" + str(row["id"]), "event": event, "source": previous["state"], "target": row["state"], "guards": deepcopy(guards), "payload": deepcopy(payload), "revision": row["revision"], "evidence_id": evidence_id, "build_id": self.bo_probe.bo_build, "run_id": self.bo_probe.bo_run, "producer_id": self.bo_probe.bo_producer})
            self.bo_states[row["id"]] = {"state": row["state"], "revision": row["revision"]}
            self.bo_revisions[row["id"]] = row["revision"]
            return self.bo_probe.snapshot("ticket:" + str(row["id"]), row["state"], ticket_context(row), row["revision"], evidence_id, event=event, guards=guards, payload=payload)
        except Exception:
            self.bo_errors += 1
            return None

    def restore_rows(self, rows):
        for row in rows:
            if row["id"] not in self.bo_revisions:
                entity = "ticket:" + str(row["id"])
                event_id = self.record("repair.list", "read", lambda: {"inputs": {}, "outputs": {"ticket_id": row["id"], "state": row["state"], "revision": row["revision"]}}, entity=entity, attempt=entity, scope="attempt", revision=row["revision"])
                self.publish(row, evidence_id=event_id)

    def execute(self, node, callback, **kwargs):
        return self.bo_data.execute(node, callback, **{**self.bo_data_context(), **kwargs})

    def transaction(self, node, manager, **kwargs):
        return self.bo_data.transaction(node, manager, **{**self.bo_data_context(), **kwargs})

    def transform(self, node, function, value, **kwargs):
        return self.bo_data.transform(node, function, value, **{**self.bo_data_context(), **kwargs})

    def bo_data_context(self):
        context = dict(self.bo_context.get())
        context.pop("owner_node", None)
        if "call_id" in context:
            context["parent_call_id"] = context.pop("call_id")
        return context

    def journal(self):
        return deepcopy(list(self.bo_journal))

    def state_bases(self):
        return deepcopy(self.bo_bases)

    def entry_html(self, raw):
        try:
            return self.bo_web.entry_html(raw.encode("utf-8")).decode("utf-8")
        except Exception:
            self.bo_errors += 1
            return raw

    def flush(self):
        return self.bo_probe.flush(timeout=5)

    def close(self):
        self.bo_data.close()
        self.bo_probe.close()
