"""Optional observation adapters."""
