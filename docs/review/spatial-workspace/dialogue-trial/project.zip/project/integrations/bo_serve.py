"""Shared observer service with read-only DOM diagnostics for this isolated trial."""

import argparse
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import bo_environment
from bo_observer.data.sync import synchronize
from bo_observer.data.watcher import DataWatch
from bo_observer.service import GraphSession, make_server

BO_DIAGNOSTICS = b'''<script type="module">
const boTimer = setInterval(() => {
  const target = document.querySelector('#viewport');
  const debug = window.graphDebug;
  if (!target || !debug) return;
  const model = debug.displayGraph || {};
  const endpoint = value => typeof value === 'string' ? value : value?.id || value?.node?.id || null;
  const nodes = Array.isArray(model.nodes) ? model.nodes.map(node => ({id:node.id,kind:node.kind,layer:node.layer,parent:node.parent})) : [];
  const edges = Array.isArray(model.edges) ? model.edges.map(edge => ({id:edge.id,from:endpoint(edge.from),to:endpoint(edge.to),type:edge.type,observed:edge.observed,items:(edge.items||[]).map(item=>({id:item.id,type:item.type,observed:item.observed}))})) : [];
  const value = {basis:'read-only getters from the actual installed renderer',build_id:debug.view?.manifest?.build_id,spatial:debug.spatial,positions:debug.spatialPositions,layers:debug.layers,displayKeys:Object.keys(model),nodes,edges};
  target.setAttribute('data-bo-trial-diagnostics', JSON.stringify(value));
}, 250);
window.addEventListener('pagehide', () => clearInterval(boTimer), {once:true});
</script>'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", required=True)
    parser.add_argument("--port", type=int, default=8899)
    args = parser.parse_args()
    root = Path(args.root).resolve()
    report = synchronize(root, model_path="bo_stategraph/project.json")
    if not report["valid"]:
        raise ValueError(report["errors"])
    session = GraphSession(root)
    server = make_server(session, args.port)
    original = server.RequestHandlerClass
    class BOHandler(original):
        def reply(self, code, body, mime="application/json"):
            if mime.startswith("text/html") and isinstance(body, bytes):
                body = body.replace(b"</body>", BO_DIAGNOSTICS + b"</body>")
            return super().reply(code, body, mime)
    server.RequestHandlerClass = BOHandler
    watcher = DataWatch(server)
    watcher.settings()
    print(f"Graph: http://127.0.0.1:{server.server_port}/graph", flush=True)
    watcher.start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        watcher.close()
        server.server_close()
        server.bo_session.close()


if __name__ == "__main__":
    main()
