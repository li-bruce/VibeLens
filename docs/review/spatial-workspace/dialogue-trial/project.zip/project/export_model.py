"""Offline native metadata exporter: no connection, migration or application import."""

import json
import bo_environment
from app.models import metadata
from bo_observer.data.catalog import export_sqlalchemy_metadata

if __name__ == "__main__":
    print(json.dumps(export_sqlalchemy_metadata(metadata, "repair")))
