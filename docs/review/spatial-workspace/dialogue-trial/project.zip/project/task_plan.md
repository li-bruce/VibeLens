# Repair trial implementation plan

## Objective and protected boundaries

Implement the explicitly confirmed simple Python repair-ticket flow in drive mode, with fixed test identities and SQLite + SQLAlchemy restart persistence. Only the submitter confirms; only the assigned technician records the result. Confirmation finishes the ticket. No rejection or rework.

All writes stay in this trial directory. Candidate repository and global skills are read-only. No agents, other chats, commits or publishing. This is simulated-user testing, not human testing.

## Phases

1. Clarification and same-source graph confirmation — complete (U2).
2. Independent expectations, change baseline, native executor and storage — complete.
3. Application UI, probes, complete source/data mappings and launch command — complete; inventory reconciliation in phase 4.
4. Business/state/mapping/isolation checks and change gate — complete for repair-evidence and later repair-runtime-owner; both later full baselines immutable. Initial manual amendment remains disclosed.
5. Browser recording/replay, source, 2D/3D and source-update acceptance — complete. Canonical two-file upgrade fixes duplicate rows; actual commit ownership, single row, both state highlights and default target selection passed real browser regression.
6. Raw dialogue preservation, evidence index and delivery — complete through the latest recorded cutoff; original failures and incorrect model retained, report/index and latest actual core ZIP prepared.

## Required evidence

Success and rejection; rejected operations preserve authoritative state; actual SQLite queries and commits/rollback; state/event/condition declaration equals executor and viewer; live recording/replay; exact formal parameter source ranges; optional code layer; layer drawer and spacing; same-layer coplanarity; camera-relative captions; geometry legend; stale source and obsolete recording behavior; observation on/off/fault/limited queue; runtime build identity and reproducible commands.

## Errors

Initial clarification failures F001–F004 are preserved in review/failures.jsonl. A later reference lookup for python-modes/bo_stategraph/workflow.py failed because that example uses driver.py; locate files before reading. No maintained source was changed.
