"""Portable observation entrypoint; independent execution is tracked under tooling/."""

from tooling.bo_observe import ROOT, CASES, independent_rows, run_case, run_suite
import json

if __name__ == "__main__":
    print(json.dumps(run_suite(), ensure_ascii=False))
