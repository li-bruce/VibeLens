"""Run the business core with its native declaration and a neutral observation port."""

import argparse
import hashlib
import json
from pathlib import Path
from app.domain import RepairService
from app.ports import NullObserver
from app.storage import Store

if __name__ == "__main__":
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--database", default="data/core.sqlite")
    parser.add_argument("--port", type=int, default=8898)
    args = parser.parse_args()
    project = json.loads((root / "bo_stategraph/project.json").read_text(encoding="utf-8"))
    core_files = sorted([*root.joinpath("app").glob("*.py"), *root.joinpath("bo_stategraph").glob("*.py")])
    build_id = hashlib.sha256(b"".join(path.read_bytes() for path in core_files) + json.dumps(project["model"]["machine"], sort_keys=True).encode()).hexdigest()
    store = Store(root / args.database)
    service = RepairService(store, project["model"]["machine"], NullObserver(), build_id)
    if args.self_test:
        row = service.submit("u1", "Core without observer")
        states = [row["state"]]
        states.append(service.claim(row["id"], "t1")["state"])
        states.append(service.record_result(row["id"], "t1", "Core repaired")["state"])
        states.append(service.confirm(row["id"], "u1")["state"])
        assert states == ["pending", "in_progress", "awaiting_confirmation", "completed"]
        print(json.dumps({"valid": True, "states": states, "observer_runtime_present": (root / "observer_runtime").exists(), "viewer_present": (root / "static/graph").exists()}))
        store.close()
    else:
        from app.server import create_app
        create_app(service, project["model"]).run(host="127.0.0.1", port=args.port, use_reloader=False)
