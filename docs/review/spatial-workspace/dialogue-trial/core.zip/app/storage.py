"""SQLite persistence with transactions and optimistic revision checks."""

from contextlib import contextmanager
from pathlib import Path
from threading import RLock
from sqlalchemy import create_engine, insert, select, update
from .models import metadata, tickets
from .ports import NullObserver


class Store:
    def __init__(self, path: Path, bo=None):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.engine = create_engine("sqlite:///" + self.path.as_posix(), connect_args={"timeout": 10})
        self.lock = RLock()
        self.bo = bo or NullObserver()
        metadata.create_all(self.engine)

    @contextmanager
    def transaction(self):
        with self.lock:
            with self.bo.transaction("db.transaction", self.engine.begin()) as connection:
                yield connection

    def list_tickets(self, connection=None) -> list:
        statement = select(tickets).order_by(tickets.c.id)
        if connection is None:
            with self.lock, self.engine.connect() as current:
                return self.list_tickets(current)
        return self.bo.execute("db.read", lambda: [dict(row) for row in connection.execute(statement).mappings()], connection=connection, statement=str(statement), language="sql", summarize=lambda rows: {"rows": len(rows), "result": {"count": len(rows)}})

    def get(self, connection, ticket_id: int) -> dict:
        statement = select(tickets).where(tickets.c.id == ticket_id)
        rows = self.bo.execute("db.read", lambda: [dict(row) for row in connection.execute(statement).mappings()], connection=connection, statement=str(statement), language="sql", summarize=lambda rows: {"rows": len(rows), "result": {"count": len(rows)}})
        if not rows:
            raise ValueError("ticket_not_found")
        return rows[0]

    def create(self, connection, values: dict) -> dict:
        statement = insert(tickets).values(**values)
        result = self.bo.execute("db.write", lambda: connection.execute(statement), connection=connection, statement=str(statement), language="sql", summarize=lambda result: {"rows": result.rowcount})
        return {"id": result.inserted_primary_key[0], **values}

    def update(self, connection, before: dict, after: dict) -> dict:
        statement = update(tickets).where(tickets.c.id == before["id"], tickets.c.revision == before["revision"]).values(**{key: value for key, value in after.items() if key != "id"})
        result = self.bo.execute("db.write", lambda: connection.execute(statement), connection=connection, statement=str(statement), language="sql", summarize=lambda result: {"rows": result.rowcount})
        if result.rowcount != 1:
            raise ValueError("revision_conflict")
        return after

    def close(self):
        self.engine.dispose()
