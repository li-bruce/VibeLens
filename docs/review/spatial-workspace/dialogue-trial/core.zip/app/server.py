"""Local Flask forms and JSON endpoints for the confirmed ticket flow."""

from pathlib import Path
from flask import Flask, jsonify, redirect, render_template, request, url_for
from .policy import IDENTITIES, identity
from bo_stategraph.query import bo_public_projection

web = Flask(__name__, template_folder=str(Path(__file__).resolve().parents[1] / "templates"))


def service():
    return web.config["REPAIR_SERVICE"]


def actor() -> str:
    value = (request.get_json(silent=True) or {}).get("actor_id") if request.is_json else request.values.get("actor_id", "u1")
    identity(value)
    return value


def reply(row):
    if request.is_json:
        return jsonify(row)
    return redirect(url_for("index", actor_id=actor()))


@web.get("/")
def index():
    current = actor()
    return service().bo.entry_html(render_template("index.html", actor_id=current, identities=IDENTITIES, tickets=service().list_tickets(), message=request.args.get("message", "")))


@web.get("/api/identities")
def identities():
    service().bo.record("repair.identities", "return", lambda: {"inputs": {}, "outputs": {"count": len(IDENTITIES)}})
    return jsonify(IDENTITIES)


@web.get("/api/tickets")
def ticket_list():
    return jsonify(service().list_tickets())


@web.post("/api/tickets")
@web.post("/tickets")
def submit():
    data = request.get_json() if request.is_json else request.form
    return reply(service().submit(actor(), data.get("content", "")))


@web.post("/api/tickets/<int:ticket_id>/claim")
@web.post("/tickets/<int:ticket_id>/claim")
def claim(ticket_id: int):
    return reply(service().claim(ticket_id, actor()))


@web.post("/api/tickets/<int:ticket_id>/result")
@web.post("/tickets/<int:ticket_id>/result")
def record_result(ticket_id: int):
    data = request.get_json() if request.is_json else request.form
    return reply(service().record_result(ticket_id, actor(), data.get("result", "")))


@web.post("/api/tickets/<int:ticket_id>/confirm")
@web.post("/tickets/<int:ticket_id>/confirm")
def confirm(ticket_id: int):
    return reply(service().confirm(ticket_id, actor()))


@web.errorhandler(ValueError)
def handle_error(error):
    if request.is_json or request.path.startswith("/api/"):
        return jsonify({"error": str(error)}), 409
    return redirect(url_for("index", actor_id=request.values.get("actor_id", "u1"), message="操作未完成：身份、单据状态或内容不符合要求。"))


@web.get("/api/stategraph")
def bo_stategraph_query():
    with service().store.lock:
        # This observer read deliberately bypasses instrumented business queries.
        from sqlalchemy import select
        from .models import tickets
        with service().store.engine.connect() as connection:
            rows = [dict(row) for row in connection.execute(select(tickets).order_by(tickets.c.id)).mappings()]
        journal = service().bo.journal()
        bases = service().bo.state_bases()
    return jsonify(bo_public_projection(web.config["BO_MODEL"], service().build_id, rows, journal, bases))


@web.get("/api/stategraph/health")
def bo_health():
    return jsonify({"project_id": "repair-20261025", "build_id": service().build_id, "mode": "drive"})


def create_app(repair_service, model: dict):
    web.config.update(REPAIR_SERVICE=repair_service, BO_MODEL=model)
    web.config["MAX_CONTENT_LENGTH"] = 8192
    return web
