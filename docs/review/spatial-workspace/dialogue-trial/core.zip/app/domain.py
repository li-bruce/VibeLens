"""Confirmed repair-ticket operations. Capture only observes actual values."""

from bo_stategraph.workflow import TicketFlow
from .policy import identity, normalize_text


class RepairService:
    def __init__(self, store, machine: dict, bo, build_id: str):
        self.store, self.bo, self.build_id = store, bo, build_id
        self.flow = TicketFlow(machine, bo)

    def submit(self, actor_id: str, content: str) -> dict:
        with self.store.lock, self.bo.call("repair.submit"):
            self.bo.record("repair.submit", "enter", lambda: {"inputs": {"actor_id": actor_id, "content_length": len(content)}, "outputs": {}})
            if identity(actor_id)["role"] != "user":
                raise ValueError("user_required")
            clean = self.bo.transform("db.normalize", normalize_text, content, before=lambda value: {"length": len(value)}, after=lambda value: {"length": len(value)})
            if not clean:
                raise ValueError("content_required")
            with self.store.transaction() as connection:
                row = self.store.create(connection, {"content": clean, "submitter_id": actor_id, "technician_id": "", "result": "", "state": self.flow.machine["initial"], "revision": 1})
            event_id = self.bo.record("repair.submit", "commit", lambda: {"inputs": {"actor_id": actor_id, "content_length": len(content)}, "outputs": {"ticket_id": row["id"], "state": row["state"], "revision": row["revision"]}}, entity="ticket:" + str(row["id"]), attempt="ticket:" + str(row["id"]), scope="attempt", revision=row["revision"])
            self.bo.publish(row, evidence_id=event_id)
            return row

    def claim(self, ticket_id: int, actor_id: str) -> dict:
        with self.store.lock, self.bo.call("repair.claim", "ticket:" + str(ticket_id)):
            self.bo.record("repair.claim", "enter", lambda: {"inputs": {"ticket_id": ticket_id, "actor_id": actor_id}, "outputs": {}})
            with self.store.transaction() as connection:
                before = self.store.get(connection, ticket_id)
                step = self.flow.step(before, "claim", actor_id)
                row = self.store.update(connection, before, {**before, "technician_id": actor_id, "state": step["state"], "revision": before["revision"] + 1})
            event_id = self.bo.record("repair.claim", "commit", lambda: {"inputs": {"ticket_id": ticket_id, "actor_id": actor_id}, "outputs": {"state": row["state"], "revision": row["revision"]}}, revision=row["revision"])
            self.bo.publish(row, "claim", step["guards"], event_id, step["payload"])
            return row

    def record_result(self, ticket_id: int, actor_id: str, result: str) -> dict:
        with self.store.lock, self.bo.call("repair.record_result", "ticket:" + str(ticket_id)):
            self.bo.record("repair.record_result", "enter", lambda: {"inputs": {"ticket_id": ticket_id, "actor_id": actor_id, "result_length": len(result)}, "outputs": {}})
            clean = self.bo.transform("db.normalize", normalize_text, result, before=lambda value: {"length": len(value)}, after=lambda value: {"length": len(value)})
            with self.store.transaction() as connection:
                before = self.store.get(connection, ticket_id)
                step = self.flow.step(before, "record_result", actor_id, len(clean))
                row = self.store.update(connection, before, {**before, "result": clean, "state": step["state"], "revision": before["revision"] + 1})
            event_id = self.bo.record("repair.record_result", "commit", lambda: {"inputs": {"ticket_id": ticket_id, "actor_id": actor_id, "result_length": len(result)}, "outputs": {"state": row["state"], "revision": row["revision"]}}, revision=row["revision"])
            self.bo.publish(row, "record_result", step["guards"], event_id, step["payload"])
            return row

    def confirm(self, ticket_id: int, actor_id: str) -> dict:
        with self.store.lock, self.bo.call("repair.confirm", "ticket:" + str(ticket_id)):
            self.bo.record("repair.confirm", "enter", lambda: {"inputs": {"ticket_id": ticket_id, "actor_id": actor_id}, "outputs": {}})
            with self.store.transaction() as connection:
                before = self.store.get(connection, ticket_id)
                step = self.flow.step(before, "confirm", actor_id)
                row = self.store.update(connection, before, {**before, "state": step["state"], "revision": before["revision"] + 1})
            event_id = self.bo.record("repair.confirm", "commit", lambda: {"inputs": {"ticket_id": ticket_id, "actor_id": actor_id}, "outputs": {"state": row["state"], "revision": row["revision"]}}, revision=row["revision"])
            self.bo.publish(row, "confirm", step["guards"], event_id, step["payload"])
            return row

    def list_tickets(self) -> list:
        with self.store.lock, self.bo.call("repair.list"):
            rows = self.store.list_tickets()
            self.bo.restore_rows(rows)
            self.bo.record("repair.list", "return", lambda: {"inputs": {}, "outputs": {"count": len(rows)}})
            return rows
