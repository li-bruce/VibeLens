"""Neutral optional observation port; business execution never requires a collector."""

from contextlib import nullcontext


class NullObserver:
    def call(self, node, entity="application"):
        return nullcontext()

    def record(self, node, phase, builder, **kwargs):
        return None

    def publish(self, row, event=None, guards=None, evidence_id=None, payload=None):
        return None

    def restore_rows(self, rows):
        return None

    def journal(self):
        return []

    def state_bases(self):
        return {}

    def entry_html(self, raw):
        return raw.replace("data-bo-entry", "data-bo-entry hidden")

    def execute(self, node, callback, **kwargs):
        return callback()

    def transaction(self, node, manager, **kwargs):
        return manager

    def transform(self, node, function, value, **kwargs):
        return function(value)

    def flush(self):
        return True

    def close(self):
        return None
