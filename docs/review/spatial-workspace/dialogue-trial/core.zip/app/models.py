"""Native SQLAlchemy metadata. Importing this file never connects or migrates."""

from sqlalchemy import CheckConstraint, Column, Integer, MetaData, String, Table, Text

metadata = MetaData()
tickets = Table(
    "tickets", metadata,
    Column("id", Integer, primary_key=True),
    Column("content", Text, nullable=False),
    Column("submitter_id", String(16), nullable=False),
    Column("technician_id", String(16), nullable=False),
    Column("result", Text, nullable=False),
    Column("state", String(32), nullable=False),
    Column("revision", Integer, nullable=False),
    CheckConstraint("state IN ('pending','in_progress','awaiting_confirmation','completed')", name="ticket_state"),
    CheckConstraint("revision >= 1", name="ticket_revision"),
    CheckConstraint("length(trim(content)) BETWEEN 1 AND 1000", name="ticket_content"),
    CheckConstraint("(state = 'pending' AND technician_id = '') OR (state <> 'pending' AND technician_id <> '')", name="ticket_assignment"),
    CheckConstraint("(state IN ('pending','in_progress') AND result = '') OR (state IN ('awaiting_confirmation','completed') AND length(trim(result)) > 0)", name="ticket_result"),
)
