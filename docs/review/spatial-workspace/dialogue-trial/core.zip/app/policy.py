"""Confirmed role and ownership guards for the fixed test identities."""

IDENTITIES = {
    "u1": {"role": "user", "label": "用户甲"},
    "u2": {"role": "user", "label": "用户乙"},
    "t1": {"role": "technician", "label": "维修员甲"},
    "t2": {"role": "technician", "label": "维修员乙"},
}


def identity(actor_id: str) -> dict:
    if actor_id not in IDENTITIES:
        raise ValueError("unknown_identity")
    return IDENTITIES[actor_id]


def is_technician(context: dict, payload: dict) -> bool:
    return identity(payload["actor_id"])["role"] == "technician"


def is_assignee(context: dict, payload: dict) -> bool:
    return context["technician_id"] == payload["actor_id"]


def is_submitter(context: dict, payload: dict) -> bool:
    return context["submitter_id"] == payload["actor_id"]


def has_result(context: dict, payload: dict) -> bool:
    return payload["result_length"] > 0


def normalize_text(value: str) -> str:
    if not isinstance(value, str):
        raise ValueError("text_required")
    clean = value.strip()
    if len(clean) > 1000:
        raise ValueError("text_too_long")
    return clean
