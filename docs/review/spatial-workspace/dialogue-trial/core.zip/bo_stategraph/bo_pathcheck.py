"""Validate retained actual path witnesses; never generate a path from final state."""


def bo_path_report(machine: dict, configurations: list, journal: list, bases: dict) -> dict:
    reports = []
    for configuration in configurations:
        ident = configuration["attempt"]
        base = bases.get(ident)
        gaps = []
        observed = sorted((entry for entry in journal if entry["attempt"] == ident), key=lambda entry: entry["revision"])
        if base is None:
            reports.append({"instance_id": ident, "status": "not_observed", "transitions": len(observed), "gaps": ["No initial actual state witness; final storage state is not a path"]})
            continue
        state, revision = base["state"], base["revision"]
        if revision != 1 or state != machine["initial"]:
            gaps.append("Earlier history before the first actual state witness is unknown")
        for entry in observed:
            if entry["revision"] != revision + 1:
                gaps.append("Missing or duplicate transition witness before revision " + str(entry["revision"]))
            if entry["source"] != state:
                gaps.append("Transition source differs from preceding actual state")
            candidates = [transition for transition in machine["transitions"] if transition["trigger"] == entry["event"] and transition["source"] == entry["source"] and transition["dest"] == entry["target"]]
            if len(candidates) != 1:
                gaps.append("Actual transition has no unique declaration binding")
            else:
                declared = candidates[0]
                for guard in declared.get("conditions", []):
                    if entry.get("guards", {}).get(guard) is not True:
                        gaps.append("Missing or false evaluated condition: " + guard)
                for guard in declared.get("unless", []):
                    if entry.get("guards", {}).get(guard) is not False:
                        gaps.append("Missing or true evaluated exclusion: " + guard)
            if not entry.get("evidence_id"):
                gaps.append("Transition has no actual event identity")
            state, revision = entry["target"], entry["revision"]
        if state != configuration["phase"] or revision != configuration["state_revision"]:
            gaps.append("Final actual state/revision has no complete transition chain")
        reports.append({"instance_id": ident, "status": "partial" if gaps else "complete", "transitions": len(observed), "gaps": gaps, "first_actual_revision": base["revision"], "final_actual_revision": configuration["state_revision"]})
    return {"status": "complete" if all(item["status"] == "complete" for item in reports) else "partial", "instances": reports, "basis": "Retained actual commit event/state/guard witnesses; declaration is used only for validation"}
