"""The real executor consumes model.machine from the canonical project document."""

from functools import partial
from .bo_executor import BOExecutor
from app import policy

GUARDS = {"is_technician": policy.is_technician, "is_assignee": policy.is_assignee, "is_submitter": policy.is_submitter, "has_result": policy.has_result}


def ticket_context(row: dict) -> dict:
    return {"submitter_id": row["submitter_id"], "technician_id": row["technician_id"], "result_length": len(row["result"])}


class TicketFlow:
    def __init__(self, machine: dict, bo):
        self.bo = bo
        self.machine = machine
        self.executor = BOExecutor(machine, {name: partial(self.evaluate_guard, name, function) for name, function in GUARDS.items()})

    def evaluate_guard(self, name: str, function, context: dict, payload: dict) -> bool:
        result = function(context, payload)
        self.bo.record("guard." + name, "decision", lambda: {"inputs": {"actor_id": payload["actor_id"], **context, "requested_result_length": payload.get("result_length", 0)}, "outputs": {"allowed": result}})
        return result

    def step(self, row: dict, event: str, actor_id: str, result_length: int = 0) -> dict:
        payload = {"actor_id": actor_id}
        if event == "record_result":
            payload["result_length"] = result_length
        with self.bo.call("flow.step"):
            result = self.executor.step(row["state"], event, ticket_context(row), payload)
            self.bo.record("flow.step", "return", lambda: {"inputs": {"event": event, "actor_id": actor_id, "result_length": result_length, "before_state": row["state"]}, "outputs": {"state": result["state"]}})
            return result
