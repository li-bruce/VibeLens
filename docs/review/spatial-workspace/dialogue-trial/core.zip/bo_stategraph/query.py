"""Read-only actual-storage projection shared by application API and acceptance."""

from . import BOStateGraph
from .workflow import ticket_context
from copy import deepcopy
from .bo_pathcheck import bo_path_report


def bo_machine_snapshot(rows: list, build_id: str, journal=(), bases=None) -> dict:
    configurations = [{"attempt": "ticket:" + str(row["id"]), "phase": row["state"], "state_revision": row["revision"], "revision": row["revision"], "param_version": row["revision"], "run_build_id": build_id, "source_status": "current", "context": ticket_context(row), "activities": {}, "resources": {}, "journal": []} for row in rows]
    by_attempt = {configuration["attempt"]: configuration for configuration in configurations}
    retained = [deepcopy(entry) for entry in journal if entry.get("attempt") in by_attempt and entry.get("build_id") == build_id and entry.get("revision", -1) <= by_attempt[entry["attempt"]]["state_revision"]]
    for configuration in configurations:
        configuration["journal"] = [deepcopy(entry) for entry in retained if entry["attempt"] == configuration["attempt"]]
    return {"configurations": configurations, "current": rows[-1]["state"] if rows else None, "journal": retained, "journal_coverage": "retained actual commit publications only; prior process paths are unknown"}


def bo_public_projection(model: dict, build_id: str, rows: list, journal=(), bases=None) -> dict:
    machine = bo_machine_snapshot(rows, build_id, journal, bases)
    machine["path_evidence"] = bo_path_report(model["machine"], machine["configurations"], machine["journal"], bases or {})
    graph = BOStateGraph(model, build_id=build_id, mode="drive")
    return {"build_id": build_id, "machine": machine, "instances": graph.bo_instances(machine), "stategraph_export": graph.bo_export(runtime={"machine": machine})}
