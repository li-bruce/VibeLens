"""Author explicit import ownership and core resources without changing business rules."""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
core = ["app", "bo_stategraph/__init__.py", "bo_stategraph/bo_contracts.py", "bo_stategraph/execution_contract.py", "bo_stategraph/bo_executor.py", "bo_stategraph/workflow.py", "bo_stategraph/query.py", "bo_stategraph/project.json", "bo_core_run.py", "templates", "requirements.txt"]
core.append("bo_stategraph/bo_pathcheck.py")
config = {"scan": ["app", "bo_stategraph/__init__.py", "bo_stategraph/bo_contracts.py", "bo_stategraph/execution_contract.py", "bo_stategraph/bo_executor.py", "bo_stategraph/workflow.py", "bo_stategraph/query.py", "integrations", "run.py", "bo_core_run.py", "templates"], "layers": {"business": {"paths": ["app", "templates"], "allows": ["business", "state", "port"], "reject_dynamic": True}, "port": {"paths": ["app/ports.py"], "allows": ["port"], "reject_dynamic": True}, "state": {"paths": ["bo_stategraph"], "allows": ["state", "business", "port"], "reject_dynamic": True}, "observer": {"paths": ["integrations", "run.py"], "allows": ["observer", "business", "state", "port"]}, "launcher": {"paths": ["bo_core_run.py"], "allows": ["launcher", "business", "state", "port"]}}, "core_include": core, "core_exclude": ["**/__pycache__/**", "**/*.pyc"], "core_layers": ["business", "state", "port", "launcher"], "core_resources": ["requirements.txt", "bo_stategraph/project.json"], "managed_paths": [], "managed_hashes": {}, "vendor_files": {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in ["bo_stategraph/__init__.py", "bo_stategraph/bo_contracts.py", "bo_stategraph/execution_contract.py", "bo_stategraph/bo_executor.py"]}}
config["scan"].append("bo_stategraph/bo_pathcheck.py")
(ROOT / "ownership.json").write_text(json.dumps(config, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print("Prepared explicit architecture and observer-free core allowlist.")
