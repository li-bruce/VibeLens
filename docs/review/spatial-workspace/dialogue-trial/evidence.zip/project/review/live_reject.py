"""Check rejected real HTTP operations against independent read-only SQLite state."""

import argparse
import json
from pathlib import Path
import sqlite3
from urllib.request import Request, urlopen
from urllib.error import HTTPError

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("case", choices=["wrong_role", "wrong_order", "wrong_technician", "wrong_submitter", "completed_terminal"])
parser.add_argument("--id", type=int, default=2)
args = parser.parse_args()
def rows():
    with sqlite3.connect("file:" + (ROOT / "data/repair.sqlite").as_posix() + "?mode=ro", uri=True) as connection:
        connection.row_factory = sqlite3.Row
        return [dict(row) for row in connection.execute("SELECT * FROM tickets ORDER BY id")]
before = rows()
action, actor_id = {"wrong_role": ("claim", "u2"), "wrong_order": ("result", "t1"), "wrong_technician": ("result", "t2"), "wrong_submitter": ("confirm", "u2"), "completed_terminal": ("confirm", "u1")}[args.case]
body = {"actor_id": actor_id, **({"result": "Deliberate rejected test"} if action == "result" else {})}
request = Request(f"http://127.0.0.1:8898/api/tickets/{args.id}/{action}", data=json.dumps(body).encode(), headers={"Content-Type": "application/json"}, method="POST")
try:
    with urlopen(request, timeout=8) as response:
        status, result = response.status, json.loads(response.read())
except HTTPError as error:
    status, result = error.code, json.loads(error.read())
after = rows()
assert status == 409 and before == after, (status, result, before, after)
artifact = {"case": args.case, "url": request.full_url, "status": status, "body": body, "response": result, "before": before, "after": after, "unchanged": before == after}
(ROOT / "review" / ("live-reject-" + args.case + ".json")).write_text(json.dumps(artifact, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps({"case": args.case, "status": status, "unchanged": True}))
