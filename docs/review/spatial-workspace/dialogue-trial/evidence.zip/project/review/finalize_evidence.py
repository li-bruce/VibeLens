"""Archive this chat only, append trial findings, and index local evidence."""
import hashlib
import json
from pathlib import Path
from datetime import datetime, timezone
ROOT=Path(__file__).resolve().parents[1]
REVIEW=ROOT/'review'
thread='01a1713d-d460-7353-9d3f-58c351e70704'
source=Path(r'C:\Users\Lvi_P\.codex\sessions\2026\10\25')/f'rollout-2026-10-25T12-07-19-{thread}.jsonl'
raw=source.read_bytes()
first=json.loads(raw.splitlines()[0])
assert first['type']=='session_meta' and first['payload']['id']==thread
(REVIEW/'raw-session.jsonl').write_bytes(raw)
messages=[]
for line in raw.splitlines():
    item=json.loads(line)
    payload=item.get('payload',{})
    if item.get('type')!='response_item' or payload.get('type')!='message' or payload.get('role') not in {'user','assistant'}:continue
    text='\n'.join(c['text'] for c in payload.get('content',[]) if c.get('type') in {'input_text','output_text'} and isinstance(c.get('text'),str))
    if text:messages.append({'timestamp':item.get('timestamp'),'role':payload['role'],'channel':payload.get('channel'),'text':text})
(REVIEW/'raw-dialogue-extract.json').write_text(json.dumps(messages,ensure_ascii=False,indent=2),encoding='utf-8')
metadata={'thread_id':thread,'source':str(source),'snapshot_at_utc':datetime.now(timezone.utc).isoformat(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'messages':len(messages),'scope':'This chat only; exact JSONL bytes through this snapshot cutoff; later tool results and final response are not included','privacy':'Private local trial evidence; not published'}
(REVIEW/'raw-session-metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf-8')
initial=json.loads((REVIEW/'candidate-baseline.json').read_text(encoding='utf-8-sig'))
candidate=Path(initial['path'])
current={p.relative_to(candidate).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in candidate.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
old=initial['files']
delta={'reference':str(candidate),'old_files':len(old),'current_files':len(current),'changed':[p for p in old.keys()&current.keys() if old[p]!=current[p]],'added':sorted(current.keys()-old.keys()),'removed':sorted(old.keys()-current.keys()),'note':'Read-only comparison. The test initiator independently updates the candidate repository; deltas do not imply trial-authored changes.','files':current}
(REVIEW/'candidate-final-inventory.json').write_text(json.dumps(delta,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({**metadata,'candidate_changed':delta['changed']},ensure_ascii=False))
