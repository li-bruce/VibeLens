"""Derive source/data projections around the one canonical executable declaration."""

import json
import os
from pathlib import Path
import bo_environment
from app.storage import Store
from code_structure import scan, enrich
from bo_observer.data.sync import synchronize
from bo_observer.observation.observation_scope import endpoint_paths

ROOT = Path(__file__).resolve().parents[1]


def write(name, value):
    path = ROOT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = json.dumps(value, ensure_ascii=False, indent=2) + "\n"
    if not path.exists() or path.read_text(encoding="utf-8") != raw:
        path.write_text(raw, encoding="utf-8")


def machine():
    path = ROOT / "bo_stategraph/project.json"
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))["model"]["machine"]
    states = ["pending", "in_progress", "awaiting_confirmation", "completed"]
    return {"engine": "bo.fsm", "version": "1", "states": states, "values": states, "initial": "pending", "state_type": "enum", "labels": {"pending": "待接单", "in_progress": "处理中", "awaiting_confirmation": "待用户确认", "completed": "已完成"}, "context": {"submitter_id": {"type": "string"}, "technician_id": {"type": "string"}, "result_length": {"type": "integer", "min": 0}}, "events": {"claim": {"payload": {"actor_id": {"type": "string"}}}, "record_result": {"payload": {"actor_id": {"type": "string"}, "result_length": {"type": "integer", "min": 0}}}, "confirm": {"payload": {"actor_id": {"type": "string"}}}}, "guards": {"is_technician": "当前身份是维修员", "is_assignee": "当前身份是接单维修员", "has_result": "处理结果非空", "is_submitter": "当前身份是提交人"}, "transitions": [{"trigger": "claim", "source": "pending", "dest": "in_progress", "conditions": ["is_technician"]}, {"trigger": "record_result", "source": "in_progress", "dest": "awaiting_confirmation", "conditions": ["is_technician", "is_assignee", "has_result"]}, {"trigger": "confirm", "source": "awaiting_confirmation", "dest": "completed", "conditions": ["is_submitter"]}]}


def build():
    cfg = json.loads((ROOT / "sync.json").read_text(encoding="utf-8"))
    cfg["code_files"] = ["app/__init__.py", "app/domain.py", "app/models.py", "app/storage.py", "app/policy.py", "app/server.py", "app/ports.py", "bo_stategraph/workflow.py", "bo_stategraph/query.py", "bo_stategraph/bo_pathcheck.py", "integrations/__init__.py", "integrations/bo_adapter.py", "integrations/bo_serve.py"]
    cfg["model"] = "bo_stategraph/project.json"
    cfg["watch_files"] = sorted(set(cfg["watch_files"] + ["tests/test_spatial_math.py", "ownership.json", "bo_core_run.py", "tests/test_engineering.py", "tests/test_evidence.py", "tooling/__init__.py", "tooling/bo_build.py", "tooling/bo_observe.py", "bo_environment.py", "export_model.py", "validate.py", "bo_stategraph/bo_executor.py", "templates/index.html", "requirements.txt", "AGENTS.md"]))
    evidence_command = ["{python}", "-B", "tests/test_evidence.py"]
    if evidence_command not in cfg["test_commands"]:
        cfg["test_commands"].append(evidence_command)
    engineering_command = ["{python}", "-B", "tests/test_engineering.py"]
    if engineering_command not in cfg["test_commands"]:
        cfg["test_commands"].append(engineering_command)
    spatial_command = ["{python}", "-B", "tests/test_spatial_math.py"]
    if spatial_command not in cfg["test_commands"]:
        cfg["test_commands"].append(spatial_command)
    cfg["source_scope"]["exclude"].update({"bo_core_run.py": "Tracked standalone core launcher; actual business methods remain indexed under app/", "tooling/**": "Tracked graph generator and independent scenario/check utilities; these are not application endpoints", "bo_environment.py": "Tracked local runtime import-path setup", "export_model.py": "Tracked offline native metadata exporter", "validate.py": "Tracked normal verification entrypoint"})
    write("sync.json", cfg)
    index = scan(ROOT, cfg["code_files"])
    if index["errors"]:
        raise ValueError(index["errors"])
    declaration = machine()
    nodes, edges = [], []
    def node(ident, kind, label, source=None, parent=None, capture=None, **extra):
        item = {"id": ident, "kind": kind, "label": label, "summary": label, "capture": capture or {"in": {}, "out": {}}, **extra}
        if source:
            path, symbol = source.split("::")
            item["source"] = {"path": path, "symbol": symbol}
        if parent:
            item["parent"] = parent
        nodes.append(item)
        return item
    def edge(ident, start, end, kind="flow", label="", **extra):
        edges.append({"id": ident, "from": start, "to": end, "type": kind, "label": label, "evidence": "Confirmed U0/U1/U2, canonical machine or explicit source binding", **extra})
    business = [("submit", "用户提交报修内容", "submit"), ("claim", "维修员接单", "claim"), ("record_result", "登记处理结果", "record_result"), ("confirm", "提交人确认完成", "confirm"), ("list", "查看报修记录", "list_tickets"), ("identities", "固定测试身份", None)]
    captures = {
        "submit": {"in": {"actor_id": "string", "content_length": "number"}, "out": {"ticket_id": "number", "state": "string", "revision": "number", "error_type": "string"}},
        "claim": {"in": {"ticket_id": "number", "actor_id": "string"}, "out": {"state": "string", "revision": "number", "error_type": "string"}},
        "record_result": {"in": {"ticket_id": "number", "actor_id": "string", "result_length": "number"}, "out": {"state": "string", "revision": "number", "error_type": "string"}},
        "confirm": {"in": {"ticket_id": "number", "actor_id": "string"}, "out": {"state": "string", "revision": "number", "error_type": "string"}},
        "list": {"in": {}, "out": {"count": "number", "ticket_id": "number", "state": "string", "revision": "number"}},
        "identities": {"in": {}, "out": {"count": "number"}},
    }
    for key, label, symbol in business:
        source = "app/domain.py::RepairService." + symbol if symbol else "app/server.py::identities"
        node("repair." + key, "action", label, source, capture=captures[key], layer="business", requirements=["R1" if key == "submit" else "R2" if key == "claim" else "R3" if key == "record_result" else "R4" if key == "confirm" else "R6"])
    state_ids = {value: "repair." + value for value in declaration["values"]}
    for value in declaration["values"]:
        node(state_ids[value], "state", declaration["labels"][value], layer="state", value=value)
    original = json.loads((ROOT / "discovery.json").read_text(encoding="utf-8"))
    for link in original["networks"][0]["edges"]:
        edge(link["id"], link["from"], link["to"], link["relation"], link["label"])
    for number, transition in enumerate(declaration["transitions"]):
        edge("machine.transition." + str(number), state_ids[transition["source"]], state_ids[transition["dest"]], "flow", transition["trigger"], event=transition["trigger"], conditions=transition.get("conditions", []))
    guard_parents = {"is_technician": "repair.claim", "is_assignee": "repair.record_result", "has_result": "repair.record_result", "is_submitter": "repair.confirm"}
    for name, label in declaration["guards"].items():
        node("guard." + name, "decision", label, "app/policy.py::" + name, guard_parents[name], {"in": {"actor_id": "string", "submitter_id": "string", "technician_id": "string", "result_length": "number", "requested_result_length": "number"}, "out": {"allowed": "boolean"}}, semantic_roles=["authorization"] if name != "has_result" else [])
        edge("guard.binding." + name, "guard." + name, guard_parents[name], "guard", label)
    node("flow.step", "function", "执行声明中的状态迁移", "bo_stategraph/workflow.py::TicketFlow.step", "repair.claim", {"in": {"event": "string", "actor_id": "string", "result_length": "number", "before_state": "string"}, "out": {"state": "string"}})
    support_bindings = {
        "app/domain.py::RepairService.__init__": "repair.submit",
        "app/storage.py::Store.__init__": "repair.submit",
        "app/storage.py::Store.transaction": "repair.submit",
        "app/storage.py::Store.list_tickets": "repair.list",
        "app/storage.py::Store.get": "repair.claim",
        "app/storage.py::Store.create": "repair.submit",
        "app/storage.py::Store.update": "repair.claim",
        "app/storage.py::Store.close": "repair.list",
        "app/policy.py::identity": "repair.identities",
        "app/policy.py::normalize_text": "repair.submit",
        "bo_stategraph/workflow.py::TicketFlow.__init__": "repair.claim",
        "bo_stategraph/workflow.py::ticket_context": "repair.submit",
        "bo_stategraph/workflow.py::TicketFlow.evaluate_guard": "repair.claim",
        "app/server.py::service": "repair.list",
        "app/server.py::actor": "repair.identities",
        "app/server.py::reply": "repair.submit",
        "app/server.py::handle_error": "repair.submit",
        "app/server.py::create_app": "repair.list",
    }
    support = {}
    for sid, parent in support_bindings.items():
        ident = "support." + sid.replace("/", ".").replace("::", ".")
        node(ident, "function", sid.split("::")[1], sid, parent)
        support[sid] = {"node": ident, "reason": "Explicit implementation helper of " + parent}
    for name in declaration["guards"]:
        support["app/policy.py::" + name] = {"node": "guard." + name, "reason": "Native executor invokes this exact guard; actual evaluations are captured after the call"}
    support["bo_stategraph/workflow.py::TicketFlow.step"] = {"node": "flow.step", "reason": "Actual declared executor, captured return linked to domain operations"}
    features = []
    route_names = {"submit": ["submit"], "claim": ["claim"], "record_result": ["record_result"], "confirm": ["confirm"], "list": ["index", "ticket_list"], "identities": ["identities"]}
    error_cases = {"submit": ["empty_content"], "claim": ["wrong_role"], "record_result": ["wrong_technician", "wrong_order", "empty_result"], "confirm": ["wrong_submitter", "completed_terminal"]}
    entry_nodes = {n.get("source", {}).get("path", "") + "::" + n.get("source", {}).get("symbol", ""): n["id"] for n in nodes if n.get("source")}
    for key, label, symbol in business:
        sources = (["app/domain.py::RepairService." + symbol] if symbol else []) + ["app/server.py::" + name for name in route_names[key]]
        owned = ["repair." + key]
        if key == "claim":
            owned += ["guard.is_technician", "flow.step"]
        if key == "record_result":
            owned += ["guard.is_assignee", "guard.has_result"]
        if key == "confirm":
            owned += ["guard.is_submitter"]
        if key == "submit":
            owned += ["db.read", "db.write", "db.transaction", "db.normalize"]
        parameters = []
        for sid in sources:
            if sid not in entry_nodes:
                ident = "entry." + sid.split("::")[1]
                node(ident, "function", sid.split("::")[1], sid, "repair." + key)
                entry_nodes[sid] = ident
            for parameter in index["symbols"][sid]["parameters"]:
                name = parameter["name"]
                if name in {"self", "cls"}:
                    continue
                field = name + "_length" if name in {"content", "result"} else name
                policy = "derived" if field != name else "value"
                parameters.append({"source": sid, "name": name, "node": "repair." + key, "direction": "in", "field": field, "policy": policy, **({"reason": "Capture text length only; ticket bodies stay in SQLite"} if policy == "derived" else {})})
        cases = [{"case": "normal", "node": "repair." + key, "phase": "return" if key in {"list", "identities"} else "commit"}]
        witness_key = {"submit": "submitted", "claim": "claimed", "record_result": "recorded", "confirm": "confirmed"}.get(key)
        if witness_key:
            inputs = list(captures[key]["in"])
            outputs = [name for name in captures[key]["out"] if name != "error_type"]
            cases.append({"case": "normal", "node": "repair." + key, "phase": "commit", "values": [{"direction": direction, "field": field, "path": [witness_key, field]} for direction, fields in [("in", inputs), ("out", outputs)] for field in fields]})
        cases += [{"case": case, "node": "repair." + key, "phase": "error"} for case in error_cases.get(key, [])]
        if key == "list":
            cases.append({"case": "restart", "node": "repair.list", "phase": "read"})
        for name in owned:
            if name.startswith("guard."):
                cases.append({"case": "normal", "node": name, "phase": "decision"})
            if name == "flow.step":
                cases.append({"case": "normal", "node": name, "phase": "return"})
        if key == "submit":
            cases += [{"case": "normal", "node": nid, "phase": phase} for nid, phase in [("db.read", "return"), ("db.write", "return"), ("db.transaction", "commit"), ("db.normalize", "change")]]
        features.append({"id": key, "label": label, "business_node": "repair." + key, "nodes": owned, "sources": sources, "parameters": parameters, "cases": cases})
    excluded = {}
    classified = set(support) | {sid for feature in features for sid in feature["sources"]}
    for sid, symbol in index["symbols"].items():
        if symbol["kind"] != "function" or sid in classified:
            continue
        if symbol["path"] in {"app/ports.py", "integrations/bo_adapter.py", "integrations/bo_serve.py", "bo_stategraph/query.py", "bo_stategraph/bo_pathcheck.py"} or symbol["symbol"] in {"bo_stategraph_query", "bo_health"}:
            item = {"category": "observer", "reason": "Exact read-only observation adapter or diagnostic endpoint; no business writes or events"}
            if symbol.get("entrypoints"):
                item["routes"] = endpoint_paths(symbol)
            excluded[sid] = item
        else:
            raise ValueError("Unclassified implementation: " + sid)
    for item in list(nodes):
        if item.get("parent"):
            edge("contains." + item["id"], item["parent"], item["id"], "contains")
    model = {"schema_version": 3, "project_id": "repair-20261025", "revision": "1", "intent": "intent.json", "source_files": sorted(set(cfg["code_files"] + cfg["watch_files"] + ["sync.json", "discovery.json", "intent.json", "acceptance.json", "mapping.json", "whitebox.json", "bo_stategraph/bo_contracts.py", "bo_stategraph/execution_contract.py", "bo_stategraph/runtime-version.json"])), "nodes": nodes, "edges": edges, "machine": declaration, "overview": [{"node": "repair." + key} for key in ["submit", "claim", "record_result", "confirm"]], "graph_roots": ["repair." + key for key, _, _ in business] + list(state_ids.values()), "presentation": {"subject": "报修单（模拟用户测试）", "runtime_owner": "repair.submit", "context_fields": list(declaration["context"]), "states": declaration["labels"]}, "scope": {"unknowns": ["Fixed local test identities without authentication", "Static dynamic calls are candidates; runtime evidence covers the named scenarios only", "No distributed worker or multi-process fairness claim"]}, "implementation": {"schema": "bo-implementation/v1", "features": features, "support": support, "excluded": excluded}}
    model = enrich(model, index, cfg["slice_depth"])
    project = {"protocol": "bo-project/v1", "project_id": "repair-20261025", "selection": {"mode": "drive", "source": "user", "answer": "drive", "locator": "review/conversation.jsonl#U1; simulated-user answer"}, "model": model}
    write("bo_stategraph/project.json", project)
    operations = []
    for ident, action, symbol, targets, before, after in [("db.read", "read", "Store.get", ["table:tickets"], {}, {"count": "number"}), ("db.write", "write", "Store.update", ["table:tickets"], {}, {}), ("db.transaction", "transaction", "Store.transaction", [], {}, {}), ("db.normalize", "transform", "normalize_text", [], {"length": "number"}, {"length": "number"})]:
        operations.append({"id": ident, "label": {"db.read": "读取报修单", "db.write": "写入报修单", "db.transaction": "事务提交与回滚", "db.normalize": "整理输入文本"}[ident], "parent": "repair.submit", "source": {"path": "app/policy.py" if action == "transform" else "app/storage.py", "symbol": symbol}, "store": "repair", "action": action, "targets": targets, "parameters": {}, "before": before, "after": after, "requirements": ["R5"], "required_cases": ["normal", "rollback"] if action == "transaction" else ["normal"], **({"failure_cases": ["rollback"]} if action == "transaction" else {})})
    write("bo_stategraph/databases.json", {"protocol": "bo-databases/v1", "stores": [{"id": "repair", "label": "本地报修单 SQLite", "engine": "sqlalchemy", "url_env": "REPAIR_DATABASE_URL", "parent": "repair.submit", "selection": {"source": "user", "answer": "SQLite + SQLAlchemy，重启后保留。", "locator": "review/conversation.jsonl#U1; simulated-user answer"}, "model_layer": "SQLAlchemy Core", "source_files": ["app/models.py", "export_model.py"], "declaration": "bo_stategraph/declaration.json"}], "operations": operations, "exporters": [{"store": "repair", "command": ["{python}", "-B", "export_model.py"], "output": "bo_stategraph/declaration.json"}]})
    Store(ROOT / "data/repair.sqlite").close()
    os.environ.setdefault("REPAIR_DATABASE_URL", "sqlite:///" + (ROOT / "data/repair.sqlite").as_posix())
    result = synchronize(ROOT, model_path="bo_stategraph/project.json")
    if not result["valid"]:
        raise ValueError(result)
    current = json.loads((ROOT / "bo_stategraph/project.json").read_text(encoding="utf-8"))["model"]
    current = enrich(current, index, cfg["slice_depth"])
    project["model"] = current
    write("bo_stategraph/project.json", project)
    write("behavior.json", current)
    print(json.dumps({"valid": True, "nodes": len(current["nodes"]), "edges": len(current["edges"]), "functions": sum(s["kind"] == "function" for s in index["symbols"].values()), "database": result["valid"]}))


if __name__ == "__main__":
    build()
