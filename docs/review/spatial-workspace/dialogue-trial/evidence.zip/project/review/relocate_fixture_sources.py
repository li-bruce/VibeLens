"""Relocate executable negative-test copies into the scanner's dedicated isolation root."""

import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / "review/engineering").resolve()
target = (ROOT / ".validation/archived-engineering").resolve()
assert source.is_relative_to(ROOT) and target.is_relative_to(ROOT)
assert source != ROOT and target != ROOT and not target.exists()
target.parent.mkdir(parents=True, exist_ok=True)
shutil.move(str(source), str(target))
source.mkdir()
(source / "README.md").write_text("# Preserved isolated engineering fixtures\n\nExecutable copies were moved intact to `.validation/archived-engineering/`. Historical results retain their original paths; replace the prefix `review/engineering/` with `.validation/archived-engineering/` when reproducing them. No source, result or original expectation was deleted. New fixtures use `.validation/engineering/`. This prevents negative-test endpoints from being mistaken for hidden production endpoints by the independent source scan.\n", encoding="utf-8")
(ROOT / "review/engineering-relocation.json").write_text(json.dumps({"source": str(source), "target": str(target), "source_preserved_intact": True, "reason": "Dedicated .validation is the tool's explicit isolated-copy boundary; review exclusions must not conceal application endpoints"}, indent=2), encoding="utf-8")
print("Moved preserved executable test copies into the dedicated isolation directory.")
