# Preserved isolated engineering fixtures

Executable copies were moved intact to `.validation/archived-engineering/`. Historical results retain their original paths; replace the prefix `review/engineering/` with `.validation/archived-engineering/` when reproducing them. No source, result or original expectation was deleted. New fixtures use `.validation/engineering/`. This prevents negative-test endpoints from being mistaken for hidden production endpoints by the independent source scan.
