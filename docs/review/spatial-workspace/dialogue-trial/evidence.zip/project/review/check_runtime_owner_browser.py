"""Read-only verification of actual CUA-captured upgraded replay rows and highlights."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def read(name):return json.loads((ROOT/name).read_text(encoding='utf-8-sig'))
record=read('review/recording-runtime-owner.json')
proof=read('review/runtime-owner-replay-proof.json')
nodes={n['id']:n for n in record['context']['model']['nodes']}
events={e['id']:e for e in record['events']}
frames={f['event_id']:f for f in record['runtime_frames']['frames']}
names=['repair.submit','repair.claim','repair.record_result','repair.confirm']
states=['pending','in_progress','awaiting_confirmation','completed']
summary=[]
for index,(step,name,state) in enumerate(zip(proof,names,states)):
    assert len(step['rows'])==1
    row=step['rows'][0];data=row['dataset'];event=events[data['eventId']]
    assert event['node']==name and event['phase']=='commit'
    assert data['attempt']=='ticket:5' and data['kind']=='business'
    assert nodes[name]['label'] in row['text']
    assert frames[event['id']]['machine']['current']==state
    owners=json.loads(data['owners'])
    expected=['repair.'+states[index-1],'repair.'+state] if index else ['repair.'+state]
    assert set(owners)==set(expected)
    assert data['owner']=='repair.'+state
    assert {n['id'] for n in step['highlights']}==set(expected)
    for highlighted in step['highlights']:
        assert len(highlighted['changes'])==1
        assert highlighted['changes'][0]['after']==state
    summary.append({'event':event['id'],'actual_node':name,'source_label':nodes[name]['label'],'rows':1,'visual_owners':owners})
clicked=read('review/runtime-owner-click-target.json')['targetState']
assert clicked['dataset']['nodeId']=='repair.completed' and clicked['ariaPressed']=='true' and clicked['dataset']['emphasis']=='selected'
assert read('review/replay-original-installed-before.json')['rowsPerCommit']==[1,2,2,2]
assert read('review/replay-original-installed-after.json')['rowsPerCommit']==[1,1,1,1]
before=read('review/runtime-owner-before/project.json')['model']
after=read('bo_stategraph/project.json')['model']
assert before['machine']==after['machine']
assert before['presentation']['runtime_owner']=='repair.submit' and 'runtime_owner' not in after['presentation']
assert (ROOT/'.stategraph/repair-runtime-owner/baseline.json').read_bytes()==(ROOT/'review/repair-runtime-owner-baseline-begin.json').read_bytes()
assert read('review/upgrade-replay-applied.json')['changes']==['static/graph/replay-steps.js','static/graph/viewer.js']
result={'valid':True,'recording':record['id'],'build':record['build_id'],'steps':summary,'actual_target_selection':'repair.completed','original_failure_retained':True,'original_record_before_rows':[1,2,2,2],'original_record_upgraded_rows':[1,1,1,1],'machine_unchanged':True,'full_baseline_bytes_unchanged':True}
(ROOT/'review/runtime-owner-browser-check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'valid':True,'actual_source_nodes':names,'rows_per_commit':[1,1,1,1],'both_state_highlights':'checked','default_target_selection':'checked','machine_unchanged':True,'baseline_bytes_unchanged':True}))
