# Business network draft

```mermaid
flowchart LR
  n0["待用户确认"]
  n1["维修员接单"]
  n2["已完成"]
  n3["提交人确认完成"]
  n4["处理中"]
  n5["待接单"]
  n6["接单维修员登记处理结果"]
  n7["用户提交报修内容"]
  n5 -->|"维修员身份；单据待接单"| n1
  n0 -->|"仅该单提交人"| n3
  n4 -->|"仅接单维修员"| n6
  n1 -->|"登记接单维修员"| n4
  n3 -->|"确认完成"| n2
  n6 -->|"保存处理结果"| n0
  n7 -->|"保存报修单"| n5
```

[Open the live graph](http://127.0.0.1:8899/graph)

Still to confirm:

- 请确认图中的流程和权限是否符合你的意思；确认后我再实现。

Confirm this understanding in the conversation, or describe a correction. Viewing the graph is not confirmation.
