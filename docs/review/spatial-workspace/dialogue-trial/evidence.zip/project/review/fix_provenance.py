"""Preserve the original baseline and explicitly audit a metadata-only provenance repair."""

import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[1]
baseline_path = ROOT / ".stategraph/repair-initial/baseline.json"
original = ROOT / "review/initial-baseline-before-provenance-repair.json"
if original.exists():
    raise SystemExit("Provenance repair already recorded; do not repeat or replace it")
shutil.copyfile(baseline_path, original)
intent_path = ROOT / "intent.json"
intent = json.loads(intent_path.read_text(encoding="utf-8"))
before = json.loads(json.dumps(intent))
for requirement in intent["requirements"]:
    requirement["status"] = "confirmed"
intent_path.write_text(json.dumps(intent, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
baseline = json.loads(baseline_path.read_text(encoding="utf-8"))
baseline["requested_requirements"] = [rule["id"] for rule in intent["requirements"]]
baseline["request_amendment"] = {"kind": "initial_provenance_metadata_repair", "authorization": "Original U0/U1/U2, already authorizing initial implementation", "original_baseline": "review/initial-baseline-before-provenance-repair.json", "allowed_delta": "Add status=confirmed to already confirmed requirement records; preserve IDs, text, source, baseline hashes and all expectations", "snapshot_reset": False}
baseline_path.write_text(json.dumps(baseline, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
(ROOT / "review/provenance-repair.json").write_text(json.dumps({"before": before, "after": intent, "baseline_id_unchanged": baseline["id"], "note": "The initial setup omitted required status metadata and omitted --requirements scope tags. The original snapshot is retained verbatim. Only request-scope metadata is amended; no source/expectation snapshot is refreshed. test_workflow.py checks the exact permitted requirement delta."}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print("Added missing status metadata; preserved original snapshot and exact repair audit.")
