"""Exercise optional Web modes against the actual running local services."""
import json
from pathlib import Path
import sys
import time
from urllib.request import Request, urlopen
from urllib.error import HTTPError
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import bo_environment
from bo_observer.web.bo_web import BOWeb
ROOT=Path(__file__).resolve().parents[1]
web=BOWeb(ROOT)
def get(url):
    try:
        with urlopen(url,timeout=8) as response:return response.status,response.read()
    except HTTPError as error:return error.code,error.read()
def post(path,body):
    request=Request('http://127.0.0.1:8898'+path,data=json.dumps(body).encode(),headers={'Content-Type':'application/json'})
    with urlopen(request,timeout=8) as response:return json.load(response)
def view():return json.loads(get('http://127.0.0.1:8899/api/view')[1])
def settled_view():
    previous=view()
    for _ in range(20):
        time.sleep(.25)
        current=view()
        if current['events']==previous['events']:return current
        previous=current
    raise AssertionError('Business capture did not settle')
result=[]
try:
    for mode in ['hidden','disabled','visible']:
        web.set_mode(mode)
        # Rendering the business page is a real business list query, so do it before
        # counting the diagnostic reads themselves.
        app_status,html=get('http://127.0.0.1:8898/')
        assert app_status==200
        assert (b'data-bo-entry hidden' in html)==(mode!='visible')
        if mode=='disabled':web.set_mode('visible')
        before=settled_view()
        web.set_mode(mode)
        status,_=get('http://127.0.0.1:8899/graph')
        assert status==(404 if mode=='disabled' else 200)
        assert get('http://127.0.0.1:8898/api/stategraph')[0]==200
        if mode=='disabled':web.set_mode('visible')
        after=settled_view()
        assert before['events']==after['events'],'Diagnostic reads emitted business events'
        result.append({'mode':mode,'app_status':app_status,'entry_hidden':mode!='visible','graph_status':status,'diagnostic_reads_added_events':0})
        if mode=='disabled':
            web.set_mode('disabled')
            row=post('/api/tickets',{'actor_id':'u1','content':'Disabled debug Web persistence trial'})
            ident=row['id']
            states=[row['state']]
            for action,body in [('claim',{'actor_id':'t1'}),('result',{'actor_id':'t1','result':'Completed while debug Web disabled'}),('confirm',{'actor_id':'u1'})]:
                states.append(post(f'/api/tickets/{ident}/{action}',body)['state'])
            assert states==['pending','in_progress','awaiting_confirmation','completed']
            result[-1]['business_states']=states
            result[-1]['ticket_id']=ident
finally:
    web.set_mode('visible')
artifact={'valid':True,'modes':result,'restored':'visible'}
(ROOT/'review/web-modes-result.json').write_text(json.dumps(artifact,indent=2),encoding='utf-8')
print(json.dumps(artifact))
