# Repair application simulated-user trial

Date: 2026-10-25 (Asia/Shanghai).

This is an authorized simulated-user test. Replies supplied by the test initiator are test evidence, not human usability feedback. No answers or confirmations may be invented.

The only project write location is this trial directory. The maintained repository and globally installed skills are read-only references. Do not contact other conversations, create agents, commit, or publish.

Candidate skill: `C:/Users/Lvi_P/Documents/Work/CF/平台软著/SoftwareStatusObserverSkill/skills/vibelens/SKILL.md` with its accompanying resources. Commands against candidate scripts use Python `-B` to avoid writing bytecode into the reference repository.

Initial supplied requirement (verbatim):

> 我要做一个简单的 Python 报修单网页。用户提交报修内容，维修员接单并登记处理结果，用户确认完成。我希望用 VibeLens 查看程序运行时的业务、状态和函数关系。先和我确认必要的细节，再实现。

Current stage: clarification. Mode, identity/ownership and storage are unanswered. No behavior implementation is authorized until the business graph has been presented with a verified URL and explicitly confirmed in this conversation.

Initial preparation:

- Read the exact candidate skill, requirements dialogue, conversation/Web and database observation references.
- Checked ancestor and target AGENTS.md locations; none existed.
- Ran candidate `bo_db.py guide --root` successfully (exit 0). Python emitted `Failed to find real location of C:\Users\Lvi_P\miniforge3\python.exe`; the guide still returned valid JSON. This warning is retained as an environment observation, not a failed database test.
- Application port 8898 and observer port 8899 remain proposed and unchecked; no services have started.

Required later evidence: original dialogue, independent expectations, actual failures/fixes/retests, screenshots, real recording and replay, declaration/executor correspondence, rejected operations preserving state, optional code layer and exact source parameters, 2D/3D, layer drawer and spacing, coplanarity, camera-relative labels, legend and updates after source changes. Report mapping, state constraints, business rules and engineering checks separately.

## Clarification received and graph review prepared

The test initiator supplied U1: drive; fixed test identity switching without login; only the submitter confirms completion; only the assigned technician records the result; SQLite + SQLAlchemy with restart persistence; no additional business scope. The exact supplied reply is retained in `conversation.jsonl` and `discovery.json` with simulated-user provenance.

The declaration-only graph has eight nodes and seven relations. The candidate validator reports `valid: true`, `ready: false`, and `D_graph` awaiting an answer. The graph confirmation remains open; no application behavior or executable state machine has been implemented.

After preserving failed launch attempts, the hidden host design service (owned PID in `design-host.json`) responded successfully at `http://127.0.0.1:8899/graph`. HTTP/API evidence is in `design-http-verification.json`; actual browser evidence is in `screenshots/design-2d.jpg`. This proves design-page access only. It is not execution, recording/replay or business acceptance evidence.

Reproduction: run candidate `scripts/bo_web.py serve --root <this-project> --port 8899` with Python `-B` in a host terminal, after checking port occupancy. On this host the default sandbox launches were unreachable; a hidden host process succeeded. Stop only a process whose command line and project root match this trial.
