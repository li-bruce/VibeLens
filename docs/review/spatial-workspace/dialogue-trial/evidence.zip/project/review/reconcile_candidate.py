"""Record explicit candidate review without editing any baseline."""

import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("--change", default=".stategraph/repair-initial")
args = parser.parse_args()
folder = ROOT / args.change
candidate = {"id": json.loads((folder / "impact.json").read_text(encoding="utf-8"))["candidate_id"]}
impact = json.loads((folder / "impact.json").read_text(encoding="utf-8"))
review = {"candidate_id": candidate["id"], "decisions": {"business": {"action": "unchanged", "reason": "Implements only U0/U1/U2 fixed-identity repair flow; no rejection/rework."}, "state_machine": {"action": "updated", "reason": "The real bo.fsm/1 executor reads the canonical four-state, three-transition declaration."}, "abstraction": {"action": "updated", "reason": "Independent source inventory, explicit source support, data operations and optional code projection are included."}, "probes": {"action": "updated", "reason": "Actual guard evaluations, function returns and after-commit snapshots are captured; on/off/fault witnesses are compared to independent SQLite reads."}}, "excluded_symbols": {symbol: "Explicit support/observer disposition is in implementation; unresolved external/dynamic calls remain unknown and named scenarios execute the actual targets." for symbol in impact.get("required_classification", [])}, "requirement_changes": {}}
if args.change == ".stategraph/repair-initial":
    review["requirement_changes"] = {"R" + str(number): "Metadata-only repair: status=confirmed added to the already confirmed original record. Original baseline and exact delta are preserved; test_workflow enforces unchanged ID/text/source. The initial baseline scope field was manually amended, so this is not an unmodified-baseline pass." for number in range(1, 7)}
if args.change == ".stategraph/repair-runtime-owner":
    review["decisions"] = {"business": {"action": "unchanged", "reason": "Confirmed fixed-identity ticket flow, guards, SQL effects and independent expected values remain unchanged."}, "state_machine": {"action": "unchanged", "reason": "Exact canonical machine equals the preserved pre-correction machine; four states and three transitions are unchanged."}, "abstraction": {"action": "updated", "reason": "Remove fixed repair.submit runtime owner, use actual native commit event.node, and apply the canonical two-file viewer fix through bo_upgrade. One fact has one summary row while all display owners remain available for highlighting."}, "probes": {"action": "unchanged", "reason": "Existing selected event schema and actual source/target/guard publications are unchanged. Added independent real-frame regression asserts actual origin, one summary row, both state owners and target-state default owner."}}
(folder / "review.json").write_text(json.dumps(review, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"candidate_id": candidate["id"], "review_written": str(folder / "review.json"), "baseline_edited": False}))
