"""Freeze confirmed requirements and independent expectations before application coding."""

import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[1]
ANSWER = "模拟用户确认：这张图符合我的意思，按图实现。处理结果提交后等待提交人确认，确认后结束；这次不加入驳回、重新处理等其他流程。"


def write(name, value):
    target = ROOT / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    discovery = json.loads((ROOT / "discovery.json").read_text(encoding="utf-8"))
    shutil.copyfile(ROOT / "discovery.json", ROOT / "review" / "discovery-before-confirmation.json")
    discovery["sources"].append({"id": "U2", "kind": "user", "text": ANSWER, "locator": "review/conversation.jsonl#U2; simulated-user graph confirmation supplied by test initiator"})
    decision = next(item for item in discovery["decisions"] if item["id"] == "D_graph")
    decision.update(status="resolved", resolution={"kind": "user_answer", "text": ANSWER, "source_refs": ["U2"]})
    discovery["title"] = "报修单流程（模拟用户测试）"
    write("discovery.json", discovery)
    with (ROOT / "review/conversation.jsonl").open("a", encoding="utf-8") as stream:
        stream.write(json.dumps({"id": "A2", "role": "assistant", "kind": "graph_confirmation", "question": "请确认图中的流程和权限是否符合你的意思；确认后我再实现。", "diagram": "review/design-preview.md", "url": "http://127.0.0.1:8899/graph", "screenshot": "review/screenshots/design-2d.jpg"}, ensure_ascii=False) + "\n")
        stream.write(json.dumps({"id": "U2", "role": "user", "provenance": "test_initiator_simulated_reply", "simulated_user_test": True, "text": ANSWER}, ensure_ascii=False) + "\n")
    rules = [
        ("R1", "A test user submits content and creates a pending ticket."),
        ("R2", "A test technician claims a pending ticket; only one claim succeeds."),
        ("R3", "Only the assigned technician records a result; the ticket then awaits confirmation."),
        ("R4", "Only the submitter confirms an awaiting ticket; completed is terminal. No rejection or rework."),
        ("R5", "SQLite with SQLAlchemy persists tickets across process restarts."),
        ("R6", "The declared machine drives execution; VibeLens maps actual functions, values, states and data without controlling outcomes."),
    ]
    write("intent.json", {"project_id": "repair-20261025", "requirements": [{"id": ident, "text": text, "source": "U0/U1/U2; review/conversation.jsonl (simulated-user trial)"} for ident, text in rules]})
    checks = []
    cases = {
        "normal": [("R1", "states", ["pending", "in_progress", "awaiting_confirmation", "completed"]), ("R4", "final_result", "Fixed the leaking tap"), ("R4", "final_revision", 4)],
        "wrong_role": [("R2", "unchanged", True)],
        "wrong_technician": [("R3", "unchanged", True)],
        "wrong_submitter": [("R4", "unchanged", True)],
        "wrong_order": [("R3", "unchanged", True)],
        "completed_terminal": [("R4", "unchanged", True)],
        "empty_content": [("R1", "no_ticket", True)],
        "empty_result": [("R3", "unchanged", True)],
        "restart": [("R5", "preserved", True)],
        "claim_race": [("R2", "successful_claims", 1)],
        "rollback": [("R5", "unchanged", True)],
    }
    for case, fields in cases.items():
        for requirement, field, value in fields:
            checks.append({"id": case + "." + field, "requirement": requirement, "case": case, "path": [field], "equals": value})
    write("acceptance.json", {"checks": checks, "model_checks": []})
    placeholders = ["app/domain.py", "app/models.py", "app/storage.py", "app/policy.py", "app/server.py", "app/ports.py", "bo_stategraph/workflow.py", "integrations/bo_adapter.py"]
    for name in placeholders:
        target = ROOT / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text('"""Pending initial implementation; preserved in the first change baseline."""\n', encoding="utf-8")
    for name in ["build_model.py", "observe.py", "test_workflow.py", "run.py"]:
        (ROOT / name).write_text('"""Pending implementation; tracked before behavior coding."""\n', encoding="utf-8")
    write("behavior.json", {"schema_version": 3, "revision": "0", "intent": "intent.json", "source_files": placeholders, "nodes": [{"id": n["id"], "kind": n["kind"], "label": n["label"], "summary": "Confirmed design; implementation pending", "capture": {"in": {}, "out": {}}} for n in discovery["networks"][0]["nodes"]], "edges": [], "overview": [], "scope": {"unknowns": ["Initial implementation pending"]}})
    write("mapping.json", {"schema": "bo-mapping/v1", "cases": list(cases), "modes": ["on", "off", "fault"], "source": "Independent SQLite reads", "actual_collection": ["authority_snapshot", "runs"], "actual_id": ["id"], "fields": [], "export": {"case": "normal", "mode": "on"}})
    write("whitebox.json", {"schema_version": 1, "rules": [], "checks": []})
    write("sync.json", {"model": "behavior.json", "manifest": "manifest.json", "code_files": placeholders, "watch_files": ["build_model.py", "observe.py", "test_workflow.py", "run.py", "bo_stategraph/__init__.py"], "source_scope": {"roots": ["."], "require_symbol_classification": True, "exclude": {".venv/**": "Local dependencies, excluded from project source", "observer_runtime/**": "Versioned candidate runtime copied by bo_upgrade", "bo_stategraph/__init__.py": "Shared public core, parity checked", "bo_stategraph/bo_contracts.py": "Shared declaration validator, parity checked", "bo_stategraph/execution_contract.py": "Shared execution validator, parity checked", "bo_stategraph/bo_executor.py": "Shared native flat executor, parity and engine checks", "review/**": "Private trial evidence and audit utilities", "tests/**": "Independent acceptance and mutation utilities", "build_model.py": "Tracked generator, executed by validation", "observe.py": "Tracked independent real-run witness entrypoint", "test_workflow.py": "Tracked independent business checks", "run.py": "Tracked development launcher", "static/graph/**": "Versioned candidate viewer, checked by upgrade hashes"}}, "stategraph": {"module": "bo_stategraph/__init__.py", "development_mode": "drive", "execution_mode": "drive", "decision_source": "user", "decision": "drive"}, "discovery": "discovery.json", "whitebox": "whitebox.json", "require_mapping_witnesses": True, "mapping_contract": "mapping.json", "acceptance": "acceptance.json", "slice_depth": 1, "probe_callees": ["self.bo.record"], "required_probes": [{"symbol": "app/domain.py::RepairService.submit", "node": "repair.submit", "phase": "commit"}], "required_runtime_probes": [{"case": "normal", "node": "repair.confirm", "phase": "commit"}], "probe_modes": ["on", "off", "fault"], "observations_command": ["{python}", "-B", "observe.py"], "test_commands": [["{python}", "-B", "test_workflow.py"]], "timeout_seconds": 120})
    print("Prepared confirmed intent, independent expectations and pre-implementation baseline inputs.")


if __name__ == "__main__":
    main()
