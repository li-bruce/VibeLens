"""Validate saved real recording, actual package and isolated stale-source rejection."""
import json
from pathlib import Path
import shutil
import subprocess
import sys
import uuid
import zipfile
import argparse
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import bo_environment
from bo_observer.code_graph.service import CodeGraph
def read(path):return json.loads((ROOT/path).read_text(encoding='utf-8-sig'))
parser=argparse.ArgumentParser()
parser.add_argument('--recording',default='review/recording-delivery.json')
parser.add_argument('--query',default='review/public-query-delivery.json')
parser.add_argument('--view',default='review/live-view-delivery.json')
parser.add_argument('--change',default='.stategraph/repair-evidence')
parser.add_argument('--core',default='dist/repair-core-20261025.zip')
parser.add_argument('--instance',default='ticket:4')
parser.add_argument('--out',default='review/delivery-check-result.json')
args=parser.parse_args()
record=read(args.recording)
public=read(args.query)
live=read(args.view)
accepted=read(args.change+'/accepted.json')
assert record['build_id']==public['build_id']==accepted['build_id']==live['manifest']['build_id']
assert record['status']=='stopped' and record['gaps']==[]
assert live['health']['errors']==live['health']['dropped']==0
events=record['events'];byid={e['id']:e for e in events};calls={}
for e in events:calls.setdefault(e['call_id'],set()).add(e['node'])
assert all(len(v)==1 for v in calls.values())
for e in events:
    if e['node']=='flow.step':assert next(iter(calls[e['parent_call_id']])).startswith('repair.')
    if e['node'].startswith('guard.'):assert calls[e['parent_call_id']]=={'flow.step'}
frames=[f for f in record['runtime_frames']['frames'] if f['authority'].get('entity')==args.instance]
assert [(f['revision'],f['machine']['current']) for f in frames]==[(1,'pending'),(2,'in_progress'),(3,'awaiting_confirmation'),(4,'completed')]
journal=[j for j in public['machine']['journal'] if j['attempt']==args.instance]
expected=[('claim','pending','in_progress',{'is_technician':True}),('record_result','in_progress','awaiting_confirmation',{'is_technician':True,'is_assignee':True,'has_result':True}),('confirm','awaiting_confirmation','completed',{'is_submitter':True})]
assert [(j['event'],j['source'],j['target'],j['guards']) for j in journal]==expected
for j in journal:
    event=byid[j['evidence_id']]
    assert event['phase']=='commit' and event['outputs']['state']==j['target']
    frame=next(f for f in frames if f['event_id']==j['evidence_id'])
    native=frame['machine']['journal'][0]
    assert tuple(native[k] for k in ['event','source','target','revision','evidence_id'])==tuple(j[k] for k in ['event','source','target','revision','evidence_id'])
    flow=[e for e in events if e['node']=='flow.step' and e['phase']=='return' and e['inputs']['event']==j['event']]
    assert len(flow)==1
    guard_values={e['node'].split('.',1)[1]:e['outputs']['allowed'] for e in events if e['node'].startswith('guard.') and e['parent_call_id']==flow[0]['call_id']}
    assert guard_values==j['guards']
assert next(p for p in public['machine']['path_evidence']['instances'] if p['instance_id']==args.instance)['status']=='complete'
assert record['sources']['app/domain.py']==(ROOT/'app/domain.py').read_text(encoding='utf-8')
folder=ROOT/'.validation/delivery'/uuid.uuid4().hex[:8]
folder.mkdir(parents=True)
core=folder/'actual-core-package'
with zipfile.ZipFile(ROOT/args.core) as archive:archive.extractall(core)
run=subprocess.run([sys.executable,'-B','bo_core_run.py','--self-test'],cwd=core,capture_output=True,text=True,encoding='utf-8')
assert run.returncode==0,(run.stdout,run.stderr)
core_result=json.loads(run.stdout)
assert not core_result['observer_runtime_present'] and not core_result['viewer_present']
isolated=folder/'stale-source';isolated.mkdir()
project=read('bo_stategraph/project.json')
for name in set(project['model']['source_files'])|{'bo_stategraph/project.json','bo_stategraph/databases.json','bo_stategraph/declaration.json','bo_stategraph/database-catalog.json','manifest.json'}:
    target=isolated/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/name,target)
shutil.copytree(ROOT/'.stategraph',isolated/'.stategraph')
def gate():
    command=[sys.executable,'-B',str(ROOT/'observer_runtime/change_sync.py'),'check','--root',str(isolated)]
    result=subprocess.run(command,cwd=isolated,capture_output=True,text=True,encoding='utf-8')
    return result.returncode,json.loads(result.stdout)
before_exit,before=gate()
assert before_exit==0,before
code=CodeGraph(isolated);old_revision=code.refresh()[0]['revision']
source=isolated/'app/domain.py'
source.write_text(source.read_text(encoding='utf-8')+'\n# Deliberate isolated source freshness counterexample\n',encoding='utf-8')
after_exit,after=gate()
assert after_exit!=0 and not after['valid'],after
try:code.source('app/domain.py',old_revision)
except ValueError as error:source_rejection=str(error)
else:raise AssertionError('Old source revision was returned after source changed')
result={'valid':True,'build_id':accepted['build_id'],'recording':{'id':record['id'],'events':len(events),'gaps':record['gaps'],'actual_state_frames':len(frames),'actual_transitions':len(journal),'guard_values_and_parent_calls':'checked','query_and_native_frame_edges':'checked'},'actual_core_package_execution':core_result,'stale_source':{'before':before,'after':after,'source_rejection':source_rejection},'evidence_directory':str(folder.relative_to(ROOT))}
(ROOT/args.out).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
