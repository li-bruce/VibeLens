"""Restart only the verified trial-owned process tree and compare durable evidence."""
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import time
from urllib.request import urlopen
ROOT=Path(__file__).resolve().parents[1]
def get(path,port=8899):
    with urlopen(f'http://127.0.0.1:{port}'+path,timeout=2) as response:return json.load(response)
def rows():
    with sqlite3.connect('file:'+(ROOT/'data/repair.sqlite').as_posix()+'?mode=ro',uri=True) as connection:return connection.execute('SELECT * FROM tickets ORDER BY id').fetchall()
before={'health':get('/api/bo/health'),'recordings':get('/api/recordings'),'preferences':get('/api/preferences'),'rows':rows()}
(ROOT/'review/restart-before.json').write_text(json.dumps(before,ensure_ascii=False,indent=2),encoding='utf-8')
metadata=json.loads((ROOT/'.stategraph/processes.json').read_text())
assert Path(metadata['root']).resolve()==ROOT
pid=metadata['supervisor_pid']
command=subprocess.run(['powershell','-NoProfile','-Command',f"(Get-CimInstance Win32_Process -Filter 'ProcessId={pid}').CommandLine"],capture_output=True,text=True,encoding='utf-8').stdout
assert str(ROOT) in command and 'run.py' in command,command
subprocess.run(['taskkill','/PID',str(pid),'/T','/F'],capture_output=True,check=True)
streams=[(ROOT/'review/restart.stdout.log').open('a',encoding='utf-8'),(ROOT/'review/restart.stderr.log').open('a',encoding='utf-8')]
child=subprocess.Popen([sys.executable,'-B',str(ROOT/'run.py')],cwd=ROOT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONIOENCODING':'utf-8'},stdout=streams[0],stderr=streams[1],creationflags=subprocess.CREATE_NO_WINDOW)
for _ in range(60):
    try:
        after={'health':get('/api/bo/health'),'recordings':get('/api/recordings'),'preferences':get('/api/preferences'),'rows':rows(),'app_health':get('/api/stategraph/health',8898)}
        break
    except OSError:time.sleep(.25)
else:raise AssertionError('Restart failed')
assert before['health']['build_id']==after['health']['build_id']==after['app_health']['build_id']
assert before['rows']==after['rows']
assert before['recordings']==after['recordings']
assert before['preferences']['entries']==after['preferences']['entries']
record_id=before['recordings']['recordings'][0]['id']
retained=get('/api/recordings/'+record_id)
assert retained['id']==record_id and len(retained['events'])==63 and retained['gaps']==[]
after.update(valid=True,retained_recording=record_id,recording_events=63,preferences_unchanged=True,rows_unchanged=True,supervisor_started_pid=child.pid)
(ROOT/'review/restart-after.json').write_text(json.dumps(after,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'valid':True,'same_build':after['health']['build_id'],'rows':len(after['rows']),'retained_recording':record_id,'events':63,'preferences_unchanged':True,'process_tree_verified':True}))
