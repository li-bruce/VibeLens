"""Prepare declaration-only review evidence; no application behavior is implemented."""

import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
SKILL = ROOT.parents[1] / "SoftwareStatusObserverSkill" / "skills" / "vibelens"
REPLY = "继续这次模拟用户试用。我的回答是：选择 drive。先做固定测试身份切换，不做登录；只有提交人能确认完成，只有接单的维修员能登记处理结果。用 SQLite + SQLAlchemy，重启后保留。先按这条流程做，不增加其他业务。"
QUESTION = "请确认图中的流程和权限是否符合你的意思；确认后我再实现。"


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    history = ROOT / "review" / "conversation.jsonl"
    turns = [json.loads(line) for line in history.read_text(encoding="utf-8").splitlines() if line]
    if not any(turn["id"] == "U1" for turn in turns):
        with history.open("a", encoding="utf-8") as output:
            output.write(json.dumps({"id": "U1", "role": "user", "provenance": "test_initiator_simulated_reply", "simulated_user_test": True, "text": REPLY}, ensure_ascii=False) + "\n")
    sources = [
        {"id": "U0", "kind": "user", "text": turns[0]["text"], "locator": "review/conversation.jsonl#U0; simulated-user test initial requirement"},
        {"id": "A1", "kind": "assistant", "text": turns[1]["text"], "locator": "review/conversation.jsonl#A1; assistant clarification"},
        {"id": "U1", "kind": "user", "text": REPLY, "locator": "review/conversation.jsonl#U1; test initiator supplied simulated user answer, not human testing"},
        {"id": "A2", "kind": "assistant", "text": QUESTION, "locator": "Current conversation graph review question; review/design-preview.md"},
    ]
    labels = [
        ("repair.submit", "用户提交报修内容", "action", ["U0"]),
        ("repair.pending", "待接单", "state", ["U0"]),
        ("repair.claim", "维修员接单", "action", ["U0"]),
        ("repair.in_progress", "处理中", "state", ["U0"]),
        ("repair.record_result", "接单维修员登记处理结果", "action", ["U0", "U1"]),
        ("repair.awaiting_confirmation", "待用户确认", "state", ["U0"]),
        ("repair.confirm", "提交人确认完成", "action", ["U0", "U1"]),
        ("repair.completed", "已完成", "state", ["U0"]),
    ]
    nodes = [{"id": ident, "label": label, "kind": kind, "source_refs": refs, "model_nodes": [ident]} for ident, label, kind, refs in labels]
    links = [
        ("repair.submitted", "repair.submit", "repair.pending", "flow", "保存报修单"),
        ("repair.can_claim", "repair.pending", "repair.claim", "guard", "维修员身份；单据待接单"),
        ("repair.claimed", "repair.claim", "repair.in_progress", "flow", "登记接单维修员"),
        ("repair.can_record", "repair.in_progress", "repair.record_result", "guard", "仅接单维修员"),
        ("repair.result_recorded", "repair.record_result", "repair.awaiting_confirmation", "flow", "保存处理结果"),
        ("repair.can_confirm", "repair.awaiting_confirmation", "repair.confirm", "guard", "仅该单提交人"),
        ("repair.confirmed", "repair.confirm", "repair.completed", "flow", "确认完成"),
    ]
    edges = [{"id": ident, "from": start, "to": end, "relation": relation, "label": label, "source_refs": ["U0", "U1"]} for ident, start, end, relation, label in links]
    decisions = []
    for ident, topic, question, why, affected, answer in [
        ("D_mode", "other", "drive 或 observe？", "Determines the authoritative execution model.", ["repair.claim", "repair.record_result", "repair.confirm"], "drive"),
        ("D_identity", "authority", "如何区分用户和维修员；谁可登记结果和确认？", "Determines actor and ownership conditions.", ["repair.can_claim", "repair.can_record", "repair.can_confirm"], "固定测试身份切换，不做登录；只有提交人确认，只有接单维修员登记结果。"),
        ("D_storage", "resources", "是否 SQLite + SQLAlchemy，重启后保留？", "Determines durable storage and its model adapter.", ["repair.submitted", "repair.claimed", "repair.result_recorded", "repair.confirmed"], "SQLite + SQLAlchemy，重启后保留。"),
    ]:
        decisions.append({"id": ident, "topic": topic, "question": question, "why": why, "affects": affected, "blocking": True, "status": "resolved", "priority": 1, "source_refs": ["U0", "U1"], "asked_in": ["A1"], "resolution": {"kind": "user_answer", "text": answer, "source_refs": ["U1"]}})
    decisions.append({"id": "D_graph", "topic": "scope", "question": QUESTION, "why": "Confirm the shared business and state graph before behavior implementation.", "affects": [node["id"] for node in nodes], "blocking": True, "status": "open", "priority": 1, "source_refs": ["U0", "U1", "A2"], "asked_in": ["A2"]})
    document = {"schema": "business-discovery/v1", "project_id": "repair-20261025", "layout_id": "repair-20261025", "title": "报修单流程（模拟用户测试 · 待确认设计稿）", "goal": sources[0]["text"], "sources": sources, "networks": [{"id": "repair.lifecycle", "title": "提交、接单、处理结果与完成确认", "actors": ["固定测试用户", "固定测试维修员"], "trigger": "用户提交报修内容", "outcome": "接单维修员登记结果后，由提交人确认完成；SQLite 持久化。", "nodes": nodes, "edges": edges}], "decisions": decisions}
    write(ROOT / "discovery.json", document)
    files = {str(path.relative_to(SKILL)).replace("\\", "/"): hashlib.sha256(path.read_bytes()).hexdigest() for path in SKILL.rglob("*") if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc" and "node_modules" not in path.parts}
    write(ROOT / "review" / "candidate-baseline.json", {"path": str(SKILL), "scope": "Candidate skill with companion resources; read-only reference", "files": files})
    output = subprocess.run(["git", "-C", str(SKILL.parents[1]), "status", "--short"], capture_output=True, text=True, encoding="utf-8")
    (ROOT / "review" / "candidate-git-status-before.txt").write_text(output.stdout, encoding="utf-8")
    print(json.dumps({"nodes": len(nodes), "edges": len(edges), "candidate_files": len(files), "stage": "design", "confirmation": "pending"}))


if __name__ == "__main__":
    main()
