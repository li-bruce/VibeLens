"""Add explicit storage projection obligations and guard expectations; never infer expected outcomes from execution."""

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def write(name, value):
    (ROOT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    mapping = json.loads((ROOT / "mapping.json").read_text(encoding="utf-8"))
    mapping["fields"] = [{"id": name, "node": "repair.submit", "actual": [name], "mapped": [name]} for name in ("state", "revision", "build_id")]
    mapping["fields"] += [{"id": name, "node": "repair.submit", "actual": [name], "mapped": ["context", name]} for name in ("submitter_id", "technician_id", "result_length")]
    write("mapping.json", mapping)
    rules, checks = [], []
    for name, requirement, false_case in [("is_technician", "R2", "wrong_role"), ("is_assignee", "R3", "wrong_technician"), ("has_result", "R3", "empty_result"), ("is_submitter", "R4", "wrong_submitter")]:
        rules.append({"id": name, "requirement": requirement, "category": "decision", "claim": "The actual " + name + " evaluation follows the confirmed actor/ownership/content condition", "basis": "U0/U1/U2 in review/conversation.jsonl (simulated-user confirmation)", "node": "guard." + name, "source": {"path": "app/policy.py", "symbol": name}, "parameters": {"context": "dict", "payload": "dict"}, "returns": "bool"})
        for case, allowed in [("normal", True), (false_case, False)]:
            checks.append({"id": name + "." + case, "rule": name, "case": case, "phase": "decision", "count": {"min": 1}, "fields": [{"path": ["outputs", "allowed"], "type": "boolean", "equals": allowed}]})
    rules.append({"id": "confirm_commit", "requirement": "R4", "category": "state", "claim": "Final submitter confirmation commits completed at revision four in the independent four-operation scenario", "basis": "U2; independent normal scenario expectation", "node": "repair.confirm", "source": {"path": "app/domain.py", "symbol": "RepairService.confirm"}, "parameters": {"ticket_id": "int", "actor_id": "str"}, "returns": "dict"})
    checks.append({"id": "confirm_commit.normal", "rule": "confirm_commit", "case": "normal", "phase": "commit", "count": {"min": 1, "max": 1}, "fields": [{"path": ["outputs", "state"], "equals": "completed", "type": "string"}, {"path": ["outputs", "revision"], "equals": 4, "type": "integer"}]})
    write("whitebox.json", {"schema_version": 1, "rules": rules, "checks": checks})
    discovery = json.loads((ROOT / "discovery.json").read_text(encoding="utf-8"))
    for decision in discovery["decisions"]:
        decision["links"] = {"requirements": ["R1", "R2", "R3", "R4", "R5", "R6"], "model_nodes": [node["id"] for node in discovery["networks"][0]["nodes"]], "checks": ["normal.states", "normal.final_revision", "wrong_technician.unchanged", "wrong_submitter.unchanged", "restart.preserved"]}
    write("discovery.json", discovery)
    print("Prepared mapping and white-box expectations without reading runtime results.")


if __name__ == "__main__":
    main()
