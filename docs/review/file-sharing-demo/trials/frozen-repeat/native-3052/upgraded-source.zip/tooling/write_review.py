"""Record the coding agent's technical reconciliation for the current inspected candidate."""
import json
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "observer_runtime"))
from sync_config import config, snapshot
from sync_io import write


def main():
    cfg = config(ROOT, "sync.json")
    candidate = snapshot(ROOT, cfg)
    active = json.loads((ROOT / ".stategraph/active.json").read_text(encoding="utf-8"))
    review = {
        "candidate_id": candidate["id"],
        "author": "Coding agent; technical review, not human product acceptance.",
        "source": "Explicit revocation scope in discovery.json:U4; authorized simulated restatement in U5.",
        "decisions": {
            "business": {"action": "updated", "reason": "U4 authorizes only owner-targeted revocation, next-request denial from an unchanged page, retained other access, and re-sharing."},
            "state_machine": {"action": "updated", "reason": "Native bo.fsm adds revoke transitions to shared/private according to the same transaction's remaining recipient list; original transitions remain."},
            "abstraction": {"action": "updated", "reason": "Stable discovery IDs map to real handlers, predicates, database operations, and source-derived helpers. Explicit predicate anchors stabilize canonical projections."},
            "probes": {"action": "updated", "reason": "Capture only allowlisted identity, size, hash, decisions, states, and counts. Preserve on/off/fault modes and independent mapping/business expectations."},
        },
        "requirement_changes": {"R_BOUNDARY": "U4 moves revocation from deferred scope into this iteration; no registration, preview, editing, or deletion is added.",
                                "R_REVOKE": "U4 explicitly authorizes targeted cancellation, next-request enforcement, preserved other access, and later re-sharing."},
        "excluded_symbols": {},
    }
    write(ROOT / active["change"] / "review.json", review)
    print(json.dumps({"candidate_id": candidate["id"], "review": active["change"] + "/review.json"}))


if __name__ == "__main__":
    main()
