"""Execute protected real scenarios; write actual evidence for the canonical gate."""
import argparse
import json
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "observer_runtime"))
from behavior_model import capture
from mapping_contract import instance_witnesses
from bo_stategraph import BOStateGraph
from bo_stategraph.workflow import definition
from tooling.scenarios import CASES, execute


def observe():
    project = json.loads((ROOT / "bo_stategraph/project.json").read_text(encoding="utf-8"))
    model = project["model"]
    build = capture(ROOT, model)["build_id"]
    runs = [execute(case, mode) for mode in ("on", "off", "fault") for case in CASES]
    witnesses = []
    for run in runs:
        actual = {row["id"]: {"state": row["state"], "revision": row["revision"],
                              "context": row["context"], "build_id": row["build_id"]}
                  for row in run["authority"]["files"]}
        witnesses.extend(instance_witnesses(run["projection"]["instances"], actual,
            case=run["case"] + ":" + run["mode"], source="SQLite independent authoritative reads"))
    selected = next(run for run in runs if run["case"] == "normal" and run["mode"] == "on")
    graph = BOStateGraph(model, build_id=build, mode="drive")
    result = {"build_id": build, "machine": definition(), "runs": runs,
              "mapping_checks": witnesses,
              "stategraph_export": graph.bo_export(runtime={"machine": selected["projection"]["machine"]})}
    assert capture(ROOT, model)["build_id"] == build, "Source changed during verification."
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    result = observe()
    raw = json.dumps(result, ensure_ascii=False)
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(raw + "\n", encoding="utf-8")
        print(json.dumps({"runs": len(result["runs"]), "out": str(args.out),
                          "events": sum(len(run["events"]) for run in result["runs"])}))
    else:
        print(raw)


if __name__ == "__main__":
    main()
