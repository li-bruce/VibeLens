"""Independent synthetic-data scenarios through real HTTP handlers and SQLite."""
from io import BytesIO
import hashlib
from pathlib import Path
import tempfile

from sqlalchemy import text
from sqlalchemy.exc import IntegrityError

from app.store import Store
from app.service import FileService
from app.web import create_app
from integrations.bo_adapter import BOAdapter
from bo_stategraph.query import bo_machine

CASES = (
    "login_success", "login_invalid", "upload_signed_in", "upload_anonymous",
    "share_owner", "share_recipient_denied", "share_unrelated_denied",
    "share_anonymous_denied", "share_unknown_recipient", "view_owner", "view_recipient",
    "view_unrelated_denied", "view_anonymous_denied", "download_owner",
    "download_recipient", "download_unrelated_denied", "download_anonymous_denied",
    "normal", "share_idempotent", "database_rollback",
    "revoke_owner", "revoke_nonowner_denied", "revoke_anonymous_denied",
    "revoke_idempotent", "revoke_last_recipient", "revoke_reshare",
    "revoke_other_file_retained", "revoke_unknown_recipient",
)
SAMPLE = b"A private handoff file.\n"


def post(client, path, **kwargs):
    cookie = client.get_cookie("fs_csrf")
    headers = kwargs.pop("headers", {})
    if cookie:
        headers["X-CSRF-Token"] = cookie.value
    return client.post(path, headers=headers, **kwargs)


def sign_in(client, user):
    return post(client, "/api/login", json={"username": user, "password": "trial-" + user})


def upload(client, name="handoff.txt", content=SAMPLE):
    return post(client, "/api/files", data={"file": (BytesIO(content), name)},
                content_type="multipart/form-data")


def execute(case, mode="on", capacity=8192, slow_sink=False):
    if case not in CASES:
        raise ValueError("Unknown independent scenario")
    events, snapshots = [], []

    def sink(value, kind):
        if mode == "fault":
            raise OSError("Deliberate observer transport failure; no business state is mocked.")
        if slow_sink:
            import time
            time.sleep(0.02)
        (events if kind == "events" else snapshots).append(value)

    scratch = Path(__file__).resolve().parents[1] / "review" / "scratch"
    scratch.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="small-share-case-", dir=scratch) as directory:
        assert Path(directory).resolve().is_relative_to(scratch.resolve())
        adapter = BOAdapter(mode, sink=sink, capacity=capacity, run_id=case + "-" + mode)
        store = Store(Path(directory) / "files.sqlite3", adapter.events)
        service = FileService(store, adapter.build_id, adapter.events)
        app = create_app(service)
        app.config["TESTING"] = True
        clients = {name: app.test_client() for name in ("linzhou", "xuning", "zhoulan")}
        anonymous = app.test_client()
        observations = {}
        try:
            if case == "login_invalid":
                response = post(clients["linzhou"], "/api/login",
                                json={"username": "linzhou", "password": "incorrect"})
            elif case == "login_success":
                response = sign_in(clients["linzhou"], "linzhou")
            else:
                for user, client in clients.items():
                    assert sign_in(client, user).status_code == 200
                owner, recipient, unrelated = [clients[user] for user in ("linzhou", "xuning", "zhoulan")]
                owner.get("/login")
                owner.get("/api/users")
                if case in {"upload_signed_in", "upload_anonymous"}:
                    response = upload(owner if case == "upload_signed_in" else anonymous)
                else:
                    created = upload(owner)
                    assert created.status_code == 201
                    file_id = created.json["id"]
                    observations["file_id"] = file_id
                    observations["owner_id"] = created.json["owner_id"]
                    observations["uploaded_filename"] = created.json["filename"]
                    observations["uploaded_size"] = created.json["size"]
                    if case in {"view_recipient", "download_recipient", "share_recipient_denied",
                                "normal", "share_idempotent"}:
                        assert post(owner, f"/api/files/{file_id}/share",
                                    json={"recipient_id": "xuning"}).status_code == 200
                    if case.startswith("revoke_"):
                        response = revocation_case(case, owner, recipient, unrelated, anonymous,
                                                   store, file_id, observations)
                    elif case.startswith("share_") and case != "share_idempotent":
                        caller = {"share_owner": owner, "share_recipient_denied": recipient,
                                  "share_unrelated_denied": unrelated, "share_anonymous_denied": anonymous,
                                  "share_unknown_recipient": owner}[case]
                        response = post(caller, f"/api/files/{file_id}/share",
                                        json={"recipient_id": "missing" if case == "share_unknown_recipient" else "zhoulan"})
                    elif case.startswith("view_"):
                        caller = {"view_owner": owner, "view_recipient": recipient,
                                  "view_unrelated_denied": unrelated, "view_anonymous_denied": anonymous}[case]
                        response = caller.get(f"/api/files/{file_id}")
                    elif case.startswith("download_"):
                        caller = {"download_owner": owner, "download_recipient": recipient,
                                  "download_unrelated_denied": unrelated, "download_anonymous_denied": anonymous}[case]
                        response = caller.get(f"/api/files/{file_id}/download")
                        observations["bytes_match"] = response.data == SAMPLE
                    elif case == "share_idempotent":
                        response = post(owner, f"/api/files/{file_id}/share", json={"recipient_id": "xuning"})
                        observations["share_count"] = len(store.snapshot()["shares"])
                    elif case == "database_rollback":
                        with store.engine.connect() as connection:
                            before = connection.execute(text("SELECT count(*) FROM users")).scalar_one()
                        try:
                            with store.transaction() as connection:
                                store.write(connection,
                                    "INSERT INTO users(id,display_name,password_hash) VALUES(:id,:name,:password)",
                                    {"id": "linzhou", "name": "duplicate", "password": "unused"},
                                    "constraint_rollback")
                        except IntegrityError:
                            observations["status"] = 409
                            observations["scenario_outcome"] = "Actual SQLite uniqueness error rolled back; no HTTP endpoint."
                        else:
                            raise AssertionError("SQLite did not enforce the declared primary key.")
                        with store.engine.connect() as connection:
                            after = connection.execute(text("SELECT count(*) FROM users")).scalar_one()
                        observations["row_count_unchanged"] = before == after
                        response = None
                    else:
                        assert owner.get("/api/files").status_code == 200
                        assert recipient.get("/api/files").status_code == 200
                        metadata = recipient.get(f"/api/files/{file_id}")
                        assert metadata.status_code == 200
                        assert metadata.json["filename"] == "handoff.txt"
                        assert metadata.json["size"] == len(SAMPLE)
                        observations["metadata"] = metadata.json
                        response = recipient.get(f"/api/files/{file_id}/download")
                        observations["bytes_match"] = response.data == SAMPLE
                        observations["download_size"] = len(response.data)
                        observations["download_sha256"] = hashlib.sha256(response.data).hexdigest()
                        observations["unrelated_file_count"] = len(unrelated.get("/api/files").json["files"])
                        assert post(owner, "/api/logout").status_code == 200
            if response is not None:
                observations["status"] = response.status_code
                observations["error"] = response.json.get("error", "") if response.is_json else ""
            authority = store.snapshot()
            if case == "normal":
                observations["recipient_ids"] = [row["recipient_id"] for row in authority["shares"]]
                observations["stored_sha256"] = authority["files"][0]["context"]["sha256"]
            adapter.bo_close()
            projection = {"build_id": adapter.build_id, "machine": bo_machine(authority),
                          "instances": adapter.graph.bo_instances(bo_machine(authority))}
            assert not any(instance["errors"] or instance["missing"] for instance in projection["instances"])
            return {
                "case": case, "mode": mode, "events": events, "snapshots": snapshots,
                "policy_evaluations": adapter.evaluations, "observations": observations,
                "authority": authority, "projection": projection,
                "capture_diagnostics": {"errors": adapter.probe.bo_errors,
                                        "dropped": adapter.probe.bo_dropped,
                                        "queued": adapter.probe.bo_seq},
            }
        finally:
            adapter.probe.close()
            store.engine.dispose()



def revocation_case(case, owner, recipient, other, anonymous, store, file_id, observations):
    assert post(owner, f"/api/files/{file_id}/share", json={"recipient_id": "xuning"}).status_code == 200
    if case != "revoke_last_recipient":
        assert post(owner, f"/api/files/{file_id}/share", json={"recipient_id": "zhoulan"}).status_code == 200
    second_id = None
    if case == "revoke_other_file_retained":
        second = upload(owner, name="other-file.txt", content=SAMPLE)
        assert second.status_code == 201
        second_id = second.json["id"]
        assert post(owner, f"/api/files/{second_id}/share", json={"recipient_id": "xuning"}).status_code == 200
    before = store.snapshot()
    caller = recipient if case == "revoke_nonowner_denied" else anonymous if case == "revoke_anonymous_denied" else owner
    target = "missing" if case == "revoke_unknown_recipient" else "xuning"
    response = post(caller, f"/api/files/{file_id}/revoke", json={"recipient_id": target})
    observations["recipient_id"] = target
    observations["effect_unchanged"] = store.snapshot() == before
    if case in {"revoke_nonowner_denied", "revoke_anonymous_denied", "revoke_unknown_recipient"}:
        observations["recipient_download_status"] = recipient.get(f"/api/files/{file_id}/download").status_code
        return response
    assert response.status_code == 200
    after = next(row for row in store.snapshot()["files"] if row["id"] == file_id)
    observations["remaining_after_revoke"] = after["context"]["recipient_ids"]
    observations["revoke_state"] = after["state"]
    observations["owner_id"] = after["owner_id"]
    observations["revoke_changed"] = response.json["changed"]
    observations["revoked_download_status"] = recipient.get(f"/api/files/{file_id}/download").status_code
    observations["revoked_metadata_status"] = recipient.get(f"/api/files/{file_id}").status_code
    owner_result = owner.get(f"/api/files/{file_id}/download")
    observations["owner_download_status"] = owner_result.status_code
    observations["owner_bytes_match"] = owner_result.data == SAMPLE
    if case != "revoke_last_recipient":
        other_result = other.get(f"/api/files/{file_id}/download")
        observations["other_download_status"] = other_result.status_code
        observations["other_bytes_match"] = other_result.data == SAMPLE
    if case == "revoke_idempotent":
        revision = after["revision"]
        response = post(owner, f"/api/files/{file_id}/revoke", json={"recipient_id": "xuning"})
        final = next(row for row in store.snapshot()["files"] if row["id"] == file_id)
        observations["duplicate_changed"] = response.json["changed"]
        observations["duplicate_revision_unchanged"] = final["revision"] == revision
    if case == "revoke_reshare":
        response = post(owner, f"/api/files/{file_id}/share", json={"recipient_id": "xuning"})
        restored = recipient.get(f"/api/files/{file_id}/download")
        observations["restored_download_status"] = restored.status_code
        observations["restored_bytes_match"] = restored.data == SAMPLE
    if second_id:
        retained = recipient.get(f"/api/files/{second_id}/download")
        observations["other_file_download_status"] = retained.status_code
        observations["other_file_bytes_match"] = retained.data == SAMPLE
    return response

