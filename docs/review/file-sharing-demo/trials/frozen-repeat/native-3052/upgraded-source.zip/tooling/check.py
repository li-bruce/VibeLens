"""Connected canonical project gate; no validator or projection compatibility replacement."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
ROOT = Path(__file__).resolve().parents[1]


def run(name, arguments):
    result = subprocess.run([sys.executable, "-B", "-X", "utf8", *arguments],
                            cwd=ROOT, capture_output=True, text=True, encoding="utf-8")
    path = ROOT / "review" / (name + ".json")
    path.write_text(result.stdout, encoding="utf-8")
    (ROOT / "review" / (name + ".stderr.txt")).write_text(result.stderr, encoding="utf-8")
    if result.returncode:
        try:
            data = json.loads(result.stdout)
            print(json.dumps({"stage": name, "valid": False,
                              "errors": data.get("errors"),
                              "reports": data.get("reports", data.get("review_errors"))}, ensure_ascii=False))
        except ValueError:
            print(f"{name} failed; see {path}")
        raise SystemExit(result.returncode)
    print(f"{name}: passed", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--accept", action="store_true")
    args = parser.parse_args()
    os.environ.setdefault("FILESHARE_DB_URL", "sqlite:///data/files.sqlite3")
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
    run("gate-architecture", ["observer_runtime/architecture_guard.py", "check", "--root", "."])
    run("gate-scan", ["observer_runtime/bo_sync.py", "scan", "--root", "."])
    run("gate-inspect", ["observer_runtime/change_sync.py", "inspect", "--root", "."])
    run("gate-verify", ["observer_runtime/change_sync.py", "verify", "--root", "."])
    if args.accept:
        run("gate-accept", ["observer_runtime/change_sync.py", "accept", "--root", "."])
    run("gate-check", ["observer_runtime/change_sync.py", "check", "--root", "."])


if __name__ == "__main__":
    main()
