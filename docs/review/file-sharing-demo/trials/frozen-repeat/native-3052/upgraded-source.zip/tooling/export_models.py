"""Export native declarations only; this command never creates or connects to a database."""
import json
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "observer_runtime"))
from sqlalchemy.dialects.sqlite import dialect
from app.models import metadata
from bo_observer.data.catalog import export_sqlalchemy_metadata

if __name__ == "__main__":
    print(json.dumps(export_sqlalchemy_metadata(metadata, "files", dialect=dialect())))
