"""Run representative business operations with the observer implementation absent."""
from pathlib import Path
import sys
import tempfile
from app.store import Store
from app.ports import BOEvents
from app.service import FileService, BusinessError

root = Path.cwd().resolve()
assert not (root / "observer_runtime").exists(), "Run this check in the extracted core."
scratch = root / "scratch"
scratch.mkdir(exist_ok=True)
with tempfile.TemporaryDirectory(dir=scratch) as directory:
    assert Path(directory).resolve().is_relative_to(root)
    store = Store(Path(directory) / "core.sqlite3", BOEvents())
    service = FileService(store, "core")
    try:
        service.login("linzhou", "trial-linzhou")
        uploaded = service.upload("linzhou", "core.txt", b"core independently works")
        service.share("linzhou", uploaded["id"], "xuning")
        assert service.download("xuning", uploaded["id"])["content"] == b"core independently works"
        try:
            service.download("zhoulan", uploaded["id"])
        except BusinessError as error:
            assert error.status == 403
        else:
            raise AssertionError("Unrelated user unexpectedly accessed core file.")
        service.share("linzhou", uploaded["id"], "zhoulan")
        service.revoke("linzhou", uploaded["id"], "xuning")
        try:
            service.download("xuning", uploaded["id"])
        except BusinessError as error:
            assert error.status == 403
        else:
            raise AssertionError("Revoked recipient unexpectedly accessed core file.")
        assert service.download("zhoulan", uploaded["id"])["content"] == b"core independently works"
        assert service.download("linzhou", uploaded["id"])["content"] == b"core independently works"
        service.share("linzhou", uploaded["id"], "xuning")
        assert service.download("xuning", uploaded["id"])["content"] == b"core independently works"
        service.revoke("linzhou", uploaded["id"], "zhoulan")
        service.revoke("linzhou", uploaded["id"], "xuning")
        assert store.snapshot()["files"][0]["state"] == "private"
        assert service.download("linzhou", uploaded["id"])["content"] == b"core independently works"
    finally:
        store.engine.dispose()
assert not any(name.startswith(("observer_runtime", "bo_observer", "integrations"))
               for name in sys.modules)
print("Core upload/share/revoke/re-share/download and access boundaries passed without observer modules.")
