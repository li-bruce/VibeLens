"""Build the authored graph using canonical source, policy, and database projectors."""
from copy import deepcopy
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "observer_runtime"))
from code_structure import scan, enrich
from behavior_model import capture
from bo_observer.policy.projection import project as project_policy
from bo_observer.data.sync import synchronize
from bo_observer.observation.observation_scope import observer_exclusion, endpoint_paths


def read(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def write(name, value):
    path = ROOT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    discovery, sync = read("discovery.json"), read("sync.json")
    requirements = [item["id"] for item in read("intent.json")["requirements"]]
    checks = [item["id"] for item in read("acceptance.json")["checks"]]
    for decision in discovery["decisions"]:
        decision["links"] = {"requirements": requirements,
                             "model_nodes": [node["id"] for node in discovery["networks"][0]["nodes"]],
                             "checks": checks}
    write("discovery.json", discovery)
    code_files = sorted(
        path.relative_to(ROOT).as_posix()
        for folder in ("app", "integrations") for path in (ROOT / folder).rglob("*.py")
    ) + ["bo_stategraph/workflow.py", "bo_stategraph/query.py", "bo_stategraph/driver.py", "server.py", "run.py"]
    sync["code_files"] = code_files
    sync["source_scope"]["exclude"].pop("bo_stategraph/driver.py", None)
    sync["source_scope"]["exclude"]["app/templates/**"] = (
        "Declarative HTML forms; all handler source is inventoried and forms are browser-tested.")
    sync["source_scope"]["exclude"]["app/static/**"] = (
        "Stylesheet only; HTML and CSS are build-bound and browser-checked.")
    watched = ["bo_stategraph/__init__.py", "bo_stategraph/bo_contracts.py",
               "bo_stategraph/execution_contract.py", "bo_stategraph/driver.py",
               "bo_stategraph/runtime-version.json", "tooling/build_model.py",
               "tooling/observe.py", "tooling/scenarios.py", "tooling/export_models.py",
               "requirements.txt", "app/static/app.css", "app/static/favicon.svg", "review/design-dialogue.md",
               "bo_stategraph/databases.json", "bo_stategraph/model-declaration.json",
               "pytest.ini", "AGENTS.md", "tests/test_business.py", "ownership.json",
               "tooling/check.py", "tooling/write_review.py", "tooling/core_smoke.py",
               "review/browser_acceptance.py", "review/revocation-design-dialogue.md",
               "review/known-framework-limitations.md"]
    watched += sorted(path.relative_to(ROOT).as_posix()
                      for path in (ROOT / "app/templates").glob("*.html"))
    sync["watch_files"] = watched
    write("sync.json", sync)
    index = scan(ROOT, code_files)
    if index["errors"]:
        raise ValueError(index["errors"])
    bindings = {
        "login": ("FileService.login", {"username": "string"},
                  {"authenticated": "boolean", "actor_id": "string"}, "return", "R_LOGIN"),
        "session_lookup": ("FileService.current_user", {},
                  {"authenticated": "boolean", "actor_id": "string"}, "return", "R_LOGIN"),
        "logout": ("FileService.logout", {"actor_id": "string"},
                  {"authenticated": "boolean"}, "commit", "R_LOGIN"),
        "upload": ("FileService.upload", {"actor_id": "string", "filename": "string", "size": "number"},
                  {"file_id": "string", "owner_id": "string", "state": "string", "sha256": "string"},
                  "commit", "R_UPLOAD"),
        "choose_recipient": ("FileService.users", {"actor_id": "string"},
                  {"user_ids": ["string"]}, "return", "R_SHARE"),
        "received_list": ("FileService.list_files", {"actor_id": "string"},
                  {"file_ids": ["string"], "count": "number"}, "return", "R_ACCESS"),
        "file_metadata": ("FileService.metadata", {"actor_id": "string", "file_id": "string"},
                  {"filename": "string", "size": "number", "owner_id": "string"}, "return", "R_ACCESS"),
        "share": ("FileService.share",
                  {"actor_id": "string", "file_id": "string", "recipient_id": "string"},
                  {"state": "string", "changed": "boolean", "recipient_id": "string"},
                  "commit", "R_SHARE"),
        "revoke": ("FileService.revoke",
                  {"actor_id": "string", "file_id": "string", "recipient_id": "string"},
                  {"state": "string", "changed": "boolean", "recipient_id": "string",
                   "owner_id": "string", "remaining_recipient_ids": ["string"]},
                  "commit", "R_REVOKE"),
        "download": ("FileService.download", {"actor_id": "string", "file_id": "string"},
                  {"size": "number", "sha256": "string"}, "return", "R_ACCESS"),
        "authorization": ("FileService.authorise",
                  {"operation": "string", "actor_id": "string", "file_id": "string",
                   "recipient_id": "string", "fact_revision": "string"},
                  {"allowed": "boolean", "decision": "string"}, "decision", "R_ACCESS"),
    }
    design_nodes = {n["id"]: n for n in discovery["networks"][0]["nodes"]}
    nodes = []
    for identity, spec in bindings.items():
        symbol, inputs, outputs, phase, requirement = spec
        nodes.append({
            "id": identity, "kind": "decision" if identity == "authorization" else "action",
            "layer": "business",
            "label": design_nodes.get(identity, {}).get("label", identity.replace("_", " ")),
            "summary": "Authoritative application operation: " + symbol,
            "source": {"path": "app/service.py", "symbol": symbol},
            "capture": {"in": inputs, "out": outputs}, "requirements": [requirement],
        })
    for identity in ("owned_file", "unrelated_user", "access_denied", "recipient_grant", "retained_access"):
        nodes.append({"id": identity, "kind": "data", "layer": "design",
                      "label": design_nodes[identity]["label"],
                      "summary": "Confirmed ownership or access consequence; values come from actual storage and decisions.",
                      "capture": {"in": {}, "out": {}}, "requirements": ["R_ACCESS"]})
    states = ["pending", "private", "shared"]
    machine = {
        "engine": "bo.fsm", "version": "1", "states": states, "values": states,
        "initial": "pending", "state_type": "enum",
        "transitions": [
            {"trigger": "upload", "source": "pending", "dest": "private",
             "conditions": "permission_granted"},
            {"trigger": "share", "source": "private", "dest": "shared",
             "conditions": "permission_granted"},
            {"trigger": "share", "source": "shared", "dest": "shared",
             "conditions": "permission_granted"},
            {"trigger": "revoke", "source": "shared", "dest": "shared",
             "conditions": ["permission_granted", "has_recipients"]},
            {"trigger": "revoke", "source": "shared", "dest": "private",
             "conditions": "permission_granted", "unless": "has_recipients"},
        ],
        "events": {"upload": {"payload": {}}, "share": {"payload": {}}, "revoke": {"payload": {}}},
        "context": {"owner_id": {"type": "string"}, "filename": {"type": "string"},
                    "size": {"type": "integer", "min": 0},
                    "recipient_ids": {"type": "array", "items": {"type": "string"}},
                    "sha256": {"type": "string"}},
        "guards": {"permission_granted": "The current native policy evaluation returned true.",
                   "has_recipients": "The same transaction's remaining recipient list is nonempty."},
    }
    nodes += [{"id": "state." + state, "kind": "state", "layer": "state",
               "value": state, "label": state, "summary": "Persisted file lifecycle: " + state}
              for state in states]
    edges = [{"id": e["id"], "from": e["from"], "to": e["to"], "type": e["relation"],
              "label": e["label"], "evidence": "Confirmed simulated trial scope"}
             for e in discovery["networks"][0]["edges"]]
    for position, transition in enumerate(machine["transitions"]):
        edges.append({"id": "state.transition." + str(position),
                      "from": "state." + transition["source"],
                      "to": "state." + transition["dest"], "type": "flow",
                      "event": transition["trigger"], "conditions": transition["conditions"],
                      "label": transition["trigger"], "evidence": "Native executable declaration",
                      **({"unless": transition["unless"]} if "unless" in transition else {})})
    policy = deepcopy(discovery["policy"])
    policy["stage"] = "bound"
    for predicate in policy["predicates"]:
        predicate["source"] = {"path": "app/predicates.py", "symbol": predicate["id"]}
        predicate["implementation_node"] = "predicate." + predicate["id"]
        nodes.append({"id": predicate["implementation_node"], "kind": "function",
                      "layer": "program", "parent": "authorization",
                      "label": predicate["id"], "summary": "Explicit native predicate binding.",
                      "source": predicate["source"], "capture": {"in": {}, "out": {}}})
    model = {
        "schema_version": 3, "revision": read("intent.json")["revision"], "project_id": discovery["project_id"],
        "title": discovery["title"], "intent": "intent.json", "nodes": nodes, "edges": edges,
        "machine": machine, "policy": policy,
        "graph_roots": list(dict.fromkeys(list(design_nodes) + ["session_lookup", "logout", "file_metadata", "authorization"])),
        "overview": [{"node": name} for name in ("login", "upload", "share", "revoke", "received_list", "download")],
        "scope": {"unknowns": [
            "Finite local synthetic-data cases; no production or independent human acceptance.",
            "Unresolved library/dynamic calls remain static unknowns and are not execution proof.",
            "Registration, editing, deletion, online preview, public links and teams are excluded.",
            "Canonical Boolean data-event versus guard-edge replay matching is a user-reported known limitation; this project does not patch it.",
        ]},
        "presentation": {"subject": discovery["title"], "layout_id": discovery["layout_id"]},
        "source_files": sorted(set(code_files + watched + [
            "intent.json", "discovery.json", "sync.json", "acceptance.json",
            "whitebox.json", "mapping.json", "implementation.json"])),
    }
    model = project_policy(model)
    operations = []
    for identity, action, source, parent in [
        ("db.read", "read", "Store.query", "authorization"),
        ("db.write", "write", "Store.write", "owned_file"),
        ("db.tx", "transaction", "Store.transaction", "owned_file"),
        ("db.metadata", "transform", "project_metadata", "received_list"),
    ]:
        operations.append({
            "id": identity, "label": identity, "parent": parent,
            "source": {"path": "app/service.py" if action == "transform" else "app/store.py", "symbol": source},
            "store": "files", "action": action,
            "targets": ["table:users", "table:sessions", "table:files", "table:shares"] if action in {"read", "write"} else [],
            "parameters": {"query_name": "string"} if action in {"read", "write"} else {},
            "before": {"count": "number"} if action == "transform" else {},
            "after": {"count": "number"} if action in {"read", "write", "transform"} else {},
            "required_cases": ["normal", "database_rollback"] if action in {"write", "transaction"} else ["normal"],
            "failure_cases": ["database_rollback"] if action in {"write", "transaction"} else [],
            "requirements": ["R_STORAGE"],
        })
        if action in {"read", "write"}:
            operations[-1]["target_actions"] = {target: action for target in operations[-1]["targets"]}
        if action in {"read", "write", "transaction"}:
            operations[-1]["required_cases"] += ["revoke_owner", "revoke_last_recipient", "revoke_idempotent"]
    database = {
        "protocol": "bo-databases/v1",
        "stores": [{"id": "files", "label": "Local SQLite", "engine": "sqlalchemy",
                    "url_env": "FILESHARE_DB_URL", "model_layer": "SQLAlchemy Core",
                    "source_files": ["app/models.py", "tooling/export_models.py"],
                    "declaration": "bo_stategraph/model-declaration.json",
                    "selection": {"source": "user", "answer": "Python + SQLite",
                                  "locator": "discovery.json:U1; explicit initial stack choice"}}],
        "operations": operations,
        "exporters": [{"store": "files", "command": ["{python}", "-B", "-X", "utf8", "tooling/export_models.py"],
                       "output": "bo_stategraph/model-declaration.json"}],
    }
    write("bo_stategraph/databases.json", database)
    plan = {"schema": "bo-implementation/v1", "features": [], "support": {}, "excluded": {}}
    route_sources = {
        "login": ["login_page", "login_action"], "session_lookup": ["session_info"],
        "logout": ["logout_action"], "upload": ["upload_action"],
        "choose_recipient": ["user_list"], "received_list": ["file_list"],
        "file_metadata": ["file_info"], "share": ["share_action"], "download": ["download_file"],
        "revoke": ["revoke_action"],
    }
    for identity, spec in bindings.items():
        symbol, inputs, outputs, phase, requirement = spec
        sources = ["app/service.py::" + symbol]
        sources += ["app/web.py::" + name for name in route_sources.get(identity, [])]
        feature_nodes = [identity]
        if identity == "authorization":
            feature_nodes += [n["id"] for n in model["nodes"]
                              if n.get("origin") == "policy-definition" and any(n.get("capture", {}).values())]
        parameters = []
        for source in sources:
            for parameter in index["symbols"][source]["parameters"]:
                name = parameter["name"]
                if name == "self":
                    continue
                field, direction, policy_kind, reason = name, "in", "value", ""
                if name in {"password", "token"}:
                    field, direction, policy_kind, reason = (
                        "authenticated", "out", "derived",
                        "Only the actual authentication outcome is captured; credentials are never collected.")
                elif name == "content":
                    field, policy_kind, reason = "size", "derived", "Capture byte length and output SHA256, never file content."
                elif name == "filename":
                    policy_kind, reason = "derived", "The stored normalized basename is captured; discard any supplied path."
                elif name == "connection":
                    field, policy_kind, reason = "fact_revision", "derived", "The connection is represented by the selected request/file read basis; never serialize connections."
                elif name == "row":
                    field, policy_kind, reason = "file_id", "derived", "Capture selected file identity, never the row containing file bytes."
                parameters.append({"source": source, "name": name, "node": identity, "direction": direction,
                                   "field": field, "policy": policy_kind, **({"reason": reason} if reason else {})})
        case_name = "revoke_owner" if identity == "revoke" else "normal"
        cases = [{"case": case_name, "node": identity, "phase": phase}]
        witnesses = {
            "upload": [("in", "filename", ["uploaded_filename"]),
                       ("in", "size", ["uploaded_size"]),
                       ("out", "owner_id", ["owner_id"]),
                       ("out", "sha256", ["stored_sha256"])],
            "download": [("out", "size", ["download_size"]),
                         ("out", "sha256", ["download_sha256"])],
            "file_metadata": [("out", field, ["metadata", field])
                              for field in ("filename", "size", "owner_id")],
            "revoke": [("in", "recipient_id", ["recipient_id"]),
                       ("out", "remaining_recipient_ids", ["remaining_after_revoke"]),
                       ("out", "state", ["revoke_state"]),
                       ("out", "owner_id", ["owner_id"])],
        }
        if identity in witnesses:
            cases[0]["values"] = [{"direction": direction, "field": field, "path": path}
                                  for direction, field, path in witnesses[identity]]
        if identity == "authorization":
            cases += [{"case": "normal", "node": node, "phase": "decision"} for node in feature_nodes[1:]]
        plan["features"].append({"id": identity, "label": identity, "business_node": identity,
                                  "nodes": feature_nodes, "sources": sources, "parameters": parameters,
                                  "cases": cases, "requirements": [requirement]})
    for operation in operations:
        source = operation["source"]["path"] + "::" + operation["source"]["symbol"]
        params = []
        for parameter in index["symbols"][source]["parameters"]:
            name = parameter["name"]
            if name == "self":
                continue
            direction = "in"
            field = "before" if operation["action"] == "transform" else "parameters"
            if operation["action"] == "transform":
                direction = "out"
            params.append({"source": source, "name": name, "node": operation["id"],
                           "direction": direction, "field": field, "policy": "derived",
                           "reason": "Capture only the safe operation label or selected counts; raw clients, SQL bindings, and row content remain private."})
        plan["features"].append({
            "id": operation["id"], "label": operation["label"],
            "business_node": operation["parent"] if operation["parent"] in bindings else "upload",
            "nodes": [operation["id"]], "sources": [source], "parameters": params,
            "cases": [{"case": "normal", "node": operation["id"],
                       "phase": "commit" if operation["action"] == "transaction" else "change" if operation["action"] == "transform" else "return"}],
            "requirements": ["R_STORAGE"],
        })
    classified = {source for feature in plan["features"] for source in feature["sources"]}
    for source, symbol in index["symbols"].items():
        if symbol["kind"] != "function" or source in classified:
            continue
        item = {"category": "observer", "reason": "Exact optional observer adapter, query endpoint, or neutral capture port."}
        routes = endpoint_paths(symbol)
        if routes:
            item["routes"] = routes
        if observer_exclusion(symbol, item) and symbol["path"] != "bo_stategraph/driver.py":
            plan["excluded"][source] = item
        else:
            plan["support"][source] = {
                "node": "authorization" if "predicate" in source or "workflow" in source else "owned_file" if "store" in source or "query.py" in source else "login",
                "reason": "Project helper remains statically mapped; only actual emitted boundaries count as runtime evidence.",
            }
    model["implementation"] = plan
    write("implementation.json", plan)
    selection = read("bo_stategraph/project.json")["selection"]
    write("bo_stategraph/project.json", {"protocol": "bo-project/v1",
          "project_id": discovery["project_id"], "selection": selection, "model": model})
    os.environ.setdefault("FILESHARE_DB_URL", "sqlite:///data/files.sqlite3")
    result = synchronize(ROOT)
    if not result["valid"]:
        raise ValueError(result["errors"])
    project = read("bo_stategraph/project.json")
    project["model"] = project_policy(enrich(project["model"], index, depth=1))
    write("bo_stategraph/project.json", project)
    write("manifest.json", capture(ROOT, project["model"]))
    print(json.dumps({"valid": True, "nodes": len(project["model"]["nodes"]),
                      "features": len(plan["features"]), "source_files": len(code_files)}))


if __name__ == "__main__":
    main()
