"""Repeatable headless browser acceptance over the app, recording, and replay."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sqlite3
import time
import uuid

from playwright.sync_api import expect, sync_playwright

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--app", default="http://127.0.0.1:8840")
    parser.add_argument("--graph", default="http://127.0.0.1:8841")
    args = parser.parse_args()
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:6]
    output = ROOT / "review" / "browser" / stamp
    output.mkdir(parents=True)
    report = {"status": "running", "app": args.app, "graph": args.graph,
              "provenance": "Automated browser trial with synthetic data; not independent human acceptance.",
              "checks": [], "page_errors": [], "console_errors": [],
              "expected_http_console_errors": []}
    expected_denials = set()
    content = b"Browser-verified private file sharing.\n"
    filename = "browser-handoff-" + stamp + ".txt"
    try:
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(headless=True, args=["--no-proxy-server"])
            try:
                contexts = [browser.new_context(accept_downloads=True,
                            viewport={"width": 1450, "height": 1000}) for _ in range(4)]
                owner, recipient, unrelated, graph = [context.new_page() for context in contexts]
                for page in (owner, recipient, unrelated, graph):
                    page.on("pageerror", lambda error: report["page_errors"].append(str(error)))
                    def capture_console(message):
                        if message.type != "error":
                            return
                        expected = (message.location.get("url") in expected_denials
                                    and "403 (FORBIDDEN)" in message.text)
                        key = "expected_http_console_errors" if expected else "console_errors"
                        report[key].append({"message": message.text, "location": message.location})
                    page.on("console", capture_console)
                graph.goto(args.graph + "/graph", wait_until="domcontentloaded")
                expect(graph.locator("#canvas-host canvas")).to_be_visible(timeout=20000)
                expect(graph.locator("#record-start")).to_be_enabled(timeout=20000)
                before = graph.request.get(args.graph + "/api/view").json()
                with graph.expect_response(lambda response: response.url.endswith("/api/recordings/start")) as started:
                    graph.locator("#record-start").click()
                assert started.value.status == 200
                recording_id = started.value.json()["id"]
                report["recording_id"] = recording_id
                assert len(graph.request.get(args.graph + "/api/view").json()["events"]) == len(before["events"])
                report["checks"].append("Starting a real recording creates no business events.")

                def login(page, user):
                    page.goto(args.app + "/login", wait_until="networkidle")
                    page.select_option("#username", user)
                    page.fill("#password", "trial-" + user)
                    page.locator('[data-testid="login-form"] button').click()
                    page.wait_for_url(args.app + "/")
                    expect(page.locator('[data-testid="current-user"]')).to_be_visible()

                login(owner, "linzhou")
                owner.screenshot(path=str(output / "owner-empty.png"), full_page=True)
                owner.locator("#file").set_input_files(
                    {"name": filename, "mimeType": "text/plain", "buffer": content})
                owner.locator('[data-testid="upload-form"] button').click()
                owner.wait_for_url("**/?notice=uploaded")
                owner_row = owner.locator('[data-testid="owned-section"] tr').filter(has_text=filename)
                expect(owner_row).to_be_visible()
                file_id = owner_row.get_attribute("data-file-id")
                owner_row.locator('select[name="recipient_id"]').select_option("xuning")
                owner_row.locator('[data-testid="share-form"] button').click()
                owner.wait_for_url("**/?notice=shared")
                owner_row = owner.locator('[data-testid="owned-section"] tr').filter(has_text=filename)
                expect(owner_row.locator(".recipient-chip")).to_have_text("许宁")
                owner.screenshot(path=str(output / "owner-shared.png"), full_page=True)
                report["checks"].append("Owner uploads, selects an existing recipient, and sees the saved relationship.")

                login(recipient, "xuning")
                row = recipient.locator('[data-testid="received-section"] tr').filter(has_text=filename)
                expect(row).to_be_visible()
                expect(row).to_contain_text("林舟")
                expect(row).to_contain_text(str(len(content)) + " B")
                assert row.locator('[data-testid="share-form"]').count() == 0
                with recipient.expect_download() as pending_download:
                    row.locator('[data-testid="download"]').click()
                download = pending_download.value
                assert download.suggested_filename == filename
                download_path = output / "downloaded-synthetic-file.txt"
                download.save_as(str(download_path))
                assert download_path.read_bytes() == content
                recipient.screenshot(path=str(output / "recipient.png"), full_page=True)
                report["checks"].append("Recipient sees filename, size, and sharer, has no share control, and downloads exact bytes.")

                login(unrelated, "zhoulan")
                assert unrelated.locator('[data-testid="received-section"]').get_by_text(filename).count() == 0
                assert unrelated.request.get(args.app + f"/api/files/{file_id}").status == 403
                assert unrelated.request.get(args.app + f"/api/files/{file_id}/download").status == 403
                csrf = unrelated.request.get(args.app + "/api/session").json()["csrf"]
                rejected = unrelated.request.post(args.app + f"/api/files/{file_id}/share",
                    data={"recipient_id": "xuning"}, headers={"X-CSRF-Token": csrf})
                assert rejected.status == 403
                unrelated.screenshot(path=str(output / "unrelated.png"), full_page=True)
                report["checks"].append("Unrelated user cannot see the file and direct view/download/share requests are denied.")

                recipient.goto(args.app + "/?lang=en", wait_until="networkidle")
                expect(recipient.get_by_role("heading", name="Shared with me")).to_be_visible()
                recipient.screenshot(path=str(output / "recipient-english.png"), full_page=True)
                recipient.set_viewport_size({"width": 390, "height": 844})
                assert recipient.evaluate("document.documentElement.scrollWidth <= window.innerWidth")
                recipient.screenshot(path=str(output / "recipient-mobile.png"), full_page=True)
                report["checks"].append("English selection and a narrow desktop-browser viewport remain usable.")

                with sqlite3.connect((ROOT / "data/files.sqlite3").as_uri() + "?mode=ro", uri=True) as db:
                    saved = db.execute("SELECT owner_id,filename,size,content,state FROM files WHERE id=?", (file_id,)).fetchone()
                    recipients = db.execute("SELECT recipient_id,shared_by FROM shares WHERE file_id=?", (file_id,)).fetchall()
                assert saved == ("linzhou", filename, len(content), content, "shared")
                assert recipients == [("xuning", "linzhou")]
                report["checks"].append("Independent SQLite reads match ownership, recipient, state, size, name, and bytes.")

                def api_post(page, path, data=None, multipart=None):
                    token = page.request.get(args.app + "/api/session").json()["csrf"]
                    options = {"headers": {"X-CSRF-Token": token}}
                    if multipart is not None:
                        options["multipart"] = multipart
                    else:
                        options["data"] = data or {}
                    return page.request.post(args.app + path, **options)

                assert row.locator('[data-testid="revoke-form"]').count() == 0
                old_download_url = args.app + row.locator('[data-testid="download"]').get_attribute("href")
                old_page_html = recipient.content()
                old_page_url = recipient.url
                assert api_post(owner, f"/api/files/{file_id}/share",
                                {"recipient_id": "zhoulan"}).status == 200
                owner_row = owner.locator('[data-testid="owned-section"] tr').filter(has_text=filename)
                owner_row.locator('[data-recipient-id="xuning"] [data-testid="revoke-form"] button').click()
                owner.wait_for_url("**/?notice=revoked")
                expect(owner_row.locator(".recipient-chip")).to_have_text("周岚")
                assert recipient.url == old_page_url and recipient.content() == old_page_html
                owner.screenshot(path=str(output / "owner-revoked-one-recipient.png"), full_page=True)
                expected_denials.add(old_download_url)
                with recipient.expect_response(lambda response: response.url == old_download_url) as denied:
                    row.locator('[data-testid="download"]').click()
                assert denied.value.status == 403
                expect(recipient.locator(".error-page .eyebrow")).to_have_text("access_denied")
                recipient.screenshot(path=str(output / "recipient-stale-page-denied.png"), full_page=True)
                assert unrelated.request.get(args.app + f"/api/files/{file_id}/download").body() == content
                assert owner.request.get(args.app + f"/api/files/{file_id}/download").body() == content
                with sqlite3.connect((ROOT / "data/files.sqlite3").as_uri() + "?mode=ro", uri=True) as db:
                    relations_after = db.execute("SELECT recipient_id FROM shares WHERE file_id=?", (file_id,)).fetchall()
                    identity_after = db.execute("SELECT owner_id,state FROM files WHERE id=?", (file_id,)).fetchone()
                assert relations_after == [("zhoulan",)]
                assert identity_after == ("linzhou", "shared")
                report["checks"].append("Owner cancels only Xuning's relation; the unchanged recipient page's actual next download is 403, while owner and Zhoulan retain exact-byte access.")
                owner_row.locator('select[name="recipient_id"]').select_option("xuning")
                owner_row.locator('[data-testid="share-form"] button').click()
                owner.wait_for_url("**/?notice=shared")
                recipient.goto(args.app + "/", wait_until="networkidle")
                restored_row = recipient.locator('[data-testid="received-section"] tr').filter(has_text=filename)
                expect(restored_row).to_be_visible()
                with recipient.expect_download() as restored_download:
                    restored_row.locator('[data-testid="download"]').click()
                restored_path = output / "reshared-synthetic-file.txt"
                restored_download.value.save_as(str(restored_path))
                assert restored_path.read_bytes() == content
                report["checks"].append("The owner can share to Xuning again and the recipient downloads the same bytes.")

                second_name = "last-recipient-" + stamp + ".txt"
                second = api_post(owner, "/api/files", multipart={"file": {
                    "name": second_name, "mimeType": "text/plain", "buffer": content}})
                assert second.status == 201
                second_id = second.json()["id"]
                assert api_post(owner, f"/api/files/{second_id}/share", {"recipient_id": "xuning"}).status == 200
                last_cancel = api_post(owner, f"/api/files/{second_id}/revoke", {"recipient_id": "xuning"})
                assert last_cancel.status == 200
                assert last_cancel.json()["state"] == "private"
                assert last_cancel.json()["remaining_recipient_ids"] == []
                assert recipient.request.get(args.app + f"/api/files/{second_id}/download").status == 403
                assert owner.request.get(args.app + f"/api/files/{second_id}/download").body() == content
                assert recipient.request.get(old_download_url).body() == content
                assert unrelated.request.get(args.app + f"/api/files/{file_id}/download").body() == content
                assert api_post(owner, f"/api/files/{second_id}/share", {"recipient_id": "xuning"}).status == 200
                assert recipient.request.get(args.app + f"/api/files/{second_id}/download").body() == content
                report["secondary_file_id"] = second_id
                report["checks"].append("Cancelling the last recipient produces private state without removing file bytes or owner access, leaves another file unchanged, and re-sharing restores access.")

                drain_started = time.monotonic()
                deadline = drain_started + 900
                drain_samples = []
                report["drain_wait_predicate"] = "Native flush() observes queue.unfinished_tasks == 0; final pending is zero, accepted event count equals stable enqueued event count, and errors/drops/gaps are zero. No count target substitutes for queue completion."
                while True:
                    flushed = owner.request.post(args.app + "/api/stategraph/flush", data={})
                    assert flushed.status == 200
                    diagnostics = flushed.json()
                    live = graph.request.get(args.graph + "/api/view").json()
                    sample = {"elapsed_seconds": round(time.monotonic() - drain_started, 3),
                              "flush_http_status": flushed.status, **diagnostics,
                              "accepted_events": len(live["events"]) - len(before["events"]),
                              "accepted_state_frames": len(live["runtime_frames"]["frames"])}
                    if diagnostics["errors"] == 0 and diagnostics["dropped"] == 0:
                        sample["sent_envelopes"] = (diagnostics["enqueued_events"]
                            + diagnostics["enqueued_snapshots"] - diagnostics["pending_envelopes"])
                    drain_samples.append(sample)
                    report["drain_progress"] = drain_samples
                    (output / "drain-progress.json").write_text(
                        json.dumps(drain_samples, indent=2), encoding="utf-8")
                    assert diagnostics["errors"] == 0 and diagnostics["dropped"] == 0, diagnostics
                    if len(drain_samples) > 1:
                        previous = drain_samples[-2]
                        assert sample["enqueued_events"] == previous["enqueued_events"], "Capture source still generating events during drain."
                        assert sample["enqueued_snapshots"] == previous["enqueued_snapshots"]
                        assert sample["pending_envelopes"] <= previous["pending_envelopes"]
                        assert sample["accepted_events"] >= previous["accepted_events"]
                    if len(drain_samples) >= 7:
                        earlier = drain_samples[-7]
                        assert (sample["pending_envelopes"] < earlier["pending_envelopes"]
                                or diagnostics["flushed"]), "No actual queue progress across six flush samples; diagnose before retrying."
                    if diagnostics["flushed"] or time.monotonic() >= deadline:
                        break
                report["last_flush_response"] = diagnostics
                assert diagnostics["flushed"] is True, diagnostics
                assert diagnostics["pending_envelopes"] == 0
                assert sample["accepted_events"] == diagnostics["enqueued_events"]
                assert sample["accepted_state_frames"] == diagnostics["enqueued_snapshots"]
                report["drain_wait_seconds"] = round(time.monotonic() - drain_started, 3)
                view = graph.request.get(args.graph + "/api/view").json()
                assert view["binding_status"]["status"] == "current"
                assert all(any(event["node"] == node for event in view["events"])
                           for node in ("login", "upload", "share", "download", "authorization"))
                build_id = view["manifest"]["build_id"]
                assert owner.request.get(args.app + "/api/stategraph/health").json()["build_id"] == build_id
                assert json.loads((ROOT / "manifest.json").read_text(encoding="utf-8"))["build_id"] == build_id
                count = len(view["events"])
                graph.request.get(args.graph + "/api/source?path=app/service.py")
                graph.request.get(args.graph + "/api/preferences")
                owner.request.get(args.app + "/api/stategraph")
                owner.request.get(args.app + "/api/stategraph/export")
                assert len(graph.request.get(args.graph + "/api/view").json()["events"]) == count
                report["checks"].append("App and graph share a current build; graph/source/query controls create no business events.")

                expect(graph.locator("#record-stop")).to_be_enabled(timeout=10000)
                with graph.expect_response(lambda response: response.url.endswith("/api/recordings/stop")) as stopped:
                    graph.locator("#record-stop").click()
                assert stopped.value.status == 200
                assert stopped.value.json()["id"] == recording_id
                recording = graph.request.get(args.graph + "/api/recordings/" + recording_id).json()
                assert recording["status"] == "stopped"
                assert not recording["gaps"], recording["gaps"]
                assert len(recording["events"]) > 0
                frames = [frame for frame in recording["runtime_frames"]["frames"]
                          if frame["authority"]["entity"] == file_id]
                assert [frame["machine"]["current"] for frame in frames] == ["pending", "private", "shared", "shared", "shared", "shared"]
                assert frames[1]["machine"]["journal"][0]["source"] == "pending"
                assert frames[1]["machine"]["journal"][0]["target"] == "private"
                assert frames[2]["machine"]["journal"][0]["source"] == "private"
                assert frames[2]["machine"]["journal"][0]["target"] == "shared"
                assert frames[4]["machine"]["configurations"][0]["context"]["recipient_ids"] == ["zhoulan"]
                assert frames[4]["machine"]["configurations"][0]["state_journal"][-1]["guards"] == {"permission_granted": True, "has_recipients": True}
                second_frames = [frame for frame in recording["runtime_frames"]["frames"]
                                 if frame["authority"]["entity"] == second_id]
                assert [frame["machine"]["current"] for frame in second_frames] == ["pending", "private", "shared", "private", "shared"]
                assert second_frames[3]["machine"]["configurations"][0]["state_journal"][-1]["guards"] == {"permission_granted": True, "has_recipients": False}
                expect(graph.locator("#replay")).to_be_visible(timeout=15000)
                replay_witnesses = []
                timeline_input = {key: recording[key] for key in
                                  ("events", "commands", "status", "started_at", "ended_at")}
                for entity, node, state in ((file_id, "upload", "private"), (file_id, "share", "shared"),
                                            (file_id, "revoke", "shared"), (second_id, "revoke", "private")):
                    event = next(event for event in recording["events"]
                                 if event["node"] == node and event["phase"] == "commit"
                                 and event["entity"] == entity)
                    event_index = graph.evaluate("""async ({recording, id}) => {
                        const { timeline } = await import('/recording.js');
                        return timeline(recording).findIndex(event => event.id === id);
                    }""", {"recording": timeline_input, "id": event["id"]})
                    assert event_index > 0
                    graph.locator("#replay-events").select_option(str(event_index))
                    expect(graph.locator("#replay-position")).to_have_attribute("data-event-id", event["id"])
                    expect(graph.locator(f'[data-node-id="state.{state}"]')).to_have_attribute("data-run-state", "active")
                    replay_witnesses.append({"event_id": event["id"], "state": state,
                                             "timeline_index": event_index})
                report["replay_witnesses"] = replay_witnesses
                graph.screenshot(path=str(output / "graph-replay.png"), full_page=True)
                graph.locator("#replay-next").click()
                graph.locator("#replay-live").click()
                expect(graph.locator("#replay")).to_be_hidden(timeout=10000)
                graph.reload(wait_until="domcontentloaded")
                expect(graph.locator("#canvas-host canvas")).to_be_visible(timeout=15000)
                graph.wait_for_function("document.querySelector('#semantic').children.length > 0", timeout=20000)
                expect(graph.locator("#connection")).not_to_have_text("连接中", timeout=20000)
                expect(graph.locator("#project-title")).to_have_text("文件共享：用户、所有者与接收者")
                listing = graph.request.get(args.graph + "/api/recordings").json()
                assert recording_id in json.dumps(listing)
                graph.screenshot(path=str(output / "graph-live.png"), full_page=True)
                report["checks"].append("Real operation recording retains pending/private/shared frames, both revoke outcomes and actual transition witnesses, has no gaps, and replays exact event IDs after reload.")
                assert "trial-linzhou" not in json.dumps(recording["events"])
                assert content.decode().strip() not in json.dumps(recording["events"])
                assert not report["page_errors"], report["page_errors"]
                assert not report["console_errors"], report["console_errors"]
                (output / "recording.json").write_text(json.dumps(recording, ensure_ascii=False), encoding="utf-8")
                report.update(status="passed", build_id=build_id, recording_id=recording_id,
                              file_id=file_id, event_count=len(recording["events"]),
                              downloaded_sha256=hashlib.sha256(content).hexdigest(),
                              state_frames=[frame["machine"]["current"] for frame in frames],
                              secondary_state_frames=[frame["machine"]["current"] for frame in second_frames],
                              framework_boolean_edge_animation="Known user-reported data/guard replay matching limitation retained; not patched or claimed resolved.")
            finally:
                browser.close()
    except Exception as error:
        report.update(status="failed", error=f"{type(error).__name__}: {error}")
        raise
    finally:
        (output / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        (ROOT / "review/browser-latest.json").write_text(json.dumps(
            {"report": str(output / "report.json"), "status": report["status"]}, indent=2), encoding="utf-8")
        print(json.dumps({"status": report["status"], "report": str(output / "report.json")}, ensure_ascii=True))


if __name__ == "__main__":
    main()
