"""Audit real evidence and checker sensitivity using isolated copies only."""
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import sys
import tempfile
from urllib.request import build_opener, ProxyHandler

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "observer_runtime"))
from implementation_coverage import runtime_errors as coverage_errors
from mapping_contract import assess_projections
from behavior_model import check as check_binding
from bo_observer.data.catalog import collect, export_sqlalchemy_metadata
from bo_observer.data.schema_compare import structure_differences
from sqlalchemy import text
from sqlalchemy.dialects.sqlite import dialect
from app.models import metadata
from app.store import Store
from app.ports import BOEvents
from bo_stategraph import bo_validate_export


def read(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8-sig"))


def rejected(action):
    try:
        result = action()
    except (ValueError, AssertionError, KeyError) as error:
        return {"rejected": True, "reason": str(error)}
    errors = result[0] if isinstance(result, tuple) else result.get("errors", [])
    return {"rejected": bool(errors), "errors": errors[:3]}


def flat_witnesses(recording, file_id, stored_journal):
    frames = {frame["event_id"]: frame for frame in recording["runtime_frames"]["frames"]}
    matched = []
    for item in stored_journal:
        events = [event for event in recording["events"]
                  if event["entity"] == file_id and event["node"] == item["event"]
                  and event["phase"] == "commit" and event["revision"] == item["seq"]]
        assert len(events) == 1, "Missing unique actual transition event."
        frame = frames.get(events[0]["id"])
        assert frame is not None, "Missing exact transition frame."
        assert frame["machine"]["current"] == item["after"]
        assert any(witness["event"] == item["event"]
                   and witness["source"] == item["before"]
                   and witness["target"] == item["after"]
                   for witness in frame["machine"]["journal"]), "Missing actual transition path witness."
        configuration = frame["machine"]["configurations"][0]
        assert configuration["state_journal"][-1] == item
        expected_guards = {"permission_granted": True}
        if item["event"] == "revoke":
            expected_guards["has_recipients"] = item["after"] == "shared"
        assert item["guards"] == expected_guards
        matched.append((item["before"], item["event"], item["after"]))
    return matched


def revoke_target_echo(payload):
    run = next(run for run in payload["runs"]
               if run["case"] == "revoke_owner" and run["mode"] == "on")
    expected = run["observations"]["recipient_id"]
    events = [event for event in run["events"]
              if event["node"] == "revoke" and event["phase"] == "commit"]
    assert len(events) == 1
    assert events[0]["inputs"]["recipient_id"] == expected
    assert events[0]["outputs"]["recipient_id"] == expected
    return {"errors": []}


def main():
    project = read("bo_stategraph/project.json")
    model = project["model"]
    active = read(".stategraph/active.json")["change"]
    receipt = read(active + "/checks/observations.json")
    payload = json.loads(receipt["stdout"])
    manifest = read("manifest.json")
    assert payload["build_id"] == manifest["build_id"], "Refuse stale runtime evidence."
    plan = read("mapping.json")
    clean = coverage_errors(model["implementation"], model, payload, root=ROOT)
    assert not clean["errors"], clean["errors"]
    assert not assess_projections(payload, plan, model, manifest["build_id"])[0]
    assert not revoke_target_echo(payload)["errors"]
    results = {"build_id": manifest["build_id"],
               "scope": "Synthetic trial; counterexamples alter evidence in memory or temporary copies, never the application.",
               "checks": {}}

    missing = deepcopy(payload)
    run = next(run for run in missing["runs"] if run["case"] == "normal" and run["mode"] == "on")
    for event in run["events"]:
        if event["node"] == "download" and event["phase"] == "return":
            del event["outputs"]["sha256"]
    results["checks"]["missing_capture_field"] = rejected(
        lambda: coverage_errors(model["implementation"], model, missing, root=ROOT))
    wrong = deepcopy(payload)
    run = next(run for run in wrong["runs"] if run["case"] == "normal" and run["mode"] == "on")
    for event in run["events"]:
        if event["node"] == "download" and event["phase"] == "return":
            event["outputs"]["size"] += 1
    results["checks"]["incorrect_captured_value"] = rejected(
        lambda: coverage_errors(model["implementation"], model, wrong, root=ROOT))
    missing_revoke = deepcopy(payload)
    run = next(run for run in missing_revoke["runs"]
               if run["case"] == "revoke_owner" and run["mode"] == "on")
    for event in run["events"]:
        if event["node"] == "revoke" and event["phase"] == "commit":
            del event["outputs"]["remaining_recipient_ids"]
    results["checks"]["missing_revoke_capture"] = rejected(
        lambda: coverage_errors(model["implementation"], model, missing_revoke, root=ROOT))
    wrong_revoke = deepcopy(payload)
    run = next(run for run in wrong_revoke["runs"]
               if run["case"] == "revoke_owner" and run["mode"] == "on")
    for event in run["events"]:
        if event["node"] == "revoke" and event["phase"] == "commit":
            event["inputs"]["recipient_id"] = "zhoulan"
    results["checks"]["wrong_revoke_target"] = rejected(
        lambda: coverage_errors(model["implementation"], model, wrong_revoke, root=ROOT))
    wrong_echo = deepcopy(payload)
    run = next(run for run in wrong_echo["runs"]
               if run["case"] == "revoke_owner" and run["mode"] == "on")
    for event in run["events"]:
        if event["node"] == "revoke" and event["phase"] == "commit":
            event["outputs"]["recipient_id"] = "zhoulan"
    results["checks"]["wrong_revoke_output_echo"] = rejected(lambda: revoke_target_echo(wrong_echo))
    results["capture_contract_scope"] = (
        "The native declared value witness binds the input recipient_id. The selected output echo "
        "is type-checked but has no native value witness; this supplementary independent audit "
        "compares both input and output against the scenario's requested target. The initial "
        "unbound-output counterexample remains preserved in evidence-checks-unbound-echo-attempt.json.")
    missing_instance = deepcopy(payload)
    run = next(run for run in missing_instance["runs"] if run["case"] == "normal" and run["mode"] == "on")
    run["projection"]["instances"] = []
    results["checks"]["missing_exported_instance"] = rejected(
        lambda: assess_projections(missing_instance, plan, model, manifest["build_id"]))

    scratch = ROOT / "review/scratch"
    scratch.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(dir=scratch, prefix="evidence-audit-") as directory:
        copy_root = Path(directory).resolve()
        assert copy_root.is_relative_to(scratch.resolve())
        for name in model["source_files"]:
            target = copy_root / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes((ROOT / name).read_bytes())
        predicate = copy_root / "app/predicates.py"
        predicate.write_bytes(predicate.read_bytes() + b"\n# Isolated source-freshness counterexample.\n")
        binding = check_binding(copy_root, model, manifest)
        results["checks"]["unsynchronized_source"] = {
            "rejected": binding["status"] == "stale" and "app/predicates.py" in binding["changed_files"],
            "changed_files": binding["changed_files"],
        }
        store = Store(copy_root / "schema.sqlite3", BOEvents())
        original_env = os.environ.get("SCHEMA_AUDIT_URL")
        os.environ["SCHEMA_AUDIT_URL"] = "sqlite:///" + store.path.as_posix()
        configured = deepcopy(read("bo_stategraph/databases.json")["stores"][0])
        configured["url_env"] = "SCHEMA_AUDIT_URL"
        try:
            declaration = export_sqlalchemy_metadata(metadata, "files", dialect=dialect())
            before = collect(configured, root=ROOT)
            assert not structure_differences(before, declaration)
            with store.engine.begin() as connection:
                connection.execute(text("ALTER TABLE files RENAME COLUMN filename TO stored_filename"))
            after = collect(configured, root=ROOT)
            differences = structure_differences(after, declaration)
            results["checks"]["real_schema_change"] = {
                "rejected": bool(differences), "differences": differences,
                "operation": "A real SQLite column rename in an isolated database copy.",
            }
        finally:
            store.engine.dispose()
            if original_env is None:
                os.environ.pop("SCHEMA_AUDIT_URL", None)
            else:
                os.environ["SCHEMA_AUDIT_URL"] = original_env

    browser_pointer = read("review/browser-latest.json")
    browser_report = json.loads(Path(browser_pointer["report"]).read_text(encoding="utf-8"))
    assert browser_report["status"] == "passed"
    recording_path = Path(browser_pointer["report"]).parent / "recording.json"
    recording = json.loads(recording_path.read_text(encoding="utf-8"))
    assert recording["build_id"] == manifest["build_id"]
    file_id = browser_report["file_id"]
    with sqlite3.connect((ROOT / "data/files.sqlite3").as_uri() + "?mode=ro", uri=True) as connection:
        journal = json.loads(connection.execute("SELECT journal FROM files WHERE id=?", (file_id,)).fetchone()[0])
    paths = flat_witnesses(recording, file_id, journal)
    reduced = deepcopy(recording)
    upload_event = next(event["id"] for event in reduced["events"]
                        if event["entity"] == file_id and event["node"] == "upload" and event["phase"] == "commit")
    reduced["runtime_frames"]["frames"] = [
        frame for frame in reduced["runtime_frames"]["frames"] if frame["event_id"] != upload_event]
    results["checks"]["removed_transition_witness"] = rejected(
        lambda: {"paths": flat_witnesses(reduced, file_id, journal), "errors": []})
    reduced_revoke = deepcopy(recording)
    revoke_event = next(event["id"] for event in reduced_revoke["events"]
                        if event["entity"] == file_id and event["node"] == "revoke"
                        and event["phase"] == "commit")
    reduced_revoke["runtime_frames"]["frames"] = [
        frame for frame in reduced_revoke["runtime_frames"]["frames"]
        if frame["event_id"] != revoke_event]
    results["checks"]["removed_revoke_transition_witness"] = rejected(
        lambda: {"paths": flat_witnesses(reduced_revoke, file_id, journal), "errors": []})
    secondary_id = browser_report["secondary_file_id"]
    with sqlite3.connect((ROOT / "data/files.sqlite3").as_uri() + "?mode=ro", uri=True) as connection:
        secondary_journal = json.loads(connection.execute(
            "SELECT journal FROM files WHERE id=?", (secondary_id,)).fetchone()[0])
    results["secondary_transition_paths"] = flat_witnesses(recording, secondary_id, secondary_journal)
    opener = build_opener(ProxyHandler({}))
    exports = {}
    for name, port in (("application", 8840), ("observer", 8841)):
        with opener.open(f"http://127.0.0.1:{port}/api/stategraph/export", timeout=15) as response:
            exported = json.load(response)
        bo_validate_export(exported)
        exports[name] = {"validated": True, "instances": len(exported["instances"])}
    results["public_exports"] = exports
    results["real_transition_paths"] = paths
    results["baseline_sha256"] = hashlib.sha256((ROOT / ".stategraph/initial-v1/baseline.json").read_bytes()).hexdigest()
    assert results["baseline_sha256"] == "8339139b0637be9abdea6611a1952bccce286954ea2ceca351ec0293456c79f7"
    snapshot_manifest = read(".stategraph/revocation-v2/source-before-manifest.json")
    baseline = read(".stategraph/revocation-v2/baseline.json")
    assert baseline["id"] == "de568f8032081e09018f41908949af30c344eea3526db17bae16a258f218f18f"
    for name, digest in snapshot_manifest["files"].items():
        source = ROOT / ".stategraph/revocation-v2/source-before" / name
        assert hashlib.sha256(source.read_bytes()).hexdigest() == digest
        if name in baseline["files"]:
            assert baseline["files"][name] == digest
    results["revocation_baseline_sha256"] = hashlib.sha256(
        (ROOT / ".stategraph/revocation-v2/baseline.json").read_bytes()).hexdigest()
    results["preserved_source_files"] = len(snapshot_manifest["files"])
    results["status"] = "passed" if all(result["rejected"] for result in results["checks"].values()) else "failed"
    (ROOT / "review/evidence-checks-latest-attempt.json").write_text(
        json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    assert results["status"] == "passed", {
        name: result for name, result in results["checks"].items() if not result["rejected"]}
    results["status"] = "passed"
    (ROOT / "review/evidence-checks.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"status": "passed", "counterexamples": len(results["checks"]),
                      "actual_transition_paths": paths}))


if __name__ == "__main__":
    main()
