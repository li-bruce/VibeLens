"""Project adapter for the canonical native flat-state executor."""
import json
from pathlib import Path
from bo_stategraph.driver import BOExecutor


def definition() -> dict:
    path = Path(__file__).resolve().parent / "project.json"
    return json.loads(path.read_text(encoding="utf-8"))["model"]["machine"]


class FileWorkflow:
    def __init__(self, permission: bool):
        self.permission = permission
        self.executor = BOExecutor(definition(), {"permission_granted": self.permission_granted,
                                                  "has_recipients": self.has_recipients})

    def permission_granted(self, context: dict, payload: dict) -> bool:
        return self.permission is True

    def has_recipients(self, context: dict, payload: dict) -> bool:
        return bool(context["recipient_ids"])

    def apply(self, state: str, event: str, context: dict) -> dict:
        return self.executor.step(state, event, context, {})
