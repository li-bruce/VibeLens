"""Read-only instance projection shared by public queries, tests, and exports."""


def bo_machine(snapshot: dict) -> dict:
    configurations = []
    journal = []
    for row in snapshot["files"]:
        configurations.append({
            "attempt": row["id"], "phase": row["state"], "state_revision": row["revision"],
            "run_build_id": row["build_id"], "context": row["context"],
            "revision": row["revision"], "activities": {}, "resources": {},
            "journal": [], "state_journal": row["journal"],
        })
        journal.extend({"seq": entry["seq"], "event": entry["event"],
                        "source": entry["before"], "target": entry["after"],
                        "guards": entry["guards"], "attempt": row["id"]}
                       for entry in row["journal"])
    return {"configurations": configurations, "journal": journal}
