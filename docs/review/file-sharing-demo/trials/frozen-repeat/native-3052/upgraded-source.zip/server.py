"""Run the business application, optionally with isolated graph capture."""
import argparse
import hashlib
import json
from pathlib import Path

from app.ports import BOEvents
from app.store import Store
from app.service import FileService
from app.web import create_app

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8840)
    parser.add_argument("--database", type=Path, default=ROOT / "data/files.sqlite3")
    parser.add_argument("--no-observer", action="store_true")
    args = parser.parse_args()
    adapter = None
    if args.no_observer:
        events = BOEvents()
        build_id = hashlib.sha256((ROOT / "bo_stategraph/project.json").read_bytes()).hexdigest()
    else:
        from integrations.bo_adapter import BOAdapter
        adapter = BOAdapter()
        events, build_id = adapter.events, adapter.build_id
    store = Store(args.database, events)
    app = create_app(FileService(store, build_id, events))
    if adapter:
        from integrations.bo_http import bo_web
        adapter.bo_bind(store)
        app.config["BO_ADAPTER"] = adapter
        app.register_blueprint(bo_web)
    print(f"Application: http://127.0.0.1:{args.port}", flush=True)
    try:
        app.run(host="127.0.0.1", port=args.port, debug=False, use_reloader=False, threaded=True)
    finally:
        if adapter:
            adapter.bo_close()


if __name__ == "__main__":
    main()
