"""Native SQLAlchemy declarations; importing this module never opens a database."""
from sqlalchemy import (MetaData, Table, Column, String, Integer, LargeBinary,
                        ForeignKey, CheckConstraint, UniqueConstraint)
metadata = MetaData()
users = Table("users", metadata,
    Column("id", String, primary_key=True),
    Column("display_name", String, nullable=False),
    Column("password_hash", String, nullable=False))
sessions = Table("sessions", metadata,
    Column("token_hash", String, primary_key=True),
    Column("user_id", String, ForeignKey("users.id"), nullable=False),
    Column("csrf_hash", String, nullable=False),
    Column("expires_at", Integer, nullable=False))
files = Table("files", metadata,
    Column("id", String, primary_key=True),
    Column("owner_id", String, ForeignKey("users.id"), nullable=False),
    Column("filename", String, nullable=False),
    Column("size", Integer, nullable=False),
    Column("content", LargeBinary, nullable=False),
    Column("state", String, nullable=False),
    Column("revision", Integer, nullable=False),
    Column("build_id", String, nullable=False),
    Column("journal", String, nullable=False),
    CheckConstraint("size >= 0"),
    CheckConstraint("state IN ('private', 'shared')"),
    CheckConstraint("revision >= 1"))
shares = Table("shares", metadata,
    Column("file_id", String, ForeignKey("files.id"), primary_key=True),
    Column("recipient_id", String, ForeignKey("users.id"), primary_key=True),
    Column("shared_by", String, ForeignKey("users.id"), nullable=False),
    UniqueConstraint("file_id", "recipient_id"))
