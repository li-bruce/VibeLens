"""Private file-sharing application."""
