"""Pure predicates shared by the declared permission network."""


def same_identity(left: str, right: str) -> bool:
    return bool(left) and left == right


def flag_enabled(value: bool) -> bool:
    return value is True
