"""Application-owned observation ports; domain execution does not import the observer."""
from contextlib import nullcontext


class BOEvents:
    def __init__(self, record=None, evaluation=None, snapshot=None, data=None):
        self.record = record
        self.evaluation = evaluation
        self.snapshot = snapshot
        self.data = data
        self.errors = 0

    def bo_record(self, node, phase, inputs, outputs, **context):
        if self.record is None:
            return None
        try:
            return self.record(node, phase, lambda: {"inputs": inputs, "outputs": outputs}, **context)
        except Exception:
            self.errors += 1
            return None

    def bo_evaluation(self, policy, result, **context):
        if self.evaluation is not None:
            try:
                self.evaluation(policy, result, **context)
            except Exception:
                self.errors += 1

    def bo_snapshot(self, row, event_id, **context):
        if self.snapshot is not None and event_id:
            try:
                self.snapshot(row, event_id, **context)
            except Exception:
                self.errors += 1

    def bo_data_execute(self, node, callback, **context):
        if self.data is None:
            return callback()
        called, result, failure = False, None, None

        def once():
            nonlocal called, result, failure
            called = True
            try:
                result = callback()
                return result
            except BaseException as error:
                failure = error
                raise

        try:
            return self.data.execute(node, once, **context)
        except BaseException:
            if failure is not None:
                raise failure
            self.errors += 1
            return result if called else callback()

    def bo_transaction(self, node, manager, **context):
        if self.data is None:
            return manager
        return self.data.transaction(node, manager, **context)

    def bo_transform(self, node, function, value, **context):
        if self.data is None:
            return function(value)
        called, result, failure = False, None, None

        def once(original):
            nonlocal called, result, failure
            called = True
            try:
                result = function(original)
                return result
            except BaseException as error:
                failure = error
                raise

        try:
            return self.data.transform(node, once, value, **context)
        except BaseException:
            if failure is not None:
                raise failure
            self.errors += 1
            return result if called else function(value)
