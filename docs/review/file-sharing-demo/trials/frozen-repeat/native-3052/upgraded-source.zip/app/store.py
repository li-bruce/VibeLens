"""SQLite storage and explicit, selected database-operation observation."""
import hashlib
import json
from pathlib import Path

from sqlalchemy import create_engine, event, text
from werkzeug.security import generate_password_hash
from app.models import metadata
from app.ports import BOEvents

ACCOUNTS = [("linzhou", "林舟"), ("xuning", "许宁"), ("zhoulan", "周岚")]


def enable_foreign_keys(connection, record):
    connection.execute("PRAGMA foreign_keys=ON")


class Store:
    def __init__(self, path: Path, events=None):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.events = events or BOEvents()
        self.engine = create_engine("sqlite:///" + self.path.as_posix(),
                                    connect_args={"timeout": 15})
        event.listen(self.engine, "connect", enable_foreign_keys)
        metadata.create_all(self.engine)
        with self.engine.begin() as connection:
            for user_id, display_name in ACCOUNTS:
                exists = connection.execute(text("SELECT id FROM users WHERE id=:id"),
                                            {"id": user_id}).first()
                if exists is None:
                    connection.execute(text(
                        "INSERT INTO users(id,display_name,password_hash) VALUES(:id,:name,:password)"),
                        {"id": user_id, "name": display_name,
                         "password": generate_password_hash("trial-" + user_id)})

    def query(self, connection, statement: str, values: dict, query_name: str) -> list:
        def execute():
            return [dict(row) for row in connection.execute(text(statement), values).mappings()]
        return self.events.bo_data_execute(
            "db.read", execute, connection=connection, statement=statement, language="sql",
            parameters={"query_name": query_name},
            summarize=lambda rows: {"rows": len(rows), "result": {"count": len(rows)}})

    def write(self, connection, statement: str, values: dict, query_name: str) -> int:
        def execute():
            return connection.execute(text(statement), values).rowcount
        return self.events.bo_data_execute(
            "db.write", execute, connection=connection, statement=statement, language="sql",
            parameters={"query_name": query_name},
            summarize=lambda count: {"rows": count, "result": {"count": count}})

    def transaction(self):
        return self.events.bo_transaction("db.tx", self.engine.begin())

    def snapshot(self) -> dict:
        with self.engine.connect() as connection:
            rows = [dict(row) for row in connection.execute(text(
                "SELECT id,owner_id,filename,size,state,revision,build_id,journal FROM files")).mappings()]
            relations = [dict(row) for row in connection.execute(text(
                "SELECT file_id,recipient_id,shared_by FROM shares ORDER BY recipient_id")).mappings()]
            content_hashes = {row.id: hashlib.sha256(row.content).hexdigest()
                              for row in connection.execute(text("SELECT id,content FROM files"))}
        for row in rows:
            row["context"] = {
                "owner_id": row["owner_id"], "filename": row["filename"], "size": row["size"],
                "recipient_ids": [s["recipient_id"] for s in relations if s["file_id"] == row["id"]],
                "sha256": content_hashes[row["id"]],
            }
            row["journal"] = json.loads(row["journal"])
        return {"files": rows, "shares": relations}
