# Project verification requirements

This project retains a developer graph with canonical source bindings and selected runtime evidence.
Run the normal project gate with `.venv/Scripts/python.exe -B -X utf8 tooling/check.py`.
Behavior changes must preserve the active immutable change baseline and complete scan, inspect, verify, accept, and check.
Keep independent business expectations, safe captures, policy/data declarations, and source inventory synchronized.
Keep requirement, business, mapping, state, UI, and observer-isolation results distinct.
Unrun or failed checks are never passes.

Interactive VibeLens adoption is separate from these project checks. This file does not activate a Skill in another conversation.
The current trial was explicitly activated and uses the frozen canonical revision recorded in review/implementation-version.json.
Do not modify canonical validators/projectors or replace them with project compatibility shims.
Do not contact other chats or inspect other trials. The current user iteration authorizes owner-only revocation for one file and recipient, next-request denial from an unrefreshed page, preservation of other access, and re-sharing.
Keep the user-reported Boolean data/guard replay matching limitation intact; do not patch canonical validation, projection, viewer, or framework tests.
