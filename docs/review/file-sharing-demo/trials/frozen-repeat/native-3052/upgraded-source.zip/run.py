"""Launch this project's application and observer together; own only these child processes."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from urllib.request import build_opener, ProxyHandler

ROOT = Path(__file__).resolve().parent


def wait_ready(url, process, timeout=30):
    opener = build_opener(ProxyHandler({}))
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise RuntimeError("Started child exited; inspect this project's review server logs.")
        try:
            with opener.open(url, timeout=1) as response:
                if response.status == 200:
                    return
        except OSError:
            time.sleep(0.15)
    raise RuntimeError("Started child did not become ready: " + url)


def bo_current_build():
    return json.loads((ROOT / "manifest.json").read_text(encoding="utf-8"))["build_id"]


def bo_stop_children(processes):
    for process in reversed(processes):
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(5)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--app-port", type=int, default=8840)
    parser.add_argument("--graph-port", type=int, default=8841)
    args = parser.parse_args()
    review = ROOT / "review"
    review.mkdir(exist_ok=True)
    env = os.environ.copy()
    env.update(PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1",
               FILESHARE_DB_URL="sqlite:///data/files.sqlite3")
    processes, logs = [], []
    creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
    commands = [
        ("graph", [sys.executable, "-B", "-u", "observer_runtime/bo.py", "serve",
                   "--root", ".", "--port", str(args.graph_port),
                   "--origin", f"http://127.0.0.1:{args.app_port}"],
         f"http://127.0.0.1:{args.graph_port}/graph"),
        ("app", [sys.executable, "-B", "-u", "server.py", "--port", str(args.app_port)],
         f"http://127.0.0.1:{args.app_port}/api/stategraph/health"),
    ]
    try:
        for name, command, health_url in commands:
            log = (review / (name + "-server.log")).open("ab")
            logs.append(log)
            process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=log,
                                       stderr=subprocess.STDOUT, creationflags=creationflags)
            processes.append(process)
            wait_ready(health_url, process)
        (review / "development-processes.json").write_text(
            json.dumps({"launcher": os.getpid(), "children": [p.pid for p in processes],
                        "project": str(ROOT)}), encoding="utf-8")
        print(f"Application: http://127.0.0.1:{args.app_port}", flush=True)
        print(f"Graph: http://127.0.0.1:{args.graph_port}/graph", flush=True)
        print("Press Ctrl+C to stop only the processes started by this launcher.", flush=True)
        loaded_build = bo_current_build()
        while all(process.poll() is None for process in processes):
            time.sleep(0.25)
            try:
                current_build = bo_current_build()
            except (OSError, ValueError, KeyError):
                continue
            if current_build != loaded_build:
                print("Graph build changed; restarting this launcher's observer and producer.", flush=True)
                bo_stop_children(processes)
                processes.clear()
                for name, command, health_url in commands:
                    log = (review / (name + "-server.log")).open("ab")
                    logs.append(log)
                    process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=log,
                                               stderr=subprocess.STDOUT, creationflags=creationflags)
                    processes.append(process)
                    wait_ready(health_url, process)
                (review / "development-processes.json").write_text(
                    json.dumps({"launcher": os.getpid(), "children": [p.pid for p in processes],
                                "project": str(ROOT)}), encoding="utf-8")
                loaded_build = current_build
                print(f"Reloaded app and graph for build {current_build}", flush=True)
        raise RuntimeError("A development service stopped. Review the project logs.")
    except KeyboardInterrupt:
        pass
    finally:
        bo_stop_children(processes)
        for log in logs:
            log.close()


if __name__ == "__main__":
    main()
