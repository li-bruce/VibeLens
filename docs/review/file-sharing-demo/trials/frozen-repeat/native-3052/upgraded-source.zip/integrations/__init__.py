"""Optional application/observer adapters."""
