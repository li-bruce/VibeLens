"""Public read-only query/export endpoints, excluded from business capture."""
from flask import Blueprint, current_app, jsonify
from bo_stategraph.query import bo_machine

bo_web = Blueprint("bo_web", __name__)


@bo_web.get("/api/stategraph")
def bo_stategraph():
    adapter = current_app.config["BO_ADAPTER"]
    return jsonify({"instances": adapter.graph.bo_instances(), "build_id": adapter.build_id})


@bo_web.get("/api/stategraph/export")
def bo_export():
    adapter = current_app.config["BO_ADAPTER"]
    store = current_app.config["FILE_SERVICE"].store
    return jsonify(adapter.graph.bo_export(runtime={"machine": bo_machine(store.snapshot())}))


@bo_web.post("/api/stategraph/flush")
def bo_flush():
    adapter = current_app.config["BO_ADAPTER"]
    flushed = adapter.probe.flush(10)
    return jsonify({"flushed": flushed, "errors": adapter.probe.bo_errors,
                    "dropped": adapter.probe.bo_dropped,
                    "enqueued_events": adapter.probe.bo_seq,
                    "enqueued_snapshots": adapter.bo_snapshot_enqueued,
                    "pending_envelopes": adapter.probe.bo_queue.unfinished_tasks,
                    "waiting_envelopes": adapter.probe.bo_queue.qsize(),
                    "worker_alive": adapter.probe.bo_worker.is_alive()})
