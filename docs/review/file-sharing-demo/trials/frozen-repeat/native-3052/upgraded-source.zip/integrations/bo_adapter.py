"""Optional bounded capture; native domain execution never depends on this module."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "observer_runtime"))
from bo_observer.adapters.python.bo_probe import BOProbe
from bo_observer.policy.recording import record_evaluation
from bo_observer.data.runtime import BODataRuntime
from behavior_model import capture
from app.ports import BOEvents
from bo_stategraph import BOStateGraph
from bo_stategraph.query import bo_machine


class BOAdapter:
    def __init__(self, mode="on", sink=None, capacity=8192, run_id=None):
        self.project = json.loads((ROOT / "bo_stategraph/project.json").read_text(encoding="utf-8"))
        self.build_id = capture(ROOT, self.project["model"])["build_id"]
        settings_path = ROOT / ".stategraph/collector.json"
        settings = json.loads(settings_path.read_text(encoding="utf-8")) if settings_path.exists() else {}
        self.evaluations = []
        self.bo_snapshot_enqueued = 0
        self.probe = BOProbe(self.project, self.build_id,
            endpoint=settings.get("endpoint", "http://127.0.0.1:8841"),
            token=settings.get("token", ""), enabled=mode != "off",
            timeout=10.0, capacity=capacity, sink=sink, run_id=run_id)
        config = json.loads((ROOT / "bo_stategraph/databases.json").read_text(encoding="utf-8"))
        self.data = BODataRuntime(self.probe, config) if mode != "off" else None
        self.events = BOEvents(
            record=self.probe.record if mode != "off" else None,
            evaluation=self.bo_evaluation if mode != "off" else None,
            snapshot=self.bo_snapshot if mode != "off" else None,
            data=self.data)
        self.graph = BOStateGraph(self.project["model"], build_id=self.build_id, mode="drive")

    def bo_evaluation(self, policy, result, **context):
        self.evaluations.append(result)
        record_evaluation(policy, result, self.probe, **context)

    def bo_snapshot(self, row, event_id, **context):
        accepted = self.probe.snapshot(row["id"], row["state"], row["context"], row["revision"],
                                       event_id, payload={},
                                       configuration=bo_machine({"files": [row]})["configurations"][0],
                                       **context)
        if accepted:
            with self.probe.bo_lock:
                self.bo_snapshot_enqueued += 1
        return accepted

    def bo_bind(self, store):
        self.graph.bo_bind_instances(lambda: bo_machine(store.snapshot()))

    def bo_close(self):
        self.probe.flush(10)
        self.probe.close()
        if self.data:
            self.data.close()
