"""Reproduce browser checks for the design-only VibeLens graph."""
from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
from playwright.sync_api import expect, sync_playwright


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--url", default="http://127.0.0.1:8841/graph")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    output = root / "review" / "design-browser"
    output.mkdir(parents=True, exist_ok=True)
    previous_report = output / "report.json"
    if previous_report.exists():
        previous = json.loads(previous_report.read_text(encoding="utf-8"))
        stamp = previous["checked_at"].replace(":", "-").replace("+", "_")
        (output / f"report-{stamp}.json").write_text(
            json.dumps(previous, ensure_ascii=False, indent=2), encoding="utf-8"
        )
    report = {
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "url": args.url,
        "scope": "Design viewer only; application behavior is not implemented.",
        "status": "running",
        "checks": [],
        "page_errors": [],
        "console_errors": [],
        "requests": [],
    }
    try:
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(headless=True, args=["--no-proxy-server"])
            try:
                page = browser.new_page(viewport={"width": 1500, "height": 1000})
                page.on("pageerror", lambda error: report["page_errors"].append(str(error)))
                page.on("request", lambda request: report["requests"].append(request.url))
                page.on(
                    "console",
                    lambda message: report["console_errors"].append(message.text)
                    if message.type == "error" else None,
                )
                response = page.goto(args.url, wait_until="domcontentloaded", timeout=15000)
                assert response and response.status == 200
                try:
                    page.wait_for_load_state("networkidle", timeout=10000)
                except PlaywrightTimeoutError:
                    report["network_idle"] = "not reached; element readiness still required"
                expect(page.locator("#canvas-host canvas")).to_be_visible(timeout=15000)
                page.wait_for_function(
                    "document.querySelector('#semantic').children.length > 0",
                    timeout=15000,
                )
                view_response = page.request.get(args.url.rsplit("/", 1)[0] + "/api/view")
                assert view_response.status == 200
                view = view_response.json()
                assert view["stage"] == "design"
                assert view["events"] == []
                assert view["binding_status"]["status"] == "design"
                assert view["model"]["project_id"] == root.name
                nodes = {node["id"]: node for node in view["model"]["nodes"]}
                discovery = json.loads((root / "discovery.json").read_text(encoding="utf-8"))
                for network in discovery["networks"]:
                    for node in network["nodes"]:
                        assert nodes[node["id"]]["label"] == node["label"]
                assert "policy:share_allowed" in nodes
                assert "policy:access_allowed" in nodes
                assert page.locator("#language").input_value() == "zh-CN"
                report["checks"] = [
                    "Graph page and design API return HTTP 200.",
                    "Canvas and accessible graph render in headless Chromium.",
                    "Project identity and all business node labels match discovery.json.",
                    "Shared ownership and recipient policy nodes exist.",
                    "The interface uses the conversation language zh-CN.",
                    "The graph is explicitly design-only and has zero runtime events.",
                ]
                report["project_title"] = page.locator("#project-title").inner_text()
                report["connection"] = page.locator("#connection").inner_text()
                report["node_count"] = len(nodes)
                report["build_id"] = view["manifest"]["build_id"]
                (output / "rendered-body.txt").write_text(
                    page.locator("body").inner_text(), encoding="utf-8"
                )
                page.screenshot(path=str(output / "graph.png"), full_page=True)
                assert not report["page_errors"], report["page_errors"]
                assert not report["console_errors"], report["console_errors"]
                report["status"] = "passed"
            finally:
                if report["status"] != "passed" and "page" in locals():
                    (output / "failure-body.txt").write_text(
                        page.locator("body").inner_text(timeout=3000), encoding="utf-8"
                    )
                    page.screenshot(path=str(output / "failure.png"), timeout=3000)
                browser.close()
    except Exception as error:
        report["status"] = "failed"
        report["error"] = f"{type(error).__name__}: {error}"
        raise
    finally:
        (output / "report.json").write_text(
            json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        print(json.dumps(
            {"status": report["status"], "report": str(output / "report.json")},
            ensure_ascii=True,
        ))


if __name__ == "__main__":
    main()
