"""Reproduce the exported core in a checked temporary extraction only."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]
build_id = json.loads((ROOT / "manifest.json").read_text(encoding="utf-8"))["build_id"]
archive_name = f"dist/core-revocation-v2-{build_id[:8]}.zip"
archive = ROOT / archive_name
review = (ROOT / "review").resolve()
report = {"status": "running", "archive": archive_name, "build_id": build_id,
          "sha256": hashlib.sha256(archive.read_bytes()).hexdigest()}
try:
    with tempfile.TemporaryDirectory(prefix="core-export-revocation-v2-", dir=review) as directory:
        target = Path(directory).resolve()
        assert target.is_relative_to(review) and target.parent == review
        assert not target.is_symlink() and not target.is_junction()
        with zipfile.ZipFile(archive) as bundle:
            names = bundle.namelist()
            for name in names:
                destination = (target / name).resolve()
                assert destination.is_relative_to(target)
                assert not name.startswith(("observer_runtime/", "integrations/"))
                assert bundle.read(name) == (ROOT / name).read_bytes()
            bundle.extractall(target)
        result = subprocess.run([sys.executable, "-B", "-X", "utf8", "-m", "tooling.core_smoke"],
                                cwd=target, capture_output=True, text=True,
                                encoding="utf-8", timeout=60)
        report.update(file_count=len(names), command=result.args,
                      exit_code=result.returncode, stdout=result.stdout, stderr=result.stderr,
                      observer_modules_absent=not (target / "observer_runtime").exists(),
                      current_core_content_identical=True)
        assert result.returncode == 0, result.stderr
        assert "without observer modules" in result.stdout
        assert target.is_relative_to(review) and target.parent == review
        assert not target.is_symlink() and not target.is_junction()
    report.update(status="passed", temporary_extraction_removed=not target.exists())
finally:
    if report["status"] != "passed":
        report["status"] = "failed"
    (review / "revocation-core-reproduction.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({key: report.get(key) for key in
                      ("status", "file_count", "exit_code", "temporary_extraction_removed")}))
