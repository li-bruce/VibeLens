"""Independent assertions over real handlers, file bytes, and SQLite effects."""
from io import BytesIO
from pathlib import Path
import json
import tempfile

import pytest

from app.store import Store
from app.service import FileService
from app.ports import BOEvents
from app.web import create_app
from integrations.bo_adapter import BOAdapter
from tooling.scenarios import CASES, SAMPLE, execute, post, sign_in, upload

EXPECTED = {
    "login_success": 200, "login_invalid": 401, "upload_signed_in": 201,
    "upload_anonymous": 401, "share_owner": 200, "share_recipient_denied": 403,
    "share_unrelated_denied": 403, "share_anonymous_denied": 401, "share_unknown_recipient": 400,
    "view_owner": 200, "view_recipient": 200, "view_unrelated_denied": 403,
    "view_anonymous_denied": 401, "download_owner": 200, "download_recipient": 200,
    "download_unrelated_denied": 403, "download_anonymous_denied": 401,
    "normal": 200, "share_idempotent": 200, "database_rollback": 409,
}


@pytest.mark.parametrize("case", CASES)
def test_confirmed_business_cases(case):
    result = execute(case)
    assert result["observations"]["status"] == EXPECTED[case]
    assert result["capture_diagnostics"]["errors"] == 0
    assert result["capture_diagnostics"]["dropped"] == 0
    if case == "normal":
        assert result["observations"]["bytes_match"]
        assert result["observations"]["owner_id"] == "linzhou"
        assert result["observations"]["recipient_ids"] == ["xuning"]
        assert result["observations"]["unrelated_file_count"] == 0
        assert result["authority"]["files"][0]["state"] == "shared"
        journal = result["authority"]["files"][0]["journal"]
        assert [(entry["before"], entry["event"], entry["after"]) for entry in journal] == [
            ("pending", "upload", "private"), ("private", "share", "shared")]
        raw = json.dumps(result["events"])
        assert "trial-linzhou" not in raw
        assert SAMPLE.decode().strip() not in raw


@pytest.mark.parametrize("mode", ["off", "fault"])
def test_observer_does_not_change_business(mode):
    result = execute("normal", mode)
    assert result["observations"]["bytes_match"]
    assert result["observations"]["unrelated_file_count"] == 0
    assert result["authority"]["files"][0]["state"] == "shared"
    assert not result["events"]
    if mode == "fault":
        assert result["capture_diagnostics"]["errors"] > 0


def test_bounded_queue_does_not_change_business():
    result = execute("normal", capacity=1, slow_sink=True)
    assert result["observations"]["bytes_match"]
    assert result["authority"]["files"][0]["state"] == "shared"
    assert result["capture_diagnostics"]["dropped"] > 0


def test_empty_file_other_owner_and_excluded_mutations(tmp_path):
    adapter = BOAdapter("off")
    store = Store(tmp_path / "files.sqlite3", BOEvents())
    try:
        service = FileService(store, adapter.build_id)
        app = create_app(service)
        client = app.test_client()
        assert sign_in(client, "xuning").status_code == 200
        created = upload(client, name="empty.txt", content=b"")
        assert created.status_code == 201
        assert created.json["owner_id"] == "xuning"
        identity = created.json["id"]
        assert client.get(f"/api/files/{identity}/download").data == b""
        assert post(client, f"/api/files/{identity}/share", json={"recipient_id": "linzhou"}).status_code == 200
        assert client.put(f"/api/files/{identity}", json={"filename": "changed"}).status_code == 405
        assert client.delete(f"/api/files/{identity}").status_code == 405
        assert post(client, "/api/register", json={}).status_code == 404
        assert post(client, f"/api/files/{identity}/revoke", json={}).status_code == 404
        assert client.post("/api/files", data={"file": (BytesIO(b"x"), "x.txt")}).status_code == 403
    finally:
        adapter.bo_close()
        store.engine.dispose()
