"""Record authorized revocation intent and prepare its design-only graph."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[1]


def read(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def write(name, value):
    path = ROOT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    change = ROOT / ".stategraph/revocation-v2"
    source_root = change / "source-before"
    if source_root.exists():
        raise RuntimeError("Do not replace the preserved source baseline.")
    source_files = sorted(set(read("sync.json")["code_files"] + [
        "discovery.json", "intent.json", "acceptance.json", "mapping.json", "whitebox.json",
        "implementation.json", "bo_stategraph/project.json", "tooling/build_model.py",
        "tooling/scenarios.py", "tooling/observe.py", "tests/test_business.py",
        "review/browser_acceptance.py", "AGENTS.md",
    ]))
    hashes = {}
    for name in source_files:
        target = source_root / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / name, target)
        hashes[name] = hashlib.sha256(target.read_bytes()).hexdigest()
    write(".stategraph/revocation-v2/source-before-manifest.json", {"files": hashes})
    discovery = read("discovery.json")
    request_text = (ROOT / "review/revocation-design-dialogue.md").read_text(encoding="utf-8").split("## Original request\n\n> ", 1)[1].split("\n\n##", 1)[0]
    discovery["sources"].extend([
        {"id": "U4", "kind": "user", "text": request_text,
         "locator": "Current chat: forwarded revocation request, 2026-10-29; no source-chat inspection."},
        {"id": "U5", "kind": "user", "text": "SIMULATED persona restatement, authorized by U4: 对，就按这个范围做，不需要额外功能。",
         "locator": "review/revocation-design-dialogue.md: simulated scope restatement by coding agent; not independent human acceptance."},
    ])
    network = discovery["networks"][0]
    new_nodes = [
        ("revoke", "所有者取消指定接收者的共享", "action"),
        ("recipient_grant", "当前文件与指定接收者的共享关系", "data"),
        ("authorization", "每次请求读取并判断当前权限", "condition"),
        ("retained_access", "其他接收者与所有者继续访问", "data"),
    ]
    network["nodes"].extend({"id": identity, "label": label, "kind": kind,
                             "source_refs": ["U4"], "model_nodes": [identity]}
                            for identity, label, kind in new_nodes)
    new_edges = [
        ("share_grant", "share", "recipient_grant", "data", "建立或重新建立指定关系"),
        ("revoke_grant", "revoke", "recipient_grant", "data", "只移除所选文件与接收者的关系"),
        ("grant_authorization", "recipient_grant", "authorization", "data", "请求时读取当前关系"),
        ("authorized_download", "authorization", "download", "guard", "所有者或当前接收者才允许"),
        ("denied_after_revoke", "authorization", "access_denied", "guard", "取消后下一次请求被拒绝"),
        ("revoke_retains", "revoke", "retained_access", "data", "保留其他关系与所有权"),
        ("revoke_reshare", "revoke", "share", "flow", "以后可以再次共享"),
    ]
    network["edges"].extend({"id": identity, "from": source, "to": target, "relation": relation,
                             "label": label, "source_refs": ["U4"]}
                            for identity, source, target, relation, label in new_edges)
    network["outcome"] = "The owner can share or revoke one recipient relation; every new request reads current facts. Other recipients and owner access remain, and re-sharing is allowed."
    cases = ["revoke_owner", "revoke_nonowner_denied", "revoke_anonymous_denied",
             "revoke_idempotent", "revoke_last_recipient", "revoke_reshare",
             "revoke_other_file_retained", "revoke_unknown_recipient"]
    discovery["policy"]["operations"].append({
        "id": "revoke", "root": "share_allowed", "business_nodes": ["revoke"],
        "cases": cases, "source_refs": ["U4"],
    })
    discovery["decisions"].append({
        "id": "D_REVOKE", "topic": "authority", "blocking": True, "status": "resolved",
        "question": "取消是否只作用于所选文件与接收者，并在下一次下载请求时使用当前权限？",
        "why": "Bind the supplied target, next-request timing, preserved relations, and re-sharing scope.",
        "affects": ["revoke", "recipient_grant", "authorization", "download", "retained_access"],
        "source_refs": ["U4", "U5"],
        "resolution": {"kind": "user_answer",
                       "text": "U4 directly supplies this scope; U5 is an explicitly authorized simulated restatement, not a human reply.",
                       "source_refs": ["U4", "U5"]},
    })
    previous_deferred = discovery.pop("deferred_scope", [])
    discovery["resolved_deferred_scope"] = [
        {"previous": item, "resolved_by": "U4"} for item in previous_deferred]
    write("discovery.json", discovery)
    intent = read("intent.json")
    for requirement in intent["requirements"]:
        if requirement["id"] == "R_BOUNDARY":
            requirement["text"] = "Recipients cannot reshare or edit. No preview, registration, file editing, or file deletion."
            requirement["source"] = "discovery.json:U1,U2,U4; revocation is now explicitly in scope."
    intent["requirements"].append({
        "id": "R_REVOKE", "status": "confirmed",
        "text": "Only the owner can revoke one file/recipient relation. A subsequent request from an unchanged page must be denied, while other recipients and owner access remain. Re-sharing later restores access.",
        "source": "discovery.json:U4; U5 is a simulated scope restatement authorized by U4.",
    })
    intent["revision"] = "revocation-v2"
    intent["exclusions"] = [value for value in intent["exclusions"] if not value.startswith("Revocation")]
    write("intent.json", intent)
    print(json.dumps({"design": "prepared", "new_operation": "revoke", "cases": cases,
                      "source_snapshot_files": len(hashes)}))


if __name__ == "__main__":
    main()
