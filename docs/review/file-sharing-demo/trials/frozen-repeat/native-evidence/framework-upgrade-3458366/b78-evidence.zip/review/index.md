# File-sharing trial evidence index

- Current framework-only upgrade: [b78f03a native upgrade review](framework-upgrade-b78f03a/index.md). Native application and unaffected regressions pass; overall upgrade acceptance has not passed because the strict keyboard source-menu test fails. Await an upstream fix/new frozen version. Business source, state/policy declarations and original expectations are unchanged.
- Accepted revocation V2 at frozen e69ce09: [original acceptance](revocation-acceptance.md), [summary](revocation-summary.json), [measured 363.125-second capture drain](revocation-drain-analysis.md).
- Initial implementation: [original initial acceptance](initial-acceptance.md).
- Immutable V2 preservation: [source archive](framework-upgrade-b78f03a/v2-source.zip), [evidence archive](framework-upgrade-b78f03a/v2-evidence.zip), [per-file verification](framework-upgrade-b78f03a/preservation-check.json).

Reports distinguish automated synthetic checks, observed limitations, and human/production acceptance. Old raw recordings and failure history remain preserved. Shared current gate receipts and the latest-browser pointer may advance between independently recorded iterations.
