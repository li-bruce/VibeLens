"""Small HTML forms and JSON endpoints over the same authoritative service."""
from io import BytesIO
from pathlib import Path
import secrets

from flask import (Blueprint, Flask, current_app, request, jsonify, redirect,
                   render_template, send_file, url_for)
from app.i18n import EN, ZH
from app.service import BusinessError, digest_token, MAX_FILE_SIZE
from app.store import ACCOUNTS

web = Blueprint("web", __name__)


def service():
    return current_app.config["FILE_SERVICE"]


def language() -> str:
    value = request.args.get("lang", request.cookies.get("fs_language", "zh-CN"))
    return value if value in {"en", "zh-CN"} else "en"


def strings() -> dict:
    return {**EN, **(ZH if language() == "zh-CN" else {})}


def actor() -> dict:
    return service().current_user(request.cookies.get("fs_session", ""))


def payload() -> dict:
    return request.get_json(silent=True) or request.form


def api_request() -> bool:
    return request.path.startswith("/api/")


def csrf_user() -> dict:
    user = actor()
    if not user:
        raise BusinessError(401, "login_required")
    candidate = request.headers.get("X-CSRF-Token", request.form.get("csrf", ""))
    if not secrets.compare_digest(digest_token(candidate), user["csrf_hash"]):
        raise BusinessError(403, "csrf_invalid")
    return user


def render_page(name: str, **values):
    return render_template(name, t=strings(), lang=language(), **values)


@web.get("/login")
def login_page():
    return render_page("login.html", accounts=ACCOUNTS, error="")


@web.post("/login")
@web.post("/api/login")
def login_action():
    body = payload()
    result = service().login(str(body.get("username", "")), str(body.get("password", "")))
    response = jsonify({"user": result["user"], "csrf": result["csrf"]}) if api_request() else redirect("/", 303)
    response.set_cookie("fs_session", result["token"], httponly=True, samesite="Strict", max_age=28800)
    response.set_cookie("fs_csrf", result["csrf"], samesite="Strict", max_age=28800)
    return response


@web.get("/")
@web.get("/api/files")
def file_list():
    user = actor()
    if not user:
        if api_request():
            raise BusinessError(401, "login_required")
        return redirect("/login", 303)
    rows = service().list_files(user["id"])
    if api_request():
        return jsonify({"files": rows})
    own = [row for row in rows if row["owner_id"] == user["id"]]
    received = [row for row in rows if row["owner_id"] != user["id"]]
    options = service().users(user["id"])
    return render_page("home.html", user=user, own=own, received=received, options=options,
                       csrf=request.cookies.get("fs_csrf", ""), notice=request.args.get("notice", ""))


@web.get("/api/session")
def session_info():
    user = actor()
    if not user:
        raise BusinessError(401, "login_required")
    return jsonify({"user": {"id": user["id"], "display_name": user["display_name"]},
                    "csrf": request.cookies.get("fs_csrf", "")})


@web.get("/api/users")
def user_list():
    return jsonify({"users": service().users(actor().get("id", ""))})


@web.post("/upload")
@web.post("/api/files")
def upload_action():
    user = csrf_user() if actor() else {"id": ""}
    upload = request.files.get("file")
    if upload is None:
        raise BusinessError(400, "invalid_filename")
    result = service().upload(user["id"], upload.filename or "", upload.read(MAX_FILE_SIZE + 1))
    return (jsonify(result), 201) if api_request() else redirect("/?notice=uploaded", 303)


@web.post("/files/<file_id>/share")
@web.post("/api/files/<file_id>/share")
def share_action(file_id: str):
    user = csrf_user() if actor() else {"id": ""}
    result = service().share(user["id"], file_id, str(payload().get("recipient_id", "")))
    return jsonify(result) if api_request() else redirect("/?notice=shared", 303)


@web.get("/api/files/<file_id>")
def file_info(file_id: str):
    return jsonify(service().metadata(actor().get("id", ""), file_id))


@web.get("/files/<file_id>/download")
@web.get("/api/files/<file_id>/download")
def download_file(file_id: str):
    result = service().download(actor().get("id", ""), file_id)
    response = send_file(BytesIO(result["content"]), as_attachment=True,
                         download_name=result["filename"], mimetype="application/octet-stream",
                         max_age=0)
    response.headers["Cache-Control"] = "no-store, private"
    return response


@web.post("/logout")
@web.post("/api/logout")
def logout_action():
    user = csrf_user()
    service().logout(request.cookies.get("fs_session", ""), user["id"])
    response = jsonify({"ok": True}) if api_request() else redirect("/login", 303)
    response.delete_cookie("fs_session")
    response.delete_cookie("fs_csrf")
    return response


@web.get("/api/stategraph/health")
def bo_health():
    return jsonify({"status": "ok", "build_id": service().build_id})


def handle_business_error(error):
    if api_request():
        return jsonify({"error": error.code}), error.status
    return render_page("error.html", code=error.code), error.status


def protect_request():
    origin = request.headers.get("Origin")
    if request.method == "POST" and (
        request.headers.get("Sec-Fetch-Site") == "cross-site"
        or (origin and origin != request.host_url.rstrip("/"))
    ):
        raise BusinessError(403, "request_rejected")


def response_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "same-origin"
    response.headers["Content-Security-Policy"] = "default-src 'self'; style-src 'self'; form-action 'self'; frame-ancestors 'none'"
    if request.path != "/api/stategraph/health":
        response.headers["Cache-Control"] = "no-store"
    if request.args.get("lang") in {"en", "zh-CN"}:
        response.set_cookie("fs_language", request.args["lang"], samesite="Strict")
    return response


def create_app(file_service) -> Flask:
    app = Flask(__name__, template_folder=str(Path(__file__).parent / "templates"),
                static_folder=str(Path(__file__).parent / "static"))
    app.config.update(FILE_SERVICE=file_service, MAX_CONTENT_LENGTH=MAX_FILE_SIZE + 1024 * 1024)
    app.register_blueprint(web)
    app.register_error_handler(BusinessError, handle_business_error)
    app.before_request(protect_request)
    app.after_request(response_headers)
    return app
