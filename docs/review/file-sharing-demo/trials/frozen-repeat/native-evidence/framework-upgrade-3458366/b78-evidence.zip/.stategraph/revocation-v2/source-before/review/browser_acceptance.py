"""Repeatable headless browser acceptance over the app, recording, and replay."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sqlite3
import time
import uuid

from playwright.sync_api import expect, sync_playwright

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--app", default="http://127.0.0.1:8840")
    parser.add_argument("--graph", default="http://127.0.0.1:8841")
    args = parser.parse_args()
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:6]
    output = ROOT / "review" / "browser" / stamp
    output.mkdir(parents=True)
    report = {"status": "running", "app": args.app, "graph": args.graph,
              "provenance": "Automated browser trial with synthetic data; not independent human acceptance.",
              "checks": [], "page_errors": [], "console_errors": []}
    content = b"Browser-verified private file sharing.\n"
    filename = "browser-handoff-" + stamp + ".txt"
    try:
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(headless=True, args=["--no-proxy-server"])
            try:
                contexts = [browser.new_context(accept_downloads=True,
                            viewport={"width": 1450, "height": 1000}) for _ in range(4)]
                owner, recipient, unrelated, graph = [context.new_page() for context in contexts]
                for page in (owner, recipient, unrelated, graph):
                    page.on("pageerror", lambda error: report["page_errors"].append(str(error)))
                    page.on("console", lambda message: report["console_errors"].append(message.text)
                            if message.type == "error" else None)
                graph.goto(args.graph + "/graph", wait_until="domcontentloaded")
                expect(graph.locator("#canvas-host canvas")).to_be_visible(timeout=20000)
                expect(graph.locator("#record-start")).to_be_enabled(timeout=20000)
                before = graph.request.get(args.graph + "/api/view").json()
                with graph.expect_response(lambda response: response.url.endswith("/api/recordings/start")) as started:
                    graph.locator("#record-start").click()
                assert started.value.status == 200
                recording_id = started.value.json()["id"]
                assert len(graph.request.get(args.graph + "/api/view").json()["events"]) == len(before["events"])
                report["checks"].append("Starting a real recording creates no business events.")

                def login(page, user):
                    page.goto(args.app + "/login", wait_until="networkidle")
                    page.select_option("#username", user)
                    page.fill("#password", "trial-" + user)
                    page.locator('[data-testid="login-form"] button').click()
                    page.wait_for_url(args.app + "/")
                    expect(page.locator('[data-testid="current-user"]')).to_be_visible()

                login(owner, "linzhou")
                owner.screenshot(path=str(output / "owner-empty.png"), full_page=True)
                owner.locator("#file").set_input_files(
                    {"name": filename, "mimeType": "text/plain", "buffer": content})
                owner.locator('[data-testid="upload-form"] button').click()
                owner.wait_for_url("**/?notice=uploaded")
                owner_row = owner.locator('[data-testid="owned-section"] tr').filter(has_text=filename)
                expect(owner_row).to_be_visible()
                file_id = owner_row.get_attribute("data-file-id")
                owner_row.locator('select[name="recipient_id"]').select_option("xuning")
                owner_row.locator('[data-testid="share-form"] button').click()
                owner.wait_for_url("**/?notice=shared")
                owner_row = owner.locator('[data-testid="owned-section"] tr').filter(has_text=filename)
                expect(owner_row.locator(".recipient-chip")).to_have_text("许宁")
                owner.screenshot(path=str(output / "owner-shared.png"), full_page=True)
                report["checks"].append("Owner uploads, selects an existing recipient, and sees the saved relationship.")

                login(recipient, "xuning")
                row = recipient.locator('[data-testid="received-section"] tr').filter(has_text=filename)
                expect(row).to_be_visible()
                expect(row).to_contain_text("林舟")
                expect(row).to_contain_text(str(len(content)) + " B")
                assert row.locator('[data-testid="share-form"]').count() == 0
                with recipient.expect_download() as pending_download:
                    row.locator('[data-testid="download"]').click()
                download = pending_download.value
                assert download.suggested_filename == filename
                download_path = output / "downloaded-synthetic-file.txt"
                download.save_as(str(download_path))
                assert download_path.read_bytes() == content
                recipient.screenshot(path=str(output / "recipient.png"), full_page=True)
                report["checks"].append("Recipient sees filename, size, and sharer, has no share control, and downloads exact bytes.")

                login(unrelated, "zhoulan")
                assert unrelated.locator('[data-testid="received-section"]').get_by_text(filename).count() == 0
                assert unrelated.request.get(args.app + f"/api/files/{file_id}").status == 403
                assert unrelated.request.get(args.app + f"/api/files/{file_id}/download").status == 403
                csrf = unrelated.request.get(args.app + "/api/session").json()["csrf"]
                rejected = unrelated.request.post(args.app + f"/api/files/{file_id}/share",
                    data={"recipient_id": "xuning"}, headers={"X-CSRF-Token": csrf})
                assert rejected.status == 403
                unrelated.screenshot(path=str(output / "unrelated.png"), full_page=True)
                report["checks"].append("Unrelated user cannot see the file and direct view/download/share requests are denied.")

                recipient.goto(args.app + "/?lang=en", wait_until="networkidle")
                expect(recipient.get_by_role("heading", name="Shared with me")).to_be_visible()
                recipient.screenshot(path=str(output / "recipient-english.png"), full_page=True)
                recipient.set_viewport_size({"width": 390, "height": 844})
                assert recipient.evaluate("document.documentElement.scrollWidth <= window.innerWidth")
                recipient.screenshot(path=str(output / "recipient-mobile.png"), full_page=True)
                report["checks"].append("English selection and a narrow desktop-browser viewport remain usable.")

                with sqlite3.connect((ROOT / "data/files.sqlite3").as_uri() + "?mode=ro", uri=True) as db:
                    saved = db.execute("SELECT owner_id,filename,size,content,state FROM files WHERE id=?", (file_id,)).fetchone()
                    recipients = db.execute("SELECT recipient_id,shared_by FROM shares WHERE file_id=?", (file_id,)).fetchall()
                assert saved == ("linzhou", filename, len(content), content, "shared")
                assert recipients == [("xuning", "linzhou")]
                report["checks"].append("Independent SQLite reads match ownership, recipient, state, size, name, and bytes.")

                drain_started = time.monotonic()
                deadline = drain_started + 120
                while True:
                    flushed = owner.request.post(args.app + "/api/stategraph/flush", data={})
                    assert flushed.status == 200
                    assert flushed.json()["errors"] == 0 and flushed.json()["dropped"] == 0, flushed.json()
                    if flushed.json()["flushed"] or time.monotonic() >= deadline:
                        break
                assert flushed.json()["flushed"] is True, flushed.json()
                report["drain_wait_seconds"] = round(time.monotonic() - drain_started, 3)
                view = graph.request.get(args.graph + "/api/view").json()
                assert view["binding_status"]["status"] == "current"
                assert all(any(event["node"] == node for event in view["events"])
                           for node in ("login", "upload", "share", "download", "authorization"))
                build_id = view["manifest"]["build_id"]
                assert owner.request.get(args.app + "/api/stategraph/health").json()["build_id"] == build_id
                assert json.loads((ROOT / "manifest.json").read_text(encoding="utf-8"))["build_id"] == build_id
                count = len(view["events"])
                graph.request.get(args.graph + "/api/source?path=app/service.py")
                graph.request.get(args.graph + "/api/preferences")
                owner.request.get(args.app + "/api/stategraph")
                owner.request.get(args.app + "/api/stategraph/export")
                assert len(graph.request.get(args.graph + "/api/view").json()["events"]) == count
                report["checks"].append("App and graph share a current build; graph/source/query controls create no business events.")

                expect(graph.locator("#record-stop")).to_be_enabled(timeout=10000)
                with graph.expect_response(lambda response: response.url.endswith("/api/recordings/stop")) as stopped:
                    graph.locator("#record-stop").click()
                assert stopped.value.status == 200
                assert stopped.value.json()["id"] == recording_id
                recording = graph.request.get(args.graph + "/api/recordings/" + recording_id).json()
                assert recording["status"] == "stopped"
                assert not recording["gaps"], recording["gaps"]
                assert len(recording["events"]) > 0
                frames = [frame for frame in recording["runtime_frames"]["frames"]
                          if frame["authority"]["entity"] == file_id]
                assert [frame["machine"]["current"] for frame in frames] == ["pending", "private", "shared"]
                assert frames[1]["machine"]["journal"][0]["source"] == "pending"
                assert frames[1]["machine"]["journal"][0]["target"] == "private"
                assert frames[2]["machine"]["journal"][0]["source"] == "private"
                assert frames[2]["machine"]["journal"][0]["target"] == "shared"
                expect(graph.locator("#replay")).to_be_visible(timeout=15000)
                replay_witnesses = []
                timeline_input = {key: recording[key] for key in
                                  ("events", "commands", "status", "started_at", "ended_at")}
                for node, state in (("upload", "private"), ("share", "shared")):
                    event = next(event for event in recording["events"]
                                 if event["node"] == node and event["phase"] == "commit"
                                 and event["entity"] == file_id)
                    event_index = graph.evaluate("""async ({recording, id}) => {
                        const { timeline } = await import('/recording.js');
                        return timeline(recording).findIndex(event => event.id === id);
                    }""", {"recording": timeline_input, "id": event["id"]})
                    assert event_index > 0
                    graph.locator("#replay-events").select_option(str(event_index))
                    expect(graph.locator("#replay-position")).to_have_attribute("data-event-id", event["id"])
                    expect(graph.locator(f'[data-node-id="state.{state}"]')).to_have_attribute("data-run-state", "active")
                    replay_witnesses.append({"event_id": event["id"], "state": state,
                                             "timeline_index": event_index})
                report["replay_witnesses"] = replay_witnesses
                graph.screenshot(path=str(output / "graph-replay.png"), full_page=True)
                graph.locator("#replay-next").click()
                graph.locator("#replay-live").click()
                expect(graph.locator("#replay")).to_be_hidden(timeout=10000)
                graph.reload(wait_until="domcontentloaded")
                expect(graph.locator("#canvas-host canvas")).to_be_visible(timeout=15000)
                graph.wait_for_function("document.querySelector('#semantic').children.length > 0", timeout=20000)
                expect(graph.locator("#connection")).not_to_have_text("连接中", timeout=20000)
                expect(graph.locator("#project-title")).to_have_text("文件共享：用户、所有者与接收者")
                listing = graph.request.get(args.graph + "/api/recordings").json()
                assert recording_id in json.dumps(listing)
                graph.screenshot(path=str(output / "graph-live.png"), full_page=True)
                report["checks"].append("Real operation recording retains initial/pending, upload/private, and share/shared frames and transition witnesses, has no gaps, and replays after reload.")
                assert "trial-linzhou" not in json.dumps(recording["events"])
                assert content.decode().strip() not in json.dumps(recording["events"])
                assert not report["page_errors"], report["page_errors"]
                assert not report["console_errors"], report["console_errors"]
                (output / "recording.json").write_text(json.dumps(recording, ensure_ascii=False), encoding="utf-8")
                report.update(status="passed", build_id=build_id, recording_id=recording_id,
                              file_id=file_id, event_count=len(recording["events"]),
                              downloaded_sha256=hashlib.sha256(content).hexdigest(),
                              state_frames=[frame["machine"]["current"] for frame in frames])
            finally:
                browser.close()
    except Exception as error:
        report.update(status="failed", error=f"{type(error).__name__}: {error}")
        raise
    finally:
        (output / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        (ROOT / "review/browser-latest.json").write_text(json.dumps(
            {"report": str(output / "report.json"), "status": report["status"]}, indent=2), encoding="utf-8")
        print(json.dumps({"status": report["status"], "report": str(output / "report.json")}, ensure_ascii=True))


if __name__ == "__main__":
    main()
