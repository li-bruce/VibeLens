"""Add independently stated revocation expectations without changing earlier outcomes."""
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]


def read(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def write(name, value):
    (ROOT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    statuses = {
        "revoke_owner": 200, "revoke_nonowner_denied": 403, "revoke_anonymous_denied": 401,
        "revoke_idempotent": 200, "revoke_last_recipient": 200, "revoke_reshare": 200,
        "revoke_other_file_retained": 200, "revoke_unknown_recipient": 400,
    }
    acceptance = read("acceptance.json")
    if any(item["id"] == "revoke_owner-status" for item in acceptance["checks"]):
        raise RuntimeError("Do not replace protected expectations.")
    new_checks = []
    for case, expected in statuses.items():
        new_checks.append({"id": case + "-status", "requirement": "R_REVOKE",
                           "case": case, "path": ["status"], "equals": expected})
    success_cases = ["revoke_owner", "revoke_idempotent", "revoke_last_recipient",
                     "revoke_reshare", "revoke_other_file_retained"]
    for case in success_cases:
        values = {
            "revoked_download_status": 403, "revoked_metadata_status": 403,
            "owner_download_status": 200, "owner_bytes_match": True,
            "owner_id": "linzhou", "revoke_changed": True,
            "revoke_state": "private" if case == "revoke_last_recipient" else "shared",
            "remaining_after_revoke": [] if case == "revoke_last_recipient" else ["zhoulan"],
        }
        if case != "revoke_last_recipient":
            values.update(other_download_status=200, other_bytes_match=True)
        if case == "revoke_idempotent":
            values.update(duplicate_changed=False, duplicate_revision_unchanged=True)
        if case == "revoke_reshare":
            values.update(restored_download_status=200, restored_bytes_match=True)
        if case == "revoke_other_file_retained":
            values.update(other_file_download_status=200, other_file_bytes_match=True)
        for field, value in values.items():
            new_checks.append({"id": case + "-" + field, "requirement": "R_REVOKE",
                               "case": case, "path": [field], "equals": value})
    for case in ["revoke_nonowner_denied", "revoke_anonymous_denied", "revoke_unknown_recipient"]:
        for field, value in {"effect_unchanged": True, "recipient_download_status": 200}.items():
            new_checks.append({"id": case + "-" + field, "requirement": "R_REVOKE",
                               "case": case, "path": [field], "equals": value})
    acceptance["checks"].extend(new_checks)
    write("acceptance.json", acceptance)
    write("review/revocation-expectations.json",
          {"source": "User request U4; independent expected effects, not graph truth or observations.",
           "checks": new_checks})
    mapping = read("mapping.json")
    mapping["cases"].extend(statuses)
    write("mapping.json", mapping)
    whitebox = read("whitebox.json")
    whitebox["rules"].append({
        "id": "owner_revoke", "requirement": "R_REVOKE", "category": "parameter",
        "claim": "Only the authenticated owner cancels the selected file/recipient relation.",
        "basis": "discovery.json:U4; U5 is an authorized simulated scope restatement.",
        "node": "revoke", "source": {"path": "app/service.py", "symbol": "FileService.revoke"},
        "parameters": {"actor_id": "str", "file_id": "str", "recipient_id": "str"}, "returns": "dict",
    })
    for case, remaining, state in [("revoke_owner", ["zhoulan"], "shared"),
                                    ("revoke_last_recipient", [], "private")]:
        whitebox["checks"].append({
            "id": case + "-values", "rule": "owner_revoke", "case": case, "phase": "commit",
            "count": {"min": 1},
            "fields": [
                {"path": ["inputs", "actor_id"], "type": "string", "equals": "linzhou"},
                {"path": ["inputs", "recipient_id"], "type": "string", "equals": "xuning"},
                {"path": ["outputs", "owner_id"], "type": "string", "equals": "linzhou"},
                {"path": ["outputs", "state"], "type": "string", "equals": state},
                {"path": ["outputs", "changed"], "type": "boolean", "equals": True},
            ],
        })
    write("whitebox.json", whitebox)
    print(json.dumps({"new_cases": len(statuses), "new_assertions": len(new_checks),
                      "old_assertions_preserved": len(acceptance["checks"]) - len(new_checks)}))


if __name__ == "__main__":
    main()
