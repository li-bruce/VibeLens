# Design-only checks

The application has not been implemented. This checkpoint exists to review the supplied scope before coding.

- Discovery structure: passed; readiness is intentionally blocked by `D_GRAPH` until the displayed scope is confirmed in the conversation.
- Business and policy declarations: draft only; predicate functions and runtime evaluations do not exist yet.
- Browser viewer: passed in headless Chromium, with no page or console errors; see `design-browser/report.json` and `design-browser/graph.png`.
- Evidence provenance: forwarded requirements and design answers; no source-chat inspection or independent human testing.
- Deferred iteration: revocation and denial of a download from an unchanged recipient page after revocation.

Run these commands from the project directory in PowerShell:

```powershell
python -B ../vibelens-policy-graph/skills/vibelens/scripts/requirements_dialogue.py validate --file discovery.json
python -B ../vibelens-policy-graph/skills/vibelens/scripts/bo_web.py serve --root . --port 8841
```

In another terminal:

```powershell
python -B review/verify_design_browser.py --url http://127.0.0.1:8841/graph
```

The shared Skill source remains the explicitly selected frozen revision `088514b6f41f222944a47ca55e642b4ed99b37c3`. No installed older Skill or other trial is used. The design server has no application recording or state executor.
