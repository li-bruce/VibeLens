"""Authoritative file-sharing behavior, permissions, sessions, and effects."""
import hashlib
import json
import secrets
import time
import uuid
from pathlib import Path

from werkzeug.security import check_password_hash
from app.predicates import same_identity, flag_enabled
from bo_stategraph.policy.runtime import evaluate
from bo_stategraph.workflow import FileWorkflow

ROOT = Path(__file__).resolve().parents[1]
MAX_FILE_SIZE = 16 * 1024 * 1024


class BusinessError(Exception):
    def __init__(self, status: int, code: str):
        super().__init__(code)
        self.status, self.code = status, code


def digest_token(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def normalize_filename(value: str) -> str:
    name = value.replace("\\", "/").rsplit("/", 1)[-1].strip()
    name = "".join(character for character in name if ord(character) >= 32 and character != "\x7f")
    if not name or len(name) > 180:
        raise BusinessError(400, "invalid_filename")
    return name


def project_metadata(rows: list) -> list:
    return [{key: row[key] for key in
             ("id", "owner_id", "owner_name", "filename", "size", "state", "revision")}
            for row in rows]


class FileService:
    def __init__(self, store, build_id: str, events=None):
        self.store, self.build_id = store, build_id
        self.events = events or store.events
        project = json.loads((ROOT / "bo_stategraph/project.json").read_text(encoding="utf-8"))
        self.policy = project["model"]["policy"]

    def login(self, username: str, password: str) -> dict:
        with self.store.transaction() as connection:
            rows = self.store.query(connection, "SELECT * FROM users WHERE id=:id",
                                    {"id": username}, "login_user")
            allowed = bool(rows) and check_password_hash(rows[0]["password_hash"], password)
            if allowed:
                token, csrf = secrets.token_urlsafe(32), secrets.token_urlsafe(32)
                self.store.write(connection,
                    "INSERT INTO sessions(token_hash,user_id,csrf_hash,expires_at) "
                    "VALUES(:token,:user,:csrf,:expires)",
                    {"token": digest_token(token), "user": username, "csrf": digest_token(csrf),
                     "expires": int(time.time()) + 8 * 3600}, "create_session")
        self.events.bo_record("login", "return", {"username": username},
                              {"authenticated": allowed, "actor_id": username if allowed else ""})
        if not allowed:
            raise BusinessError(401, "invalid_credentials")
        return {"user": {"id": username, "display_name": rows[0]["display_name"]},
                "token": token, "csrf": csrf}

    def current_user(self, token: str) -> dict:
        if not token:
            self.events.bo_record("session_lookup", "return", {},
                                  {"authenticated": False, "actor_id": ""})
            return {}
        with self.store.engine.connect() as connection:
            rows = self.store.query(connection,
                "SELECT u.id,u.display_name,s.csrf_hash FROM sessions s "
                "JOIN users u ON u.id=s.user_id "
                "WHERE s.token_hash=:token AND s.expires_at>:clock",
                {"token": digest_token(token), "clock": int(time.time())}, "session_identity")
        result = rows[0] if rows else {}
        self.events.bo_record("session_lookup", "return", {},
            {"authenticated": bool(result), "actor_id": result.get("id", "")})
        return result

    def logout(self, token: str, actor_id: str) -> None:
        with self.store.transaction() as connection:
            self.store.write(connection, "DELETE FROM sessions WHERE token_hash=:token",
                             {"token": digest_token(token)}, "end_session")
        self.events.bo_record("logout", "commit", {"actor_id": actor_id}, {"authenticated": False})

    def users(self, actor_id: str) -> list:
        if not actor_id:
            raise BusinessError(401, "login_required")
        with self.store.engine.connect() as connection:
            rows = self.store.query(connection, "SELECT id,display_name FROM users ORDER BY id",
                                    {}, "recipient_options")
        self.events.bo_record("choose_recipient", "return", {"actor_id": actor_id},
                              {"user_ids": [row["id"] for row in rows]})
        return rows

    def authorise(self, connection, operation: str, actor_id: str, row=None,
                  recipient_id: str = "") -> dict:
        actor = self.store.query(connection, "SELECT id FROM users WHERE id=:id",
                                 {"id": actor_id}, "actor_exists") if actor_id else []
        grants = self.store.query(connection,
            "SELECT recipient_id FROM shares WHERE file_id=:file AND recipient_id=:actor",
            {"file": row["id"], "actor": actor_id}, "recipient_fact") if row else []
        recipient = self.store.query(connection, "SELECT id FROM users WHERE id=:id",
            {"id": recipient_id}, "recipient_exists") if recipient_id else []
        inputs = {"actor_id": actor_id, "owner_id": row["owner_id"] if row else "",
                  "logged_in": bool(actor), "received_share": bool(grants),
                  "recipient_exists": bool(recipient)}
        basis = f"{row['id']}:{row['revision']}" if row else "request:" + uuid.uuid4().hex
        result = evaluate(self.policy, operation, inputs,
                          {"same_identity": same_identity, "flag_enabled": flag_enabled},
                          fact_revision=basis, source_root=ROOT)
        self.events.bo_evaluation(self.policy, result,
                                 entity=row["id"] if row else "application",
                                 attempt=row["id"] if row else "application")
        self.events.bo_record("authorization", "decision",
            {"operation": operation, "actor_id": actor_id,
             "file_id": row["id"] if row else "", "recipient_id": recipient_id,
             "fact_revision": basis},
            {"allowed": result["value"] is True, "decision": result["decision"]},
            entity=row["id"] if row else "application",
            attempt=row["id"] if row else "application", scope="entity")
        if result["value"] is not True:
            if not actor:
                raise BusinessError(401, "login_required")
            if operation == "share" and same_identity(actor_id, row["owner_id"]) and not recipient:
                raise BusinessError(400, "recipient_not_found")
            raise BusinessError(403, "access_denied")
        return result

    def upload(self, actor_id: str, filename: str, content: bytes) -> dict:
        file_id = uuid.uuid4().hex
        with self.store.transaction() as connection:
            permission = self.authorise(connection, "upload", actor_id)
            filename = normalize_filename(filename)
            if len(content) > MAX_FILE_SIZE:
                raise BusinessError(413, "file_too_large")
            context = {"owner_id": actor_id, "filename": filename, "size": len(content),
                       "recipient_ids": [], "sha256": hashlib.sha256(content).hexdigest()}
            workflow = FileWorkflow(permission["value"])
            initial_state = "pending"
            initial_event = self.events.bo_record("upload", "enter",
                {"actor_id": actor_id, "filename": filename, "size": len(content)},
                {"file_id": file_id, "owner_id": actor_id, "state": initial_state,
                 "sha256": context["sha256"]},
                entity=file_id, attempt=file_id, scope="entity", revision=0)
            self.events.bo_snapshot({"id": file_id, "state": initial_state, "context": context,
                "revision": 0, "build_id": self.build_id, "journal": []},
                initial_event, event=None, guards={})
            transition = workflow.apply(initial_state, "upload", context)
            journal = [{"seq": 1, "event": "upload", "before": "pending",
                        "after": transition["state"], "guards": transition["guards"]}]
            self.store.write(connection,
                "INSERT INTO files(id,owner_id,filename,size,content,state,revision,build_id,journal) "
                "VALUES(:id,:owner,:name,:size,:content,:state,1,:build,:journal)",
                {"id": file_id, "owner": actor_id, "name": filename, "size": len(content),
                 "content": content, "state": transition["state"], "build": self.build_id,
                 "journal": json.dumps(journal)}, "upload_file")
        event_id = self.events.bo_record("upload", "commit",
            {"actor_id": actor_id, "filename": filename, "size": len(content)},
            {"file_id": file_id, "owner_id": actor_id, "state": transition["state"],
             "sha256": context["sha256"]},
            entity=file_id, attempt=file_id, scope="entity", revision=1)
        row = next(row for row in self.store.snapshot()["files"] if row["id"] == file_id)
        self.events.bo_snapshot(row, event_id, event="upload", guards=transition["guards"])
        return {"id": file_id, "filename": filename, "size": len(content), "owner_id": actor_id}

    def read_file(self, connection, file_id: str) -> dict:
        rows = self.store.query(connection,
            "SELECT f.*,u.display_name AS owner_name FROM files f JOIN users u ON u.id=f.owner_id "
            "WHERE f.id=:id", {"id": file_id}, "file_record")
        if not rows:
            raise BusinessError(404, "file_not_found")
        return rows[0]

    def metadata(self, actor_id: str, file_id: str) -> dict:
        with self.store.engine.connect() as connection:
            row = self.read_file(connection, file_id)
            self.authorise(connection, "view", actor_id, row)
            result = project_metadata([row])[0]
        self.events.bo_record("file_metadata", "return", {"actor_id": actor_id, "file_id": file_id},
                              {"filename": result["filename"], "size": result["size"],
                               "owner_id": result["owner_id"]}, entity=file_id,
                              attempt=file_id, scope="entity")
        return result

    def list_files(self, actor_id: str) -> list:
        if not actor_id:
            raise BusinessError(401, "login_required")
        with self.store.engine.connect() as connection:
            rows = self.store.query(connection,
                "SELECT f.id,f.owner_id,u.display_name AS owner_name,f.filename,f.size,f.state,f.revision "
                "FROM files f JOIN users u ON u.id=f.owner_id WHERE f.owner_id=:actor OR "
                "EXISTS(SELECT 1 FROM shares s WHERE s.file_id=f.id AND s.recipient_id=:actor) "
                "ORDER BY f.rowid DESC", {"actor": actor_id}, "visible_files")
            for row in rows:
                self.authorise(connection, "view", actor_id, row)
        result = self.events.bo_transform("db.metadata", project_metadata, rows,
            before=lambda value: {"count": len(value)}, after=lambda value: {"count": len(value)})
        with self.store.engine.connect() as connection:
            for item in result:
                item["recipients"] = self.store.query(connection,
                    "SELECT u.id,u.display_name FROM shares s JOIN users u ON u.id=s.recipient_id "
                    "WHERE s.file_id=:id AND :actor=:owner ORDER BY u.id",
                    {"id": item["id"], "actor": actor_id, "owner": item["owner_id"]},
                    "visible_recipients")
        self.events.bo_record("received_list", "return", {"actor_id": actor_id},
                              {"file_ids": [row["id"] for row in result], "count": len(result)})
        return result

    def share(self, actor_id: str, file_id: str, recipient_id: str) -> dict:
        changed = False
        with self.store.transaction() as connection:
            row = self.read_file(connection, file_id)
            permission = self.authorise(connection, "share", actor_id, row, recipient_id)
            existing = self.store.query(connection,
                "SELECT recipient_id FROM shares WHERE file_id=:file AND recipient_id=:recipient",
                {"file": file_id, "recipient": recipient_id}, "existing_share")
            if not existing:
                context = next(record["context"] for record in self.store.snapshot()["files"]
                               if record["id"] == file_id)
                transition = FileWorkflow(permission["value"]).apply(row["state"], "share", context)
                journal = json.loads(row["journal"])
                revision = row["revision"] + 1
                journal.append({"seq": revision, "event": "share", "before": row["state"],
                                "after": transition["state"], "guards": transition["guards"]})
                self.store.write(connection,
                    "INSERT INTO shares(file_id,recipient_id,shared_by) VALUES(:file,:recipient,:actor)",
                    {"file": file_id, "recipient": recipient_id, "actor": actor_id}, "create_share")
                self.store.write(connection,
                    "UPDATE files SET state=:state,revision=:revision,journal=:journal,build_id=:build "
                    "WHERE id=:id",
                    {"state": transition["state"], "revision": revision,
                     "journal": json.dumps(journal), "id": file_id, "build": self.build_id},
                    "share_file_state")
                changed = True
        current = next(record for record in self.store.snapshot()["files"] if record["id"] == file_id)
        event_id = self.events.bo_record("share", "commit",
            {"actor_id": actor_id, "file_id": file_id, "recipient_id": recipient_id},
            {"state": current["state"], "changed": changed, "recipient_id": recipient_id},
            entity=file_id, attempt=file_id, scope="entity",
            revision=current["revision"] if changed else None)
        if changed:
            self.events.bo_snapshot(current, event_id, event="share", guards=transition["guards"])
        return {"file_id": file_id, "recipient_id": recipient_id, "changed": changed}

    def download(self, actor_id: str, file_id: str) -> dict:
        with self.store.engine.connect() as connection:
            row = self.read_file(connection, file_id)
            self.authorise(connection, "download", actor_id, row)
            result = {"filename": row["filename"], "content": row["content"]}
        self.events.bo_record("download", "return", {"actor_id": actor_id, "file_id": file_id},
            {"size": len(result["content"]), "sha256": hashlib.sha256(result["content"]).hexdigest()},
            entity=file_id, attempt=file_id, scope="entity")
        return result
