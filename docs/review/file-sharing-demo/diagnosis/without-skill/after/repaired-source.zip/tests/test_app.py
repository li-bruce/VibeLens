"""Exercise real HTTP requests and an isolated SQLite database."""

from __future__ import annotations

import hashlib
import http.cookiejar
import json
import sqlite3
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from contextlib import closing
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app import DEMO_PASSWORD, MAX_FILE_BYTES, create_server


class Client:
    def __init__(self, base_url: str):
        self.base_url = base_url
        self.cookies = http.cookiejar.CookieJar()
        self.opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.cookies))
        self.csrf_token = ""
        self.user = None

    def request(self, path, method="GET", body=None, headers=None, csrf=True):
        headers = dict(headers or {})
        if method != "GET" and csrf:
            headers["X-CSRF-Token"] = self.csrf_token
        if isinstance(body, dict):
            body = json.dumps(body).encode()
            headers["Content-Type"] = "application/json"
        request = urllib.request.Request(self.base_url + path, data=body, method=method, headers=headers)
        try:
            response = self.opener.open(request, timeout=10)
        except urllib.error.HTTPError as error:
            response = error
        with response:
            raw = response.read()
            value = json.loads(raw) if response.headers.get_content_type() == "application/json" else raw
            return response.status, value, response.headers

    def login(self, username):
        status, body, headers = self.request("/api/login", "POST", {"username": username, "password": DEMO_PASSWORD})
        assert status == 200, body
        self.csrf_token = body["csrf_token"]
        self.user = body["user"]
        return headers

    def upload(self, name="sample.txt", content=b"The owner chose one recipient.\n", extra_fields=b""):
        boundary = "test-boundary-20261028"
        prefix = (f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="{name}"\r\n'
                  'Content-Type: application/octet-stream\r\n\r\n').encode()
        body = prefix + content + b"\r\n" + extra_fields + f"--{boundary}--\r\n".encode()
        return self.request("/api/files", "POST", body, {"Content-Type": f"multipart/form-data; boundary={boundary}"})


class FileSharingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.test_root = Path(__file__).resolve().parents[1] / "review" / ".tmp"
        cls.test_root.mkdir(parents=True, exist_ok=True)
        cls.temporary = tempfile.TemporaryDirectory(prefix="http-", dir=cls.test_root)
        cls.data_dir = Path(cls.temporary.name)
        cls.server = create_server(cls.data_dir, port=0)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base_url = f"http://127.0.0.1:{cls.server.server_address[1]}"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=5)
        cls.data_dir.resolve().relative_to(cls.test_root.resolve())
        cls.temporary.cleanup()

    def setUp(self):
        self.owner = Client(self.base_url)
        self.owner.login("linzhou")
        self.recipient = Client(self.base_url)
        self.recipient.login("xuning")
        self.outsider = Client(self.base_url)
        self.outsider.login("zhoulan")

    def upload_file(self, **kwargs):
        status, file, _ = self.owner.upload(**kwargs)
        self.assertEqual(status, 201, file)
        return file

    def share_file(self, file):
        status, body, _ = self.owner.request(f"/api/files/{file['id']}/shares", "POST", {"recipient_id": self.recipient.user["id"]})
        self.assertEqual(status, 200, body)

    def test_primary_story_owner_recipient_and_outsider(self):
        content = "林舟的文件，分享给许宁。\n".encode()
        file = self.upload_file(name="project-notes.txt", content=content)
        self.assertEqual(file["owner_id"], self.owner.user["id"])
        download_path = f"/api/files/{file['id']}/download"
        status, data, headers = self.owner.request(download_path)
        self.assertEqual((status, data), (200, content))
        self.assertEqual(headers["Cache-Control"], "no-store")
        self.assertTrue(headers["Content-Disposition"].startswith("attachment;"))
        self.assertEqual(self.recipient.request(download_path)[0], 403)
        self.share_file(file)
        owned = self.owner.request("/api/files")[1]["owned"]
        entry = next(item for item in owned if item["id"] == file["id"])
        self.assertEqual(entry["recipients"], [{"id": self.recipient.user["id"], "display_name": "许宁"}])
        received = self.recipient.request("/api/files")[1]["received"]
        entry = next(item for item in received if item["id"] == file["id"])
        self.assertEqual((entry["name"], entry["size"], entry["owner_name"], entry["is_owner"]),
                         (file["name"], len(content), "林舟", False))
        status, data, _ = self.recipient.request(download_path)
        self.assertEqual(status, 200)
        self.assertEqual(hashlib.sha256(data).hexdigest(), hashlib.sha256(content).hexdigest())
        outsider_files = self.outsider.request("/api/files")[1]
        self.assertNotIn(file["id"], [item["id"] for item in outsider_files["received"] + outsider_files["owned"]])
        self.assertEqual(self.outsider.request(download_path)[0], 403)
        self.assertEqual(self.outsider.request(f"/api/files/{file['id']}")[0], 403)

    def test_recipient_cannot_reshare_even_with_a_direct_request(self):
        file = self.upload_file()
        self.share_file(file)
        status, _, _ = self.recipient.request(f"/api/files/{file['id']}/shares", "POST", {"recipient_id": self.outsider.user["id"]})
        self.assertEqual(status, 403)
        self.assertEqual(self.outsider.request(f"/api/files/{file['id']}/download")[0], 403)

    def test_new_upload_does_not_inherit_another_files_recipients(self):
        first = self.upload_file(name="same-name.txt", content=b"first")
        self.share_file(first)
        second = self.upload_file(name="same-name.txt", content=b"second")
        self.assertNotEqual(first["id"], second["id"])
        self.assertEqual(self.recipient.request(f"/api/files/{second['id']}/download")[0], 403)
        self.assertEqual(self.owner.request(f"/api/files/{first['id']}/download")[1], b"first")
        self.assertEqual(self.owner.request(f"/api/files/{second['id']}/download")[1], b"second")

    def test_owner_id_cannot_be_assigned_by_the_upload_request(self):
        extra = (f'--test-boundary-20261028\r\nContent-Disposition: form-data; name="owner_id"\r\n\r\n'
                 f'{self.outsider.user["id"]}\r\n').encode()
        file = self.upload_file(extra_fields=extra)
        self.assertEqual(file["owner_id"], self.owner.user["id"])

    def test_every_account_can_upload_its_own_private_file(self):
        status, file, _ = self.outsider.upload("private.txt", b"Zhou Lan owns this file.")
        self.assertEqual(status, 201)
        self.assertEqual(file["owner_id"], self.outsider.user["id"])
        self.assertEqual(self.owner.request(f"/api/files/{file['id']}/download")[0], 403)

    def test_session_authentication_and_logout(self):
        anonymous = Client(self.base_url)
        self.assertIsNone(anonymous.request("/api/session")[1]["user"])
        self.assertEqual(anonymous.request("/api/files")[0], 401)
        self.assertEqual(anonymous.request("/api/users")[0], 401)
        file = self.upload_file()
        self.assertEqual(anonymous.request(f"/api/files/{file['id']}/download")[0], 401)
        self.assertEqual(anonymous.request("/api/login", "POST", {"username": "linzhou", "password": "wrong"})[0], 401)
        headers = anonymous.login("linzhou")
        self.assertIn("HttpOnly", headers["Set-Cookie"])
        self.assertIn("SameSite=Strict", headers["Set-Cookie"])
        self.assertEqual(anonymous.request("/api/logout", "POST")[0], 200)
        self.assertEqual(anonymous.request(f"/api/files/{file['id']}/download")[0], 401)

    def test_mutations_require_csrf_and_same_origin(self):
        file = self.upload_file()
        path = f"/api/files/{file['id']}/shares"
        payload = {"recipient_id": self.recipient.user["id"]}
        self.assertEqual(self.owner.request(path, "POST", payload, csrf=False)[0], 403)
        self.assertEqual(self.owner.request(path, "POST", payload, {"Origin": "http://example.invalid"})[0], 403)
        self.assertEqual(self.recipient.request(f"/api/files/{file['id']}/download")[0], 403)

    def test_invalid_recipient_and_duplicate_share(self):
        file = self.upload_file()
        path = f"/api/files/{file['id']}/shares"
        for recipient_id in (self.owner.user["id"], 99999, -1, 2**80, "2", True, None):
            with self.subTest(recipient_id=recipient_id):
                self.assertEqual(self.owner.request(path, "POST", {"recipient_id": recipient_id})[0], 400)
        self.share_file(file)
        self.share_file(file)
        with closing(sqlite3.connect(self.data_dir / "app.sqlite3")) as db:
            self.assertEqual(db.execute("SELECT count(*) FROM shares WHERE file_id = ?", (file["id"],)).fetchone()[0], 1)

    def test_non_owner_cannot_share_an_unshared_file(self):
        file = self.upload_file()
        self.assertEqual(self.outsider.request(f"/api/files/{file['id']}/shares", "POST", {"recipient_id": self.recipient.user["id"]})[0], 403)

    def test_multipart_size_limits_and_empty_files(self):
        status, _, _ = self.owner.upload("too-large.bin", b"x" * (MAX_FILE_BYTES + 1))
        self.assertEqual(status, 413)
        status, file, _ = self.owner.upload("empty.txt", b"")
        self.assertEqual(status, 201)
        self.assertEqual(self.owner.request(f"/api/files/{file['id']}/download")[1], b"")
        self.assertEqual(self.owner.request("/api/files", "POST", b"invalid", {"Content-Type": "text/plain"})[0], 415)
        self.assertEqual(self.owner.request("/api/files", "POST", b"invalid", {"Content-Type": "multipart/form-data; boundary=none"})[0], 400)

    def test_file_names_and_storage_do_not_expose_arbitrary_paths(self):
        file = self.upload_file(name="../../outside.txt", content=b"path-safe")
        self.assertEqual(file["name"], "outside.txt")
        self.assertEqual(self.owner.request(f"/api/files/{file['id']}/download")[1], b"path-safe")
        for path in ("/data/app.sqlite3", "/../app.py", "/static/../app.py", "/api/files/not-a-number/download"):
            self.assertEqual(self.owner.request(path)[0], 404, path)
        info = self.owner.request(f"/api/files/{file['id']}")[1]
        self.assertNotIn("storage_key", info)

    def test_data_and_permissions_survive_a_new_server_instance(self):
        file = self.upload_file(content=b"persistent content")
        self.share_file(file)
        other = create_server(self.data_dir, port=0)
        thread = threading.Thread(target=other.serve_forever, daemon=True)
        thread.start()
        try:
            client = Client(f"http://127.0.0.1:{other.server_address[1]}")
            client.login("xuning")
            self.assertEqual(client.request(f"/api/files/{file['id']}/download")[:2], (200, b"persistent content"))
        finally:
            other.shutdown()
            other.server_close()
            thread.join(timeout=5)


if __name__ == "__main__":
    unittest.main(verbosity=2)
