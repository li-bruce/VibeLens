"""Run a real-browser acceptance flow and preserve review evidence."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
import tempfile
import threading
import traceback
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from app import create_server
from playwright.sync_api import expect, sync_playwright

SAMPLE_NAME = "demo-project-notes.txt"
SAMPLE_BYTES = (
    b"File Desk - V1 acceptance sample\n"
    b"Owner: Lin Zhou (linzhou)\n"
    b"Recipient: Xu Ning (xuning)\n"
    b"Zhou Lan has not been granted access.\n"
)


def sign_in(page, base_url, username):
    page.goto(base_url, wait_until="networkidle")
    page.locator(f'[data-account="{username}"]').click()
    page.get_by_role("button", name="Sign in").click()
    expect(page.locator("#workspace-view")).to_be_visible()
    expect(page.locator("#account-username")).to_have_text(username)
    expect(page.locator("#refresh-files")).to_be_visible()


def run_flow(base_url, browser_executable, temporary_root, evidence_dir, result):
    screenshot_dir = evidence_dir / "screenshots"
    download_dir = evidence_dir / "downloads"
    screenshot_dir.mkdir(parents=True, exist_ok=True)
    download_dir.mkdir(parents=True, exist_ok=True)
    browser_errors = []
    checks = []
    result.update({"checks": checks, "browser_errors": browser_errors, "screenshots": str(screenshot_dir.relative_to(ROOT))})
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(
            executable_path=browser_executable, headless=True,
            downloads_path=str(temporary_root / "browser-downloads"),
        )
        result["browser"] = browser.version
        contexts = []

        def new_page():
            context = browser.new_context(viewport={"width": 1440, "height": 1000}, accept_downloads=True)
            contexts.append(context)
            page = context.new_page()
            page.on("pageerror", lambda error: browser_errors.append(str(error)))
            return page

        try:
            owner = new_page()
            owner.goto(base_url, wait_until="networkidle")
            expect(owner.get_by_role("heading", name="Sign in")).to_be_visible()
            owner.screenshot(path=str(screenshot_dir / "v1-login.png"), full_page=True)
            sign_in(owner, base_url, "linzhou")
            owner.locator("#file-input").set_input_files({"name": SAMPLE_NAME, "mimeType": "text/plain", "buffer": SAMPLE_BYTES})
            with owner.expect_response(lambda response: response.url.endswith("/api/files") and response.request.method == "POST") as uploaded:
                owner.get_by_role("button", name="Upload file").click()
            assert uploaded.value.status == 201
            file_id = uploaded.value.json()["id"]
            result["file_id"] = file_id
            row = owner.locator(f'tr[data-file-id="{file_id}"]')
            expect(row).to_contain_text(SAMPLE_NAME)
            expect(row).to_contain_text("Only you")
            checks.append({"name": "Owner uploads a private file through the UI", "result": "passed", "file_id": file_id})

            recipient = new_page()
            sign_in(recipient, base_url, "xuning")
            before = recipient.context.request.get(f"{base_url}/api/files/{file_id}/download")
            assert before.status == 403
            checks.append({"name": "Recipient cannot download before being selected", "result": "passed", "http_status": before.status})

            row.get_by_role("combobox").select_option(label="许宁")
            with owner.expect_response(lambda response: response.url.endswith(f"/api/files/{file_id}/shares")) as shared:
                row.get_by_role("button", name="Share", exact=True).click()
            assert shared.value.status == 200
            expect(row).to_contain_text("许宁 · View & download")
            owner.screenshot(path=str(screenshot_dir / "v1-owner.png"), full_page=True)
            checks.append({"name": "Owner selects Xu Ning and sees the explicit grant", "result": "passed"})

            recipient.get_by_role("button", name="Refresh").click()
            recipient.get_by_role("tab", name=re.compile("Shared with me")).click()
            received_row = recipient.locator(f'tr[data-file-id="{file_id}"]')
            expect(received_row).to_contain_text(SAMPLE_NAME)
            expect(received_row).to_contain_text(f"{len(SAMPLE_BYTES)} B")
            expect(received_row).to_contain_text("林舟")
            expect(received_row).to_contain_text("View & download")
            expect(received_row.get_by_role("combobox")).to_have_count(0)
            expect(received_row.get_by_role("button", name="Share", exact=True)).to_have_count(0)
            with recipient.expect_download() as downloaded:
                received_row.get_by_role("button", name=f"Download {SAMPLE_NAME}", exact=True).click()
            download = downloaded.value
            target = download_dir / "v1-recipient-demo-project-notes.txt"
            download.save_as(target)
            assert download.suggested_filename == SAMPLE_NAME
            assert target.read_bytes() == SAMPLE_BYTES
            recipient.screenshot(path=str(screenshot_dir / "v1-recipient.png"), full_page=True)
            checks.append({"name": "Recipient sees name, size, owner and downloads identical bytes", "result": "passed",
                           "sha256": hashlib.sha256(target.read_bytes()).hexdigest()})
            checks.append({"name": "Recipient has no sharing control", "result": "passed"})

            outsider = new_page()
            sign_in(outsider, base_url, "zhoulan")
            outsider.get_by_role("tab", name=re.compile("Shared with me")).click()
            expect(outsider.locator(f'tr[data-file-id="{file_id}"]')).to_have_count(0)
            denied = outsider.context.request.get(f"{base_url}/api/files/{file_id}/download")
            assert denied.status == 403
            outsider.screenshot(path=str(screenshot_dir / "v1-outsider.png"), full_page=True)
            checks.append({"name": "Zhou Lan sees no grant and direct download returns 403", "result": "passed", "http_status": denied.status})

            recipient_session = recipient.context.request.get(f"{base_url}/api/session").json()
            outsider_session = outsider.context.request.get(f"{base_url}/api/session").json()
            forbidden_share = recipient.context.request.post(
                f"{base_url}/api/files/{file_id}/shares",
                headers={"X-CSRF-Token": recipient_session["csrf_token"]},
                data={"recipient_id": outsider_session["user"]["id"]},
            )
            assert forbidden_share.status == 403
            checks.append({"name": "Recipient cannot share through a forged direct request", "result": "passed", "http_status": forbidden_share.status})

            owner.reload(wait_until="networkidle")
            expect(owner.locator("#account-username")).to_have_text("linzhou")
            expect(owner.locator(f'tr[data-file-id="{file_id}"]')).to_contain_text("许宁 · View & download")
            checks.append({"name": "Reload preserves the authenticated user and stored grant", "result": "passed"})

            owner.set_viewport_size({"width": 390, "height": 844})
            expect(owner.get_by_role("heading", name="林舟's file desk.")).to_be_visible()
            assert owner.evaluate("document.documentElement.scrollWidth <= window.innerWidth")
            owner.screenshot(path=str(screenshot_dir / "v1-mobile.png"), full_page=True)
            checks.append({"name": "Narrow browser viewport has no page-level horizontal overflow", "result": "passed"})

            recipient.get_by_role("button", name="Sign out", exact=True).click()
            expect(recipient.get_by_role("heading", name="Sign in")).to_be_visible()
            after_logout = recipient.context.request.get(f"{base_url}/api/files/{file_id}/download")
            assert after_logout.status == 401
            checks.append({"name": "Sign out invalidates authenticated download", "result": "passed", "http_status": after_logout.status})
            assert not browser_errors, browser_errors
            checks.append({"name": "No browser JavaScript exceptions", "result": "passed"})
            result["status"] = "passed"
            return result
        except Exception:
            for index, context in enumerate(contexts):
                for page_index, page in enumerate(context.pages):
                    try:
                        page.screenshot(path=str(screenshot_dir / f"failure-context-{index}-page-{page_index}.png"), full_page=True, timeout=5000)
                    except Exception:
                        pass
            raise
        finally:
            for context in contexts:
                context.close()
            browser.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url")
    parser.add_argument("--browser-executable", default=r"C:\Program Files\Google\Chrome\Application\chrome.exe")
    parser.add_argument("--run-id")
    args = parser.parse_args()
    test_root = ROOT / "review" / ".tmp"
    test_root.mkdir(parents=True, exist_ok=True)
    temporary = tempfile.TemporaryDirectory(prefix="browser-", dir=test_root)
    temporary_root = Path(temporary.name)
    os.environ["TEMP"] = str(temporary_root)
    os.environ["TMP"] = str(temporary_root)
    tempfile.tempdir = str(temporary_root)
    server = None
    thread = None
    started_at = datetime.now(timezone(timedelta(hours=8)))
    run_id = args.run_id or started_at.strftime("%Y%m%dT%H%M%S-%f")
    if not re.fullmatch(r"[A-Za-z0-9_-]+", run_id):
        parser.error("The run ID must contain only letters, digits, underscores, or hyphens.")
    evidence_dir = ROOT / "review" / "browser-runs" / run_id
    evidence_dir.mkdir(parents=True, exist_ok=False)
    result = {"run_id": run_id, "timestamp": started_at.isoformat(), "status": "running", "headless": True,
              "sample_name": SAMPLE_NAME, "data_mode": "running demo; sample retained" if args.base_url else "isolated temporary database"}
    try:
        base_url = args.base_url
        if not base_url:
            server = create_server(temporary_root / "data", port=0)
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            base_url = f"http://127.0.0.1:{server.server_address[1]}"
        result["base_url"] = base_url
        run_flow(base_url, args.browser_executable, temporary_root, evidence_dir, result)
        (ROOT / "review" / "browser-results-v1.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception as error:
        result.update({"status": "failed", "error": str(error), "traceback": traceback.format_exc()})
        raise
    finally:
        result["finished_at"] = datetime.now(timezone(timedelta(hours=8))).isoformat()
        (evidence_dir / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps(result, ensure_ascii=False, indent=2))
        if server:
            server.shutdown()
            server.server_close()
            thread.join(timeout=5)
        temporary_root.resolve().relative_to(test_root.resolve())
        temporary.cleanup()


if __name__ == "__main__":
    main()
