"""Verify revocation authorization, scope, persistence, and existing behavior."""

from __future__ import annotations

import sqlite3
import tempfile
import threading
import unittest
from contextlib import closing
from pathlib import Path

from test_app import Client
from app import create_server


class SharingRevocationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.test_root = Path(__file__).resolve().parents[1] / "review" / ".tmp"
        cls.test_root.mkdir(parents=True, exist_ok=True)
        cls.temporary = tempfile.TemporaryDirectory(prefix="revoke-http-", dir=cls.test_root)
        cls.data_dir = Path(cls.temporary.name)
        cls.server = create_server(cls.data_dir, port=0)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base_url = f"http://127.0.0.1:{cls.server.server_address[1]}"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=5)
        cls.data_dir.resolve().relative_to(cls.test_root.resolve())
        cls.temporary.cleanup()

    def setUp(self):
        self.owner = Client(self.base_url)
        self.owner.login("linzhou")
        self.recipient = Client(self.base_url)
        self.recipient.login("xuning")
        self.outsider = Client(self.base_url)
        self.outsider.login("zhoulan")
        self.content = b"Revoking access keeps the owner's file intact.\n"
        status, self.file, _ = self.owner.upload("revocation-test.txt", self.content)
        self.assertEqual(status, 201)
        self.file_id = self.file["id"]
        self.download_path = f"/api/files/{self.file_id}/download"
        self.revoke_path = f"/api/files/{self.file_id}/revoke"
        self.share(self.file_id, self.recipient)

    def share(self, file_id, recipient):
        status, body, _ = self.owner.request(f"/api/files/{file_id}/shares", "POST", {"recipient_id": recipient.user["id"]})
        self.assertEqual(status, 200, body)

    def revoke(self):
        return self.owner.request(self.revoke_path, "POST", {"recipient_id": self.recipient.user["id"]})

    def test_owner_revokes_access_but_keeps_ownership_and_content(self):
        self.assertEqual(self.recipient.request(self.download_path)[:2], (200, self.content))
        status, body, _ = self.revoke()
        self.assertEqual(status, 200)
        self.assertFalse(body["shared"])
        self.assertEqual(self.recipient.request(self.download_path)[0], 403)
        self.assertEqual(self.recipient.request(f"/api/files/{self.file_id}")[0], 403)
        self.assertNotIn(self.file_id, [item["id"] for item in self.recipient.request("/api/files")[1]["received"]])
        self.assertEqual(self.owner.request(self.download_path)[:2], (200, self.content))
        owned = next(item for item in self.owner.request("/api/files")[1]["owned"] if item["id"] == self.file_id)
        self.assertEqual(owned["owner_id"], self.owner.user["id"])
        self.assertEqual(owned["recipients"], [])
        with closing(sqlite3.connect(self.data_dir / "app.sqlite3")) as db:
            storage_key = db.execute("SELECT storage_key FROM files WHERE id = ?", (self.file_id,)).fetchone()[0]
        self.assertEqual((self.data_dir / "uploads" / storage_key).read_bytes(), self.content)

    def test_recipient_and_unrelated_user_cannot_revoke_any_grant(self):
        self.share(self.file_id, self.outsider)
        for actor, target in ((self.recipient, self.outsider), (self.outsider, self.recipient)):
            with self.subTest(actor=actor.user["username"]):
                status, _, _ = actor.request(self.revoke_path, "POST", {"recipient_id": target.user["id"], "owner_id": self.owner.user["id"]})
                self.assertEqual(status, 403)
        self.assertEqual(self.recipient.request(self.download_path)[0], 200)
        self.assertEqual(self.outsider.request(self.download_path)[0], 200)

    def test_cancellation_targets_one_file_and_one_recipient(self):
        self.share(self.file_id, self.outsider)
        status, second_file, _ = self.owner.upload("another-file.txt", b"another file")
        self.assertEqual(status, 201)
        self.share(second_file["id"], self.recipient)
        self.assertEqual(self.revoke()[0], 200)
        self.assertEqual(self.recipient.request(self.download_path)[0], 403)
        self.assertEqual(self.outsider.request(self.download_path)[:2], (200, self.content))
        self.assertEqual(self.recipient.request(f"/api/files/{second_file['id']}/download")[:2], (200, b"another file"))

    def test_revocation_survives_another_server_instance(self):
        self.assertEqual(self.revoke()[0], 200)
        other = create_server(self.data_dir, port=0)
        thread = threading.Thread(target=other.serve_forever, daemon=True)
        thread.start()
        try:
            client = Client(f"http://127.0.0.1:{other.server_address[1]}")
            client.login("xuning")
            self.assertEqual(client.request(self.download_path)[0], 403)
            client.login("linzhou")
            self.assertEqual(client.request(self.download_path)[:2], (200, self.content))
        finally:
            other.shutdown()
            other.server_close()
            thread.join(timeout=5)

    def test_repeat_cancellation_and_original_resharing_work(self):
        self.assertEqual(self.revoke()[0], 200)
        self.assertEqual(self.revoke()[0], 200)
        self.assertEqual(self.recipient.request(self.download_path)[0], 403)
        self.share(self.file_id, self.recipient)
        self.assertEqual(self.recipient.request(self.download_path)[:2], (200, self.content))

    def test_cancel_requires_login_csrf_and_same_origin(self):
        payload = {"recipient_id": self.recipient.user["id"]}
        self.assertEqual(Client(self.base_url).request(self.revoke_path, "POST", payload)[0], 401)
        self.assertEqual(self.owner.request(self.revoke_path, "POST", payload, csrf=False)[0], 403)
        self.assertEqual(self.owner.request(self.revoke_path, "POST", payload, {"Origin": "http://example.invalid"})[0], 403)
        self.assertEqual(self.recipient.request(self.download_path)[0], 200)

    def test_invalid_cancellation_targets_do_not_change_access(self):
        for recipient_id in (self.owner.user["id"], 99999, -1, 2**80, "2", True, None):
            with self.subTest(recipient_id=recipient_id):
                self.assertEqual(self.owner.request(self.revoke_path, "POST", {"recipient_id": recipient_id})[0], 400)
        self.assertEqual(self.recipient.request(self.download_path)[0], 200)

    def test_unknown_file_cancellation_is_not_success(self):
        self.assertEqual(self.owner.request("/api/files/999999/revoke", "POST", {"recipient_id": self.recipient.user["id"]})[0], 404)


if __name__ == "__main__":
    unittest.main(verbosity=2)
