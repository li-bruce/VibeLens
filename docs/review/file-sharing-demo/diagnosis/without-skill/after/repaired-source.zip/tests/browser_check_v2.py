"""Run V1 regression and V2 stale-page revocation acceptance headlessly."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import tempfile
import threading
import traceback
from datetime import datetime, timedelta, timezone
from pathlib import Path

from browser_check import ROOT, run_flow, sign_in
from app import create_server
from playwright.sync_api import expect, sync_playwright

SAMPLE_NAME = "revocation-sample.txt"
SAMPLE_BYTES = b"V2 sample: cancel one recipient, keep the owner's file.\n"


def revocation_flow(base_url, executable, temporary_root, evidence_dir, result):
    screenshots = evidence_dir / "screenshots"
    downloads = evidence_dir / "downloads"
    screenshots.mkdir(parents=True, exist_ok=True)
    downloads.mkdir(parents=True, exist_ok=True)
    result.update({"checks": [], "browser_errors": [], "recipient_requests_after_cancel": []})
    checks = result["checks"]
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(executable_path=executable, headless=True,
                                            downloads_path=str(temporary_root / "revocation-downloads"))
        contexts = []

        def new_page():
            context = browser.new_context(viewport={"width": 1440, "height": 1000}, accept_downloads=True)
            contexts.append(context)
            page = context.new_page()
            page.on("pageerror", lambda error: result["browser_errors"].append(str(error)))
            return page

        def share(owner_row):
            owner_row.get_by_role("combobox").select_option(label="许宁")
            with owner.expect_response(lambda response: response.url.endswith(f"/api/files/{file_id}/shares")) as response:
                owner_row.get_by_role("button", name="Share", exact=True).click()
            assert response.value.status == 200
            expect(owner_row).to_contain_text("许宁 · View & download")

        def cancel(owner_row):
            with owner.expect_response(lambda response: response.url.endswith(f"/api/files/{file_id}/revoke")) as response:
                owner_row.get_by_role("button", name=f"Cancel sharing with 许宁 for {SAMPLE_NAME}", exact=True).click()
            assert response.value.status == 200
            expect(owner_row).to_contain_text("Only you")

        def download(page, row, name):
            with page.expect_download() as download_event:
                row.get_by_role("button", name=f"Download {SAMPLE_NAME}", exact=True).click()
            target = downloads / name
            download_event.value.save_as(target)
            assert target.read_bytes() == SAMPLE_BYTES
            return hashlib.sha256(target.read_bytes()).hexdigest()

        try:
            owner = new_page()
            sign_in(owner, base_url, "linzhou")
            owner.locator("#file-input").set_input_files({"name": SAMPLE_NAME, "mimeType": "text/plain", "buffer": SAMPLE_BYTES})
            with owner.expect_response(lambda response: response.url.endswith("/api/files") and response.request.method == "POST") as uploaded:
                owner.get_by_role("button", name="Upload file").click()
            assert uploaded.value.status == 201
            file_id = uploaded.value.json()["id"]
            result["file_id"] = file_id
            owner_row = owner.locator(f'tr[data-file-id="{file_id}"]')
            expect(owner_row).to_contain_text("Only you")
            share(owner_row)
            expect(owner_row.get_by_role("button", name=f"Cancel sharing with 许宁 for {SAMPLE_NAME}", exact=True)).to_be_visible()
            owner.screenshot(path=str(screenshots / "v2-owner-before-cancel.png"), full_page=True)
            checks.append({"name": "Owner uploads, shares and sees a recipient-specific cancellation control", "result": "passed"})

            recipient = new_page()
            sign_in(recipient, base_url, "xuning")
            recipient.get_by_role("tab", name=re.compile("Shared with me")).click()
            recipient_row = recipient.locator(f'tr[data-file-id="{file_id}"]')
            expect(recipient_row).to_contain_text(SAMPLE_NAME)
            expect(recipient.locator(".cancel-share-button")).to_have_count(0)
            content_hash = download(recipient, recipient_row, "recipient-before-cancel.txt")
            recipient.screenshot(path=str(screenshots / "v2-recipient-before-cancel.png"), full_page=True)
            checks.append({"name": "Recipient can download before cancellation and has no cancellation control", "result": "passed", "sha256": content_hash})

            outsider = new_page()
            sign_in(outsider, base_url, "zhoulan")
            expect(outsider.locator(".cancel-share-button")).to_have_count(0)
            for actor, actor_name in ((recipient, "xuning"), (outsider, "zhoulan")):
                session = actor.context.request.get(f"{base_url}/api/session").json()
                rejected = actor.context.request.post(f"{base_url}/api/files/{file_id}/revoke",
                    headers={"X-CSRF-Token": session["csrf_token"]}, data={"recipient_id": 2})
                assert rejected.status == 403
                checks.append({"name": f"Non-owner {actor_name} cannot cancel through a direct request", "result": "passed", "http_status": rejected.status})

            original_page_time = recipient.evaluate("performance.timeOrigin")
            recipient_requests = result["recipient_requests_after_cancel"]
            recipient.on("request", lambda request: recipient_requests.append({"method": request.method, "url": request.url}))
            download_events = []
            recipient.on("download", lambda event: download_events.append(event.suggested_filename))
            cancel(owner_row)
            owner.screenshot(path=str(screenshots / "v2-owner-after-cancel.png"), full_page=True)
            expect(recipient_row).to_be_visible()
            assert recipient.evaluate("performance.timeOrigin") == original_page_time
            assert not recipient_requests
            result["stale_page_proof"] = {"same_document_time_origin": original_page_time, "no_recipient_requests_during_cancellation": True,
                                          "old_row_visible_before_download": True}
            recipient.screenshot(path=str(screenshots / "v2-recipient-stale-page.png"), full_page=True)
            checks.append({"name": "Owner cancels while recipient remains on the same unrefreshed document with the old row", "result": "passed"})

            download_url = f"{base_url}/api/files/{file_id}/download"
            with recipient.expect_response(lambda response: response.url == download_url) as denied:
                recipient_row.get_by_role("button", name=f"Download {SAMPLE_NAME}", exact=True).click()
            assert denied.value.status == 403
            assert denied.value.headers["cache-control"] == "no-store"
            expect(recipient.locator("#notice")).to_have_text("You do not have access to this file.")
            expect(recipient_row.get_by_role("button", name=f"Download {SAMPLE_NAME}", exact=True)).to_be_enabled()
            assert not download_events
            assert recipient.evaluate("performance.timeOrigin") == original_page_time
            assert recipient_requests == [{"method": "GET", "url": download_url}]
            recipient.screenshot(path=str(screenshots / "v2-stale-download-denied.png"), full_page=True)
            checks.append({"name": "Clicking the stale download button returns 403, displays rejection and creates no download", "result": "passed", "http_status": 403})
            result["stale_page_proof"]["requests_through_rejection"] = list(recipient_requests)
            result["stale_page_proof"]["download_events_after_cancellation"] = len(download_events)

            owner_hash = download(owner, owner_row, "owner-after-cancel.txt")
            assert owner_hash == content_hash
            owner.screenshot(path=str(screenshots / "v2-owner-still-downloads.png"), full_page=True)
            checks.append({"name": "Owner keeps the file and downloads identical bytes after cancellation", "result": "passed", "sha256": owner_hash})

            with recipient.expect_response(lambda response: response.url.endswith("/api/files") and response.request.method == "GET"):
                recipient.get_by_role("button", name="Refresh").click()
            expect(recipient_row).to_have_count(0)
            recipient.screenshot(path=str(screenshots / "v2-recipient-after-refresh.png"), full_page=True)
            checks.append({"name": "Refreshing the recipient list removes the canceled file", "result": "passed"})

            share(owner_row)
            recipient.get_by_role("button", name="Refresh").click()
            expect(recipient_row).to_be_visible()
            assert download(recipient, recipient_row, "recipient-after-reshare.txt") == content_hash
            checks.append({"name": "Original sharing and downloading work again after the owner regrants access", "result": "passed"})
            cancel(owner_row)
            recipient.get_by_role("button", name="Refresh").click()
            expect(recipient_row).to_have_count(0)
            expect(owner_row).to_be_visible()
            checks.append({"name": "Final demo state retains the owner's file with recipient access canceled", "result": "passed"})
            assert not result["browser_errors"], result["browser_errors"]
            checks.append({"name": "No browser JavaScript exceptions during revocation acceptance", "result": "passed"})
            result["status"] = "passed"
        except Exception:
            for index, context in enumerate(contexts):
                for page_index, page in enumerate(context.pages):
                    try:
                        page.screenshot(path=str(screenshots / f"failure-context-{index}-page-{page_index}.png"), full_page=True, timeout=5000)
                    except Exception:
                        pass
            raise
        finally:
            for context in contexts:
                context.close()
            browser.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url")
    parser.add_argument("--browser-executable", default=r"C:\Program Files\Google\Chrome\Application\chrome.exe")
    parser.add_argument("--run-id")
    args = parser.parse_args()
    started_at = datetime.now(timezone(timedelta(hours=8)))
    run_id = args.run_id or started_at.strftime("v2-%Y%m%dT%H%M%S-%f")
    if not re.fullmatch(r"[A-Za-z0-9_-]+", run_id):
        parser.error("The run ID must contain only letters, digits, underscores, or hyphens.")
    evidence_dir = ROOT / "review" / "browser-runs" / run_id
    evidence_dir.mkdir(parents=True, exist_ok=False)
    test_root = ROOT / "review" / ".tmp"
    test_root.mkdir(parents=True, exist_ok=True)
    temporary = tempfile.TemporaryDirectory(prefix="browser-v2-", dir=test_root)
    temporary_root = Path(temporary.name)
    os.environ["TEMP"] = str(temporary_root)
    os.environ["TMP"] = str(temporary_root)
    tempfile.tempdir = str(temporary_root)
    server = None
    thread = None
    result = {"run_id": run_id, "version": "v2", "timestamp": started_at.isoformat(), "status": "running", "headless": True,
              "data_mode": "running demo; samples retained" if args.base_url else "isolated temporary database",
              "regression": {"status": "running"}, "revocation": {"status": "pending"}}
    try:
        base_url = args.base_url
        if not base_url:
            server = create_server(temporary_root / "data", port=0)
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            base_url = f"http://127.0.0.1:{server.server_address[1]}"
        result["base_url"] = base_url
        run_flow(base_url, args.browser_executable, temporary_root, evidence_dir / "regression", result["regression"])
        revocation_flow(base_url, args.browser_executable, temporary_root, evidence_dir / "revocation", result["revocation"])
        result["status"] = "passed"
    except Exception as error:
        result.update({"status": "failed", "error": str(error), "traceback": traceback.format_exc()})
        raise
    finally:
        result["finished_at"] = datetime.now(timezone(timedelta(hours=8))).isoformat()
        (evidence_dir / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        if result["status"] == "passed":
            (ROOT / "review" / "browser-results-v2.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps(result, ensure_ascii=False, indent=2))
        if server:
            server.shutdown()
            server.server_close()
            thread.join(timeout=5)
        temporary_root.resolve().relative_to(test_root.resolve())
        temporary.cleanup()


if __name__ == "__main__":
    main()
