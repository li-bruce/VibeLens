"use strict";

const state = { user: null, csrfToken: "", users: [], owned: [], received: [], activeTab: "owned" };
const byId = (id) => document.getElementById(id);
let noticeTimer;

function notice(message, failure = false) {
  const target = byId("notice");
  target.textContent = message;
  target.classList.toggle("failure", failure);
  target.hidden = false;
  clearTimeout(noticeTimer);
  noticeTimer = setTimeout(() => { target.hidden = true; }, 5500);
}

async function api(path, options = {}) {
  const headers = { ...(options.headers || {}) };
  if (options.method && options.method !== "GET") headers["X-CSRF-Token"] = state.csrfToken;
  const response = await fetch(path, { ...options, headers, cache: "no-store" });
  const body = await response.json();
  if (!response.ok) {
    if (response.status === 401 && path !== "/api/login") showLogin();
    throw new Error(body.error || "The request could not be completed.");
  }
  return body;
}

function showLogin() {
  state.user = null;
  state.csrfToken = "";
  state.users = [];
  state.owned = [];
  state.received = [];
  byId("file-list").replaceChildren();
  byId("workspace-view").hidden = true;
  byId("login-view").hidden = false;
  byId("password").value = "";
}

async function showWorkspace() {
  byId("login-view").hidden = true;
  byId("workspace-view").hidden = false;
  byId("account-name").textContent = state.user.display_name;
  byId("account-username").textContent = state.user.username;
  byId("account-avatar").textContent = state.user.display_name[0];
  byId("greeting").textContent = `${state.user.display_name}'s file desk.`;
  state.activeTab = "owned";
  byId("upload-form").reset();
  byId("selected-file").textContent = "No file selected";
  byId("upload-submit").disabled = true;
  const [users, files] = await Promise.all([api("/api/users"), api("/api/files")]);
  state.users = users.users;
  state.owned = files.owned;
  state.received = files.received;
  renderFiles();
}

async function refreshFiles() {
  const files = await api("/api/files");
  state.owned = files.owned;
  state.received = files.received;
  renderFiles();
}

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function formatSize(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

async function downloadFile(file, button) {
  button.disabled = true;
  try {
    const response = await fetch(`/api/files/${file.id}/download`, { cache: "no-store" });
    if (!response.ok) {
      const body = await response.json();
      if (response.status === 401) showLogin();
      throw new Error(body.error || "The download could not be completed.");
    }
    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const link = element("a");
    link.href = url;
    link.download = file.name;
    document.body.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    notice(`Downloaded ${file.name}`);
  } catch (error) {
    notice(error.message, true);
  } finally {
    button.disabled = false;
  }
}

function shareControls(file) {
  const remaining = state.users.filter((user) => !file.recipients.some((recipient) => recipient.id === user.id));
  if (!remaining.length) return element("p", "all-shared", "Shared with all other users");
  const form = element("form", "share-form");
  const select = element("select");
  select.setAttribute("aria-label", `Recipient for ${file.name}`);
  select.required = true;
  const placeholder = element("option", "", "Select recipient");
  placeholder.value = "";
  placeholder.disabled = true;
  placeholder.selected = true;
  select.append(placeholder);
  for (const user of remaining) {
    const option = element("option", "", user.display_name);
    option.value = String(user.id);
    select.append(option);
  }
  const button = element("button", "", "Share");
  button.type = "submit";
  form.append(select, button);
  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!select.value) return;
    button.disabled = true;
    try {
      const recipient = state.users.find((user) => user.id === Number(select.value));
      await api(`/api/files/${file.id}/shares`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ recipient_id: recipient.id }),
      });
      await refreshFiles();
      notice(`Shared ${file.name} with ${recipient.display_name}. They can view and download.`);
    } catch (error) {
      notice(error.message, true);
      button.disabled = false;
    }
  });
  return form;
}

function recipientAccess(file, recipient) {
  const group = element("div", "recipient-access");
  const button = element("button", "cancel-share-button", "Cancel sharing");
  button.type = "button";
  button.setAttribute("aria-label", `Cancel sharing with ${recipient.display_name} for ${file.name}`);
  button.addEventListener("click", async () => {
    button.disabled = true;
    try {
      await api(`/api/files/${file.id}/revoke`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ recipient_id: recipient.id }),
      });
      await refreshFiles();
      notice(`Sharing with ${recipient.display_name} was canceled. Your file is still available to you.`);
    } catch (error) {
      notice(error.message, true);
      button.disabled = false;
    }
  });
  group.append(element("span", "access-tag", `${recipient.display_name} · View & download`), button);
  return group;
}

function renderFiles() {
  const isOwned = state.activeTab === "owned";
  byId("owned-count").textContent = String(state.owned.length);
  byId("received-count").textContent = String(state.received.length);
  for (const kind of ["owned", "received"]) {
    const tab = byId(`${kind}-tab`);
    const selected = state.activeTab === kind;
    tab.classList.toggle("active", selected);
    tab.setAttribute("aria-selected", String(selected));
    tab.tabIndex = selected ? 0 : -1;
  }
  byId("file-panel").setAttribute("aria-labelledby", `${state.activeTab}-tab`);
  byId("permission-description").textContent = isOwned
    ? "You own these files. Share with selected recipients or cancel their access; your files stay with you."
    : "These owners shared files with you. You can view file information and download; only the owner can share.";
  const list = byId("file-list");
  list.replaceChildren();
  const files = state[state.activeTab];
  if (!files.length) {
    const empty = element("div", "empty-state");
    empty.append(element("div", "empty-symbol", "▤"),
      element("h3", "", isOwned ? "Your desk is ready for its first file" : "No files have been shared with you"),
      element("p", "", isOwned ? "Upload a file above, then choose someone to share it with." : "Files appear here when their owner chooses you as a recipient."));
    list.append(empty);
    return;
  }
  const scroll = element("div", "table-scroll");
  const table = element("table");
  table.setAttribute("aria-label", isOwned ? "My files" : "Files shared with me");
  const head = element("thead");
  const heading = element("tr");
  for (const title of ["FILE NAME", "OWNER", isOwned ? "WHO HAS ACCESS" : "YOUR ACCESS", "ACTIONS"]) {
    const cell = element("th", "", title);
    cell.scope = "col";
    heading.append(cell);
  }
  head.append(heading);
  const body = element("tbody");
  for (const file of files) {
    const row = element("tr");
    row.dataset.fileId = String(file.id);
    const nameCell = element("td");
    const fileCell = element("div", "file-cell");
    const suffix = file.name.includes(".") ? file.name.split(".").pop().slice(0, 4).toUpperCase() : "FILE";
    const details = element("div");
    details.append(element("span", "file-title", file.name), element("span", "file-meta", `${formatSize(file.size)} · ${new Date(file.created_at * 1000).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" })}`));
    fileCell.append(element("span", "file-icon", suffix), details);
    nameCell.append(fileCell);
    const ownerCell = element("td");
    ownerCell.append(element("span", "owner-label", file.owner_name), element("span", "owner-subtitle", isOwned ? "You · File owner" : "Shared by owner"));
    const accessCell = element("td");
    if (isOwned) {
      accessCell.append(element("span", "owner-subtitle", "You · Own & share"));
      if (file.recipients.length) {
        for (const recipient of file.recipients) accessCell.append(recipientAccess(file, recipient));
      } else {
        accessCell.append(element("span", "access-private", "Only you · No recipients"));
      }
    } else {
      accessCell.append(element("span", "access-tag", "View & download"), element("span", "owner-subtitle", "Sharing is controlled by the owner"));
    }
    const actions = element("td", "action-cell");
    const download = element("button", "download-button", "Download ↓");
    download.type = "button";
    download.setAttribute("aria-label", `Download ${file.name}`);
    download.addEventListener("click", () => downloadFile(file, download));
    actions.append(download);
    if (isOwned) actions.append(shareControls(file));
    row.append(nameCell, ownerCell, accessCell, actions);
    body.append(row);
  }
  table.append(head, body);
  scroll.append(table);
  list.append(scroll);
}

byId("login-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  byId("login-submit").disabled = true;
  byId("login-error").hidden = true;
  try {
    const session = await api("/api/login", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username: byId("username").value, password: byId("password").value }) });
    state.user = session.user;
    state.csrfToken = session.csrf_token;
    byId("password").value = "";
    await showWorkspace();
  } catch (error) {
    byId("login-error").textContent = error.message;
    byId("login-error").hidden = false;
  } finally {
    byId("login-submit").disabled = false;
  }
});

document.querySelectorAll("[data-account]").forEach((button) => button.addEventListener("click", () => {
  byId("username").value = button.dataset.account;
  byId("password").value = "Demo123!";
  byId("login-submit").focus();
}));

byId("sign-out").addEventListener("click", async () => {
  try { await api("/api/logout", { method: "POST" }); showLogin(); }
  catch (error) { notice(error.message, true); }
});

byId("file-input").addEventListener("change", () => {
  const file = byId("file-input").files[0];
  byId("selected-file").textContent = file ? file.name : "No file selected";
  byId("upload-submit").disabled = !file;
});

byId("upload-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const file = byId("file-input").files[0];
  if (!file) return;
  if (file.size > 10 * 1024 * 1024) { notice("The file is too large. Maximum file size is 10 MB.", true); return; }
  byId("upload-submit").disabled = true;
  try {
    const body = new FormData();
    body.append("file", file);
    await api("/api/files", { method: "POST", body });
    state.activeTab = "owned";
    await refreshFiles();
    byId("upload-form").reset();
    byId("selected-file").textContent = "No file selected";
    notice(`Uploaded ${file.name}. You are the owner.`);
  } catch (error) { notice(error.message, true); }
  finally { byId("upload-submit").disabled = !byId("file-input").files.length; }
});

for (const kind of ["owned", "received"]) {
  byId(`${kind}-tab`).addEventListener("click", () => { state.activeTab = kind; renderFiles(); });
  byId(`${kind}-tab`).addEventListener("keydown", (event) => {
    if (["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) {
      event.preventDefault();
      state.activeTab = event.key === "Home" ? "owned" : event.key === "End" ? "received" : kind === "owned" ? "received" : "owned";
      renderFiles();
      byId(`${state.activeTab}-tab`).focus();
    }
  });
}
byId("refresh-files").addEventListener("click", () => refreshFiles().catch((error) => notice(error.message, true)));

(async () => {
  try {
    const session = await api("/api/session");
    if (!session.user) { showLogin(); return; }
    state.user = session.user;
    state.csrfToken = session.csrf_token;
    await showWorkspace();
  } catch (error) { showLogin(); notice(error.message, true); }
})();
