# File Desk

A small local file-sharing application using Python, SQLite, and plain HTML/CSS/JavaScript. The server has no third-party dependencies.

## Run

Requires Python 3.10 or newer. From this project directory:

```powershell
python app.py --port 8767
```

Open http://127.0.0.1:8767. The server binds only to the local loopback interface. To use another port or an isolated data directory, pass `--port` or `--data-dir`.

| Display name | Username | Password | Demo scenario |
|---|---|---|---|
| 林舟 | linzhou | Demo123! | Upload and share a file |
| 许宁 | xuning | Demo123! | Receive and download that file |
| 周岚 | zhoulan | Demo123! | No access to that shared file |

All users can upload their own files. The scenarios above are examples, not global role restrictions. Choose a demo account on the sign-in screen to fill its credentials, then press **Sign in**.

## Main flow

1. Sign in as 林舟 and upload a file (up to 10 MiB).
2. Under **My files**, select 许宁 and press **Share**. The owner and recipients are listed next to the file.
3. Sign out and sign in as 许宁. Under **Shared with me**, view the file name, size, and owner, then press **Download**.
4. Sign in as 周岚. The file is absent from the list; direct file information and download requests are denied.

5. As the owner, press **Cancel sharing** beside a recipient. That recipient's next download is denied even if their page is still open. The owner keeps the file and can still download it.

The recipient cannot share, cancel another user's access, or modify the file. V2 adds cancellation for one selected recipient; it has no preview or file deletion. The owner may share the file again using the original control.

## Files and permissions

- `app.py`: HTTP endpoints, login sessions, SQLite schema, uploads, and permission checks.
- `static/`: lightweight web interface without a build step or external resources.
- `data/app.sqlite3`: runtime users, sessions, file metadata, and explicit recipient permissions.
- `data/uploads/`: file contents stored with random keys, outside static routing.
- `tests/test_app.py`: real HTTP integration tests with a temporary database and storage.
- `tests/browser_check.py`: optional Playwright browser acceptance checks; requires Playwright and Chromium for testing only.
- `tests/test_revocation.py`: revocation authorization, scope, persistence, and resharing tests.
- `tests/browser_check_v2.py`: headless V1 regression and V2 stale-page download acceptance.
- `review/`: original requirements and answer, design decisions, change history, test reports, and screenshots.

The authenticated user becomes the owner of every uploaded file. Only the owner may add or remove recipients. File listing, metadata, and download endpoints enforce permissions on the server. Cancellation deletes only the selected `(file_id, recipient_id)` grant and commits before returning success. Download requests read current permissions from SQLite. Session tokens are stored as hashes; passwords use salted PBKDF2. Mutations require a session CSRF token and reject cross-origin requests.

## Verify

```powershell
python -m unittest discover -s tests -p 'test_*.py' -v
python tests/browser_check_v2.py
python tests/browser_check_v2.py --base-url http://127.0.0.1:8767
```

The browser check runs headless and creates its own temporary database and local server by default. Use `--base-url` to check the running demo and leave an explicitly labeled sample file for manual review. Every run creates a unique evidence directory under `review/browser-runs/`, including results, screenshots, and downloaded bytes; failures retain partial results and screenshots. Use `--run-id` to name a new evidence directory explicitly. Tests do not alter unrelated projects.

V2 acceptance: 20 HTTP integration tests and 22 checks against the live demo passed, including the unrefreshed-page rejection and owner download. See `review/test-results-v2.md`. V1 source, design, failed attempts, retests, and screenshots remain preserved; its source archive is `review/v1-source-baseline.zip`.

This is a local demo with known demonstration passwords and HTTP cookies for loopback access. Deployment, public hosting, registration, TLS, and broader account administration are outside this version's scope.
