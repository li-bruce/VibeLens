$projectRoot = Split-Path -Parent $PSScriptRoot
$recordPath = Join-Path $projectRoot 'review\running-services.json'
if (-not (Test-Path -LiteralPath $recordPath)) { exit 0 }
$record = Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json
$launcher = Get-CimInstance Win32_Process -Filter ('ProcessId = ' + $record.pid) -ErrorAction SilentlyContinue
if ($launcher -and $launcher.CommandLine -and $launcher.CommandLine.Contains($projectRoot) -and $launcher.CommandLine.Contains('run.py')) {
    & taskkill /PID $record.pid /T /F
}
