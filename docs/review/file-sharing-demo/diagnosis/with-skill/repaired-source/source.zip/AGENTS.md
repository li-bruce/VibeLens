# Project verification

Maintain the developer graph, source mappings, canonical state declaration, and independent expectations. Run `python tooling/verify.py` before delivery. Preserve accepted baselines. Activate VibeLens conversation guidance only after an explicit invocation in the current conversation. Manual viewer controls require `/vibelens`. This local trial uses the Skill path recorded in `tooling/skill-path.txt`; do not edit that source repository.
