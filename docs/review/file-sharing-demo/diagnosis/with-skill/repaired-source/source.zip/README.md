# File Sharing Policy Trial

A local Python and SQLite application for a deliberately small sharing flow:
sign in, upload a file, select an existing recipient, and download shared files.

The supplied answers are **simulated trial evidence**, preserved verbatim in
`review/simulated-answer-01.txt`. They are not independent human acceptance.

## Run

From this project directory in PowerShell:

```powershell
.\.venv\Scripts\python.exe -B run.py
```

- Application: http://127.0.0.1:8850/
- Developer graph: http://127.0.0.1:8847/graph
- Accounts: `linzhou` (林舟), `xuning` (许宁), `zhoulan` (周岚)
- Demonstration password for all three accounts: `file-demo-2026`

The launcher starts its own worker, prints both actual URLs, restarts that worker
after the canonical graph or its bound source changes, and terminates only the worker it created.
Use `--core` to run without the observer. The native declaration and policy
executor remain available when the observer is absent or unavailable.

## Permissions and scope

Every authenticated user may upload their own files. The uploader becomes the
immutable owner. Only the owner may share with an existing user. Owners and
designated recipients may view metadata and download; unrelated users cannot.
Only the owner may revoke access for one selected recipient. After its transaction commits, the server rejects a new download request from an unchanged recipient page. The file and owner download remain. The application reevaluates each request against SQLite facts. Recipient access
does not grant ownership, content editing, or resharing.

Version two adds recipient-specific revocation. File deletion, online preview, registration, teams, public links, approval, and subscription features remain outside the scope. Initial source, checks, and screenshots are frozen in `review/baselines/initial-v1/`.

Content is stored as a SQLite BLOB with its metadata in one transaction. Requests
are limited to 16 MiB per file. This is a loopback-only local demonstration.

## Reproduce checks

```powershell
.\.venv\Scripts\python.exe -B tooling/build_model.py
.\.venv\Scripts\python.exe -B tooling/refresh_graph.py
.\.venv\Scripts\python.exe -B tooling/reconcile.py
.\.venv\Scripts\python.exe -B tooling/verify.py
.\.venv\Scripts\python.exe -B tooling/browser_check.py
.\.venv\Scripts\python.exe -B tooling/browser_revoke_check.py
```

The browser check uses headless Playwright and installed Chrome. Set
`FILE_SHARING_BROWSER` to another compatible Chromium executable if needed.
Keep the local services running for that check. It saves the actual operation
order, screenshots, downloaded bytes, recording information, and served-build
identity to `review/browser/`.

`verify.py` runs the activated Skill's source scan and inspect/verify/accept/check
cycle. It never recreates the immutable initial baseline. The initial frozen
requirements, independent expectations, on/off/fault observations, state
witnesses, failure records, and retests remain in this project.

## Local Skill integration

The exact user-selected Skill path is recorded in `tooling/skill-path.txt`.
Runtime copies are installed and upgraded only through its `bo_upgrade.py`.
The native policy package is checked against the managed manifest and the
current canonical source. The native executor is independently inventoried as
application source rather than hidden by a broad exclusion.

The separately recorded framework compatibility regression uses an unreleased
working-tree candidate through the normal upgrade interface. The former local
schema/projection shim and its CLI wrapper have been removed. Project checks
invoke the canonical CLI directly; installed protocol validation and projection
composition run without monkeypatches. Arbitrary `maps` edges remain rejected.
The unchanged `integrations/bo_view.py` converts the project's native flat-state
journal into historical display frames while retaining the original journal.
This is application-format adaptation, not a framework schema override.
The previous adapted V2 source, acceptance evidence, and costs are preserved;
candidate-framework regression results and costs are separate under
`review/framework-compat-01/`. Repository-wide release acceptance is not claimed.

Graph mapping, native state consistency, business expectations, application
checks, and actual browser acceptance are reported separately. Static calls do
not prove runtime execution; unexercised paths remain outside the evidence.
