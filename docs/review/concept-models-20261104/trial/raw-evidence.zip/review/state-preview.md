# State model draft

```mermaid
flowchart LR
  n0["revoke"]
  n1["share"]
  n2["may_manage"]
  n3["Recipient grant"]
  n4["active"]
  n5["inactive"]
  n6["grant-replace"]
  n7["grant-revoke"]
  n8["grant-share"]
  n1 -->|"requests_transition"| n6
  n0 -->|"requests_transition"| n7
  n1 -->|"requests_transition"| n8
  n3 -->|"contains"| n4
  n3 -->|"contains"| n5
  n3 -->|"declares_event"| n0
  n3 -->|"declares_event"| n1
  n3 -->|"declares_guard"| n2
  n4 -->|"share"| n4
  n4 -->|"revoke"| n5
  n5 -->|"share"| n4
  n6 -->|"guarded_by"| n2
  n7 -->|"guarded_by"| n2
  n8 -->|"guarded_by"| n2
  n6 -->|"declares_target"| n4
  n7 -->|"declares_target"| n5
  n8 -->|"declares_target"| n4
  b0["policy-operation:manage (outside scope)"]
  n2 -.->|"guard_resolves_decision"| b0
  b1["See received files (outside scope)"]
  b1 -.->|"reads_state"| n3
  b2["Read shared file (outside scope)"]
  b2 -.->|"reads_state"| n3
  b3["Revoke access (outside scope)"]
  b3 -.->|"changes_state"| n3
  b4["Share file (outside scope)"]
  b4 -.->|"changes_state"| n3
  b5["policy-operation:manage (outside scope)"]
  n6 -.->|"transition_guarded_by"| b5
  b6["policy-operation:manage (outside scope)"]
  n7 -.->|"transition_guarded_by"| b6
  b7["Revoke access (outside scope)"]
  b7 -.->|"action_requests_event"| n0
  b8["policy-operation:manage (outside scope)"]
  n8 -.->|"transition_guarded_by"| b8
  b9["Share file (outside scope)"]
  b9 -.->|"action_requests_event"| n1
  b10["grant (outside scope)"]
  n3 -.->|"state_subject"| b10
```

[Open the live graph](http://127.0.0.1:8916/graph)

This is a focused view. Dashed boundaries retain original relations; open Web for the complete graph.

Confirm this understanding in the conversation, or describe a correction. Viewing the graph is not confirmation.
