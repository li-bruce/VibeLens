# Rule network draft

```mermaid
flowchart LR
  n0["active-grant"]
  n1["actor-id"]
  n2["owner-id"]
  n3["recipient-id"]
  n4["policy-predicate:same_identity"]
  n5["active"]
  n6["actor"]
  n7["is_owner"]
  n8["is_recipient"]
  n9["may_read"]
  n10["owner"]
  n11["recipient"]
  n4 -->|"data"| n7
  n6 -->|"data"| n7
  n10 -->|"data"| n7
  n4 -->|"data"| n8
  n6 -->|"data"| n8
  n11 -->|"data"| n8
  n8 -->|"guard"| n9
  n5 -->|"guard"| n9
  n5 -->|"decision_reads_fact"| n0
  n6 -->|"decision_reads_fact"| n1
  n10 -->|"decision_reads_fact"| n2
  n11 -->|"decision_reads_fact"| n3
  b0["grant (outside scope)"]
  b0 -.->|"describes_fact"| n0
  b1["actor (outside scope)"]
  b1 -.->|"describes_fact"| n1
  b2["grant (outside scope)"]
  b2 -.->|"describes_fact"| n2
  b3["grant (outside scope)"]
  b3 -.->|"describes_fact"| n3
  b4["policy-operation:manage (outside scope)"]
  n7 -.->|"decision_result"| b4
  b5["policy-operation:read (outside scope)"]
  n9 -.->|"decision_result"| b5
```

[Open the live graph](http://127.0.0.1:8916/graph)

This is a focused view. Dashed boundaries retain original relations; open Web for the complete graph.

Confirm this understanding in the conversation, or describe a correction. Viewing the graph is not confirmation.
