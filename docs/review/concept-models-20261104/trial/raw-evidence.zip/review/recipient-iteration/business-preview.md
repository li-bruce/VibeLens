# Business network draft

```mermaid
flowchart LR
  n0["File sharing"]
  n1["See received files"]
  n2["actor"]
  n3["grant"]
  n4["Read shared file"]
  n5["Revoke access"]
  n6["Share file"]
  n7["Upload file"]
  n0 -->|"Contains"| n1
  n0 -->|"Contains"| n4
  n0 -->|"Contains"| n5
  n0 -->|"Contains"| n6
  n0 -->|"Contains"| n7
  n1 -->|"Download file"| n4
  n6 -->|"Recipient sees file"| n1
  n6 -->|"Owner withdraws access"| n5
  n7 -->|"Choose recipient"| n6
  b0["active-grant (outside scope)"]
  n3 -.->|"Describes"| b0
  b1["actor-id (outside scope)"]
  n2 -.->|"Describes"| b1
  b2["owner-id (outside scope)"]
  n3 -.->|"Describes"| b2
  b3["recipient-id (outside scope)"]
  n3 -.->|"Describes"| b3
  b4["policy-operation:read (outside scope)"]
  n1 -.->|"Requires"| b4
  b5["policy-operation:read (outside scope)"]
  n4 -.->|"Requires"| b5
  b6["policy-operation:manage (outside scope)"]
  n5 -.->|"Requires"| b6
  b7["policy-operation:manage (outside scope)"]
  n6 -.->|"Requires"| b7
  b8["Recipient grant (outside scope)"]
  n1 -.->|"Reads state"| b8
  b9["Recipient grant (outside scope)"]
  n4 -.->|"Reads state"| b9
  b10["Recipient grant (outside scope)"]
  n5 -.->|"Changes state"| b10
  b11["Recipient grant (outside scope)"]
  n6 -.->|"Changes state"| b11
  b12["revoke (outside scope)"]
  n5 -.->|"Triggers"| b12
  b13["share (outside scope)"]
  n6 -.->|"Triggers"| b13
  b14["Recipient grant (outside scope)"]
  b14 -.->|"State of"| n3
```

[Open the live graph](http://127.0.0.1:8916/graph)

This is a focused view. Dashed boundaries retain original relations; open Web for the complete graph.

Confirm this understanding in the conversation, or describe a correction. Viewing the graph is not confirmation.
