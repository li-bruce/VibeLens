# State model draft

```mermaid
flowchart LR
  n0["revoke"]
  n1["share"]
  n2["may_manage"]
  n3["Recipient grant"]
  n4["active"]
  n5["inactive"]
  n6["grant-replace"]
  n7["grant-revoke"]
  n8["grant-share"]
  n1 -->|"Triggers"| n6
  n0 -->|"Triggers"| n7
  n1 -->|"Triggers"| n8
  n3 -->|"Contains"| n4
  n3 -->|"Contains"| n5
  n3 -->|"Event"| n0
  n3 -->|"Event"| n1
  n3 -->|"Condition"| n2
  n4 -->|"share"| n4
  n4 -->|"revoke"| n5
  n5 -->|"share"| n4
  n6 -->|"Requires"| n2
  n7 -->|"Requires"| n2
  n8 -->|"Requires"| n2
  n6 -->|"Enters"| n4
  n7 -->|"Enters"| n5
  n8 -->|"Enters"| n4
  b0["policy-operation:manage (outside scope)"]
  n2 -.->|"Evaluates"| b0
  b1["See received files (outside scope)"]
  b1 -.->|"Reads state"| n3
  b2["Read shared file (outside scope)"]
  b2 -.->|"Reads state"| n3
  b3["Revoke access (outside scope)"]
  b3 -.->|"Changes state"| n3
  b4["Share file (outside scope)"]
  b4 -.->|"Changes state"| n3
  b5["policy-operation:manage (outside scope)"]
  n6 -.->|"Requires"| b5
  b6["policy-operation:manage (outside scope)"]
  n7 -.->|"Requires"| b6
  b7["Revoke access (outside scope)"]
  b7 -.->|"Triggers"| n0
  b8["policy-operation:manage (outside scope)"]
  n8 -.->|"Requires"| b8
  b9["Share file (outside scope)"]
  b9 -.->|"Triggers"| n1
  b10["grant (outside scope)"]
  n3 -.->|"State of"| b10
```

[Open the live graph](http://127.0.0.1:8916/graph)

This is a focused view. Dashed boundaries retain original relations; open Web for the complete graph.

Confirm this understanding in the conversation, or describe a correction. Viewing the graph is not confirmation.
