# Business network draft

```mermaid
flowchart LR
  n0["File sharing"]
  n1["See received files"]
  n2["actor"]
  n3["grant"]
  n4["Read shared file"]
  n5["Revoke access"]
  n6["Share file"]
  n7["Upload file"]
  n0 -->|"contains"| n1
  n0 -->|"contains"| n4
  n0 -->|"contains"| n5
  n0 -->|"contains"| n6
  n0 -->|"contains"| n7
  n1 -->|"Download file"| n4
  n6 -->|"Recipient sees file"| n1
  n6 -->|"Owner withdraws access"| n5
  n7 -->|"Choose recipient"| n6
  b0["active-grant (outside scope)"]
  n3 -.->|"describes_fact"| b0
  b1["actor-id (outside scope)"]
  n2 -.->|"describes_fact"| b1
  b2["owner-id (outside scope)"]
  n3 -.->|"describes_fact"| b2
  b3["recipient-id (outside scope)"]
  n3 -.->|"describes_fact"| b3
  b4["policy-operation:read (outside scope)"]
  n1 -.->|"requires_decision"| b4
  b5["policy-operation:read (outside scope)"]
  n4 -.->|"requires_decision"| b5
  b6["policy-operation:manage (outside scope)"]
  n5 -.->|"requires_decision"| b6
  b7["policy-operation:manage (outside scope)"]
  n6 -.->|"requires_decision"| b7
  b8["Recipient grant (outside scope)"]
  n1 -.->|"reads_state"| b8
  b9["Recipient grant (outside scope)"]
  n4 -.->|"reads_state"| b9
  b10["Recipient grant (outside scope)"]
  n5 -.->|"changes_state"| b10
  b11["Recipient grant (outside scope)"]
  n6 -.->|"changes_state"| b11
  b12["revoke (outside scope)"]
  n5 -.->|"action_requests_event"| b12
  b13["share (outside scope)"]
  n6 -.->|"action_requests_event"| b13
  b14["Recipient grant (outside scope)"]
  b14 -.->|"state_subject"| n3
```

[Open the live graph](http://127.0.0.1:8916/graph)

This is a focused view. Dashed boundaries retain original relations; open Web for the complete graph.

Confirm this understanding in the conversation, or describe a correction. Viewing the graph is not confirmation.
